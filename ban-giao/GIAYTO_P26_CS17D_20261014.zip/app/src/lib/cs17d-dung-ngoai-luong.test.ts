import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { cleanEdges, runJob, type PixelJob } from "./pixels";
import { trimBox } from "./dewarp";
import { applyFilterPx, cleanEdgesPx, type RenderEnv } from "./render-core";
import { Lru } from "./render-cache";

/** CS-17d: dựng bản đầy đủ trên bộ đệm (render-core) trong Worker — luồng chính không đọc/ghi điểm ảnh lớn. */
const img = (W: number, H: number, seed: number) => {
  const d = new Uint8ClampedArray(W * H * 4); let s = seed;
  const rnd = () => ((s = (s * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const edge = x < 6 || y < 5 || x > W - 7; // dải nền tối sát mép
    const ink = !edge && y % 17 < 4 && x > 20 && x < W - 20 && rnd() > 0.3, v = edge ? 30 : ink ? 40 : 215 - ((30 * x) / W) | 0, i = (y * W + x) * 4;
    d[i] = v; d[i + 1] = v - 2; d[i + 2] = ink ? 120 : v - 6; d[i + 3] = 255;
  }
  return d;
};
/** Môi trường giả: chạy việc điểm ảnh tại chỗ, không cần canvas (các nhánh thử không đụng canvas). */
const env: RenderEnv = {
  canvas: () => { throw new Error("không dùng canvas trong ca này"); },
  run: async (j: PixelJob) => runJob(j),
  warp: async () => { throw new Error("không nắn"); },
  jpeg: async () => null,
  bitmap: async () => { throw new Error("không giải mã"); },
};

describe("CS-17d render-core trên bộ đệm", () => {
  it("cleanEdgesPx = trimBox + cắt + cleanEdges như bản canvas cũ", async () => {
    const W = 160, H = 220, a = img(W, H, 3);
    const b = trimBox(a, W, H), w = b.x1 - b.x0, h = b.y1 - b.y0;
    const crop = new Uint8ClampedArray(w * h * 4);
    for (let y = 0; y < h; y++) { const s = ((y + b.y0) * W + b.x0) * 4; crop.set(a.subarray(s, s + w * 4), y * w * 4); }
    const want = cleanEdges(crop, w, h);
    const got = await cleanEdgesPx(env, { d: a.slice(), w: W, h: H });
    expect([got.w, got.h]).toEqual([w, h]);
    expect(Array.from(got.d)).toEqual(Array.from(want));
  });
  it("applyFilterPx: Tự động (đã chuẩn sáng) = docchain deep; cấp độ < 100 trộn với bản vào", async () => {
    const W = 120, H = 150, a = img(W, H, 5);
    const want = runJob({ op: "docchain", d: a.slice(), W, H, sharp: false, deep: true });
    expect(Array.from(await applyFilterPx(env, a.slice(), W, H, { filter: "auto", brightness: 0, contrast: 0, preFlat: true }))).toEqual(Array.from(want));
    const half = await applyFilterPx(env, a.slice(), W, H, { filter: "auto", brightness: 0, contrast: 0, preFlat: true, level: 50 });
    for (const i of [0, 4 * 777, 4 * 5000 + 1]) expect(half[i]).toBe(new Uint8ClampedArray([a[i]! + (want[i]! - a[i]!) * 0.5])[0]);
  });
  it("Lru.delete bỏ mục và trừ dung lượng (bộ đệm mượn bị mất)", () => {
    const l = new Lru<Uint8Array>(4, undefined, (v) => v.length, 100);
    l.set("a", new Uint8Array(30)); l.set("b", new Uint8Array(20));
    l.delete("a"); l.delete("không-có");
    expect(l.get("a")).toBeUndefined(); expect(l.size).toBe(1); expect(l.bytes).toBe(20);
  });
  it("kiểm tĩnh: dựng trang đi qua Worker 'render', bộ đệm lớn cho mượn (không sao chép trên luồng chính)", () => {
    const im = readFileSync("src/lib/image.ts", "utf8"), pw = readFileSync("src/lib/pool.worker.ts", "utf8"), rc = readFileSync("src/lib/render-core.ts", "utf8");
    expect(im).toMatch(/runInPool<T & OffReply>\("render"/);
    expect(im).toMatch(/lend: true/);
    expect(im).not.toMatch(/async function (applyFilter|flattenLight|band0Fix|cleanEdges)\(/); // bản canvas cũ đã thay bằng render-core
    expect(pw).toMatch(/back\.slice\(\)/); // Worker tự sao chép bộ đệm mượn
    expect(pw).toMatch(/post\(\{ id: m\.id, fallback:[^\n]*back/); // lỗi vẫn trả bộ đệm mượn
    expect(rc).not.toMatch(/document\./); // chạy được trong Worker
    expect(rc).not.toMatch(/await import\(/); // Worker iife không tách chunk
  });
});
