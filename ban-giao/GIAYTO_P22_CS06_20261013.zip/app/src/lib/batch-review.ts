// CS-06: xem lại theo lô — trang nào cần xem, vì sao, và cách ghi kết quả mà KHÔNG chặn các trang khác.
import type { Page, PageEdit } from "./db";
import { needsReview, type PageReview } from "./page-review";
import { pageStatus, withStatus } from "./page-state";

/** Dấu ghi vào page.warnings khi máy chưa chắc mép giấy lúc chụp (trước: chỉ nằm trong state màn Chụp → mất khi bấm Xong). */
export const EDGE_WARNING = "Máy chưa chắc mép giấy";

/** Chỉ số các trang cần xem lại: trạng thái "xem-lai", có cảnh báo lúc chụp, hoặc điểm chất lượng thấp (đã đo). */
export function reviewTargets(pages: Page[], reviews: Record<string, PageReview | undefined> = {}): number[] {
  const out: number[] = [];
  pages.forEach((p, i) => {
    const r = reviews[p.id];
    if (pageStatus(p) === "xem-lai" || (p.warnings?.length ?? 0) > 0 || (!p.manual && r && needsReview(r.score))) out.push(i);
  });
  return out;
}

export function reviewReason(p: Page, r?: PageReview): string {
  if (p.warnings?.length) return p.warnings.join("; ");
  if (pageStatus(p) === "xem-lai") return "App chưa chắc khung cắt của trang này";
  if (r && needsReview(r.score)) return `Chất lượng thấp (${r.score}/100) — ${r.note}`;
  return "";
}

/** "Giữ nguyên": bỏ cảnh báo, trang xem-lai → xong. Không đổi ảnh. */
export function markChecked(p: Page): Page {
  const { warnings: _w, ...rest } = p; void _w;
  const q = rest as Page;
  return pageStatus(q) === "xem-lai" ? withStatus(q, "xong") : q;
}

/**
 * Sửa khung một trang mà không chờ dựng ảnh: ghi edit mới + trạng thái "dang" — bộ điều phối nền (healPending → việc "finish")
 * dựng bản đầy đủ sau, người dùng sang trang kế ngay (tiêu chí "sửa 1 trang không chặn trang khác").
 */
export function applyCropFix(p: Page, edit: Partial<PageEdit>): Page {
  const { warnings: _w, ...rest } = p; void _w;
  let q: Page = { ...(rest as Page), edit: { ...p.edit, ...edit }, manual: true };
  const s = pageStatus(q);
  if (s === "loi") q = withStatus(q, "cho");
  if (s === "moi") q = withStatus(q, "cho");
  return pageStatus(q) === "dang" ? q : withStatus(q, "dang");
}
