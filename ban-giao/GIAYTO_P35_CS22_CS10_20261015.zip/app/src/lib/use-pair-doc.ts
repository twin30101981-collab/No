// CS-10: hook nối điện thoại ↔ tài liệu đang mở (phòng ghép G4-02, nhận ảnh G4-03, hàng đợi tuần tự).
import { useEffect, useReducer, useRef, useState } from "react";
import QRCode from "qrcode";
import { Assembler, type Part } from "@/lib/pair-transfer";
import { joinRoom, newRoomCode, pairUrl, remaining, type PairPeer } from "@/lib/pair";
import { dataUrlToFile, queueReduce, type QueueItem } from "@/lib/pair-doc";

export type PairDocState = { room: { code: string; created: number } | null; qr: string; phone: PairPeer | undefined; queue: QueueItem[]; left: number; fresh: () => void; clear: () => void };

/** `active` bật = tạo phòng + nghe ảnh; `onImage` thêm 1 ảnh vào tài liệu, trả true khi đã thêm. Ảnh tới được xếp hàng, thêm lần lượt. */
export function usePairDoc(active: boolean, onImage: (f: File) => Promise<boolean>): PairDocState {
  const [room, setRoom] = useState<{ code: string; created: number } | null>(null);
  const [qr, setQr] = useState("");
  const [peers, setPeers] = useState<PairPeer[]>([]);
  const [now, setNow] = useState(Date.now());
  const [queue, dispatch] = useReducer(queueReduce, [] as QueueItem[]);
  const cb = useRef(onImage); cb.current = onImage;
  const chain = useRef<Promise<void>>(Promise.resolve());
  const count = useRef(0);

  useEffect(() => { if (active && !room) setRoom({ code: newRoomCode(), created: Date.now() }); if (!active) { setRoom(null); setPeers([]); } }, [active, room]);
  useEffect(() => { if (!active) return; const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, [active]);
  useEffect(() => {
    if (!room) return;
    let off = false;
    void QRCode.toDataURL(pairUrl(location.origin, room.code, room.created), { margin: 1, width: 320 }).then((u) => { if (!off) setQr(u); });
    setPeers([]);
    const asm = new Assembler();
    const r = joinRoom(room.code, { role: "desktop", device: "Máy tính" }, setPeers, undefined, (ch) => {
      ch.on("broadcast", { event: "part" }, ({ payload }) => {
        const p = payload as Part;
        const done = asm.push(p);
        if (!done) { const pr = asm.progress(p.id); if (pr !== null) dispatch({ type: "progress", id: p.id, pct: pr }); return; }
        dispatch({ type: "received", id: done.id });
        void ch.send({ type: "broadcast", event: "ack", payload: { id: done.id } });
        const n = ++count.current;
        chain.current = chain.current.then(async () => {
          dispatch({ type: "adding", id: done.id });
          try { dispatch({ type: (await cb.current(dataUrlToFile(done.dataUrl, `Từ điện thoại ${n}`))) ? "done" : "fail", id: done.id }); }
          catch { dispatch({ type: "fail", id: done.id }); }
        });
      });
    });
    return () => { off = true; r.leave(); };
  }, [room]);

  return {
    room, qr, phone: peers.find((p) => p.role === "phone"), queue, left: room ? remaining(room.created, now) : 0,
    fresh: () => { setQr(""); setRoom({ code: newRoomCode(), created: Date.now() }); },
    clear: () => dispatch({ type: "clear" }),
  };
}
