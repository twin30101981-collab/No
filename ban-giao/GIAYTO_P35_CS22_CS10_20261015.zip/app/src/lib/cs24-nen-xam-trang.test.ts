import { describe, expect, it } from "vitest";
import { PAPER_TARGET, whitenPaper } from "./auto-level";

const px = (v: number) => new Uint8ClampedArray([v, v, v, 255]);
describe("CS-24 whitenPaper (nền bộ lọc Xám)", () => {
  it("nền giấy PAPER_TARGET → 255, nét tối không đổi", () => {
    const a = px(PAPER_TARGET); whitenPaper(a); expect(a[0]).toBe(255);
    for (const v of [0, 40, 128, 200, 232]) { const b = px(v); whitenPaper(b); expect(b[0]).toBe(v); }
  });
  it("đơn điệu, không bước nhảy > 6 mức giữa hai mức liền kề", () => {
    let prev = -1;
    for (let v = 0; v < 256; v++) { const b = px(v); whitenPaper(b); expect(b[0]!).toBeGreaterThanOrEqual(prev); if (prev >= 0) expect(b[0]! - prev).toBeLessThanOrEqual(6); prev = b[0]!; }
  });
});
