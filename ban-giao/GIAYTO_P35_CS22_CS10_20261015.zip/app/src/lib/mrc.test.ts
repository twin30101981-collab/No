import { describe, expect, it } from "vitest";
import { mrcSplit } from "./mrc";
import { encodeG4, packG4 } from "./g4";

/** Trang giả: nền kem có nhiễu + dòng chữ đen + dấu đỏ. */
function page(w: number, h: number, seed = 1) {
  const d = new Uint8ClampedArray(w * h * 4); let s = seed;
  const rnd = () => ((s = (s * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff - 0.5);
  for (let i = 0; i < w * h; i++) { const v = 238 + rnd() * 10; d[i * 4] = v; d[i * 4 + 1] = v - 4; d[i * 4 + 2] = v - 14; d[i * 4 + 3] = 255; }
  const put = (x: number, y: number, r: number, g: number, b: number) => { const i = (y * w + x) * 4; d[i] = r; d[i + 1] = g; d[i + 2] = b; };
  for (let line = 0; line < 12; line++) for (let x = 20; x < w - 20; x++) if ((x >> 2) % 3) for (let y = 30 + line * 22; y < 30 + line * 22 + 3; y++) put(x, y, 20, 20, 20);
  for (let y = 10; y < 28; y++) for (let x = w - 60; x < w - 30; x++) put(x, y, 200, 30, 30); // dấu đỏ
  return d;
}
describe("CS-22 mrcSplit", () => {
  const W = 300, H = 400, d = page(W, H);
  const r = mrcSplit(d, W, H)!;
  it("tách được: lớp chữ có chữ, không có dấu đỏ; nền thấp độ phân giải", () => {
    expect(r).not.toBeNull();
    expect(r.inkShare).toBeGreaterThan(0.02); expect(r.inkShare).toBeLessThan(0.35);
    expect(r.mask[31 * W + 100]).toBe(0);                       // chữ đen → mặt nạ
    expect(r.mask[15 * W + (W - 45)]).toBe(255);                // dấu đỏ → ở lại lớp nền
    expect(r.bgW).toBe(150); expect(r.bgH).toBe(200);
  });
  it("dung lượng: lớp chữ G4 + nền JPEG nhỏ hơn nhiều so với JPEG trang đầy đủ", () => {
    const g4 = packG4(encodeG4(r.mask, W, H), W, H).length;
    expect(g4 + r.bg.length).toBeLessThan(W * H * 0.12);
  });
  it("trang ảnh (mảng tối > 35 %) → null (dùng đường nén thường)", () => {
    const dark = new Uint8ClampedArray(W * H * 4); for (let i = 0; i < W * H; i++) { const v = (i % 7) * 10; dark[i * 4] = v; dark[i * 4 + 1] = v; dark[i * 4 + 2] = v; dark[i * 4 + 3] = 255; }
    // nền tối đều có Sauvola không tạo chữ; dùng nhiễu mạnh để chắc chắn vượt ngưỡng
    const noisy = new Uint8ClampedArray(W * H * 4); let s = 7; for (let i = 0; i < W * H; i++) { s = (s * 1103515245 + 12345) & 0x7fffffff; const v = (s >> 8) & 255; noisy[i * 4] = noisy[i * 4 + 1] = noisy[i * 4 + 2] = v; noisy[i * 4 + 3] = 255; }
    expect(mrcSplit(noisy, W, H)).toBeNull();
  });
});

describe("CS-22 vùng ảnh", () => {
  it("khối ảnh (nhiều mức xám giữa) ở lại lớp nền, chữ bên cạnh vẫn vào mặt nạ", () => {
    const W = 300, H = 400, d = page(W, H);
    for (let y = 150; y < 300; y++) for (let x = 150; x < 280; x++) { const v = 40 + ((x * 7 + y * 13) % 150); const i = (y * W + x) * 4; d[i] = v; d[i + 1] = v; d[i + 2] = v; }
    const r = mrcSplit(d, W, H)!;
    expect(r).not.toBeNull();
    let ink = 0; for (let y = 160; y < 290; y++) for (let x = 160; x < 270; x++) if (r.mask[y * W + x] === 0) ink++;
    expect(ink).toBe(0);
    expect(r.mask[31 * W + 100]).toBe(0);
  });
});
