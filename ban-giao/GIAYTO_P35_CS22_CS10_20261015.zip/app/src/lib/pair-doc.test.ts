import { describe, expect, it } from "vitest";
import { dataUrlToFile, queueReduce, type QueueItem } from "./pair-doc";

describe("CS-10 hàng đợi ảnh từ điện thoại", () => {
  it("nhận → chờ → thêm → xong, giữ thứ tự tới và đặt tên Ảnh n", () => {
    let q: QueueItem[] = [];
    q = queueReduce(q, { type: "progress", id: "a", pct: 0.4 });
    q = queueReduce(q, { type: "progress", id: "b", pct: 0.1 });
    q = queueReduce(q, { type: "progress", id: "a", pct: 0.2 }); // không lùi
    expect(q.map((x) => [x.name, x.state, x.pct])).toEqual([["Ảnh 1", "receiving", 0.4], ["Ảnh 2", "receiving", 0.1]]);
    q = queueReduce(q, { type: "received", id: "a" });
    q = queueReduce(q, { type: "adding", id: "a" });
    q = queueReduce(q, { type: "done", id: "a" });
    expect(q[0]!.state).toBe("done");
    q = queueReduce(q, { type: "received", id: "c" }); // ảnh nhỏ tới đủ 1 mẩu, chưa có tiến độ
    expect(q[2]).toMatchObject({ name: "Ảnh 3", state: "waiting" });
  });
  it("xoá bỏ mục xong/lỗi, giữ mục đang chạy; id lạ bị bỏ qua", () => {
    let q: QueueItem[] = [];
    for (const id of ["a", "b", "c"]) q = queueReduce(q, { type: "received", id });
    q = queueReduce(q, { type: "done", id: "a" }); q = queueReduce(q, { type: "fail", id: "b" });
    expect(queueReduce(q, { type: "done", id: "zzz" })).toBe(q);
    expect(queueReduce(q, { type: "clear" }).map((x) => x.id)).toEqual(["c"]);
  });
  it("dataUrlToFile: JPEG/PNG → File đúng loại; chuỗi lạ → lỗi", () => {
    const f = dataUrlToFile("data:image/jpeg;base64,/9j/4AAQ", "Ảnh 1");
    expect(f.type).toBe("image/jpeg"); expect(f.name).toBe("Ảnh-1.jpg"); expect(f.size).toBe(6);
    expect(dataUrlToFile("data:image/png;base64,iVBORw0KGgo=", "x").name).toBe("x.png");
    expect(() => dataUrlToFile("data:text/plain;base64,AAAA", "x")).toThrow();
  });
});
