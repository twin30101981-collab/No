// CS-22 (QD-11): PDF "HD nhẹ" kiểu MRC — tách trang thành lớp CHỮ 1-bit độ phân giải cao (CCITT G4, nét như bản in) + lớp NỀN JPEG
// độ phân giải thấp (màu, dấu, ảnh, bóng đổ). Chữ ghi đè lên nền trong PDF bằng mặt nạ khoá màu (xem files.ts "G4M"). Thuần TS, chạy trong Worker.
import { lumOf, sauvola } from "./bilevel";
import { encodeJpeg } from "./jpeg-enc";

export type MrcOpts = { /** hệ số thu nhỏ lớp nền so với lớp chữ (mặc định 2) */ f?: number; /** chất lượng JPEG nền 0–100 (mặc định 55) */ q?: number; gray?: boolean };
export type MrcResult = { mask: Uint8Array; w: number; h: number; bg: Uint8Array; bgW: number; bgH: number; inkShare: number };

/** Điểm màu rực (dấu đỏ, chữ ký xanh) không đưa vào lớp chữ đen — giữ ở lớp nền để không mất màu. */
const SAT_MIN = 70;

/**
 * Tách lớp. Trả null khi trang không hợp MRC (ảnh chụp, mảng tối lớn: > 35 % điểm là "chữ") → nơi gọi dùng đường nén thường.
 * mask: 0 = chữ (đen), 255 = trong suốt.
 */
export function mrcSplit(rgba: Uint8ClampedArray | Uint8Array, w: number, h: number, o: MrcOpts = {}): MrcResult | null {
  const f = Math.max(1, Math.round(o.f ?? 2)), n = w * h;
  const lum = lumOf(rgba, n);
  const mask = sauvola(lum, w, h);
  // điểm màu rực → ở lại lớp nền
  for (let i = 0; i < n; i++) {
    if (mask[i] !== 0) continue;
    const r = rgba[i * 4]!, g = rgba[i * 4 + 1]!, b = rgba[i * 4 + 2]!;
    if (Math.max(r, g, b) - Math.min(r, g, b) > SAT_MIN) mask[i] = 255;
  }
  // vùng ẢNH (nhiều mức xám giữa hoặc nhiều màu): không tách chữ ở đó — mặt nạ 1-bit làm ảnh bị vón đen/loang; ảnh ở lại lớp nền tự nhiên
  const photo = photoBlocks(rgba, lum, w, h);
  if (photo.share > 0.6) return null;
  if (photo.share > 0) for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (photo.at(x, y)) mask[y * w + x] = 255;
  let ink = 0; for (let i = 0; i < n; i++) if (mask[i] === 0) ink++;
  const share = ink / n;
  if (share > 0.35) return null;
  // lớp nền: trung bình khối f×f trên các điểm KHÔNG thuộc chữ (chữ nở 1 điểm để không lọt viền khử răng cưa); khối toàn chữ → trung bình mọi điểm
  const bgW = Math.max(1, Math.ceil(w / f)), bgH = Math.max(1, Math.ceil(h / f));
  const bg = new Uint8ClampedArray(bgW * bgH * 4);
  const near = (x: number, y: number) => {
    for (let dy = -1; dy <= 1; dy++) { const yy = y + dy; if (yy < 0 || yy >= h) continue; for (let dx = -1; dx <= 1; dx++) { const xx = x + dx; if (xx >= 0 && xx < w && mask[yy * w + xx] === 0) return true; } }
    return false;
  };
  for (let by = 0; by < bgH; by++) for (let bx = 0; bx < bgW; bx++) {
    let sr = 0, sg = 0, sb = 0, c = 0, ar = 0, ag = 0, ab = 0, ac = 0;
    for (let y = by * f; y < Math.min(h, by * f + f); y++) for (let x = bx * f; x < Math.min(w, bx * f + f); x++) {
      const i = (y * w + x) * 4; ar += rgba[i]!; ag += rgba[i + 1]!; ab += rgba[i + 2]!; ac++;
      if (mask[y * w + x] === 0 || near(x, y)) continue;
      sr += rgba[i]!; sg += rgba[i + 1]!; sb += rgba[i + 2]!; c++;
    }
    const o4 = (by * bgW + bx) * 4;
    if (c) { bg[o4] = sr / c; bg[o4 + 1] = sg / c; bg[o4 + 2] = sb / c; } else { bg[o4] = ar / ac; bg[o4 + 1] = ag / ac; bg[o4 + 2] = ab / ac; }
    bg[o4 + 3] = 255;
  }
  // khối toàn chữ nằm giữa chữ nền trắng → trung bình mọi điểm kéo nền sẫm (vệt đen mờ) → thay bằng khối lân cận hợp lệ gần nhất theo hàng
  fixSolid(bg, bgW, bgH, mask, w, h, f);
  return { mask, w, h, bg: encodeJpeg(bg, bgW, bgH, o.q ?? 55, !!o.gray), bgW, bgH, inkShare: share };
}

/** Khối nền mà MỌI điểm đều là chữ (nét dày): mượn màu khối kế bên không phải chữ (trái → phải → trên → dưới). */
function fixSolid(bg: Uint8ClampedArray, bw: number, bh: number, mask: Uint8Array, w: number, h: number, f: number) {
  const solid = new Uint8Array(bw * bh);
  for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
    let all = true;
    for (let y = by * f; all && y < Math.min(h, by * f + f); y++) for (let x = bx * f; x < Math.min(w, bx * f + f); x++) if (mask[y * w + x] !== 0) { all = false; break; }
    solid[by * bw + bx] = all ? 1 : 0;
  }
  const copy = (d: number, s: number) => { for (let k = 0; k < 4; k++) bg[d * 4 + k] = bg[s * 4 + k]!; };
  for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
    if (!solid[by * bw + bx]) continue;
    let s = -1;
    for (let r = 1; r < 6 && s < 0; r++) for (const [dx, dy] of [[-r, 0], [r, 0], [0, -r], [0, r]] as const) {
      const x = bx + dx, y = by + dy; if (x >= 0 && x < bw && y >= 0 && y < bh && !solid[y * bw + x]) { s = y * bw + x; break; }
    }
    if (s >= 0) copy(by * bw + bx, s);
  }
}

/** Khối PB×PB là "ảnh" khi > 20 % điểm có mức xám giữa (90–190: chữ/nền chỉ có điểm giữa ở viền khử răng cưa) hoặc > 25 % điểm màu rực hoặc > 55 % điểm tối (vùng tối của ảnh), rồi nở 1 khối. */
const PB = 24;
function photoBlocks(rgba: Uint8ClampedArray | Uint8Array, lum: Uint8Array, w: number, h: number) {
  const bw = Math.ceil(w / PB), bh = Math.ceil(h / PB), flag = new Uint8Array(bw * bh);
  let cnt = 0;
  for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
    let mid = 0, col = 0, dark = 0, t = 0;
    for (let y = by * PB; y < Math.min(h, by * PB + PB); y++) for (let x = bx * PB; x < Math.min(w, bx * PB + PB); x++) {
      const i = y * w + x, v = lum[i]!; t++;
      if (v >= 90 && v <= 190) mid++; else if (v < 90) dark++;
      const r = rgba[i * 4]!, g = rgba[i * 4 + 1]!, b = rgba[i * 4 + 2]!;
      if (Math.max(r, g, b) - Math.min(r, g, b) > 50) col++;
    }
    if (mid / t > 0.2 || col / t > 0.25 || dark / t > 0.55) flag[by * bw + bx] = 1;
  }
  // nở 1 khối: viền ảnh (khối nửa ảnh nửa nền) cũng ở lại lớp nền
  const src = flag.slice(); flag.fill(0);
  for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) if (src[by * bw + bx]) for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const x = bx + dx, y = by + dy; if (x >= 0 && x < bw && y >= 0 && y < bh) flag[y * bw + x] = 1; }
  for (let i = 0; i < flag.length; i++) cnt += flag[i]!;
  return { share: cnt / (bw * bh), at: (x: number, y: number) => flag[((y / PB) | 0) * bw + ((x / PB) | 0)] === 1 };
}
