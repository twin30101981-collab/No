// R2.2: nén trang PDF chạy trong BỂ WORKER CHUNG (worker-pool.ts, kind "compress")
// thay cho pool compress-page.worker riêng — cùng thuật toán compressPage.
// null khi thiếu OffscreenCanvas/Worker → files.ts rơi về luồng chính.
import { runInPool } from "./worker-pool";

/** CS-21: bw = 1-bit Sauvola + CCITT G4; gray = JPEG xám 1 kênh; c444 = JPEG màu 4:4:4; mrc = CS-22 chữ G4 + nền JPEG; ink = chỉ đo tỉ lệ mực màu. */
export type PdfMode = "bw" | "gray" | "c444" | "ink" | "mrc";
export type CompressedPage = { src: string; /** CS-21: gói G4 (fmt "G4") */ data?: Uint8Array; w: number; h: number; fmt: "JPEG" | "PNG" | "G4" | "MRC" /* CS-22: src = nền JPEG, data = chữ G4 */; /** BL-06: ánh xạ ảnh nguồn → ảnh nén (cắt lề ox/oy, thu nhỏ scale) */ ox?: number; oy?: number; scale?: number };
/** Tắt Worker (đo so sánh / rollback): setCompressWorker(false). */
let enabled = true;
export function setCompressWorker(on: boolean) { enabled = on; }

export function compressInWorker(src: string, maxSide: number, q: number, bw: boolean, isJpeg: boolean, crop = true): Promise<CompressedPage> | null {
  if (!enabled) return null;
  const p = runInPool<{ page?: CompressedPage; error?: string }>("compress", { src, maxSide, q, bw, isJpeg, crop });
  if (!p) return null;
  return p.then((r) => {
    if (!r.page) throw new Error(r.error || "compress worker");
    return r.page;
  });
}

/** CS-21: trang PDF theo loại (Worker). null = không có Worker/OffscreenCanvas → nơi gọi dùng compressPage như cũ. */
export function pdfPageInWorker(src: string, mode: Exclude<PdfMode, "ink">, q: number, maxSide: number, scale = 1, adaptive = true): Promise<CompressedPage> | null {
  if (!enabled) return null;
  const p = runInPool<{ page?: CompressedPage; error?: string }>("compress", { src, maxSide, q, bw: false, isJpeg: false, mode, scale, adaptive });
  return p ? p.then((r) => { if (!r.page) throw new Error(r.error || "pdfpage worker"); return r.page; }) : null;
}
/** CS-21: tỉ lệ điểm mực màu của ảnh trang (dấu đỏ, chữ ký xanh). null = không có Worker. */
export function inkShareInWorker(src: string, maxSide = 900): Promise<number> | null {
  if (!enabled) return null;
  const p = runInPool<{ ink?: number; error?: string }>("compress", { src, maxSide, q: 0, bw: false, isJpeg: false, mode: "ink" });
  return p ? p.then((r) => { if (typeof r.ink !== "number") throw new Error(r.error || "ink worker"); return r.ink; }) : null;
}
