// CS-10: bảng "Chụp bằng điện thoại" trong tài liệu đang mở trên PC — QR nối điện thoại + hàng đợi ảnh (hook: lib/use-pair-doc.ts).
import { Check, Laptop, Loader2, RefreshCw, Smartphone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { QUEUE_LABEL } from "@/lib/pair-doc";
import type { PairDocState } from "@/lib/use-pair-doc";

export function PairDocBody({ st, onStop }: { st: PairDocState; onStop: () => void }) {
  const expired = !!st.room && st.left === 0 && !st.phone && st.queue.length === 0;
  const done = st.queue.filter((x) => x.state === "done").length;
  return (
    <div className="space-y-3 text-center">
      {!st.phone && (
        <>
          <p className="text-sm text-muted-foreground">Mở camera trên điện thoại, quét mã này. Ảnh chụp sẽ vào thẳng tài liệu này, cuối tài liệu.</p>
          <div className="mx-auto grid aspect-square w-56 place-items-center rounded-xl border bg-card p-3">
            {expired ? <p className="text-sm text-muted-foreground">Mã đã hết hạn</p> : st.qr ? <img src={st.qr} alt="Mã QR ghép điện thoại" className="w-full" /> : <p className="text-sm text-muted-foreground">Đang tạo mã…</p>}
          </div>
        </>
      )}
      {st.phone ? (
        <div role="status" className="flex items-center justify-center gap-2 rounded-lg bg-primary/10 p-3 font-medium text-primary">
          <Smartphone className="h-5 w-5" aria-hidden /> Đã nối với {st.phone.device}{done ? ` · đã thêm ${done} ảnh` : ""}
        </div>
      ) : (
        <div role="status" className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
          <Laptop className="h-4 w-4" aria-hidden />
          {expired ? "Tạo mã mới để thử lại" : `Đang chờ điện thoại… mã còn ${Math.floor(st.left / 60000)}:${String(Math.floor(st.left / 1000) % 60).padStart(2, "0")}`}
        </div>
      )}
      {st.queue.length > 0 && (
        <ul className="space-y-1 text-left text-sm" aria-live="polite" data-testid="pair-queue">
          {st.queue.map((x) => (
            <li key={x.id} className="flex items-center gap-2">
              {x.state === "done" ? <Check className="h-4 w-4 text-primary" aria-hidden /> : x.state === "fail" ? <span aria-hidden>!</span> : <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
              {x.name}: {x.state === "receiving" ? `${QUEUE_LABEL.receiving} ${Math.round(x.pct * 100)}%` : QUEUE_LABEL[x.state]}
            </li>
          ))}
        </ul>
      )}
      <div className="flex flex-wrap justify-center gap-2">
        <Button size="sm" variant="glass" onClick={st.fresh}><RefreshCw className="mr-1 h-4 w-4" aria-hidden />Tạo mã mới</Button>
        {st.queue.some((x) => x.state === "done" || x.state === "fail") && <Button size="sm" variant="glass" onClick={st.clear}>Xoá danh sách đã xong</Button>}
        <Button size="sm" variant="outline" onClick={onStop}>Ngắt kết nối</Button>
      </div>
      <p className="text-xs text-muted-foreground">Không cần đăng nhập. Phòng chỉ tồn tại khi tài liệu này đang mở; ảnh không lưu trên máy chủ. Đóng bảng này, điện thoại vẫn gửi được.</p>
    </div>
  );
}
