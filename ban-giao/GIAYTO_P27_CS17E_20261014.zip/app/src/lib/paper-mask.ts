/**
 * B4 — Mặt nạ giấy + xoá nêm góc (O6).
 *
 * Sau khi nắn, khung tinh chỉnh lệch vài px hoặc giấy cong để lại "nêm" nền tối ở góc/mép.
 * - paperColor: ước lượng màu giấy từ vành trong (4–12 % mỗi cạnh), chỉ lấy điểm sáng.
 * - paperMaskFill: dựng mặt nạ "ngoài giấy" = vùng tối hơn giấy rõ rệt, nối liền với viền ảnh,
 *   nằm trong dải mép (tối đa 6 %), nở thêm vài px để nuốt viền chuyển tiếp, rồi tô màu giấy (mép mềm).
 * - darkBorderRegions: đo các vùng tối dính viền còn sót (mm theo khổ A4) — dùng cho nghiệm thu "0 vùng tối > 3 mm".
 */
type Px = Uint8ClampedArray;

const lumOf = (d: Px, i: number) => d[i * 4] * 0.3 + d[i * 4 + 1] * 0.59 + d[i * 4 + 2] * 0.11;

/** CS-17e: gọi f(o, a, b) cho từng đoạn hàng [o+a, o+b) của dải mép rộng B (cả ảnh khi 2B ≥ W hoặc H). */
function forBand(W: number, H: number, B: number, f: (o: number, a: number, b: number) => void) {
  const full = !(B * 2 < W && B * 2 < H);
  for (let y = 0; y < H; y++) {
    const o = y * W;
    if (full || y < B || y >= H - B) f(o, 0, W);
    else { f(o, 0, B); f(o, W - B, W); }
  }
}
/** CS-17e: độ sáng Float32 (như mảng L cũ) chỉ trong dải mép B; ngoài dải để 0 — nơi gọi không đọc ngoài dải. */
function lumBand(d: Px, W: number, H: number, B: number) {
  const L = new Float32Array(W * H);
  forBand(W, H, B, (o, a, b) => { for (let i = o + a; i < o + b; i++) L[i] = lumOf(d, i); });
  return L;
}

/** Màu giấy (RGB + độ sáng) từ vành trong, bỏ điểm tối (chữ, bóng). */
export function paperColor(d: Px, W: number, H: number) {
  const hist = new Uint32Array(256); const pts: number[] = [];
  const x0 = Math.floor(W * 0.04), x1 = Math.ceil(W * 0.12), y0 = Math.floor(H * 0.04), y1 = Math.ceil(H * 0.12);
  const step = Math.max(1, Math.round(Math.min(W, H) / 400));
  const take = (x: number, y: number) => { const i = y * W + x; hist[Math.round(lumOf(d, i))]++; pts.push(i); };
  for (let y = y0; y < y1; y += step) for (let x = x0; x < W - x0; x += step) { take(x, y); take(x, H - 1 - y); }
  for (let x = x0; x < x1; x += step) for (let y = y1; y < H - y1; y += step) { take(x, y); take(W - 1 - x, y); }
  const n = pts.length; if (!n) return { r: 255, g: 255, b: 255, L: 255 };
  // phân vị 75 % = mức giấy; trung bình màu của các điểm quanh mức đó
  let acc = 0, P = 255; for (let v = 0; v < 256; v++) { acc += hist[v]; if (acc >= n * 0.75) { P = v; break; } }
  let r = 0, g = 0, b = 0, c = 0;
  for (const i of pts) { const l = lumOf(d, i); if (l >= P - 12 && l <= P + 20) { r += d[i * 4]; g += d[i * 4 + 1]; b += d[i * 4 + 2]; c++; } }
  return c ? { r: r / c, g: g / c, b: b / c, L: P } : { r: P, g: P, b: P, L: P };
}

/** Ngưỡng "tối hơn giấy rõ rệt": chịu được giấy tương phản thấp (nền 160 / giấy 215). */
export const darkThreshold = (P: number) => Math.min(P * 0.85, P - 22);

/** Mặt nạ vùng ngoài giấy (1 = nền) — chỉ trong dải mép, nối với viền ảnh. */
export function paperMask(d: Px, W: number, H: number, band = 0.06) {
  const { L: P } = paperColor(d, W, H); const mask = new Uint8Array(W * H);
  if (P < 90) return { mask, count: 0, P, bw: 0 };
  const dark = darkThreshold(P), bw = Math.max(4, Math.round(Math.min(W, H) * band));
  const inBand = (x: number, y: number) => x < bw || y < bw || x >= W - bw || y >= H - bw;
  const stack: number[] = []; let count = 0;
  const push = (x: number, y: number) => { const i = y * W + x; if (!mask[i] && lumOf(d, i) < dark) { mask[i] = 1; count++; stack.push(i); } };
  for (let x = 0; x < W; x++) { push(x, 0); push(x, H - 1); }
  for (let y = 0; y < H; y++) { push(0, y); push(W - 1, y); }
  while (stack.length) {
    const i = stack.pop()!; const x = i % W, y = (i / W) | 0;
    if (x + 1 < W && inBand(x + 1, y)) push(x + 1, y);
    if (x > 0 && inBand(x - 1, y)) push(x - 1, y);
    if (y + 1 < H && inBand(x, y + 1)) push(x, y + 1);
    if (y > 0 && inBand(x, y - 1)) push(x, y - 1);
  }
  return { mask, count, P, bw };
}

/** Nở mặt nạ r px (hình vuông, tách 2 lượt). V5b: chỉ quét dải viền B px khi biết mặt nạ = 0 ngoài dải bw (B ≥ bw + r). */
function dilate(m: Uint8Array, W: number, H: number, r: number, B = Infinity) {
  const t = new Uint8Array(W * H), o = new Uint8Array(W * H);
  const row = (y: number, a: number, b: number) => { let last = -1e9; for (let x = a; x < b; x++) { if (m[y * W + x]) last = x; if (x - last <= r) t[y * W + x] = 1; } last = 1e9; for (let x = b - 1; x >= a; x--) { if (m[y * W + x]) last = x; if (last - x <= r) t[y * W + x] = 1; } };
  const full = !(B * 2 < W && B * 2 < H);
  for (let y = 0; y < H; y++) { if (full || y < B || y >= H - B) row(y, 0, W); else { row(y, 0, B); row(y, W - B, W); } }
  if (full) {
    // CS-17a: nở dọc cả ảnh quét theo hàng (mảng "điểm gần nhất" mỗi cột) thay vì đi dọc từng cột — cùng tập điểm.
    const last = new Float64Array(W);
    last.fill(-1e9);
    for (let y = 0; y < H; y++) { const o0 = y * W; for (let x = 0; x < W; x++) { if (t[o0 + x]) last[x] = y; if (y - last[x] <= r) o[o0 + x] = 1; } }
    last.fill(1e9);
    for (let y = H - 1; y >= 0; y--) { const o0 = y * W; for (let x = 0; x < W; x++) { if (t[o0 + x]) last[x] = y; if (last[x] - y <= r) o[o0 + x] = 1; } }
    return o;
  }
  // CS-17e: lượt dọc dải mép quét theo hàng (mảng "điểm gần nhất" mỗi cột) — cùng tập điểm như col(): cột giữa chỉ có
  // hai đoạn [0, B) và [H − B, H), mỗi đoạn bắt đầu lại "last".
  const last = new Float64Array(W);
  last.fill(-1e9);
  for (let y = 0; y < H; y++) {
    if (y === H - B) last.fill(-1e9, B, W - B);
    const o0 = y * W, mid = y >= B && y < H - B;
    for (let x = 0; x < W; x++) {
      if (mid && x === B) x = W - B;
      if (t[o0 + x]) last[x] = y; if (y - last[x] <= r) o[o0 + x] = 1;
    }
  }
  last.fill(1e9);
  for (let y = H - 1; y >= 0; y--) {
    if (y === B - 1) last.fill(1e9, B, W - B);
    const o0 = y * W, mid = y >= B && y < H - B;
    for (let x = 0; x < W; x++) {
      if (mid && x === B) x = W - B;
      if (t[o0 + x]) last[x] = y; if (last[x] - y <= r) o[o0 + x] = 1;
    }
  }
  return o;
}

/** Tô vùng ngoài giấy bằng màu giấy ước lượng; viền nở thêm `grow` px pha mềm để không lộ mép. */
export function paperMaskFill(d: Px, W: number, H: number, grow = 3) {
  const { mask, count, bw } = paperMask(d, W, H); if (!count) return d;
  const col = paperColor(d, W, H);
  const g1 = Math.max(1, grow - 1), B = bw + g1 + 2; // V5b: mọi điểm mặt nạ nằm trong dải bw
  const core = dilate(mask, W, H, g1, B), soft = dilate(core, W, H, 1, B);
  const px = (i: number) => {
    if (!soft[i]) return;
    const a = core[i] ? 1 : 0.5, j = i * 4;
    // chỉ làm sáng lên (không xoá chữ sáng hơn giấy — hiếm), pha theo a
    if (lumOf(d, i) >= col.L && !core[i]) return;
    d[j] = d[j] * (1 - a) + col.r * a; d[j + 1] = d[j + 1] * (1 - a) + col.g * a; d[j + 2] = d[j + 2] * (1 - a) + col.b * a;
  };
  const full = !(B * 2 < W && B * 2 < H);
  for (let y = 0; y < H; y++) {
    const o = y * W;
    if (full || y < B || y >= H - B) { for (let x = 0; x < W; x++) px(o + x); }
    else { for (let x = 0; x < B; x++) px(o + x); for (let x = W - B; x < W; x++) px(o + x); }
  }
  return d;
}

export type DarkRegion = { px: number; mm: number; x: number; y: number };
/** Các vùng tối dính viền (trong dải 6 %); kích thước = cạnh lớn nhất của hộp bao, đổi ra mm theo cạnh ngắn = 210 mm. */
export function darkBorderRegions(d: Px, W: number, H: number, shortMm = 210): DarkRegion[] {
  const { L: P } = paperColor(d, W, H); const dark = darkThreshold(P);
  const bw = Math.max(4, Math.round(Math.min(W, H) * 0.06)); const mmPx = shortMm / Math.min(W, H);
  const seen = new Uint8Array(W * H); const out: DarkRegion[] = [];
  const inBand = (x: number, y: number) => x < bw || y < bw || x >= W - bw || y >= H - bw;
  const border: [number, number][] = [];
  for (let x = 0; x < W; x++) border.push([x, 0], [x, H - 1]);
  for (let y = 0; y < H; y++) border.push([0, y], [W - 1, y]);
  for (const [sx, sy] of border) {
    const s = sy * W + sx; if (seen[s] || lumOf(d, s) >= dark) continue;
    let x0 = sx, x1 = sx, y0 = sy, y1 = sy; const st = [s]; seen[s] = 1;
    while (st.length) {
      const i = st.pop()!; const x = i % W, y = (i / W) | 0;
      if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
      for (const [nx, ny] of [[x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]]) {
        if (nx < 0 || ny < 0 || nx >= W || ny >= H || !inBand(nx, ny)) continue;
        const k = ny * W + nx; if (!seen[k] && lumOf(d, k) < dark) { seen[k] = 1; st.push(k); }
      }
    }
    const px = Math.max(x1 - x0 + 1, y1 - y0 + 1); out.push({ px, mm: px * mmPx, x: x0, y: y0 });
  }
  return out.sort((a, b) => b.px - a.px);
}

/**
 * S10 – Q1: bóng xám mềm dính mép/góc (tối hơn giấy nhẹ, không đủ "tối rõ rệt" cho paperMask).
 * Loang từ viền ảnh qua điểm "phẳng" (không có nét chữ) tối hơn giấy ≥ 8, trong dải `band` (15 %).
 * Chữ có độ tương phản cục bộ cao nên chặn loang → không xoá chữ. Tô dần về màu giấy theo độ tối.
 */
export function edgeShadowLift(d: Px, W: number, H: number, band = 0.15) {
  const col = paperColor(d, W, H); const P = col.L; if (P < 90) return d;
  const mild = P - 8, bw = Math.max(4, Math.round(Math.min(W, H) * band)), s = 2;
  // CS-17e: mặt nạ chỉ loang trong dải bw → mọi điểm đọc/ghi nằm trong dải bw + s + 2 (nở 2) — chỉ tính trong dải đó.
  const B = bw + s + 4, L = lumBand(d, W, H, B);
  const inBand = (x: number, y: number) => x < bw || y < bw || x >= W - bw || y >= H - bw;
  const smooth = (x: number, y: number) => {
    const v = L[y * W + x];
    return (x < s || Math.abs(L[y * W + x - s] - v) < 14) && (x >= W - s || Math.abs(L[y * W + x + s] - v) < 14)
      && (y < s || Math.abs(L[(y - s) * W + x] - v) < 14) && (y >= H - s || Math.abs(L[(y + s) * W + x] - v) < 14);
  };
  const m = new Uint8Array(W * H); const st: number[] = [];
  const push = (x: number, y: number) => { const i = y * W + x; if (!m[i] && L[i] < mild && smooth(x, y)) { m[i] = 1; st.push(i); } };
  for (let x = 0; x < W; x++) { push(x, 0); push(x, H - 1); }
  for (let y = 0; y < H; y++) { push(0, y); push(W - 1, y); }
  while (st.length) {
    const i = st.pop()!; const x = i % W, y = (i / W) | 0;
    if (x + 1 < W && inBand(x + 1, y)) push(x + 1, y);
    if (x > 0 && inBand(x - 1, y)) push(x - 1, y);
    if (y + 1 < H && inBand(x, y + 1)) push(x, y + 1);
    if (y > 0 && inBand(x, y - 1)) push(x, y - 1);
  }
  const g = dilate(m, W, H, 2, B);
  forBand(W, H, B, (o, a, b) => {
    for (let i = o + a; i < o + b; i++) {
      if (!g[i]) continue; const j = i * 4;
      // điểm nở thêm mà tối đậm (chữ) thì giữ nguyên
      if (!m[i] && L[i] < P * 0.6) continue;
      d[j] = col.r; d[j + 1] = col.g; d[j + 2] = col.b;
    }
  });
  return d;
}

/**
 * S10 – Q2: rác điểm ảnh ở mép (chấm đen, vệt nhỏ) – thành phần tối nhỏ nằm trọn trong dải mép `band` (2 %).
 * Chữ thật hiếm khi nằm trọn trong 2 % sát mép; thành phần lớn hơn `maxFrac` cạnh ngắn được giữ.
 */
export function edgeSpeckClean(d: Px, W: number, H: number, band = 0.02, maxFrac = 0.03) {
  const col = paperColor(d, W, H); const dark = darkThreshold(col.L);
  const bw = Math.max(3, Math.round(Math.min(W, H) * band)), maxPx = Math.max(4, Math.round(Math.min(W, H) * maxFrac));
  const inBand = (x: number, y: number) => x < bw || y < bw || x >= W - bw || y >= H - bw;
  const seen = new Uint8Array(W * H);
  const scan = (sx: number, sy: number) => {
    const s = sy * W + sx; if (seen[s] || lumOf(d, s) >= dark) return;
    const comp = [s]; const st = [s]; seen[s] = 1; let inside = true, x0 = sx, x1 = sx, y0 = sy, y1 = sy;
    while (st.length) {
      const i = st.pop()!; const x = i % W, y = (i / W) | 0;
      if (!inBand(x, y)) inside = false;
      if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
      for (const [nx, ny] of [[x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]]) {
        if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
        const k = ny * W + nx; if (!seen[k] && lumOf(d, k) < dark) { seen[k] = 1; st.push(k); comp.push(k); }
      }
    }
    if (inside && Math.max(x1 - x0, y1 - y0) + 1 <= maxPx) for (const i of comp) { d[i * 4] = col.r; d[i * 4 + 1] = col.g; d[i * 4 + 2] = col.b; }
  };
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (inBand(x, y)) scan(x, y);
  return d;
}

/**
 * S10f – Q2 sót: vệt mảnh dài song song mép (mép tờ giấy bên dưới) nằm trong dải `band` (8 %).
 * Thành phần tối có bề ngang ≤ 1,2 % cạnh ngắn, dài ≥ 6 % cạnh ngắn và ≥ 8× bề ngang → tô màu giấy.
 * Nét chữ ngắn (l, I) không đủ dài nên giữ nguyên.
 */
export function edgeLineClean(d: Px, W: number, H: number, band = 0.08) {
  const col = paperColor(d, W, H); const dark = darkThreshold(col.L) + 25; const S = Math.min(W, H);
  const bw = Math.round(S * band), maxW = Math.max(3, Math.round(S * 0.012)), minL = Math.round(S * 0.06);
  // CS-17e: seen 0 = chưa, 1 = đã loang, 2 = đã biết sáng (nhớ isDark; điểm bị tô luôn đã loang nên không đọc lại).
  const seen = new Uint8Array(W * H);
  const isDark = (k: number) => { if (lumOf(d, k) < dark) return true; seen[k] = 2; return false; };
  const comp: number[] = [], st: number[] = [];
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    if (!(x < bw || y < bw || x >= W - bw || y >= H - bw)) { x = W - bw - 1; continue; } // CS-17a: nhảy qua giữa hàng
    const s = y * W + x; if (seen[s] || !isDark(s)) continue;
    comp.length = 0; st.length = 0; comp.push(s); st.push(s); seen[s] = 1; let x0 = x, x1 = x, y0 = y, y1 = y;
    while (st.length && comp.length < 200000) {
      const i = st.pop()!; const py = (i / W) | 0, px = i - py * W;
      if (px < x0) x0 = px; if (px > x1) x1 = px; if (py < y0) y0 = py; if (py > y1) y1 = py;
      // CS-17a: 4 láng giềng viết thẳng, cùng thứ tự (phải, trái, dưới, trên) — không cấp phát mảng mỗi điểm.
      if (px + 1 < W && !seen[i + 1] && isDark(i + 1)) { seen[i + 1] = 1; st.push(i + 1); comp.push(i + 1); }
      if (px > 0 && !seen[i - 1] && isDark(i - 1)) { seen[i - 1] = 1; st.push(i - 1); comp.push(i - 1); }
      if (py + 1 < H && !seen[i + W] && isDark(i + W)) { seen[i + W] = 1; st.push(i + W); comp.push(i + W); }
      if (py > 0 && !seen[i - W] && isDark(i - W)) { seen[i - W] = 1; st.push(i - W); comp.push(i - W); }
    }
    const bwX = x1 - x0 + 1, bhY = y1 - y0 + 1;
    const vert = bwX <= maxW * 2 && bhY >= minL && bhY >= 8 * bwX && (x1 < bw || x0 >= W - bw);
    const horz = bhY <= maxW * 2 && bwX >= minL && bwX >= 8 * bhY && (y1 < bw || y0 >= H - bw);
    // thickness check: average run per row/col
    const thin = vert ? comp.length / bhY <= maxW : horz ? comp.length / bwX <= maxW : false;
    if ((vert || horz) && thin) for (const i of comp) { d[i * 4] = col.r; d[i * 4 + 1] = col.g; d[i * 4 + 2] = col.b; }
  }
  return d;
}

/**
 * S10b – Q1: bóng xám không chạm mép ảnh. Làm phẳng nền theo nền cục bộ:
 * nền = độ sáng lớn nhất trong ô `cell` px (bỏ chữ), làm mượt 3×3; chỗ nền tối hơn giấy ≥ 6
 * và nằm trong dải mép `band` (25 %) thì nhân điểm ảnh theo tỉ số giấy/nền (giữ chữ, chỉ bỏ bóng).
 */
export function edgeShadowFlatten(d: Px, W: number, H: number, band = 0.25) {
  const col = paperColor(d, W, H); const P = col.L; if (P < 90) return d;
  const cell = Math.max(8, Math.round(Math.min(W, H) / 40));
  const cw = Math.ceil(W / cell), ch = Math.ceil(H / cell); const bg = new Float32Array(cw * ch);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const k = ((y / cell) | 0) * cw + ((x / cell) | 0); const l = lumOf(d, y * W + x); if (l > bg[k]) bg[k] = l; }
  const sm = new Float32Array(cw * ch);
  for (let cy = 0; cy < ch; cy++) for (let cx = 0; cx < cw; cx++) {
    let s = 0, n = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const X = cx + dx, Y = cy + dy; if (X >= 0 && Y >= 0 && X < cw && Y < ch) { s += bg[Y * cw + X]; n++; } }
    sm[cy * cw + cx] = s / n;
  }
  const bw = Math.min(W, H) * band;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const e = Math.min(x, y, W - 1 - x, H - 1 - y); if (e > bw) continue;
    // nội suy song tuyến nền
    const fx = Math.min(cw - 1, Math.max(0, x / cell - 0.5)), fy = Math.min(ch - 1, Math.max(0, y / cell - 0.5));
    const x0 = fx | 0, y0 = fy | 0, x1 = Math.min(cw - 1, x0 + 1), y1 = Math.min(ch - 1, y0 + 1), ax = fx - x0, ay = fy - y0;
    const b = (sm[y0 * cw + x0] * (1 - ax) + sm[y0 * cw + x1] * ax) * (1 - ay) + (sm[y1 * cw + x0] * (1 - ax) + sm[y1 * cw + x1] * ax) * ay;
    if (b >= P - 6 || b < 40) continue;
    const g = Math.min(3, P / b), j = (y * W + x) * 4;
    d[j] = Math.min(255, d[j] * g); d[j + 1] = Math.min(255, d[j + 1] * g); d[j + 2] = Math.min(255, d[j + 2] * g);
  }
  return d;
}

/**
 * S10b – Q1 (bản dùng): bóng xám mềm trong dải mép, không cần chạm viền ảnh.
 * Điểm "phẳng" (lệch < 14 so với láng giềng cách 2 px) có độ sáng trong (0,55·P; P−6) → tô màu giấy.
 * Nét chữ có cạnh gắt nên không phẳng; lõi nét đậm < 0,55·P nên được giữ.
 */
export function edgeShadowSmooth(d: Px, W: number, H: number, band = 0.25) {
  const col = paperColor(d, W, H); const P = col.L; if (P < 90) return d;
  const lo = P * 0.55, hi = P - 6, bw = Math.min(W, H) * band, s = 2;
  // CS-17e: điểm mặt nạ có min(x, y, …) ≤ bw → nằm trong dải ⌊bw⌋ + 1; đọc lệch s, nở 2 → chỉ tính trong dải B.
  const B = Math.floor(bw) + 1 + s + 4, L = lumBand(d, W, H, B);
  const m = new Uint8Array(W * H);
  forBand(W, H, B, (o, a, b) => {
    const y = o / W; if (y < s || y >= H - s) return;
    for (let x = a < s ? s : a, xe = b > W - s ? W - s : b; x < xe; x++) {
      if (Math.min(x, y, W - 1 - x, H - 1 - y) > bw) continue;
      const i = o + x, v = L[i]; if (v <= lo || v >= hi) continue;
      if (Math.abs(L[i - s] - v) < 14 && Math.abs(L[i + s] - v) < 14 && Math.abs(L[i - s * W] - v) < 14 && Math.abs(L[i + s * W] - v) < 14) m[i] = 1;
    }
  });
  const g = dilate(m, W, H, 2, B);
  forBand(W, H, B, (o, a, b) => {
    for (let i = o + a; i < o + b; i++) {
      if (!g[i] || L[i] < lo) continue; const j = i * 4;
      d[j] = col.r; d[j + 1] = col.g; d[j + 2] = col.b;
    }
  });
  return d;
}

/**
 * S10g/S10h – vệt đứt nét sát mép (mép tờ bên dưới): nhiều mảnh mảnh, dài theo một hướng, nối thành đường gần thẳng
 * (cho phép xiên ≤ 0,2 px/px) trong dải mép `band` (12 %). Điểm "tối" theo tương phản cục bộ: tối hơn nền ô ≥ 14
 * (bắt cả vệt xám nhạt). Mảnh phải cô lập (không có điểm tối bên cạnh như chữ cùng dòng). Tổng dài ≥ 6 % cạnh ngắn → xoá.
 */
/**
 * V5d: điểm tối theo tương phản cục bộ (nền = độ sáng lớn nhất trong ô S/40, kẹp ≤ màu giấy; tối hơn nền ≥ 14).
 * Dùng chung cho edgeDashClean/edgeStrokeClean; chỉ số ô tính theo hàng + bảng cột, không chia cho từng điểm.
 */
/**
 * CS-17e: tính lười — chỉ ô nền / điểm được hỏi tới (dải mép + nơi loang tới), kết quả y hệt bản tính cả ảnh cũ
 * (L Float32 = Math.fround(lumOf), nền ô = max L khởi 0). Điều kiện: d không đổi giữa lần hỏi đầu và lần cuối.
 */
function lazyLocalDark(d: Px, W: number, H: number, S: number, paperL: number, band: number) {
  const cell = Math.max(8, Math.round(S / 40)), cw = Math.ceil(W / cell), bg = new Float32Array(cw * Math.ceil(H / cell)).fill(-1);
  const dk = new Uint8Array(W * H); // 0 = chưa tính, 1 = tối, 2 = không
  // Tính sẵn (vòng theo hàng như localDark) cho các ô phủ dải mép `band`; ngoài đó tính khi được hỏi.
  {
    const xa = Math.ceil(band / cell) * cell, xb = Math.floor((W - band) / cell) * cell, ya = Math.ceil(band / cell) * cell, yb = Math.floor((H - band) / cell) * cell;
    const full = xa >= xb || ya >= yb, cx = new Int32Array(W); for (let x = 0; x < W; x++) cx[x] = (x / cell) | 0;
    const seg = (f: (o: number, r: number, a: number, b: number) => void) => {
      for (let y = 0; y < H; y++) { const o = y * W, r = ((y / cell) | 0) * cw; if (full || y < ya || y >= yb) f(o, r, 0, W); else { f(o, r, 0, xa); f(o, r, xb, W); } }
    };
    seg((o, r, a, b) => { for (let x = a; x < b; x++) { const k = r + cx[x], v = Math.fround(lumOf(d, o + x)); if (bg[k] < 0 || v > bg[k]) bg[k] = bg[k] < 0 ? (v > 0 ? v : 0) : v; } });
    seg((o, r, a, b) => { for (let x = a; x < b; x++) dk[o + x] = Math.min(paperL, bg[r + cx[x]]) - Math.fround(lumOf(d, o + x)) >= 14 ? 1 : 2; });
  }
  const cellBg = (k: number) => {
    const cy = (k / cw) | 0, cx = k - cy * cw, x0 = cx * cell, y0 = cy * cell, x1 = Math.min(W, x0 + cell), y1 = Math.min(H, y0 + cell);
    let v = 0;
    for (let y = y0; y < y1; y++) for (let i = y * W + x0, e = y * W + x1; i < e; i++) { const l = Math.fround(lumOf(d, i)); if (l > v) v = l; }
    return (bg[k] = v);
  };
  const get = (i: number) => {
    let v = dk[i];
    if (!v) {
      const y = (i / W) | 0, k = ((y / cell) | 0) * cw + (((i - y * W) / cell) | 0);
      let b = bg[k]; if (b < 0) b = cellBg(k);
      v = dk[i] = Math.min(paperL, b) - Math.fround(lumOf(d, i)) >= 14 ? 1 : 2;
    }
    return v === 1;
  };
  return { get, raw: dk };
}

export function edgeDashClean(d: Px, W: number, H: number, band = 0.12) {
  const col = paperColor(d, W, H); const S = Math.min(W, H); if (col.L < 90) return d;
  const bw = Math.round(S * band), maxW = Math.max(3, Math.round(S * 0.008)), minL = Math.round(S * 0.06), maxGap = Math.round(S * 0.05);
  const { get: dk, raw } = lazyLocalDark(d, W, H, S, col.L, bw + maxW * 3 + 2); // CS-17e: d chỉ bị tô sau khi dò xong; dải tính sẵn phủ cả ô darkIn
  const seen = new Uint8Array(W * H);
  type C = { px: number[]; c: number; a0: number; a1: number; v: boolean };
  const cs: C[] = [];
  const darkIn = (xa: number, xb: number, ya: number, yb: number) => { let n = 0; for (let y = Math.max(0, ya); y <= Math.min(H - 1, yb); y++) for (let x = Math.max(0, xa), xe = Math.min(W - 1, xb), o = y * W; x <= xe; x++) { const v = raw[o + x]; n += v === 1 ? 1 : v === 0 && dk(o + x) ? 1 : 0; } return n; };
  forBand(W, H, bw, (o, a, b) => { for (let s = o + a; s < o + b; s++) {
    if (seen[s] || !dk(s)) continue; const x = s - o, y = o / W;
    const comp = [s], st = [s]; seen[s] = 1; let x0 = x, x1 = x, y0 = y, y1 = y;
    while (st.length && comp.length < 5000) {
      const i = st.pop()!; const px = i % W, py = (i / W) | 0;
      if (px < x0) x0 = px; if (px > x1) x1 = px; if (py < y0) y0 = py; if (py > y1) y1 = py;
      // V5d: 4 láng giềng viết thẳng (không cấp phát mảng cho từng điểm)
      if (px + 1 < W) { const k = i + 1; if (!seen[k] && dk(k)) { seen[k] = 1; st.push(k); comp.push(k); } }
      if (px > 0) { const k = i - 1; if (!seen[k] && dk(k)) { seen[k] = 1; st.push(k); comp.push(k); } }
      if (py + 1 < H) { const k = i + W; if (!seen[k] && dk(k)) { seen[k] = 1; st.push(k); comp.push(k); } }
      if (py > 0) { const k = i - W; if (!seen[k] && dk(k)) { seen[k] = 1; st.push(k); comp.push(k); } }
    }
    const w = x1 - x0 + 1, h = y1 - y0 + 1, r = maxW * 3;
    if (h >= 4 * w && h >= 6 && comp.length / h <= maxW && (x1 < bw || x0 >= W - bw)) {
      if (darkIn(x0 - r, x0 - 2, y0, y1) + darkIn(x1 + 2, x1 + r, y0, y1) <= h * 0.3) cs.push({ px: comp, c: (x0 + x1) / 2, a0: y0, a1: y1, v: true });
    } else if (w >= 4 * h && w >= 6 && comp.length / w <= maxW && (y1 < bw || y0 >= H - bw)) {
      if (darkIn(x0, x1, y0 - r, y0 - 2) + darkIn(x0, x1, y1 + 2, y1 + r) <= w * 0.3) cs.push({ px: comp, c: (y0 + y1) / 2, a0: x0, a1: x1, v: false });
    }
  } });
  for (const v of [true, false]) {
    const g = cs.filter((c) => c.v === v).sort((a, b) => a.a0 - b.a0); const used = new Uint8Array(g.length);
    for (let i = 0; i < g.length; i++) {
      if (used[i]) continue; const chain = [i]; used[i] = 1; let last = g[i], tot = last.a1 - last.a0 + 1;
      for (let j = i + 1; j < g.length; j++) {
        if (used[j]) continue; const gap = g[j].a0 - last.a1; if (gap > maxGap) break;
        if (Math.abs(g[j].c - last.c) <= maxW * 1.5 + Math.max(0, gap + (g[j].a1 - g[j].a0)) * 0.2) { chain.push(j); used[j] = 1; tot += g[j].a1 - g[j].a0 + 1; last = g[j]; }
      }
      if (tot >= minL && chain.length > 1) for (const k of chain) for (const p of g[k].px) { d[p * 4] = col.r; d[p * 4 + 1] = col.g; d[p * 4 + 2] = col.b; }
    }
  }
  return d;
}

/**
 * S10i – vệt đứt nét/xiên bất kỳ góc (mép tờ dưới, vết bút) trong dải mép `band` (15 %).
 * Điểm tối theo tương phản cục bộ (≥ 14). Mảnh nhỏ (≤ 4× bề dày tối đa) nằm thưa (ít điểm tối lạ quanh mảnh) được
 * coi là ứng viên; tìm đường thẳng đi qua ≥ 5 mảnh (≥ 6 mảnh gạch thuôn, phủ ≥ 40 %, lệch ≤ bề dày tối đa, khe ≤ 5 %, dài ≥ 8 % cạnh ngắn; hai bên trống ≥ 98 %),
 * không gần nằm ngang (≥ 35°, tránh dòng chữ nghiêng). Mỗi mảnh trên đường phải trống hai bên (không có chữ) → tô màu giấy.
 */
export function edgeStrokeClean(d: Px, W: number, H: number, band = 0.15) {
  const col = paperColor(d, W, H); const S = Math.min(W, H); if (col.L < 90) return d;
  const bw = Math.round(S * band), maxW = Math.max(3, Math.round(S * 0.008)), minL = S * 0.08, maxGap = S * 0.05;
  const dk = lazyLocalDark(d, W, H, S, col.L, bw + maxW * 4).get; // CS-17e: tô dồn về cuối → d không đổi khi còn hỏi dk
  const lab = new Int32Array(W * H).fill(-1);
  type F = { px: number[]; id: number; x: number; y: number; x0: number; x1: number; y0: number; y1: number };
  const fs: F[] = []; let nid = 0;
  const maxS = maxW * 4;
  forBand(W, H, bw, (o, a, b) => { for (let s = o + a; s < o + b; s++) {
    if (lab[s] !== -1 || !dk(s)) continue; const x = s - o, y = o / W;
    const id = nid++; const comp = [s], st = [s]; lab[s] = id; let x0 = x, x1 = x, y0 = y, y1 = y;
    while (st.length && comp.length < 4000) {
      const i = st.pop()!; const py = (i / W) | 0, px = i - py * W;
      if (px < x0) x0 = px; if (px > x1) x1 = px; if (py < y0) y0 = py; if (py > y1) y1 = py;
      if (px > 0 && py > 0 && px < W - 1 && py < H - 1) { // CS-17e: điểm trong — 8 láng giềng cùng thứ tự, bỏ kiểm biên (chính nó đã đánh dấu)
        let k = i - W - 1; if (lab[k] === -1 && dk(k)) { lab[k] = id; st.push(k); comp.push(k); }
        k = i - W; if (lab[k] === -1 && dk(k)) { lab[k] = id; st.push(k); comp.push(k); }
        k = i - W + 1; if (lab[k] === -1 && dk(k)) { lab[k] = id; st.push(k); comp.push(k); }
        k = i - 1; if (lab[k] === -1 && dk(k)) { lab[k] = id; st.push(k); comp.push(k); }
        k = i + 1; if (lab[k] === -1 && dk(k)) { lab[k] = id; st.push(k); comp.push(k); }
        k = i + W - 1; if (lab[k] === -1 && dk(k)) { lab[k] = id; st.push(k); comp.push(k); }
        k = i + W; if (lab[k] === -1 && dk(k)) { lab[k] = id; st.push(k); comp.push(k); }
        k = i + W + 1; if (lab[k] === -1 && dk(k)) { lab[k] = id; st.push(k); comp.push(k); }
      } else
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        const nx = px + dx, ny = py + dy; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
        const k = ny * W + nx; if (lab[k] === -1 && dk(k)) { lab[k] = id; st.push(k); comp.push(k); }
      }
    }
    const n = comp.length;
    if (n < 3 || x1 - x0 + 1 > maxS || y1 - y0 + 1 > maxS) continue;
    // thưa: điểm tối lạ trong khung nở r
    const r = maxW * 2; let foreign = 0;
    for (let yy = Math.max(0, y0 - r); yy <= Math.min(H - 1, y1 + r); yy += 2) for (let xx = Math.max(0, x0 - r); xx <= Math.min(W - 1, x1 + r); xx += 2) { const k = yy * W + xx; if (dk(k) && lab[k] !== id) foreign++; }
    if (foreign > Math.max(40, n * 1.5)) continue;
    let mx = 0, my = 0; for (const p of comp) { mx += p % W; my += (p / W) | 0; }
    fs.push({ px: comp, id, x: mx / n, y: my / n, x0, x1, y0, y1 });
  } });
  const paintF: number[] = [];
  const alive = new Uint8Array(fs.length).fill(1); const sinH = Math.sin((35 * Math.PI) / 180);
  for (let i = 0; i < fs.length; i++) for (let j = i + 1; j < fs.length; j++) {
    if (!alive[i] || !alive[j]) continue;
    const a = fs[i], b = fs[j]; const dx = b.x - a.x, dy = b.y - a.y, dist = Math.hypot(dx, dy);
    if (dist < maxW * 2 || dist > maxGap) continue;
    const ux = dx / dist, uy = dy / dist; if (Math.abs(uy) < sinH) continue;
    const inl: { k: number; t: number }[] = [];
    for (let k = 0; k < fs.length; k++) { if (!alive[k]) continue; const ex = fs[k].x - a.x, ey = fs[k].y - a.y; if (Math.abs(-ex * uy + ey * ux) <= maxW) inl.push({ k, t: ex * ux + ey * uy }); }
    if (inl.length < 5) continue;
    inl.sort((p, q) => p.t - q.t);
    // đoạn liên tục chứa a (t=0)
    let s0 = inl.findIndex((p) => p.k === i), e0 = s0;
    while (s0 > 0 && inl[s0].t - inl[s0 - 1].t <= maxGap) s0--;
    while (e0 < inl.length - 1 && inl[e0 + 1].t - inl[e0].t <= maxGap) e0++;
    const run = inl.slice(s0, e0 + 1); if (run.length < 6 || run[run.length - 1].t - run[0].t < minL) continue;
    // mảnh phải là đoạn gạch thuôn theo hướng đường (chấm tròn của dòng "....." không tính); phủ ≥ 40 % chiều dài
    let cover = 0, along = 0;
    for (const { k } of run) {
      let t0 = Infinity, t1 = -Infinity, v0 = Infinity, v1 = -Infinity;
      for (const p of fs[k].px) { const ex = (p % W) - a.x, ey = ((p / W) | 0) - a.y; const t = ex * ux + ey * uy, v = -ex * uy + ey * ux; if (t < t0) t0 = t; if (t > t1) t1 = t; if (v < v0) v0 = v; if (v > v1) v1 = v; }
      cover += t1 - t0 + 1; if (t1 - t0 >= 1.5 * (v1 - v0)) along++;
    }
    const span = run[run.length - 1].t - run[0].t;
    if (cover < span * 0.4 || along < run.length * 0.6) continue;
    // hai bên đường phải trống (chữ có láng giềng bên cạnh)
    let side = 0, tot = 0; const R = maxW * 3;
    for (const { k } of run) { const f = fs[k]; for (const sg of [-1, 1]) for (let v = maxW; v <= R; v++) { const X = Math.round(f.x - sg * v * uy), Y = Math.round(f.y + sg * v * ux); tot++; if (X >= 0 && Y >= 0 && X < W && Y < H && dk(Y * W + X) && lab[Y * W + X] !== f.id) side++; } }
    if (side > tot * 0.02) continue;
    for (const { k } of run) { alive[k] = 0; paintF.push(k); }
  }
  for (const k of paintF) for (const p of fs[k].px) { d[p * 4] = col.r; d[p * 4 + 1] = col.g; d[p * 4 + 2] = col.b; }
  return d;
}

/**
 * S10j – (1) khung xám mảnh: hàng/cột gần thẳng trục trong dải mép `band` có ≥ 25 % chiều dài là điểm hơi tối
 * (tương phản ≥ 6), dày ≤ bề dày tối đa, hai bên là giấy → tô màu giấy.
 * (2) vạch liền dài: thành phần tối liền khối, thuôn (dài ≥ 6 % cạnh ngắn, ≥ 8× bề ngang trung bình), góc ≥ 35°,
 * nằm trong dải mép, ít điểm tối lạ quanh → tô màu giấy.
 */
export function edgeFrameClean(d: Px, W: number, H: number, band = 0.15) {
  const col = paperColor(d, W, H); const S = Math.min(W, H); if (col.L < 90) return d;
  const bw = Math.round(S * band), maxW = Math.max(3, Math.round(S * 0.008));
  // CS-17e: (1) chỉ đọc/tô hàng-cột trong dải bw ± 5 → L, fM, pM chỉ tính trong dải B (L ngoài dải: tính khi cần, xem Lat).
  const B = bw + 8, L = lumBand(d, W, H, B);
  const inB = (i: number) => { const y = (i / W) | 0, x = i - y * W; return x < B || y < B || x >= W - B || y >= H - B || !(B * 2 < W && B * 2 < H); };
  const paint = (i: number) => { d[i * 4] = col.r; d[i * 4 + 1] = col.g; d[i * 4 + 2] = col.b; };
  const faint = (i: number) => col.L - L[i] >= 6 && col.L - L[i] < 120;
  const isPaper = (i: number) => col.L - L[i] < 5;
  // (1) đường thẳng trục: quét từng hàng/cột trong dải; đoạn liên tục dài ≥ 20 % cạnh ngắn
  const minRun = S * 0.2;
  const fM = new Uint8Array(W * H), pM = new Uint8Array(W * H);
  forBand(W, H, B, (o, a, b) => { for (let i = o + a; i < o + b; i++) { if (faint(i)) fM[i] = 1; if (isPaper(i)) pM[i] = 1; } });
  const scan = (horiz: boolean) => {
    const N = horiz ? H : W, M = horiz ? W : H;
    const at = (a: number, b: number) => (horiz ? a * W + b : b * W + a);
    // CS-17a: q(aa) = hàng "nét nhạt kẹp giữa giấy" của dòng aa, giữ 3 dòng gần nhất; on = q(a) | q(a−1) | q(a+1) như cũ.
    const qRows = new Map<number, Uint8Array>();
    // CS-17e: quét dọc — tính sẵn q của mọi cột dải mép (bw + 1 cột mỗi bên) bằng vòng theo hàng (đọc liền bộ nhớ),
    // lưu chuyển vị QT[cột·H + hàng]; cùng phép thử fM/pM như q().
    if (!horiz) {
      const QT = new Uint8Array(W * H), z = new Uint8Array(H), c1 = Math.min(W, bw + 1), c2 = Math.max(c1, W - bw - 1);
      for (let y = 0; y < H; y++) {
        const o = y * W;
        for (let aa = 0; aa < W; aa++) {
          if (aa === c1) aa = c2; if (aa >= W) break;
          const up = aa > 4 ? aa - 4 : 0, dn = aa + 4 < W - 1 ? aa + 4 : W - 1;
          if (fM[o + aa] && pM[o + up] && pM[o + dn]) QT[aa * H + y] = 1;
        }
      }
      for (let aa = -1; aa <= W; aa++) { if (aa === c1) aa = c2; qRows.set(aa, aa >= 0 && aa < W ? QT.subarray(aa * H, aa * H + H) : z); }
    }
    const q = (aa: number) => {
      let r = qRows.get(aa);
      if (r) return r;
      r = new Uint8Array(M);
      if (aa >= 0 && aa < N) { const up = aa > 4 ? aa - 4 : 0, dn = aa + 4 < N - 1 ? aa + 4 : N - 1; for (let b = 0; b < M; b++) if (fM[at(aa, b)] && pM[at(up, b)] && pM[at(dn, b)]) r[b] = 1; }
      qRows.set(aa, r); if (horiz) qRows.delete(aa - 3);
      return r;
    };
    for (let a = 0; a < N; a++) {
      if (a >= bw && a < N - bw) continue;
      let s = -1, gap = 0, hit = 0;
      const q0 = q(a), qm = q(a - 1), qp = q(a + 1);
      for (let b = 0; b <= M; b++) {
        const on = b < M && (q0[b] | qm[b] | qp[b]) === 1;
        if (on) { if (s < 0) s = b; hit++; gap = 0; continue; }
        if (s >= 0 && b < M && ++gap <= maxW * 2) continue;
        const e = b - gap; if (s >= 0 && e - s >= minRun && hit >= (e - s) * 0.6) {
          for (let k = s; k <= e && k < M; k++) for (let t = -3; t <= 3; t++) { const aa = a + t; if (aa < 0 || aa >= N) continue; const i = at(aa, k); if (faint(i)) paint(i); }
        }
        s = -1; gap = 0; hit = 0;
      }
    }
  };
  scan(true); scan(false);
  // (2) vạch liền dài thuôn
  // CS-17e: dk tính lười trên d sau (1) (0 = chưa tính, 1 = tối, 2 = không); việc tô của (2) dồn về cuối nên d không đổi khi còn hỏi dk.
  // L của (2) là L trước (1): trong dải B lấy mảng L; ngoài dải (1) không tô nên tính thẳng từ d (trước khi tô (2)).
  const dkc = new Uint8Array(W * H);
  const dk = (i: number) => { let v = dkc[i]; if (!v) v = dkc[i] = col.L - lumOf(d, i) >= 30 ? 1 : 2; return v === 1; };
  forBand(W, H, bw, (o, a, b) => { for (let i = o + a; i < o + b; i++) dkc[i] = col.L - lumOf(d, i) >= 30 ? 1 : 2; }); // dải dò: tính sẵn
  const Lat = (k: number) => (inB(k) ? L[k] : Math.fround(lumOf(d, k)));
  const seen = new Uint8Array(W * H); const sinH = Math.sin((35 * Math.PI) / 180); const paintK: number[] = [];
  forBand(W, H, bw, (o, a, b) => { for (let s = o + a; s < o + b; s++) {
    if (seen[s] || dkc[s] !== 1) continue;
    const comp = [s], st = [s]; seen[s] = 1;
    while (st.length && comp.length < 20000) { const i = st.pop()!; const py = (i / W) | 0, px = i - py * W;
      if (px > 0 && py > 0 && px < W - 1 && py < H - 1) { // CS-17e: điểm trong — 8 láng giềng cùng thứ tự, bỏ kiểm biên (chính nó đã đánh dấu)
        let k = i - W - 1; if (!seen[k] && dk(k)) { seen[k] = 1; st.push(k); comp.push(k); }
        k = i - W; if (!seen[k] && dk(k)) { seen[k] = 1; st.push(k); comp.push(k); }
        k = i - W + 1; if (!seen[k] && dk(k)) { seen[k] = 1; st.push(k); comp.push(k); }
        k = i - 1; if (!seen[k] && dk(k)) { seen[k] = 1; st.push(k); comp.push(k); }
        k = i + 1; if (!seen[k] && dk(k)) { seen[k] = 1; st.push(k); comp.push(k); }
        k = i + W - 1; if (!seen[k] && dk(k)) { seen[k] = 1; st.push(k); comp.push(k); }
        k = i + W; if (!seen[k] && dk(k)) { seen[k] = 1; st.push(k); comp.push(k); }
        k = i + W + 1; if (!seen[k] && dk(k)) { seen[k] = 1; st.push(k); comp.push(k); }
      } else
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const nx = px + dx, ny = py + dy; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue; const k = ny * W + nx; if (!seen[k] && dk(k)) { seen[k] = 1; st.push(k); comp.push(k); } } }
    const n = comp.length; if (n < 20) continue;
    let mx = 0, my = 0; for (const p of comp) { mx += p % W; my += (p / W) | 0; } mx /= n; my /= n;
    let sxx = 0, syy = 0, sxy = 0; for (const p of comp) { const ex = (p % W) - mx, ey = ((p / W) | 0) - my; sxx += ex * ex; syy += ey * ey; sxy += ex * ey; }
    const th = 0.5 * Math.atan2(2 * sxy, sxx - syy), ux = Math.cos(th), uy = Math.sin(th);
    let t0 = Infinity, t1 = -Infinity; for (const p of comp) { const t = ((p % W) - mx) * ux + (((p / W) | 0) - my) * uy; if (t < t0) t0 = t; if (t > t1) t1 = t; }
    const len = t1 - t0 + 1, wAvg = n / len;
    // thẳng: lệch vuông góc RMS nhỏ (nét chữ ký cong bị loại)
    let rr = 0; for (const p of comp) { const v = -((p % W) - mx) * uy + (((p / W) | 0) - my) * ux; rr += v * v; }
    if (Math.sqrt(rr / n) > Math.max(1.5, wAvg * 0.6)) continue;
    if (len < S * 0.04 || wAvg > maxW * 1.5 || len < wAvg * 8 || Math.abs(uy) < sinH) continue;
    // ít điểm tối lạ hai bên (không phải nét chữ ký/chữ)
    let side = 0, tot = 0; const R = maxW * 4;
    for (let q = 0; q < n; q += 3) { const p = comp[q]; const px = p % W, py = (p / W) | 0;
      for (const sg of [-1, 1]) for (let v = maxW * 2; v <= R; v += 2) { const X = Math.round(px - sg * v * uy), Y = Math.round(py + sg * v * ux); tot++; if (X >= 0 && Y >= 0 && X < W && Y < H && dk(Y * W + X) && !seen[Y * W + X]) side++; } }
    if (side > tot * 0.02) continue;
    for (const p of comp) { paintK.push(p); const px = p % W, py = (p / W) | 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const k = (py + dy) * W + px + dx; if (k >= 0 && k < W * H) { const l = Lat(k); if (col.L - l >= 6 && col.L - l < 80) paintK.push(k); } } }
  } });
  for (const k of paintK) paint(k);
  return d;
}

/**
 * S10j – mảng xám phẳng (bóng tờ khác, cạnh sắc) bất kỳ vị trí: nền cục bộ (đóng hình thái max→min trên ảnh ½)
 * thấp hơn giấy 6–70 → chia nền (flat-field) cho điểm đó; chữ vẫn tối, nền về màu giấy.
 */
export function greyBlockLift(d: Px, W: number, H: number) {
  const col = paperColor(d, W, H); if (col.L < 120) return d;
  const w = Math.ceil(W / 2), h = Math.ceil(H / 2), g = new Float32Array(w * h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) g[y * w + x] = lumOf(d, Math.min(H - 1, y * 2) * W + Math.min(W - 1, x * 2));
  const r = Math.max(4, Math.round(Math.min(w, h) / 180));
  // V5c: lọc max/min trượt van Herk–Gil-Werman (O(1)/điểm, kết quả y hệt cửa sổ [x−r, x+r] kẹp mép)
  let pad = new Float32Array(0);
  const vhgw = (src: Float32Array, dst: Float32Array, n: number, off: number, step: number, isMax: boolean, gF: Float32Array, hF: Float32Array) => {
    const k = 2 * r + 1, fill = isMax ? -Infinity : Infinity;
    const m = Math.ceil((n + 2 * r) / k) * k; // chuỗi đệm: i ∈ [0, m) ↔ vị trí i − r
    // CS-17a: chép chuỗi đệm một lần (pad) rồi chạy vòng max/min riêng — cùng phép so sánh, bỏ closure + rẽ nhánh mỗi điểm.
    for (let i = 0; i < m; i++) { const q = i - r; pad[i] = q >= 0 && q < n ? src[off + q * step] : fill; }
    if (isMax) {
      for (let b = 0; b < m; b += k) {
        let v = fill; for (let i = b; i < b + k; i++) { const a = pad[i]; v = a > v ? a : v; gF[i] = v; }
        v = fill; for (let i = b + k - 1; i >= b; i--) { const a = pad[i]; v = a > v ? a : v; hF[i] = v; }
      }
      for (let q = 0; q < n; q++) { const a = hF[q], c = gF[q + 2 * r]; dst[off + q * step] = a > c ? a : c; }
    } else {
      for (let b = 0; b < m; b += k) {
        let v = fill; for (let i = b; i < b + k; i++) { const a = pad[i]; v = a < v ? a : v; gF[i] = v; }
        v = fill; for (let i = b + k - 1; i >= b; i--) { const a = pad[i]; v = a < v ? a : v; hF[i] = v; }
      }
      for (let q = 0; q < n; q++) { const a = hF[q], c = gF[q + 2 * r]; dst[off + q * step] = a < c ? a : c; }
    }
  };
  // CS-17e: lượt dọc của vhgw chạy theo khối CW cột liền nhau (đọc/ghi theo hàng, thân thiện bộ đệm) — từng cột cùng
  // chuỗi phép so sánh như vhgw(…, step = w): g = max/min tiến trong khối k, h = lùi, kết quả = so(h[q], g[q + 2r]).
  const CW = 128, kk = 2 * r + 1, mm = Math.ceil((h + 2 * r) / kk) * kk;
  const G = new Float32Array(mm * CW), Hb = new Float32Array(mm * CW);
  const colPass = (src: Float32Array, dst: Float32Array, isMax: boolean) => {
    const fill = isMax ? -Infinity : Infinity;
    for (let c0 = 0; c0 < w; c0 += CW) {
      const cn = Math.min(CW, w - c0);
      for (let b = 0; b < mm; b += kk) {
        for (let i = b; i < b + kk; i++) {
          const q = i - r, inr = q >= 0 && q < h, so = q * w + c0, go = i * CW, gp = go - CW, first = i === b;
          for (let x = 0; x < cn; x++) {
            const a = inr ? src[so + x] : fill, v = first ? fill : G[gp + x];
            G[go + x] = isMax ? (a > v ? a : v) : (a < v ? a : v);
          }
        }
        for (let i = b + kk - 1; i >= b; i--) {
          const q = i - r, inr = q >= 0 && q < h, so = q * w + c0, go = i * CW, gp = go + CW, first = i === b + kk - 1;
          for (let x = 0; x < cn; x++) {
            const a = inr ? src[so + x] : fill, v = first ? fill : Hb[gp + x];
            Hb[go + x] = isMax ? (a > v ? a : v) : (a < v ? a : v);
          }
        }
      }
      for (let q = 0; q < h; q++) {
        const ho = q * CW, go = (q + 2 * r) * CW, o = q * w + c0;
        for (let x = 0; x < cn; x++) { const a = Hb[ho + x], c = G[go + x]; dst[o + x] = isMax ? (a > c ? a : c) : (a < c ? a : c); }
      }
    }
  };
  const filt = (src: Float32Array, isMax: boolean) => {
    const a = new Float32Array(w * h), b = new Float32Array(w * h);
    const len = Math.max(w, h) + 4 * r + 2, gF = new Float32Array(len), hF = new Float32Array(len); pad = new Float32Array(len);
    for (let y = 0; y < h; y++) vhgw(src, a, w, y * w, 1, isMax, gF, hF);
    colPass(a, b, isMax);
    return b;
  };
  const bg0 = filt(filt(g, true), false);
  // S10k: nền mỗi điểm = min nền ½ trong lân cận 3×3 → điểm ngay mép mảng (mất khi lấy mẫu ½) cũng được nâng, hết đường mép sắc.
  const bg = new Float32Array(w * h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    let v = bg0[y * w + x];
    if (y > 0 && y < h - 1 && x > 0 && x < w - 1) { // CS-17a: điểm trong — 9 ô không cần kiểm biên (min không phụ thuộc thứ tự)
      const i = y * w + x;
      v = Math.min(v, bg0[i - w - 1], bg0[i - w], bg0[i - w + 1], bg0[i - 1], bg0[i + 1], bg0[i + w - 1], bg0[i + w], bg0[i + w + 1]);
    } else for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const yy = y + dy, xx = x + dx; if (yy >= 0 && yy < h && xx >= 0 && xx < w) v = Math.min(v, bg0[yy * w + xx]); }
    bg[y * w + x] = v;
  }
  // CS-17e: L (độ sáng sau khi nâng) tính ngay trong vòng nâng — mỗi điểm chỉ bị nâng ở lượt của chính nó nên y hệt
  // vòng tính L riêng sau đó. y >> 1 ≤ h − 1 và x >> 1 ≤ w − 1 luôn đúng (w = ⌈W/2⌉) → bỏ kẹp.
  const lifted = new Uint8Array(W * H), rowL = new Uint8Array(H), L = new Float32Array(W * H);
  for (let y = 0; y < H; y++) {
    const br = (y >> 1) * w, o = y * W;
    for (let x = 0; x < W; x++) {
      const i = o + x, b = bg[br + (x >> 1)], def = col.L - b;
      if (def >= 6 && def <= 70) {
        const s = col.L / b; lifted[i] = 1; rowL[y] = 1;
        for (let c = 0; c < 3; c++) d[i * 4 + c] = Math.min(255, d[i * 4 + c] * s);
      }
      L[i] = lumOf(d, i);
    }
  }
  // S10k: đường mép mảnh (≤ 2 px) nhạt còn lại trong vùng đã nâng, hai bên cách 3 px là giấy → tô màu giấy.
  // CS-17e: hàng y chỉ xét khi hàng y, y ± 3 có điểm đã nâng.
  const pap = (k: number) => L[k] >= col.L - 12;
  for (let y = 3; y < H - 3; y++) {
    if (!rowL[y] && !rowL[y - 3] && !rowL[y + 3]) continue;
    for (let x = 3; x < W - 3; x++) {
    const i = y * W + x; if (!lifted[i] && !lifted[i - 3] && !lifted[i + 3] && !lifted[i - 3 * W] && !lifted[i + 3 * W]) continue;
    const def = col.L - L[i]; if (def < 6 || def > 45) continue;
    if ((pap(i - 3) && pap(i + 3)) || (pap(i - 3 * W) && pap(i + 3 * W))) { for (let c = 0; c < 3; c++) d[i * 4 + c] = d[(pap(i - 3) ? i - 3 : i - 3 * W) * 4 + c]; }
    }
  }
  return d;
}

/**
 * S10m – Q2 sót ở góc: vệt mảnh cô lập (dấu tick, đoạn mép tờ dưới) nằm trong vùng góc 12 %.
 * Thành phần tối: dài 2–10 % cạnh ngắn, bề dày TB ≤ 1,2 % cạnh ngắn, quanh nó (lề 2 %) gần như không có
 * điểm tối khác → tô màu giấy. Chữ ký/chữ ở góc lớn hơn hoặc không cô lập nên được giữ.
 */
export function edgeCornerClean(d: Px, W: number, H: number, zone = 0.12) {
  const col = paperColor(d, W, H); const dark = darkThreshold(col.L) + 25; const S = Math.min(W, H);
  const cz = Math.round(S * zone), minL = Math.round(S * 0.02), maxL = Math.round(S * 0.1), maxW = Math.max(3, Math.round(S * 0.012)), mg = Math.round(S * 0.02);
  const inCorner = (x: number, y: number) => (x < cz || x >= W - cz) && (y < cz || y >= H - cz);
  // CS-17a: nhớ kết quả tối/sáng mỗi điểm (0 = chưa tính); điểm bị tô lại thì xoá nhớ → kết quả y như tính trực tiếp.
  const dc = new Uint8Array(W * H);
  const isDark = (k: number) => { let v = dc[k]; if (!v) { v = lumOf(d, k) < dark ? 1 : 2; dc[k] = v; } return v === 1; };
  const seen = new Uint8Array(W * H), mine = new Uint8Array(W * H);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    if (!inCorner(x, y)) { x = x < W - cz ? W - cz - 1 : W; continue; } // CS-17a: nhảy tới vùng góc kế tiếp trên hàng
    const s = y * W + x; if (seen[s] || !isDark(s)) continue;
    const comp = [s], st = [s]; seen[s] = 1; let x0 = x, x1 = x, y0 = y, y1 = y;
    while (st.length && comp.length < 100000) {
      const i = st.pop()!; const py = (i / W) | 0, px = i - py * W;
      if (px < x0) x0 = px; if (px > x1) x1 = px; if (py < y0) y0 = py; if (py > y1) y1 = py;
      if (px > 0 && py > 0 && px < W - 1 && py < H - 1) { // CS-17e: điểm trong — 8 láng giềng cùng thứ tự, bỏ kiểm biên (chính nó đã đánh dấu)
        let k = i - W - 1; if (!seen[k] && isDark(k)) { seen[k] = 1; st.push(k); comp.push(k); }
        k = i - W; if (!seen[k] && isDark(k)) { seen[k] = 1; st.push(k); comp.push(k); }
        k = i - W + 1; if (!seen[k] && isDark(k)) { seen[k] = 1; st.push(k); comp.push(k); }
        k = i - 1; if (!seen[k] && isDark(k)) { seen[k] = 1; st.push(k); comp.push(k); }
        k = i + 1; if (!seen[k] && isDark(k)) { seen[k] = 1; st.push(k); comp.push(k); }
        k = i + W - 1; if (!seen[k] && isDark(k)) { seen[k] = 1; st.push(k); comp.push(k); }
        k = i + W; if (!seen[k] && isDark(k)) { seen[k] = 1; st.push(k); comp.push(k); }
        k = i + W + 1; if (!seen[k] && isDark(k)) { seen[k] = 1; st.push(k); comp.push(k); }
      } else
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        const nx = px + dx, ny = py + dy; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
        const k = ny * W + nx; if (!seen[k] && isDark(k)) { seen[k] = 1; st.push(k); comp.push(k); }
      }
    }
    const len = Math.max(x1 - x0, y1 - y0) + 1;
    if (len < minL || len > maxL || comp.length / len > maxW) continue;
    if (!(inCorner(x0, y0) && inCorner(x1, y1) && inCorner(x0, y1) && inCorner(x1, y0))) continue;
    for (const i of comp) mine[i] = 1;
    let other = 0;
    for (let yy = Math.max(0, y0 - mg); yy <= Math.min(H - 1, y1 + mg); yy++) for (let xx = Math.max(0, x0 - mg); xx <= Math.min(W - 1, x1 + mg); xx++) {
      const k = yy * W + xx; if (!mine[k] && isDark(k)) other++;
    }
    for (const i of comp) mine[i] = 0;
    if (other > comp.length * 0.15) continue;
    // xoá cả quầng xám quanh nét (≤ 3 px)
    for (let yy = Math.max(0, y0 - 3); yy <= Math.min(H - 1, y1 + 3); yy++) for (let xx = Math.max(0, x0 - 3); xx <= Math.min(W - 1, x1 + 3); xx++) {
      const k = yy * W + xx; if (lumOf(d, k) < col.L - 3) { d[k * 4] = col.r; d[k * 4 + 1] = col.g; d[k * 4 + 2] = col.b; dc[k] = 0; }
    }
  }
  // vạch mảnh nhạt dọc/ngang trong vùng góc (đuôi đường kẻ bảng, mép tờ dưới): hai bên cách 4 px là giấy, dài ≥ 2 % → tô giấy
  const grey = (k: number) => lumOf(d, k) < col.L - 15, pap = (k: number) => lumOf(d, k) >= col.L - 8;
  const wipe = (ks: number[]) => { for (const k of ks) { d[k * 4] = col.r; d[k * 4 + 1] = col.g; d[k * 4 + 2] = col.b; } };
  for (let x = 4; x < W - 4; x++) {
    if (!(x < cz || x >= W - cz)) continue;
    for (const [ya, yb] of [[0, cz], [H - cz, H]]) {
      let run: number[] = [];
      for (let y = ya; y <= yb; y++) {
        const k = y * W + x;
        if (y < yb && grey(k) && pap(k - 4) && pap(k + 4)) { run.push(k); continue; }
        if (run.length >= minL) wipe(run); run = [];
      }
    }
  }
  for (let y = 4; y < H - 4; y++) {
    if (!(y < cz || y >= H - cz)) continue;
    for (const [xa, xb] of [[0, cz], [W - cz, W]]) {
      let run: number[] = [];
      for (let x = xa; x <= xb; x++) {
        const k = y * W + x;
        if (x < xb && grey(k) && pap(k - 4 * W) && pap(k + 4 * W)) { run.push(k); continue; }
        if (run.length >= minL) wipe(run); run = [];
      }
    }
  }
  return d;
}

/**
 * R6.1b-3 – Nâng bóng nền tràn vào 4 góc sau khi nắn khung (cổng 17.4: góc tối ≤ 0,2 %).
 * Thành phần tối (luma < 60) trong vùng góc 6 % mà chạm mép ảnh là nền ngoài tờ giấy
 * (nội dung thật hầu như không dính mép) → tô màu giấy cả quầng xám 2 px quanh nó.
 * Vệt tối ở góc nhưng KHÔNG chạm mép (chữ ký, dấu) được giữ nguyên.
 */
export function cornerShadowLift(d: Px, W: number, H: number, zone = 0.06) {
  const col = paperColor(d, W, H); const S = Math.min(W, H);
  const cz = Math.round(S * zone);
  const inCorner = (x: number, y: number) => (x < cz || x >= W - cz) && (y < cz || y >= H - cz);
  const isDark = (k: number) => lumOf(d, k) < 60;
  const seen = new Uint8Array(W * H);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    if (!inCorner(x, y)) { x = x < W - cz ? W - cz - 1 : W; continue; } // CS-17a: nhảy tới vùng góc kế tiếp trên hàng
    const s = y * W + x; if (seen[s] || !isDark(s)) continue;
    const st = [s]; seen[s] = 1; let touch = false;
    let x0 = x, x1 = x, y0 = y, y1 = y; let n = 0;
    while (st.length && n < 200000) {
      const i = st.pop()!; n++; const px = i % W, py = (i / W) | 0;
      if (px < x0) x0 = px; if (px > x1) x1 = px; if (py < y0) y0 = py; if (py > y1) y1 = py;
      if (px === 0 || py === 0 || px === W - 1 || py === H - 1) touch = true;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        const nx = px + dx, ny = py + dy;
        if (nx < 0 || ny < 0 || nx >= W || ny >= H || !inCorner(nx, ny)) continue;
        const k = ny * W + nx; if (!seen[k] && isDark(k)) { seen[k] = 1; st.push(k); }
      }
    }
    if (!touch) {
      // Khối đen đặc (khối marker/che nằm trong vùng góc, không chạm mép): lấp đầy > 70 % khung bao,
      // cạnh 0,5–8 % cạnh ngắn → coi là vật lạ, tô giấy. Nét chữ/con dấu loang không đặc nên được giữ.
      const bw = x1 - x0 + 1, bh = y1 - y0 + 1, fill = n / (bw * bh);
      const block = fill > 0.7 && bw >= S * 0.005 && bh >= S * 0.005 && bw <= S * 0.08 && bh <= S * 0.08;
      if (!block) continue;
    }
    for (let yy = Math.max(0, y0 - 2); yy <= Math.min(H - 1, y1 + 2); yy++) for (let xx = Math.max(0, x0 - 2); xx <= Math.min(W - 1, x1 + 2); xx++) {
      const k = yy * W + xx; if (lumOf(d, k) < col.L - 3) { d[k * 4] = col.r; d[k * 4 + 1] = col.g; d[k * 4 + 2] = col.b; }
    }
  }
  return d;
}
