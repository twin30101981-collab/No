@echo off
REM Dua Ghi Nhanh len Cloudflare Workers (mien phi). Can Node.js LTS.
cd /d "%~dp0ghi-nhanh"
call npx --yes wrangler@4 whoami >nul 2>&1 || call npx --yes wrangler@4 login
call npx --yes wrangler@4 deploy -c server/wrangler.json
echo.
echo Xong. Mo dia chi https://ghi-nhanh....workers.dev o tren bang Chrome tren dien thoai, bam menu, chon Cai dat ung dung.
pause
