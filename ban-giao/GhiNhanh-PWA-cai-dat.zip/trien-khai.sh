#!/usr/bin/env bash
# Đưa Ghi Nhanh lên Cloudflare Workers (miễn phí). Cần Node.js LTS.
set -e
cd "$(dirname "$0")/ghi-nhanh"
npx --yes wrangler@4 whoami >/dev/null 2>&1 || npx --yes wrangler@4 login
npx --yes wrangler@4 deploy -c server/wrangler.json
echo; echo "Xong. Mở địa chỉ https://ghi-nhanh....workers.dev ở trên bằng Chrome trên điện thoại → ⋮ → Cài đặt ứng dụng."
