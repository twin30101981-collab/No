import { n as runInPool } from "./worker-pool-DW9Ak2AM.mjs";
import { A as loadImg, B as sharpSize, E as grayscale, H as skewFromGray, O as lapVarGray, T as glare, U as skewSize, Z as yieldTask } from "./image-DFWRNlNd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/post-capture-metrics-X7ExzflM.js
var clamp = (v) => Math.max(0, Math.min(1, v));
function gradePage(m) {
	const net = clamp((m.blur - 12) / 58);
	const loa = clamp(1 - m.glare / .06);
	const nghieng = clamp(1 - (Math.abs(m.skew) - 1) / 7);
	const nen = clamp((m.brightness - 70) / 100) * .7 + clamp(m.contrast / 50) * .3;
	const parts = {
		net,
		loa,
		nghieng,
		nen
	};
	const worst = Math.min(net, loa, nghieng, nen);
	const avg = .4 * net + .25 * loa + .15 * nghieng + .2 * nen;
	const score = Math.round(100 * Math.min(avg, worst + .35));
	const level = score >= 75 ? "tot" : score >= 50 ? "kha" : "kem";
	const names = {
		net: "Ảnh hơi mờ",
		loa: "Bị lóa sáng",
		nghieng: "Trang bị nghiêng",
		nen: "Nền tối / thiếu sáng"
	};
	const k = Object.keys(parts).reduce((a, b) => parts[b] < parts[a] ? b : a);
	return {
		score,
		level,
		parts,
		tip: level === "tot" ? "Trang đạt chất lượng" : names[k]
	};
}
/** CS-05 (G-05): số đo chất lượng lưu theo ẢNH GỐC (GradeBadge nhận pg.orig) nhưng trước đây tra theo p.src (ảnh đã dựng)
*  → trúng 0/10, và chỉ ô đang hiện mới được tính (2/10). Nay tra theo ảnh gốc, tính bù cho mọi trang MỚI — ở nền, sau khi đã điều hướng. */
async function postCaptureWithMetrics(saved, before, isNew, opts = {}) {
	const m = /* @__PURE__ */ new Map();
	const idle = () => new Promise((r) => "requestIdleCallback" in window ? requestIdleCallback(() => r(), { timeout: 3e3 }) : setTimeout(r, 200));
	const fresh = saved.pages.filter((p) => !before.has(p.id));
	try {
		if (!opts.heal || fresh.some((p) => !metricsCache.has(p.orig || p.src))) await new Promise((r) => setTimeout(r, 1500));
		for (const p of fresh) {
			const k = p.orig || p.src;
			if (!metricsCache.has(k)) {
				await idle();
				await gradeOf(k).catch(() => null);
			}
			const x = metricsCache.get(k);
			if (x) m.set(p.id, x);
		}
		const { runPostCapture } = await import("./post-capture-Bf4S_rOw.mjs");
		await runPostCapture(saved, before, isNew, m, opts);
	} catch (e) {
		if (opts.heal) await import("./runner-CZAn6hg6.mjs").then((n) => n.o).then((n) => n.a).then((r) => r.healPending([saved])).catch(() => {});
		throw e;
	}
}
var gradeCache = /* @__PURE__ */ new Map();
var metricsCache = /* @__PURE__ */ new Map();
async function gradeOf(src) {
	const hit = gradeCache.get(src);
	if (hit) return hit;
	const img = await loadImg(src);
	const W = img.naturalWidth, H = img.naturalHeight;
	const s = Math.min(1, 600 / Math.max(W, H));
	const c = document.createElement("canvas");
	c.width = Math.round(W * s);
	c.height = Math.round(H * s);
	const g = c.getContext("2d");
	g.drawImage(img, 0, 0, c.width, c.height);
	const d = g.getImageData(0, 0, c.width, c.height).data;
	let sum = 0, sq = 0;
	const n = d.length / 4;
	for (let i = 0; i < d.length; i += 4) {
		const l = .299 * d[i] + .587 * d[i + 1] + .114 * d[i + 2];
		sum += l;
		sq += l * l;
	}
	const mean = sum / n;
	await yieldTask();
	const k1 = skewSize(c.width, c.height);
	let g1 = null;
	try {
		g1 = grayscale(c, k1.w, k1.h);
	} catch {}
	await yieldTask();
	const k2 = sharpSize(W, H);
	const g2 = grayscale(img, k2.w, k2.h);
	await yieldTask();
	const gl = glare(img, W, H);
	const job = g1 ? runInPool("grade", {
		g1,
		w1: k1.w,
		h1: k1.h,
		g2,
		w2: k2.w,
		h2: k2.h
	}, [g1.buffer, g2.buffer]) : null;
	const viaPool = job ? await job.then((r) => r.out, () => null) : null;
	let skew = 0, blur;
	if (viaPool) [skew, blur] = viaPool;
	else {
		try {
			if (g1) skew = skewFromGray(g1.byteLength ? g1 : grayscale(c, k1.w, k1.h), k1.w, k1.h);
		} catch {}
		blur = lapVarGray(g2.byteLength ? g2 : grayscale(img, k2.w, k2.h), k2.w, k2.h);
	}
	const m = {
		blur,
		glare: gl,
		skew,
		brightness: mean,
		contrast: Math.sqrt(Math.max(0, sq / n - mean * mean))
	};
	const r = gradePage(m);
	metricsCache.set(src, m);
	c.width = 0;
	gradeCache.set(src, r);
	return r;
}
//#endregion
export { gradeCache, gradeOf, postCaptureWithMetrics, gradePage as t };
