import { n as init_performance, r as performance_default } from "../_libs/canvg+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/offline-BFa7CUSi.js
init_performance();
/** Chỉ bật ở bản đã xuất bản: trong khung xem trước/bản dev, SW sẽ giữ mã cũ gây khó hiểu. */
function swAllowed(loc, inIframe, isProd) {
	if (!isProd || inIframe) return false;
	const sw = loc.search ? new URLSearchParams(loc.search).get("sw") : null;
	if (sw === "off") return false;
	if (sw === "on") return true;
	const h = loc.hostname;
	if (h === "localhost" || h === "127.0.0.1") return false;
	if (h.startsWith("id-preview--") || h.startsWith("preview--") || h.includes("-dev.lovable.app")) return false;
	const under = (d) => h === d || h.endsWith(`.${d}`);
	if (under("lovableproject.com") || under("lovableproject-dev.com") || under("beta.lovable.dev")) return false;
	return true;
}
/** HM-08: địa chỉ đăng ký SW kèm mã bản build → mỗi bản phát hành là một SW mới (xem public/sw.js). */
var swScriptUrl = (buildId) => `/sw.js?v=${encodeURIComponent(buildId || "dev")}`;
function isAppSwUrl(url) {
	try {
		return new URL(url).pathname.endsWith("/sw.js");
	} catch {
		return false;
	}
}
function unregisterAppSw() {
	navigator.serviceWorker.getRegistrations().then((rs) => rs.forEach((r) => {
		if (isAppSwUrl((r.active ?? r.waiting ?? r.installing)?.scriptURL ?? "")) r.unregister();
	})).catch(() => {});
}
/** R6.3: tệp mã/kiểu/phông cùng nguồn mà trang đã tải — cần cất vào bộ nhớ đệm của SW. */
function shellAssetUrls(names, origin) {
	const out = /* @__PURE__ */ new Set();
	for (const n of names) {
		let u;
		try {
			u = new URL(n, origin);
		} catch {
			continue;
		}
		if (u.origin !== origin) continue;
		if (u.pathname.startsWith("/assets/") || u.pathname.startsWith("/fonts/")) out.add(u.pathname + u.search);
	}
	return [...out];
}
/**
* Lần mở đầu tiên, trang nạp xong TRƯỚC khi SW kiểm soát nên các tệp /assets/ không được cất lại
* → mất mạng ngay sau đó thì trang không chạy được. Sau khi SW sẵn sàng, tải lại các tệp đó qua SW
* (lấy từ bộ đệm HTTP, gần như không tốn mạng) để SW cất vào bộ nhớ đệm.
*/
function warmShellCache(reg) {
	navigator.serviceWorker.ready.then(async () => {
		if (!navigator.serviceWorker.controller) {
			await new Promise((done) => {
				navigator.serviceWorker.addEventListener("controllerchange", () => done(), { once: true });
				setTimeout(done, 5e3);
			});
			if (!navigator.serviceWorker.controller) return;
		}
		const names = performance_default.getEntriesByType("resource").map((e) => e.name);
		const links = Array.from(document.querySelectorAll("link[rel=modulepreload],link[rel=stylesheet]")).map((l) => l.href);
		const urls = shellAssetUrls([...names, ...links], window.location.origin);
		await Promise.all(urls.map((u) => fetch(u).then((r) => r.arrayBuffer()).catch(() => {})));
	}).catch(() => {});
}
function registerServiceWorker() {
	if (typeof window === "undefined" || !("serviceWorker" in navigator)) return;
	let inIframe = true;
	try {
		inIframe = window.self !== window.top;
	} catch {}
	if (!swAllowed(window.location, inIframe, true)) {
		unregisterAppSw();
		return;
	}
	const go = () => {
		navigator.serviceWorker.register(swScriptUrl("20261015024518"), {
			scope: "/",
			updateViaCache: "none"
		}).then((reg) => {
			warmShellCache(reg);
			return watchUpdates(reg, navigator.serviceWorker);
		}).catch(() => {});
	};
	if (document.readyState === "complete") go();
	else window.addEventListener("load", go, { once: true });
}
function watchUpdates(reg, sw, notify = notifyUpdate, everyMs = 18e5) {
	if (!sw.controller) return;
	let shown = false;
	const offer = (w) => {
		if (!w || shown) return;
		shown = true;
		notify(() => {
			sw.addEventListener("controllerchange", () => window.location.reload());
			w.postMessage("skip-waiting");
		});
	};
	offer(reg.waiting);
	reg.addEventListener("updatefound", () => {
		const w = reg.installing;
		w?.addEventListener("statechange", () => {
			if (w.state === "installed") offer(w);
		});
	});
	const t = setInterval(() => {
		if (navigator.onLine !== false) reg.update().catch(() => {});
	}, everyMs);
	return () => clearInterval(t);
}
function notifyUpdate(apply) {
	import("../_libs/sonner.mjs").then((n) => n.n).then(({ toast }) => toast("Đã có bản mới của Ghi Nhanh.", {
		duration: Infinity,
		action: {
			label: "Cập nhật",
			onClick: apply
		}
	}));
}
var READY_KEY = "ghi-nhanh-offline-ocr";
var SHELL_TAG = "shell";
function offlineOcrReady(lang) {
	try {
		return localStorage.getItem(READY_KEY) === `${lang}|${SHELL_TAG}`;
	} catch {
		return false;
	}
}
/**
* B13: lưu sẵn vỏ ứng dụng — tải trước các trang chính qua service worker
* (networkFirstPage cất vào bộ nhớ đệm) để chế độ máy bay vẫn mở và quét được.
*/
async function prepareOfflineShell(routes = ["/", "/scan"], fetchFn = fetch) {
	for (const r of routes) {
		const res = await fetchFn(r, { credentials: "same-origin" });
		if (!res.ok) throw new Error(`Không tải được ${r} (${res.status})`);
	}
}
/** Mở một OCR worker để tải worker, lõi và dữ liệu ngôn ngữ — SW và trình duyệt giữ lại cho lần sau. */
async function prepareOfflineOcr(lang) {
	const { persistOnce } = await import("./persist-ClcimcMq.mjs");
	await persistOnce().catch(() => false);
	await prepareOfflineShell();
	const { sharedOcr } = await import("./ocr-worker-DbwCMwXG.mjs").then((n) => n.t).then((n) => n.t);
	await sharedOcr().warm(lang);
	try {
		localStorage.setItem(READY_KEY, `${lang}|${SHELL_TAG}`);
	} catch {}
}
//#endregion
export { prepareOfflineOcr as n, registerServiceWorker as r, offlineOcrReady as t };
