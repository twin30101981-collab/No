import { o as __toESM, r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ocr-worker-DbwCMwXG.js
var ocr_worker_DbwCMwXG_exports = /* @__PURE__ */ __exportAll({
	n: () => sharedOcr,
	t: () => ocr_worker_exports
});
var ocr_worker_exports = /* @__PURE__ */ __exportAll$1({
	OcrUnavailableError: () => OcrUnavailableError,
	SharedOcr: () => SharedOcr,
	assertOcrReachable: () => assertOcrReachable,
	currentLang: () => currentLang,
	extraOcr: () => extraOcr,
	ocrWorkerUrl: () => ocrWorkerUrl,
	sharedOcr: () => sharedOcr
});
var SharedOcr = class {
	factory;
	engine = null;
	lang = "";
	chain = Promise.resolve();
	progress = null;
	created = 0;
	constructor(factory) {
		this.factory = factory;
	}
	get(lang) {
		if (this.engine && this.lang !== lang) {
			const old = this.engine;
			this.engine = null;
			old.then((e) => e.terminate()).catch(() => {});
		}
		this.lang = lang;
		if (!this.engine) {
			this.created++;
			const p = this.factory(lang, (m) => {
				if (m.status === "recognizing text") this.progress?.(m.progress);
			});
			p.catch(() => {
				if (this.engine === p) this.engine = null;
			});
			this.engine = p;
		}
		return this.engine;
	}
	/** Chạy một lượt nhận chữ; các lượt nối đuôi nhau trên cùng Worker. */
	run(lang, src, opts) {
		const job = this.chain.then(async () => {
			this.progress = opts?.onProgress ?? null;
			try {
				return await (await this.get(lang)).recognize(src, {}, opts?.out);
			} finally {
				this.progress = null;
			}
		});
		this.chain = job.catch(() => {});
		return job;
	}
	/** Chỉ tải sẵn Worker + dữ liệu ngôn ngữ. */
	async warm(lang) {
		await this.get(lang);
	}
	/** Dừng việc đang chạy (huỷ): bỏ Worker, lượt sau tự dựng lại. */
	async reset() {
		const e = this.engine;
		this.engine = null;
		if (e) await e.then((w) => w.terminate()).catch(() => {});
	}
};
/** HM-07: không tải được gói nhận chữ (mất mạng/CDN bị chặn lần đầu) — lỗi có tên để giao diện báo đúng cách khắc phục. */
var OcrUnavailableError = class extends Error {
	constructor() {
		super("Chưa tải được gói nhận chữ");
		this.name = "OcrUnavailableError";
	}
};
var ocrWorkerUrl = (version) => `https://cdn.jsdelivr.net/npm/tesseract.js@v${version}/dist/worker.min.js`;
/** Thử với tới tệp worker trước khi dựng Worker: nếu thất bại thì ném lỗi gọn, thay vì để Worker nổ lỗi importScripts không ai bắt.
*  Tệp đã được service worker giữ (mục Tôi → Tải sẵn) vẫn lấy được khi mất mạng. */
async function assertOcrReachable(fetchFn = fetch, url) {
	try {
		await fetchFn(url ?? ocrWorkerUrl((await import("./package-B2n4Arbl.mjs")).default.version), { mode: "no-cors" });
	} catch {
		throw new OcrUnavailableError();
	}
}
async function makeEngine(lang, logger) {
	await assertOcrReachable();
	return (await import("../_libs/tesseract.js+unenv.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()))).createWorker(lang, 1, { logger });
}
var shared = null;
function sharedOcr() {
	return shared ??= new SharedOcr(makeEngine);
}
/** S7: Worker Tesseract riêng cho làn OCR phụ (không nối đuôi với Worker chung). */
function extraOcr() {
	return new SharedOcr(makeEngine);
}
async function currentLang() {
	return (await import("./settings-DDlMLZCe.mjs").then((n) => n.s).then((n) => n.s)).getSettings().ocrLang;
}
//#endregion
export { sharedOcr as n, ocr_worker_DbwCMwXG_exports as t };
