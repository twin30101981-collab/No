import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { i as getVaultKey, r as encryptJson, t as decryptJson } from "./vault-CuGqX6h0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-keys-fpHjq2Jo.js
/**
* AI-04 (QD-12): "Khoá AI của tôi" — người dùng nhập/đổi/xoá key Claude/Mistral/Gemini ngay trong app, chọn mô hình Claude, đổi thứ tự nguồn.
* Lưu MÃ HOÁ AES-GCM trên máy: khoá thiết bị (WebCrypto, không xuất được) trong IndexedDB riêng "ghi-nhanh-khoa-ai"; đang bật khoá PIN
* (két đang mở) thì mã hoá bằng khoá két. KHÔNG nằm trong sao lưu (CSDL riêng), đồng bộ mây, nhật ký, gói báo lỗi hay URL.
* Gửi tới máy chủ của app qua tiêu đề x-ai-keys CHỈ ở các lệnh AI (middleware trong ai.functions.ts); máy chủ dùng cho lượt đó, không lưu/ghi log.
*/
var ai_keys_exports = /* @__PURE__ */ __exportAll({
	AI_KEYS_HEADER: () => AI_KEYS_HEADER,
	AI_PROVIDER_ORDER: () => AI_PROVIDER_ORDER,
	CLAUDE_MODELS: () => CLAUDE_MODELS,
	aiKeysHeader: () => aiKeysHeader,
	cleanKeys: () => cleanKeys,
	clearAiKeys: () => clearAiKeys,
	encodeAiKeys: () => encodeAiKeys,
	hasAnyKey: () => hasAnyKey,
	loadAiKeys: () => loadAiKeys,
	maskKey: () => maskKey,
	saveAiKeys: () => saveAiKeys
});
var AI_PROVIDER_ORDER = [
	"lovable",
	"claude",
	"mistral",
	"gemini"
];
var CLAUDE_MODELS = [
	{
		id: "claude-opus-5-5",
		label: "Claude Opus 5.5 (chính xác nhất)"
	},
	{
		id: "claude-sonnet-5-5",
		label: "Claude Sonnet 5.5 (cân bằng)"
	},
	{
		id: "claude-haiku-5-5",
		label: "Claude Haiku 5.5 (rẻ nhất)"
	}
];
var AI_KEYS_HEADER = "x-ai-keys";
var DB = "ghi-nhanh-khoa-ai";
var STORE = "kv";
function open() {
	return new Promise((res, rej) => {
		const r = indexedDB.open(DB, 1);
		r.onupgradeneeded = () => r.result.createObjectStore(STORE);
		r.onsuccess = () => res(r.result);
		r.onerror = () => rej(r.error);
	});
}
async function kv(mode, fn) {
	const db = await open();
	try {
		return await new Promise((res, rej) => {
			const q = fn(db.transaction(STORE, mode).objectStore(STORE));
			q.onsuccess = () => res(q.result);
			q.onerror = () => rej(q.error);
		});
	} finally {
		db.close();
	}
}
async function deviceKey() {
	const k = await kv("readonly", (s) => s.get("device-key"));
	if (k) return k;
	const nk = await crypto.subtle.generateKey({
		name: "AES-GCM",
		length: 256
	}, false, ["encrypt", "decrypt"]);
	await kv("readwrite", (s) => s.put(nk, "device-key"));
	return nk;
}
/** Chuẩn hoá: bỏ khoảng trắng, key rỗng; thứ tự chỉ gồm nguồn hợp lệ, không trùng. */
function cleanKeys(k) {
	const out = {};
	for (const p of [
		"claude",
		"mistral",
		"gemini"
	]) {
		const v = k[p]?.trim();
		if (v) out[p] = v.slice(0, 400);
	}
	if (k.claudeModel && CLAUDE_MODELS.some((m) => m.id === k.claudeModel)) out.claudeModel = k.claudeModel;
	const ord = [...new Set((k.order ?? []).filter((p) => AI_PROVIDER_ORDER.includes(p)))];
	if (ord.length) out.order = ord;
	return out;
}
var hasAnyKey = (k) => !!(k && (k.claude || k.mistral || k.gemini));
/** Hiện key dạng che: 6 ký tự đầu … 4 ký tự cuối. */
var maskKey = (k) => !k ? "" : k.length <= 12 ? "••••" : `${k.slice(0, 6)}…${k.slice(-4)}`;
var cache;
async function loadAiKeys() {
	if (typeof indexedDB === "undefined") return {
		keys: null,
		locked: false
	};
	const st = await kv("readonly", (s) => s.get("keys"));
	if (!st) {
		cache = null;
		return {
			keys: null,
			locked: false
		};
	}
	const key = st.mode === "pin" ? getVaultKey() : await deviceKey();
	if (!key) return {
		keys: null,
		locked: true
	};
	try {
		cache = cleanKeys(await decryptJson(key, st.blob));
		return {
			keys: cache,
			locked: false
		};
	} catch {
		return {
			keys: null,
			locked: st.mode === "pin"
		};
	}
}
async function saveAiKeys(k) {
	const keys = cleanKeys(k);
	const vk = getVaultKey();
	const mode = vk ? "pin" : "device";
	const blob = await encryptJson(vk ?? await deviceKey(), keys);
	await kv("readwrite", (s) => s.put({
		mode,
		blob
	}, "keys"));
	cache = keys;
	return mode;
}
async function clearAiKeys() {
	await kv("readwrite", (s) => s.delete("keys"));
	cache = null;
}
/** Giá trị tiêu đề x-ai-keys cho lệnh AI (base64 JSON), hoặc null khi không có key/két khoá. */
async function aiKeysHeader() {
	if (cache === void 0) try {
		await loadAiKeys();
	} catch {
		cache = null;
	}
	if (!cache || !hasAnyKey(cache) && !cache.order && !cache.claudeModel) return null;
	return encodeAiKeys(cache);
}
/** base64(UTF-8 JSON) — máy chủ giải bằng aiKeysOverrides (ai-chain.server.ts). */
function encodeAiKeys(k) {
	const bytes = new TextEncoder().encode(JSON.stringify(cleanKeys(k)));
	let s = "";
	for (const b of bytes) s += String.fromCharCode(b);
	return btoa(s);
}
//#endregion
export { clearAiKeys as a, saveAiKeys as c, cleanKeys as i, CLAUDE_MODELS as n, loadAiKeys as o, ai_keys_exports as r, maskKey as s, AI_PROVIDER_ORDER as t };
