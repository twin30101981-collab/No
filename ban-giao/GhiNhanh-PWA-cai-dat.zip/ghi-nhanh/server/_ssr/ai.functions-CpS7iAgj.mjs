import { r as __exportAll } from "../_runtime.mjs";
import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as createSsrRpc } from "./createSsrRpc-CVjuB6nW.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { t as createMiddleware } from "./createMiddleware-B_4t7rW1.mjs";
import { n as MAX_DATA_CHARS } from "./scan-diagnose-HshWtdyP.mjs";
import { i as stringType, n as enumType, r as objectType, t as arrayType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai.functions-CpS7iAgj.js
var ai_functions_CpS7iAgj_exports = /* @__PURE__ */ __exportAll({
	a: () => aiLayout,
	c: () => aiPhotoCheck,
	d: () => aiScanDiagnose,
	f: () => aiTable,
	i: () => aiKeyCheck,
	l: () => aiProviders,
	m: () => ai_functions_exports,
	n: () => aiDocAsk,
	o: () => aiPaperCorners,
	p: () => aiText,
	r: () => aiExtract,
	s: () => aiPersonGreen,
	t: () => aiClassify,
	u: () => aiReceipt
});
var ai_functions_exports = /* @__PURE__ */ __exportAll$1({
	aiClassify: () => aiClassify,
	aiDocAsk: () => aiDocAsk,
	aiExtract: () => aiExtract,
	aiKeyCheck: () => aiKeyCheck,
	aiLayout: () => aiLayout,
	aiPaperCorners: () => aiPaperCorners,
	aiPersonGreen: () => aiPersonGreen,
	aiPhotoCheck: () => aiPhotoCheck,
	aiProviders: () => aiProviders,
	aiReceipt: () => aiReceipt,
	aiScanDiagnose: () => aiScanDiagnose,
	aiTable: () => aiTable,
	aiText: () => aiText,
	aiTranslateBlocks: () => aiTranslateBlocks
});
var img = stringType().startsWith("data:image/").max(4e6);
/** AI-04: chỉ các lệnh AI gắn tiêu đề x-ai-keys (key người dùng đã lưu mã hoá trên máy); không có key thì không gắn gì. */
var aiKeysMw = createMiddleware({ type: "function" }).client(async ({ next }) => {
	if (typeof window === "undefined") return next();
	const { aiKeysHeader, AI_KEYS_HEADER } = await import("./ai-keys-fpHjq2Jo.mjs").then((n) => n.r);
	const { aiSensitivityHint, AI_SENSITIVE_HEADER } = await import("./ai-sensitivity-GdXzjggN.mjs");
	const h = await aiKeysHeader().catch(() => null), s = aiSensitivityHint();
	const headers = {};
	if (h) headers[AI_KEYS_HEADER] = h;
	if (s !== null) headers[AI_SENSITIVE_HEADER] = s ? "1" : "0";
	return next({ headers });
});
/** AI-01: chạy việc AI trong ngữ cảnh chuỗi nguồn; kết quả thành công kèm `source` (nguồn đã phục vụ: lovable/claude/mistral/gemini). */
var aiExtract = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({
	images: arrayType(img).min(1).max(4),
	template: enumType([
		"vat",
		"xe",
		"sodo"
	]).optional()
}).parse(d)).handler(createSsrRpc("1453a21a4491fc7bec8ad067eb310e9b22376f2bd30a0340c16bfdf1dee2689b"));
var aiText = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({
	task: enumType([
		"translate",
		"summarize",
		"solve",
		"handwrite"
	]),
	text: stringType().max(3e4).optional(),
	images: arrayType(img).max(4).optional(),
	lang: stringType().max(40).optional()
}).refine((v) => v.text?.trim() || v.images?.length, "empty").parse(d)).handler(createSsrRpc("56db84a888ffaeaaab3462275df7b64e74b44521d4436490ac79509b4b855c40"));
createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ images: arrayType(img).min(1).max(4) }).parse(d)).handler(createSsrRpc("8409476496bea21a8699cd409cbee795dd07ebd0d8433c5decd4a798620bf15b"));
/** Bảng từ ảnh gốc: AI đọc từng dòng, cột được ghép bằng toạ độ (columns.ts). */
var aiTable = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ images: arrayType(img).min(1).max(4) }).parse(d)).handler(createSsrRpc("fee9b6c827c57709b7fa5d29bb1e9186399d74aefeb66a06a34263447dde1f67"));
var aiLayout = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ images: arrayType(img).min(1).max(4) }).parse(d)).handler(createSsrRpc("40eea221df3652422361115215091d174916a19c57ecb22f77d6664f33c524c6"));
/** Hỏi đáp với tài liệu (G3-10): nhận chữ các trang, tự chọn đoạn liên quan, trả lời kèm trang. */
var aiDocAsk = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({
	question: stringType().trim().min(1).max(1e3),
	pages: arrayType(stringType().max(5e4)).min(1).max(60)
}).parse(d)).handler(createSsrRpc("280c0f12ccaa87a6526d913e064908c02360938c46115eaad9cbad77b3fe7a2b"));
/** G3-12: AI tự đặt tên & phân loại sau khi quét. */
var aiClassify = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ images: arrayType(img).min(1).max(2) }).parse(d)).handler(createSsrRpc("53a4f104cd1c70577f4c82bb90053dfe68e795719b2f232b2bf3cfbbe723f46a"));
/** G3-14: dịch các khối chữ đã lấy khung từ ảnh. */
var aiTranslateBlocks = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({
	texts: arrayType(stringType().max(4e3)).min(1).max(200),
	lang: stringType().min(1).max(40)
}).parse(d)).handler(createSsrRpc("92c12948b77e36ae0d6df5dfcfbf3ce549377e5dcd880612d491f718bdea9bb7"));
/** G3-16: ảnh người trên nền xanh lục để tách nền ảnh thẻ. */
var aiPersonGreen = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ image: img }).parse(d)).handler(createSsrRpc("6db13cc0879a96b11a9842037feb4ee8580102b2c161116c256fdec3b86b4a87"));
/** G3-18: trích tổng tiền, ngày từ ảnh hoá đơn/biên lai. */
var aiReceipt = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ image: img }).parse(d)).handler(createSsrRpc("0ca6e7554fc3f33aecb540529f35ca3c25c7cc60e65d242a45ec1ee9d3492afb"));
var aiPaperCorners = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ image: img }).parse(d)).handler(createSsrRpc("50d37df7685c56c9fbdeb09183eab242f1002b2926c86996bd696b307e77d0fe"));
/** Chấm độ rõ, ánh sáng, độ chói, góc chụp và gợi ý chụp lại. */
var aiPhotoCheck = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ image: img }).parse(d)).handler(createSsrRpc("d862f1b45ce22fc1327a146114ddb240c9906758a402c31bd89063f3e24b2191"));
/** S12 – chẩn đoán ảnh quét (chỉ gọi khi người dùng bấm); log không chứa nội dung. */
var aiScanDiagnose = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({
	image: stringType().startsWith("data:image/").max(MAX_DATA_CHARS),
	version: stringType().max(200)
}).parse(d)).handler(createSsrRpc("a7c4e12c7d4bceefff8bdb2102e80eefafe878a9712152d19cf39bf8d137fcbe"));
/** AI-04: "Kiểm tra" một nguồn bằng key đã lưu (hoặc key máy chủ) — Sẵn sàng / Key sai / Hết lượt / Lỗi. */
var aiKeyCheck = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ provider: enumType([
	"lovable",
	"claude",
	"mistral",
	"gemini"
]) }).parse(d)).handler(createSsrRpc("3cc5d315fc0705890be69eb9a4146e5e25a5b69a7f7976a6be3c4e4b75a7d087"));
/** AI-02: nguồn AI đã cấu hình (key máy chủ hay key của người dùng), theo thứ tự dùng — không gọi AI, không trả key. */
var aiProviders = createServerFn({ method: "POST" }).middleware([aiKeysMw]).handler(createSsrRpc("b7955cf62ddfdb3b49e42ebc7c3a1fbfc7e7891d9b33db3970e46e6401cad67e"));
//#endregion
export { aiLayout as a, aiPhotoCheck as c, aiScanDiagnose as d, aiTable as f, aiKeyCheck as i, aiProviders as l, ai_functions_CpS7iAgj_exports as m, aiDocAsk as n, aiPaperCorners as o, aiText as p, aiExtract as r, aiPersonGreen as s, aiClassify as t, aiReceipt as u };
