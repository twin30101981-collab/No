import { o as __toESM } from "../_runtime.mjs";
import { w as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { At as FileArchive, Ct as FileText, It as Download, St as FileTypeCorner, V as Pencil, d as TriangleAlert, f as Trash2, nn as ArrowLeft, wt as FileSpreadsheet } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-CZvf2xHx.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { c as download } from "./files-CTF11Arr.mjs";
import { n as confirmDialog } from "./dialog-IcUxZaUZ.mjs";
import { h as useConversions, o as deleteConversions, s as fmtSize } from "./history-ZPjFrOJG.mjs";
import { t as ExportReview } from "./export-review-DWV3zMTm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tools_.history-B1hS4iPe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var when = (t) => new Date(t).toLocaleString("vi-VN", {
	dateStyle: "short",
	timeStyle: "short"
});
function HistoryPage() {
	const items = useConversions();
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [review, setReview] = (0, import_react.useState)(null);
	const kinds = (0, import_react.useMemo)(() => [...new Set((items ?? []).map((c) => c.kind))], [items]);
	const shown = (items ?? []).filter((c) => filter === "all" || c.kind === filter);
	const reopen = (c) => c.review && setReview({
		...c.review,
		source: {
			historyId: c.id,
			kind: c.kind,
			name: c.sourceName
		}
	});
	const remove = async (c) => {
		if (await confirmDialog("Xoá mục này?", {
			okText: "Xoá",
			danger: true
		})) {
			await deleteConversions([c.id]);
			toast("Đã xoá");
		}
	};
	const clearAll = async () => {
		if (items?.length && await confirmDialog(`Xoá toàn bộ ${items.length} mục lịch sử?`, {
			okText: "Xoá hết",
			danger: true
		})) {
			await deleteConversions(items.map((c) => c.id));
			toast("Đã xoá lịch sử");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Lịch sử chuyển đổi",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/tools",
			"aria-label": "Về Công cụ",
			className: "grid size-10 place-items-center rounded-full",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "space-y-3 px-5 pb-28 pt-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						"Giữ ",
						30,
						" lần gần nhất (tối đa 200 MB) trên máy này. Mục cũ tự xoá."
					]
				}),
				kinds.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1 overflow-x-auto",
					children: ["all", ...kinds].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: filter === k ? "default" : "glass",
						onClick: () => setFilter(k),
						children: k === "all" ? "Tất cả" : k
					}, k))
				}),
				items === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Đang tải…"
				}) : !shown.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-10 text-center text-sm text-muted-foreground",
					children: "Chưa có lần chuyển đổi nào. Kết quả sẽ hiện ở đây sau khi bạn bấm Lưu tệp."
				}) : shown.map((c) => {
					const total = c.pages.reduce((n, p) => n + p.unsure.length, 0);
					const Icon = c.outputName.endsWith(".xlsx") ? FileSpreadsheet : c.outputName.endsWith(".zip") ? FileArchive : c.outputName.endsWith(".pdf") ? FileText : FileTypeCorner;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "document-row space-y-2 rounded-[16px] p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "mt-0.5 size-5 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-medium",
										children: c.outputName
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-xs text-muted-foreground",
										children: [
											c.kind,
											" · ",
											c.sourceName,
											" · ",
											when(c.at),
											" · ",
											fmtSize(c.outputBlob.size)
										]
									})]
								})]
							}),
							!!c.details?.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
								className: "text-xs text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
									className: "cursor-pointer",
									children: [
										"Chi tiết (",
										c.details.length,
										")"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-1 list-disc space-y-0.5 pl-4",
									children: c.details.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: d }, i))
								})]
							}),
							c.warnings.map((w, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: w
							}, i)),
							!c.review ? null : total > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex flex-wrap items-center gap-1 text-xs text-warning-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-3.5" }),
									" ",
									total,
									" ô chưa sửa: ",
									c.pages.filter((p) => p.unsure.length).map((p) => `trang ${p.index + 1} (${p.unsure.length})`).join(", ")
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Không còn ô chưa chắc"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										onClick: () => download(c.outputBlob, c.outputName),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), " Tải lại"]
									}),
									c.sourceBlob && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "glass",
										onClick: () => download(c.sourceBlob, c.sourceName),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), " Tệp gốc"]
									}),
									c.review && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "glass",
										onClick: () => reopen(c),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {}), " Sửa"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "glass",
										"aria-label": "Xoá",
										onClick: () => remove(c),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
									})
								]
							})
						]
					}, c.id);
				}),
				!!items?.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					className: "w-full",
					onClick: clearAll,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Xoá toàn bộ lịch sử"]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportReview, {
			review,
			onClose: () => setReview(null)
		})]
	});
}
//#endregion
export { HistoryPage as component };
