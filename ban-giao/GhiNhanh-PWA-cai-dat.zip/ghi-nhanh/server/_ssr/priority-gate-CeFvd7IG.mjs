//#region node_modules/.nitro/vite/services/ssr/assets/priority-gate-CeFvd7IG.js
var scanActive = false;
var idleWaiters = /* @__PURE__ */ new Set();
/** Gọi bởi màn hình chụp: true khi mở, false khi rời. */
function setScanActive(on) {
	if (scanActive === on) return;
	scanActive = on;
	if (!on) {
		idleWaiters.forEach((f) => f());
		idleWaiters.clear();
	}
}
function isScanActive() {
	return scanActive;
}
/** Chờ tới khi màn hình chụp đóng (trả về ngay nếu đã đóng). */
function whenScanIdle() {
	if (!scanActive) return Promise.resolve();
	return new Promise((ok) => idleWaiters.add(ok));
}
/** Đăng ký nghe lúc máy rảnh trở lại (dùng cho hàng đợi AI). */
function onScanIdle(cb) {
	idleWaiters.add(cb);
	return () => idleWaiters.delete(cb);
}
//#endregion
export { whenScanIdle as i, onScanIdle as n, setScanActive as r, isScanActive as t };
