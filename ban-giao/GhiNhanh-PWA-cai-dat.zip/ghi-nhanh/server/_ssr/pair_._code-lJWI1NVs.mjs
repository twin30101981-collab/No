import { o as __toESM } from "../_runtime.mjs";
import { w as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { X as LoaderCircle, Xt as Check, Zt as Camera, ot as ImagePlus, rt as Laptop } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-CZvf2xHx.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { j as normalize } from "./image-DFWRNlNd.mjs";
import { n as pickFiles } from "./importer-BUHDogNt.mjs";
import { c as roomExpired, i as joinRoom, l as split, n as deviceLabel, r as isRoomCode } from "./pair-DrmeGriq.mjs";
import { t as Route } from "./pair_._code-BPp1iwsc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pair_._code-lJWI1NVs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PairPhone() {
	const { code } = Route.useParams();
	const { t } = Route.useSearch();
	const [peers, setPeers] = (0, import_react.useState)([]);
	const chRef = (0, import_react.useRef)(null);
	const acks = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const [sent, setSent] = (0, import_react.useState)([]);
	const [state, setState] = (0, import_react.useState)("checking");
	(0, import_react.useEffect)(() => {
		if (!isRoomCode(code) || roomExpired(t ?? null, Date.now())) {
			setState("bad");
			return;
		}
		setState("joining");
		const r = joinRoom(code, {
			role: "phone",
			device: deviceLabel(navigator.userAgent)
		}, setPeers, (s) => {
			if (s === "SUBSCRIBED") setState("joined");
		}, (ch) => {
			chRef.current = ch;
			ch.on("broadcast", { event: "ack" }, ({ payload }) => {
				const id = payload?.id;
				if (id) acks.current.get(id)?.();
			});
		});
		return () => r.leave();
	}, [code, t]);
	const desktop = peers.some((p) => p.role === "desktop");
	const upd = (id, patch) => setSent((l) => l.map((x) => x.id === id ? {
		...x,
		...patch
	} : x));
	async function sendFiles(capture) {
		const files = await pickFiles("image/*", !capture, capture ? "environment" : void 0);
		for (const f of files) {
			const id = crypto.randomUUID();
			setSent((l) => [...l, {
				id,
				state: "sending",
				pct: 0
			}]);
			try {
				const img = await normalize(f, 2400, .85);
				const parts = split(id, img);
				const acked = new Promise((res) => {
					acks.current.set(id, () => res(true));
					setTimeout(() => res(false), 2e4);
				});
				for (const p of parts) {
					await chRef.current?.send({
						type: "broadcast",
						event: "part",
						payload: p
					});
					upd(id, { pct: (p.i + 1) / p.n });
				}
				upd(id, { state: await acked ? "ok" : "fail" });
			} catch {
				upd(id, { state: "fail" });
			} finally {
				acks.current.delete(id);
			}
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Nối với máy tính",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-md space-y-4 p-6 text-center",
			children: [state === "bad" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: "Mã này đã hết hạn hoặc không đúng."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Trên máy tính, bấm \"Tạo mã mới\" rồi quét lại."
			})] }) : desktop ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "status",
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Laptop, {
						className: "mx-auto h-10 w-10 text-primary",
						"aria-hidden": true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: "Đã nối với máy tính"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Giữ trang này mở. Ảnh bạn chụp sẽ được gửi sang máy tính."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "lg",
							onClick: () => sendFiles(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {
								className: "mr-2 h-5 w-5",
								"aria-hidden": true
							}), "Chụp và gửi"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: () => sendFiles(false),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {
								className: "mr-2 h-4 w-4",
								"aria-hidden": true
							}), "Gửi ảnh có sẵn"]
						})]
					}),
					sent.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1 pt-2 text-left text-sm",
						"aria-live": "polite",
						children: sent.map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2",
							children: [
								x.state === "ok" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									className: "h-4 w-4 text-primary",
									"aria-hidden": true
								}) : x.state === "sending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
									className: "h-4 w-4 animate-spin",
									"aria-hidden": true
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-hidden": true,
									children: "!"
								}),
								"Ảnh ",
								i + 1,
								": ",
								x.state === "ok" ? "đã tới máy tính" : x.state === "sending" ? `đang gửi ${Math.round(x.pct * 100)}%` : "chưa tới — kiểm tra mạng rồi gửi lại"
							]
						}, x.id))
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "status",
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
					className: "mx-auto h-8 w-8 animate-spin text-muted-foreground",
					"aria-hidden": true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: state === "joined" ? "Không thấy máy tính — hãy giữ trang mã QR mở trên máy tính." : "Đang nối…" })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "outline",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: "Về trang chính"
				})
			})]
		})
	});
}
//#endregion
export { PairPhone as component };
