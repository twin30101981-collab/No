import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { c as parseDate } from "./receipt-aj8VqILp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/offline-extract-CYJH6W2G.js
var offline_extract_exports = /* @__PURE__ */ __exportAll({
	LOCAL_CONFIDENCE: () => LOCAL_CONFIDENCE,
	aiUnavailable: () => aiUnavailable,
	extractFromText: () => extractFromText,
	findDate: () => findDate,
	findMerchant: () => findMerchant,
	findTotal: () => findTotal,
	fold: () => fold,
	guessCategory: () => guessCategory,
	guessType: () => guessType,
	receiptFromText: () => receiptFromText
});
/** Độ chắc chắn của kết quả trên máy — dưới ngưỡng xem lại (0.6) để luôn hiện "kiểm tra lại". */
var LOCAL_CONFIDENCE = .4;
/** Bỏ dấu tiếng Việt + chữ thường: OCR hay mất dấu ("TONG CONG"), so khớp trên dạng này. */
function fold(s) {
	return s.normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase();
}
var lines = (text) => text.split(/\r?\n/).map((l) => l.replace(/\s+/g, " ").trim()).filter(Boolean);
/** Số tiền trong một dòng: "1.234.500", "1,234,500", "125 000", "45000" (≥ 4 chữ số khi không có dấu phân nhóm). */
var MONEY_RE = /\d{1,3}(?:[.,\s]\d{3})+(?:,\d{1,2})?(?!\d)|\d{4,}/g;
function amounts(line) {
	const out = [];
	for (const m of line.matchAll(MONEY_RE)) {
		const raw = m[0];
		const digits = raw.replace(/[^\d]/g, "");
		if (/^0\d{8,10}$/.test(digits)) continue;
		if (digits.length > 12) continue;
		const v = Number(raw.replace(/,\d{1,2}$/, "").replace(/[.,\s]/g, ""));
		if (Number.isFinite(v) && v > 0) out.push(v);
	}
	return out;
}
var TOTAL_KEYS = /tong\s*(cong|thanh\s*toan|tien|so\s*tien)|thanh\s*toan|phai\s*tra|can\s*tra|total|amount\s*due|grand/;
var NOT_TOTAL = /khach\s*(dua|tra)|tien\s*mat|tra\s*lai|tien\s*thua|cash|change|chiet\s*khau|giam\s*gia|discount|ma\s*so\s*thue|mst|dien\s*thoai|sdt|tel|so\s*(hoa\s*don|hd)|so\s*tk|tai\s*khoan/;
var NOT_AMOUNT = /ma\s*so\s*thue|mst|dien\s*thoai|sdt|tel|hotline|so\s*(hoa\s*don|hd|tk)|tai\s*khoan|ky\s*hieu|ngay|date|gio|time|\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}/;
/** Tổng tiền: số lớn nhất trên dòng có từ khoá "Tổng cộng/Thanh toán/Total"; không có thì số lớn nhất trong bài (bỏ dòng mã số/điện thoại/ngày). */
function findTotal(text) {
	const ls = lines(text);
	let best = null;
	for (let i = 0; i < ls.length; i++) {
		const f = fold(ls[i]);
		if (!TOTAL_KEYS.test(f) || NOT_TOTAL.test(f)) continue;
		const vs = amounts(ls[i]);
		const cand = vs.length ? vs : ls[i + 1] && !NOT_AMOUNT.test(fold(ls[i + 1])) ? amounts(ls[i + 1]) : [];
		for (const v of cand) if (best === null || v > best) best = v;
	}
	if (best !== null) return best;
	for (const l of ls) {
		if (NOT_AMOUNT.test(fold(l))) continue;
		for (const v of amounts(l)) if (v >= 1e3 && (best === null || v > best)) best = v;
	}
	return best;
}
/** Ngày đầu tiên đọc được: dd/mm/yyyy, yyyy-mm-dd hoặc "ngày 12 tháng 10 năm 2026" → "yyyy-mm-dd"; không có → "". */
function findDate(text) {
	const f = fold(text);
	const c = [];
	const m = f.match(/ngay\s*(\d{1,2})\s*thang\s*(\d{1,2})\s*nam\s*(\d{4})/);
	if (m) {
		const d = parseDate(`${m[1]}/${m[2]}/${m[3]}`);
		if (d) c.push([m.index ?? 0, d]);
	}
	for (const l of lines(text)) {
		const d = parseDate(l);
		if (d) {
			c.push([f.indexOf(fold(l)), d]);
			break;
		}
	}
	c.sort((a, b) => a[0] - b[0]);
	return c[0]?.[1] ?? "";
}
var HEADER_NOISE = /ky\s*hieu|hoa\s*don|bien\s*lai|receipt|invoice|phieu|ma\s*so\s*thue|mst|dia\s*chi|dien\s*thoai|sdt|tel|ngay|date|so\s*:|www\.|http/;
/** Tên cửa hàng: dòng chữ đầu tiên (≥ 3 chữ cái) không phải tiêu đề/mã số/địa chỉ. */
function findMerchant(text) {
	for (const l of lines(text).slice(0, 8)) {
		const f = fold(l);
		if (HEADER_NOISE.test(f)) continue;
		const v = l.includes(":") ? l.slice(l.indexOf(":") + 1).trim() : l;
		if ((v.match(/\p{L}/gu) ?? []).length < 3) continue;
		return v.slice(0, 80);
	}
	return "";
}
var CATEGORY_KEYS = [
	["Ăn uống", /ca\s*phe|coffee|cafe|nha\s*hang|quan\s|pho\b|bun\b|com\b|tra\s*sua|banh|food|restaurant|highlands|starbucks|kfc|lotteria|pizza|bia\b/],
	["Đi lại", /xang|dau\s*diesel|petrolimex|grab|taxi|be\s*group|xanh\s*sm|ve\s*xe|gui\s*xe|bai\s*xe|cau\s*duong|parking|vetc|epass/],
	["Điện nước", /dien\s*luc|evn|tien\s*dien|cap\s*nuoc|tien\s*nuoc|nuoc\s*sach|internet|cuoc\s*vien\s*thong|vnpt|viettel|fpt\s*telecom|truyen\s*hinh/],
	["Y tế", /nha\s*thuoc|hieu\s*thuoc|pharma|benh\s*vien|phong\s*kham|long\s*chau|an\s*khang|y\s*te|thuoc\b/],
	["Giáo dục", /hoc\s*phi|truong\s|nha\s*sach|fahasa|giao\s*duc|khoa\s*hoc|trung\s*tam\s*anh\s*ngu/],
	["Mua sắm", /sieu\s*thi|mart\b|co\.?op|winmart|bach\s*hoa|cua\s*hang|shop|store|tap\s*hoa|lotte|aeon|big\s*c|go!|thoi\s*trang/]
];
function guessCategory(text) {
	const f = fold(text);
	return CATEGORY_KEYS.find(([, re]) => re.test(f))?.[0] ?? "Khác";
}
/** Hoá đơn/biên lai từ chữ OCR — cùng dạng kết quả AI để đi qua normalizeReceipt. */
function receiptFromText(text) {
	const total = findTotal(text);
	const date = findDate(text);
	return {
		merchant: findMerchant(text),
		total: total != null ? String(total) : "",
		date: date ? date.split("-").reverse().join("/") : "",
		category: guessCategory(text),
		confidence: LOCAL_CONFIDENCE
	};
}
var TYPE_KEYS = [
	["CCCD/Hộ chiếu", /can\s*cuoc|cccd|cmnd|chung\s*minh\s*nhan\s*dan|identity\s*card|ho\s*chieu|passport/],
	["Giấy đăng ký xe", /dang\s*ky\s*xe|bien\s*so|so\s*khung|so\s*may/],
	["Sổ đỏ", /quyen\s*su\s*dung\s*dat|thua\s*dat/],
	["Hợp đồng", /hop\s*dong|contract|ben\s*a\b|ben\s*b\b/],
	["Biên bản", /bien\s*ban/],
	["Hoá đơn", /hoa\s*don|invoice|vat|gtgt|tong\s*cong|thanh\s*toan/],
	["Biên lai", /bien\s*lai|receipt|phieu\s*thu/],
	["Sao kê/Chứng từ ngân hàng", /sao\s*ke|so\s*du|ngan\s*hang|giao\s*dich/],
	["Công văn", /cong\s*van|kinh\s*gui|v\/v/],
	["Đơn từ", /don\s*(xin|de\s*nghi)|kinh\s*gui/]
];
function guessType(text) {
	const f = fold(text);
	return TYPE_KEYS.find(([, re]) => re.test(f))?.[0] ?? (text.trim() ? "Ghi chú" : "Khác");
}
var dmy = (iso) => iso ? iso.split("-").reverse().join("/") : "";
var vnd = (n) => n.toLocaleString("vi-VN");
/**
* Trích cơ bản từ chữ OCR: loại tài liệu theo từ khoá, các dòng "Nhãn: giá trị", ngày, tổng tiền, mã số thuế, số CCCD, điện thoại, email.
* `template` (vat/xe/sodo) đặt tên trường theo mẫu để bảng kiểm mẫu dùng được.
*/
function extractFromText(text, template) {
	const type = template === "vat" ? "Hoá đơn" : template === "xe" ? "Giấy đăng ký xe" : template === "sodo" ? "Sổ đỏ" : guessType(text);
	const fields = [];
	const has = (label) => fields.some((f) => fold(f.label) === fold(label));
	const add = (label, value) => {
		const v = value.trim();
		if (v && !has(label) && fields.length < 16) fields.push({
			label,
			value: v.slice(0, 120)
		});
	};
	const f = fold(text);
	const ls = lines(text);
	const date = findDate(text);
	const tax = text.match(/(?:m[ãa]\s*s[ốo]\s*thu[ếe]|MST)\s*[:.]?\s*(\d[\d\s.-]{8,15}\d)/i)?.[1]?.replace(/[\s.]/g, "");
	const total = findTotal(text);
	if (type === "Hoá đơn" || type === "Biên lai") {
		const no = text.match(/s[ốo]\s*(?:h[oó]a\s*đ[ơo]n|hđ)?\s*[:.]\s*(\d{3,10})/i)?.[1];
		if (template === "vat") {
			if (no) add("Số hoá đơn", no);
			add("Ngày", dmy(date));
			add("Bên bán", findMerchant(text));
			if (tax) add("Mã số thuế bên bán", tax);
			if (total != null) add("Tổng thanh toán", vnd(total));
		} else {
			if (total != null) add("Số tiền", vnd(total));
			add("Ngày", dmy(date));
			add("Bên bán", findMerchant(text));
			if (no) add("Số hoá đơn", no);
			if (tax) add("Mã số thuế", tax);
		}
	} else if (type === "CCCD/Hộ chiếu") {
		const id = text.match(/(?<!\d)(\d{12}|\d{9}|[A-Z]\d{7})(?!\d)/)?.[1];
		if (id) add("Số giấy tờ", id);
		const name = ls.findIndex((l) => /ho\s*(va\s*)?ten|full\s*name/.test(fold(l)));
		if (name >= 0) add("Họ tên", ls[name].split(/[:/]/).slice(1).join(" ").replace(/full\s*name/i, "").trim() || ls[name + 1] || "");
		const dob = text.match(/(?:sinh|birth)[^\d]{0,20}(\d{1,2}[/.-]\d{1,2}[/.-]\d{4})/i)?.[1];
		if (dob) add("Ngày sinh", dob);
	} else if (date) add(type === "Hợp đồng" ? "Ngày ký" : "Ngày", dmy(date));
	for (const l of ls) {
		const m = l.match(/^([\p{L}][\p{L}\s/().]{1,32}?)\s*[:：]\s*(.{1,120})$/u);
		if (!m) continue;
		const label = m[1].trim().replace(/\s+/g, " ");
		if (/^(https?|www)$/i.test(label)) continue;
		if (fields.some((x) => fold(x.value) === fold(m[2].trim()))) continue;
		add(label.charAt(0).toUpperCase() + label.slice(1), m[2]);
	}
	if (tax && !fields.some((x) => /thue/.test(fold(x.label)))) add("Mã số thuế", tax);
	const phone = text.match(/(?<!\d)((?:\+84|0)\d{2}[\s.]?\d{3,4}[\s.]?\d{3,4})(?!\d)/)?.[1];
	if (phone && !fields.some((x) => /dien\s*thoai|sdt|tel/.test(fold(x.label)))) add("Điện thoại", phone);
	const email = text.match(/[\w.+-]+@[\w-]+\.[\w.]+/)?.[0];
	if (email && !fields.some((x) => /email/.test(fold(x.label)))) add("Email", email);
	const title = (ls.find((l) => (l.match(/\p{L}/gu) ?? []).length >= 4) ?? type).slice(0, 60);
	const keyPoints = ls.filter((l) => (l.match(/\p{L}/gu) ?? []).length >= 6).slice(0, 4).map((l) => l.slice(0, 120));
	const tags = type !== "Khác" && type !== "Ghi chú" ? [type.split("/")[0]] : [];
	return {
		type,
		title,
		summary: f.trim() ? `Đọc trên máy (không dùng AI): ${type.toLowerCase()}, ${fields.length} trường.` : "",
		keyPoints,
		confidence: LOCAL_CONFIDENCE,
		fields,
		tags
	};
}
/** Lỗi AI nghĩa là "AI không dùng được" (khác ảnh xấu/kết quả rỗng) → nên chạy đường trên máy. */
function aiUnavailable(r) {
	return !r.ok && [
		0,
		401,
		402,
		403,
		408,
		429,
		451,
		500,
		502,
		503,
		504
	].includes(r.code ?? 0);
}
//#endregion
export { offline_extract_exports as n, aiUnavailable as t };
