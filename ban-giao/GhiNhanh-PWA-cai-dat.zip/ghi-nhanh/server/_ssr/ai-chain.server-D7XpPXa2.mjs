import processModule from "node:process";
import { AsyncLocalStorage } from "node:async_hooks";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-chain.server-D7XpPXa2.js
/**
* AI-01 (QD-13): chuỗi nguồn AI dự phòng phía máy chủ — Lovable → Claude → Mistral → Gemini; nguồn nào lỗi/hết lượt/từ chối/quá
* 60 s thì chuyển nguồn kế; hết nguồn thì báo lỗi (client còn đường xử lý trên máy). Thứ tự đổi bằng AI_PROVIDERS; nguồn thiếu key bị bỏ qua.
* AI-05 dùng `sensitive`: giấy tờ nhạy cảm không gửi tới nguồn miễn phí (Mistral/Gemini có thể dùng dữ liệu để huấn luyện).
* Nguồn đã dùng ghi vào ngữ cảnh yêu cầu (AsyncLocalStorage) để trả về client ("ghi nguồn") và ghi nhật ký máy chủ (không chứa nội dung).
*/
var ALL_PROVIDERS = [
	"lovable",
	"claude",
	"mistral",
	"gemini"
];
/** Nguồn gói miễn phí — không nhận giấy tờ nhạy cảm. */
var FREE_PROVIDERS = /* @__PURE__ */ new Set(["mistral", "gemini"]);
var PROVIDER_KEY_ENV = {
	lovable: "LOVABLE_API_KEY",
	claude: "ANTHROPIC_API_KEY",
	mistral: "MISTRAL_API_KEY",
	gemini: "GEMINI_API_KEY"
};
var PROVIDER_LABEL = {
	lovable: "Lovable AI",
	claude: "Claude",
	mistral: "Mistral",
	gemini: "Gemini"
};
var AI_TIMEOUT_MS = 6e4;
var als = new AsyncLocalStorage();
/** Biến môi trường AI của lượt hiện tại: key người dùng (AI-04, tiêu đề x-ai-keys) đè lên biến máy chủ. */
var aiEnv = () => als.getStore()?.env ?? (typeof processModule !== "undefined" ? processModule.env : {});
var envOf = aiEnv;
/** Thứ tự nguồn dùng được: AI_PROVIDERS (danh sách phẩy, bỏ tên lạ/trùng) hoặc mặc định; chỉ nguồn có key; bỏ nguồn miễn phí khi nhạy cảm. */
function providerOrder(opts = {}, env = envOf()) {
	const wanted = (env["AI_PROVIDERS"] ?? "").split(",").map((s) => s.trim().toLowerCase()).filter((s) => ALL_PROVIDERS.includes(s));
	return [...new Set(wanted.length ? wanted : ALL_PROVIDERS)].filter((p) => !!env[PROVIDER_KEY_ENV[p]]?.trim() && !(opts.sensitive && FREE_PROVIDERS.has(p)));
}
var providerKey = (p, env = envOf()) => env[PROVIDER_KEY_ENV[p]]?.trim() ?? "";
/** Mã lỗi HTTP của một lỗi nguồn (SDK: status / statusCode; hết giờ: 408; từ chối: 451). */
function errorCode(e) {
	const x = e ?? {};
	if (x.refusal) return 451;
	if (x.name === "TimeoutError" || x.name === "AbortError" || x.name === "APIConnectionTimeoutError") return 408;
	const inner = x.lastError ?? x;
	return inner.statusCode ?? inner.status ?? x.statusCode ?? x.status ?? 500;
}
/** Chạy `attempt` lần lượt trên từng nguồn tới khi có kết quả. Hết nguồn → ném lỗi có nghĩa đầu tiên (bỏ qua lỗi chung 500/401 khi có lỗi
* cụ thể hơn như hết lượt 402, quá tải 429, từ chối 451, hết giờ 408) để thông báo cho người dùng đúng nguyên nhân. */
async function runChain(task, attempt, opts = {}, env = envOf()) {
	const order = providerOrder({ sensitive: opts.sensitive ?? als.getStore()?.sensitive }, env);
	if (!order.length) throw Object.assign(/* @__PURE__ */ new Error("no provider"), { statusCode: 401 });
	const ctx = als.getStore();
	const errs = [];
	for (const p of order) try {
		const v = await attempt(p);
		if (ctx) ctx.source = p;
		if (errs.length) console.log(`[ai] ${task}: dùng nguồn dự phòng ${p} sau ${errs.length} nguồn lỗi`);
		return v;
	} catch (e) {
		const code = errorCode(e);
		errs.push(e);
		ctx?.tried.push({
			provider: p,
			code
		});
		console.warn(`[ai] ${task}: ${p} lỗi ${code}${p === order[order.length - 1] ? " — hết nguồn" : " → nguồn kế"}`);
	}
	throw errs.find((e) => ![500, 401].includes(errorCode(e))) ?? errs[0];
}
/** Bao một lời gọi AI: trả kết quả kèm nguồn đã phục vụ (và các nguồn đã thử). */
async function withAiSource(fn, overrides, sensitive) {
	const ctx = {
		tried: [],
		sensitive,
		...overrides ? { env: {
			...typeof processModule !== "undefined" ? processModule.env : {},
			...overrides
		} } : {}
	};
	return {
		value: await als.run(ctx, fn),
		source: ctx.source,
		tried: ctx.tried
	};
}
/**
* AI-04: đọc tiêu đề x-ai-keys (base64 JSON do ai-keys.ts tạo) → biến ghi đè cho lượt này. Hỏng/thiếu → null.
* Chỉ nhận chuỗi ngắn; không bao giờ ghi log nội dung.
*/
function aiKeysOverrides(header) {
	if (!header || header.length > 4e3) return null;
	let j;
	try {
		j = JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(header), (c) => c.charCodeAt(0))));
	} catch {
		return null;
	}
	if (!j || typeof j !== "object") return null;
	const s = (v) => typeof v === "string" && v.trim() && v.length <= 400 ? v.trim() : void 0;
	const out = {};
	for (const [k, envName] of Object.entries({
		claude: "ANTHROPIC_API_KEY",
		mistral: "MISTRAL_API_KEY",
		gemini: "GEMINI_API_KEY"
	})) {
		const v = s(j[k]);
		if (v) out[envName] = v;
	}
	const model = s(j["claudeModel"]);
	if (model && /^claude-[a-z0-9-]+$/.test(model)) out["ANTHROPIC_MODEL"] = model;
	if (Array.isArray(j["order"])) {
		const ord = j["order"].filter((p) => typeof p === "string" && ALL_PROVIDERS.includes(p));
		if (ord.length) out["AI_PROVIDERS"] = ord.join(",");
	}
	return Object.keys(out).length ? out : null;
}
//#endregion
export { AI_TIMEOUT_MS, ALL_PROVIDERS, FREE_PROVIDERS, PROVIDER_KEY_ENV, PROVIDER_LABEL, aiEnv, aiKeysOverrides, errorCode, providerKey, providerOrder, runChain, withAiSource };
