import { n as getSettings } from "./settings-DDlMLZCe.mjs";
import { c as download, s as docToPdf, x as safeName } from "./files-CTF11Arr.mjs";
import { c as needsReview } from "./batch-review-Be3azLyj.mjs";
import { d as recordFile } from "./history-ZPjFrOJG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quick-export-Bj-jGh2q.js
/**
* R3.5 – Xuất 1 chạm: PDF mức Chuẩn (balanced), tên tự động theo tên tài liệu,
* nhắc “Còn N trang nên xem lại” khi có trang điểm thấp.
* Luồng Thêm → Xuất chỉ còn 2 thao tác: bấm Xuất, xong.
*/
/** Tên tệp xuất tự động cho tài liệu. */
var quickExportName = (doc) => `${safeName(doc.name)}.pdf`;
/** Số trang cần xem lại (điểm < ngưỡng). Trang chưa đo điểm không tính. */
function reviewCount(reviews) {
	return Object.values(reviews).filter((r) => r && needsReview(r.score)).length;
}
/** Câu nhắc sau khi xuất; null khi không còn trang nào cần xem lại. */
function reviewReminder(reviews) {
	const n = reviewCount(reviews);
	return n > 0 ? `Còn ${n} trang nên xem lại` : null;
}
/** Tuỳ chọn PDF 1 chạm (QD-10): "Chuẩn – khớp ảnh" (khổ theo cài đặt, mặc định khớp ảnh), không hình mờ/mật khẩu. */
function quickExportOpts() {
	return {
		paper: getSettings().pdfPage ?? "fit",
		size: "balanced"
	};
}
/** Xuất 1 chạm: dựng PDF Chuẩn, tải về với tên tự động, ghi lịch sử. Trả về số trang cần xem lại. */
async function quickExportPdf(doc, reviews = {}) {
	const blob = await docToPdf(doc, quickExportOpts());
	const name = quickExportName(doc);
	download(blob, name);
	await recordFile({
		kind: "Xuất 1 chạm → PDF",
		sourceName: doc.name,
		outputBlob: blob,
		outputName: name,
		details: [`${doc.pages.length} trang`]
	}).catch((e) => console.error("history", e));
	return reviewCount(reviews);
}
//#endregion
export { quickExportPdf, reviewReminder };
