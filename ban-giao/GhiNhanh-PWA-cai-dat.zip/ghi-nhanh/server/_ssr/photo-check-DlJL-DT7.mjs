import { o as __toESM } from "../_runtime.mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as aiPhotoCheck } from "./ai.functions-CpS7iAgj.mjs";
import { i as showError } from "./errors-DKvrPJ4v.mjs";
import { F as RectangleHorizontal, X as LoaderCircle, Zt as Camera, et as Lightbulb, g as Sun, ot as ImagePlus, x as Sparkle, xt as Focus } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-CZvf2xHx.mjs";
import { i as useQueuedServerFn } from "./ai-queue-DZjZmUCT.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { j as normalize } from "./image-DFWRNlNd.mjs";
import { n as pickFiles } from "./importer-BUHDogNt.mjs";
import { t as Progress } from "./progress-DOIEKRJF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/photo-check-DlJL-DT7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ROWS = [
	{
		k: "sharpness",
		label: "Độ rõ nét",
		icon: Focus
	},
	{
		k: "lighting",
		label: "Ánh sáng",
		icon: Sun
	},
	{
		k: "glare",
		label: "Độ chói (ít loá)",
		icon: Sparkle
	},
	{
		k: "angle",
		label: "Góc chụp",
		icon: RectangleHorizontal
	}
];
var clamp10 = (n) => Math.max(0, Math.min(10, Math.round(n * 10) / 10));
var tone = (s) => s >= 7.5 ? "text-primary" : s >= 5 ? "text-foreground" : "text-destructive";
function PhotoCheckPage() {
	const fn = useQueuedServerFn(aiPhotoCheck, "Đánh giá ảnh chụp");
	const [src, setSrc] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [res, setRes] = (0, import_react.useState)(null);
	const take = async (capture) => {
		const [f] = await pickFiles("image/*", false, capture);
		if (!f) return;
		setBusy(true);
		setRes(null);
		try {
			const img = await normalize(f, 1600, .85);
			setSrc(img);
			const r = await fn({ data: { image: img } });
			if (!r.ok) throw new Error(r.message);
			setRes(r.data);
		} catch (e) {
			showError(e, "Không đánh giá được ảnh này");
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Đánh giá ảnh chụp",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 px-4 pb-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Tải ảnh tài liệu lên, AI sẽ chấm độ rõ, ánh sáng, độ chói, góc chụp và gợi ý cách chụp lại."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						disabled: busy,
						onClick: () => take("environment"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {}), " Chụp ảnh"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "glass",
						disabled: busy,
						onClick: () => take(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {}), " Chọn ảnh"]
					})]
				}),
				src && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src,
					alt: "Ảnh đang đánh giá",
					className: "max-h-72 w-full rounded-xl border object-contain"
				}),
				busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-2 text-sm text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), " AI đang xem ảnh…"]
				}),
				res && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-4 rounded-2xl border bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-lg font-semibold",
								children: "Tổng điểm"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `font-display text-3xl font-bold ${tone(res.overall)}`,
								children: [clamp10(res.overall), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-base text-muted-foreground",
									children: "/10"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: res.verdict
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-3",
							children: ROWS.map(({ k, label, icon: Icon }) => {
								const c = res[k];
								const s = clamp10(c.score);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-sm font-medium",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }),
													" ",
													label
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: tone(s),
												children: [s, "/10"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: s * 10 }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: c.note
										})
									]
								}, k);
							})
						}),
						res.tips.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-muted p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "mb-2 flex items-center gap-2 text-sm font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, { className: "size-4" }), " Cách chụp lại tốt hơn"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "list-decimal space-y-1 pl-5 text-sm",
								children: res.tips.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t }, i))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "glass",
							className: "w-full",
							disabled: busy,
							onClick: () => take("environment"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {}), " Chụp lại"]
						})
					]
				})
			]
		})
	});
}
//#endregion
export { PhotoCheckPage as component };
