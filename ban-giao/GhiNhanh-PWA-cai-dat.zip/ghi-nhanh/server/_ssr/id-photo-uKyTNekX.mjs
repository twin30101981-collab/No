import { o as __toESM } from "../_runtime.mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { s as aiPersonGreen } from "./ai.functions-CpS7iAgj.mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { i as showError } from "./errors-DKvrPJ4v.mjs";
import { It as Download, R as Printer, X as LoaderCircle, ot as ImagePlus } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-CZvf2xHx.mjs";
import { i as useQueuedServerFn } from "./ai-queue-DZjZmUCT.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { j as normalize } from "./image-DFWRNlNd.mjs";
import { c as download, o as dataUrlToBlob } from "./files-CTF11Arr.mjs";
import { n as pickFiles } from "./importer-BUHDogNt.mjs";
import { t as Slider } from "./slider-BjtFJp27.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/id-photo-uKyTNekX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Độ "xanh lục nền" của một điểm: 0 = không phải nền, 1 = chắc chắn nền. */
function greenness(r, g, b) {
	const d = g - Math.max(r, b);
	if (d <= 30) return 0;
	if (d >= 90) return 1;
	return (d - 30) / 60;
}
/** Khoá màu xanh: trả mặt nạ alpha (255 = người) và khử ánh xanh ở mép ngay trên rgba. */
function greenKeyMask(rgba, w, h) {
	const a = new Uint8ClampedArray(w * h);
	for (let i = 0, p = 0; i < a.length; i++, p += 4) {
		const r = rgba[p], g = rgba[p + 1], b = rgba[p + 2];
		const k = greenness(r, g, b);
		a[i] = Math.round((1 - k) * 255);
		const cap = Math.max(r, b);
		if (g > cap) rgba[p + 1] = cap;
	}
	return keepLargest({
		w,
		h,
		a
	});
}
/** Chỉ giữ vùng người lớn nhất (bỏ đốm nhiễu rời rạc). */
function keepLargest(m, thr = 128) {
	const { w, h, a } = m;
	const lab = new Int32Array(w * h);
	let best = 0, bestSize = 0, cur = 0;
	const stack = [];
	for (let s = 0; s < a.length; s++) {
		if (a[s] < thr || lab[s]) continue;
		cur++;
		let size = 0;
		stack.push(s);
		lab[s] = cur;
		while (stack.length) {
			const i = stack.pop();
			size++;
			const x = i % w, y = i / w | 0;
			const nb = [
				x > 0 ? i - 1 : -1,
				x < w - 1 ? i + 1 : -1,
				y > 0 ? i - w : -1,
				y < h - 1 ? i + w : -1
			];
			for (const n of nb) if (n >= 0 && !lab[n] && a[n] >= thr) {
				lab[n] = cur;
				stack.push(n);
			}
		}
		if (size > bestSize) {
			bestSize = size;
			best = cur;
		}
	}
	if (!best) return m;
	for (let i = 0; i < a.length; i++) if (a[i] >= thr && lab[i] !== best) a[i] = 0;
	return m;
}
/** Màu nền ước lượng từ viền ảnh (trung vị từng kênh). */
function borderColor(rgba, w, h) {
	const ch = [
		[],
		[],
		[]
	];
	const push = (x, y) => {
		const p = (y * w + x) * 4;
		for (let c = 0; c < 3; c++) ch[c].push(rgba[p + c]);
	};
	for (let x = 0; x < w; x++) push(x, 0);
	for (let y = 1; y < h; y++) {
		push(0, y);
		push(w - 1, y);
	}
	const med = (v) => {
		v.sort((a, b) => a - b);
		return v[v.length >> 1] ?? 0;
	};
	return [
		med(ch[0]),
		med(ch[1]),
		med(ch[2])
	];
}
/** Dự phòng không cần AI: loang từ viền trên/trái/phải qua các điểm giống màu nền. Hợp với nền tường phẳng. */
function floodMask(rgba, w, h, tol = 38) {
	const [br, bg, bb] = borderColor(rgba, w, h);
	const bgSet = new Uint8Array(w * h);
	const near = (i) => {
		const p = i * 4, dr = rgba[p] - br, dg = rgba[p + 1] - bg, db = rgba[p + 2] - bb;
		return Math.sqrt(dr * dr + dg * dg + db * db) <= tol;
	};
	const stack = [];
	const seed = (i) => {
		if (!bgSet[i] && near(i)) {
			bgSet[i] = 1;
			stack.push(i);
		}
	};
	for (let x = 0; x < w; x++) seed(x);
	for (let y = 0; y < h; y++) {
		seed(y * w);
		seed(y * w + w - 1);
	}
	while (stack.length) {
		const i = stack.pop();
		const x = i % w, y = i / w | 0;
		if (x > 0) seed(i - 1);
		if (x < w - 1) seed(i + 1);
		if (y > 0) seed(i - w);
		if (y < h - 1) seed(i + w);
	}
	const a = new Uint8ClampedArray(w * h);
	for (let i = 0; i < a.length; i++) a[i] = bgSet[i] ? 0 : 255;
	return keepLargest(featherMask({
		w,
		h,
		a
	}));
}
/** Làm mềm mép 1 px (trung bình 3x3) để viền không răng cưa. */
function featherMask(m) {
	const { w, h, a } = m;
	const out = new Uint8ClampedArray(a.length);
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		let s = 0, n = 0;
		for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
			const xx = x + dx, yy = y + dy;
			if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
			s += a[yy * w + xx];
			n++;
		}
		out[y * w + x] = Math.round(s / n);
	}
	return {
		w,
		h,
		a: out
	};
}
/** Tỉ lệ diện tích người; dùng để loại kết quả AI hỏng (gần như toàn nền hoặc toàn người). */
function coverage(m) {
	let s = 0;
	for (let i = 0; i < m.a.length; i++) s += m.a[i];
	return s / (255 * m.a.length);
}
async function pixels(src, max) {
	const { loadImg } = await import("./image-DFWRNlNd.mjs").then((n) => n.D).then((n) => n.f);
	const img = await loadImg(src);
	const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
	const w = Math.round(img.naturalWidth * k), h = Math.round(img.naturalHeight * k);
	const c = document.createElement("canvas");
	c.width = w;
	c.height = h;
	const ctx = c.getContext("2d");
	ctx.drawImage(img, 0, 0, w, h);
	return {
		c,
		ctx,
		data: ctx.getImageData(0, 0, w, h),
		w,
		h
	};
}
/** Ảnh gốc + mặt nạ → PNG nền trong suốt (màu lấy từ ảnh gốc, chỉ alpha từ mặt nạ). */
function compose(base, m, ctx, despill) {
	const d = base.data;
	for (let i = 0, p = 0; i < m.a.length; i++, p += 4) {
		if (despill && m.a[i] < 250) {
			d[p] = despill[p];
			d[p + 1] = despill[p + 1];
			d[p + 2] = despill[p + 2];
		}
		d[p + 3] = m.a[i];
	}
	ctx.putImageData(base, 0, 0);
}
/**
* Tách nền người. `ai` nhận ảnh JPEG, trả ảnh nền xanh lục (hoặc ném lỗi) — tiêm vào để test/hàng đợi.
* AI lỗi hoặc kết quả bất thường → dùng loang màu viền.
*/
async function cutoutPerson(src, ai, max = 1200) {
	const base = await pixels(src, max);
	if (ai) try {
		const g = await pixels(await ai(base.c.toDataURL("image/jpeg", .9)), max);
		let gd = g.data;
		if (g.w !== base.w || g.h !== base.h) {
			const c = document.createElement("canvas");
			c.width = base.w;
			c.height = base.h;
			const x = c.getContext("2d");
			x.drawImage(g.c, 0, 0, base.w, base.h);
			gd = x.getImageData(0, 0, base.w, base.h);
		}
		const m = greenKeyMask(gd.data, base.w, base.h);
		const cov = coverage(m);
		if (cov > .05 && cov < .95) {
			compose(base.data, m, base.ctx, gd.data);
			return {
				png: base.c.toDataURL("image/png"),
				w: base.w,
				h: base.h,
				via: "ai"
			};
		}
	} catch (e) {
		console.warn("cutoutPerson: AI lỗi, dùng dự phòng", e);
	}
	const m = floodMask(base.data.data, base.w, base.h);
	compose(base.data, m, base.ctx);
	return {
		png: base.c.toDataURL("image/png"),
		w: base.w,
		h: base.h,
		via: "local"
	};
}
var PHOTO_SIZES = [
	{
		id: "3x4",
		label: "3×4 cm",
		wMm: 30,
		hMm: 40
	},
	{
		id: "4x6",
		label: "4×6 cm",
		wMm: 40,
		hMm: 60
	},
	{
		id: "2x3",
		label: "2×3 cm",
		wMm: 20,
		hMm: 30
	},
	{
		id: "35x45",
		label: "3,5×4,5 (hộ chiếu)",
		wMm: 35,
		hMm: 45
	}
];
var SHEETS = [
	{
		id: "10x15",
		label: "Ảnh 10×15",
		wMm: 100,
		hMm: 150
	},
	{
		id: "13x18",
		label: "Ảnh 13×18",
		wMm: 130,
		hMm: 180
	},
	{
		id: "a4",
		label: "Giấy A4",
		wMm: 210,
		hMm: 297
	}
];
var BACKGROUNDS = [
	{
		id: "white",
		label: "Trắng",
		color: "#ffffff"
	},
	{
		id: "blue",
		label: "Xanh",
		color: "#2f6fd6"
	},
	{
		id: "lightblue",
		label: "Xanh nhạt",
		color: "#bcd8f2"
	},
	{
		id: "gray",
		label: "Xám",
		color: "#d9d9d9"
	}
];
var mmToPx = (mm, dpi = 300) => Math.round(mm / 25.4 * dpi);
/** Khung người (alpha ≥ thr) trong mặt nạ; null nếu trống. */
function personBox(a, w, h, thr = 128) {
	let x0 = w, y0 = h, x1 = -1, y1 = -1;
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (a[y * w + x] >= thr) {
		if (x < x0) x0 = x;
		if (x > x1) x1 = x;
		if (y < y0) y0 = y;
		if (y > y1) y1 = y;
	}
	return x1 < 0 ? null : {
		x: x0,
		y: y0,
		w: x1 - x0 + 1,
		h: y1 - y0 + 1
	};
}
/**
* Vùng cắt theo tỉ lệ ảnh thẻ: đầu chiếm khoảng 70% chiều cao khung, chừa ~10% phía trên đầu.
* Ước lượng đầu = phần trên 45% chiều cao người (ảnh chân dung tới vai/ngực).
* Vùng có thể vượt ra ngoài ảnh — phần đó được tô màu nền.
*/
function cropForSize(person, size, zoom = 1) {
	const ratio = size.wMm / size.hMm;
	const h = Math.min(person.h * .45, person.w * .75) / .55 / zoom;
	const w = h * ratio;
	const cx = person.x + person.w / 2;
	const y = person.y - h * .1;
	return {
		x: cx - w / 2,
		y,
		w,
		h
	};
}
/** Xếp lưới ảnh lên khổ in, chừa lề và khe cắt. */
function tileLayout(sheet, size, marginMm = 4, gapMm = 2) {
	const fit = (total, item) => Math.max(0, Math.floor((total - 2 * marginMm + gapMm) / (item + gapMm)));
	const tryFit = (rot) => {
		const pw = rot ? size.hMm : size.wMm, ph = rot ? size.wMm : size.hMm;
		return {
			cols: fit(sheet.wMm, pw),
			rows: fit(sheet.hMm, ph),
			pw,
			ph,
			rot
		};
	};
	const a = tryFit(false);
	const cells = [];
	const usedW = a.cols * a.pw + (a.cols - 1) * gapMm, usedH = a.rows * a.ph + (a.rows - 1) * gapMm;
	const ox = (sheet.wMm - usedW) / 2, oy = (sheet.hMm - usedH) / 2;
	for (let r = 0; r < a.rows; r++) for (let c = 0; c < a.cols; c++) cells.push({
		x: ox + c * (a.pw + gapMm),
		y: oy + r * (a.ph + gapMm),
		w: a.pw,
		h: a.ph
	});
	return {
		cols: a.cols,
		rows: a.rows,
		count: cells.length,
		cells
	};
}
async function load(src) {
	const { loadImg } = await import("./image-DFWRNlNd.mjs").then((n) => n.D).then((n) => n.f);
	return loadImg(src);
}
/** Ảnh người nền trong suốt → ảnh thẻ đúng cỡ (300 dpi) trên nền màu. */
async function renderIdPhoto(cutoutPng, size, bg, zoom = 1, offsetY = 0) {
	const img = await load(cutoutPng);
	const sw = img.naturalWidth, sh = img.naturalHeight;
	const tmp = document.createElement("canvas");
	tmp.width = sw;
	tmp.height = sh;
	const tctx = tmp.getContext("2d");
	tctx.drawImage(img, 0, 0);
	const d = tctx.getImageData(0, 0, sw, sh).data;
	const alpha = new Uint8ClampedArray(sw * sh);
	for (let i = 0; i < alpha.length; i++) alpha[i] = d[i * 4 + 3];
	const crop = cropForSize(personBox(alpha, sw, sh) ?? {
		x: 0,
		y: 0,
		w: sw,
		h: sh
	}, size, zoom);
	crop.y += offsetY * crop.h;
	const W = mmToPx(size.wMm), H = mmToPx(size.hMm);
	const c = document.createElement("canvas");
	c.width = W;
	c.height = H;
	const ctx = c.getContext("2d");
	ctx.fillStyle = bg;
	ctx.fillRect(0, 0, W, H);
	ctx.imageSmoothingQuality = "high";
	const k = W / crop.w;
	ctx.drawImage(img, -crop.x * k, -crop.y * k, sw * k, sh * k);
	return c.toDataURL("image/jpeg", .95);
}
/** Xếp nhiều bản ảnh thẻ lên khổ in, có đường cắt mảnh. */
async function renderSheet(photo, sheet, size) {
	const img = await load(photo);
	const lay = tileLayout(sheet, size);
	const c = document.createElement("canvas");
	c.width = mmToPx(sheet.wMm);
	c.height = mmToPx(sheet.hMm);
	const ctx = c.getContext("2d");
	ctx.fillStyle = "#ffffff";
	ctx.fillRect(0, 0, c.width, c.height);
	ctx.strokeStyle = "#bbbbbb";
	ctx.lineWidth = 1;
	for (const b of lay.cells) {
		const x = mmToPx(b.x), y = mmToPx(b.y), w = mmToPx(b.w), h = mmToPx(b.h);
		ctx.drawImage(img, x, y, w, h);
		ctx.strokeRect(x - .5, y - .5, w + 1, h + 1);
	}
	return {
		jpeg: c.toDataURL("image/jpeg", .95),
		count: lay.count
	};
}
function Chip({ on, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		size: "sm",
		variant: on ? "default" : "outline",
		onClick,
		children
	});
}
function IdPhoto() {
	const aiFn = useQueuedServerFn(aiPersonGreen, "Tách nền ảnh thẻ");
	const [cut, setCut] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [sizeId, setSizeId] = (0, import_react.useState)("3x4");
	const [sheetId, setSheetId] = (0, import_react.useState)("10x15");
	const [bg, setBg] = (0, import_react.useState)(BACKGROUNDS[0].color);
	const [zoom, setZoom] = (0, import_react.useState)(1);
	const [shift, setShift] = (0, import_react.useState)(0);
	const [photo, setPhoto] = (0, import_react.useState)("");
	const size = PHOTO_SIZES.find((s) => s.id === sizeId);
	const sheet = SHEETS.find((s) => s.id === sheetId);
	const pick = async () => {
		const [f] = await pickFiles("image/*", false);
		if (!f) return;
		setBusy(true);
		try {
			const r = await cutoutPerson(await normalize(f), typeof navigator !== "undefined" && navigator.onLine === false ? void 0 : async (jpeg) => {
				const res = await aiFn({ data: { image: jpeg } });
				if (!res.ok) throw new Error(res.message);
				return res.image;
			});
			setCut(r);
			if (r.via === "local") toast("Đã tách nền không dùng AI — hợp với ảnh chụp trên nền tường phẳng.");
		} catch (e) {
			showError(e, "Không tách được nền ảnh này");
		} finally {
			setBusy(false);
		}
	};
	(0, import_react.useEffect)(() => {
		if (!cut) return;
		let alive = true;
		renderIdPhoto(cut.png, size, bg, zoom, shift).then((p) => alive && setPhoto(p)).catch((e) => showError(e, "Không dựng được ảnh thẻ"));
		return () => {
			alive = false;
		};
	}, [
		cut,
		size,
		bg,
		zoom,
		shift
	]);
	const saveSheet = async (pdf) => {
		if (!photo) return;
		const r = await renderSheet(photo, sheet, size);
		if (pdf) {
			const { jsPDF } = await import("../_libs/jspdf.mjs").then((n) => n.t);
			const doc = new jsPDF({
				unit: "mm",
				format: [sheet.wMm, sheet.hMm]
			});
			doc.addImage(r.jpeg, "JPEG", 0, 0, sheet.wMm, sheet.hMm);
			download(doc.output("blob"), `anh-the-${size.id}-${sheet.id}.pdf`);
		} else download(await dataUrlToBlob(r.jpeg), `anh-the-${size.id}-${sheet.id}.jpg`);
		toast.success(`Đã lưu khổ in ${r.count} ảnh`);
	};
	const count = tileLayout(sheet, size).count;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Ảnh thẻ",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-xl space-y-5 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					className: "w-full",
					onClick: pick,
					disabled: busy,
					children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "mr-2 h-4 w-4" }), busy ? "Đang tách nền…" : cut ? "Chọn ảnh khác" : "Chọn ảnh chân dung"]
				}),
				photo && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: photo,
						alt: "Ảnh thẻ xem trước",
						className: "max-h-72 rounded-md border border-border shadow-sm"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium text-muted-foreground",
						children: "Cỡ ảnh"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: PHOTO_SIZES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							on: s.id === sizeId,
							onClick: () => setSizeId(s.id),
							children: s.label
						}, s.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium text-muted-foreground",
						children: "Màu nền"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: BACKGROUNDS.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setBg(b.color),
							"aria-label": b.label,
							title: b.label,
							className: `h-10 w-10 rounded-full border-2 ${bg === b.color ? "border-primary" : "border-border"}`,
							style: { background: b.color }
						}, b.id))
					})]
				}),
				cut && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium text-muted-foreground",
							children: "Phóng to / dời lên xuống"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: .7,
							max: 1.5,
							step: .01,
							value: [zoom],
							onValueChange: ([v]) => setZoom(v),
							"aria-label": "Phóng to"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: -.2,
							max: .2,
							step: .01,
							value: [shift],
							onValueChange: ([v]) => setShift(v),
							"aria-label": "Dời lên xuống"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "text-sm font-medium text-muted-foreground",
						children: [
							"Khổ in (",
							count,
							" ảnh)"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: SHEETS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							on: s.id === sheetId,
							onClick: () => setSheetId(s.id),
							children: s.label
						}, s.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							disabled: !photo,
							onClick: async () => photo && download(await dataUrlToBlob(photo), `anh-the-${size.id}.jpg`),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "mr-1 h-4 w-4" }), "Ảnh lẻ"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							disabled: !photo,
							onClick: () => saveSheet(false).catch((e) => showError(e, "Không lưu được")),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "mr-1 h-4 w-4" }), "Khổ in JPG"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							disabled: !photo,
							onClick: () => saveSheet(true).catch((e) => showError(e, "Không lưu được")),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "mr-1 h-4 w-4" }), "Khổ in PDF"]
						})
					]
				})
			]
		})
	});
}
//#endregion
export { IdPhoto as component };
