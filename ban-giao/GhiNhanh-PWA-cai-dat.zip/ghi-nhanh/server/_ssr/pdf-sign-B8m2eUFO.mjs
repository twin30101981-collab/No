import { o as __toESM } from "../_runtime.mjs";
import { t as require_lib } from "../_libs/node-forge.mjs";
import { a as PDFName, i as PDFHexString, n as PDFDocument, o as PDFArray, r as PDFString, s as PDFNumber } from "../_libs/pdf-lib+tslib.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pdf-sign-B8m2eUFO.js
var import_lib = /* @__PURE__ */ __toESM(require_lib());
/**
* p12.ts — tạo và nhập chứng thư số PKCS#12 (.p12/.pfx) để ký PDF.
* Dùng node-forge (thuần JS, chạy được trên trình duyệt, không cần server).
* Chứng thư tự ký phục vụ ký số nội bộ; khóa riêng chỉ nằm trong bộ nhớ
* và trong tệp .p12 người dùng tự giữ — không gửi đi đâu.
*/
function fieldText(field) {
	const f = field;
	if (!f || typeof f.value !== "string") return "";
	if (f.valueTagClass === import_lib.default.asn1.Type.UTF8) try {
		return import_lib.default.util.decodeUtf8(f.value);
	} catch {
		return f.value;
	}
	if (f.valueTagClass === import_lib.default.asn1.Type.BMPSTRING) {
		let out = "";
		for (let i = 0; i + 1 < f.value.length; i += 2) out += String.fromCharCode(f.value.charCodeAt(i) << 8 | f.value.charCodeAt(i + 1));
		return out;
	}
	return f.value;
}
/** Chuỗi JS → byte UTF-16BE (dạng chuỗi nhị phân của forge) cho BMPString (friendlyName của .p12). */
function toBmp(s) {
	let out = "";
	for (let i = 0; i < s.length; i++) {
		const c = s.charCodeAt(i);
		out += String.fromCharCode(c >> 8, c & 255);
	}
	return out;
}
function certInfo(cert) {
	const get = (name) => fieldText(cert.subject.getField(name));
	const md = import_lib.default.md.sha256.create();
	md.update(import_lib.default.asn1.toDer(import_lib.default.pki.certificateToAsn1(cert)).getBytes());
	return {
		commonName: get("CN"),
		organization: get("O"),
		email: get("E"),
		serialNumber: cert.serialNumber,
		notBefore: cert.validity.notBefore,
		notAfter: cert.validity.notAfter,
		sha256Fingerprint: md.digest().toHex()
	};
}
/** Tạo cặp khóa RSA-2048 + chứng thư tự ký, đóng gói thành .p12. */
function createP12(opts) {
	if (!opts.password || opts.password.length < 6) throw new Error("Mật khẩu chứng thư cần ít nhất 6 ký tự.");
	if (!opts.commonName.trim()) throw new Error("Cần nhập tên chủ thể.");
	const keys = import_lib.default.pki.rsa.generateKeyPair(2048);
	const cert = import_lib.default.pki.createCertificate();
	cert.publicKey = keys.publicKey;
	const sn = import_lib.default.random.getBytesSync(16);
	cert.serialNumber = import_lib.default.util.bytesToHex(String.fromCharCode(sn.charCodeAt(0) & 127 | 64) + sn.slice(1));
	cert.validity.notBefore = /* @__PURE__ */ new Date();
	cert.validity.notAfter = /* @__PURE__ */ new Date();
	cert.validity.notAfter.setDate(cert.validity.notAfter.getDate() + (opts.days ?? 825));
	const attrs = [{
		name: "commonName",
		value: opts.commonName.trim(),
		valueTagClass: import_lib.default.asn1.Type.UTF8
	}];
	if (opts.organization?.trim()) attrs.push({
		name: "organizationName",
		value: opts.organization.trim(),
		valueTagClass: import_lib.default.asn1.Type.UTF8
	});
	if (opts.email?.trim()) attrs.push({
		name: "emailAddress",
		value: opts.email.trim(),
		valueTagClass: import_lib.default.asn1.Type.IA5STRING
	});
	cert.setSubject(attrs);
	cert.setIssuer(attrs);
	cert.setExtensions([
		{
			name: "basicConstraints",
			cA: false
		},
		{
			name: "keyUsage",
			digitalSignature: true,
			nonRepudiation: true
		},
		{
			name: "extKeyUsage",
			emailProtection: true
		}
	]);
	cert.sign(keys.privateKey, import_lib.default.md.sha256.create());
	const p12Asn1 = import_lib.default.pkcs12.toPkcs12Asn1(keys.privateKey, [cert], opts.password, {
		algorithm: "3des",
		friendlyName: toBmp(opts.commonName.trim())
	});
	const der = import_lib.default.asn1.toDer(p12Asn1).getBytes();
	const p12Bytes = new Uint8Array(der.length);
	for (let i = 0; i < der.length; i++) p12Bytes[i] = der.charCodeAt(i);
	return {
		p12Bytes,
		info: certInfo(cert)
	};
}
/** Mở tệp .p12 bằng mật khẩu, lấy chứng thư + khóa riêng. */
function importP12(p12Bytes, password) {
	let der = "";
	for (let i = 0; i < p12Bytes.length; i++) der += String.fromCharCode(p12Bytes[i]);
	let p12;
	try {
		p12 = import_lib.default.pkcs12.pkcs12FromAsn1(import_lib.default.asn1.fromDer(der), password);
	} catch {
		throw new Error("Không mở được tệp chứng thư — sai mật khẩu hoặc tệp hỏng.");
	}
	const certBags = p12.getBags({ bagType: import_lib.default.pki.oids["certBag"] });
	const keyBags = p12.getBags({ bagType: import_lib.default.pki.oids["pkcs8ShroudedKeyBag"] });
	const cert = certBags[import_lib.default.pki.oids["certBag"]]?.[0]?.cert;
	const key = keyBags[import_lib.default.pki.oids["pkcs8ShroudedKeyBag"]]?.[0]?.key;
	if (!cert || !key) throw new Error("Tệp chứng thư thiếu chứng thư hoặc khóa riêng.");
	return {
		info: certInfo(cert),
		privateKeyPem: import_lib.default.pki.privateKeyToPem(key),
		certPem: import_lib.default.pki.certificateToPem(cert)
	};
}
/** Kiểm tra chứng thư còn hạn tại thời điểm cho trước. */
function isCertValid(info, at = /* @__PURE__ */ new Date()) {
	return at >= info.notBefore && at <= info.notAfter;
}
/**
* pdf-sign.ts — nhúng chữ ký số PKCS#7 (adbe.pkcs7.detached) vào PDF.
* Dùng pdf-lib dựng ô chữ ký + chỗ trống, node-forge ký SHA-256 bằng khóa từ .p12.
* Chạy hoàn toàn trên máy; khóa riêng không rời bộ nhớ.
*/
var SIG_BYTES = 8192;
var BR_PLACEHOLDER = 9999999999;
var latin1 = (b) => new TextDecoder("latin1").decode(b);
function toBinary(b) {
	let s = "";
	for (let i = 0; i < b.length; i += 32768) s += String.fromCharCode.apply(null, Array.from(b.subarray(i, i + 32768)));
	return s;
}
async function signPdf(pdf, key, opts = {}) {
	const doc = await PDFDocument.load(pdf, { ignoreEncryption: false });
	const ctx = doc.context;
	const date = opts.date ?? /* @__PURE__ */ new Date();
	const byteRange = PDFArray.withContext(ctx);
	byteRange.push(PDFNumber.of(0));
	for (let i = 0; i < 3; i++) byteRange.push(PDFNumber.of(BR_PLACEHOLDER));
	const sig = ctx.obj({
		Type: "Sig",
		Filter: "Adobe.PPKLite",
		SubFilter: "adbe.pkcs7.detached",
		ByteRange: byteRange,
		Contents: PDFHexString.of("0".repeat(SIG_BYTES * 2)),
		Reason: PDFHexString.fromText(opts.reason ?? "Ký số"),
		Location: PDFHexString.fromText(opts.location ?? ""),
		Name: PDFHexString.fromText(opts.name ?? key.info.commonName),
		M: PDFString.fromDate(date)
	});
	const sigRef = ctx.register(sig);
	const page = doc.getPage(0);
	const widget = ctx.obj({
		Type: "Annot",
		Subtype: "Widget",
		FT: "Sig",
		Rect: [
			0,
			0,
			0,
			0
		],
		V: sigRef,
		T: PDFString.of(`Signature${Date.now()}`),
		F: 132,
		P: page.ref
	});
	const widgetRef = ctx.register(widget);
	let annots = page.node.lookup(PDFName.of("Annots"));
	if (!(annots instanceof PDFArray)) {
		annots = PDFArray.withContext(ctx);
		page.node.set(PDFName.of("Annots"), annots);
	}
	annots.push(widgetRef);
	const form = doc.getForm();
	form.acroForm.dict.set(PDFName.of("SigFlags"), PDFNumber.of(3));
	form.acroForm.addField(widgetRef);
	const out = await doc.save({ useObjectStreams: false });
	const text = latin1(out);
	const cStart = text.indexOf("<" + "0".repeat(SIG_BYTES * 2) + ">");
	if (cStart < 0) throw new Error("Không tạo được chỗ chữ ký trong PDF.");
	const cEnd = cStart + SIG_BYTES * 2 + 2;
	const m = new RegExp(`/ByteRange\\s*\\[\\s*0\\s+${BR_PLACEHOLDER}\\s+${BR_PLACEHOLDER}\\s+${BR_PLACEHOLDER}\\s*\\]`).exec(text);
	if (!m) throw new Error("Không tìm thấy vùng ByteRange.");
	let brText = `/ByteRange [${[
		0,
		cStart,
		cEnd,
		out.length - cEnd
	].join(" ")}]`;
	if (brText.length > m[0].length) throw new Error("ByteRange quá dài.");
	brText = brText.padEnd(m[0].length, " ");
	const bytes = new Uint8Array(out);
	for (let i = 0; i < brText.length; i++) bytes[m.index + i] = brText.charCodeAt(i);
	const signed = new Uint8Array(cStart + (out.length - cEnd));
	signed.set(bytes.subarray(0, cStart), 0);
	signed.set(bytes.subarray(cEnd), cStart);
	const p7 = import_lib.default.pkcs7.createSignedData();
	p7.content = import_lib.default.util.createBuffer(toBinary(signed));
	const cert = import_lib.default.pki.certificateFromPem(key.certPem);
	p7.addCertificate(cert);
	p7.addSigner({
		key: import_lib.default.pki.privateKeyFromPem(key.privateKeyPem),
		issuer: cert.issuer.attributes.map((a) => a.valueTagClass === import_lib.default.asn1.Type.UTF8 ? {
			...a,
			value: fieldText(a)
		} : a),
		serialNumber: cert.serialNumber,
		digestAlgorithm: import_lib.default.pki.oids["sha256"],
		authenticatedAttributes: [
			{
				type: import_lib.default.pki.oids["contentType"],
				value: import_lib.default.pki.oids["data"]
			},
			{ type: import_lib.default.pki.oids["messageDigest"] },
			{
				type: import_lib.default.pki.oids["signingTime"],
				value: date
			}
		]
	});
	p7.sign({ detached: true });
	const hex = import_lib.default.util.bytesToHex(import_lib.default.asn1.toDer(p7.toAsn1()).getBytes());
	if (hex.length > SIG_BYTES * 2) throw new Error("Chữ ký quá lớn.");
	const padded = hex.padEnd(SIG_BYTES * 2, "0");
	for (let i = 0; i < padded.length; i++) bytes[cStart + 1 + i] = padded.charCodeAt(i);
	return bytes;
}
/** Lấy ByteRange + chữ ký hex của chữ ký cuối trong PDF (dùng cho kiểm tra). */
function readSignature(pdf) {
	const text = latin1(pdf);
	const all = [...text.matchAll(/\/ByteRange\s*\[\s*(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*\]/g)];
	const last = all[all.length - 1];
	if (!last) return null;
	const ranges = last.slice(1, 5).map(Number);
	const raw = import_lib.default.util.hexToBytes(text.slice(ranges[1] + 1, ranges[2] - 1));
	return {
		ranges,
		der: raw.slice(0, derLength(raw))
	};
}
/** Độ dài một phần tử DER (thẻ + độ dài + nội dung) ở đầu chuỗi. P18: trước đây cắt mọi "00" ở cuối hex
*  → chữ ký có byte cuối 0x00 (~1/256) bị cắt cụt và báo "không hợp lệ". Không đọc được thì giữ cả chuỗi. */
function derLength(b) {
	if (b.length < 2) return b.length;
	const l0 = b.charCodeAt(1);
	if (l0 < 128) return Math.min(b.length, 2 + l0);
	const n = l0 & 127;
	if (n === 0 || n > 4 || b.length < 2 + n) return b.length;
	let len = 0;
	for (let i = 0; i < n; i++) len = len * 256 + b.charCodeAt(2 + i);
	return Math.min(b.length, 2 + n + len);
}
var binOf = (u) => toBinary(u);
/** Kiểm tra chữ ký số cuối trong PDF: băm nội dung, đối chiếu chữ ký RSA, hạn chứng thư. */
function verifyPdfSignature(pdf, at = /* @__PURE__ */ new Date()) {
	let s;
	try {
		s = readSignature(pdf);
	} catch {
		s = null;
	}
	if (!s || !s.der) return {
		status: "none",
		message: "Tệp không có chữ ký số."
	};
	try {
		const [a, b, c, d] = s.ranges;
		const oids = import_lib.default.pki.oids;
		const msg = import_lib.default.pkcs7.messageFromAsn1(import_lib.default.asn1.fromDer(s.der));
		const cert = msg.certificates[0];
		if (!cert) return {
			status: "invalid",
			message: "Chữ ký thiếu chứng thư."
		};
		const attrs = msg.rawCapture.authenticatedAttributes ?? [];
		const attrVal = (oid) => {
			const x = attrs.find((t) => import_lib.default.asn1.derToOid(t.value[0].value) === oid);
			return x ? x.value[1].value[0] : void 0;
		};
		const md = import_lib.default.md.sha256.create();
		md.update(binOf(pdf.subarray(a, a + b)));
		md.update(binOf(pdf.subarray(c, c + d)));
		const digestNode = attrVal(oids["messageDigest"]);
		const contentOk = !!digestNode && import_lib.default.util.bytesToHex(digestNode.value) === md.digest().toHex();
		const set = import_lib.default.asn1.create(import_lib.default.asn1.Class.UNIVERSAL, import_lib.default.asn1.Type.SET, true, attrs);
		const amd = import_lib.default.md.sha256.create();
		amd.update(import_lib.default.asn1.toDer(set).getBytes());
		let sigOk = false;
		try {
			sigOk = cert.publicKey.verify(amd.digest().getBytes(), msg.rawCapture.signature);
		} catch {
			sigOk = false;
		}
		const timeNode = attrVal(oids["signingTime"]);
		let signedAt;
		if (timeNode) try {
			signedAt = timeNode.type === import_lib.default.asn1.Type.UTCTIME ? import_lib.default.asn1.utcTimeToDate(timeNode.value) : import_lib.default.asn1.generalizedTimeToDate(timeNode.value);
		} catch {}
		const signer = fieldText(cert.subject.getField("CN"));
		let selfSigned = false;
		try {
			selfSigned = cert.isIssuer(cert) && cert.verify(cert);
		} catch {
			selfSigned = false;
		}
		const ref = signedAt ?? at;
		const certExpired = ref < cert.validity.notBefore || ref > cert.validity.notAfter;
		const coversWholeFile = c + d === pdf.length;
		const base = {
			signer,
			signedAt,
			selfSigned,
			certExpired,
			coversWholeFile
		};
		if (!sigOk) return {
			...base,
			status: "invalid",
			message: "Chữ ký không hợp lệ — không khớp với chứng thư."
		};
		if (!contentOk) return {
			...base,
			status: "modified",
			message: "Tài liệu đã bị sửa sau khi ký."
		};
		let message = "Chữ ký hợp lệ, nội dung chưa bị sửa.";
		if (!coversWholeFile) message += " Có phần thêm vào sau khi ký.";
		if (certExpired) message += " Chứng thư không còn hiệu lực tại thời điểm ký.";
		if (selfSigned) message += " Chứng thư tự ký — chỉ tin cậy nếu bạn biết người ký.";
		return {
			...base,
			status: "valid",
			message
		};
	} catch {
		return {
			status: "invalid",
			message: "Không đọc được chữ ký trong tệp."
		};
	}
}
//#endregion
export { importP12 as n, isCertValid as r, readSignature, signPdf, createP12 as t, verifyPdfSignature };
