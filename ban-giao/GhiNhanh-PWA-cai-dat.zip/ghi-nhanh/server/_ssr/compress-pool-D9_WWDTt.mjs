import { n as runInPool } from "./worker-pool-DW9Ak2AM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/compress-pool-D9_WWDTt.js
/** Tắt Worker (đo so sánh / rollback): setCompressWorker(false). */
var enabled = true;
function compressInWorker(src, maxSide, q, bw, isJpeg, crop = true) {
	if (!enabled) return null;
	const p = runInPool("compress", {
		src,
		maxSide,
		q,
		bw,
		isJpeg,
		crop
	});
	if (!p) return null;
	return p.then((r) => {
		if (!r.page) throw new Error(r.error || "compress worker");
		return r.page;
	});
}
/** CS-21: trang PDF theo loại (Worker). null = không có Worker/OffscreenCanvas → nơi gọi dùng compressPage như cũ. */
function pdfPageInWorker(src, mode, q, maxSide, scale = 1, adaptive = true) {
	if (!enabled) return null;
	const p = runInPool("compress", {
		src,
		maxSide,
		q,
		bw: false,
		isJpeg: false,
		mode,
		scale,
		adaptive
	});
	return p ? p.then((r) => {
		if (!r.page) throw new Error(r.error || "pdfpage worker");
		return r.page;
	}) : null;
}
/** CS-21: tỉ lệ điểm mực màu của ảnh trang (dấu đỏ, chữ ký xanh). null = không có Worker. */
function inkShareInWorker(src, maxSide = 900) {
	if (!enabled) return null;
	const p = runInPool("compress", {
		src,
		maxSide,
		q: 0,
		bw: false,
		isJpeg: false,
		mode: "ink"
	});
	return p ? p.then((r) => {
		if (typeof r.ink !== "number") throw new Error(r.error || "ink worker");
		return r.ink;
	}) : null;
}
//#endregion
export { compressInWorker, inkShareInWorker, pdfPageInWorker };
