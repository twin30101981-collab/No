import { o as __toESM } from "../_runtime.mjs";
import { T as useNavigate, w as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { a as userMessage } from "./errors-DKvrPJ4v.mjs";
import { Ct as FileText, E as Search, Ut as ClipboardPaste, Zt as Camera, b as Sparkles, c as Upload, et as Lightbulb, ht as Grid2x2, ot as ImagePlus, r as X, st as IdCard, u as Type } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-CZvf2xHx.mjs";
import { C as saveDoc, D as useDocs, S as restoreDocs, i as deleteDocs, p as newDoc } from "./db-CclUQaLE.mjs";
import { b as useLibrary, h as removeQuickFilter, p as matchesQuery } from "./library-BIMZUn1d.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { S as shareOrDownload, s as docToPdf, x as safeName } from "./files-CTF11Arr.mjs";
import { d as readClipboardImages, r as useImport, t as filesToPages } from "./importer-BUHDogNt.mjs";
import { i as TagChip } from "./library-ui-BCoN_d8a.mjs";
import { t as useImagePaste } from "./use-image-paste-FdMZgoID.mjs";
import { t as DocRow } from "./doc-row-BD9Y5xLI.mjs";
import { t as Route } from "./routes-BujOT1PY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-jaZf4-y2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SHARE_CACHE = "gn-share";
/** Đọc rồi xoá các tệp đã được service worker cất. */
async function takeSharedFiles() {
	if (typeof caches === "undefined") return [];
	const c = await caches.open(SHARE_CACHE);
	const keys = await c.keys();
	const out = [];
	for (const k of keys) {
		const res = await c.match(k);
		if (res) {
			const blob = await res.blob();
			const name = decodeURIComponent(res.headers.get("x-name") || "tep-chia-se");
			out.push(new File([blob], name, { type: blob.type || res.headers.get("content-type") || "" }));
		}
		await c.delete(k);
	}
	return out;
}
function Home() {
	const { docs, ready } = useDocs();
	const lib = useLibrary();
	const [query, setQuery] = (0, import_react.useState)("");
	const importFiles = useImport();
	const [pasting, setPasting] = (0, import_react.useState)(false);
	useImagePaste((files) => importFiles(files, "Ảnh dán"), !pasting);
	async function pasteImage() {
		if (pasting) return;
		setPasting(true);
		try {
			await importFiles(await readClipboardImages(), "Ảnh dán");
		} catch (error) {
			toast.error(userMessage(error, "Không dán được ảnh"));
		} finally {
			setPasting(false);
		}
	}
	const navigate = useNavigate();
	const { shared } = Route.useSearch();
	const sharedDone = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (shared === void 0 || sharedDone.current) return;
		sharedDone.current = true;
		(async () => {
			const id = toast.loading("Đang nhận tệp chia sẻ…");
			try {
				const files = await takeSharedFiles();
				if (!files.length) {
					toast.error("Không nhận được ảnh hoặc PDF nào. Hãy chia sẻ ảnh hoặc tệp PDF.", { id });
					navigate({
						to: "/",
						search: {},
						replace: true
					});
					return;
				}
				const pages = await filesToPages(files);
				if (!pages.length) {
					toast.error("Tệp chia sẻ không đọc được", { id });
					navigate({
						to: "/",
						search: {},
						replace: true
					});
					return;
				}
				const doc = await saveDoc(newDoc(pages, files.length === 1 ? files[0].name.replace(/\.[^.]+$/, "") : void 0, "Chia sẻ"));
				toast.success(`Đã nhận ${pages.length} trang`, { id });
				navigate({
					to: "/doc/$id",
					params: { id: doc.id },
					replace: true
				});
			} catch {
				toast.error("Không đọc được tệp chia sẻ. Thử chia sẻ lại.", { id });
			}
		})();
	}, [shared, navigate]);
	const results = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		if (!q) return docs.slice(0, 8);
		return docs.filter((d) => matchesQuery(d, q));
	}, [docs, query]);
	const unnamed = docs.filter((d) => !d.pages.some((p) => p.text) && !d.locked).length;
	const shortcuts = [
		{
			label: "Quét",
			icon: Camera,
			primary: true,
			run: () => navigate({ to: "/scan" })
		},
		{
			label: "Công cụ PDF",
			icon: FileText,
			run: () => navigate({ to: "/tools" })
		},
		{
			label: "Nhập ảnh",
			icon: ImagePlus,
			run: () => importFiles("image/*", "Ảnh")
		},
		{
			label: "Nhập tập tin",
			icon: Upload,
			run: () => importFiles("application/pdf,image/*", "PDF")
		},
		{
			label: "Thẻ ID",
			icon: IdCard,
			run: () => navigate({
				to: "/scan",
				search: { mode: "id" }
			})
		},
		{
			label: "Trích văn bản",
			icon: Type,
			run: () => importFiles("image/*,application/pdf", "Văn bản", "ocr")
		},
		{
			label: "Solver AI",
			icon: Sparkles,
			run: () => importFiles("image/*", "Bài tập", "ai-solve")
		},
		{
			label: "Tất cả",
			icon: Grid2x2,
			run: () => navigate({ to: "/tools" })
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rise grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-5 pt-[max(1.25rem,env(safe-area-inset-top))]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "brand-mark grid size-9 shrink-0 place-items-center rounded-[10px] bg-primary font-display text-sm font-bold text-primary-foreground",
						children: "G"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display truncate text-[1.0625rem] font-semibold leading-none",
							children: "Ghi Nhanh"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[0.6875rem] font-medium text-muted-foreground",
							children: "Quét · Nhận chữ · PDF"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "rounded-full bg-secondary px-2.5 py-1 text-[0.625rem] font-bold text-primary",
					children: [docs.length, " tài liệu"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rise rise-1 px-5 pt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "glass-field flex h-12 items-center gap-2.5 rounded-[14px] px-3.5",
					htmlFor: "search",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 shrink-0 text-muted-foreground" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "search",
							value: query,
							onChange: (e) => setQuery(e.target.value),
							className: "min-w-0 flex-1 bg-transparent text-[0.9375rem] outline-none placeholder:text-muted-foreground",
							placeholder: "Tìm tên, chữ trong ảnh, thẻ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-md bg-secondary px-2 py-0.5 text-[0.625rem] font-bold text-primary",
							children: "OCR"
						})
					]
				})
			}),
			!query && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise rise-2 px-5 pt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-4 gap-2 lg:grid-cols-8",
					children: shortcuts.map(({ label, icon: Icon, primary, run }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: run,
						className: "shortcut-tile flex h-[78px] min-w-0 flex-col items-center justify-center gap-1.5 rounded-[14px] px-1 active:scale-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `grid size-9 place-items-center rounded-[10px] ${primary ? "bg-primary text-primary-foreground" : "bg-secondary text-primary"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-[18px]" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-full truncate text-center text-[0.65625rem] font-semibold",
							children: label
						})]
					}, label))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					className: "mt-3 w-full",
					disabled: pasting,
					onClick: () => void pasteImage(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, {}),
						" ",
						pasting ? "Đang dán…" : "Dán ảnh"
					]
				})]
			}),
			!query && (lib.quick.length > 0 || lib.tags.length > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise rise-2 px-5 pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-[0.875rem] font-semibold",
					children: "Bộ lọc nhanh"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none]",
					children: [lib.quick.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "shortcut-tile flex h-9 shrink-0 items-center gap-1.5 rounded-full pl-3.5 pr-2 text-xs font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/documents",
							search: { qf: q.id },
							children: q.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							"aria-label": `Xoá bộ lọc ${q.name}`,
							onClick: () => removeQuickFilter(q.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5 text-muted-foreground" })
						})]
					}, q.id)), lib.tags.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/documents",
						search: { tag: t.name },
						className: "flex shrink-0 items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagChip, { name: t.name })
					}, t.name))]
				})]
			}),
			!query && unnamed > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rise rise-2 px-5 pt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "document-row flex items-center gap-3 rounded-[14px] p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, { className: "size-5 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "min-w-0 flex-1 text-xs leading-5",
						children: [
							"Bạn có ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: unnamed }),
							" tài liệu chưa nhận diện chữ. Nhận chữ để tìm kiếm và tự đặt tên."
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise rise-3 px-5 pt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-[0.875rem] font-semibold",
							children: query ? `Kết quả (${results.length})` : "Gần đây"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/documents",
							className: "inline-flex min-h-10 items-center text-[0.75rem] font-semibold text-primary",
							children: "Xem tất cả"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-col gap-2.5 lg:grid lg:grid-cols-2 lg:gap-3",
						children: [results.map((doc) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocRow, {
							doc,
							onDelete: async () => {
								await deleteDocs([doc.id]);
								toast("Đã chuyển vào thùng rác", { action: {
									label: "Hoàn tác",
									onClick: () => void restoreDocs([doc.id])
								} });
							},
							onShare: async () => {
								await shareOrDownload(await docToPdf(doc), `${safeName(doc.name)}.pdf`);
							}
						}, doc.id)), ready && !results.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "document-row flex flex-col items-center gap-3 rounded-[16px] px-6 py-8 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-8 text-primary" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold",
									children: query ? "Không tìm thấy tài liệu" : "Chưa có tài liệu"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Nhấn nút máy ảnh bên dưới để quét trang đầu tiên."
								})
							]
						})]
					}),
					!query && docs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-center text-[0.6875rem] text-muted-foreground",
						children: "Mẹo: vuốt sang trái để chia sẻ hoặc xóa"
					})
				]
			})
		]
	});
}
//#endregion
export { Home as component };
