import { o as __toESM } from "../_runtime.mjs";
import { T as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as aiLayout, f as aiTable } from "./ai.functions-CpS7iAgj.mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { i as showError } from "./errors-DKvrPJ4v.mjs";
import { $t as BookUser, A as ScanLine, At as FileArchive, Bt as Combine, Ct as FileText, D as Scissors, Dt as FileLock, E as Search, I as Receipt, L as QrCode, M as RotateCw, O as ScanText, Ot as FileImage, Q as ListOrdered, S as Smartphone, St as FileTypeCorner, Tt as FileSearch, U as PenLine, W as MousePointerClick, Wt as ClipboardList, X as LoaderCircle, Xt as Check, _ as Stamp, b as Sparkles, c as Upload, dt as Hash, en as BookOpen, f as Trash2, h as Table2, it as Languages, j as Ruler, lt as History, o as WandSparkles, ot as ImagePlus, q as MessageSquareText, r as X, st as IdCard, u as Type, ut as Highlighter, v as Square, wt as FileSpreadsheet, y as SquareCheckBig } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-CZvf2xHx.mjs";
import { i as useQueuedServerFn } from "./ai-queue-DZjZmUCT.mjs";
import { i as topUsed, r as recordUse, t as matchTool } from "./tool-usage-C3cHF8xW.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { j as normalize, l as compress, u as countObjects, w as fileToDataUrl } from "./image-DFWRNlNd.mjs";
import { C as splitPdf, b as rotatePdf, c as download, d as mergePdfs, g as pdfjs, h as pdfToImages, m as pdfPageCount, o as dataUrlToBlob, p as parsePages, u as imagesToPdf, v as reorderPdf, w as watermarkPdf, x as safeName } from "./files-CTF11Arr.mjs";
import { i as promptDialog } from "./dialog-IcUxZaUZ.mjs";
import { n as pickFiles, r as useImport } from "./importer-BUHDogNt.mjs";
import { i as pool, n as ocrSession } from "./ocr-CLa2avjZ.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogDescription, t as Dialog } from "./dialog-3HhpKDcy.mjs";
import { t as Input } from "./input-T4LKa1EA.mjs";
import { n as sheetsToXlsx, r as textToRows } from "./xlsx-CvpeQh6I.mjs";
import { t as pmapOrdered } from "./pmap-BY7K0bZd.mjs";
import { m as textToBlocks, n as blocksToDocx, t as block } from "./history-ZPjFrOJG.mjs";
import { t as imagesToWord } from "./word-DdGqJXaY.mjs";
import { t as ExportReview } from "./export-review-DWV3zMTm.mjs";
import { t as Progress } from "./progress-DOIEKRJF.mjs";
import { i as imagesToTables, t as TABLE_PX } from "./batch-BYOz1Bdb.mjs";
import { t as Switch } from "./switch-BVIUyQVR.mjs";
import { r as useOnline } from "./feature-status-C0M5x8cK.mjs";
import { n as readCodeFromDataUrl } from "./qr-ByGtmulG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tools-Ip96NTmd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** PDF → Word/Excel. Text PDFs: read the text layer directly (fast, exact). Image-only pages: AI table reading (Excel) or OCR. */
/** Cạnh dài tối đa của ảnh gửi AI: đủ đọc số nhỏ, nhẹ hơn ~40% so với ảnh dựng trang. */
var AI_PX = 1600;
/** Group positioned text items into lines; split a line into cells where the horizontal gap is wide. */
function itemsToLines(items) {
	const its = items.filter((i) => i.str.trim()).sort((a, b) => b.y - a.y || a.x - b.x);
	const rows = [];
	for (const it of its) {
		const r = rows[rows.length - 1];
		if (r && Math.abs(r[0].y - it.y) <= Math.max(2, Math.min(r[0].h, it.h) * .5)) r.push(it);
		else rows.push([it]);
	}
	return rows.map((r) => {
		r.sort((a, b) => a.x - b.x);
		const size = Math.max(...r.map((i) => i.h));
		const cells = [r[0].str];
		for (let k = 1; k < r.length; k++) {
			const gap = r[k].x - (r[k - 1].x + r[k - 1].w);
			if (gap > size * 1.5) cells.push(r[k].str);
			else cells[cells.length - 1] += (gap > size * .15 && !/\s$/.test(cells[cells.length - 1]) ? " " : "") + r[k].str;
		}
		return {
			cells: cells.map((c) => c.replace(/\s+/g, " ").trim()).filter(Boolean),
			size
		};
	}).filter((l) => l.cells.length);
}
async function readPdf(file, opts = {}) {
	const { onStep, table, warn } = opts;
	const task = (await pdfjs()).getDocument({ data: new Uint8Array(await file.arrayBuffer()) });
	try {
		return await readOpened(await task.promise, onStep, table, warn);
	} finally {
		await task.destroy();
	}
}
async function readOpened(pdf, onStep, table, warn) {
	const n = pdf.numPages;
	const out = new Array(n);
	const scans = [];
	for (let i = 1; i <= n; i++) {
		onStep?.({
			step: "read",
			done: i - 1,
			total: n,
			label: `Đang mở trang ${i}/${n}`
		});
		const page = await pdf.getPage(i);
		const lines = itemsToLines((await page.getTextContent()).items.filter((t) => typeof t.str === "string" && t.transform).map((t) => ({
			str: t.str,
			x: t.transform[4],
			y: t.transform[5],
			w: t.width ?? 0,
			h: t.height || Math.abs(t.transform[3]) || 10
		})));
		const chars = lines.reduce((k, l) => k + l.cells.join("").length, 0);
		page.cleanup?.();
		if (chars >= 20) {
			out[i - 1] = {
				lines,
				ocr: false,
				text: lines.map((l) => l.cells.join("  ")).join("\n")
			};
			continue;
		}
		scans.push(i - 1);
	}
	if (!scans.length) return out;
	/** Dựng 1 trang thành canvas (người gọi phải giải phóng bằng `free`). */
	const render = async (i) => {
		const page = await pdf.getPage(i + 1);
		const base = page.getViewport({ scale: 1 });
		const vp = page.getViewport({ scale: Math.min(3, TABLE_PX / Math.max(base.width, base.height)) });
		const c = document.createElement("canvas");
		c.width = vp.width;
		c.height = vp.height;
		try {
			await page.render({
				canvas: c,
				canvasContext: c.getContext("2d"),
				viewport: vp
			}).promise;
		} catch (e) {
			free(c);
			throw e;
		} finally {
			page.cleanup?.();
		}
		return c;
	};
	const free = (c) => {
		c.width = 0;
		c.height = 0;
	};
	let done = 0, stopAi = !table, warned = false;
	const tick = () => onStep?.({
		step: "scan",
		done: ++done,
		total: scans.length,
		label: `Đã đọc ${done}/${scans.length} trang ảnh`
	});
	const warnOnce = (m) => {
		if (!warned) {
			warn?.(m + " Đang dùng cách đọc chữ thường (chậm và kém chính xác hơn).");
			warned = true;
		}
	};
	onStep?.({
		step: "scan",
		done: 0,
		total: scans.length,
		label: `Đang đọc ${scans.length} trang ảnh`
	});
	const failed = [];
	if (!stopAi) await pool(scans, 3, async (i) => {
		if (stopAi) {
			failed.push(i);
			return;
		}
		onStep?.({
			step: "scan",
			done,
			total: scans.length,
			label: `Đang đọc trang ${i + 1} (xong ${done}/${scans.length})`
		});
		const c = await render(i);
		try {
			const r = await table({ data: { images: [await normalize(c, AI_PX, .8)] } });
			if (r.ok && r.data.rows.length) {
				out[i] = {
					lines: r.data.rows.map((cells) => ({
						cells,
						size: 10
					})),
					ocr: true,
					ai: true,
					text: r.data.rows.map((c) => c.join("  ")).join("\n")
				};
				tick();
				return;
			}
			if (!r.ok) {
				if (r.code === 402 || r.code === 429) stopAi = true;
				warnOnce(r.message);
			}
		} catch (e) {
			console.warn("[BL-07] AI đọc bảng lỗi, chuyển sang OCR:", e);
			stopAi = true;
			warnOnce("Không gọi được AI đọc bảng.");
		} finally {
			free(c);
		}
		failed.push(i);
	});
	else failed.push(...scans);
	if (failed.length) {
		failed.sort((a, b) => a - b);
		const ocr = await ocrSession();
		try {
			for (const i of failed) {
				const c = await render(i);
				try {
					const { text } = await ocr.words(c);
					out[i] = {
						lines: textToRows(text).map((cells) => ({
							cells,
							size: 10
						})),
						ocr: true,
						text
					};
				} finally {
					free(c);
				}
				tick();
			}
		} finally {
			await ocr.close();
		}
	}
	return out;
}
/** Text-layer lines → Word blocks: runs of ≥2 multi-cell lines become tables, large lines headings. */
function linesToBlocks(lines) {
	const sizes = lines.map((l) => l.size).sort((a, b) => a - b);
	const med = sizes[sizes.length >> 1] || 10;
	const out = [];
	let i = 0;
	while (i < lines.length) {
		let j = i;
		while (j < lines.length && lines[j].cells.length >= 2) j++;
		if (j - i >= 2) {
			out.push(block("table", "", { rows: lines.slice(i, j).map((l) => l.cells) }));
			i = j;
			continue;
		}
		const l = lines[i], t = l.cells.join("    ");
		if (l.size > med * 1.25 && t.length < 120) out.push(block("heading", t, { level: l.size > med * 1.6 ? 1 : 2 }));
		else if (/^[•\-–*]\s+/.test(t)) out.push(block("bullet", t.replace(/^[•\-–*]\s+/, "")));
		else {
			const prev = out[out.length - 1];
			if (prev?.kind === "paragraph" && !/[.:;!?]$/.test(prev.text) && /^[a-zà-ỹ0-9(]/.test(t)) prev.text += " " + t;
			else out.push(block("paragraph", t));
		}
		i++;
	}
	return out;
}
function pdfPagesToWord(pages, title) {
	const blocks = pages.flatMap((p) => p.ai ? [block("table", "", { rows: p.lines.map((l) => l.cells) })] : p.ocr ? textToBlocks(p.text) : linesToBlocks(p.lines));
	return {
		blob: blocksToDocx(blocks, title),
		blocks
	};
}
function pdfPagesToExcel(pages) {
	const sheets = pages.map((p, i) => ({
		name: pages.length > 1 ? `Trang ${i + 1}` : "Bang",
		rows: p.lines.map((l) => l.cells),
		totals: true
	}));
	return {
		blob: sheetsToXlsx(sheets),
		sheets
	};
}
var XlsxError = class extends Error {
	name = "XlsxError";
};
var dec = new TextDecoder();
async function inflate(data) {
	const ds = new DecompressionStream("deflate-raw");
	const w = ds.writable.getWriter();
	w.write(data).then(() => w.close()).catch(() => {});
	const r = ds.readable.getReader();
	const parts = [];
	let n = 0;
	for (;;) {
		const { done, value } = await r.read();
		if (done) break;
		parts.push(value);
		n += value.length;
	}
	const out = new Uint8Array(n);
	let o = 0;
	for (const p of parts) {
		out.set(p, o);
		o += p.length;
	}
	return out;
}
/** Mở zip qua thư mục trung tâm; trả về hàm đọc từng tệp theo tên. */
function unzip(buf) {
	const v = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
	if (buf.length < 22 || v.getUint32(0, true) !== 67324752) throw new XlsxError("not zip");
	let e = buf.length - 22;
	while (e >= 0 && v.getUint32(e, true) !== 101010256) e--;
	if (e < 0) throw new XlsxError("no eocd");
	const count = v.getUint16(e + 10, true);
	let p = v.getUint32(e + 16, true);
	const entries = /* @__PURE__ */ new Map();
	for (let i = 0; i < count; i++) {
		if (v.getUint32(p, true) !== 33639248) throw new XlsxError("bad central");
		const flags = v.getUint16(p + 8, true), method = v.getUint16(p + 10, true), size = v.getUint32(p + 20, true);
		const nl = v.getUint16(p + 28, true), el = v.getUint16(p + 30, true), cl = v.getUint16(p + 32, true), off = v.getUint32(p + 42, true);
		entries.set(dec.decode(buf.subarray(p + 46, p + 46 + nl)), {
			method,
			size,
			off,
			flags
		});
		p += 46 + nl + el + cl;
	}
	return async (name) => {
		const en = entries.get(name.replace(/^\//, ""));
		if (!en) return null;
		if (en.flags & 1) throw new XlsxError("encrypted");
		const start = en.off + 30 + v.getUint16(en.off + 26, true) + v.getUint16(en.off + 28, true);
		const raw = buf.subarray(start, start + en.size);
		if (en.method === 0) return dec.decode(raw);
		if (en.method === 8) return dec.decode(await inflate(raw));
		throw new XlsxError("method");
	};
}
var parse = (s) => new DOMParser().parseFromString(s, "application/xml");
var all = (n, tag) => Array.from(n.getElementsByTagNameNS("*", tag));
var first = (n, tag) => n.getElementsByTagNameNS("*", tag)[0];
var kids = (n, tag) => Array.from(n.children).filter((c) => c.localName === tag);
var ref = (a) => {
	const m = /^([A-Z]+)(\d+)$/.exec(a.replace(/\$/g, ""));
	if (!m) return null;
	let c = 0;
	for (const ch of m[1]) c = c * 26 + ch.charCodeAt(0) - 64;
	return {
		r: +m[2] - 1,
		c: c - 1
	};
};
var DATE_IDS = /* @__PURE__ */ new Set([
	14,
	15,
	16,
	17,
	18,
	19,
	20,
	21,
	22,
	45,
	46,
	47
]);
var BUILTIN = {
	1: "0",
	2: "0.00",
	3: "#,##0",
	4: "#,##0.00",
	9: "0%",
	10: "0.00%",
	37: "#,##0;(#,##0)",
	38: "#,##0;[Red](#,##0)",
	39: "#,##0.00;(#,##0.00)",
	40: "#,##0.00;[Red](#,##0.00)"
};
/** Số kiểu Việt Nam: dấu chấm hàng nghìn, dấu phẩy thập phân, âm hiển thị "-1.156". */
function vnNumber(n, decimals) {
	const d = decimals ?? (Number.isInteger(n) ? 0 : Math.min(10, (String(Math.abs(n)).split(".")[1] ?? "").length));
	const [i, f] = Math.abs(n).toFixed(d).split(".");
	const s = i.replace(/\B(?=(\d{3})+(?!\d))/g, ".") + (f && /[1-9]/.test(f) || f && decimals !== void 0 ? "," + f : "");
	return (n < 0 && /[1-9]/.test(s) ? "-" : "") + s;
}
var pad = (n) => String(n).padStart(2, "0");
function serialToDate(v, withTime) {
	const ms = Math.round((v - 25569) * 864e5);
	const d = new Date(ms);
	const s = `${pad(d.getUTCDate())}/${pad(d.getUTCMonth() + 1)}/${d.getUTCFullYear()}`;
	return withTime && v % 1 ? `${s} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}` : s;
}
/** Hiển thị một số theo mã định dạng Excel. Trả về chữ và có tô đỏ hay không. */
function formatValue(v, id, code = BUILTIN[id] ?? "General") {
	const sections = code.split(";");
	const sec = v < 0 && sections[1] || sections[0];
	const bare = sec.replace(/"[^"]*"|\\.|\[[^\]]*\]/g, "");
	const red = v < 0 && /\[red\]/i.test(sec);
	if (DATE_IDS.has(id) || /[dy]/i.test(bare) && !/[0#]/.test(bare) || /m/i.test(bare) && /[dy]/i.test(bare)) return {
		text: serialToDate(v, /h/i.test(bare)),
		red
	};
	const decimals = /\.([0#]+)/.exec(bare)?.[1].length;
	const fixed = /[0#]/.test(bare) ? decimals ?? 0 : void 0;
	if (bare.includes("%")) return {
		text: vnNumber(v * 100, fixed) + "%",
		red
	};
	let text = vnNumber(v, fixed);
	if (/₫|đ|VND/i.test(sec)) text += " ₫";
	else if (sec.includes("$")) text = (v < 0 ? "-$" : "$") + text.replace(/^-/, "");
	return {
		text,
		red
	};
}
async function readXlsx(file) {
	const read = unzip(file instanceof Uint8Array ? file : new Uint8Array(await file.arrayBuffer()));
	const wbXml = await read("xl/workbook.xml");
	if (!wbXml) throw new XlsxError("no workbook");
	const wb = parse(wbXml), rels = parse(await read("xl/_rels/workbook.xml.rels") ?? "<r/>");
	const target = new Map(all(rels, "Relationship").map((r) => [r.getAttribute("Id"), r.getAttribute("Target") ?? ""]));
	const strings = await read("xl/sharedStrings.xml").then((s) => s ? all(parse(s), "si").map((si) => all(si, "t").filter((t) => t.parentElement?.localName !== "rPh").map((t) => t.textContent ?? "").join("")) : []);
	const styles = parse(await read("xl/styles.xml") ?? "<s/>");
	const codes = new Map(all(styles, "numFmt").map((n) => [+(n.getAttribute("numFmtId") ?? 0), n.getAttribute("formatCode") ?? ""]));
	const fontsEl = all(styles, "fonts")[0];
	const redFont = fontsEl ? kids(fontsEl, "font").map((f) => /^(FF)?(FF0000|C00000|E00000)$/i.test(first(f, "color")?.getAttribute("rgb") ?? "")) : [];
	const xfsEl = all(styles, "cellXfs")[0];
	const xfs = xfsEl ? kids(xfsEl, "xf").map((x) => ({
		id: +(x.getAttribute("numFmtId") ?? 0),
		font: +(x.getAttribute("fontId") ?? 0)
	})) : [];
	const out = [];
	for (const s of all(wb, "sheet")) {
		const rid = s.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id") ?? s.getAttribute("r:id");
		let t = target.get(rid) ?? "";
		if (!t) continue;
		t = t.startsWith("/") ? t.slice(1) : "xl/" + t.replace(/^\.\//, "");
		const xml = await read(t);
		if (!xml) continue;
		const doc = parse(xml);
		const grid = [];
		const red = [];
		for (const c of all(doc, "c")) {
			const p = ref(c.getAttribute("r") ?? "");
			if (!p) continue;
			const type = c.getAttribute("t"), v = first(c, "v")?.textContent ?? "";
			const st = xfs[+(c.getAttribute("s") ?? 0)] ?? {
				id: 0,
				font: 0
			};
			let text = "";
			if (type === "s") text = strings[+v] ?? "";
			else if (type === "inlineStr") text = all(c, "t").map((x) => x.textContent ?? "").join("");
			else if (type === "b") text = v === "1" ? "Đúng" : "Sai";
			else if (type === "str" || type === "e") text = v;
			else if (v !== "") {
				const f = formatValue(+v, st.id, codes.get(st.id));
				text = f.text;
				if (f.red || +v < 0 && redFont[st.font]) red.push(`${p.r},${p.c}`);
			}
			if (!text) continue;
			(grid[p.r] ??= [])[p.c] = text;
		}
		const merges = all(doc, "mergeCell").flatMap((m) => {
			const [a, b] = (m.getAttribute("ref") ?? "").split(":");
			const p = ref(a ?? ""), q = ref(b ?? a ?? "");
			return p && q ? [{
				r: p.r,
				c: p.c,
				rs: q.r - p.r + 1,
				cs: q.c - p.c + 1
			}] : [];
		});
		const used = grid.flatMap((r, ri) => r ? r.map((x, ci) => x ? [ri, ci] : null).filter(Boolean) : []);
		if (!used.length) {
			out.push({
				name: s.getAttribute("name") ?? "",
				rows: [],
				merges: [],
				red: []
			});
			continue;
		}
		const r0 = Math.min(...used.map((u) => u[0])), r1 = Math.max(...used.map((u) => u[0]));
		const c0 = Math.min(...used.map((u) => u[1])), c1 = Math.max(...used.map((u) => u[1]));
		const rows = Array.from({ length: r1 - r0 + 1 }, (_, i) => Array.from({ length: c1 - c0 + 1 }, (_, j) => grid[r0 + i]?.[c0 + j] ?? ""));
		out.push({
			name: s.getAttribute("name") ?? "",
			rows,
			merges: merges.map((m) => ({
				...m,
				r: m.r - r0,
				c: m.c - c0
			})).filter((m) => m.r >= 0 && m.c >= 0 && m.r < rows.length && m.c < rows[0].length && (m.rs > 1 || m.cs > 1)).map((m) => ({
				...m,
				rs: Math.min(m.rs, rows.length - m.r),
				cs: Math.min(m.cs, rows[0].length - m.c)
			})),
			red: red.map((k) => {
				const [r, c] = k.split(",").map(Number);
				return `${r - r0},${c - c0}`;
			})
		});
	}
	return out;
}
/** Keep page-relative placement safe even when a tap lands on an edge. Pure. */
function normalizeFreeField(field, pageCount) {
	const clamp = (value) => Math.max(0, Math.min(1, Number.isFinite(value) ? value : 0));
	return {
		...field,
		page: Math.max(0, Math.min(Math.max(0, pageCount - 1), Math.floor(field.page || 0))),
		x: clamp(field.x),
		y: clamp(field.y),
		fontSize: Math.max(8, Math.min(36, field.fontSize ?? 14))
	};
}
/** Human label from a field name: "applicant.full_name[0]" → "full name". Pure. */
function fieldLabel(name) {
	return (name.split(".").filter(Boolean).pop() ?? name).replace(/\[\d+\]$/, "").replace(/[_-]+/g, " ").replace(/([a-z])([A-Z])/g, "$1 $2").trim() || name;
}
/** Values are only written for fields that changed and are not read-only. Pure. */
function changedValues(fields, values) {
	return fields.filter((f) => !f.readOnly && f.kind !== "other" && values[f.name] !== void 0 && values[f.name] !== f.value).map((f) => ({
		f,
		v: values[f.name]
	}));
}
async function load(file) {
	const lib = await import("../_libs/pdf-lib+tslib.mjs").then((n) => n.t);
	return {
		lib,
		doc: await lib.PDFDocument.load(file instanceof Blob ? await file.arrayBuffer() : file, { ignoreEncryption: true })
	};
}
async function readFormFields(file) {
	const { lib, doc } = await load(file);
	const pages = doc.getPages().map((p) => p.ref);
	return doc.getForm().getFields().map((f) => {
		const name = f.getName();
		const pr = f.acroField.getWidgets()[0]?.P();
		const page = Math.max(0, pr ? pages.findIndex((r) => r === pr || r.toString() === pr.toString()) : 0);
		const base = {
			name,
			label: fieldLabel(name),
			page,
			readOnly: f.isReadOnly()
		};
		if (f instanceof lib.PDFTextField) return {
			...base,
			kind: "text",
			value: f.getText() ?? "",
			multiline: f.isMultiline()
		};
		if (f instanceof lib.PDFCheckBox) return {
			...base,
			kind: "check",
			value: f.isChecked() ? "1" : ""
		};
		if (f instanceof lib.PDFRadioGroup) return {
			...base,
			kind: "radio",
			value: f.getSelected() ?? "",
			options: f.getOptions()
		};
		if (f instanceof lib.PDFDropdown || f instanceof lib.PDFOptionList) return {
			...base,
			kind: "select",
			value: f.getSelected()[0] ?? "",
			options: f.getOptions()
		};
		return {
			...base,
			kind: "other",
			value: "",
			readOnly: true
		};
	}).sort((a, b) => a.page - b.page);
}
/** Fill fields, regenerating appearances with an embedded Unicode font so Vietnamese shows in every viewer. */
async function fillFormFields(file, fields, values, flatten = false) {
	const { lib, doc } = await load(file);
	const fontkit = (await import("../_libs/pako+pdf-lib__fontkit+unenv.mjs").then((n) => n.t)).default;
	doc.registerFontkit(fontkit);
	const font = await doc.embedFont(await (await fetch("/fonts/DejaVuSans.ttf")).arrayBuffer(), { subset: false });
	const form = doc.getForm();
	for (const { f, v } of changedValues(fields, values)) {
		const x = form.getField(f.name);
		if (x instanceof lib.PDFTextField) {
			const max = x.getMaxLength();
			x.setText(max ? v.slice(0, max) : v);
		} else if (x instanceof lib.PDFCheckBox) if (v) x.check();
		else x.uncheck();
		else if (x instanceof lib.PDFRadioGroup) if (v) x.select(v);
		else x.clear();
		else if (x instanceof lib.PDFDropdown || x instanceof lib.PDFOptionList) if (v) x.select(v);
		else x.clear();
	}
	form.updateFieldAppearances(font);
	if (flatten) form.flatten();
	return new Blob([await doc.save()], { type: "application/pdf" });
}
/** Bake freely placed text and ticks into PDF pages. Coordinates are 0..1 from the page's top-left. */
async function addFreeFields(file, freeFields) {
	const { lib, doc } = await load(file);
	const pages = doc.getPages();
	const fields = freeFields.map((field) => normalizeFreeField(field, pages.length));
	let font;
	if (fields.some((field) => field.kind === "text" && field.value.trim())) {
		const fontkit = (await import("../_libs/pako+pdf-lib__fontkit+unenv.mjs").then((n) => n.t)).default;
		doc.registerFontkit(fontkit);
		const response = await fetch("/fonts/DejaVuSans.ttf");
		if (!response.ok) throw new Error("Không tải được phông chữ tiếng Việt.");
		font = await doc.embedFont(await response.arrayBuffer(), { subset: false });
	}
	for (const field of fields) {
		const page = pages[field.page];
		if (!page) continue;
		const { width, height } = page.getSize();
		const x = field.x * width, y = height - field.y * height;
		if (field.kind === "text") {
			const value = field.value.trim();
			if (!value || !font) continue;
			const size = field.fontSize ?? 14;
			page.drawText(value, {
				x,
				y: Math.max(0, y - size),
				size,
				font,
				color: lib.rgb(0, 0, 0),
				maxWidth: Math.max(1, width - x)
			});
		} else if (field.value) {
			const size = Math.max(9, field.fontSize ?? 14), bottom = Math.max(0, y - size);
			page.drawRectangle({
				x,
				y: bottom,
				width: size,
				height: size,
				borderWidth: 1,
				borderColor: lib.rgb(0, 0, 0)
			});
			page.drawLine({
				start: {
					x: x + size * .18,
					y: bottom + size * .52
				},
				end: {
					x: x + size * .43,
					y: bottom + size * .23
				},
				thickness: 1.8,
				color: lib.rgb(0, 0, 0)
			});
			page.drawLine({
				start: {
					x: x + size * .43,
					y: bottom + size * .23
				},
				end: {
					x: x + size * .86,
					y: bottom + size * .82
				},
				thickness: 1.8,
				color: lib.rgb(0, 0, 0)
			});
		}
	}
	return new Blob([await doc.save()], { type: "application/pdf" });
}
/** Lists the fillable boxes found in a PDF; saves a new PDF with the typed values. */
function PdfFormFiller({ file, fields, onClose }) {
	const [values, setValues] = (0, import_react.useState)(() => Object.fromEntries(fields.map((f) => [f.name, f.value])));
	const [flatten, setFlatten] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [previews, setPreviews] = (0, import_react.useState)([]);
	const [page, setPage] = (0, import_react.useState)(0);
	const [tool, setTool] = (0, import_react.useState)("text");
	const [freeFields, setFreeFields] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		let alive = true;
		pdfToImages(file, 1.1).then((images) => alive && setPreviews(images)).catch((e) => showError(e, "Xem trước PDF"));
		return () => {
			alive = false;
		};
	}, [file]);
	const set = (n, v) => setValues((s) => ({
		...s,
		[n]: v
	}));
	const multiPage = fields.some((f) => f.page > 0);
	const n = changedValues(fields, values).length;
	const total = n + freeFields.filter((field) => field.kind === "check" || field.value.trim()).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[90dvh] overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Điền biểu mẫu" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md border bg-muted/40 p-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-2 flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										size: "sm",
										variant: tool === "text" ? "default" : "outline",
										onClick: () => setTool("text"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Type, {}), " Chữ"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										size: "sm",
										variant: tool === "check" ? "default" : "outline",
										onClick: () => setTool("check"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquareCheckBig, {}), " Tick"]
									}),
									previews.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										"aria-label": "Trang PDF",
										value: page,
										onChange: (e) => setPage(Number(e.target.value)),
										className: "ml-auto h-8 rounded-md border bg-background px-2 text-xs",
										children: previews.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
											value: i,
											children: ["Trang ", i + 1]
										}, i))
									})
								]
							}),
							previews[page] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-label": `Đặt ô ${tool === "text" ? "chữ" : "tick"} trên trang ${page + 1}`,
								className: "relative block w-full overflow-hidden rounded-md border bg-background",
								onClick: (e) => {
									const box = e.currentTarget.getBoundingClientRect();
									setFreeFields((current) => [...current, {
										id: crypto.randomUUID(),
										kind: tool,
										page,
										x: (e.clientX - box.left) / box.width,
										y: (e.clientY - box.top) / box.height,
										value: tool === "check" ? "1" : "",
										fontSize: 14
									}]);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: previews[page],
									alt: `Trang ${page + 1}`,
									className: "block h-auto w-full"
								}), freeFields.filter((field) => field.page === page).map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pointer-events-none absolute grid min-h-5 min-w-5 place-items-center border border-primary bg-background/80 px-1 text-xs font-semibold text-primary",
									style: {
										left: `${field.x * 100}%`,
										top: `${field.y * 100}%`,
										transform: "translateY(-50%)"
									},
									children: field.kind === "check" ? "✓" : field.value || "Chữ"
								}, field.id))]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-36 place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-muted-foreground",
								children: "Chọn Chữ hoặc Tick, rồi chạm vị trí cần đặt trên trang."
							})
						]
					}),
					freeFields.map((field, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 rounded-md border p-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex shrink-0 items-center gap-1 text-xs font-semibold",
								children: [
									field.kind === "text" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Type, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquareCheckBig, { className: "size-4" }),
									" Trang ",
									field.page + 1
								]
							}),
							field.kind === "text" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								"aria-label": `Nội dung ô chữ ${index + 1}`,
								value: field.value,
								placeholder: "Nhập nội dung",
								onChange: (e) => setFreeFields((current) => current.map((item) => item.id === field.id ? {
									...item,
									value: e.target.value
								} : item)),
								className: "h-9"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1 text-xs",
								children: "Dấu tick"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "icon",
								"aria-label": "Xóa ô tự do",
								onClick: () => setFreeFields((current) => current.filter((item) => item.id !== field.id)),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
							})
						]
					}, field.id)),
					!fields.length && !freeFields.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-md border border-dashed p-3 text-center text-sm text-muted-foreground",
						children: "PDF không có ô điền sẵn. Hãy thêm ô chữ hoặc tick trên trang."
					}),
					fields.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [multiPage && (i === 0 || fields[i - 1].page !== f.page) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-1 mt-2 text-xs font-semibold opacity-70",
						children: ["Trang ", f.page + 1]
					}), f.kind === "check" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								disabled: f.readOnly,
								checked: !!values[f.name],
								onChange: (e) => set(f.name, e.target.checked ? "1" : ""),
								className: "h-5 w-5"
							}),
							" ",
							f.label
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs font-semibold",
							children: [f.label, f.readOnly ? " (chỉ đọc)" : ""]
						}),
						f.kind === "text" && (f.multiline ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							disabled: f.readOnly,
							value: values[f.name],
							onChange: (e) => set(f.name, e.target.value),
							className: "mt-1 min-h-20 w-full rounded-md border bg-background p-2 text-sm"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							disabled: f.readOnly,
							value: values[f.name],
							onChange: (e) => set(f.name, e.target.value),
							className: "mt-1 h-11"
						})),
						(f.kind === "select" || f.kind === "radio") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							disabled: f.readOnly,
							value: values[f.name],
							onChange: (e) => set(f.name, e.target.value),
							className: "mt-1 h-11 w-full rounded-md border bg-background px-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "— Chưa chọn —"
							}), f.options?.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: o,
								children: o
							}, o))]
						}),
						f.kind === "other" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs opacity-70",
							children: "Ô loại này (chữ ký số, nút bấm) chưa điền được."
						})
					] })] }, f.name)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: flatten,
							onChange: (e) => setFlatten(e.target.checked),
							className: "h-5 w-5"
						}), " Khóa nội dung (không sửa được nữa)"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "w-full",
						disabled: busy || !total,
						onClick: async () => {
							setBusy(true);
							try {
								const filled = n ? await fillFormFields(file, fields, values, flatten) : file;
								const out = freeFields.length ? await addFreeFields(filled, freeFields) : filled;
								download(out, `${safeName((file.name ?? "bieu-mau").replace(/\.pdf$/i, ""))}-da-dien.pdf`);
								toast.success(`Đã điền ${total} ô`);
								onClose();
							} catch (e) {
								showError(e, "Điền biểu mẫu");
							} finally {
								setBusy(false);
							}
						},
						children: [
							busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }),
							" ",
							total ? `Lưu PDF (${total} ô)` : "Chưa có nội dung để lưu"
						]
					})
				]
			})]
		})
	});
}
var STEPS = [
	"Chọn tệp",
	"Đọc từng trang",
	"Dựng tệp",
	"Kiểm tra & tải"
];
function ConvertProgress({ state }) {
	const [now, setNow] = (0, import_react.useState)(Date.now());
	(0, import_react.useEffect)(() => {
		if (!state) return;
		const t = setInterval(() => setNow(Date.now()), 500);
		return () => clearInterval(t);
	}, [state]);
	if (!state) return null;
	const frac = state.total ? state.done / state.total : 0;
	const pct = state.step === 1 ? 5 : state.step === 2 ? 10 + frac * 75 : 85 + frac * 15;
	const secs = Math.round((now - state.startedAt) / 1e3);
	const eta = state.step === 2 && state.done > 0 && state.done < state.total ? Math.max(1, Math.round((now - state.startedAt) / state.done * (state.total - state.done) / 1e3)) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-[92vw] rounded-[18px] sm:max-w-[400px] [&>button]:hidden",
			onInteractOutside: (e) => e.preventDefault(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-display",
					children: state.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Giữ màn hình này mở. Tệp được xử lý ngay trên máy bạn." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "space-y-2.5",
					children: STEPS.map((s, i) => {
						const n = i + 1;
						const active = n === state.step, ok = n < state.step;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `grid size-7 shrink-0 place-items-center rounded-full text-xs font-bold ${ok ? "bg-primary text-primary-foreground" : active ? "bg-secondary text-primary ring-2 ring-primary" : "bg-muted text-muted-foreground"}`,
								children: ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : n
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `text-sm ${active ? "font-semibold" : ok ? "" : "text-muted-foreground"}`,
								children: s
							})]
						}, s);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						value: pct,
						"aria-label": "Tiến độ chuyển đổi"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: state.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: eta ? `còn ~${eta}s` : `${secs}s` })]
					})]
				})
			]
		})
	});
}
var KEY = "gn-convert-guide-hidden";
/** Hướng dẫn 3 bước cho người dùng lần đầu, ẩn được. */
function ConvertGuide() {
	const [show, setShow] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setShow(localStorage.getItem(KEY) !== "1");
	}, []);
	if (!show) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mt-2.5 rounded-[14px] border bg-secondary/60 p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				"aria-label": "Ẩn hướng dẫn",
				className: "absolute right-0 top-0 rounded p-3 text-muted-foreground",
				onClick: () => {
					localStorage.setItem(KEY, "1");
					setShow(false);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-[0.8125rem] font-semibold",
				children: "Lần đầu chuyển đổi? Chỉ 3 bước"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-2 grid grid-cols-3 gap-2",
				children: [
					{
						icon: MousePointerClick,
						t: "Chọn kiểu đổi",
						d: "Ví dụ PDF → Excel"
					},
					{
						icon: FileSearch,
						t: "Chọn tệp",
						d: "Xem tiến độ từng trang"
					},
					{
						icon: Table2,
						t: "Kiểm tra rồi tải",
						d: "Ô vàng là chỗ cần xem lại"
					}
				].map(({ icon: Icon, t, d }, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-col gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5 text-[0.6875rem] font-bold text-primary",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3.5" }),
							i + 1,
							". ",
							t
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[0.65625rem] leading-4 text-muted-foreground",
						children: d
					})]
				}, t))
			})
		]
	});
}
var RED = [
	.82,
	.16,
	.12
];
var FONT_SIZE = 12;
var LINE_HEIGHT = 15;
var clamp = (value) => Math.max(0, Math.min(1, Number.isFinite(value) ? value : 0));
/** Coordinates are normalized from the top-left, so placement is preview-size independent. */
function normalizeAnnotation(annotation, pageCount) {
	const x = clamp(annotation.x), y = clamp(annotation.y);
	const normalized = {
		...annotation,
		page: Math.max(0, Math.min(Math.max(0, pageCount - 1), Math.floor(annotation.page || 0))),
		x,
		y,
		width: Math.min(1 - x, Math.max(.01, clamp(annotation.width))),
		height: Math.min(1 - y, Math.max(.01, clamp(annotation.height)))
	};
	if (annotation.text !== void 0) normalized.text = annotation.text.slice(0, 500);
	return normalized;
}
/** Normalized box (top-left origin) → PDF rect [x1, y1, x2, y2] (bottom-left origin). */
function toPdfRect(item, pageWidth, pageHeight) {
	const x1 = item.x * pageWidth, y2 = pageHeight - item.y * pageHeight;
	return [
		x1,
		y2 - item.height * pageHeight,
		x1 + item.width * pageWidth,
		y2
	];
}
/** PDF rect → normalized box; inverse of toPdfRect. */
function fromPdfRect(rect, pageWidth, pageHeight) {
	const [a, b, c, d] = rect;
	const x1 = Math.min(a, c), x2 = Math.max(a, c), y1 = Math.min(b, d), y2 = Math.max(b, d);
	return {
		x: clamp(x1 / pageWidth),
		y: clamp(1 - y2 / pageHeight),
		width: clamp((x2 - x1) / pageWidth),
		height: clamp((y2 - y1) / pageHeight)
	};
}
var blobBytes = (blob) => typeof blob.arrayBuffer === "function" ? blob.arrayBuffer() : new Promise((resolve, reject) => {
	const reader = new FileReader();
	reader.onload = () => resolve(reader.result);
	reader.onerror = () => reject(reader.error);
	reader.readAsArrayBuffer(blob);
});
var toBytes = async (file) => file instanceof Blob ? await blobBytes(file) : file;
function decodeText(lib, value) {
	if (value instanceof lib.PDFString || value instanceof lib.PDFHexString) return value.decodeText();
}
function annotsOf(lib, page) {
	const raw = page.node.lookup(lib.PDFName.of("Annots"));
	return raw instanceof lib.PDFArray ? raw : void 0;
}
function wrapLines(text, font, maxWidth) {
	const lines = [];
	for (const para of text.split(/\r?\n/)) {
		let line = "";
		for (const word of para.split(/\s+/).filter(Boolean)) {
			const next = line ? `${line} ${word}` : word;
			if (font && line && font.widthOfTextAtSize(next, FONT_SIZE) > maxWidth) {
				lines.push(line);
				line = word;
			} else line = next;
		}
		lines.push(line);
	}
	return lines;
}
function appearance(doc, lib, item, w, h, font, lines = []) {
	const ops = [
		lib.pushGraphicsState(),
		lib.setStrokingRgbColor(...RED),
		lib.setFillingRgbColor(...RED),
		lib.setLineWidth(2)
	];
	if (item.kind === "underline") ops.push(lib.moveTo(0, 1), lib.lineTo(w, 1), lib.stroke());
	else if (item.kind === "rectangle") ops.push(lib.rectangle(1, 1, Math.max(0, w - 2), Math.max(0, h - 2)), lib.stroke());
	else if (font) {
		ops.push(lib.beginText(), lib.setFontAndSize(lib.PDFName.of("F1"), FONT_SIZE));
		lines.forEach((line, i) => {
			ops.push(lib.setTextMatrix(1, 0, 0, 1, 2, h - 2 - FONT_SIZE - i * LINE_HEIGHT + 2), lib.showText(font.encodeText(line)));
		});
		ops.push(lib.endText());
	}
	ops.push(lib.popGraphicsState());
	const dict = { BBox: [
		0,
		0,
		w,
		h
	] };
	if (font) dict["Resources"] = { Font: { F1: font.ref } };
	return doc.context.register(doc.context.formXObject(ops, dict));
}
/** Read app annotations (and plain FreeText/Line/Square from other readers) back for editing. */
async function readPdfAnnotations(file) {
	const lib = await import("../_libs/pdf-lib+tslib.mjs").then((n) => n.t);
	const doc = await lib.PDFDocument.load(await toBytes(file), { ignoreEncryption: true });
	const out = [];
	doc.getPages().forEach((page, pageIndex) => {
		const annots = annotsOf(lib, page);
		if (!annots) return;
		const { width, height } = page.getSize();
		for (let i = 0; i < annots.size(); i++) {
			const dict = annots.lookup(i);
			if (!(dict instanceof lib.PDFDict)) continue;
			const subtype = dict.lookup(lib.PDFName.of("Subtype"));
			const kind = subtype === lib.PDFName.of("FreeText") ? "note" : subtype === lib.PDFName.of("Line") ? "underline" : subtype === lib.PDFName.of("Square") ? "rectangle" : null;
			const rect = dict.lookup(lib.PDFName.of("Rect"));
			if (!kind || !(rect instanceof lib.PDFArray)) continue;
			const nums = rect.asArray().map((n) => n instanceof lib.PDFNumber ? n.asNumber() : 0);
			const nm = decodeText(lib, dict.lookup(lib.PDFName.of("NM")));
			const box = fromPdfRect(nums, width, height);
			const item = {
				id: nm?.startsWith("gn:") ? nm.slice(3) : crypto.randomUUID(),
				kind,
				page: pageIndex,
				...box
			};
			if (kind === "note") item.text = decodeText(lib, dict.lookup(lib.PDFName.of("Contents"))) ?? "";
			out.push(item);
		}
	});
	return out;
}
/** Remove annotations this app is about to rewrite (gn: tagged, plus those read back as editable). */
function stripEditable(lib, page) {
	const annots = annotsOf(lib, page);
	if (!annots) return;
	const editable = new Set([
		"FreeText",
		"Line",
		"Square"
	].map((n) => lib.PDFName.of(n)));
	for (let i = annots.size() - 1; i >= 0; i--) {
		const dict = annots.lookup(i);
		if (dict instanceof lib.PDFDict && editable.has(dict.lookup(lib.PDFName.of("Subtype")))) annots.remove(i);
	}
}
/**
* Save annotations. Default: standard, editable PDF annotations replacing any previously
* editable ones. `flatten: true` keeps the G3-28 behaviour (drawn into page content).
*/
async function addPdfAnnotations(file, annotations, options = {}) {
	const lib = await import("../_libs/pdf-lib+tslib.mjs").then((n) => n.t);
	const doc = await lib.PDFDocument.load(await toBytes(file), { ignoreEncryption: true });
	const pages = doc.getPages();
	const normalized = annotations.map((item) => normalizeAnnotation(item, pages.length));
	let font;
	if (normalized.some((item) => item.kind === "note" && item.text?.trim())) {
		const fontkit = (await import("../_libs/pako+pdf-lib__fontkit+unenv.mjs").then((n) => n.t)).default;
		doc.registerFontkit(fontkit);
		const response = await fetch(new URL("/fonts/DejaVuSans.ttf", globalThis.location?.href ?? "http://localhost/"));
		if (!response.ok) throw new Error("Không tải được phông chữ tiếng Việt.");
		font = await doc.embedFont(await response.arrayBuffer(), { subset: false });
	}
	if (!options.flatten) pages.forEach((page) => stripEditable(lib, page));
	const now = lib.PDFString.fromDate(/* @__PURE__ */ new Date());
	for (const item of normalized) {
		const page = pages[item.page];
		if (!page) continue;
		const { width, height } = page.getSize();
		const [x1, y1, x2, y2] = toPdfRect(item, width, height);
		const text = item.text?.trim() ?? "";
		if (item.kind === "note" && (!text || !font)) continue;
		const lines = item.kind === "note" ? wrapLines(text, font, Math.max(20, width - x1 - 4)) : [];
		const w = item.kind === "note" ? Math.min(width - x1, Math.max(x2 - x1, ...lines.map((l) => font.widthOfTextAtSize(l, FONT_SIZE) + 4))) : x2 - x1;
		const h = item.kind === "note" ? Math.min(y2, Math.max(y2 - y1, lines.length * LINE_HEIGHT + 4)) : item.kind === "underline" ? Math.max(2, y2 - y1) : y2 - y1;
		if (options.flatten) {
			if (item.kind === "underline") page.drawLine({
				start: {
					x: x1,
					y: y2 - h
				},
				end: {
					x: x1 + w,
					y: y2 - h
				},
				thickness: 2,
				color: lib.rgb(...RED)
			});
			else if (item.kind === "rectangle") page.drawRectangle({
				x: x1,
				y: y2 - h,
				width: w,
				height: h,
				borderWidth: 2,
				borderColor: lib.rgb(...RED)
			});
			else if (font) page.drawText(text, {
				x: x1,
				y: Math.max(0, y2 - 13),
				size: FONT_SIZE,
				font,
				color: lib.rgb(...RED),
				maxWidth: Math.max(1, width - x1),
				lineHeight: LINE_HEIGHT
			});
			continue;
		}
		const base = {
			Type: "Annot",
			Rect: [
				x1,
				y2 - h,
				x1 + w,
				y2
			],
			NM: lib.PDFString.of("gn:" + item.id),
			M: now,
			F: 4,
			C: RED,
			T: lib.PDFHexString.fromText("Ghi Nhanh"),
			AP: { N: appearance(doc, lib, item, w, h, font, lines) }
		};
		if (item.kind === "underline") Object.assign(base, {
			Subtype: "Line",
			L: [
				x1,
				y2 - h + 1,
				x1 + w,
				y2 - h + 1
			],
			BS: { W: 2 }
		});
		else if (item.kind === "rectangle") Object.assign(base, {
			Subtype: "Square",
			BS: { W: 2 }
		});
		else Object.assign(base, {
			Subtype: "FreeText",
			Contents: lib.PDFHexString.fromText(text),
			DA: lib.PDFString.of(`/Helv ${FONT_SIZE} Tf ${RED.join(" ")} rg`)
		});
		const ref = doc.context.register(doc.context.obj(base));
		let annots = annotsOf(lib, page);
		if (!annots) {
			annots = doc.context.obj([]);
			page.node.set(lib.PDFName.of("Annots"), annots);
		}
		annots.push(ref);
	}
	return new Blob([await doc.save()], { type: "application/pdf" });
}
var LABEL = {
	note: "Ghi chú",
	underline: "Gạch chân",
	rectangle: "Hình khối"
};
function PdfAnnotator({ file, onClose }) {
	const [previews, setPreviews] = (0, import_react.useState)([]);
	const [page, setPage] = (0, import_react.useState)(0);
	const [tool, setTool] = (0, import_react.useState)("note");
	const [items, setItems] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [flatten, setFlatten] = (0, import_react.useState)(false);
	const [loaded, setLoaded] = (0, import_react.useState)(0);
	const start = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		let alive = true;
		pdfToImages(file, 1.1, .88, false).then((images) => alive && setPreviews(images)).catch((e) => showError(e, "Xem trước PDF"));
		readPdfAnnotations(file).then((found) => {
			if (!alive || !found.length) return;
			setItems(found);
			setLoaded(found.length);
			toast.info(`Đã mở ${found.length} chú thích có sẵn để sửa`);
		}).catch(() => {});
		return () => {
			alive = false;
		};
	}, [file]);
	const point = (e) => {
		const r = e.currentTarget.getBoundingClientRect();
		return {
			x: (e.clientX - r.left) / r.width,
			y: (e.clientY - r.top) / r.height
		};
	};
	const add = (from, to) => {
		if (tool === "note") setItems((all) => [...all, {
			id: crypto.randomUUID(),
			kind: tool,
			page,
			x: from.x,
			y: from.y,
			width: .45,
			height: .04,
			text: ""
		}]);
		else {
			const x = Math.min(from.x, to.x), y = Math.min(from.y, to.y);
			const width = Math.max(.03, Math.abs(to.x - from.x)), height = Math.max(tool === "underline" ? .012 : .03, Math.abs(to.y - from.y));
			setItems((all) => [...all, {
				id: crypto.randomUUID(),
				kind: tool,
				page,
				x,
				y,
				width,
				height
			}]);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (open) => !open && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[92dvh] overflow-y-auto sm:max-w-xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Chú thích PDF" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: tool === "note" ? "default" : "outline",
								onClick: () => setTool("note"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquareText, {}), " Ghi chú"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: tool === "underline" ? "default" : "outline",
								onClick: () => setTool("underline"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Highlighter, {}), " Gạch chân"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: tool === "rectangle" ? "default" : "outline",
								onClick: () => setTool("rectangle"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, {}), " Hình khối"]
							}),
							previews.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								"aria-label": "Trang PDF",
								value: page,
								onChange: (e) => setPage(Number(e.target.value)),
								className: "ml-auto h-8 rounded-md border bg-background px-2 text-xs",
								children: previews.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: i,
									children: ["Trang ", i + 1]
								}, i))
							})
						]
					}),
					previews[page] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						"aria-label": `Trang ${page + 1} để chú thích`,
						className: "relative touch-none overflow-hidden rounded-md border bg-background",
						onPointerDown: (e) => {
							start.current = point(e);
							e.currentTarget.setPointerCapture(e.pointerId);
						},
						onPointerUp: (e) => {
							if (!start.current) return;
							add(start.current, point(e));
							start.current = null;
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: previews[page],
							alt: `Trang ${page + 1}`,
							className: "pointer-events-none block h-auto w-full select-none"
						}), items.filter((item) => item.page === page).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `pointer-events-none absolute text-xs font-semibold text-destructive ${item.kind === "rectangle" ? "border-2 border-destructive" : item.kind === "underline" ? "border-b-2 border-destructive" : "bg-background/90 px-1"}`,
							style: {
								left: `${item.x * 100}%`,
								top: `${item.y * 100}%`,
								width: `${item.width * 100}%`,
								height: `${item.height * 100}%`
							},
							children: item.kind === "note" ? item.text || "Ghi chú" : ""
						}, item.id))]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-40 place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Chạm để đặt ghi chú; kéo trên trang để gạch chân hoặc khoanh vùng."
					}),
					items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 rounded-md border p-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "shrink-0 text-xs font-semibold",
								children: [
									LABEL[item.kind],
									" · Trang ",
									item.page + 1
								]
							}),
							item.kind === "note" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								"aria-label": `Nội dung ghi chú ${index + 1}`,
								value: item.text ?? "",
								placeholder: "Nhập ghi chú",
								onChange: (e) => setItems((all) => all.map((entry) => entry.id === item.id ? {
									...entry,
									text: e.target.value
								} : entry)),
								className: "h-9"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flex-1" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								"aria-label": "Xóa chú thích",
								onClick: () => setItems((all) => all.filter((entry) => entry.id !== item.id)),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
							})
						]
					}, item.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center justify-between gap-3 rounded-md border p-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: "Làm phẳng vào trang"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: flatten ? "Không sửa lại được sau khi lưu." : "Lưu dạng chú thích chuẩn PDF, mở lại để sửa được."
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: flatten,
							onCheckedChange: setFlatten,
							"aria-label": "Làm phẳng chú thích vào trang"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "w-full",
						disabled: busy || !loaded && !items.some((item) => item.kind !== "note" || item.text?.trim()),
						onClick: async () => {
							setBusy(true);
							try {
								const valid = items.filter((item) => item.kind !== "note" || item.text?.trim());
								const out = await addPdfAnnotations(file, valid, { flatten });
								download(out, `${safeName(file.name.replace(/\.pdf$/i, ""))}-chu-thich.pdf`);
								toast.success(`Đã lưu ${valid.length} chú thích`);
								onClose();
							} catch (e) {
								showError(e, "Chú thích PDF");
							} finally {
								setBusy(false);
							}
						},
						children: [
							busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }),
							" ",
							items.length ? `Lưu PDF (${items.length} mục)` : loaded ? "Lưu PDF (xóa hết chú thích)" : "Chưa có chú thích"
						]
					})
				]
			})]
		})
	});
}
function prefetchSigning() {
	if (navigator.connection?.saveData) return () => {};
	const id = window.setTimeout(() => {
		import("./digital-sign-dialog-DE4H7Ouz.mjs");
		import("./pdf-sign-B8m2eUFO.mjs");
	}, 4e3);
	return () => window.clearTimeout(id);
}
var DigitalSignDialog = (0, import_react.lazy)(() => import("./digital-sign-dialog-DE4H7Ouz.mjs").then((m) => ({ default: m.DigitalSignDialog })));
function Tools() {
	(0, import_react.useEffect)(prefetchSigning, []);
	const navigate = useNavigate();
	const online = useOnline();
	const importFiles = useImport();
	const [busy, setBusy] = (0, import_react.useState)("");
	const [review, setReview] = (0, import_react.useState)(null);
	const [conv, setConv] = (0, import_react.useState)(null);
	const startConv = (title) => setConv({
		title,
		step: 1,
		done: 0,
		total: 1,
		label: "Đang chuẩn bị…",
		startedAt: Date.now()
	});
	const onStep = (s) => setConv((c) => c && {
		...c,
		step: s.step === "build" ? 3 : 2,
		done: s.done,
		total: s.total,
		label: s.label
	});
	const building = () => setConv((c) => c && {
		...c,
		step: 3,
		done: 1,
		total: 1,
		label: "Đang dựng tệp…"
	});
	const [form, setForm] = (0, import_react.useState)(null);
	const [digitalSign, setDigitalSign] = (0, import_react.useState)(false);
	const [annotationFile, setAnnotationFile] = (0, import_react.useState)(null);
	const [result, setResult] = (0, import_react.useState)(null);
	const work = (label, fn) => async () => {
		setBusy(label);
		try {
			await fn();
		} catch (e) {
			console.error(e);
			showError(e, "Không xử lý được tập tin này");
		} finally {
			setBusy("");
			setConv(null);
		}
	};
	const scan = (mode) => () => navigate({
		to: "/scan",
		search: { mode }
	});
	const pdfTool = (tool) => () => importFiles("application/pdf,image/*", "PDF", tool);
	const tableFn = useQueuedServerFn(aiTable, "Đọc bảng");
	const layoutFn = useQueuedServerFn(aiLayout, "Đọc bố cục");
	const base = (f) => safeName(f.name.replace(/\.[^.]+$/, ""));
	const pickPdf = async () => (await pickFiles("application/pdf", false))[0];
	const groups = [
		{
			title: "Quét",
			tools: [
				{
					label: "Tài liệu",
					icon: ScanLine,
					run: scan("doc")
				},
				{
					label: "Thẻ ID",
					icon: IdCard,
					run: scan("id")
				},
				{
					label: "Sách",
					icon: BookOpen,
					run: scan("book")
				},
				{
					label: "Hộ chiếu",
					icon: BookUser,
					run: scan("passport")
				},
				{
					label: "Mã QR",
					icon: QrCode,
					run: scan("qr")
				},
				{
					label: "Ảnh thẻ",
					icon: IdCard,
					run: () => navigate({ to: "/id-photo" })
				},
				{
					label: "Hoá đơn / Biên lai",
					icon: Receipt,
					run: () => navigate({ to: "/receipts" })
				},
				{
					label: "Đánh giá ảnh chụp",
					icon: Sparkles,
					ai: true,
					run: () => navigate({ to: "/photo-check" })
				},
				{
					label: "QR từ ảnh",
					icon: QrCode,
					run: work("QR từ ảnh", async () => {
						const [f] = await pickFiles("image/*", false);
						if (!f) return;
						const v = await readCodeFromDataUrl(await fileToDataUrl(f));
						if (!v) {
							toast("Không tìm thấy mã QR trong ảnh này. Hãy chụp gần và rõ hơn.");
							return;
						}
						setResult({
							title: "Nội dung mã QR",
							text: v
						});
					})
				}
			]
		},
		{
			title: "Nhập",
			tools: [{
				label: "Nhập ảnh",
				icon: ImagePlus,
				run: () => importFiles("image/*", "Ảnh")
			}, {
				label: "Nhập PDF",
				icon: Upload,
				run: () => importFiles("application/pdf", "PDF")
			}]
		},
		{
			title: "Chuyển đổi",
			tools: [
				{
					label: "Ảnh → PDF",
					icon: FileText,
					run: work("Ảnh → PDF", async () => {
						const files = await pickFiles("image/*");
						if (!files.length) return;
						const srcs = await Promise.all(files.map(async (f) => normalize(f)));
						download(await imagesToPdf(srcs, { searchable: true }), "anh-sang-pdf.pdf");
						toast.success("Đã tạo PDF");
					})
				},
				{
					label: "PDF → Ảnh",
					icon: FileImage,
					run: work("PDF → Ảnh", async () => {
						const [f] = await pickFiles("application/pdf", false);
						if (!f) return;
						const imgs = await pdfToImages(f);
						for (const [i, src] of imgs.entries()) download(await dataUrlToBlob(src), `${safeName(f.name.replace(/\.pdf$/i, ""))}-${i + 1}.jpg`);
						toast.success(`Đã lưu ${imgs.length} ảnh`);
					})
				},
				{
					label: "Ảnh → Word",
					icon: FileTypeCorner,
					run: work("Ảnh → Word", async () => {
						const files = await pickFiles("image/*,application/pdf");
						if (!files.length) return;
						const srcs = [];
						await pmapOrdered(files, 3, (f) => f.type === "application/pdf" ? pdfToImages(f, 1.6) : normalize(f).then((x) => [x]), (r) => {
							srcs.push(...r);
						});
						const r = await imagesToWord(srcs, base(files[0]), layoutFn);
						setReview({
							kind: "word",
							title: r.title,
							blocks: r.blocks,
							note: r.note,
							source: {
								kind: "Ảnh → Word",
								name: files[0].name,
								blob: files[0]
							}
						});
					})
				},
				{
					label: "PDF → Word",
					icon: FileTypeCorner,
					run: work("PDF → Word", async () => {
						const f = await pickPdf();
						if (!f) return;
						startConv("PDF → Word");
						const pages = await readPdf(f, {
							onStep,
							warn: (m) => toast(m)
						});
						const n = pages.filter((p) => p.ocr).length;
						building();
						const r = pdfPagesToWord(pages, base(f));
						setReview({
							kind: "word",
							title: base(f),
							blocks: r.blocks,
							source: {
								kind: "PDF → Word",
								name: f.name,
								blob: f
							},
							note: n ? `${pages.length} trang · ${n} trang ảnh được nhận chữ` : `${pages.length} trang · lấy chữ trực tiếp từ PDF`
						});
					})
				},
				{
					label: "PDF → Excel",
					icon: FileSpreadsheet,
					run: work("PDF → Excel", async () => {
						const f = await pickPdf();
						if (!f) return;
						startConv("PDF → Excel");
						const pages = await readPdf(f, {
							onStep,
							table: tableFn,
							warn: (m) => toast(m)
						});
						const n = pages.filter((p) => p.ocr).length, ai = pages.filter((p) => p.ai).length;
						building();
						const r = pdfPagesToExcel(pages);
						setReview({
							kind: "excel",
							title: base(f),
							sheets: r.sheets,
							source: {
								kind: "PDF → Excel",
								name: f.name,
								blob: f
							},
							note: n ? `${pages.length} trang · ${ai ? `${ai} trang ảnh đọc bảng bằng AI` : `${n} trang ảnh được nhận chữ`}` : `${pages.length} trang · lấy chữ trực tiếp từ PDF`
						});
					})
				},
				{
					label: "Ảnh → Excel",
					icon: FileSpreadsheet,
					run: work("Ảnh → Excel", async () => {
						const files = await pickFiles("image/*,application/pdf");
						if (!files.length) return;
						startConv("Ảnh → Excel");
						const srcs = [];
						await pmapOrdered(files, 3, (f) => f.type === "application/pdf" ? pdfToImages(f, 2) : normalize(f, 2400).then((x) => [x]), (r) => {
							srcs.push(...r);
						});
						const pages = srcs.slice(0, 12);
						let title = base(files[0]);
						onStep({
							step: "scan",
							done: 0,
							total: pages.length,
							label: `Đang đọc ${pages.length} trang`
						});
						const tables = await imagesToTables(pages, tableFn, (m) => toast(m), (d, t) => onStep({
							step: "scan",
							done: d,
							total: t,
							label: `Đã đọc ${d}/${t} trang`
						}));
						if (tables[0]?.title) title = tables[0].title;
						building();
						const sheets = tables.map((t, i) => ({
							name: pages.length > 1 ? `Trang ${i + 1}` : t.title || "Bang",
							rows: t.rows
						}));
						if (srcs.length > pages.length) toast(`Chỉ lấy ${pages.length} trang đầu.`);
						setReview({
							kind: "excel",
							title,
							sheets,
							source: {
								kind: "Ảnh → Excel",
								name: files[0].name,
								blob: files[0]
							}
						});
					})
				},
				{
					label: "Excel → Word",
					icon: FileTypeCorner,
					run: work("Excel → Word", async () => {
						const [f] = await pickFiles(".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel", false);
						if (!f) return;
						let sheets;
						try {
							sheets = await readXlsx(f);
						} catch (e) {
							console.error(e);
							throw e instanceof XlsxError ? e : new XlsxError(String(e));
						}
						const full = sheets.filter((s) => s.rows.length), empty = sheets.length - full.length;
						if (!full.length) throw new XlsxError("empty");
						if (empty) toast(`Bỏ qua ${empty} sheet trống.`);
						const blocks = full.flatMap((s) => [block("heading", s.name, { level: 2 }), block("table", "", {
							rows: s.rows,
							merges: s.merges,
							red: s.red
						})]);
						setReview({
							kind: "word",
							title: base(f),
							blocks,
							note: `${full.length} sheet · giữ ô gộp và định dạng số`,
							source: {
								kind: "Excel → Word",
								name: f.name,
								blob: f
							}
						});
					})
				},
				{
					label: "Lịch sử chuyển đổi",
					icon: History,
					run: () => navigate({ to: "/tools/history" })
				}
			]
		},
		{
			title: "Chỉnh sửa PDF",
			tools: [
				{
					label: "Ghép PDF",
					icon: Combine,
					run: work("Ghép PDF", async () => {
						const files = await pickFiles("application/pdf");
						if (files.length < 2) {
							if (files.length) toast("Chọn ít nhất 2 tập tin PDF");
							return;
						}
						download(await mergePdfs(files), "da-ghep.pdf");
						toast.success(`Đã ghép ${files.length} tập tin`);
					})
				},
				{
					label: "Tách PDF",
					icon: Scissors,
					run: work("Tách PDF", async () => {
						const [f] = await pickFiles("application/pdf", false);
						if (!f) return;
						const parts = await splitPdf(f);
						parts.forEach((b, i) => download(b, `${safeName(f.name.replace(/\.pdf$/i, ""))}-trang-${i + 1}.pdf`));
						toast.success(`Đã tách thành ${parts.length} tập tin`);
					})
				},
				{
					label: "Nén PDF",
					icon: FileArchive,
					run: work("Nén PDF", async () => {
						const [f] = await pickFiles("application/pdf", false);
						if (!f) return;
						const imgs = await Promise.all((await pdfToImages(f, 1.4, .7)).map((s) => compress(s)));
						const out = await imagesToPdf(imgs, { size: "small" });
						download(out, `${safeName(f.name.replace(/\.pdf$/i, ""))}-nen.pdf`);
						toast.success(`Đã nén: ${(f.size / 1e6).toFixed(1)} MB → ${(out.size / 1e6).toFixed(1)} MB`);
					})
				},
				{
					label: "Xoay trang",
					icon: RotateCw,
					run: work("Xoay trang", async () => {
						const f = await pickPdf();
						if (!f) return;
						const n = await pdfPageCount(f);
						const v = await promptDialog("Xoay trang nào?", {
							message: `Tệp có ${n} trang. Giữ nguyên để xoay tất cả, hoặc nhập ví dụ 1,3-4. Mỗi lần xoay 90° theo chiều kim đồng hồ.`,
							defaultValue: n > 1 ? `1-${n}` : "1",
							okText: "Xoay"
						});
						if (v == null) return;
						download(await rotatePdf(f, 90, parsePages(v, n)), `${base(f)}-xoay.pdf`);
						toast.success("Đã xoay — chữ vẫn giữ nguyên chất lượng");
					})
				},
				{
					label: "Sắp trang",
					icon: ListOrdered,
					run: work("Sắp trang", async () => {
						const f = await pickPdf();
						if (!f) return;
						const n = await pdfPageCount(f);
						const v = await promptDialog("Thứ tự trang mới", {
							message: `Tệp có ${n} trang. Nhập thứ tự mong muốn, ví dụ 3,1,2 hoặc 1-5,8. Trang không ghi sẽ bị bỏ.`,
							defaultValue: n > 1 ? `1-${n}` : "1",
							okText: "Tạo tệp"
						});
						if (v == null) return;
						const order = parsePages(v, n);
						if (!order.length) {
							toast("Chưa nhập số trang hợp lệ");
							return;
						}
						download(await reorderPdf(f, order), `${base(f)}-sap-xep.pdf`);
						toast.success(`Đã tạo tệp ${order.length} trang`);
					})
				},
				{
					label: "Mật khẩu",
					icon: FileLock,
					run: pdfTool("export")
				},
				{
					label: "Hình mờ",
					icon: Stamp,
					run: work("Hình mờ", async () => {
						const f = await pickPdf();
						if (!f) return;
						const v = await promptDialog("Chữ hình mờ", {
							defaultValue: "BẢN SAO",
							okText: "Đóng dấu"
						});
						if (!v?.trim()) return;
						download(await watermarkPdf(f, v.trim()), `${base(f)}-hinh-mo.pdf`);
						toast.success("Đã đóng hình mờ lên mọi trang");
					})
				},
				{
					label: "Điền biểu mẫu",
					icon: ClipboardList,
					run: work("Điền biểu mẫu", async () => {
						const f = await pickPdf();
						if (!f) return;
						const fields = await readFormFields(f);
						setForm({
							file: f,
							fields
						});
					})
				},
				{
					label: "Ký tên",
					icon: PenLine,
					run: pdfTool("sign")
				},
				{
					label: "Ký số",
					icon: FileLock,
					run: () => setDigitalSign(true)
				},
				{
					label: "Kiểm tra chữ ký",
					icon: FileLock,
					run: work("Kiểm tra chữ ký", async () => {
						const f = await pickPdf();
						if (!f) return;
						const { verifyPdfSignature } = await import("./pdf-sign-B8m2eUFO.mjs");
						const r = verifyPdfSignature(new Uint8Array(await f.arrayBuffer()));
						const lines = [{
							valid: "✅ HỢP LỆ",
							modified: "⚠️ ĐÃ BỊ SỬA",
							invalid: "❌ KHÔNG HỢP LỆ",
							none: "— KHÔNG CÓ CHỮ KÝ"
						}[r.status], r.message];
						if (r.signer) lines.push(`Người ký: ${r.signer}`);
						if (r.signedAt) lines.push(`Thời điểm ký: ${r.signedAt.toLocaleString("vi-VN")}`);
						setResult({
							title: `Chữ ký số — ${f.name}`,
							text: lines.join("\n")
						});
					})
				},
				{
					label: "Chú thích",
					icon: Highlighter,
					run: work("Chú thích", async () => {
						const f = await pickPdf();
						if (f) setAnnotationFile(f);
					})
				}
			]
		},
		{
			title: "Tiện ích",
			tools: [
				{
					label: "Đếm số vật",
					icon: Hash,
					run: work("Đếm số vật", async () => {
						const [f] = await pickFiles("image/*", false);
						if (!f) return;
						const r = await countObjects(await normalize(f, 1600));
						setResult({
							title: `Đếm được ${r.count} vật`,
							image: r.image
						});
					})
				},
				{
					label: "Lọc ảnh tự động",
					icon: WandSparkles,
					run: pdfTool("filter")
				},
				{
					label: "Đo độ dài",
					icon: Ruler,
					run: () => navigate({ to: "/measure" })
				},
				{
					label: "Quét bằng điện thoại",
					icon: Smartphone,
					run: () => navigate({ to: "/pair" })
				}
			]
		},
		{
			title: "Trợ lý AI",
			tools: [
				{
					label: "Trích xuất AI",
					icon: ScanText,
					ai: true,
					run: () => importFiles("image/*,application/pdf", "Ảnh", "ai-extract")
				},
				{
					label: "Dịch văn bản",
					icon: Languages,
					ai: true,
					run: () => importFiles("image/*,application/pdf", "Ảnh", "ai-translate")
				},
				{
					label: "Giải bài tập",
					icon: Sparkles,
					ai: true,
					run: () => importFiles("image/*", "Bài tập", "ai-solve")
				},
				{
					label: "Tóm tắt",
					icon: FileText,
					ai: true,
					run: () => importFiles("image/*,application/pdf", "Ảnh", "ai-summarize")
				}
			]
		}
	];
	const [query, setQuery] = (0, import_react.useState)("");
	const [usesTick, setUsesTick] = (0, import_react.useState)(0);
	const all = groups.flatMap((g) => g.tools);
	const [favs, setFavs] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		setFavs(topUsed(all.map((x) => x.label)));
	}, [usesTick]);
	const shown = query.trim() ? [{
		title: "Kết quả tìm",
		tools: all.filter((x) => matchTool(x.label, query))
	}] : [...favs.length ? [{
		title: "Hay dùng",
		tools: favs.map((l) => all.find((x) => x.label === l))
	}] : [], ...groups];
	const use = (label, run) => {
		recordUse(label);
		setUsesTick((n) => n + 1);
		run?.();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		wide: true,
		title: "Công cụ",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rise px-5 pt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "relative block",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "search",
							value: query,
							onChange: (e) => setQuery(e.target.value),
							placeholder: "Tìm công cụ (vd: ghep pdf, anh word)",
							"aria-label": "Tìm công cụ",
							className: "h-11 w-full rounded-[12px] border border-border bg-background pl-9 pr-11 text-sm outline-none focus:ring-2 focus:ring-primary/40"
						}),
						query && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Xoá tìm kiếm",
							onClick: () => setQuery(""),
							className: "absolute right-0 top-0 grid size-11 place-items-center text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})
					]
				})
			}),
			shown[0]?.tools.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				role: "status",
				className: "px-5 pt-5 text-sm text-muted-foreground",
				children: [
					"Không thấy công cụ “",
					query.trim(),
					"”. Thử từ khác, ví dụ “pdf”, “ảnh”, “ký”."
				]
			}),
			shown.filter((g) => g.tools.length).map((g, gi) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: `rise px-5 pt-5`,
				style: { animationDelay: `${gi * .04}s` },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-[0.8125rem] font-semibold text-muted-foreground",
						children: g.title
					}),
					g.title === "Chuyển đổi" && !query.trim() && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConvertGuide, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2.5 grid grid-cols-4 gap-2 lg:grid-cols-8",
						children: g.tools.map(({ label, icon: Icon, run, ai }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							disabled: !!busy,
							onClick: () => use(label, run),
							title: ai && !online ? "Cần mạng — việc AI sẽ chờ tới khi có mạng" : void 0,
							className: "shortcut-tile relative flex h-[78px] min-w-0 flex-col items-center justify-center gap-1.5 rounded-[14px] px-1 active:scale-95 disabled:opacity-60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-9 place-items-center rounded-[10px] bg-secondary text-primary",
									children: busy === label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-[18px] animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-[18px]" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-full truncate text-center text-[0.65625rem] font-semibold",
									children: label
								}),
								ai && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"data-badge": online ? "ai" : "can-mang",
									className: `absolute right-1 top-1 rounded px-1 text-[0.5rem] font-bold ${online ? "bg-primary text-primary-foreground" : "bg-amber-500 text-white"}`,
									children: online ? "AI" : "Cần mạng"
								})
							]
						}, label))
					})
				]
			}, g.title)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConvertProgress, { state: conv }),
			form && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PdfFormFiller, {
				file: form.file,
				fields: form.fields,
				onClose: () => setForm(null)
			}),
			annotationFile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PdfAnnotator, {
				file: annotationFile,
				onClose: () => setAnnotationFile(null)
			}),
			digitalSign && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
				fallback: null,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DigitalSignDialog, {
					open: digitalSign,
					onClose: () => setDigitalSign(false)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportReview, {
				review,
				onClose: () => setReview(null)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!result,
				onOpenChange: (o) => !o && setResult(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-[92vw] rounded-[18px] sm:max-w-[400px]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "font-display",
							children: result?.title
						}) }),
						result?.image && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: result.image,
							alt: "Kết quả",
							className: "max-h-[60vh] w-full rounded-lg object-contain"
						}),
						result?.text != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "max-h-[50vh] overflow-auto whitespace-pre-wrap rounded-lg bg-muted p-3 font-sans text-xs leading-5",
							children: result.text || "Không tìm thấy chữ."
						})
					]
				})
			})
		]
	});
}
//#endregion
export { Tools as component };
