import { o as __toESM } from "../_runtime.mjs";
import { T as useNavigate, w as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { i as showError } from "./errors-DKvrPJ4v.mjs";
import { f as useUser } from "./auth-BEi9IFUJ.mjs";
import { Ht as CloudDownload, P as RefreshCw, S as Smartphone, Vt as CloudUpload, d as TriangleAlert, f as Trash2, nn as ArrowLeft } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-CZvf2xHx.mjs";
import { D as useDocs } from "./db-CclUQaLE.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { n as confirmDialog } from "./dialog-IcUxZaUZ.mjs";
import { i as syncAll, n as deleteAccountData, r as lastSyncAt, t as cloudStatus } from "./cloud-sync-DGtKTTqz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sync-EBiXPsFN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LABEL = {
	same: "Giống nhau",
	"local-only": "Chỉ có trên máy",
	"cloud-only": "Chỉ có trên mây",
	"local-newer": "Máy mới hơn",
	"cloud-newer": "Mây mới hơn",
	conflict: "Xung đột"
};
var t = (n) => n ? new Date(n).toLocaleString("vi-VN") : "—";
function SyncPage() {
	const { docs, trash } = useDocs();
	const { user } = useUser();
	const nav = useNavigate();
	const [rows, setRows] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)("");
	const [res, setRes] = (0, import_react.useState)({});
	const all = [...docs, ...trash];
	const refresh = (0, import_react.useCallback)(async () => {
		try {
			setRows(await cloudStatus([...docs, ...trash]));
		} catch (e) {
			showError(e, "Chưa xem được trạng thái");
		}
	}, [docs, trash]);
	(0, import_react.useEffect)(() => {
		if (user) refresh();
	}, [user, refresh]);
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Đồng bộ",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Back, {}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "px-5 pt-4 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/auth",
				className: "font-semibold text-primary",
				children: "Đăng nhập"
			}), " để đồng bộ."]
		})
	});
	const conflicts = rows?.filter((r) => r.state === "conflict") ?? [];
	const count = (s) => rows?.filter((r) => r.state === s).length ?? 0;
	const pending = conflicts.filter((c) => !res[c.id]).length;
	async function run() {
		setBusy("Đang chuẩn bị…");
		try {
			const r = await syncAll(all, setBusy, res);
			if (r.failed.length) toast.error(`Chưa đồng bộ được ${r.failed.length} tài liệu`, { description: r.failed.slice(0, 3).join(", ") });
			else toast.success(`Đã tải về ${r.received} · tải lên ${r.sent} tài liệu`);
			setRes({});
			await refresh();
		} catch (e) {
			showError(e, "Chưa đồng bộ được");
		} finally {
			setBusy("");
		}
	}
	async function removeAccount() {
		if (!await confirmDialog("Xoá tài khoản và dữ liệu trên mây?", {
			message: "Tài liệu trên máy này vẫn giữ nguyên. Dữ liệu trên mây và tài khoản bị xoá hẳn.",
			okText: "Xoá tài khoản",
			danger: true
		})) return;
		setBusy("Đang xoá…");
		try {
			await deleteAccountData();
			toast("Đã xoá tài khoản");
			nav({ to: "/me" });
		} catch (e) {
			showError(e, "Chưa xoá được tài khoản");
		} finally {
			setBusy("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Đồng bộ",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Back, {}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "space-y-4 px-5 pb-28 pt-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						user.email,
						" · lần đồng bộ trước: ",
						t(lastSyncAt())
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2 text-sm",
					children: [
						"same",
						"local-newer",
						"cloud-newer",
						"local-only",
						"cloud-only",
						"conflict"
					].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border bg-card p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xl font-bold",
							children: rows ? count(s) : "…"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: LABEL[s]
						})]
					}, s))
				}),
				conflicts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "flex items-center gap-2 text-sm font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 text-destructive" }), " Sửa ở cả hai nơi — chọn bản giữ lại"]
						}),
						conflicts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border bg-card p-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium",
									children: c.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground",
									children: [
										"Máy: ",
										t(c.localAt),
										" · Mây: ",
										t(c.cloudAt)
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: res[c.id] === "local" ? "default" : "outline",
										onClick: () => setRes({
											...res,
											[c.id]: "local"
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, {}), " Bản trên máy"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: res[c.id] === "cloud" ? "default" : "outline",
										onClick: () => setRes({
											...res,
											[c.id]: "cloud"
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudDownload, {}), " Bản trên mây"]
									})]
								})
							]
						}, c.id)),
						pending > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								"Chưa chọn ",
								pending,
								" tài liệu — sẽ dùng bản sửa sau cùng."
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "flex-1",
						disabled: !!busy,
						onClick: run,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, {}),
							" ",
							busy || "Đồng bộ ngay"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						disabled: !!busy,
						onClick: refresh,
						"aria-label": "Làm mới",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-t pt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						className: "w-full text-destructive",
						disabled: !!busy,
						onClick: removeAccount,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Xoá tài khoản"]
					})
				})
			]
		})
	});
}
function Back() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/me",
		"aria-label": "Về trang Tôi",
		className: "grid size-10 place-items-center rounded-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
	});
}
//#endregion
export { SyncPage as component };
