import { n as machineLanes } from "./machine-lanes-xhX0UZ2n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ordered-pool-BPbz5dnO.js
async function* orderedPool(items, limit, fn) {
	const n = Math.max(1, Math.floor(limit)), started = [];
	const start = (i) => {
		if (i < items.length) {
			const p = fn(items[i], i);
			p.catch(() => {});
			started[i] = p;
		}
	};
	for (let i = 0; i < Math.min(n, items.length); i++) start(i);
	for (let i = 0; i < items.length; i++) {
		const r = await started[i];
		start(i + n);
		yield r;
	}
}
function pdfLanes() {
	return machineLanes();
}
//#endregion
export { orderedPool, pdfLanes };
