import { n as suggestFilter } from "./filter-suggest-C3Br7JC3.mjs";
import { t as gradePage } from "./post-capture-metrics-X7ExzflM.mjs";
import { preferredFilter } from "./user-recipe-DhO7F1JT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/recipe-apply-CyLpFKW0.js
/** Loại giấy tờ có ảnh/màu quan trọng (con dấu đỏ, ảnh chân dung) → tránh đen trắng. */
var COLOR_DOCS = /* @__PURE__ */ new Set([
	"sodo",
	"banglai",
	"xe",
	"khaisinh"
]);
/** Loại thuần chữ → ưu tiên rõ chữ, nhẹ tệp. */
var TEXT_DOCS = /* @__PURE__ */ new Set(["hopdong", "vat"]);
function pickRecipe(m, docTypeId) {
	const grade = gradePage(m);
	const sug = suggestFilter(m);
	const deskew = Math.abs(m.skew) > 1;
	const denoise = m.blur < 25 || m.brightness < 80;
	let filter = sug && sug.confidence >= .4 ? sug.filter : grade.level === "tot" ? "magic" : "auto";
	let reason = sug && sug.confidence >= .4 ? sug.reason : grade.level === "tot" ? "trang tốt, làm nét chữ" : "cân bằng chung";
	if (docTypeId && COLOR_DOCS.has(docTypeId) && (filter === "mono" || filter === "ink" || filter === "eco")) {
		filter = "vivid";
		reason = "giữ màu con dấu/ảnh";
	} else if (docTypeId && TEXT_DOCS.has(docTypeId) && filter === "magic") {
		filter = "sharp";
		reason = "tài liệu chữ, làm rõ chữ";
	}
	return {
		filter,
		deskew,
		denoise,
		reason
	};
}
function planRecipes(doc, before, metrics, defaultFilter, docTypeId, learned) {
	if (doc.locked) return [];
	const learned_ = docTypeId && learned ? preferredFilter(learned, docTypeId) : null;
	const out = [];
	for (const p of doc.pages) {
		if (before.has(p.id) || p.edit.filter !== defaultFilter) continue;
		const m = metrics.get(p.id);
		if (!m) continue;
		const r = pickRecipe(m, docTypeId);
		const to = learned_ ?? r.filter;
		const reason = learned_ ? "theo thói quen của bạn" : r.reason;
		if (to !== p.edit.filter) out.push({
			pageId: p.id,
			from: p.edit.filter,
			to,
			reason
		});
	}
	return out;
}
/** Áp thay đổi vào danh sách trang (bất biến). Trang đã bị người dùng đổi bộ lọc trong lúc chờ → bỏ qua. */
function applyRecipes(pages, changes) {
	if (!changes.length) return pages;
	const by = new Map(changes.map((c) => [c.pageId, c]));
	return pages.map((p) => {
		const c = by.get(p.id);
		if (!c || p.edit.filter !== c.from) return p;
		return {
			...p,
			edit: {
				...p.edit,
				filter: c.to
			},
			status: "dang",
			autoFilter: {
				from: c.from,
				to: c.to,
				reason: c.reason
			}
		};
	});
}
//#endregion
export { applyRecipes, planRecipes };
