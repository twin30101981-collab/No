import { o as __toESM } from "../_runtime.mjs";
import { w as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { J as Lock, Xt as Check, f as Trash2, qt as ChevronRight, w as Share2 } from "../_libs/lucide-react.mjs";
import { T as timeAgo, a as docSize } from "./db-CclUQaLE.mjs";
import { a as baseName } from "./library-BIMZUn1d.mjs";
import { r as useThumb } from "./thumbs-Bxe3hgYK.mjs";
import { i as TagChip } from "./library-ui-BCoN_d8a.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/doc-row-BD9Y5xLI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Document row: swipe left for share/delete, long-press to multi-select. */
var DocRow = (0, import_react.memo)(function DocRow({ doc, selectMode, selected, onLongPress, onToggle, onDelete, onShare, grid }) {
	const [dx, setDx] = (0, import_react.useState)(0);
	const start = (0, import_react.useRef)(null);
	const timer = (0, import_react.useRef)(0);
	const moved = (0, import_react.useRef)(false);
	const small = useThumb(doc);
	const thumb = doc.locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "document-thumb grid h-full w-full place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-5 text-primary" })
	}) : doc.pages[0] ? small ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: small,
		alt: "",
		loading: "lazy",
		decoding: "async",
		className: "h-full w-full object-cover"
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "document-thumb h-full w-full animate-pulse" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "document-thumb h-full w-full" });
	const handlers = {
		draggable: true,
		onDragStart: (e) => {
			clearTimeout(timer.current);
			e.dataTransfer.setData("text/doc-id", doc.id);
		},
		onPointerDown: (e) => {
			start.current = {
				x: e.clientX,
				y: e.clientY
			};
			moved.current = false;
			timer.current = window.setTimeout(() => {
				moved.current = true;
				navigator.vibrate?.(15);
				onLongPress?.();
			}, 480);
		},
		onPointerMove: (e) => {
			if (!start.current) return;
			const x = e.clientX - start.current.x, y = e.clientY - start.current.y;
			if (Math.abs(x) > 8 || Math.abs(y) > 8) clearTimeout(timer.current);
			if (!grid && !selectMode && Math.abs(x) > Math.abs(y) && Math.abs(x) > 10) {
				moved.current = true;
				setDx(Math.max(-132, Math.min(0, x + (dx < 0 ? -132 : 0))));
			}
		},
		onPointerUp: () => {
			clearTimeout(timer.current);
			start.current = null;
			setDx((v) => v < -60 ? -132 : 0);
		},
		onPointerCancel: () => {
			clearTimeout(timer.current);
			start.current = null;
		},
		onClickCapture: (e) => {
			if (moved.current || dx < 0) {
				e.preventDefault();
				e.stopPropagation();
				if (dx < 0 && !moved.current) setDx(0);
				return;
			}
			if (selectMode) {
				e.preventDefault();
				onToggle?.();
			}
		}
	};
	if (grid) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/doc/$id",
		params: { id: doc.id },
		...handlers,
		className: `document-row relative block select-none overflow-hidden rounded-[14px] p-2 ${selected ? "ring-2 ring-primary" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "aspect-[3/4] overflow-hidden rounded-[8px] bg-muted",
				children: thumb
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 truncate text-xs font-semibold",
				children: doc.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "truncate text-[0.625rem] text-muted-foreground",
				children: [
					doc.pages.length,
					" trang · ",
					timeAgo(doc.updatedAt)
				]
			}),
			selectMode && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectDot, { on: !!selected })
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative overflow-hidden rounded-[16px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `absolute inset-y-0 right-0 flex w-[132px] transition-opacity ${dx < 0 ? "" : "pointer-events-none opacity-0"}`,
			inert: dx < 0 ? void 0 : true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				"aria-label": "Chia sẻ",
				onClick: () => {
					setDx(0);
					onShare?.();
				},
				className: "grid flex-1 place-items-center bg-secondary text-primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				"aria-label": "Xóa",
				onClick: () => {
					setDx(0);
					onDelete?.();
				},
				className: "grid flex-1 place-items-center bg-destructive text-destructive-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-5" })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/doc/$id",
			params: { id: doc.id },
			...handlers,
			style: { transform: `translateX(${dx}px)` },
			className: `document-row relative grid w-full touch-pan-y select-none grid-cols-[52px_minmax(0,1fr)_auto] items-center gap-3 rounded-[16px] p-2.5 transition-transform ${selected ? "ring-2 ring-primary" : ""}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-[68px] w-[52px] overflow-hidden rounded-[8px] bg-muted",
					children: thumb
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-semibold",
							children: doc.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 truncate text-[0.6875rem] text-muted-foreground",
							children: [
								doc.pages.length,
								" trang · ",
								docSize(doc),
								" · ",
								timeAgo(doc.updatedAt)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1.5 flex min-w-0 gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate rounded-md bg-secondary px-1.5 py-0.5 text-[0.625rem] font-bold text-primary",
									children: doc.kind
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate rounded-md bg-muted px-1.5 py-0.5 text-[0.625rem] text-muted-foreground",
									children: baseName(doc.folder)
								}),
								doc.tags?.slice(0, 2).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagChip, { name: t }, t)),
								(doc.tags?.length ?? 0) > 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "shrink-0 text-[0.625rem] text-muted-foreground",
									children: ["+", doc.tags.length - 2]
								}),
								doc.pages.some((p) => p.text) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 rounded-md bg-muted px-1.5 py-0.5 text-[0.625rem] text-muted-foreground",
									children: "Đã OCR"
								})
							]
						})
					]
				}),
				selectMode ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectDot, {
					on: !!selected,
					inline: true
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 shrink-0 text-muted-foreground" })
			]
		})]
	});
});
function SelectDot({ on, inline }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `${inline ? "" : "absolute right-3 top-3"} grid size-6 shrink-0 place-items-center rounded-full border-2 ${on ? "border-primary bg-primary text-primary-foreground" : "border-muted-foreground/40 bg-card"}`,
		children: on && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" })
	});
}
//#endregion
export { DocRow as t };
