import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { i as cloudReady, t as NO_CLOUD } from "./auth-BEi9IFUJ.mjs";
import { i as fpOf } from "./disk-pack-ZdDKsocx.mjs";
import { t as safeSet } from "./safe-storage-DnXnZPA0.mjs";
import { b as readTombstones, n as clearTombstones } from "./db-CclUQaLE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cloud-sync-DGtKTTqz.js
var cloud_map_exports = /* @__PURE__ */ __exportAll({
	PAGE_BUCKET: () => PAGE_BUCKET,
	docToRow: () => docToRow,
	folderPaths: () => folderPaths,
	pagePath: () => pagePath,
	pagesToRows: () => pagesToRows,
	rowToDoc: () => rowToDoc
});
var PAGE_BUCKET = "pages";
function pagePath(userId, docId, pageId, kind) {
	const safe = (s) => s.replace(/[^a-zA-Z0-9_-]/g, "_");
	return `${userId}/${safe(docId)}/${safe(pageId)}-${kind}.jpg`;
}
function docToRow(d) {
	return {
		local_id: d.id,
		name: d.name,
		folder: d.folder ?? "",
		kind: d.kind,
		tags: d.tags ?? [],
		fields: d.fields ?? {},
		locked: !!d.locked,
		created_at: new Date(d.createdAt).toISOString(),
		deleted_at: d.deletedAt ? new Date(d.deletedAt).toISOString() : null,
		client_updated_at: d.updatedAt
	};
}
function pagesToRows(userId, d) {
	return d.pages.map((p, i) => ({
		local_id: p.id,
		position: i,
		edit: p.edit,
		text: p.text ?? null,
		orig_path: pagePath(userId, d.id, p.id, "orig"),
		src_path: pagePath(userId, d.id, p.id, "src")
	}));
}
/** Dựng lại Doc từ hàng đám mây; ảnh (orig/src) điền sau khi tải về. */
function rowToDoc(r, pages) {
	return {
		id: r.local_id,
		name: r.name,
		folder: r.folder,
		kind: r.kind,
		createdAt: Date.parse(r.created_at),
		updatedAt: r.client_updated_at || Date.parse(r.updated_at),
		...r.tags.length ? { tags: r.tags } : {},
		...Object.keys(r.fields ?? {}).length ? { fields: r.fields } : {},
		...r.locked ? { locked: true } : {},
		...r.deleted_at ? { deletedAt: Date.parse(r.deleted_at) } : {},
		pages: [...pages].sort((a, b) => a.position - b.position).map((p) => ({
			id: p.local_id,
			orig: "",
			src: "",
			edit: p.edit,
			...p.text != null ? { text: p.text } : {}
		}))
	};
}
/** Thư mục cha của mọi tài liệu ("a/b/c" -> a, a/b, a/b/c). */
function folderPaths(docs) {
	const out = /* @__PURE__ */ new Set();
	for (const d of docs) {
		const parts = (d.folder ?? "").split("/").filter(Boolean);
		for (let i = 1; i <= parts.length; i++) out.add(parts.slice(0, i).join("/"));
	}
	return [...out].sort();
}
var KEY = "gn-sync-up";
function readSyncState(uid) {
	try {
		return JSON.parse(localStorage.getItem(`${KEY}:${uid}`) ?? "");
	} catch {
		return {
			docs: {},
			imgs: {}
		};
	}
}
function writeSyncState(uid, s) {
	safeSet(`${KEY}:${uid}`, JSON.stringify(s));
}
/** Dấu vân tay rẻ của ảnh data URL (độ dài + vài đoạn mẫu). */
/** S15f3b: object URL dùng dấu vân tay đã lưu kèm (disk-pack), data URL tính như cũ. */
var fingerprint = fpOf;
/** Tài liệu cần gửi: mới hoặc sửa sau lần gửi trước. */
function plan(docs, st) {
	return docs.filter((d) => (st.docs[d.id] ?? -1) < d.updatedAt);
}
/** Ảnh cần gửi của một tài liệu (đường dẫn kho -> data URL). */
function imagesToSend(uid, d, st) {
	const rows = pagesToRows(uid, d);
	const out = [];
	d.pages.forEach((p, i) => {
		const r = rows[i];
		for (const [path, data] of [[r.orig_path, p.orig], [r.src_path, p.src]]) {
			if (!data) continue;
			const fp = fingerprint(data);
			if (st.imgs[path] !== fp) out.push({
				path,
				data,
				fp
			});
		}
	});
	return out;
}
async function toBlob(data) {
	return (await fetch(data)).blob();
}
var must = (r) => {
	if (r.error) throw r.error;
	return r;
};
/** BL-05b: thu hồi mọi liên kết chia sẻ còn hiệu lực của một tài liệu trên mây. */
async function revokeLinks(supabase, documentId) {
	must(await supabase.from("share_links").update({ revoked_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("document_id", documentId).is("revoked_at", null));
}
/** BL-05b: gỡ hẳn bản trên mây của một tài liệu (xoá hẳn trên máy, hoặc tài liệu đã khoá PIN — QD-5): thu hồi liên kết, xoá ảnh, trang, hàng. */
async function removeRemote(supabase, localId, st) {
	const { data: row } = must(await supabase.from("documents").select("id").eq("local_id", localId).maybeSingle());
	if (row) {
		await revokeLinks(supabase, row.id);
		const { data: pg } = must(await supabase.from("pages").select("orig_path,src_path").eq("document_id", row.id));
		const paths = (pg ?? []).flatMap((p) => [p.orig_path, p.src_path]).filter((x) => !!x);
		for (let i = 0; i < paths.length; i += 100) must(await supabase.storage.from(PAGE_BUCKET).remove(paths.slice(i, i + 100)));
		must(await supabase.from("pages").delete().eq("document_id", row.id));
		must(await supabase.from("documents").delete().eq("id", row.id));
		for (const p of paths) delete st.imgs[p];
	}
	delete st.docs[localId];
}
async function uploadAll(docs, onProgress, opts = {}) {
	if (!cloudReady()) throw new Error(NO_CLOUD);
	const { supabase } = await import("./client-D3MSxqCj.mjs").then((n) => n.t).then((n) => n.t);
	const { data: u } = await supabase.auth.getUser();
	const uid = u.user?.id;
	if (!uid) throw new Error("Hãy đăng nhập trước khi đồng bộ");
	const st = readSyncState(uid);
	const failed = [], rmFailed = [];
	const { getDocs } = await import("./db-CclUQaLE.mjs").then((n) => n.r).then((n) => n.n);
	const local = new Set([...docs, ...getDocs()].map((d) => d.id));
	const gone = Object.keys(readTombstones()).filter((id) => !local.has(id));
	const lockedSent = docs.filter((d) => d.locked && st.docs[d.id] !== void 0).map((d) => d.id);
	const cleared = [];
	for (const id of [...gone, ...lockedSent]) try {
		await removeRemote(supabase, id, st);
		if (!local.has(id)) cleared.push(id);
	} catch {
		rmFailed.push(docs.find((d) => d.id === id)?.name || id);
	}
	clearTombstones(cleared);
	writeSyncState(uid, st);
	const base = new Set(plan(docs, st).map((d) => d.id));
	const todo = docs.filter((d) => !d.enc && !d.locked).filter((d) => base.has(d.id) && !opts.skip?.has(d.id) || opts.force?.has(d.id));
	let done = 0;
	onProgress?.(0, todo.length);
	const folders = folderPaths(docs);
	if (folders.length) await supabase.from("folders").upsert(folders.map((path) => ({
		path,
		user_id: uid
	})), {
		onConflict: "user_id,path",
		ignoreDuplicates: true
	});
	for (const d of todo) {
		try {
			if (d.deletedAt && st.docs[d.id] === void 0) {
				onProgress?.(++done, todo.length);
				continue;
			}
			if (d.deletedAt) {
				const { data: row } = must(await supabase.from("documents").upsert({
					...docToRow(d),
					user_id: uid
				}, { onConflict: "user_id,local_id" }).select("id").single());
				if (!row) throw new Error("upsert");
				await revokeLinks(supabase, row.id);
				st.docs[d.id] = d.updatedAt;
				writeSyncState(uid, st);
				onProgress?.(++done, todo.length);
				continue;
			}
			for (const img of imagesToSend(uid, d, st)) {
				const { error } = await supabase.storage.from(PAGE_BUCKET).upload(img.path, await toBlob(img.data), {
					upsert: true,
					contentType: "image/jpeg"
				});
				if (error) throw error;
				st.imgs[img.path] = img.fp;
			}
			const { data: row, error } = await supabase.from("documents").upsert({
				...docToRow(d),
				user_id: uid
			}, { onConflict: "user_id,local_id" }).select("id").single();
			if (error || !row) throw error ?? /* @__PURE__ */ new Error("upsert");
			const pages = pagesToRows(uid, d).map((p) => ({
				...p,
				edit: p.edit,
				user_id: uid,
				document_id: row.id
			}));
			if (pages.length) {
				const { error: e2 } = await supabase.from("pages").upsert(pages, { onConflict: "document_id,local_id" });
				if (e2) throw e2;
			}
			const keep = pages.map((p) => p.local_id);
			let del = supabase.from("pages").delete().eq("document_id", row.id);
			if (keep.length) del = del.not("local_id", "in", `(${keep.map((k) => `"${k}"`).join(",")})`);
			await del;
			st.docs[d.id] = d.updatedAt;
			writeSyncState(uid, st);
		} catch {
			failed.push(d.name || d.id);
		}
		onProgress?.(++done, todo.length);
	}
	writeSyncState(uid, st);
	return {
		sent: todo.length - failed.length,
		failed: [...rmFailed, ...failed],
		upFailed: failed,
		skipped: docs.length - todo.length,
		removed: cleared.length + lockedSent.length - rmFailed.length
	};
}
/** Bản nào sửa sau cùng (giờ sửa trên máy) thì thắng. Trả về tài liệu cần tải về. */
function pullPlan(local, remote) {
	const m = new Map(local.map((d) => [d.id, d.updatedAt]));
	return remote.filter((r) => {
		const t = r.client_updated_at || Date.parse(r.updated_at);
		const mine = m.get(r.local_id);
		return mine === void 0 || mine < t;
	});
}
async function blobToDataUrl(b) {
	return new Promise((res, rej) => {
		const fr = new FileReader();
		fr.onload = () => res(fr.result);
		fr.onerror = () => rej(fr.error);
		fr.readAsDataURL(b);
	});
}
async function downloadAll(local, onProgress, opts = {}) {
	if (!cloudReady()) throw new Error(NO_CLOUD);
	const { supabase } = await import("./client-D3MSxqCj.mjs").then((n) => n.t).then((n) => n.t);
	const { rowToDoc } = await Promise.resolve().then(() => cloud_map_exports);
	const { saveDocs, loadDocs } = await import("./db-CclUQaLE.mjs").then((n) => n.r).then((n) => n.n);
	const { data: u } = await supabase.auth.getUser();
	const uid = u.user?.id;
	if (!uid) throw new Error("Hãy đăng nhập trước khi đồng bộ");
	const { data: rows, error } = await supabase.from("documents").select("*");
	if (error) throw error;
	const base = new Set(pullPlan(local, rows ?? []).map((r) => r.local_id));
	const tomb = readTombstones();
	const localIds = new Set(local.map((d) => d.id));
	const lockedIds = new Set(local.filter((d) => d.locked).map((d) => d.id));
	const todo = (rows ?? []).filter((r) => !(r.local_id in tomb && !localIds.has(r.local_id)) && !lockedIds.has(r.local_id)).filter((r) => base.has(r.local_id) && !opts.skip?.has(r.local_id) || opts.force?.has(r.local_id));
	const st = readSyncState(uid);
	const failed = [];
	const got = [];
	let done = 0;
	onProgress?.(0, todo.length);
	const localById = new Map(local.map((d) => [d.id, d]));
	for (const r of todo) {
		const row = (rows ?? []).find((x) => x.id === r.id);
		try {
			const { data: pages, error: e1 } = await supabase.from("pages").select("*").eq("document_id", r.id);
			if (e1) throw e1;
			const doc = rowToDoc(row, pages ?? []);
			const old = localById.get(doc.id);
			for (const [i, p] of doc.pages.entries()) {
				const pr = [...pages ?? []].sort((a, b) => a.position - b.position)[i];
				const prev = old?.pages.find((x) => x.id === p.id);
				for (const k of ["orig", "src"]) {
					const path = k === "orig" ? pr.orig_path : pr.src_path;
					if (!path) continue;
					const prevData = prev?.[k];
					if (prevData && st.imgs[path] === fingerprint(prevData)) {
						p[k] = prevData;
						continue;
					}
					const { data: b, error: e2 } = await supabase.storage.from(PAGE_BUCKET).download(path);
					if (e2 || !b) {
						if (k === "src" && p.orig) {
							p.src = p.orig;
							continue;
						}
						throw e2 ?? /* @__PURE__ */ new Error("ảnh");
					}
					p[k] = await blobToDataUrl(b);
					st.imgs[path] = fingerprint(p[k]);
				}
				if (!p.src) p.src = p.orig;
				if (!p.orig) p.orig = p.src;
			}
			got.push(doc);
			st.docs[doc.id] = doc.updatedAt;
		} catch {
			failed.push(row.name || row.local_id);
		}
		onProgress?.(++done, todo.length);
	}
	if (got.length) {
		await saveDocs(got);
		await loadDocs();
	}
	writeSyncState(uid, st);
	return {
		received: got.length,
		failed
	};
}
/** Đồng bộ hai chiều: tải về bản mới hơn trước, rồi gửi bản trên máy mới hơn. */
async function syncAll(local, onProgress, res = {}) {
	const keepCloud = new Set(Object.keys(res).filter((k) => res[k] === "cloud"));
	const keepLocal = new Set(Object.keys(res).filter((k) => res[k] === "local"));
	const down = await downloadAll(local, (d, t) => onProgress?.(t ? `Đang tải về ${d}/${t}` : "Đang kiểm tra…"), {
		skip: keepLocal,
		force: keepCloud
	});
	const { getDocs } = await import("./db-CclUQaLE.mjs").then((n) => n.r).then((n) => n.n);
	const up = await uploadAll(getDocs(), (d, t) => onProgress?.(t ? `Đang tải lên ${d}/${t}` : "Đang chuẩn bị…"), {
		skip: keepCloud,
		force: keepLocal
	});
	safeSet(LAST_KEY, String(Date.now()));
	return {
		received: down.received,
		sent: up.sent,
		failed: [...down.failed, ...up.failed]
	};
}
var LAST_KEY = "gn-sync-last";
function lastSyncAt() {
	return Number(localStorage.getItem(LAST_KEY) || 0);
}
/** Phân loại từng tài liệu. Xung đột = cả máy và mây đều sửa sau lần đồng bộ trước của tài liệu đó. */
function classify(local, remote, st) {
	const out = [];
	const rm = new Map(remote.map((r) => [r.local_id, r]));
	for (const d of local) {
		const r = rm.get(d.id);
		rm.delete(d.id);
		if (!r) {
			out.push({
				id: d.id,
				name: d.name,
				state: "local-only",
				localAt: d.updatedAt
			});
			continue;
		}
		const c = r.client_updated_at || Date.parse(r.updated_at);
		const last = st.docs[d.id];
		let state;
		if (c === d.updatedAt) state = "same";
		else if (last !== void 0 && d.updatedAt > last && c > last) state = "conflict";
		else state = d.updatedAt > c ? "local-newer" : "cloud-newer";
		out.push({
			id: d.id,
			name: d.name,
			state,
			localAt: d.updatedAt,
			cloudAt: c
		});
	}
	const tomb = readTombstones();
	for (const r of rm.values()) if (!(r.local_id in tomb)) out.push({
		id: r.local_id,
		name: r.name || r.local_id,
		state: "cloud-only",
		cloudAt: r.client_updated_at || Date.parse(r.updated_at)
	});
	return out;
}
async function cloudStatus(local) {
	if (!cloudReady()) throw new Error(NO_CLOUD);
	const { supabase } = await import("./client-D3MSxqCj.mjs").then((n) => n.t).then((n) => n.t);
	const { data: u } = await supabase.auth.getUser();
	const uid = u.user?.id;
	if (!uid) throw new Error("Hãy đăng nhập trước khi đồng bộ");
	const { data, error } = await supabase.from("documents").select("id,local_id,name,client_updated_at,updated_at");
	if (error) throw error;
	return classify(local, data ?? [], readSyncState(uid));
}
/** Xoá toàn bộ dữ liệu trên mây (giữ nguyên trên máy) và tài khoản. */
async function deleteAccountData() {
	if (!cloudReady()) throw new Error(NO_CLOUD);
	const { supabase } = await import("./client-D3MSxqCj.mjs").then((n) => n.t).then((n) => n.t);
	const { data: u } = await supabase.auth.getUser();
	const uid = u.user?.id;
	if (!uid) throw new Error("Chưa đăng nhập");
	const paths = [];
	const { data: pg } = await supabase.from("pages").select("orig_path,src_path");
	for (const p of pg ?? []) for (const x of [p.orig_path, p.src_path]) if (x) paths.push(x);
	for (let i = 0; i < paths.length; i += 100) await supabase.storage.from(PAGE_BUCKET).remove(paths.slice(i, i + 100));
	await supabase.from("documents").delete().eq("user_id", uid);
	await supabase.from("folders").delete().eq("user_id", uid);
	localStorage.removeItem(`${KEY}:${uid}`);
	localStorage.removeItem(LAST_KEY);
	const { deleteMyAccount } = await import("./account.functions-CA73tidA.mjs");
	await deleteMyAccount();
	await supabase.auth.signOut();
}
//#endregion
export { uploadAll as a, syncAll as i, deleteAccountData as n, lastSyncAt as r, cloudStatus as t };
