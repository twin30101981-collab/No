import { o as __toESM } from "../_runtime.mjs";
import { D as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as onScanIdle, t as isScanActive } from "./priority-gate-CeFvd7IG.mjs";
import { t as useServerFn } from "./useServerFn-CrZF2pjq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-queue-DZjZmUCT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/** BL-04: số lần thử khi máy BÁO có mạng mà vẫn lỗi mạng (máy chủ không tới được) — quá thì báo lỗi, gỡ khỏi hàng. */
var MAX_NET_TRIES = 3;
/** Lỗi do mạng (không tới được máy chủ), khác lỗi AI trả về. */
function isNetworkError(e) {
	if (!e) return false;
	const m = String(e.message ?? e).toLowerCase();
	return /failed to fetch|networkerror|network request failed|load failed|offline|err_internet_disconnected|err_network/.test(m);
}
function createAiQueue(env) {
	const busy = env.busy ?? (() => false);
	let seq = 0;
	const pending = [];
	const subs = /* @__PURE__ */ new Set();
	let snap = [];
	let flushing = false;
	const emit = () => {
		snap = pending.map(({ id, label, createdAt }) => ({
			id,
			label,
			createdAt
		}));
		subs.forEach((f) => f());
	};
	async function flush() {
		if (flushing || !env.online()) return;
		flushing = true;
		try {
			while (pending.length && env.online() && !busy()) {
				const e = pending[0];
				try {
					const v = await e.run();
					pending.shift();
					e.resolve(v);
				} catch (err) {
					if (isNetworkError(err) && ++e.tries < MAX_NET_TRIES) break;
					if (isNetworkError(err)) {
						pending.shift();
						e.reject(Object.assign(new Error("Không kết nối được máy chủ AI sau nhiều lần thử — kiểm tra mạng rồi thử lại.", { cause: err }), { name: "AiUnreachable" }));
						emit();
						continue;
					}
					pending.shift();
					e.reject(err);
				}
				emit();
			}
		} finally {
			flushing = false;
			emit();
		}
	}
	env.onOnline(() => void flush());
	env.onIdle?.(() => void flush());
	return {
		/** Chạy ngay nếu có mạng; mất mạng (hoặc lỗi mạng) thì xếp hàng, promise chờ tới khi gửi được. */
		async run(label, run, onQueued) {
			if (env.online() && !pending.length && !busy()) try {
				return await run();
			} catch (e) {
				if (!isNetworkError(e)) throw e;
			}
			onQueued?.();
			return new Promise((resolve, reject) => {
				pending.push({
					id: ++seq,
					label,
					createdAt: Date.now(),
					run,
					resolve,
					reject,
					tries: 0
				});
				emit();
				flush();
			});
		},
		cancel(id) {
			const i = pending.findIndex((e) => e.id === id);
			if (i < 0) return;
			const [e] = pending.splice(i, 1);
			e.reject(/* @__PURE__ */ new Error("Đã hủy việc AI đang chờ mạng."));
			emit();
		},
		flush,
		jobs: () => snap,
		subscribe: (f) => {
			subs.add(f);
			return () => subs.delete(f);
		}
	};
}
var shared = null;
function aiQueue() {
	if (!shared) shared = createAiQueue({
		online: () => typeof navigator === "undefined" || navigator.onLine !== false,
		onOnline: (cb) => {
			if (typeof window !== "undefined") window.addEventListener("online", cb);
		},
		busy: isScanActive,
		onIdle: onScanIdle
	});
	return shared;
}
var EMPTY = [];
function useAiJobs() {
	const q = aiQueue();
	return (0, import_react.useSyncExternalStore)(q.subscribe, q.jobs, () => EMPTY);
}
/** AI-02: ghi nguồn AI đã dùng; nguồn dự phòng vừa phục vụ → báo một lần (tối đa mỗi 10 phút). */
function reportAiResult(v) {
	import("./ai-status-DsooByQF.mjs").then((n) => n.n).then(({ noteAiResult }) => {
		const name = noteAiResult(v);
		if (name) import("../_libs/sonner.mjs").then((n) => n.n).then(({ toast }) => toast.info(`AI chính đang lỗi — đang dùng nguồn dự phòng: ${name}`, { description: "Xem Tôi → Tình trạng AI." })).catch(() => {});
	}).catch(() => {});
}
/** Thay cho useServerFn với các hàm AI: tự xếp hàng khi mất mạng. */
function useQueuedServerFn(fn, label) {
	const call = useServerFn(fn);
	return (0, import_react.useCallback)(((...args) => aiQueue().run(label, () => call(...args).then((v) => {
		reportAiResult(v);
		return v;
	}), () => {
		import("../_libs/sonner.mjs").then((n) => n.n).then(({ toast }) => toast.info("Đang mất mạng — việc AI đã được giữ lại và sẽ tự gửi khi có mạng.")).catch(() => {});
	})), [call, label]);
}
//#endregion
export { useQueuedServerFn as i, reportAiResult as n, useAiJobs as r, aiQueue as t };
