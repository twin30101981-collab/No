import { o as __toESM } from "../_runtime.mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { u as aiReceipt } from "./ai.functions-CpS7iAgj.mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { i as showError } from "./errors-DKvrPJ4v.mjs";
import { X as LoaderCircle, Zt as Camera, d as TriangleAlert, f as Trash2, ot as ImagePlus, wt as FileSpreadsheet } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-CZvf2xHx.mjs";
import { i as useQueuedServerFn } from "./ai-queue-DZjZmUCT.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { j as normalize } from "./image-DFWRNlNd.mjs";
import { c as download } from "./files-CTF11Arr.mjs";
import { n as pickFiles } from "./importer-BUHDogNt.mjs";
import { t as Input } from "./input-T4LKa1EA.mjs";
import { n as sheetsToXlsx } from "./xlsx-CvpeQh6I.mjs";
import { a as monthTotals, i as loadReceipts, l as saveReceipts, n as expenseSheets, o as normalizeReceipt, r as formatVnd, s as parseAmount, t as CATEGORIES } from "./receipt-aj8VqILp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/receipts-CJ7ZFc5H.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** AI-03: đọc hoá đơn trên máy (OCR + mẫu tổng tiền/ngày) khi AI không dùng được hoặc mất mạng. */
async function readLocally(src) {
	const [{ recognize }, { receiptFromText }] = await Promise.all([import("./ocr-CLa2avjZ.mjs").then((n) => n.r).then((n) => n.r), import("./offline-extract-CYJH6W2G.mjs").then((n) => n.n)]);
	return receiptFromText(await recognize(src));
}
function Receipts() {
	const fn = useQueuedServerFn(aiReceipt, "Đọc hoá đơn");
	const [list, setList] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setList(loadReceipts());
	}, []);
	const commit = (l) => {
		setList(l);
		saveReceipts(l);
	};
	const take = async (capture) => {
		const [f] = await pickFiles("image/*", false, capture);
		if (!f) return;
		setBusy(true);
		try {
			const src = await normalize(f, 1600, .85);
			const thumb = await normalize(src, 160, .6);
			let data = null;
			let why = "";
			if (typeof navigator !== "undefined" && navigator.onLine === false) why = "đang mất mạng";
			else try {
				const res = await fn({ data: { image: src } });
				if (res.ok) data = res.data;
				else why = res.message;
			} catch (e) {
				why = String(e?.message ?? e);
			}
			const local = !data;
			if (!data) {
				console.warn("receipts: AI không dùng được, đọc trên máy —", why);
				data = await readLocally(src);
			}
			const n = normalizeReceipt(data);
			setDraft({
				merchant: n.merchant,
				total: n.total != null ? String(n.total) : "",
				date: n.date,
				category: n.category,
				thumb,
				unsure: n.unsure,
				local
			});
			if (local) toast.info("AI không dùng được — đã đọc hoá đơn trên máy.", { description: "Hãy kiểm tra tổng tiền và ngày trước khi lưu." });
		} catch (e) {
			showError(e, "Không đọc được hoá đơn này");
		} finally {
			setBusy(false);
		}
	};
	const save = () => {
		if (!draft) return;
		const total = parseAmount(draft.total);
		if (total == null || !draft.date) {
			toast("Hãy nhập tổng tiền và ngày trước khi lưu.");
			return;
		}
		commit([{
			id: crypto.randomUUID(),
			merchant: draft.merchant || "Không rõ",
			total,
			date: draft.date,
			category: draft.category,
			thumb: draft.thumb,
			createdAt: Date.now()
		}, ...list]);
		setDraft(null);
		toast.success("Đã lưu vào sổ chi tiêu");
	};
	const months = monthTotals(list);
	const exportXlsx = (month) => {
		try {
			download(sheetsToXlsx(expenseSheets(list, month ? [month] : [])), month ? `chi-tieu-${month}.xlsx` : "so-chi-tieu.xlsx");
			toast.success("Đã xuất bảng chi tiêu Excel");
		} catch (e) {
			showError(e, "Không xuất được Excel");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Hoá đơn & Biên lai",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-xl space-y-5 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => take("environment"),
						disabled: busy,
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "mr-2 h-4 w-4" }), busy ? "Đang đọc…" : "Chụp hoá đơn"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => take(),
						disabled: busy,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "mr-2 h-4 w-4" }), "Chọn ảnh"]
					})]
				}),
				draft && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3 rounded-lg border border-border bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: draft.thumb,
								alt: "Hoá đơn",
								className: "h-20 w-16 rounded object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 space-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: draft.merchant,
										placeholder: "Cửa hàng",
										onChange: (e) => setDraft({
											...draft,
											merchant: e.target.value
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: draft.total,
										inputMode: "numeric",
										placeholder: "Tổng tiền (đồng)",
										onChange: (e) => setDraft({
											...draft,
											total: e.target.value
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: draft.date,
										onChange: (e) => setDraft({
											...draft,
											date: e.target.value
										})
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: draft.category === c ? "default" : "outline",
								onClick: () => setDraft({
									...draft,
									category: c
								}),
								children: c
							}, c))
						}),
						draft.unsure && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 text-sm text-destructive",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-4 w-4" }), draft.local ? "Đọc trên máy (không dùng AI) — hãy kiểm tra tổng tiền và ngày." : "AI chưa chắc — hãy kiểm tra tổng tiền và ngày."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setDraft(null),
								children: "Bỏ"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: save,
								children: "Lưu"
							})]
						})
					]
				}),
				list.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					className: "w-full",
					onClick: () => exportXlsx(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "mr-2 h-4 w-4" }), "Xuất Excel tất cả các tháng"]
				}),
				months.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "flex justify-between text-sm font-medium text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"Tháng ",
							m.month.split("-").reverse().join("/"),
							" · ",
							m.count,
							" hoá đơn"
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1",
							children: [formatVnd(m.total), m.month !== "Không rõ" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								className: "h-7 w-7",
								"aria-label": `Xuất Excel tháng ${m.month}`,
								onClick: () => exportXlsx(m.month),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "h-4 w-4" })
							})]
						})]
					}), list.filter((r) => (r.date.slice(0, 7) || "Không rõ") === m.month).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 rounded-md border border-border p-2",
						children: [
							r.thumb && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: r.thumb,
								alt: "",
								className: "h-12 w-10 rounded object-cover"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-medium",
									children: r.merchant
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										r.date.split("-").reverse().join("/"),
										" · ",
										r.category
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: formatVnd(r.total)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								"aria-label": "Xoá",
								onClick: () => commit(list.filter((x) => x.id !== r.id)),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
							})
						]
					}, r.id))]
				}, m.month)),
				!list.length && !draft && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center text-sm text-muted-foreground",
					children: "Chưa có hoá đơn nào. Chụp hoá đơn để AI tự đọc tổng tiền và ngày."
				})
			]
		})
	});
}
//#endregion
export { Receipts as component };
