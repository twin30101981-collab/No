import { o as __toESM, r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { D as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as newDataKey, c as normRecovery, d as sealVerified, f as setVaultKey, h as wrapDataKey, i as getVaultKey, l as openDoc, n as deriveKey, o as newRecoveryCode, p as unwrapDataKey, s as newSalt, u as sealDoc } from "./vault-CuGqX6h0.mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { a as inlineDoc, c as srcBytes, l as unpackDoc, o as packDoc, r as blobifyDoc, s as revokeDoc } from "./disk-pack-ZdDKsocx.mjs";
import { t as safeSet } from "./safe-storage-DnXnZPA0.mjs";
import { n as getSettings, o as setSettings, r as hashPin } from "./settings-DDlMLZCe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/db-CclUQaLE.js
var db_CclUQaLE_exports = /* @__PURE__ */ __exportAll({
	C: () => pageStatus,
	D: () => clearTombstones,
	E: () => leftLabel,
	O: () => readTombstones,
	S: () => pageBadge,
	T: () => withStatus,
	_: () => saveDoc,
	a: () => docText,
	b: () => uid,
	c: () => loadDocs,
	d: () => newDoc,
	f: () => newPage,
	g: () => restoreDocs,
	h: () => replaceAll,
	i: () => docSize,
	l: () => mutateDoc,
	m: () => purgeDocs,
	n: () => db_exports,
	o: () => ensureDocsLoaded,
	p: () => openDb,
	r: () => deleteDocs,
	s: () => getDocs,
	t: () => FILTER_LABEL,
	u: () => mutateDocs,
	v: () => saveDocs,
	w: () => pendingPageCount,
	x: () => useDocs,
	y: () => timeAgo
});
var import_react = /* @__PURE__ */ __toESM(require_react());
var KEY = "gn-sync-tomb";
var MAX = 2e3;
function readTombstones() {
	try {
		const v = JSON.parse(localStorage.getItem(KEY) ?? "{}");
		return v && typeof v === "object" ? v : {};
	} catch {
		return {};
	}
}
function write(t) {
	const keep = Object.entries(t).sort((a, b) => b[1] - a[1]).slice(0, MAX);
	try {
		localStorage.setItem(KEY, JSON.stringify(Object.fromEntries(keep)));
	} catch {}
}
function addTombstones(ids, now = Date.now()) {
	if (!ids.length) return;
	const t = readTombstones();
	for (const id of ids) t[id] = now;
	write(t);
}
function clearTombstones(ids) {
	if (!ids.length) return;
	const t = readTombstones();
	for (const id of ids) delete t[id];
	write(t);
}
var DAY = 864e5;
/** Số ngày còn lại trước khi tự xóa (0 = sẽ xóa ở lần mở app tới). */
function daysLeft(deletedAt, now = Date.now()) {
	return Math.max(0, Math.ceil((deletedAt + 30 * DAY - now) / DAY));
}
/** Id các tài liệu đã nằm trong thùng rác đủ 30 ngày. */
function expiredIds(docs, now = Date.now()) {
	return docs.filter((d) => d.deletedAt && now - d.deletedAt >= 30 * DAY).map((d) => d.id);
}
function leftLabel(deletedAt, now = Date.now()) {
	const n = daysLeft(deletedAt, now);
	return n <= 1 ? "Tự xóa trong hôm nay" : `Tự xóa sau ${n} ngày`;
}
var PAGE_STATUSES = [
	"moi",
	"cho",
	"dang",
	"xong",
	"xem-lai",
	"loi"
];
var NEXT = {
	moi: ["cho", "loi"],
	cho: ["dang", "loi"],
	dang: [
		"xong",
		"xem-lai",
		"loi",
		"cho"
	],
	xong: ["dang"],
	"xem-lai": ["dang", "xong"],
	loi: ["cho"]
};
var canTransition = (from, to) => from === to || NEXT[from].includes(to);
var isPageStatus = (v) => typeof v === "string" && PAGE_STATUSES.includes(v);
/** Trạng thái hiệu lực của trang: thiếu hoặc không hợp lệ (dữ liệu cũ/hỏng) → "xong". */
var pageStatus = (p) => isPageStatus(p.status) ? p.status : "xong";
/** Trang còn cần việc nền (chưa dùng được hết). */
var isPending = (p) => {
	const s = pageStatus(p);
	return s === "moi" || s === "cho" || s === "dang";
};
/** Đổi trạng thái có kiểm tra vòng đời; chuyển không hợp lệ → ném lỗi (bắt lỗi logic sớm, không ghi trạng thái vô nghĩa). */
function withStatus(p, to, extra = {}) {
	const from = pageStatus(p);
	if (!canTransition(from, to)) throw new Error(`Chuyển trạng thái trang không hợp lệ: ${from} → ${to}`);
	const next = {
		...p,
		status: to,
		...extra
	};
	if (to !== "dang") delete next.progress;
	if (to !== "loi") delete next.error;
	return next;
}
/** Điền status cho trang cũ (không đổi gì nếu đã có). Trả đúng đối tượng cũ khi không có gì cần đổi (không tạo bản sao thừa). */
function normalizeDoc(d) {
	if (!d.pages?.length || d.pages.every((p) => isPageStatus(p.status))) return d;
	return {
		...d,
		pages: d.pages.map((p) => isPageStatus(p.status) ? p : {
			...p,
			status: "xong"
		})
	};
}
function pageBadge(p) {
	const s = pageStatus(p);
	if (s === "moi" || s === "cho") return {
		kind: "cho",
		text: "Chờ xử lý"
	};
	if (s === "dang") return {
		kind: "dang",
		text: p.progress != null ? `${Math.max(0, Math.min(100, Math.round(p.progress)))}%` : "Đang xử lý…"
	};
	if (s === "loi") return {
		kind: "loi",
		text: "Lỗi",
		reason: p.error || "Chưa dựng được ảnh đầy đủ cho trang này."
	};
	if (s === "xem-lai") return {
		kind: "xem-lai",
		text: "Xem lại",
		reason: p.warnings?.length ? p.warnings.join("; ") : "App chưa chắc khung cắt của trang này — hãy kiểm tra."
	};
	if (p.autoFilter) return {
		kind: "tu-loc",
		text: "Tự lọc",
		reason: `App đã tự đổi bộ lọc: ${p.autoFilter.reason}`
	};
	return null;
}
/** CS-08: số trang chưa hoàn thiện (trạng thái bền) — cho nút Xuất "còn N trang". */
var pendingPageCount = (pages) => pages.filter(isPending).length;
var db_exports = /* @__PURE__ */ __exportAll$1({
	FILTER_LABEL: () => FILTER_LABEL,
	createRecovery: () => createRecovery,
	deleteDocs: () => deleteDocs,
	docSize: () => docSize,
	docText: () => docText,
	ensureDocsLoaded: () => ensureDocsLoaded,
	getDocs: () => getDocs,
	idbError: () => idbError,
	loadDocs: () => loadDocs,
	lockVault: () => lockVault,
	migrateLocked: () => migrateLocked,
	mutateDoc: () => mutateDoc,
	mutateDocs: () => mutateDocs,
	newDoc: () => newDoc,
	newPage: () => newPage,
	openDb: () => openDb,
	plainLockedCount: () => plainLockedCount,
	purgeDocs: () => purgeDocs,
	recoverVault: () => recoverVault,
	rekeyVault: () => rekeyVault,
	replaceAll: () => replaceAll,
	restoreDocs: () => restoreDocs,
	saveDoc: () => saveDoc,
	saveDocs: () => saveDocs,
	timeAgo: () => timeAgo,
	uid: () => uid,
	unlockVault: () => unlockVault,
	useDocs: () => useDocs
});
var FILTER_LABEL = {
	original: "Màu gốc",
	magic: "Thần kỳ",
	auto: "Tài liệu sáng",
	sharp: "Sắc nét",
	mono: "Đen trắng",
	gray: "Xám",
	ink: "Mực",
	eco: "Tiết kiệm mực",
	vivid: "Tăng màu",
	bright: "Làm sáng",
	shadow: "Khử bóng",
	denoise: "Khử nhiễu"
};
var uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
var dbPromise = null;
function openDb() {
	return open();
}
function open() {
	if (!dbPromise) {
		dbPromise = new Promise((resolve, reject) => {
			const req = indexedDB.open("ghi-nhanh", 2);
			req.onupgradeneeded = () => {
				const db = req.result;
				if (!db.objectStoreNames.contains("docs")) db.createObjectStore("docs", { keyPath: "id" });
				if (!db.objectStoreNames.contains("conversions")) db.createObjectStore("conversions", { keyPath: "id" });
			};
			req.onsuccess = () => resolve(req.result);
			req.onerror = () => reject(req.error);
		});
		dbPromise.catch(() => {
			dbPromise = null;
		});
	}
	return dbPromise;
}
/** BL-02 (RS-23/28/32): lỗi giao dịch → Error tiếng Việt rõ ràng (giữ lỗi gốc ở `cause`). Bộ nhớ đầy thường chỉ lộ ra lúc COMMIT. */
function idbError(e) {
	const name = e?.name;
	const msg = name === "QuotaExceededError" ? "Bộ nhớ trên máy đã đầy — chưa lưu được. Hãy xoá bớt tài liệu hoặc dọn thùng rác rồi thử lại." : `Chưa lưu được vào bộ nhớ máy${name ? ` (${name})` : ""} — dữ liệu cũ vẫn giữ nguyên, hãy thử lại.`;
	return Object.assign(new Error(msg, { cause: e }), { name: name === "QuotaExceededError" ? "QuotaExceededError" : "IdbWriteError" });
}
/** Một lệnh trong một giao dịch. BL-02: chỉ resolve khi giao dịch COMMIT xong (oncomplete) — trước đây resolve ở req.onsuccess,
*  nên giao dịch bị huỷ lúc commit (bộ nhớ đầy…) vẫn bị báo "đã lưu" và bộ nhớ đệm bị đổi trong khi đĩa giữ bản cũ. */
async function tx(mode, fn) {
	const db = await open();
	return new Promise((resolve, reject) => {
		const t = db.transaction("docs", mode);
		const req = fn(t.objectStore("docs"));
		t.oncomplete = () => resolve(req.result);
		const fail = () => reject(idbError(t.error ?? req.error ?? new DOMException("Giao dịch bị huỷ", "AbortError")));
		t.onerror = fail;
		t.onabort = fail;
	});
}
/** Nhiều thao tác trong một giao dịch — nhanh hơn hẳn so với từng lệnh riêng. */
async function batch(fn) {
	const db = await open();
	await new Promise((resolve, reject) => {
		const t = db.transaction("docs", "readwrite");
		fn(t.objectStore("docs"));
		const fail = () => reject(idbError(t.error ?? new DOMException("Giao dịch bị huỷ", "AbortError")));
		t.oncomplete = () => resolve();
		t.onerror = fail;
		t.onabort = fail;
	});
}
/** Dạng ghi xuống ổ: tài liệu khoá được mã hoá khi đang có khoá PIN trong bộ nhớ. */
async function toDisk(d) {
	const key = getVaultKey();
	if (d.locked && key && !d.enc) return sealDoc(await inlineDoc(d), key);
	if (!d.locked && d.enc) throw new Error("Tài liệu còn mã hoá — mở khoá bằng PIN trước.");
	return packDoc(d);
}
async function writeDocs(docs) {
	const disk = await Promise.all(docs.map(toDisk));
	await batch((s) => disk.forEach((d) => s.put(d)));
	const m = new Map(docs.map((d) => [d.id, normalizeDoc(d.locked ? d : blobifyDoc(d))]));
	cache = cache.map((d) => m.get(d.id) ?? d);
	emit();
}
/** BL-05a: MỌI lần ghi kho đi qua một hàng tuần tự. Trước đây mỗi nơi "đọc bản đang có → await → ghi nguyên tài liệu"
*  chạy chồng nhau (việc nền dựng trang, OCR, xoá, đổi thư mục/thẻ…) → lần ghi sau đè mất thay đổi của lần trước
*  (đã tái hiện: xoá xong tài liệu "hồi sinh"). Sửa tài liệu đã có thì dùng mutateDoc/mutateDocs — hàm `fn` nhận bản MỚI NHẤT
*  ngay trong lượt ghi. Không gọi saveDoc/mutateDoc… từ bên trong `fn` (cùng hàng → treo). */
var writeChain = Promise.resolve();
function serial(run) {
	const p = writeChain.then(run, run);
	writeChain = p.catch(() => {});
	return p;
}
/** Ghi nguyên các tài liệu (dùng cho dữ liệu từ ngoài vào: khôi phục, kéo từ mây, khoá két). Sửa tài liệu đã có → mutateDocs. */
function saveDocs(docs) {
	return serial(() => writeDocs(docs));
}
/** BL-05a: sửa MỘT tài liệu trên bản mới nhất. `fn` thuần, đồng bộ; trả null/undefined (hoặc chính bản cũ) = không ghi.
*  Trả bản đã ghi, hoặc bản hiện có nếu không đổi, hoặc null nếu tài liệu không còn (đã xoá hẳn). */
function mutateDoc(id, fn, touch = false) {
	return serial(async () => {
		const cur = cache.find((d) => d.id === id);
		if (!cur) return null;
		const next = fn(cur);
		if (!next || next === cur) return cur;
		return writeDoc({
			...next,
			id
		}, touch);
	});
}
/** BL-05a: sửa nhiều tài liệu trên bản mới nhất trong MỘT giao dịch. `pick` = danh sách id hoặc điều kiện trên bản mới nhất.
*  BL-05b: `touch` = thay đổi của người dùng (xoá, khôi phục, thư mục, thẻ) → tăng updatedAt để lần đồng bộ sau gửi lên mây (không đổi thứ tự). */
function mutateDocs(pick, fn, touch = false) {
	return serial(async () => {
		const want = typeof pick === "function" ? pick : ((ids) => (d) => ids.has(d.id))(new Set(pick));
		const next = [];
		const now = Date.now();
		for (const d of cache) {
			if (!want(d)) continue;
			const n = fn(d);
			if (n && n !== d) next.push({
				...n,
				id: d.id,
				...touch ? { updatedAt: Math.max(now, d.updatedAt + 1) } : {}
			});
		}
		if (next.length) await writeDocs(next);
		return next;
	});
}
var cache = [];
var getDocs = () => cache;
var ready = false;
var listeners = /* @__PURE__ */ new Set();
var emit = () => listeners.forEach((l) => l());
async function loadDocs() {
	await serial(async () => {
		const raw = await Promise.all((await tx("readonly", (s) => s.getAll())).map(unpackDoc));
		const key = getVaultKey();
		cache = (await Promise.all(raw.map((d) => key && d.enc ? openDoc(d, key).catch(() => d) : d))).map(normalizeDoc).sort((a, b) => b.updatedAt - a.updatedAt);
	});
	ready = true;
	emit();
	const old = expiredIds(cache);
	if (old.length) await purgeDocs(old).catch(() => {});
}
/** CS-02: bộ điều phối nền chạy ở mọi màn — đảm bảo danh sách tài liệu đã nạp trước khi tra cứu trang. */
async function ensureDocsLoaded() {
	if (!ready) await loadDocs();
}
/** Ghi NGUYÊN một tài liệu — chỉ dùng cho tài liệu MỚI tạo (newDoc) hoặc dữ liệu từ ngoài vào. Sửa tài liệu đã có → mutateDoc. */
function saveDoc(doc, touch = true) {
	return serial(() => writeDoc(doc, touch));
}
async function writeDoc(doc, touch) {
	let next = touch ? {
		...doc,
		updatedAt: Date.now()
	} : doc;
	const disk = await toDisk(next);
	await tx("readwrite", (s) => s.put(disk));
	next = normalizeDoc(next.locked ? next : blobifyDoc(next));
	import("./persist-ClcimcMq.mjs").then((m) => m.persistOnce());
	cache = touch ? [next, ...cache.filter((d) => d.id !== doc.id)] : cache.map((d) => d.id === doc.id ? next : d);
	emit();
	return next;
}
/** Move to trash (soft delete); restore with restoreDocs. */
async function deleteDocs(ids) {
	const now = Date.now();
	await mutateDocs(ids, (d) => ({
		...d,
		deletedAt: now
	}), true);
}
async function restoreDocs(ids) {
	await mutateDocs(ids, ({ deletedAt: _, ...d }) => d, true);
}
/** Permanently remove. */
function purgeDocs(ids) {
	return serial(() => purgeNow(ids));
}
async function purgeNow(ids) {
	await batch((s) => ids.forEach((id) => s.delete(id)));
	addTombstones(ids);
	const gone = new Set(ids);
	const dead = cache.filter((d) => gone.has(d.id));
	cache = cache.filter((d) => !gone.has(d.id));
	emit();
	const keep = new Set(cache.flatMap((d) => d.pages.flatMap((p) => [p.orig, p.src])));
	dead.forEach((d) => revokeDoc(d, keep));
}
/** Thay toàn bộ kho bằng `docs` trong MỘT giao dịch (lỗi giữa chừng → giữ nguyên kho cũ). Ảnh ghi dạng nhị phân như saveDocs. */
async function replaceAll(docs) {
	const disk = docs.map((d) => d.enc ? d : packDoc(d));
	await serial(() => batch((s) => {
		s.clear();
		disk.forEach((d) => s.put(d));
	}));
	await loadDocs();
}
var warned = false;
/** HM-15: không đọc được kho tài liệu (IndexedDB bị chặn/không có) → vẫn mở app với danh sách rỗng và báo rõ một lần. */
function onLoadFailed(e) {
	console.error(e);
	cache = [];
	ready = true;
	emit();
	if (warned) return;
	warned = true;
	toast.error("Máy này không cho Ghi Nhanh lưu tài liệu", { description: "Có thể đang ở chế độ riêng tư hoặc đã chặn lưu dữ liệu. Mở bằng cửa sổ thường và cho phép lưu; tài liệu mới có thể không được giữ." });
}
function useDocs() {
	const [, force] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const l = () => force((n) => n + 1);
		listeners.add(l);
		if (!ready) loadDocs().catch(onLoadFailed);
		else l();
		return () => {
			listeners.delete(l);
		};
	}, []);
	return {
		docs: cache.filter((d) => !d.deletedAt),
		trash: cache.filter((d) => d.deletedAt),
		all: cache,
		ready
	};
}
function newPage(orig, src = orig, edit) {
	return {
		id: uid(),
		orig,
		src,
		edit: {
			rotation: 0,
			filter: "original",
			brightness: 0,
			contrast: 0,
			...edit
		},
		status: "xong"
	};
}
function newDoc(pages, name, kind = "Tài liệu") {
	const d = /* @__PURE__ */ new Date();
	const stamp = `${String(d.getDate()).padStart(2, "0")}-${String(d.getMonth() + 1).padStart(2, "0")} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
	return {
		id: uid(),
		name: name ?? `${kind} ${stamp}`,
		folder: "Chung",
		kind,
		createdAt: Date.now(),
		updatedAt: Date.now(),
		pages
	};
}
function docSize(doc) {
	const bytes = doc.pages.reduce((n, p) => n + srcBytes(p.src), 0);
	if (bytes > 0 && bytes < 1e3) return "1 KB";
	return bytes > 1e6 ? `${(bytes / 1e6).toFixed(1)} MB` : `${Math.round(bytes / 1e3)} KB`;
}
function docText(doc) {
	return doc.pages.map((p) => p.text ?? "").join("\n");
}
function timeAgo(t) {
	const m = Math.round((Date.now() - t) / 6e4);
	if (m < 1) return "Vừa xong";
	if (m < 60) return `${m} phút trước`;
	const h = Math.round(m / 60);
	if (h < 24) return `${h} giờ trước`;
	const days = Math.round(h / 24);
	return days === 1 ? "Hôm qua" : `${days} ngày trước`;
}
/** BL-03 (RS-18/24): mở từng tài liệu riêng (allSettled) — trước đây Promise.all: MỘT tài liệu hỏng làm cả két "sai PIN", không mở được gì.
*  Tài liệu không mở được giữ NGUYÊN bản mã (không bị ghi đè). Trả số mở được / tổng / tên tài liệu lỗi. */
async function openAll(key, fallback) {
	const sealed = cache.filter((d) => d.enc);
	const rs = await Promise.allSettled(sealed.map((d) => openDoc(d, key).catch((e) => {
		if (fallback) return openDoc(d, fallback);
		throw e;
	})));
	const m = /* @__PURE__ */ new Map();
	const failed = [];
	rs.forEach((r, i) => {
		if (r.status === "fulfilled") m.set(r.value.id, r.value);
		else failed.push(sealed[i].name);
	});
	cache = cache.map((d) => m.get(d.id) ?? d);
	return {
		opened: m.size,
		total: sealed.length,
		failed
	};
}
function warnUnopened(failed) {
	if (failed.length) toast.warning(`${failed.length} tài liệu khoá không mở được`, {
		description: `Dữ liệu có thể bị hỏng (${failed.slice(0, 3).join(", ")}${failed.length > 3 ? "…" : ""}). Bản mã vẫn được giữ nguyên, chưa xoá gì.`,
		duration: 1e4
	});
}
/** Chuyển tài liệu khoá còn dạng rõ (dữ liệu cũ) hoặc mã theo khoá cũ sang khoá hiện tại, có kiểm tra từng tài liệu. */
async function migrateLocked(key, all = false) {
	const todo = cache.filter((d) => d.locked && !d.enc);
	const disk = [];
	const failed = [];
	for (const d of todo) try {
		disk.push(await sealVerified((({ enc: _e, ...r }) => r)(d), key));
	} catch {
		failed.push(d.name);
	}
	if (disk.length) await batch((s) => disk.forEach((d) => s.put(d)));
	return {
		done: disk.length,
		failed
	};
}
var plainLockedCount = () => cache.filter((d) => d.locked && !d.enc).length;
/** Mở khoá bằng PIN. Trả false nếu sai. Tự chuyển dữ liệu cũ sang dạng mã hoá. */
async function unlockVault(pin, salt) {
	const kek = await deriveKey(pin, salt);
	const wrap = getSettings().vaultWrap;
	let dek;
	try {
		if (wrap) {
			dek = await unwrapDataKey(wrap.pin, kek);
			warnUnopened((await openAll(dek)).failed);
		} else {
			const r = await openAll(kek);
			if (r.total && !r.opened) throw new Error("sai PIN");
			warnUnopened(r.failed);
			dek = await newDataKey();
			setSettings({ vaultWrap: {
				v: 1,
				pin: await wrapDataKey(dek, kek)
			} });
			setVaultKey(dek);
			await migrateLocked(dek, true);
			emit();
			return true;
		}
	} catch {
		return false;
	}
	setVaultKey(dek);
	if (plainLockedCount()) await migrateLocked(dek);
	emit();
	return true;
}
/** Quên PIN: mở bằng mã khôi phục rồi đặt PIN mới (khoá dữ liệu giữ nguyên, không mã lại). */
async function recoverVault(code, newPin) {
	const wrap = getSettings().vaultWrap;
	if (!wrap?.rec || !wrap.recSalt) return false;
	try {
		const dek = await unwrapDataKey(wrap.rec, await deriveKey(normRecovery(code), wrap.recSalt));
		warnUnopened((await openAll(dek)).failed);
		setVaultKey(dek);
	} catch {
		return false;
	}
	const salt = newSalt();
	const dek = getVaultKey();
	setSettings({
		pin: await hashPin(newPin),
		pinSalt: salt,
		vaultWrap: {
			...wrap,
			pin: await wrapDataKey(dek, await deriveKey(newPin, salt))
		}
	});
	emit();
	return true;
}
/** Tạo mã khôi phục mới (cần đang mở khoá). Mã cũ hết hiệu lực. */
async function createRecovery() {
	const dek = getVaultKey();
	const wrap = getSettings().vaultWrap;
	if (!dek || !wrap) throw new Error("Hãy mở khoá bằng PIN trước");
	const code = newRecoveryCode();
	const recSalt = newSalt();
	setSettings({ vaultWrap: {
		...wrap,
		rec: await wrapDataKey(dek, await deriveKey(normRecovery(code), recSalt)),
		recSalt
	} });
	return code;
}
/** Khoá lại: quên khoá trong bộ nhớ, đọc lại bản mã hoá từ ổ. */
async function lockVault() {
	setVaultKey(null);
	if (ready) await loadDocs();
}
/** Đặt PIN mới (bọc lại khoá dữ liệu) hoặc tắt PIN (giải mã trả về dạng thường). Cần đang mở khoá. */
async function rekeyVault(next) {
	const locked = cache.filter((d) => d.locked);
	if (locked.some((d) => d.enc)) throw new Error("Cần mở khoá trước khi đổi PIN");
	if (next) {
		const dek = getVaultKey() ?? await newDataKey();
		const wrap = getSettings().vaultWrap;
		setSettings({ vaultWrap: {
			...wrap ?? {},
			v: 1,
			pin: await wrapDataKey(dek, await deriveKey(next.pin, next.salt))
		} });
		setVaultKey(dek);
		await saveDocs(locked);
	} else {
		await saveDocs(locked.map(({ locked: _, ...d }) => d));
		if ((await Promise.all(locked.map((d) => tx("readonly", (st) => st.get(d.id))))).some((d) => !d || d.enc || d.locked)) throw new Error("Kiểm tra sau khi giải mã không khớp — PIN vẫn được giữ, chưa xoá khoá. Hãy thử lại.");
		setVaultKey(null);
		{
			const { vaultWrap: _w, ...rest } = getSettings();
			safeSet("ghi-nhanh-settings", JSON.stringify(rest));
			setSettings({});
		}
	}
}
//#endregion
export { saveDoc as C, useDocs as D, uid as E, withStatus as O, restoreDocs as S, timeAgo as T, pageStatus as _, docSize as a, readTombstones as b, getDocs as c, mutateDoc as d, mutateDocs as f, pageBadge as g, openDb as h, deleteDocs as i, leftLabel as l, newPage as m, clearTombstones as n, docText as o, newDoc as p, db_CclUQaLE_exports as r, ensureDocsLoaded as s, FILTER_LABEL as t, loadDocs as u, pendingPageCount as v, saveDocs as w, replaceAll as x, purgeDocs as y };
