import { o as __toESM } from "../_runtime.mjs";
import { C as createRootRouteWithContext, E as useRouter, S as createFileRoute, T as useNavigate, b as Outlet, g as useRouterState, h as HeadContent, m as Scripts, w as Link, x as lazyRouteComponent, y as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as require_react, E as require_jsx_runtime, a as AlertDialogDescription$1, c as AlertDialogTitle$1, i as AlertDialogContent$1, n as AlertDialogAction$1, o as AlertDialogOverlay$1, r as AlertDialogCancel$1, s as AlertDialogPortal$1, t as AlertDialog$1 } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as installGlobalErrorToasts } from "./errors-DKvrPJ4v.mjs";
import { n as authMessage, s as runAuthCallbackOnce } from "./auth-BEi9IFUJ.mjs";
import { C as SlidersHorizontal, X as LoaderCircle, Zt as Camera, a as WifiOff, r as X, w as Share2 } from "../_libs/lucide-react.mjs";
import { n as SHELL_HYDRATED, r as isShellHydrated } from "./app-shell-CZvf2xHx.mjs";
import { i as installAutoLock, o as setSettings, u as useSettings } from "./settings-DDlMLZCe.mjs";
import { r as useAiJobs, t as aiQueue } from "./ai-queue-DZjZmUCT.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { n as buttonVariants, t as Button } from "./button-BbbVcZ3W.mjs";
import { s as startPipeline } from "./runner-CZAn6hg6.mjs";
import { a as useDialogState } from "./dialog-IcUxZaUZ.mjs";
import { a as DialogTitle, n as DialogContent, r as DialogDescription, t as Dialog } from "./dialog-3HhpKDcy.mjs";
import { t as Input } from "./input-T4LKa1EA.mjs";
import { i as useOcrJobs, n as ocrQueue } from "./ocr-queue-Dg31Dfup.mjs";
import { t as Route$14 } from "./doc._id-P7iptWfN.mjs";
import { t as Route$15 } from "./documents-Cxss4jut.mjs";
import { r as registerServiceWorker } from "./offline-BFa7CUSi.mjs";
import { t as Switch } from "./switch-BVIUyQVR.mjs";
import { t as Route$16 } from "./pair_._code-BPp1iwsc.mjs";
import { t as Route$17 } from "./routes-BujOT1PY.mjs";
import { n as Route$18 } from "./scan-Csud2Qvt.mjs";
import { t as Route$19 } from "./s._token-DbbrCp4H.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DU0_Bwlm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-By0Np-_k.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var AlertDialog = AlertDialog$1;
var AlertDialogPortal = AlertDialogPortal$1;
var AlertDialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay$1, {
	className: cn("fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
AlertDialogOverlay.displayName = AlertDialogOverlay$1.displayName;
var AlertDialogContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props
})] }));
AlertDialogContent.displayName = AlertDialogContent$1.displayName;
var AlertDialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
AlertDialogHeader.displayName = "AlertDialogHeader";
var AlertDialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
AlertDialogFooter.displayName = "AlertDialogFooter";
var AlertDialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold", className),
	...props
}));
AlertDialogTitle.displayName = AlertDialogTitle$1.displayName;
var AlertDialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
AlertDialogDescription.displayName = AlertDialogDescription$1.displayName;
var AlertDialogAction = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction$1, {
	ref,
	className: cn(buttonVariants(), className),
	...props
}));
AlertDialogAction.displayName = AlertDialogAction$1.displayName;
var AlertDialogCancel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel$1, {
	ref,
	className: cn(buttonVariants({ variant: "outline" }), "mt-2 sm:mt-0", className),
	...props
}));
AlertDialogCancel.displayName = AlertDialogCancel$1.displayName;
function AppDialog() {
	const d = useDialogState();
	const [value, setValue] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setValue(d?.defaultValue ?? "");
	}, [d]);
	if (!d) return null;
	const pinBad = d.kind === "pin" && !/^\d{4,6}$/.test(value);
	const ok = () => {
		if (d.kind === "choice") d.resolve("ok");
		else if (d.kind === "confirm") d.resolve(true);
		else if (!pinBad && (d.kind !== "prompt" || value.trim())) d.resolve(value);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
		open: true,
		onOpenChange: (o) => {
			if (!o) d.resolve(d.kind === "confirm" ? false : null);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogContent, {
			className: "max-w-[92vw] rounded-[20px] sm:max-w-sm",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (e) => {
					e.preventDefault();
					ok();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, {
						className: "font-display",
						children: d.title
					}), d.message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: d.message })] }),
					d.kind === "prompt" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						autoFocus: true,
						className: "mt-4 h-12",
						value,
						placeholder: d.placeholder,
						onChange: (e) => setValue(e.target.value)
					}),
					d.kind === "pin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						autoFocus: true,
						inputMode: "numeric",
						type: "password",
						maxLength: 6,
						className: "mt-4 h-14 text-center text-2xl tracking-[0.5em]",
						value,
						onChange: (e) => setValue(e.target.value.replace(/\D/g, ""))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, {
						className: "mt-5 flex-row gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								className: "flex-1",
								onClick: () => d.resolve(d.kind === "confirm" ? false : null),
								children: "Huỷ"
							}),
							d.kind === "choice" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "destructive",
								className: "flex-1",
								onClick: () => d.resolve("alt"),
								children: d.altText
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								variant: d.danger ? "destructive" : "default",
								className: "flex-1",
								disabled: pinBad || d.kind === "prompt" && !value.trim(),
								children: d.okText ?? "Đồng ý"
							})
						]
					})
				]
			})
		})
	});
}
/** G3-30: three-screen first-run guide; re-openable from Tôi > Xem lại hướng dẫn. */
var ONBOARDING_STEPS = [
	{
		icon: Camera,
		title: "Chụp hoặc nhập giấy tờ",
		body: "Bấm Quét để chụp. Ứng dụng tự tìm mép giấy và tự chụp khi máy đứng yên. Bạn cũng có thể nhập ảnh hoặc PDF có sẵn."
	},
	{
		icon: SlidersHorizontal,
		title: "Sửa cho rõ nét",
		body: "Kéo góc để cắt lại, chọn bộ lọc, khử bóng, che thông tin nhạy cảm. Mọi chỉnh sửa đều làm lại được, ảnh gốc luôn được giữ."
	},
	{
		icon: Share2,
		title: "Xuất và chia sẻ",
		body: "Lưu thành PDF, Word, Excel hoặc ảnh. Tài liệu nằm trên máy bạn; đăng nhập chỉ khi muốn đồng bộ hoặc gửi liên kết."
	}
];
function Onboarding() {
	const s = useSettings();
	const path = useRouterState({ select: (r) => r.location.pathname });
	const [step, setStep] = (0, import_react.useState)(0);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let t2 = 0;
		const go = () => {
			window.clearTimeout(t2);
			t2 = window.setTimeout(() => setReady(true), 500);
		};
		if (isShellHydrated()) {
			go();
			return;
		}
		window.addEventListener(SHELL_HYDRATED, go, { once: true });
		const t = window.setTimeout(go, 4e3);
		return () => {
			window.removeEventListener(SHELL_HYDRATED, go);
			window.clearTimeout(t);
			window.clearTimeout(t2);
		};
	}, []);
	if (!ready) return null;
	if (s.onboarded || path.startsWith("/s/")) return null;
	const done = () => {
		setSettings({ onboarded: true });
		setStep(0);
	};
	const item = ONBOARDING_STEPS[step];
	const Icon = item.icon;
	const last = step === ONBOARDING_STEPS.length - 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (open) => !open && done(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-semibold text-muted-foreground",
					"aria-live": "polite",
					children: [
						"Bước ",
						step + 1,
						" / ",
						ONBOARDING_STEPS.length
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid size-14 place-items-center rounded-2xl bg-primary/10 text-primary",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-7" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-display text-xl",
					children: item.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "text-base leading-relaxed text-foreground/80",
					children: item.body
				}),
				step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center justify-between gap-3 rounded-md border p-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: "Chữ lớn"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Dễ đọc hơn, đổi lại được trong mục Tôi."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						"aria-label": "Chữ lớn",
						checked: s.largeText,
						onCheckedChange: (v) => setSettings({ largeText: v })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center gap-1.5",
					"aria-hidden": "true",
					children: ONBOARDING_STEPS.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1.5 rounded-full transition-all ${i === step ? "w-6 bg-primary" : "w-1.5 bg-muted-foreground/30"}` }, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [step > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						className: "flex-1",
						onClick: () => setStep(step - 1),
						children: "Quay lại"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "flex-1",
						onClick: done,
						children: "Bỏ qua"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "flex-1",
						onClick: () => last ? done() : setStep(step + 1),
						children: last ? "Bắt đầu" : "Tiếp"
					})]
				})
			]
		})
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
/** Floating background-OCR status: visible on every screen while pages are being read. */
function OcrDock() {
	const jobs = useOcrJobs();
	if (!jobs.length) return null;
	const cur = jobs.find((j) => j.status === "running") ?? jobs[0];
	const done = ocrQueue().done, total = done + jobs.length;
	const pct = Math.round((done + cur.progress) / total * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "status",
		className: "fixed inset-x-0 bottom-[calc(5rem+env(safe-area-inset-bottom))] z-50 mx-auto w-[min(92vw,400px)] rounded-full bg-foreground px-3 py-2 text-background shadow-lg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 text-xs font-semibold",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 shrink-0 animate-spin" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1 truncate",
					children: [
						"Nhận chữ ",
						done + 1,
						"/",
						total,
						" · ",
						cur.label,
						" · ",
						pct,
						"%"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					"aria-label": "Hủy nhận chữ",
					onClick: () => void ocrQueue().cancel(),
					className: "flex items-center gap-1 rounded-full bg-background/15 px-2 py-0.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" }), " Hủy"]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1.5 h-1 overflow-hidden rounded-full bg-background/20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full bg-primary transition-[width]",
				style: { width: `${pct}%` }
			})
		})]
	});
}
/** Báo việc AI đang chờ mạng; hiện trên mọi màn hình. */
function AiQueueDock() {
	const jobs = useAiJobs();
	if (!jobs.length) return null;
	const first = jobs[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "status",
		className: "fixed inset-x-0 top-[calc(2.75rem+env(safe-area-inset-top))] z-50 mx-auto w-[min(92vw,400px)] rounded-full bg-foreground px-3 py-2 text-background shadow-lg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 text-xs font-semibold",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WifiOff, { className: "size-3.5 shrink-0" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1 truncate",
					children: [
						jobs.length,
						" việc AI chờ mạng · ",
						first.label
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					"aria-label": "Hủy việc AI đang chờ",
					onClick: () => aiQueue().cancel(first.id),
					className: "flex items-center gap-1 rounded-full bg-background/15 px-2 py-0.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" }), " Hủy"]
				})
			]
		})
	});
}
/** G2-10: báo mất mạng; có mạng lại thì báo ngắn rồi ẩn. */
function OfflineBanner() {
	const [offline, setOffline] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setOffline(navigator.onLine === false);
		const off = () => setOffline(true);
		const on = () => {
			setOffline(false);
			toast.success("Đã có mạng trở lại.");
		};
		window.addEventListener("offline", off);
		window.addEventListener("online", on);
		return () => {
			window.removeEventListener("offline", off);
			window.removeEventListener("online", on);
		};
	}, []);
	if (!offline) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "status",
		className: "fixed inset-x-0 top-0 z-50 flex pt-[calc(0.375rem+env(safe-area-inset-top))] items-center justify-center gap-2 bg-destructive px-3 py-1.5 text-xs font-semibold text-destructive-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WifiOff, { className: "size-3.5" }), " Đang mất mạng — vẫn quét, sửa được; việc AI sẽ chờ."]
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Không tìm thấy trang"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Trang bạn tìm không tồn tại hoặc đã được chuyển đi."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Về trang chủ"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	const msg = error instanceof Error ? error.message : String(error);
	const noCloud = /Missing Supabase environment/i.test(msg);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: noCloud ? "Chưa kết nối máy chủ đám mây" : "Không tải được trang này"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: noCloud ? "Tính năng này cần đăng nhập/đồng bộ qua Lovable Cloud nhưng bản này chưa được cấu hình. Các tính năng trên máy (quét, PDF, công cụ) vẫn dùng bình thường." : "Đã có lỗi xảy ra. Bạn thử tải lại hoặc quay về trang chủ."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Thử lại"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Về trang chủ"
					})]
				})
			]
		})
	});
}
var Route$13 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{
				name: "theme-color",
				content: "#006F59"
			},
			{
				name: "apple-mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-title",
				content: "Ghi Nhanh"
			},
			{ title: "Ghi Nhanh" },
			{
				name: "description",
				content: "Ứng dụng quét, nhận diện chữ và xuất PDF."
			},
			{
				name: "author",
				content: "Ghi Nhanh"
			},
			{
				property: "og:title",
				content: "Ghi Nhanh"
			},
			{
				property: "og:description",
				content: "Ứng dụng quét, nhận diện chữ và xuất PDF."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/manifest.webmanifest"
			},
			{
				rel: "icon",
				href: "/icon.svg",
				type: "image/svg+xml"
			},
			{
				rel: "icon",
				href: "/favicon.png",
				type: "image/png"
			},
			{
				rel: "apple-touch-icon",
				href: "/apple-touch-icon.png"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "vi",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$13.useRouteContext();
	const { dark, largeText } = useSettings();
	(0, import_react.useEffect)(() => {
		document.documentElement.classList.toggle("dark", dark);
	}, [dark]);
	(0, import_react.useEffect)(() => {
		document.documentElement.classList.toggle("large-text", largeText);
	}, [largeText]);
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		startPipeline();
	}, []);
	(0, import_react.useEffect)(() => {
		const run = runAuthCallbackOnce();
		if (!run) return;
		const id = toast.loading("Đang hoàn tất đăng nhập…");
		run.then((r) => {
			if (r.user) {
				toast.success("Đã đăng nhập", { id });
				navigate({
					to: r.next,
					replace: true
				});
			} else {
				toast.error(authMessage(r.error ?? "Sign in failed"), { id });
				if (window.location.pathname === "/") navigate({
					to: "/auth",
					replace: true
				});
			}
		});
	}, []);
	(0, import_react.useEffect)(() => {
		const a = installAutoLock();
		const b = installGlobalErrorToasts();
		registerServiceWorker();
		return () => {
			a();
			b();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OcrDock, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OfflineBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiQueueDock, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
				position: "top-center",
				richColors: true,
				closeButton: true,
				offset: { top: "calc(env(safe-area-inset-top) + 64px)" },
				mobileOffset: { top: "calc(env(safe-area-inset-top) + 64px)" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppDialog, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Onboarding, {})
		]
	});
}
var $$splitComponentImporter$12 = () => import("./auth-DjrNf2r5.mjs");
var Route$12 = createFileRoute("/auth")({
	head: () => ({ meta: [
		{ title: "Đăng nhập — Ghi Nhanh" },
		{
			name: "description",
			content: "Đăng nhập tùy chọn bằng email hoặc Google để chuẩn bị đồng bộ tài liệu."
		},
		{
			property: "og:title",
			content: "Đăng nhập — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Đăng nhập tùy chọn bằng email hoặc Google để chuẩn bị đồng bộ tài liệu."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./compare-BQxMbw9a.mjs");
var TITLE = "So sánh với CamScanner — Ghi Nhanh";
var DESC = "Đo độ nét, nghiêng, chói, tương phản, tốc độ và kết quả AI của cùng một biên bản chụp bằng Ghi Nhanh và CamScanner.";
var Route$11 = createFileRoute("/compare")({
	head: () => ({ meta: [
		{ title: TITLE },
		{
			name: "description",
			content: DESC
		},
		{
			property: "og:title",
			content: TITLE
		},
		{
			property: "og:description",
			content: DESC
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./field-test-DH_aayMX.mjs");
var Route$10 = createFileRoute("/field-test")({
	head: () => ({ meta: [
		{ title: "Thử trên điện thoại thật — Ghi Nhanh" },
		{
			name: "description",
			content: "Chọn ảnh chụp thật, xem app dò mép giấy đúng hay sai và xuất báo cáo để hiệu chỉnh."
		},
		{
			property: "og:title",
			content: "Thử trên điện thoại thật — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Đo độ chính xác dò mép giấy và chất lượng ảnh trên máy của bạn."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./id-photo-uKyTNekX.mjs");
var Route$9 = createFileRoute("/id-photo")({
	head: () => ({ meta: [
		{ title: "Ảnh thẻ — Ghi Nhanh" },
		{
			name: "description",
			content: "Tách nền, đổi nền trắng/xanh, cắt ảnh thẻ 3x4, 4x6 và xếp lên khổ in 10x15 hoặc A4."
		},
		{
			property: "og:title",
			content: "Ảnh thẻ — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Tách nền, đổi nền, cắt ảnh thẻ 3x4, 4x6 và xếp lên khổ in."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./me-F60X5wi8.mjs");
var Route$8 = createFileRoute("/me")({
	head: () => ({ meta: [
		{ title: "Cài đặt — Ghi Nhanh" },
		{
			name: "description",
			content: "Chất lượng ảnh, khổ giấy, ngôn ngữ nhận chữ, mã PIN và sao lưu tài liệu."
		},
		{
			property: "og:title",
			content: "Cài đặt — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Chất lượng ảnh, khổ giấy, ngôn ngữ nhận chữ, mã PIN và sao lưu tài liệu."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./measure-DkZYRLnx.mjs");
var Route$7 = createFileRoute("/measure")({
	head: () => ({ meta: [
		{ title: "Đo độ dài — Ghi Nhanh" },
		{
			name: "description",
			content: "Đo độ dài vật trong ảnh bằng một vật mẫu quen thuộc như thẻ CCCD hoặc tờ A4."
		},
		{
			property: "og:title",
			content: "Đo độ dài — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Đo độ dài vật trong ảnh bằng một vật mẫu quen thuộc như thẻ CCCD hoặc tờ A4."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./pair-BjtEtPv4.mjs");
var Route$6 = createFileRoute("/pair")({
	head: () => ({ meta: [
		{ title: "Quét bằng điện thoại — Ghi Nhanh" },
		{
			name: "description",
			content: "Ghép máy tính với điện thoại bằng mã QR để chụp giấy tờ bằng điện thoại."
		},
		{
			property: "og:title",
			content: "Quét bằng điện thoại — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Ghép máy tính với điện thoại bằng mã QR để chụp giấy tờ bằng điện thoại."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./photo-check-DlJL-DT7.mjs");
var Route$5 = createFileRoute("/photo-check")({
	head: () => ({ meta: [
		{ title: "Đánh giá ảnh chụp — Ghi Nhanh" },
		{
			name: "description",
			content: "AI chấm độ rõ, ánh sáng, độ chói và góc chụp của ảnh tài liệu, rồi gợi ý cách chụp lại tốt hơn."
		},
		{
			property: "og:title",
			content: "Đánh giá ảnh chụp — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Chấm độ rõ, ánh sáng, độ chói, góc chụp và gợi ý chụp lại."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./receipts-CJ7ZFc5H.mjs");
var Route$4 = createFileRoute("/receipts")({
	head: () => ({ meta: [
		{ title: "Hoá đơn & Biên lai — Ghi Nhanh" },
		{
			name: "description",
			content: "Chụp hoá đơn, biên lai: AI tự đọc tổng tiền, ngày và nhóm chi tiêu, lưu thành sổ chi tiêu theo tháng."
		},
		{
			property: "og:title",
			content: "Hoá đơn & Biên lai — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Chụp hoá đơn, tự đọc tổng tiền và ngày, cộng chi tiêu theo tháng."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
/** AI-03: đọc hoá đơn trên máy (OCR + mẫu tổng tiền/ngày) khi AI không dùng được hoặc mất mạng. */
var $$splitComponentImporter$3 = () => import("./sync-EBiXPsFN.mjs");
var Route$3 = createFileRoute("/sync")({
	head: () => ({ meta: [
		{ title: "Đồng bộ đám mây — Ghi Nhanh" },
		{
			name: "description",
			content: "Xem trạng thái đồng bộ, xử lý xung đột giữa máy và đám mây, xoá tài khoản."
		},
		{
			property: "og:title",
			content: "Đồng bộ đám mây — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Xem trạng thái đồng bộ, xử lý xung đột giữa máy và đám mây, xoá tài khoản."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./tools-Ip96NTmd.mjs");
var Route$2 = createFileRoute("/tools")({
	head: () => ({ meta: [
		{ title: "Công cụ — Ghi Nhanh" },
		{
			name: "description",
			content: "Ghép, tách, nén, ký, đặt mật khẩu PDF; chuyển ảnh sang Word, Excel; quét thẻ, sách, mã QR."
		},
		{
			property: "og:title",
			content: "Công cụ — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Ghép, tách, nén, ký, đặt mật khẩu PDF; chuyển ảnh sang Word, Excel; quét thẻ, sách, mã QR."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./trash-C6O_iLO-.mjs");
var Route$1 = createFileRoute("/trash")({
	head: () => ({ meta: [
		{ title: "Thùng rác — Ghi Nhanh" },
		{
			name: "description",
			content: "Khôi phục tài liệu đã xóa hoặc xóa hẳn. Tài liệu tự xóa sau 30 ngày."
		},
		{
			property: "og:title",
			content: "Thùng rác — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Khôi phục tài liệu đã xóa hoặc xóa hẳn. Tài liệu tự xóa sau 30 ngày."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./tools_.history-B1hS4iPe.mjs");
var Route = createFileRoute("/tools_/history")({
	head: () => ({ meta: [
		{ title: "Lịch sử chuyển đổi — Ghi Nhanh" },
		{
			name: "description",
			content: "Xem lại các lần chuyển PDF, ảnh, Excel sang Word/Excel; tải lại tệp và sửa các ô chưa chắc."
		},
		{
			property: "og:title",
			content: "Lịch sử chuyển đổi — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Xem lại các lần chuyển PDF, ảnh, Excel sang Word/Excel; tải lại tệp và sửa các ô chưa chắc."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$17.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$13
	}),
	AuthRoute: Route$12.update({
		id: "/auth",
		path: "/auth",
		getParentRoute: () => Route$13
	}),
	CompareRoute: Route$11.update({
		id: "/compare",
		path: "/compare",
		getParentRoute: () => Route$13
	}),
	DocumentsRoute: Route$15.update({
		id: "/documents",
		path: "/documents",
		getParentRoute: () => Route$13
	}),
	FieldTestRoute: Route$10.update({
		id: "/field-test",
		path: "/field-test",
		getParentRoute: () => Route$13
	}),
	IdPhotoRoute: Route$9.update({
		id: "/id-photo",
		path: "/id-photo",
		getParentRoute: () => Route$13
	}),
	MeRoute: Route$8.update({
		id: "/me",
		path: "/me",
		getParentRoute: () => Route$13
	}),
	MeasureRoute: Route$7.update({
		id: "/measure",
		path: "/measure",
		getParentRoute: () => Route$13
	}),
	PairRoute: Route$6.update({
		id: "/pair",
		path: "/pair",
		getParentRoute: () => Route$13
	}),
	PhotoCheckRoute: Route$5.update({
		id: "/photo-check",
		path: "/photo-check",
		getParentRoute: () => Route$13
	}),
	ReceiptsRoute: Route$4.update({
		id: "/receipts",
		path: "/receipts",
		getParentRoute: () => Route$13
	}),
	ScanRoute: Route$18.update({
		id: "/scan",
		path: "/scan",
		getParentRoute: () => Route$13
	}),
	SyncRoute: Route$3.update({
		id: "/sync",
		path: "/sync",
		getParentRoute: () => Route$13
	}),
	ToolsRoute: Route$2.update({
		id: "/tools",
		path: "/tools",
		getParentRoute: () => Route$13
	}),
	TrashRoute: Route$1.update({
		id: "/trash",
		path: "/trash",
		getParentRoute: () => Route$13
	}),
	DocIdRoute: Route$14.update({
		id: "/doc/$id",
		path: "/doc/$id",
		getParentRoute: () => Route$13
	}),
	PairCodeRoute: Route$16.update({
		id: "/pair_/$code",
		path: "/pair/$code",
		getParentRoute: () => Route$13
	}),
	STokenRoute: Route$19.update({
		id: "/s/$token",
		path: "/s/$token",
		getParentRoute: () => Route$13
	}),
	ToolsHistoryRoute: Route.update({
		id: "/tools_/history",
		path: "/tools/history",
		getParentRoute: () => Route$13
	})
};
var routeTree = Route$13._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
