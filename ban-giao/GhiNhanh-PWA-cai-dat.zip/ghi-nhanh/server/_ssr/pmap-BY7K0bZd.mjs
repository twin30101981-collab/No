//#region node_modules/.nitro/vite/services/ssr/assets/pmap-BY7K0bZd.js
/** S5: chạy song song tối đa `limit` việc, gọi `onDone` đúng thứ tự đầu vào ngay khi phần đầu dãy sẵn sàng. */
async function pmapOrdered(items, limit, fn, onDone) {
	const res = new Array(items.length);
	let next = 0;
	const slots = [];
	const start = () => {
		const i = next++;
		const p = fn(items[i], i);
		res[i] = p;
		return p.then(() => void 0, () => void 0);
	};
	const n = Math.max(1, Math.min(limit, items.length));
	for (let k = 0; k < n; k++) slots.push(start());
	for (let i = 0; i < items.length; i++) {
		const r = await res[i];
		res[i] = void 0;
		if (next < items.length) start();
		await onDone(r, i);
	}
	await Promise.all(slots);
}
//#endregion
export { pmapOrdered as t };
