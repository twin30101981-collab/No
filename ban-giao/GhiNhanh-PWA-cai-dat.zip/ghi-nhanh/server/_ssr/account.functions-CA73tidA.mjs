import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as createSsrRpc } from "./createSsrRpc-CVjuB6nW.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CwccI41b.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account.functions-CA73tidA.js
var deleteMyAccount = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("27301031363e284184ead21ac910c33ebfbe9159435c975f26319c6a65fade88"));
//#endregion
export { deleteMyAccount };
