import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scan-log-DnWLrMlu.js
var scan_log_exports = /* @__PURE__ */ __exportAll({
	DEDUP_MS: () => DEDUP_MS,
	addEntry: () => addEntry,
	clearScanLog: () => clearScanLog,
	deviceInfo: () => deviceInfo,
	logScan: () => logScan,
	newScanSession: () => newScanSession,
	readScanLog: () => readScanLog
});
/** Lỗi trùng mã + nội dung trong khoảng này được gộp thành một mục có đếm. */
var DEDUP_MS = 6e4;
/** Thuần: thêm một mục, gộp nếu trùng mục gần nhất cùng mã/nội dung trong DEDUP_MS. */
function addEntry(list, e, max = 100) {
	const now = Date.parse(e.at);
	const i = list.findIndex((x) => x.code === e.code && x.message === e.message && now - Date.parse(x.lastAt ?? x.at) < 6e4);
	if (i >= 0) {
		const hit = list[i];
		return [{
			...hit,
			count: (hit.count ?? 1) + 1,
			lastAt: e.at
		}, ...list.filter((_, k) => k !== i)].slice(0, max);
	}
	return [e, ...list].slice(0, max);
}
var KEY = "ghi-nhanh:scan-log";
var newScanSession = () => (crypto.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`).slice(0, 18);
/** Mô tả thiết bị ngắn gọn (hệ điều hành + trình duyệt + màn hình), không lưu định danh cá nhân. */
function deviceInfo() {
	if (typeof navigator === "undefined") return "";
	const ua = navigator.userAgent;
	return `${/iPhone|iPad/.test(ua) ? "iOS" : /Android [\d.]+/.exec(ua)?.[0] ?? (/Mac/.test(ua) ? "macOS" : /Windows/.test(ua) ? "Windows" : "Khác")} · ${/CriOS\/\d+|Chrome\/\d+/.exec(ua)?.[0] ?? /Firefox\/\d+/.exec(ua)?.[0] ?? (/Safari/.test(ua) ? "Safari" : "Khác")} · ${screen.width}x${screen.height}@${devicePixelRatio}`;
}
function logScan(e) {
	try {
		const list = JSON.parse(localStorage.getItem(KEY) ?? "[]");
		localStorage.setItem(KEY, JSON.stringify(addEntry(list, {
			at: (/* @__PURE__ */ new Date()).toISOString(),
			device: deviceInfo(),
			...e
		})));
	} catch {}
}
function readScanLog() {
	try {
		return JSON.parse(localStorage.getItem(KEY) ?? "[]");
	} catch {
		return [];
	}
}
function clearScanLog() {
	try {
		localStorage.removeItem(KEY);
	} catch {}
}
//#endregion
export { readScanLog as a, newScanSession as i, deviceInfo as n, scan_log_exports as o, logScan as r, clearScanLog as t };
