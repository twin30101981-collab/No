//#region node_modules/.nitro/vite/services/ssr/assets/pdf.worker.min-BFJhmjfM.js
var pdf_worker_min_default = "/assets/pdf.worker.min-Dkey6ZUl.mjs";
//#endregion
export { pdf_worker_min_default as default };
