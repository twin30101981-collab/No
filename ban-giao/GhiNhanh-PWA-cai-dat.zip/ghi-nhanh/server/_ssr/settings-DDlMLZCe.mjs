import { o as __toESM, r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { D as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as safeSet } from "./safe-storage-DnXnZPA0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-DDlMLZCe.js
var settings_DDlMLZCe_exports = /* @__PURE__ */ __exportAll({
	a: () => lockNow,
	c: () => unlocked,
	i: () => installAutoLock,
	l: () => useLockTick,
	n: () => getSettings,
	o: () => setSettings,
	r: () => hashPin,
	s: () => settings_exports,
	t: () => getPinSalt,
	u: () => useSettings
});
var import_react = /* @__PURE__ */ __toESM(require_react());
var settings_exports = /* @__PURE__ */ __exportAll$1({
	getPinSalt: () => getPinSalt,
	getSettings: () => getSettings,
	hashPin: () => hashPin,
	installAutoLock: () => installAutoLock,
	lockNow: () => lockNow,
	setSettings: () => setSettings,
	unlocked: () => unlocked,
	useLockTick: () => useLockTick,
	useSettings: () => useSettings
});
var DEFAULTS = {
	quality: "high",
	paper: "a4",
	ocrLang: "vie+eng",
	dark: false,
	pin: "",
	autoLock: 1,
	autoCapture: true,
	maxQuality: false,
	captureSound: true,
	captureVibrate: true,
	defaultFilter: "auto",
	autoName: true,
	autoOcr: true,
	nameTemplate: "{ten}",
	folderRules: [],
	largeText: false,
	onboarded: false,
	voiceGuide: false,
	guideVibrate: true
};
var KEY = "ghi-nhanh-settings";
var listeners = /* @__PURE__ */ new Set();
function getSettings() {
	if (typeof window === "undefined") return DEFAULTS;
	try {
		return {
			...DEFAULTS,
			...JSON.parse(localStorage.getItem(KEY) ?? "{}")
		};
	} catch {
		return DEFAULTS;
	}
}
function setSettings(patch) {
	safeSet(KEY, JSON.stringify({
		...getSettings(),
		...patch
	}));
	listeners.forEach((l) => l());
}
function useSettings() {
	const [s, set] = (0, import_react.useState)(DEFAULTS);
	(0, import_react.useEffect)(() => {
		const l = () => set(getSettings());
		l();
		listeners.add(l);
		return () => {
			listeners.delete(l);
		};
	}, []);
	return s;
}
async function hashPin(pin) {
	const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("gn:" + pin));
	return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
var unlocked = /* @__PURE__ */ new Set();
/** Khoá lại mọi tài liệu đã mở; các màn hình đang mở sẽ hiện lại ô nhập PIN. */
var lockTick = 0;
var lockListeners = /* @__PURE__ */ new Set();
function lockNow() {
	unlocked.clear();
	lockTick++;
	lockListeners.forEach((l) => l());
	import("./db-CclUQaLE.mjs").then((n) => n.r).then((n) => n.n).then((m) => m.lockVault());
}
/** Muối PBKDF2 cho khoá mã hoá; tạo một lần cho máy có PIN từ trước khi có mã hoá. */
function getPinSalt() {
	const s = getSettings();
	if (s.pinSalt) return s.pinSalt;
	const salt = btoa(String.fromCharCode(...crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(16))));
	setSettings({ pinSalt: salt });
	return salt;
}
function useLockTick() {
	const [t, set] = (0, import_react.useState)(lockTick);
	(0, import_react.useEffect)(() => {
		const l = () => set(lockTick);
		lockListeners.add(l);
		return () => {
			lockListeners.delete(l);
		};
	}, []);
	return t;
}
/** Tự khoá sau N phút không thao tác hoặc khi rời ứng dụng quá N phút (0 = khoá ngay khi rời). */
function installAutoLock() {
	let last = Date.now();
	let hiddenAt = 0;
	const active = () => {
		last = Date.now();
	};
	const limit = () => {
		const s = getSettings();
		return s.pin && s.autoLock >= 0 ? s.autoLock * 6e4 : Infinity;
	};
	const vis = () => {
		if (document.hidden) {
			hiddenAt = Date.now();
			if (limit() === 0) lockNow();
		} else if (hiddenAt && Date.now() - hiddenAt >= limit()) lockNow();
	};
	const t = setInterval(() => {
		const l = limit();
		if (l > 0 && unlocked.size && Date.now() - last >= l) lockNow();
	}, 1e4);
	const evs = [
		"pointerdown",
		"keydown",
		"scroll"
	];
	evs.forEach((e) => window.addEventListener(e, active, { passive: true }));
	document.addEventListener("visibilitychange", vis);
	return () => {
		clearInterval(t);
		evs.forEach((e) => window.removeEventListener(e, active));
		document.removeEventListener("visibilitychange", vis);
	};
}
//#endregion
export { lockNow as a, unlocked as c, installAutoLock as i, useLockTick as l, getSettings as n, setSettings as o, hashPin as r, settings_DDlMLZCe_exports as s, getPinSalt as t, useSettings as u };
