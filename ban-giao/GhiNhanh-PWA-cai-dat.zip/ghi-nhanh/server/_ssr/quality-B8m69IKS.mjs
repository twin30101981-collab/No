import { t as SCAN_ERRORS } from "./scan-errors-Bcd_8AUe.mjs";
import { A as loadImg, C as estimateSkew, T as glare, V as sharpness, Z as yieldTask, m as detectPaperAsync } from "./image-DFWRNlNd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quality-B8m69IKS.js
/** Ngưỡng có thể hiệu chỉnh sau khi đo trên nhiều điện thoại thật. */
var QUALITY_THRESHOLDS = {
	BLUR_REJECT: 12,
	BLUR_WARNING: 35,
	DARK_REJECT: 55,
	DARK_WARNING: 90,
	CONTRAST_WARNING: 28,
	GLARE_LIGHT: .005,
	GLARE_WARNING: .02,
	GLARE_REJECT: .08,
	SKEW_AUTO_FIX: 5,
	MIN_SIDE_REJECT: 600,
	MIN_SIDE_WARNING: 1e3
};
/** P1.2: độ sáng trung bình (0–255) của dữ liệu RGBA, lấy mẫu cách bước để chạy nhanh trên khung xem trước. */
function meanLumaRGBA(d, step = 4) {
	let sum = 0, n = 0;
	for (let i = 0; i + 2 < d.length; i += 4 * step) {
		sum += .299 * d[i] + .587 * d[i + 1] + .114 * d[i + 2];
		n++;
	}
	return n ? sum / n : 0;
}
/** P1.2: thiếu sáng khi chụp — dùng chung ngưỡng DARK_* với cổng chất lượng. */
function lightLevel(mean) {
	return mean < QUALITY_THRESHOLDS.DARK_REJECT ? "dark" : mean < QUALITY_THRESHOLDS.DARK_WARNING ? "dim" : "ok";
}
function lumaStats(img) {
	const s = 200 / Math.max(img.naturalWidth, img.naturalHeight);
	const w = Math.max(8, Math.round(img.naturalWidth * s)), h = Math.max(8, Math.round(img.naturalHeight * s));
	const c = document.createElement("canvas");
	c.width = w;
	c.height = h;
	const ctx = c.getContext("2d");
	ctx.drawImage(img, 0, 0, w, h);
	const d = ctx.getImageData(0, 0, w, h).data;
	let sum = 0, sq = 0;
	const n = w * h;
	for (let i = 0; i < d.length; i += 4) {
		const l = .299 * d[i] + .587 * d[i + 1] + .114 * d[i + 2];
		sum += l;
		sq += l * l;
	}
	c.width = 0;
	const mean = sum / n;
	return {
		mean,
		std: Math.sqrt(Math.max(0, sq / n - mean * mean))
	};
}
/** Phân loại chói: chói vùng giữa (nơi có chữ) nặng hơn chói ở mép. */
function glareLevel(total, center) {
	const T = QUALITY_THRESHOLDS;
	if (total > T.GLARE_REJECT) return "severe";
	if (center > T.GLARE_WARNING) return "text";
	if (total > T.GLARE_LIGHT) return "light";
	return "none";
}
/** Điểm chất lượng 0–100 từ các chỉ số (để ghi nhật ký & so sánh). */
function qualityScore(m) {
	const T = QUALITY_THRESHOLDS;
	const clamp = (v) => Math.max(0, Math.min(1, v));
	const s = .35 * clamp((m.blur - T.BLUR_REJECT) / (T.BLUR_WARNING * 2 - T.BLUR_REJECT)) + .2 * clamp((m.brightness - T.DARK_REJECT) / (150 - T.DARK_REJECT)) + .15 * clamp(m.contrast / 60) + .15 * clamp(1 - m.glare / T.GLARE_REJECT) + .15 * clamp((m.side - T.MIN_SIDE_REJECT) / (1600 - T.MIN_SIDE_REJECT));
	return Math.round(s * 100);
}
var issue = (code, level, extra) => ({
	code,
	level,
	message: `${SCAN_ERRORS[code].message}${extra ? " " + extra : ""} ${level === "reject" ? SCAN_ERRORS[code].hint : ""}`.trim()
});
/** Image Quality Gate: kiểm tra mờ, tối, tương phản, chói, nghiêng, mép giấy và độ phân giải trước khi gửi AI. */
async function checkQuality(src, opts = {}) {
	const T = QUALITY_THRESHOLDS;
	const img = await loadImg(src);
	const W = img.naturalWidth, H = img.naturalHeight;
	const blur = sharpness(img, W, H);
	await yieldTask();
	const gl = glare(img, W, H);
	await yieldTask();
	const glCenter = glare(img, W, H, [
		[.2, .2],
		[.8, .2],
		[.8, .8],
		[.2, .8]
	]);
	await yieldTask();
	const { mean, std } = lumaStats(img), side = Math.min(W, H);
	let skew = 0;
	try {
		await yieldTask();
		const c = document.createElement("canvas");
		const s = Math.min(1, 900 / Math.max(W, H));
		c.width = Math.round(W * s);
		c.height = Math.round(H * s);
		c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
		await yieldTask();
		skew = estimateSkew(c);
		c.width = 0;
	} catch {}
	const paper = opts.cropped === false ? await detectPaperAsync(img, W, H) : null;
	const issues = [];
	if (blur < T.BLUR_REJECT) issues.push(issue("SCAN_IMAGE_TOO_BLURRY", "reject"));
	else if (blur < T.BLUR_WARNING) issues.push(issue("SCAN_IMAGE_TOO_BLURRY", "warn", "(nhẹ)"));
	if (mean < T.DARK_REJECT) issues.push(issue("SCAN_LOW_CONTRAST", "reject"));
	else if (mean < T.DARK_WARNING || std < T.CONTRAST_WARNING) issues.push(issue("SCAN_LOW_CONTRAST", "warn"));
	const gLevel = glareLevel(gl, glCenter);
	if (gLevel === "severe" || gLevel === "text") issues.push(issue("SCAN_EXCESSIVE_GLARE", "reject"));
	else if (gLevel === "light") issues.push({
		code: "SCAN_EXCESSIVE_GLARE",
		level: "warn",
		message: "Có vùng chói nhẹ ngoài vùng chữ — vẫn xử lý được."
	});
	if (Math.abs(skew) >= T.SKEW_AUTO_FIX - .5) issues.push(issue("SCAN_EXCESSIVE_SKEW", "warn"));
	if (opts.cropped === false && !paper) issues.push(issue("SCAN_DOCUMENT_NOT_FOUND", "warn"));
	if (side < T.MIN_SIDE_REJECT) issues.push(issue("SCAN_LOW_RESOLUTION", "reject"));
	else if (side < T.MIN_SIDE_WARNING) issues.push(issue("SCAN_LOW_RESOLUTION", "warn"));
	const level = issues.some((i) => i.level === "reject") ? "reject" : issues.length ? "warn" : "ok";
	const score = qualityScore({
		blur,
		brightness: mean,
		contrast: std,
		glare: gl,
		side
	});
	return {
		level,
		score,
		glareLevel: gLevel,
		issues,
		metrics: {
			blur: Math.round(blur),
			brightness: Math.round(mean),
			contrast: Math.round(std),
			glare: +gl.toFixed(3),
			glareCenter: +glCenter.toFixed(3),
			skew: +skew.toFixed(1),
			width: W,
			height: H,
			score
		}
	};
}
//#endregion
export { meanLumaRGBA as i, checkQuality as n, lightLevel as r, QUALITY_THRESHOLDS as t };
