import { o as __toESM } from "../_runtime.mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { i as showError } from "./errors-DKvrPJ4v.mjs";
import { X as LoaderCircle } from "../_libs/lucide-react.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { c as download, x as safeName } from "./files-CTF11Arr.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, t as Dialog } from "./dialog-3HhpKDcy.mjs";
import { t as Input } from "./input-T4LKa1EA.mjs";
import { n as importP12, r as isCertValid, signPdf, t as createP12 } from "./pdf-sign-B8m2eUFO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/digital-sign-dialog-DE4H7Ouz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Ký số PDF bằng chứng thư .p12 — mọi bước chạy trên máy. */
function DigitalSignDialog({ open, onClose }) {
	const [pdf, setPdf] = (0, import_react.useState)(null);
	const [p12, setP12] = (0, import_react.useState)(null);
	const [p12Name, setP12Name] = (0, import_react.useState)("");
	const [pw, setPw] = (0, import_react.useState)("");
	const [cn, setCn] = (0, import_react.useState)("");
	const [reason, setReason] = (0, import_react.useState)("Duyệt tài liệu");
	const [location, setLocation] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)("");
	const makeCert = async () => {
		setBusy("Đang tạo chứng thư…");
		await new Promise((r) => setTimeout(r, 30));
		try {
			const r = createP12({
				commonName: cn,
				password: pw
			});
			setP12(r.p12Bytes);
			setP12Name(`${safeName(cn)}.p12`);
			download(new Blob([r.p12Bytes], { type: "application/x-pkcs12" }), `${safeName(cn)}.p12`);
			toast.success("Đã tạo và lưu tệp chứng thư — hãy giữ cẩn thận cùng mật khẩu.");
		} catch (e) {
			showError(e, "Không tạo được chứng thư");
		} finally {
			setBusy("");
		}
	};
	const sign = async () => {
		if (!pdf || !p12) return;
		setBusy("Đang ký…");
		try {
			const key = importP12(p12, pw);
			if (!isCertValid(key.info)) throw new Error("Chứng thư đã hết hạn hoặc chưa có hiệu lực.");
			const out = await signPdf(new Uint8Array(await pdf.arrayBuffer()), key, {
				reason,
				location
			});
			download(new Blob([out], { type: "application/pdf" }), `${safeName(pdf.name.replace(/\.pdf$/i, ""))}-da-ky.pdf`);
			toast.success(`Đã ký số bởi ${key.info.commonName}`);
			onClose();
		} catch (e) {
			showError(e, "Không ký được tệp này");
		} finally {
			setBusy("");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-[92vw] rounded-[18px] sm:max-w-[420px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "font-display",
				children: "Ký số PDF"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "1. Tệp PDF"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "file",
							accept: "application/pdf",
							"aria-label": "Chọn tệp PDF",
							onChange: (e) => setPdf(e.target.files?.[0] ?? null)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "2. Chứng thư (.p12)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "file",
								accept: ".p12,.pfx",
								"aria-label": "Chọn tệp chứng thư",
								onChange: async (e) => {
									const f = e.target.files?.[0];
									if (f) {
										setP12(new Uint8Array(await f.arrayBuffer()));
										setP12Name(f.name);
									}
								}
							}),
							p12Name && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: ["Đang dùng: ", p12Name]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "password",
						placeholder: "Mật khẩu chứng thư (≥ 6 ký tự)",
						"aria-label": "Mật khẩu chứng thư",
						value: pw,
						onChange: (e) => setPw(e.target.value)
					}),
					!p12 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 rounded-lg bg-muted p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Chưa có chứng thư? Tạo chứng thư tự ký (dùng nội bộ) bằng mật khẩu ở trên."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Họ tên người ký",
								"aria-label": "Họ tên người ký",
								value: cn,
								onChange: (e) => setCn(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								size: "sm",
								disabled: !!busy || !cn.trim() || pw.length < 6,
								onClick: makeCert,
								children: "Tạo chứng thư"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Lý do ký",
						"aria-label": "Lý do ký",
						value: reason,
						onChange: (e) => setReason(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Nơi ký (tuỳ chọn)",
						"aria-label": "Nơi ký",
						value: location,
						onChange: (e) => setLocation(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						disabled: !!busy || !pdf || !p12 || !pw,
						onClick: sign,
						children: busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }), busy] }) : "Ký và tải về"
					})
				]
			})]
		})
	});
}
//#endregion
export { DigitalSignDialog };
