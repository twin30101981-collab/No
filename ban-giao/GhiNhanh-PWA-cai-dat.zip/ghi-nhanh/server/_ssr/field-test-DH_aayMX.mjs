import { o as __toESM } from "../_runtime.mjs";
import { n as init_performance, r as performance_default } from "../_libs/canvg+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { i as showError } from "./errors-DKvrPJ4v.mjs";
import { H as PencilRuler, It as Download, X as LoaderCircle, Xt as Check, f as Trash2, ot as ImagePlus, r as X } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-CZvf2xHx.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { A as loadImg, g as detectQuadFromSrc, j as normalize } from "./image-DFWRNlNd.mjs";
import { c as download } from "./files-CTF11Arr.mjs";
import { n as pickFiles } from "./importer-BUHDogNt.mjs";
import { n as checkQuality } from "./quality-B8m69IKS.mjs";
import { t as CropEditor } from "./crop-editor-CWKLJmf0.mjs";
import { n as cornerError } from "./crop-bench-CnNlpcAa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/field-test-DH_aayMX.js
init_performance();
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var median = (a) => {
	if (!a.length) return 0;
	const s = [...a].sort((x, y) => x - y);
	const m = s.length >> 1;
	return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};
var mean = (a) => a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0;
var r3 = (x) => Math.round(x * 1e3) / 1e3;
/** Error ≤ tol (share of diagonal) counts as a correct detection. */
function fieldReport(samples, device = "", tol = .03) {
	const judged = samples.filter((s) => s.verdict !== "pending");
	let hit = 0, miss = 0, falseFind = 0;
	const errs = [];
	for (const s of judged) {
		if (!s.truth) {
			if (s.detected) falseFind++;
			continue;
		}
		if (!s.detected) {
			miss++;
			continue;
		}
		const e = cornerError(s.detected, s.truth, s.width, s.height);
		errs.push(e);
		if (e <= tol) hit++;
		else miss++;
	}
	const withPaper = judged.filter((s) => s.truth).length;
	const ms = samples.map((s) => s.ms);
	const q = (v) => r3(mean(judged.filter((s) => s.verdict === v).map((s) => s.quality.score)));
	const rep = {
		device,
		total: samples.length,
		judged: judged.length,
		hit,
		miss,
		falseFind,
		hitRate: withPaper ? r3(hit / withPaper) : 0,
		meanError: r3(mean(errs)),
		worstError: r3(Math.max(0, ...errs)),
		medianMs: Math.round(median(ms)),
		slowMs: Math.round(Math.max(0, ...ms)),
		qualityByVerdict: {
			ok: q("ok"),
			fixed: q("fixed")
		},
		suggestions: []
	};
	if (withPaper >= 5 && rep.hitRate < .8) rep.suggestions.push("Tỉ lệ dò đúng dưới 80%: nên nới ngưỡng điểm khung hoặc dùng AI dò mép sớm hơn.");
	if (falseFind >= 2) rep.suggestions.push("Có ảnh không có giấy mà app vẫn thấy khung: nên tăng ngưỡng điểm khung.");
	if (rep.medianMs > 800) rep.suggestions.push("Dò khung chậm trên máy này: nên giảm cỡ ảnh dò.");
	const okBlur = judged.filter((s) => s.verdict !== "nopaper").map((s) => s.quality.blur);
	if (okBlur.length >= 5 && median(okBlur) < 35) rep.suggestions.push("Độ nét trung vị thấp hơn ngưỡng cảnh báo: có thể ngưỡng mờ quá chặt với máy này.");
	return rep;
}
var KEY = "gn-field-test";
function loadField() {
	try {
		return JSON.parse(localStorage.getItem(KEY) || "[]");
	} catch {
		return [];
	}
}
function saveField(l) {
	localStorage.setItem(KEY, JSON.stringify(l));
}
var poly = (q) => q.map(([x, y]) => `${x * 100},${y * 100}`).join(" ");
function FieldTest() {
	const [list, setList] = (0, import_react.useState)([]);
	const [thumbs, setThumbs] = (0, import_react.useState)({});
	const [busy, setBusy] = (0, import_react.useState)(0);
	const [edit, setEdit] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setList(loadField());
	}, []);
	const commit = (l) => {
		setList(l);
		saveField(l);
	};
	const report = (0, import_react.useMemo)(() => fieldReport(list, typeof navigator === "undefined" ? "" : navigator.userAgent), [list]);
	const add = async () => {
		const files = await pickFiles("image/*", true);
		if (!files.length) return;
		setBusy(files.length);
		let cur = list;
		for (const f of files) {
			try {
				const src = await normalize(f, 2e3, .9);
				const img = await loadImg(src);
				const t0 = performance_default.now();
				const detected = await detectQuadFromSrc(src);
				const ms = performance_default.now() - t0;
				const qr = await checkQuality(src, { cropped: false });
				const m = qr.metrics;
				const id = crypto.randomUUID();
				setThumbs((t) => ({
					...t,
					[id]: src
				}));
				cur = [{
					id,
					name: f.name,
					width: img.naturalWidth,
					height: img.naturalHeight,
					ms,
					detected,
					truth: detected,
					verdict: "pending",
					quality: {
						score: qr.score,
						level: qr.level,
						blur: m.blur,
						brightness: m.brightness,
						contrast: m.contrast,
						glare: m.glare,
						skew: m.skew
					}
				}, ...cur];
				commit(cur);
			} catch (e) {
				showError(e, `Không đọc được ảnh ${f.name}`);
			}
			setBusy((b) => b - 1);
		}
	};
	const set = (id, p) => commit(list.map((s) => s.id === id ? {
		...s,
		...p
	} : s));
	const exportReport = () => {
		const body = {
			report,
			samples: list.map(({ id: _id, ...s }) => s),
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		download(new Blob([JSON.stringify(body, null, 2)], { type: "application/json" }), "bao-cao-thu-thuc-te.json");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Thử trên điện thoại thật",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Chọn vài ảnh tài liệu chụp bằng máy này (cả ảnh khó: nghiêng, tối, nền rối, và 1–2 ảnh không có giấy). Với mỗi ảnh, bấm Đúng, Sửa khung, hoặc Không có giấy. Ảnh chỉ nằm trên máy; báo cáo chỉ gồm con số."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: add,
						disabled: busy > 0,
						children: busy > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }),
							" Còn ",
							busy,
							" ảnh"
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {}), " Thêm ảnh"] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: exportReport,
						disabled: !list.length,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), " Xuất báo cáo"]
					})]
				}),
				list.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border bg-card p-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-2xl font-semibold",
									children: [Math.round(report.hitRate * 100), "%"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Dò đúng"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-2xl font-semibold",
									children: [
										report.judged,
										"/",
										report.total
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Đã chấm"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-2xl font-semibold",
									children: [report.medianMs, " ms"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Thời gian dò"
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-muted-foreground",
							children: [
								"Sai lệch góc trung bình ",
								(report.meanError * 100).toFixed(1),
								"% · lớn nhất ",
								(report.worstError * 100).toFixed(1),
								"% · thấy khung nhầm ",
								report.falseFind
							]
						}),
						report.suggestions.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-destructive",
							children: ["• ", t]
						}, t)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							className: "mt-1",
							onClick: () => {
								commit([]);
								setThumbs({});
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Xoá kết quả thử"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-3",
					children: list.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3 rounded-2xl border bg-card p-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative w-24 shrink-0",
							children: [thumbs[s.id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: thumbs[s.id],
								alt: s.name,
								className: "block w-full rounded-lg"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid aspect-[3/4] place-items-center rounded-lg bg-muted text-[0.625rem] text-muted-foreground",
								children: "Ảnh không lưu"
							}), thumbs[s.id] && s.detected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								viewBox: "0 0 100 100",
								preserveAspectRatio: "none",
								className: "pointer-events-none absolute inset-0 h-full w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
									points: poly(s.detected),
									className: "scan-quad"
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 space-y-1 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-medium",
									children: s.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-muted-foreground",
									children: [
										s.detected ? "Thấy khung" : "Không thấy khung",
										" · ",
										Math.round(s.ms),
										" ms · chất lượng ",
										s.quality.score
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: {
										ok: "✓ Đúng",
										fixed: "Đã sửa khung",
										nopaper: "Không có giấy",
										pending: "Chưa chấm"
									}[s.verdict]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											variant: "outline",
											disabled: !s.detected,
											onClick: () => set(s.id, {
												verdict: "ok",
												truth: s.detected
											}),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), " Đúng"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											variant: "outline",
											disabled: !thumbs[s.id],
											onClick: () => setEdit(s),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PencilRuler, {}), " Sửa"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => set(s.id, {
												verdict: "nopaper",
												truth: null
											}),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}), " Không giấy"]
										})
									]
								})
							]
						})]
					}, s.id))
				})
			]
		}), edit && thumbs[edit.id] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CropEditor, {
			src: thumbs[edit.id],
			quad: edit.truth ?? void 0,
			onClose: () => setEdit(null),
			applyLabel: "Lưu khung đúng",
			onApply: (q) => {
				set(edit.id, {
					verdict: "fixed",
					truth: q
				});
				setEdit(null);
				toast.success("Đã ghi khung đúng");
			}
		})]
	});
}
//#endregion
export { FieldTest as component };
