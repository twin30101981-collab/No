import { o as __toESM } from "../_runtime.mjs";
import { D as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as fpOf } from "./disk-pack-ZdDKsocx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/preview-src-DrbqV_z6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/** S15g: xem trước ≤1200 px, dựng lười. Màn xem tài liệu không giải mã ảnh gốc nhiều MB;
*  chỉ trang đang xem ±1 được thu nhỏ (object URL, LRU), trang xa không dựng. */
var PREVIEW_MAX = 1200;
function previewSize(w, h, max = PREVIEW_MAX) {
	const s = Math.min(1, max / Math.max(w, h, 1));
	return {
		w: Math.max(1, Math.round(w * s)),
		h: Math.max(1, Math.round(h * s)),
		scaled: s < 1
	};
}
/** Trang i có cần dựng khi đang xem trang active không. */
var inPreviewWindow = (i, active, radius = 1) => Math.abs(i - active) <= radius;
var cache = /* @__PURE__ */ new Map();
var pending = /* @__PURE__ */ new Map();
function touch(k, u) {
	cache.delete(k);
	cache.set(k, u);
	while (cache.size > 8) {
		const [old, url] = cache.entries().next().value;
		cache.delete(old);
		if (url.startsWith("blob:") && !url.endsWith("#orig")) URL.revokeObjectURL(url);
	}
}
async function build(src) {
	const blob = await (await fetch(src)).blob();
	const bmp = await createImageBitmap(blob);
	const sz = previewSize(bmp.width, bmp.height);
	if (!sz.scaled) {
		bmp.close();
		return src;
	}
	const c = document.createElement("canvas");
	c.width = sz.w;
	c.height = sz.h;
	const g = c.getContext("2d");
	g.imageSmoothingQuality = "high";
	g.drawImage(bmp, 0, 0, sz.w, sz.h);
	bmp.close();
	const out = await new Promise((r) => c.toBlob(r, "image/jpeg", .85));
	return out ? URL.createObjectURL(out) : src;
}
function getPreview(src) {
	const k = fpOf(src);
	const hit = cache.get(k);
	if (hit) {
		touch(k, hit);
		return Promise.resolve(hit);
	}
	let p = pending.get(k);
	if (!p) {
		p = build(src).then((u) => {
			if (u !== src) touch(k, u);
			return u;
		}).catch(() => src).finally(() => pending.delete(k));
		pending.set(k, p);
	}
	return p;
}
/** Trả nguồn xem trước; null khi chưa cần dựng (enabled=false).
*  B14: fallback (ảnh thu nhỏ riêng của trang) hiện ngay trong lúc dựng bản xem trước. */
function usePreview(src, enabled, fallback) {
	const [url, setUrl] = (0, import_react.useState)(() => cache.get(fpOf(src)) ?? null);
	(0, import_react.useEffect)(() => {
		if (!enabled) return;
		let live = true;
		getPreview(src).then((u) => {
			if (live) setUrl(u);
		});
		return () => {
			live = false;
		};
	}, [src, enabled]);
	return url ?? fallback ?? null;
}
//#endregion
export { previewSize as n, usePreview as r, inPreviewWindow as t };
