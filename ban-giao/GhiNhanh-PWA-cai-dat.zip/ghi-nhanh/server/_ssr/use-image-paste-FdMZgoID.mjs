import { o as __toESM } from "../_runtime.mjs";
import { D as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { l as isEditingText, o as clipboardImages } from "./importer-BUHDogNt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-image-paste-FdMZgoID.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/** Active only on intake screens; never consumes ordinary text paste. */
function useImagePaste(onImages, enabled = true) {
	const latest = (0, import_react.useRef)(onImages);
	latest.current = onImages;
	const running = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!enabled) return;
		const paste = (event) => {
			if (event.defaultPrevented || isEditingText(event.target)) return;
			const files = clipboardImages(event.clipboardData);
			if (!files.length) return;
			event.preventDefault();
			if (running.current) return;
			running.current = true;
			latest.current(files).finally(() => {
				running.current = false;
			});
		};
		document.addEventListener("paste", paste);
		return () => document.removeEventListener("paste", paste);
	}, [enabled]);
}
//#endregion
export { useImagePaste as t };
