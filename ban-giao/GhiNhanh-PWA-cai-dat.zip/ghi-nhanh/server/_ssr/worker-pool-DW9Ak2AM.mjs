//#region node_modules/.nitro/vite/services/ssr/assets/worker-pool-DW9Ak2AM.js
/**
* R2.1: Bể Worker chung cho detect / preview / normalize / image (pixels).
* Một bể duy nhất (kích thước poolSizeFor, kẹp 2..4) với hàng đợi ưu tiên:
* số nhỏ chạy trước — detect (0, nhịp ngắm trực tiếp) > preview (1) > normalize (2) > pixels (3, dựng trang nặng).
* Mỗi Worker chỉ nhận 1 việc tại một thời điểm; việc mới chọn Worker rảnh, không có thì xếp hàng theo ưu tiên.
* Không có Worker hoặc Worker lỗi → gọi nơi trả null/để tầng trên rơi về luồng chính.
*/
/** Số Worker trong bể: lõi − 1, kẹp 2..4. */
function poolSizeFor(cores) {
	return Math.max(2, Math.min(4, (Number.isFinite(cores) && cores > 0 ? cores : 2) - 1));
}
/** Mức ưu tiên: nhỏ chạy trước. R2.2: thêm page (dựng trang nền) và compress (trang PDF). */
var PRIORITY = {
	detect: 0,
	frame: 0,
	grade: 2,
	preview: 1,
	normalize: 2,
	pixels: 3,
	gpuwarp: 3,
	render: 3,
	quick: 2,
	page: 4,
	compress: 5
};
var slots;
var queue = [];
var jobs = /* @__PURE__ */ new Map();
var seq = 0;
/** Hỗ trợ OffscreenCanvas (cần cho normalize/preview); pixels/detect chỉ cần Worker. */
function poolCanvasSupported() {
	return typeof Worker !== "undefined" && typeof OffscreenCanvas !== "undefined" && typeof createImageBitmap === "function";
}
function spawn() {
	try {
		const w = new Worker(new URL("./pool.worker.ts", import.meta.url), { type: "module" });
		const slot = {
			w,
			busy: false
		};
		w.onmessage = (e) => {
			slot.busy = false;
			const j = jobs.get(e.data.id);
			jobs.delete(e.data.id);
			if (j) {
				const ok = e.data["out"] !== void 0 || e.data["det"] !== void 0 || e.data["blob"] !== void 0 || e.data["main"] !== void 0 || e.data["page"] !== void 0;
				if (e.data["error"] !== void 0 && !ok) j.pending.reject(e.data);
				else j.pending.resolve(e.data);
			}
			pump();
		};
		w.onerror = () => {
			slot.busy = false;
			for (const [id, j] of jobs) if (j.slot === slot) {
				jobs.delete(id);
				j.pending.reject({ error: "worker" });
			}
			if (slots) slots = slots.filter((s) => s !== slot);
			pump();
		};
		return slot;
	} catch {
		return null;
	}
}
/** Lấy bể; null khi trình duyệt không có Worker. */
function getSharedPool() {
	if (slots !== void 0) return slots && slots.length ? slots : null;
	if (typeof Worker === "undefined") return slots = null;
	const n = poolSizeFor(typeof navigator !== "undefined" ? navigator.hardwareConcurrency : void 0);
	const made = [];
	for (let i = 0; i < n; i++) {
		const s = spawn();
		if (s) made.push(s);
	}
	slots = made.length ? made : null;
	return slots;
}
function pump() {
	const pool = slots;
	if (!pool) return;
	const free = pool.find((s) => !s.busy);
	if (!free || !queue.length) return;
	let bi = 0;
	for (let i = 1; i < queue.length; i++) if (PRIORITY[queue[i].kind] < PRIORITY[queue[bi].kind]) bi = i;
	const j = queue.splice(bi, 1)[0];
	free.busy = true;
	j.slot = free;
	try {
		free.w.postMessage({
			id: ++seq,
			kind: j.kind,
			...j.payload
		}, j.transfer);
	} catch (err) {
		free.busy = false;
		j.pending.reject({ error: String(err) });
		pump();
		return;
	}
	jobs.set(seq, j);
}
/**
* Đẩy việc vào bể. Trả null khi không có Worker (gọi nơi tự chạy luồng chính).
* Kết quả là MessageEvent.data của Worker; lỗi reject với { error }.
*/
function runInPool(kind, payload, transfer = []) {
	if (!getSharedPool()) return null;
	return new Promise((resolve, reject) => {
		queue.push({
			kind,
			payload,
			transfer,
			pending: {
				resolve,
				reject
			}
		});
		pump();
	});
}
//#endregion
export { runInPool as n, poolCanvasSupported as t };
