import { o as __toESM } from "../_runtime.mjs";
import { w as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { Zt as Camera, ct as House, i as Wrench, s as UserRound, vt as FolderOpen } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-shell-CZvf2xHx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Fired once the page frame has hydrated; first-run dialogs wait for it (see onboarding.tsx). */
var SHELL_HYDRATED = "gn:shell-hydrated";
function isShellHydrated() {
	return typeof window !== "undefined" && Boolean(window.__gnShell);
}
/** Phone-only frame: centered 430px column with a thumb-reach bottom bar. */
function AppShell({ children, title, action, wide }) {
	(0, import_react.useEffect)(() => {
		window.__gnShell = true;
		window.dispatchEvent(new Event(SHELL_HYDRATED));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "app-shell min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ambient ambient-one" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ambient ambient-two" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `phone-frame relative mx-auto flex min-h-dvh w-full max-w-[430px] flex-col pb-[calc(96px+env(safe-area-inset-bottom))] ${wide ? "lg:max-w-[880px]" : ""}`,
				children: [title && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "rise grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-5 pt-[max(1.25rem,env(safe-area-inset-top))]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display truncate text-xl font-semibold",
						children: title
					}), action]
				}), children]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: `bottom-nav fixed inset-x-0 bottom-0 z-30 mx-auto grid w-full max-w-[430px] grid-cols-5 items-end px-2 pb-[env(safe-area-inset-bottom)] pt-1.5 ${wide ? "lg:max-w-[880px]" : ""}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavItem, {
						to: "/",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, {}),
						label: "Trang chủ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavItem, {
						to: "/documents",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, {}),
						label: "Tài liệu"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/scan",
						"aria-label": "Quét tài liệu",
						className: "camera-button mx-auto mb-3 grid size-[60px] -translate-y-3 place-items-center rounded-full bg-primary text-primary-foreground active:scale-95",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-7" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavItem, {
						to: "/tools",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, {}),
						label: "Công cụ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavItem, {
						to: "/me",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {}),
						label: "Tôi"
					})
				]
			})
		]
	});
}
function NavItem({ to, icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		activeOptions: { exact: true },
		className: "flex h-14 min-w-0 flex-col items-center justify-center gap-1 text-[0.625rem] font-semibold text-muted-foreground [&_svg]:size-5",
		activeProps: { className: "text-primary" },
		children: [icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "truncate",
			children: label
		})]
	});
}
//#endregion
export { SHELL_HYDRATED as n, isShellHydrated as r, AppShell as t };
