//#region node_modules/.nitro/vite/services/ssr/assets/scan-diagnose-HshWtdyP.js
/** S12 – Chẩn đoán ảnh quét bằng AI: phần thuần (chặn ảnh hỏng, chuẩn hoá kết quả, khoá phiên bản). */
var DIAG_GROUPS = [
	"shadow",
	"edge_noise",
	"cut_text",
	"skew"
];
var DIAG_LABEL = {
	shadow: "Bóng/vệt tối",
	edge_noise: "Rác mép",
	cut_text: "Mất chữ mép",
	skew: "Dòng cong/nghiêng"
};
/** Trần chuỗi data URL máy chủ nhận cho chẩn đoán (aiScanDiagnose dùng đúng hằng này). */
var MAX_DATA_CHARS = 4e6;
/** Chặn trước khi gửi: ảnh hỏng, quá nhỏ, quá lớn, ngoại tuyến. */
function guardImage(i) {
	if (!i.online) return {
		ok: false,
		reason: "Đang ngoại tuyến – chẩn đoán AI cần mạng."
	};
	if (!(i.width > 0 && i.height > 0 && i.bytes > 0)) return {
		ok: false,
		reason: "Ảnh hỏng, không đọc được."
	};
	if (Math.min(i.width, i.height) < 800) return {
		ok: false,
		reason: `Ảnh quá nhỏ (cạnh ngắn < 800px).`
	};
	if (i.bytes > 2999952) return {
		ok: false,
		reason: "Ảnh quá lớn để gửi (> 3 MB). Thử trang chưa làm nét HD."
	};
	return { ok: true };
}
/** Khoá phiên bản ảnh: cùng trang + cùng bộ lọc + cùng nội dung → cùng khoá. */
function imageVersion(pageId, filter, data) {
	let h1 = 2166136261, h2 = -624069552;
	for (let k = 0; k < data.length; k++) {
		const c = data.charCodeAt(k);
		h1 = Math.imul(h1 ^ c, 16777619);
		h2 = Math.imul(h2 ^ c, 2246822519);
	}
	return `${pageId}:${filter}:${data.length}:${(h1 >>> 0).toString(36)}${(h2 >>> 0).toString(36)}`;
}
/** Kết quả chỉ được gắn khi phiên bản còn khớp ảnh hiện tại. */
function matchesVersion(d, current) {
	return !!d && d.version === current;
}
var clamp01 = (v) => {
	const n = Number(v);
	return Number.isFinite(n) ? Math.min(1, Math.max(0, n)) : 0;
};
/** Chuẩn hoá câu trả lời AI: bỏ nhóm lạ, kẹp toạ độ/điểm, gộp trùng nhóm, sắp theo mức nặng. */
function normalizeDiagnosis(raw, version) {
	const r = raw ?? {};
	const by = /* @__PURE__ */ new Map();
	for (const it of Array.isArray(r.issues) ? r.issues : []) {
		const o = it;
		const g = o.group;
		if (!DIAG_GROUPS.includes(g)) continue;
		const regions = (Array.isArray(o.regions) ? o.regions : []).map((q) => {
			const p = q;
			const x = clamp01(p.x), y = clamp01(p.y);
			return {
				x,
				y,
				w: Math.min(clamp01(p.w), 1 - x),
				h: Math.min(clamp01(p.h), 1 - y)
			};
		}).filter((q) => q.w > .005 && q.h > .005).slice(0, 8);
		const issue = {
			group: g,
			severity: clamp01(o.severity),
			confidence: clamp01(o.confidence),
			note: String(o.note ?? "").slice(0, 200),
			regions
		};
		const prev = by.get(g);
		if (!prev) by.set(g, issue);
		else by.set(g, {
			...prev,
			severity: Math.max(prev.severity, issue.severity),
			confidence: Math.max(prev.confidence, issue.confidence),
			regions: [...prev.regions, ...issue.regions].slice(0, 8)
		});
	}
	return {
		version,
		issues: [...by.values()].filter((i) => i.severity > 0).sort((a, b) => b.severity - a.severity),
		summary: String(r.summary ?? "").slice(0, 300)
	};
}
/** Thông báo dự phòng theo mã lỗi (402/429/ngoại tuyến/khác). */
function diagFallback(code) {
	if (code === "offline") return "Đang ngoại tuyến. Ảnh vẫn được xử lý tự động; thử chẩn đoán khi có mạng.";
	if (code === 402) return "Hết lượt AI. Ảnh vẫn dùng được với xử lý tự động.";
	if (code === 429) return "AI đang quá tải, hãy thử lại sau khoảng một phút.";
	return "Chưa chẩn đoán được. Ảnh vẫn dùng được với xử lý tự động.";
}
/** Dòng log an toàn: chỉ mã và số lượng, không chứa nội dung tài liệu. */
function diagLogLine(version, d, code) {
	const ver = version.split(":").slice(1).join(":");
	return d ? `[s12] ok v=${ver} issues=${d.issues.map((i) => i.group).join(",") || "none"}` : `[s12] fail v=${ver} code=${code ?? 0}`;
}
//#endregion
export { guardImage as a, normalizeDiagnosis as c, diagLogLine as i, MAX_DATA_CHARS as n, imageVersion as o, diagFallback as r, matchesVersion as s, DIAG_LABEL as t };
