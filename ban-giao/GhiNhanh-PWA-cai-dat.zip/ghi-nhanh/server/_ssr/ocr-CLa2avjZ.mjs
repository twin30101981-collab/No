import { r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { n as getSettings } from "./settings-DDlMLZCe.mjs";
import { n as sharedOcr } from "./ocr-worker-DbwCMwXG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ocr-CLa2avjZ.js
var ocr_CLa2avjZ_exports = /* @__PURE__ */ __exportAll({
	a: () => recognize,
	i: () => pool,
	n: () => ocrSession,
	o: () => recognizeWordBoxes,
	r: () => ocr_exports,
	s: () => recognizeWords,
	t: () => classify
});
var ocr_exports = /* @__PURE__ */ __exportAll$1({
	V9_PROBE_MAX: () => V9_PROBE_MAX,
	classify: () => classify,
	ocrSession: () => ocrSession,
	pickOrientation: () => pickOrientation,
	pool: () => pool,
	recognize: () => recognize,
	recognizeWordBoxes: () => recognizeWordBoxes,
	recognizeWords: () => recognizeWords,
	rotateCanvas: () => rotateCanvas,
	unrotateBox: () => unrotateBox
});
async function recognize(src) {
	const result = await sharedOcr().run(getSettings().ocrLang, src);
	return String(result.data.text).trim();
}
/** V9: chọn hướng xoay từ các lượt dò nhanh — chỉ nhận hướng mới khi hơn hướng gốc ≥ 10 điểm tin cậy. */
function pickOrientation(base, probes) {
	let best = {
		deg: 0,
		confidence: base
	};
	for (const p of probes) if (p.confidence > best.confidence + 10 && p.confidence > base + 10) best = p;
	return best.deg;
}
/** V9: cạnh dài của ảnh dò hướng (dò trên ảnh nhỏ, đọc thật trên ảnh đầy đủ). */
var V9_PROBE_MAX = 1e3;
function v9() {
	const g = globalThis;
	return g.__v9 ??= {
		full: 0,
		probe: 0,
		rotated: 0
	};
}
/**
* BL-07 (RS-34): khung chữ đọc trên ảnh đã XOAY `deg` (90/270, theo chiều kim đồng hồ như rotateCanvasEl) → khung trên ảnh GỐC W×H.
* Trước: toạ độ trả về theo khung đã xoay → gợi ý chỗ ký lệch hẳn khi trang phải xoay mới đọc được.
*/
function unrotateBox(b, deg, W, H) {
	const map = (x, y) => deg === 90 ? [y, H - x] : deg === 270 ? [W - y, x] : [x, y];
	const [ax, ay] = map(b.x0, b.y0), [bx, by] = map(b.x1, b.y1);
	return {
		x0: Math.min(ax, bx),
		y0: Math.min(ay, by),
		x1: Math.max(ax, bx),
		y1: Math.max(ay, by)
	};
}
/** One reusable OCR worker per batch — creating a worker (and loading language data) per page was the slowest step. */
async function ocrSession() {
	const run = async (src, unrot) => {
		const result = await sharedOcr().run(getSettings().ocrLang, src, { out: {
			blocks: true,
			text: true
		} });
		const words = [];
		for (const b of result.data.blocks ?? []) for (const p of b.paragraphs) for (const l of p.lines) for (const w of l.words) {
			const { x0, y0, x1, y1 } = unrot ? unrotateBox(w.bbox, unrot.deg, unrot.W, unrot.H) : w.bbox;
			words.push({
				str: w.text,
				x: x0,
				y: -(y0 + y1) / 2,
				w: x1 - x0,
				h: y1 - y0
			});
		}
		return {
			text: result.data.text.trim(),
			words,
			confidence: result.data.confidence ?? 0
		};
	};
	return {
		/** OCR with word positions; if the page reads badly, probe sideways on a small copy (scanned tables are often landscape),
		* then read full size only in the winning orientation. V9: canvas goes straight to Tesseract (no JPEG re-encode). */
		async words(canvas) {
			const st = v9();
			st.full++;
			const best = await run(canvas);
			if (best.confidence >= 55) return best;
			const small = scaleCanvas(canvas, V9_PROBE_MAX);
			const probes = [];
			for (const deg of [90, 270]) {
				st.probe++;
				const r = await run(rotateCanvasEl(small, deg));
				probes.push({
					deg,
					confidence: r.confidence
				});
			}
			if (small !== canvas) small.width = 0;
			const deg = pickOrientation(best.confidence, probes);
			if (!deg) return best;
			st.full++;
			st.rotated++;
			const rc = rotateCanvasEl(canvas, deg);
			const r = await run(rc, {
				deg,
				W: canvas.width,
				H: canvas.height
			});
			rc.width = 0;
			return r.confidence > best.confidence ? r : best;
		},
		async close() {}
	};
}
function scaleCanvas(c, max) {
	const k = Math.min(1, max / Math.max(c.width, c.height));
	if (k === 1) return c;
	const o = document.createElement("canvas");
	o.width = Math.round(c.width * k);
	o.height = Math.round(c.height * k);
	o.getContext("2d").drawImage(c, 0, 0, o.width, o.height);
	return o;
}
function rotateCanvasEl(c, deg) {
	const o = document.createElement("canvas");
	o.width = c.height;
	o.height = c.width;
	const g = o.getContext("2d");
	g.translate(o.width / 2, o.height / 2);
	g.rotate(deg * Math.PI / 180);
	g.drawImage(c, -c.width / 2, -c.height / 2);
	return o;
}
function rotateCanvas(c, deg) {
	const o = rotateCanvasEl(c, deg);
	const url = o.toDataURL("image/jpeg", .9);
	o.width = 0;
	return url;
}
/** Back-compat single-image OCR with positions. */
async function recognizeWords(src) {
	const result = await sharedOcr().run(getSettings().ocrLang, src, { out: {
		blocks: true,
		text: true
	} });
	const words = [];
	for (const b of result.data.blocks ?? []) for (const p of b.paragraphs) for (const l of p.lines) for (const w of l.words) {
		const { x0, y0, x1, y1 } = w.bbox;
		words.push({
			str: w.text,
			x: x0,
			y: -(y0 + y1) / 2,
			w: x1 - x0,
			h: y1 - y0
		});
	}
	return {
		text: result.data.text.trim(),
		words
	};
}
/** Run tasks with limited parallelism, keeping result order. */
async function pool(items, limit, fn) {
	const out = new Array(items.length);
	let next = 0;
	await Promise.all(Array.from({ length: Math.min(limit, items.length) }, async () => {
		while (next < items.length) {
			const i = next++;
			out[i] = await fn(items[i], i);
		}
	}));
	return out;
}
var RULES = [
	["CCCD", /căn cước|cccd|identity card|chứng minh/i],
	["Hóa đơn", /hóa đơn|hoá đơn|invoice|tổng cộng|thanh toán|vat/i],
	["Hợp đồng", /hợp đồng|contract|bên a|bên b|điều khoản/i],
	["Biên lai", /biên lai|receipt/i]
];
/** Guess a category and readable title from recognized text. */
function classify(text) {
	return {
		kind: RULES.find(([, re]) => re.test(text))?.[0] ?? "Ghi chú",
		title: (text.split(/\n/).map((l) => l.trim()).find((l) => l.length > 4 && /[a-zà-ỹ]/i.test(l)) ?? "").slice(0, 48)
	};
}
/** S13d – Hộp từ OCR theo điểm ảnh (y hướng xuống) kèm độ tin cậy, trên ảnh thu nhỏ ≤ `max` px; trả cả kích thước ảnh đã đọc để đổi sang toạ độ chuẩn hoá. */
async function recognizeWordBoxes(src, max = 1280) {
	const img = await new Promise((ok, bad) => {
		const i = new Image();
		i.crossOrigin = "anonymous";
		i.onload = () => ok(i);
		i.onerror = () => bad(/* @__PURE__ */ new Error("Không mở được ảnh"));
		i.src = src;
	});
	const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
	const c = document.createElement("canvas");
	c.width = Math.round(img.naturalWidth * k);
	c.height = Math.round(img.naturalHeight * k);
	c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
	const url = c.toDataURL("image/jpeg", .9);
	const size = {
		w: c.width,
		h: c.height
	};
	c.width = 0;
	const result = await sharedOcr().run(getSettings().ocrLang, url, { out: { blocks: true } });
	const words = [];
	for (const b of result.data.blocks ?? []) for (const p of b.paragraphs) for (const l of p.lines) for (const w of l.words) words.push({
		text: w.text,
		conf: w.confidence,
		...w.bbox
	});
	return {
		size,
		words
	};
}
//#endregion
export { recognize as a, pool as i, ocrSession as n, recognizeWordBoxes as o, ocr_CLa2avjZ_exports as r, recognizeWords as s, classify as t };
