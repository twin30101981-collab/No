import { S as createFileRoute, x as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/documents-Cxss4jut.js
var $$splitComponentImporter = () => import("./documents-BhyCIB_A.mjs");
var Route = createFileRoute("/documents")({
	head: () => ({ meta: [
		{ title: "Tài liệu — Ghi Nhanh" },
		{
			name: "description",
			content: "Toàn bộ tài liệu đã quét, sắp xếp theo thư mục, loại và ngày."
		},
		{
			property: "og:title",
			content: "Tài liệu — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Toàn bộ tài liệu đã quét, sắp xếp theo thư mục, loại và ngày."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	validateSearch: (s) => ({
		...typeof s["qf"] === "string" ? { qf: s["qf"] } : {},
		...typeof s["tag"] === "string" ? { tag: s["tag"] } : {}
	}),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
