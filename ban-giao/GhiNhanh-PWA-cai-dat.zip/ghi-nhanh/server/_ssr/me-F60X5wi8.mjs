import { o as __toESM } from "../_runtime.mjs";
import { w as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { s as newSalt } from "./vault-CuGqX6h0.mjs";
import { a as clearAiKeys, c as saveAiKeys, i as cleanKeys, n as CLAUDE_MODELS, o as loadAiKeys, s as maskKey, t as AI_PROVIDER_ORDER } from "./ai-keys-fpHjq2Jo.mjs";
import { i as readAiStatus, r as providerState, t as AI_NAME } from "./ai-status-DsooByQF.mjs";
import { i as aiKeyCheck, l as aiProviders } from "./ai.functions-CpS7iAgj.mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { a as userMessage, i as showError } from "./errors-DKvrPJ4v.mjs";
import { f as useUser, i as cloudReady, u as signOut } from "./auth-BEi9IFUJ.mjs";
import { Bt as Combine, G as Moon, It as Download, J as Lock, Lt as Database, Pt as Eraser, S as Smartphone, Vt as CloudUpload, X as LoaderCircle, at as KeyRound, c as Upload, d as TriangleAlert, en as BookOpen, f as Trash2, r as X, rn as ArrowDown, s as UserRound, tn as ArrowUp, u as Type, z as Plus } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-CZvf2xHx.mjs";
import { i as fpOf, n as blobFor } from "./disk-pack-ZdDKsocx.mjs";
import { a as lockNow, n as getSettings, o as setSettings, r as hashPin, t as getPinSalt, u as useSettings } from "./settings-DDlMLZCe.mjs";
import { D as useDocs, f as mutateDocs, w as saveDocs, x as replaceAll } from "./db-CclUQaLE.mjs";
import { a as renderTemplate, n as PLACEHOLDERS, t as FIELD_LABEL } from "./name-rules-BfNs0V4s.mjs";
import { d as getLibrary, v as setLibrary } from "./library-BIMZUn1d.mjs";
import { t as useServerFn } from "./useServerFn-CrZF2pjq.mjs";
import { a as overBudgetText, i as downloadBaseline, n as buildReport, r as clearPerf, s as readPerf, t as budgetReport } from "./perf-stats-C5jrVSN8.mjs";
import { a as readScanLog, t as clearScanLog } from "./scan-log-DnWLrMlu.mjs";
import { c as download } from "./files-CTF11Arr.mjs";
import { i as promptDialog, n as confirmDialog, r as pinDialog, t as choiceDialog } from "./dialog-IcUxZaUZ.mjs";
import { n as pickFiles } from "./importer-BUHDogNt.mjs";
import { t as Input } from "./input-T4LKa1EA.mjs";
import { i as syncAll } from "./cloud-sync-DGtKTTqz.mjs";
import { c as historyForBackup, p as restoreHistory } from "./history-ZPjFrOJG.mjs";
import { n as driveReady, r as getQuota } from "./drive-B45FnGmw.mjs";
import { t as compareBench } from "./crop-bench-CnNlpcAa.mjs";
import { n as prepareOfflineOcr, t as offlineOcrReady } from "./offline-BFa7CUSi.mjs";
import { t as Switch } from "./switch-BVIUyQVR.mjs";
import { n as gatherFeatureEnv, r as useOnline, t as featureStatuses } from "./feature-status-C0M5x8cK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/me-F60X5wi8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BackupError = class extends Error {};
/** Nội dung ảnh trang → data URL. Blob lấy từ sổ đăng ký của app; không có thì thử đọc chính địa chỉ blob:. */
function blobToDataUrl(b) {
	return new Promise((res, rej) => {
		const r = new FileReader();
		r.onload = () => res(String(r.result));
		r.onerror = () => rej(r.error);
		r.readAsDataURL(b);
	});
}
async function portableUrl(u, memo, where) {
	if (!u || !u.startsWith("blob:")) return u;
	const hit = memo.get(u);
	if (hit) return hit;
	let b = blobFor(u);
	if (!b) try {
		b = await (await fetch(u)).blob();
	} catch {}
	if (!b || b.size === 0) throw new BackupError(`Không đọc được ảnh của ${where}`);
	const du = await blobToDataUrl(b);
	memo.set(u, du);
	return du;
}
/** Bản tài liệu mang theo được: mọi ảnh là dữ liệu thật (data URL), không còn địa chỉ blob:. */
async function toPortableDoc(d) {
	if (d.enc || !d.pages?.length) return d;
	const memo = /* @__PURE__ */ new Map();
	const pages = [];
	for (const [i, p] of d.pages.entries()) {
		const where = `“${d.name}” trang ${i + 1}`;
		const out = {
			...p,
			orig: await portableUrl(p.orig, memo, where) ?? "",
			src: await portableUrl(p.src, memo, where) ?? ""
		};
		if (p.thumb) out.thumb = await portableUrl(p.thumb, memo, where) ?? "";
		pages.push(out);
	}
	return {
		...d,
		pages
	};
}
async function sha256(s) {
	const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
	return [...new Uint8Array(buf)].map((x) => x.toString(16).padStart(2, "0")).join("");
}
/** Tạo tệp sao lưu. Ném BackupError nếu có ảnh không đọc được — không bao giờ trả tệp thiếu ảnh. */
async function buildBackup(src, now = Date.now()) {
	const parts = [];
	const index = [];
	for (const d of src.docs) {
		const p = await toPortableDoc(d);
		const compact = {
			...p,
			pages: p.pages.map((pg) => pg.src && pg.src === pg.orig ? {
				...pg,
				src: "="
			} : pg)
		};
		const s = JSON.stringify(compact);
		index.push({
			id: d.id,
			pages: p.pages.length,
			sha256: await sha256(s)
		});
		parts.push(s);
	}
	const head = {
		app: "ghi-nhanh",
		version: 4,
		createdAt: now,
		index,
		...src.vault ? { vault: src.vault } : {},
		...src.library ? { library: src.library } : {},
		...src.conversions ? { conversions: src.conversions } : {}
	};
	const headJson = JSON.stringify(head);
	return new Blob([
		headJson.slice(0, -1),
		",\"docs\":[",
		parts.join(","),
		"]}"
	], { type: "application/json" });
}
var isObj = (v) => !!v && typeof v === "object" && !Array.isArray(v);
function docProblem(d) {
	if (!isObj(d)) return "không phải tài liệu";
	if (typeof d["id"] !== "string" || !d["id"]) return "thiếu mã tài liệu";
	if (typeof d["name"] !== "string") return "thiếu tên";
	if (d["enc"]) return null;
	if (!Array.isArray(d["pages"])) return "thiếu danh sách trang";
	for (const [i, p] of d["pages"].entries()) {
		if (!isObj(p) || typeof p["id"] !== "string" || typeof p["orig"] !== "string" || typeof p["src"] !== "string") return `trang ${i + 1} hỏng`;
		if (p["orig"].startsWith("blob:") || p["src"].startsWith("blob:")) return "tệp sao lưu cũ chỉ lưu địa chỉ ảnh tạm, không có ảnh thật";
		if (!p["orig"]) return `trang ${i + 1} không có ảnh`;
	}
	return null;
}
/** Đọc + kiểm tra tệp sao lưu: cấu trúc, phiên bản, tổng kiểm, ảnh thật. Tài liệu hỏng bị loại và liệt kê, không làm hỏng phần còn lại. */
async function parseBackup(text) {
	let raw;
	try {
		raw = JSON.parse(text);
	} catch {
		return {
			ok: false,
			error: "Tệp không đúng định dạng — hãy chọn tệp sao lưu tạo từ Ghi Nhanh."
		};
	}
	if (!isObj(raw) || raw["app"] !== "ghi-nhanh" || !Array.isArray(raw["docs"])) return {
		ok: false,
		error: "Đây không phải tệp sao lưu của Ghi Nhanh."
	};
	const version = typeof raw["version"] === "number" ? raw["version"] : 0;
	if (version > 4) return {
		ok: false,
		error: "Tệp sao lưu tạo bằng bản Ghi Nhanh mới hơn — hãy cập nhật app rồi khôi phục lại."
	};
	const data = raw;
	const idx = new Map((Array.isArray(data.index) ? data.index : []).map((e) => [e.id, e]));
	const docs = [];
	const skipped = [];
	for (const d of data.docs) {
		const name = isObj(d) && typeof d["name"] === "string" ? d["name"] : "(không tên)";
		const why = docProblem(d);
		if (why) {
			skipped.push({
				name,
				why
			});
			continue;
		}
		const doc = d;
		const want = idx.get(doc.id);
		if (want && want.sha256 !== await sha256(JSON.stringify(doc))) {
			skipped.push({
				name,
				why: "sai tổng kiểm (tệp bị sửa hoặc hỏng)"
			});
			continue;
		}
		docs.push({
			...doc,
			pages: (doc.pages ?? []).map((p) => p.src === "=" ? {
				...p,
				src: p.orig
			} : p)
		});
	}
	if (!docs.length && data.docs.length) return {
		ok: false,
		error: `Không có tài liệu nào khôi phục được: ${skipped[0]?.name ?? ""} — ${skipped[0]?.why ?? ""}.`
	};
	return {
		ok: true,
		data,
		docs,
		skipped,
		legacy: version < 4
	};
}
/** GỘP (mặc định): thêm tài liệu mới; trùng mã thì giữ bản có `updatedAt` mới hơn; không xoá gì của máy. Tài liệu khoá PIN của khoá khác bị bỏ qua. */
function planMerge(current, incoming, opts) {
	const cur = new Map(current.map((d) => [d.id, d]));
	const plan = {
		toSave: [],
		added: 0,
		updated: 0,
		kept: 0,
		skippedLocked: 0
	};
	for (const d of incoming) {
		if (d.enc && !opts.sameVault) {
			plan.skippedLocked++;
			continue;
		}
		const have = cur.get(d.id);
		if (!have) {
			plan.toSave.push(d);
			plan.added++;
		} else if ((d.updatedAt ?? 0) > (have.updatedAt ?? 0)) {
			plan.toSave.push(d);
			plan.updated++;
		} else plan.kept++;
	}
	return plan;
}
/** Gộp thư mục/thẻ/bộ lọc nhanh: hợp của hai bên, không mất cái nào. */
function mergeLibrary(a, b) {
	if (!b) return a;
	const tagNames = new Set(a.tags.map((t) => t.name.toLowerCase()));
	const qIds = new Set(a.quick.map((q) => q.id));
	return {
		folders: [.../* @__PURE__ */ new Set([...a.folders, ...b.folders ?? []])],
		tags: [...a.tags, ...(b.tags ?? []).filter((t) => !tagNames.has(t.name.toLowerCase()))],
		quick: [...a.quick, ...(b.quick ?? []).filter((q) => !qIds.has(q.id))]
	};
}
/** Dung lượng: đo, cảnh báo, dọn ảnh tạm (ảnh thu nhỏ cũ/thừa). */
var bytes = (s) => !s ? 0 : s.startsWith("blob:") ? blobFor(s)?.size ?? 0 : Math.round(s.length * .75);
var thumbKey = (p) => fpOf(p.src);
function breakdown(docs) {
	let active = 0, trash = 0, temp = 0;
	for (const d of docs) for (const [i, p] of d.pages.entries()) {
		const main = bytes(p.src) + (p.orig !== p.src ? bytes(p.orig) : 0);
		if (d.deletedAt) trash += main;
		else active += main;
		if (p.thumb && (i > 0 || p.thumbKey !== thumbKey(p))) temp += bytes(p.thumb);
	}
	return {
		active,
		trash,
		temp
	};
}
/** Bỏ ảnh thu nhỏ hết hạn (ảnh đã sửa) hoặc thừa (không phải trang đầu). Trả về tài liệu cần lưu. */
function cleanTemp(docs) {
	const out = [];
	for (const d of docs) {
		let changed = false;
		const pages = d.pages.map((p, i) => {
			if (p.thumb && (i > 0 || p.thumbKey !== thumbKey(p))) {
				changed = true;
				const { thumb: _, thumbKey: __, ...rest } = p;
				return rest;
			}
			return p;
		});
		if (changed) out.push({
			...d,
			pages
		});
	}
	return out;
}
function level(usage, quota) {
	if (!quota) return "ok";
	const r = usage / quota;
	return r >= .95 ? "full" : r >= .8 ? "warn" : "ok";
}
function fmtBytes(n) {
	return n >= 1e9 ? `${(n / 1e9).toFixed(1)} GB` : n >= 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.round(n / 1e3)} KB`;
}
var deferred = null;
var listeners = /* @__PURE__ */ new Set();
if (typeof window !== "undefined") {
	window.addEventListener("beforeinstallprompt", (e) => {
		e.preventDefault();
		deferred = e;
		listeners.forEach((l) => l());
	});
	window.addEventListener("appinstalled", () => {
		deferred = null;
		listeners.forEach((l) => l());
	});
}
/** Trạng thái nút "Cài ứng dụng": có thể cài trực tiếp, iPhone (hướng dẫn), hoặc đã cài. */
function useInstall() {
	const [, tick] = (0, import_react.useState)(0);
	const [env, setEnv] = (0, import_react.useState)({
		installed: false,
		ios: false
	});
	(0, import_react.useEffect)(() => {
		const l = () => tick((n) => n + 1);
		listeners.add(l);
		setEnv({
			installed: window.matchMedia("(display-mode: standalone)").matches || navigator.standalone === true,
			ios: /iphone|ipad|ipod/i.test(navigator.userAgent)
		});
		return () => {
			listeners.delete(l);
		};
	}, []);
	return {
		...env,
		canPrompt: !!deferred,
		async install() {
			if (!deferred) return false;
			await deferred.prompt();
			const r = await deferred.userChoice;
			deferred = null;
			listeners.forEach((l) => l());
			return r.outcome === "accepted";
		}
	};
}
function NamingRules() {
	const s = useSettings();
	const rules = s.folderRules ?? [];
	const [field, setField] = (0, import_react.useState)("type");
	const [contains, setContains] = (0, import_react.useState)("");
	const [folder, setFolder] = (0, import_react.useState)("");
	const sample = renderTemplate(s.nameTemplate, {
		title: "Điện lực tháng 9",
		type: "Hoá đơn",
		tags: ["Nhà"],
		date: Date.now()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "text-sm",
				htmlFor: "name-tpl",
				children: "Mẫu đặt tên"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "name-tpl",
				className: "mt-1",
				value: s.nameTemplate,
				placeholder: "{ten}",
				onChange: (e) => setSettings({ nameTemplate: e.target.value })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1.5 flex flex-wrap gap-1",
				children: PLACEHOLDERS.map(([k, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					title: l,
					onClick: () => setSettings({ nameTemplate: `${s.nameTemplate}${s.nameTemplate ? " " : ""}${k}` }),
					className: "rounded-[8px] bg-muted px-2 min-h-10 text-xs font-semibold text-muted-foreground",
					children: k
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: ["Ví dụ: ", sample]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: "Tự chuyển thư mục"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Quy tắc đầu tiên khớp được dùng; chỉ áp cho tài liệu đang ở \"Chung\"."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 space-y-1",
				children: rules.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2 rounded-[10px] bg-muted px-2.5 py-1.5 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1 truncate",
						children: [
							FIELD_LABEL[r.field],
							" có \"",
							r.contains,
							"\" → ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: r.folder })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Xoá quy tắc",
						onClick: () => setSettings({ folderRules: rules.filter((x) => x.id !== r.id) }),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}, r.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-wrap items-center gap-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						"aria-label": "Điều kiện",
						value: field,
						onChange: (e) => setField(e.target.value),
						className: "h-10 rounded-[8px] border bg-background px-2 text-xs",
						children: Object.keys(FIELD_LABEL).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: f,
							children: FIELD_LABEL[f]
						}, f))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						"aria-label": "Chứa chữ",
						className: "h-10 w-24 flex-1 text-xs",
						placeholder: "hoá đơn",
						value: contains,
						onChange: (e) => setContains(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						"aria-label": "Thư mục",
						className: "h-10 w-24 flex-1 text-xs",
						placeholder: "Chi tiêu/Hoá đơn",
						value: folder,
						onChange: (e) => setFolder(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Thêm quy tắc",
						disabled: !contains.trim() || !folder.trim(),
						className: "grid size-10 place-items-center rounded-[8px] bg-primary text-primary-foreground disabled:opacity-40",
						onClick: () => {
							setSettings({ folderRules: [...rules, {
								id: crypto.randomUUID(),
								field,
								contains: contains.trim(),
								folder: folder.trim()
							}] });
							setContains("");
							setFolder("");
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
					})
				]
			})
		] })]
	});
}
var DOT$1 = {
	ok: "bg-emerald-500",
	warn: "bg-amber-500",
	off: "bg-muted-foreground/50"
};
var WORD = {
	ok: "Dùng được",
	warn: "Lưu ý",
	off: "Chưa dùng được"
};
function summary(rows) {
	const n = (k) => rows.filter((r) => r.state === k).length;
	return [
		`${n("ok")} dùng được`,
		n("warn") && `${n("warn")} lưu ý`,
		n("off") && `${n("off")} chưa dùng được`
	].filter(Boolean).join(" · ");
}
function FeatureStatusCard() {
	const online = useOnline();
	const { user } = useUser();
	const s = useSettings();
	const [rows, setRows] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		const r = buildReport(readPerf(), readScanLog());
		const q = getQuota();
		gatherFeatureEnv({
			online,
			cloud: cloudReady(),
			signedIn: !!user,
			drive: driveReady(),
			ocrOffline: offlineOcrReady(s.ocrLang),
			askLeft: q.left,
			askLimit: 30,
			aiErrorRate: r.ai.ok + r.ai.fail >= 3 ? r.ai.errorRate : null
		}).then((env) => {
			if (live) setRows(featureStatuses(env));
		});
		return () => {
			live = false;
		};
	}, [
		online,
		user,
		s.ocrLang
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rise rise-2 px-5 pt-5",
		"aria-labelledby": "fx01-title",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			id: "fx01-title",
			className: "mb-2 font-display text-[0.8125rem] font-semibold text-muted-foreground",
			children: "Tình trạng tính năng"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
			className: "document-row group overflow-hidden rounded-[16px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
				className: "flex min-h-[52px] cursor-pointer list-none items-center gap-3 px-4 py-2 text-sm [&::-webkit-details-marker]:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 flex-1",
						children: rows ? summary(rows) : "Đang kiểm tra…"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 text-xs font-semibold text-primary group-open:hidden",
						children: "Xem"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden shrink-0 text-xs font-semibold text-primary group-open:inline",
						children: "Thu gọn"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border border-t border-border",
				"data-testid": "feature-status",
				children: (rows ?? []).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					"data-feature": r.id,
					"data-state": r.state,
					className: "flex min-h-[52px] items-start gap-3 px-4 py-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						className: `mt-1.5 size-2.5 shrink-0 rounded-full ${DOT$1[r.state]}`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-baseline justify-between gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: r.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 text-[0.6875rem] text-muted-foreground",
								children: WORD[r.state]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs leading-5 text-muted-foreground",
							children: r.detail
						})]
					})]
				}, r.id))
			})]
		})]
	});
}
var NAME = {
	lovable: "Lovable AI (máy chủ)",
	claude: "Claude",
	mistral: "Mistral (miễn phí)",
	gemini: "Gemini (miễn phí)"
};
var HINT = {
	claude: "sk-ant-…",
	mistral: "Key Mistral",
	gemini: "AIza…"
};
var STATUS = {
	ready: "Sẵn sàng",
	"bad-key": "Key sai",
	quota: "Hết lượt / quá tải",
	error: "Lỗi — thử lại sau",
	"no-key": "Chưa có key"
};
var KEYED = [
	"claude",
	"mistral",
	"gemini"
];
function AiKeysPanel() {
	const check = useServerFn(aiKeyCheck);
	const [saved, setSaved] = (0, import_react.useState)({});
	const [locked, setLocked] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)({
		claude: "",
		mistral: "",
		gemini: ""
	});
	const [model, setModel] = (0, import_react.useState)(CLAUDE_MODELS[0].id);
	const [order, setOrder] = (0, import_react.useState)([...AI_PROVIDER_ORDER]);
	const [status, setStatus] = (0, import_react.useState)({});
	const [busy, setBusy] = (0, import_react.useState)("");
	const apply = (k) => {
		const v = k ?? {};
		setSaved(v);
		setModel(v.claudeModel ?? CLAUDE_MODELS[0].id);
		setOrder(v.order?.length ? [...v.order, ...AI_PROVIDER_ORDER.filter((p) => !v.order.includes(p))] : [...AI_PROVIDER_ORDER]);
	};
	(0, import_react.useEffect)(() => {
		loadAiKeys().then((r) => {
			setLocked(r.locked);
			apply(r.keys);
		}).catch(() => {});
	}, []);
	const save = async (quiet = false) => {
		const next = {
			...saved,
			claudeModel: model,
			order
		};
		for (const p of KEYED) if (draft[p].trim()) next[p] = draft[p].trim();
		const mode = await saveAiKeys(next);
		apply(cleanKeys(next));
		setDraft({
			claude: "",
			mistral: "",
			gemini: ""
		});
		if (!quiet) toast.success(mode === "pin" ? "Đã lưu khoá AI (trong két PIN)" : "Đã lưu khoá AI (mã hoá trên máy này)");
	};
	const remove = async (p) => {
		const next = { ...saved };
		delete next[p];
		await saveAiKeys(next);
		apply(cleanKeys(next));
		setStatus((s) => ({
			...s,
			[p]: void 0
		}));
		toast(`Đã xoá key ${NAME[p]}`);
	};
	const test = async (p) => {
		setBusy(p);
		try {
			if (p !== "lovable" && draft[p].trim()) await save(true);
			const r = await check({ data: { provider: p } });
			setStatus((s) => ({
				...s,
				[p]: r.ok ? "ready" : r.status
			}));
		} catch {
			setStatus((s) => ({
				...s,
				[p]: "error"
			}));
		} finally {
			setBusy("");
		}
	};
	const move = (i, d) => setOrder((o) => {
		const n = [...o];
		const j = i + d;
		if (j < 0 || j >= n.length) return o;
		[n[i], n[j]] = [n[j], n[i]];
		return n;
	});
	if (locked) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "p-4 text-sm text-muted-foreground",
		role: "status",
		children: "Khoá AI đang nằm trong két PIN — mở khoá PIN để xem hoặc sửa."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 p-4",
		"data-testid": "ai-keys",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Key được mã hoá trên máy này (bật mã PIN thì nằm trong két PIN); không có trong sao lưu, đồng bộ hay báo lỗi. Claude không có gói miễn phí (nạp tiền trong Anthropic Console); Mistral/Gemini miễn phí nhưng có thể dùng dữ liệu để huấn luyện nên giấy tờ nhạy cảm không gửi tới đó."
			}),
			KEYED.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: NAME[p]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"data-testid": `ai-key-${p}`,
							className: "text-xs text-muted-foreground",
							children: saved[p] ? maskKey(saved[p]) : "chưa có"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								autoComplete: "off",
								spellCheck: false,
								"aria-label": `Key ${NAME[p]}`,
								placeholder: saved[p] ? "Dán key mới để đổi" : HINT[p],
								value: draft[p],
								onChange: (e) => setDraft((d) => ({
									...d,
									[p]: e.target.value
								})),
								className: "h-11 min-w-0 flex-1 rounded-[12px] border border-border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/40"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => void test(p),
								disabled: !!busy || !saved[p] && !draft[p].trim(),
								className: "h-11 shrink-0 rounded-[12px] border border-border px-3 text-xs font-semibold disabled:opacity-50",
								children: busy === p ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : "Kiểm tra"
							}),
							saved[p] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => void remove(p),
								className: "h-11 shrink-0 rounded-[12px] px-2 text-xs text-destructive",
								children: "Xoá"
							})
						]
					}),
					status[p] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "status",
						"data-testid": `ai-status-${p}`,
						className: `text-xs ${status[p] === "ready" ? "text-primary" : "text-destructive"}`,
						children: STATUS[status[p]]
					})
				]
			}, p)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1.5 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold",
					children: "Mô hình Claude"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					"aria-label": "Mô hình Claude",
					value: model,
					onChange: (e) => setModel(e.target.value),
					className: "h-11 w-full rounded-[12px] border border-border bg-background px-3 text-sm",
					children: CLAUDE_MODELS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: m.id,
						children: m.label
					}, m.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: "Thứ tự dùng nguồn AI"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "space-y-1",
					"data-testid": "ai-order",
					children: order.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-2 rounded-[12px] bg-secondary/50 pl-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							i + 1,
							". ",
							NAME[p]
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `Đưa ${NAME[p]} lên`,
								disabled: i === 0,
								onClick: () => move(i, -1),
								className: "grid size-11 place-items-center disabled:opacity-30",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `Đưa ${NAME[p]} xuống`,
								disabled: i === order.length - 1,
								onClick: () => move(i, 1),
								className: "grid size-11 place-items-center disabled:opacity-30",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-4" })
							})]
						})]
					}, p))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => void save(),
					className: "flex h-11 flex-1 items-center justify-center gap-2 rounded-[12px] bg-primary text-sm font-semibold text-primary-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-4" }), " Lưu khoá AI"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: async () => {
						if (await confirmDialog("Xoá mọi khoá AI trên máy này?", {
							okText: "Xoá",
							danger: true
						})) {
							await clearAiKeys();
							apply(null);
							setStatus({});
							toast("Đã xoá khoá AI");
						}
					},
					className: "h-11 rounded-[12px] border border-border px-3 text-sm",
					children: "Xoá hết"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => void test("lovable"),
				disabled: !!busy,
				className: "text-xs text-muted-foreground underline",
				children: busy === "lovable" ? "Đang kiểm tra…" : "Kiểm tra Lovable AI (key máy chủ)"
			}),
			status["lovable"] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "status",
				"data-testid": "ai-status-lovable",
				className: "text-xs",
				children: STATUS[status["lovable"]]
			})
		]
	});
}
var DOT = {
	ok: "bg-emerald-500",
	warn: "bg-amber-500",
	off: "bg-muted-foreground/50"
};
function AiStatusCard() {
	const load = useServerFn(aiProviders);
	const [rows, setRows] = (0, import_react.useState)(null);
	const [err, setErr] = (0, import_react.useState)(false);
	const [tick, setTick] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		let live = true;
		setErr(false);
		load().then((r) => {
			if (live) setRows(r.providers);
		}).catch(() => {
			if (live) setErr(true);
		});
		return () => {
			live = false;
		};
	}, [load, tick]);
	const [st, setSt] = (0, import_react.useState)({ providers: {} });
	(0, import_react.useEffect)(() => {
		setSt(readAiStatus());
	}, [rows, tick]);
	const last = st.last;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1 p-4",
		"data-testid": "ai-status",
		children: [
			err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "status",
				className: "text-sm text-muted-foreground",
				children: "Không hỏi được máy chủ (mất mạng?) — việc AI sẽ chờ có mạng."
			}),
			!rows && !err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Đang kiểm tra…"
			}),
			rows?.map((r, i) => {
				const s = providerState(r.keySource, r.enabled, st.providers[r.id]);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					"data-provider": r.id,
					"data-state": s.state,
					className: "flex min-h-[44px] items-center gap-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							className: `size-2.5 shrink-0 rounded-full ${DOT[s.state]}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-medium",
								children: [
									i + 1,
									". ",
									r.label
								]
							}), r.free && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-1 text-[0.6875rem] text-muted-foreground",
								children: "(miễn phí, không nhận giấy tờ nhạy cảm)"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `shrink-0 text-xs ${s.state === "warn" ? "text-amber-600" : "text-muted-foreground"}`,
							children: s.text
						})
					]
				}, r.id);
			}),
			last && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				"data-testid": "ai-last",
				className: "pt-1 text-xs text-muted-foreground",
				children: [
					"Lần gần nhất: ",
					AI_NAME[last.source],
					last.fallback ? " (nguồn dự phòng)" : "",
					" · ",
					new Date(last.at).toLocaleTimeString("vi-VN", {
						hour: "2-digit",
						minute: "2-digit"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTick((n) => n + 1),
				className: "min-h-[44px] text-xs font-semibold text-primary",
				children: "Làm mới"
			})
		]
	});
}
function Me() {
	const s = useSettings();
	const { user } = useUser();
	const [sync, setSync] = (0, import_react.useState)("");
	const { docs, all, trash } = useDocs();
	const [usage, setUsage] = (0, import_react.useState)("");
	const [lvl, setLvl] = (0, import_react.useState)("ok");
	const parts = breakdown(all);
	const inst = useInstall();
	const [ocrReady, setOcrReady] = (0, import_react.useState)(false);
	const [ocrBusy, setOcrBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setOcrReady(offlineOcrReady(s.ocrLang)), [s.ocrLang]);
	const [logCount, setLogCount] = (0, import_react.useState)(0);
	const [bench, setBench] = (0, import_react.useState)("");
	const [perf, setPerf] = (0, import_react.useState)(null);
	const [budget, setBudget] = (0, import_react.useState)([]);
	const [perfCount, setPerfCount] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const sp = readPerf();
		setPerf(buildReport(sp, readScanLog()));
		setBudget(budgetReport(sp));
		setPerfCount(sp.length);
	}, []);
	(0, import_react.useEffect)(() => setLogCount(readScanLog().length), []);
	(0, import_react.useEffect)(() => {
		navigator.storage?.estimate?.().then((e) => {
			setUsage(`${fmtBytes(e.usage ?? 0)} / ${fmtBytes(e.quota ?? 0)}`);
			setLvl(level(e.usage ?? 0, e.quota ?? 0));
		});
	}, [all]);
	async function cleanUp() {
		const fixed = cleanTemp(all);
		if (typeof caches !== "undefined") {
			for (const k of await caches.keys().catch(() => [])) if (k.startsWith("gn-tmp")) await caches.delete(k);
		}
		if (!fixed.length) {
			toast("Không có ảnh tạm để dọn");
			return;
		}
		await mutateDocs(fixed.map((d) => d.id), (d) => cleanTemp([d])[0]);
		toast.success(`Đã dọn ${fmtBytes(parts.temp)} ảnh tạm`);
	}
	async function setPin() {
		if (s.pin) {
			const cur = await pinDialog("Tắt mã PIN", "Nhập mã PIN hiện tại. Tài liệu đã khoá sẽ mở tự do.");
			if (!cur) return;
			if (await hashPin(cur) !== s.pin) {
				toast.error("Sai mã PIN", { description: "Thử lại với mã bạn đã đặt." });
				return;
			}
			const { unlockVault, rekeyVault } = await import("./db-CclUQaLE.mjs").then((n) => n.r).then((n) => n.n);
			if (!await unlockVault(cur, getPinSalt())) {
				toast.error("Không giải mã được tài liệu đã khoá");
				return;
			}
			await rekeyVault(null);
			setSettings({ pin: "" });
			toast("Đã tắt mã PIN");
			return;
		}
		const pin = await pinDialog("Đặt mã PIN", "Nhập 4–6 chữ số.");
		if (!pin) return;
		const again = await pinDialog("Nhập lại mã PIN", "Để chắc chắn bạn nhớ đúng.");
		if (again === null) return;
		if (again !== pin) {
			toast.error("Hai lần nhập không khớp", { description: "Hãy đặt lại mã PIN." });
			return;
		}
		const salt = newSalt();
		setSettings({
			pin: await hashPin(pin),
			pinSalt: salt
		});
		await (await import("./db-CclUQaLE.mjs").then((n) => n.r).then((n) => n.n)).rekeyVault({
			pin,
			salt
		});
		toast.success("Đã bật mã PIN. Khóa tài liệu trong menu của tài liệu.");
	}
	async function makeRecovery() {
		const { createRecovery, unlockVault } = await import("./db-CclUQaLE.mjs").then((n) => n.r).then((n) => n.n);
		const { getVaultKey } = await import("./vault-CuGqX6h0.mjs").then((n) => n.m).then((n) => n.m);
		if (!getVaultKey()) {
			const cur = await pinDialog("Nhập mã PIN", "Để tạo mã khôi phục.");
			if (!cur) return;
			if (await hashPin(cur) !== s.pin || !await unlockVault(cur, getPinSalt())) {
				toast.error("Sai mã PIN");
				return;
			}
		}
		const code = await createRecovery();
		await navigator.clipboard?.writeText(code).catch(() => {});
		await confirmDialog("Mã khôi phục của bạn", {
			message: `${code}\n\nGhi lại và cất ở nơi an toàn (đã chép vào bộ nhớ tạm). Mã chỉ hiện một lần; tạo mã mới thì mã cũ hết hiệu lực. Mất cả PIN lẫn mã này thì không mở lại được tài liệu đã khoá.`,
			okText: "Tôi đã ghi lại"
		});
	}
	async function forgotPin() {
		const code = await promptDialog("Quên mã PIN", {
			message: "Nhập mã khôi phục (24 ký tự).",
			placeholder: "XXXX-XXXX-…",
			okText: "Tiếp tục"
		});
		if (!code) return;
		const pin = await pinDialog("Đặt mã PIN mới", "Nhập 4–6 chữ số.");
		if (!pin) return;
		const { recoverVault } = await import("./db-CclUQaLE.mjs").then((n) => n.r).then((n) => n.n);
		if (await recoverVault(code, pin)) toast.success("Đã đặt PIN mới, tài liệu đã khoá vẫn nguyên vẹn");
		else toast.error("Mã khôi phục không đúng", { description: "Kiểm tra lại từng ký tự rồi thử lại." });
	}
	async function backup() {
		const id = toast.loading("Đang tạo tệp sao lưu…");
		try {
			const blob = await buildBackup({
				docs: all,
				vault: getSettings().vaultWrap,
				library: getLibrary(),
				conversions: await historyForBackup()
			});
			download(blob, `ghi-nhanh-sao-luu-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`);
			toast.success(`Đã sao lưu ${all.length} tài liệu (${fmtBytes(blob.size)})`, { id });
		} catch (e) {
			console.error(e);
			toast.error(e instanceof BackupError ? userMessage(e, "Không sao lưu được") : "Không sao lưu được", {
				id,
				description: "Chưa tải tệp nào về. Thử lại; nếu vẫn lỗi hãy tải lại trang rồi sao lưu."
			});
		}
	}
	async function restore() {
		const [f] = await pickFiles("application/json,.json", false);
		if (!f) return;
		const id = toast.loading("Đang kiểm tra tệp sao lưu…");
		try {
			const r = await parseBackup(await f.text());
			toast.dismiss(id);
			if (!r.ok) {
				toast.error("Không khôi phục được", { description: r.error });
				return;
			}
			const mine = getSettings().vaultWrap, theirs = r.data.vault;
			const sameVault = !theirs || !mine || JSON.stringify(mine) === JSON.stringify(theirs);
			const bad = r.skipped.length ? `\n\n${r.skipped.length} tài liệu hỏng bị bỏ qua (${r.skipped.slice(0, 2).map((x) => `${x.name}: ${x.why}`).join("; ")}${r.skipped.length > 2 ? "…" : ""}).` : "";
			const pick = await choiceDialog(`Khôi phục ${r.docs.length} tài liệu?`, {
				message: `Gộp (khuyên dùng): thêm tài liệu mới, giữ bản mới hơn khi trùng, không xoá gì trên máy này.\nThay thế: bỏ toàn bộ dữ liệu hiện tại, dùng đúng như tệp (app tự tải bản dự phòng trước).${bad}`,
				okText: "Gộp",
				altText: "Thay thế"
			});
			if (!pick) return;
			if (pick === "ok") {
				const plan = planMerge(all, r.docs, { sameVault });
				if (plan.toSave.length) await saveDocs(plan.toSave);
				if (theirs && !mine) setSettings({ vaultWrap: theirs });
				if (r.data.library) setLibrary(mergeLibrary(getLibrary(), r.data.library));
				if (r.data.conversions) await restoreHistory(r.data.conversions);
				toast.success(`Đã gộp: thêm ${plan.added}, cập nhật ${plan.updated}, giữ nguyên ${plan.kept}`, { description: plan.skippedLocked ? `${plan.skippedLocked} tài liệu khoá PIN bỏ qua vì khác khoá của máy này — dùng Thay thế nếu muốn lấy về.` : void 0 });
				return;
			}
			if (all.length) download(await buildBackup({
				docs: all,
				vault: mine,
				library: getLibrary(),
				conversions: await historyForBackup()
			}), `ghi-nhanh-du-phong-truoc-khoi-phuc-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`);
			if (!await confirmDialog("Thay thế toàn bộ?", {
				message: `${all.length} tài liệu hiện có sẽ được thay bằng ${r.docs.length} tài liệu trong tệp.${all.length ? " Bản dự phòng vừa được tải về máy." : ""}`,
				okText: "Thay thế",
				danger: true
			})) return;
			if (theirs) setSettings({ vaultWrap: theirs });
			await replaceAll(r.docs);
			if (r.data.library) setLibrary(r.data.library);
			if (r.data.conversions) await restoreHistory(r.data.conversions);
			toast.success(`Đã thay thế bằng ${r.docs.length} tài liệu`);
		} catch (e) {
			toast.dismiss(id);
			showError(e, "Không khôi phục được");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		wide: true,
		title: "Tôi",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rise rise-1 px-5 pt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "document-row flex items-center gap-3 rounded-[16px] p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "brand-mark grid size-12 shrink-0 place-items-center rounded-[12px] bg-primary font-display text-lg font-bold text-primary-foreground",
						children: "G"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display font-semibold",
							children: "Ghi Nhanh"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Không quảng cáo · Không giới hạn trang · Lưu trên máy"
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeatureStatusCard, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:grid lg:grid-cols-2 lg:items-start lg:gap-x-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
						title: "Quét",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Chất lượng ảnh",
								value: s.quality,
								options: [["normal", "Thường"], ["high", "Cao"]],
								onChange: (v) => setSettings({ quality: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Bộ lọc mặc định",
								value: s.defaultFilter,
								options: [
									["magic", "Thần kỳ"],
									["auto", "Tự động"],
									["sharp", "Sắc nét"],
									["original", "Gốc"]
								],
								onChange: (v) => setSettings({ defaultFilter: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Tự chụp khi máy đứng yên",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									"aria-label": "Tự chụp khi máy đứng yên",
									checked: s.autoCapture,
									onCheckedChange: (v) => setSettings({ autoCapture: v })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Chất lượng tối đa (chụp chậm hơn)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									"aria-label": "Chất lượng tối đa",
									checked: s.maxQuality,
									onCheckedChange: (v) => setSettings({ maxQuality: v })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Âm báo khi chụp",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									"aria-label": "Âm báo khi chụp",
									checked: s.captureSound,
									onCheckedChange: (v) => setSettings({ captureSound: v })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "AI tự đặt tên sau khi quét",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									"aria-label": "AI tự đặt tên sau khi quét",
									checked: s.autoName,
									onCheckedChange: (v) => setSettings({ autoName: v })
								})
							}),
							s.autoName && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NamingRules, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Xử lý ảnh nền khi rời màn chụp (thử nghiệm)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									"aria-label": "Xử lý ảnh nền khi rời màn chụp",
									checked: s.globalPipeline !== false,
									onCheckedChange: (v) => setSettings({ globalPipeline: v })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Tự nhận chữ sau khi quét",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									"aria-label": "Tự nhận chữ sau khi quét",
									checked: s.autoOcr ?? true,
									onCheckedChange: (v) => setSettings({ autoOcr: v })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Đọc hướng dẫn khi quét",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									"aria-label": "Đọc hướng dẫn khi quét",
									checked: s.voiceGuide,
									onCheckedChange: (v) => setSettings({ voiceGuide: v })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Rung theo hướng dẫn",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									"aria-label": "Rung theo hướng dẫn",
									checked: s.guideVibrate,
									onCheckedChange: (v) => setSettings({ guideVibrate: v })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Rung khi chụp",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									"aria-label": "Rung khi chụp",
									checked: s.captureVibrate,
									onCheckedChange: (v) => setSettings({ captureVibrate: v })
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
						title: "Xuất & nhận chữ",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Khổ trang PDF",
								value: s.pdfPage ?? "fit",
								options: [
									["fit", "Khớp ảnh"],
									["a4", "A4 có lề"],
									["letter", "Letter có lề"]
								],
								onChange: (v) => setSettings({ pdfPage: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Ngôn ngữ chữ",
								value: s.ocrLang,
								options: [
									["vie+eng", "Việt + Anh"],
									["vie", "Việt"],
									["eng", "Anh"]
								],
								onChange: (v) => setSettings({ ocrLang: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: ocrReady ? "Dùng khi mất mạng: đã sẵn sàng" : "Tải sẵn để mở app & nhận chữ khi mất mạng",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									disabled: ocrBusy,
									className: "min-h-10 min-w-10 text-sm font-semibold text-primary disabled:opacity-50",
									onClick: async () => {
										setOcrBusy(true);
										try {
											await prepareOfflineOcr(s.ocrLang);
											setOcrReady(true);
											toast.success("Đã tải sẵn dữ liệu nhận chữ");
										} catch (e) {
											showError(e, "Chưa tải được — kiểm tra mạng rồi thử lại");
										} finally {
											setOcrBusy(false);
										}
									},
									children: ocrBusy ? "Đang tải…" : ocrReady ? "Tải lại" : "Tải sẵn"
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
						title: "Giao diện & riêng tư",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Chữ lớn",
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Type, {}),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									"aria-label": "Chữ lớn",
									checked: s.largeText,
									onCheckedChange: (v) => setSettings({ largeText: v })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setSettings({ onboarded: false }),
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Xem lại hướng dẫn",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-semibold text-primary",
										children: "Mở"
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Chế độ tối",
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {}),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									"aria-label": "Chế độ tối",
									checked: s.dark,
									onCheckedChange: (v) => setSettings({ dark: v })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: setPin,
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: s.pin ? "Mã PIN: đang bật" : "Đặt mã PIN",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-semibold text-primary",
										children: s.pin ? "Tắt" : "Bật"
									})
								})
							}),
							s.pin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Tự khoá sau",
								value: String(s.autoLock),
								options: [
									["0", "Ngay"],
									["1", "1 phút"],
									["5", "5 phút"],
									["15", "15 phút"]
								],
								onChange: (v) => setSettings({ autoLock: Number(v) })
							}),
							s.pin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: makeRecovery,
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: s.vaultWrap?.rec ? "Mã khôi phục: đã tạo" : "Tạo mã khôi phục",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-semibold text-primary",
										children: s.vaultWrap?.rec ? "Tạo lại" : "Tạo"
									})
								})
							}),
							s.pin && s.vaultWrap?.rec && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: forgotPin,
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Quên mã PIN?",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-semibold text-primary",
										children: "Dùng mã khôi phục"
									})
								})
							}),
							s.pin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => {
									lockNow();
									toast("Đã khoá tất cả tài liệu");
								},
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Khoá ngay",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						title: "Tình trạng AI",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiStatusCard, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						title: "Khoá AI của tôi",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiKeysPanel, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						title: "Tài khoản",
						children: user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: async () => {
									await signOut();
									toast("Đã đăng xuất");
								},
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: `Đã đăng nhập: ${user.email ?? ""}`,
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-semibold text-primary",
										children: "Đăng xuất"
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: !!sync,
								onClick: async () => {
									setSync("Đang chuẩn bị…");
									try {
										const r = await syncAll(all, setSync);
										if (r.failed.length) toast.error(`Chưa đồng bộ được ${r.failed.length} tài liệu`, { description: `${r.failed.slice(0, 3).join(", ")} — kiểm tra mạng rồi bấm lại.` });
										else toast.success(r.sent || r.received ? `Đã tải về ${r.received} · tải lên ${r.sent} tài liệu` : "Máy và đám mây đã giống nhau");
									} catch (e) {
										showError(e, "Chưa đồng bộ được");
									} finally {
										setSync("");
									}
								},
								className: "w-full disabled:opacity-60",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: sync || "Đồng bộ với đám mây",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted-foreground",
										children: "bản mới nhất thắng"
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/sync",
								className: "block w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Màn hình đồng bộ · xung đột · xoá tài khoản",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-semibold text-primary",
										children: "Mở"
									})
								})
							})
						] }) : cloudReady() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/auth",
							className: "block w-full",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Đăng nhập (không bắt buộc)",
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {}),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-semibold text-primary",
									children: "Email · Google"
								})
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Đăng nhập: bản này chưa cấu hình máy chủ đám mây — tài liệu lưu trên máy",
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {}),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
						title: "Dữ liệu",
						children: [
							lvl !== "ok" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: lvl === "full" ? "Bộ nhớ gần đầy — có thể không lưu được ảnh mới. Dọn thùng rác hoặc ảnh tạm." : "Đã dùng trên 80% bộ nhớ cho app. Nên dọn bớt.",
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "!text-destructive" }),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: `Đã dùng ${usage || "…"}`,
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, {}),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: [docs.length, " tài liệu"]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => {
									downloadBaseline();
									toast(perfCount ? "Đã tải tệp số đo tốc độ" : "Chưa có số đo — hãy chụp vài trang trước", { description: perfCount ? void 0 : "Vào Quét, chụp khoảng 20 trang rồi bấm lại ở đây." });
								},
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Tải số đo tốc độ (perf-baseline.json)",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-muted-foreground",
										children: [perfCount, " lần đo"]
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: `Tài liệu ${fmtBytes(parts.active)} · Thùng rác ${fmtBytes(parts.trash)} · Ảnh tạm ${fmtBytes(parts.temp)}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: cleanUp,
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Dọn ảnh tạm",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted-foreground",
										children: fmtBytes(parts.temp)
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/trash",
								className: "block w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Thùng rác",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-muted-foreground",
										children: [trash.length, " tài liệu · giữ 30 ngày"]
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: backup,
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Sao lưu ra tệp",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: restore,
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Khôi phục từ tệp",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
								})
							}),
							perf && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PerfCard, {
								r: perf,
								budget,
								onClear: () => {
									clearPerf();
									setPerf(buildReport([], readScanLog()));
									setBudget(budgetReport([]));
									setPerfCount(0);
									toast("Đã xoá số đo tốc độ");
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => {
									setBench("Đang đo…");
									setTimeout(() => {
										const c = compareBench();
										const r = c.cur;
										setBench(`Mới ${r.correct}/${r.total} · Cũ ${c.old.correct}/${c.old.total}`);
										if (c.worse.length) toast("Bộ dò mới kém hơn ở: " + c.worse.join(", "));
										if (r.rate < .95) toast("Chưa đạt 95%", { description: r.results.filter((x) => !x.ok).map((x) => x.name).join(", ") });
									}, 30);
								},
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Đo tỉ lệ cắt đúng (24 ảnh mẫu)",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted-foreground",
										children: bench || "Bấm để đo"
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: async () => {
									const note = await promptDialog("Gửi báo lỗi", {
										message: "Mô tả ngắn lỗi gặp phải (không bắt buộc). Gói gửi kèm nhật ký và số đo tốc độ, KHÔNG kèm ảnh hay nội dung tài liệu.",
										placeholder: "Ví dụ: chụp xong bấm Xong bị treo",
										okText: "Tạo gói"
									});
									if (note === null) return;
									const { currentBugReport } = await import("./bug-report-DtCM4Aom.mjs");
									const { shareOrSave } = await import("./share-C6NDb_Ds.mjs").then((n) => n.r);
									const r = currentBugReport(note);
									await shareOrSave(r.blob, r.name, download, {
										title: "Báo lỗi Ghi Nhanh",
										text: "Gói báo lỗi Ghi Nhanh (không kèm ảnh)"
									});
								},
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Gửi báo lỗi (kèm nhật ký, không kèm ảnh)",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-semibold text-primary",
										children: "Gửi"
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => {
									const l = readScanLog();
									if (!l.length) {
										toast("Chưa có nhật ký quét");
										return;
									}
									download(new Blob([JSON.stringify(l, null, 2)], { type: "application/json" }), `ghi-nhanh-nhat-ky-quet-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`);
								},
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Tải nhật ký lỗi quét/AI",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-muted-foreground",
										children: [logCount, " mục"]
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: async () => {
									if (await confirmDialog("Xoá nhật ký quét?", {
										okText: "Xoá",
										danger: true
									})) {
										clearScanLog();
										setLogCount(0);
										toast("Đã xoá nhật ký");
									}
								},
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Xoá nhật ký quét",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/compare",
								className: "block w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "So với CamScanner (kiểm thử)",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Combine, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-semibold text-primary",
										children: "Mở"
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/field-test",
								className: "block w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Thử trên điện thoại thật (kiểm thử)",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, {}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-semibold text-primary",
										children: "Mở"
									})
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						title: "Cài như ứng dụng",
						children: inst.installed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Đã cài trên máy này",
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, {}),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
						}) : inst.canPrompt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: async () => {
								if (await inst.install()) toast.success("Đã cài Ghi Nhanh");
							},
							className: "w-full",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Cài Ghi Nhanh lên màn hình chính",
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, {}),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-semibold text-primary",
									children: "Cài"
								})
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: inst.ios ? "Bấm nút Chia sẻ của Safari → “Thêm vào MH chính”" : "Mở menu trình duyệt → “Cài ứng dụng” / “Thêm vào màn hình chính”",
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, {}),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
						})
					})
				]
			})
		]
	});
}
function Group({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rise rise-2 px-5 pt-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-2 font-display text-[0.8125rem] font-semibold text-muted-foreground",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "document-row divide-y divide-border overflow-hidden rounded-[16px]",
			children
		})]
	});
}
function Row({ label, icon, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[52px] items-center gap-3 px-4 py-2 text-left [&>svg]:size-5 [&>svg]:shrink-0 [&>svg]:text-primary",
		children: [
			icon,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0 flex-1 text-sm",
				children: label
			}),
			children
		]
	});
}
function Choice({ label, value, options, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[52px] items-center gap-3 px-4 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "min-w-0 flex-1 text-sm",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex shrink-0 rounded-[10px] bg-muted p-0.5",
			children: options.map(([v, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => onChange(v),
				className: `h-10 min-w-10 rounded-[8px] px-2.5 text-xs font-semibold ${value === v ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`,
				children: l
			}, v))
		})]
	});
}
function PerfCard({ r, budget, onClear }) {
	const sec = (ms) => ms >= 1e3 ? `${(ms / 1e3).toFixed(1)} giây` : `${ms} ms`;
	const line = (label, st) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-between gap-3 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: st.count ? `${sec(st.median)} · chậm nhất ~${sec(st.p90)} (${st.count} lần)` : "chưa có"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "document-row space-y-2 rounded-[16px] p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display font-semibold",
				children: "Tốc độ & lỗi trên máy này"
			}),
			line("Nắn ảnh (card đồ hoạ)", r.warpGpu),
			line("Nắn ảnh (bộ xử lý)", r.warpCpu),
			line("AI đọc trang", r.ai),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-between gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tỉ lệ lỗi AI" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: r.ai.errorRate > .2 ? "text-destructive" : "text-muted-foreground",
					children: r.ai.ok + r.ai.fail ? `${Math.round(r.ai.errorRate * 100)}% (${r.ai.fail}/${r.ai.ok + r.ai.fail})` : "chưa có"
				})]
			}),
			r.topErrors.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: ["Lỗi hay gặp: ", r.topErrors.map((e) => `${e.code} ×${e.n}`).join(", ")]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pt-1 text-sm font-semibold",
				children: "Ngân sách thời gian"
			}),
			budget.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				"data-testid": `budget-${b.k}`,
				className: "flex justify-between gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					b.label,
					" (≤ ",
					sec(b.budget),
					")"
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: b.ok === false ? "text-destructive" : "text-muted-foreground",
					children: b.count ? `~${sec(b.p90)} (${b.count} lần)${b.ok === false ? " — vượt" : b.ok ? " — đạt" : ""}` : "chưa có"
				})]
			}, b.k)),
			budget.some((b) => b.ok === false) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				role: "alert",
				className: "text-xs text-destructive",
				children: ["Máy này đang chậm hơn ngân sách ở: ", budget.filter((b) => b.ok === false).map((b) => overBudgetText(b)).join("; ")]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onClear,
				className: "py-3 text-xs text-muted-foreground underline",
				children: "Xoá số đo tốc độ"
			})
		]
	});
}
//#endregion
export { Me as component };
