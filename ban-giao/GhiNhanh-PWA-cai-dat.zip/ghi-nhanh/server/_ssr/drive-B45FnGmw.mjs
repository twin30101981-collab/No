//#region node_modules/.nitro/vite/services/ssr/assets/drive-B45FnGmw.js
var HIST_KEY = (docId) => `ghinhanh.chat.${docId}`;
var QUOTA_KEY = "ghinhanh.chat.quota";
var mem = /* @__PURE__ */ new Map();
var memStore = {
	getItem: (k) => mem.get(k) ?? null,
	setItem: (k, v) => void mem.set(k, v),
	removeItem: (k) => void mem.delete(k)
};
function store() {
	try {
		if (typeof localStorage !== "undefined") return localStorage;
	} catch {}
	return memStore;
}
function dayKey(t = Date.now()) {
	const d = new Date(t);
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
/** Cắt lịch sử, giữ các tin mới nhất. */
function trimHistory(list, max = 60) {
	return list.length > max ? list.slice(list.length - max) : list;
}
function loadHistory(docId, s = store()) {
	try {
		const v = JSON.parse(s.getItem(HIST_KEY(docId)) ?? "[]");
		return Array.isArray(v) ? v.filter((m) => m && (m.role === "user" || m.role === "ai") && typeof m.text === "string") : [];
	} catch {
		return [];
	}
}
function saveHistory(docId, list, s = store()) {
	const t = trimHistory(list);
	try {
		s.setItem(HIST_KEY(docId), JSON.stringify(t));
	} catch {}
	return t;
}
function clearHistory(docId, s = store()) {
	s.removeItem(HIST_KEY(docId));
}
function getQuota(now = Date.now(), s = store(), limit = 30) {
	const day = dayKey(now);
	let used = 0;
	try {
		const v = JSON.parse(s.getItem(QUOTA_KEY) ?? "null");
		if (v && v.day === day && Number.isFinite(v.used)) used = Math.max(0, v.used);
	} catch {}
	return {
		day,
		used,
		limit,
		left: Math.max(0, limit - used)
	};
}
/** Ghi nhận một lượt hỏi. Trả về null khi đã hết hạn mức hôm nay. */
function takeQuotaSlot(now = Date.now(), s = store(), limit = 30) {
	const q = getQuota(now, s, limit);
	if (q.left <= 0) return null;
	const used = q.used + 1;
	s.setItem(QUOTA_KEY, JSON.stringify({
		day: q.day,
		used
	}));
	return {
		...q,
		used,
		left: limit - used
	};
}
/** Hoàn lại lượt khi AI lỗi (không tính lượt hỏng). */
function refundQuotaSlot(now = Date.now(), s = store(), limit = 30) {
	const q = getQuota(now, s, limit);
	if (q.used > 0) s.setItem(QUOTA_KEY, JSON.stringify({
		day: q.day,
		used: q.used - 1
	}));
}
/** Tách câu trả lời thành phần chữ và nút trích dẫn [Trang N]. */
function splitCitations(text) {
	const out = [];
	const re = /\[Trang\s+(\d+)\]/gi;
	let last = 0;
	let m;
	while (m = re.exec(text)) {
		if (m.index > last) out.push({
			t: "text",
			v: text.slice(last, m.index)
		});
		out.push({
			t: "page",
			v: Number(m[1])
		});
		last = m.index + m[0].length;
	}
	if (last < text.length) out.push({
		t: "text",
		v: text.slice(last)
	});
	return out;
}
/**
* G4-22: save a document to the user's own Google Drive.
* Each user connects their own Drive with Google sign-in (scope drive.file: the app only sees files it created).
* Token lives in memory + sessionStorage of the tab (TF-03: không hỏi lại trong phiên); files go to a "Ghi Nhanh" folder. Pure helpers are exported for tests.
*/
var DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.file";
var DRIVE_FOLDER = "Ghi Nhanh";
var GIS_SRC = "https://accounts.google.com/gsi/client";
function driveClientId() {
	return {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/"
	}["VITE_GOOGLE_CLIENT_ID"]?.trim() ?? "";
}
var driveReady = () => driveClientId().length > 0;
/** Drive search query for our folder (single quotes escaped). */
function folderQuery(name = DRIVE_FOLDER) {
	return `name='${name.replace(/\\/g, "\\\\").replace(/'/g, "\\'")}' and mimeType='application/vnd.google-apps.folder' and trashed=false`;
}
/** multipart/related body: JSON metadata + file bytes. */
function multipartBody(meta, blob, boundary) {
	const head = `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(meta)}\r\n--${boundary}\r\nContent-Type: ${blob.type || "application/octet-stream"}\r\n\r\n`;
	return new Blob([
		head,
		blob,
		`\r\n--${boundary}--`
	], { type: `multipart/related; boundary=${boundary}` });
}
/** Map Drive API failures to Vietnamese messages. */
function driveError(status, body = "") {
	if (status === 401) return "Phiên Google Drive đã hết hạn — bấm lại để kết nối.";
	if (status === 403 && /storageQuota|quota/i.test(body)) return "Google Drive đã hết dung lượng.";
	if (status === 403) return "Google Drive từ chối quyền ghi tệp.";
	if (status === 429 || status >= 500) return "Google Drive đang bận, thử lại sau ít phút.";
	return `Không lưu được lên Google Drive (mã ${status}).`;
}
var TOKEN_KEY = "gn-drive-token";
/** TF-03: token giữ theo PHIÊN thẻ (sessionStorage; tắt thẻ là mất; không lưu lâu dài) → tải lại trang vẫn không hỏi Google lại. */
function readStoredToken(store, now = Date.now()) {
	try {
		const t = JSON.parse(store?.getItem(TOKEN_KEY) ?? "null");
		if (t && typeof t.value === "string" && typeof t.until === "number" && t.until > now + 3e4) return {
			value: t.value,
			until: t.until
		};
		store?.removeItem(TOKEN_KEY);
	} catch {}
	return null;
}
function storeToken(t) {
	try {
		if (t) sessionStorage.setItem(TOKEN_KEY, JSON.stringify(t));
		else sessionStorage.removeItem(TOKEN_KEY);
	} catch {}
}
var token = typeof sessionStorage === "undefined" ? null : readStoredToken(sessionStorage);
var gis = null;
function loadGis() {
	if (window.google?.accounts?.oauth2) return Promise.resolve();
	gis ??= new Promise((ok, fail) => {
		const s = document.createElement("script");
		s.src = GIS_SRC;
		s.async = true;
		s.onload = () => ok();
		s.onerror = () => {
			gis = null;
			fail(/* @__PURE__ */ new Error("Không tải được đăng nhập Google — kiểm tra mạng."));
		};
		document.head.appendChild(s);
	});
	return gis;
}
async function getToken() {
	if (token && token.until > Date.now() + 3e4) return token.value;
	const id = driveClientId();
	if (!id) throw new Error("Chưa cấu hình kết nối Google Drive.");
	await loadGis();
	const g = window.google;
	return new Promise((ok, fail) => {
		g.accounts.oauth2.initTokenClient({
			client_id: id,
			scope: DRIVE_SCOPE,
			callback: (r) => {
				if (!r.access_token) return fail(/* @__PURE__ */ new Error(r.error === "access_denied" ? "Bạn chưa cho phép truy cập Google Drive." : "Không kết nối được Google Drive."));
				token = {
					value: r.access_token,
					until: Date.now() + (r.expires_in ?? 3600) * 1e3
				};
				storeToken(token);
				ok(r.access_token);
			},
			error_callback: (e) => fail(/* @__PURE__ */ new Error(e?.type === "popup_closed" ? "Đã đóng cửa sổ Google." : "Trình duyệt chặn cửa sổ đăng nhập Google."))
		}).requestAccessToken({ prompt: token ? "" : "consent" });
	});
}
async function api(path, init, f = fetch) {
	const t = await getToken();
	const r = await f(`https://www.googleapis.com${path}`, {
		...init,
		headers: {
			...init.headers ?? {},
			Authorization: `Bearer ${t}`
		}
	});
	if (!r.ok) {
		const b = await r.text().catch(() => "");
		if (r.status === 401) {
			token = null;
			storeToken(null);
		}
		throw new Error(driveError(r.status, b));
	}
	return r.json();
}
async function folderId() {
	const found = (await api(`/drive/v3/files?q=${encodeURIComponent(folderQuery())}&fields=files(id)&spaces=drive`, {})).files?.[0]?.id;
	if (found) return found;
	return (await api("/drive/v3/files?fields=id", {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			name: DRIVE_FOLDER,
			mimeType: "application/vnd.google-apps.folder"
		})
	})).id;
}
/** Upload a file; returns its Drive view link. Must be started from a click (opens Google popup on first use). */
async function saveToDrive(blob, name) {
	const parent = await folderId();
	const boundary = "gn" + Math.random().toString(36).slice(2);
	const r = await api("/upload/drive/v3/files?uploadType=multipart&fields=id,webViewLink", {
		method: "POST",
		headers: { "Content-Type": `multipart/related; boundary=${boundary}` },
		body: multipartBody({
			name,
			parents: [parent]
		}, blob, boundary)
	});
	return {
		id: r.id,
		link: r.webViewLink ?? `https://drive.google.com/file/d/${r.id}/view`
	};
}
//#endregion
export { refundQuotaSlot as a, splitCitations as c, loadHistory as i, takeQuotaSlot as l, driveReady as n, saveHistory as o, getQuota as r, saveToDrive as s, clearHistory as t };
