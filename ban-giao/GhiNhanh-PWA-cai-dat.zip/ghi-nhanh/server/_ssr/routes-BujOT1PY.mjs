import { S as createFileRoute, x as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BujOT1PY.js
var $$splitComponentImporter = () => import("./routes-jaZf4-y2.mjs");
var Route = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "Ghi Nhanh — Quét tài liệu trên điện thoại" },
		{
			name: "description",
			content: "Quét nhiều trang, cắt thẳng, nhận diện chữ tiếng Việt và xuất PDF ngay trên điện thoại."
		},
		{
			property: "og:title",
			content: "Ghi Nhanh — Quét tài liệu trên điện thoại"
		},
		{
			property: "og:description",
			content: "Quét nhiều trang, cắt thẳng, nhận diện chữ tiếng Việt và xuất PDF ngay trên điện thoại."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	validateSearch: (s) => s["shared"] != null ? { shared: Number(s["shared"]) || 0 } : {},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
