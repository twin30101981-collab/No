import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as createMiddleware } from "./createMiddleware-B_4t7rW1.mjs";
import { t as createServerRpc } from "./createServerRpc-CxD4EZ5P.mjs";
import { c as normalizeDiagnosis, i as diagLogLine, n as MAX_DATA_CHARS } from "./scan-diagnose-HshWtdyP.mjs";
import { i as stringType, n as enumType, r as objectType, t as arrayType } from "../_libs/zod.mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/ai.functions-YcTY3dK8.js
/**
* BL-08 (log AI): một dòng log gọn cho lỗi AI ở máy chủ. KHÔNG in nguyên đối tượng lỗi: APICallError của AI SDK mang
* `requestBodyValues` (ảnh base64 của giấy tờ — CCCD, hoá đơn) và `responseBody`; console.error(e) đổ cả vào log máy chủ.
*/
function redactSecrets(s) {
	return s.replace(/data:[\w/+.-]+;base64,[A-Za-z0-9+/=]+/g, "data:…").replace(/[A-Za-z0-9+/=_-]{120,}/g, "…").replace(/\b(sk-[A-Za-z0-9]{0,6}|AIza[0-9A-Za-z_-]{0,4})[0-9A-Za-z_-]{8,}/g, "$1…").replace(/([?&](?:key|api_key|token)=)[^&\s"]+/gi, "$1…").replace(/(Bearer\s+)[^\s"]+/gi, "$1…");
}
function aiErrorLine(e, where = "ai") {
	const o = e && typeof e === "object" ? e : {};
	const msg = redactSecrets(String(o.message ?? e)).slice(0, 300);
	const status = typeof o.statusCode === "number" ? ` ${o.statusCode}` : "";
	const code = typeof o.code === "string" ? ` ${o.code}` : "";
	return `[${where}] ${typeof o.name === "string" ? o.name : "Error"}${status}${code}: ${msg}`;
}
var img = stringType().startsWith("data:image/").max(4e6);
/** AI-04: chỉ các lệnh AI gắn tiêu đề x-ai-keys (key người dùng đã lưu mã hoá trên máy); không có key thì không gắn gì. */
var aiKeysMw = createMiddleware({ type: "function" }).client(async ({ next }) => {
	if (typeof window === "undefined") return next();
	const { aiKeysHeader, AI_KEYS_HEADER } = await import("./ai-keys-fpHjq2Jo.mjs").then((n) => n.r);
	const { aiSensitivityHint, AI_SENSITIVE_HEADER } = await import("./ai-sensitivity-GdXzjggN.mjs");
	const h = await aiKeysHeader().catch(() => null), s = aiSensitivityHint();
	const headers = {};
	if (h) headers[AI_KEYS_HEADER] = h;
	if (s !== null) headers[AI_SENSITIVE_HEADER] = s ? "1" : "0";
	return next({ headers });
});
/** AI-01: chạy việc AI trong ngữ cảnh chuỗi nguồn; kết quả thành công kèm `source` (nguồn đã phục vụ: lovable/claude/mistral/gemini). */
async function tracked(task, data, fn) {
	const { withAiSource, aiKeysOverrides } = await import("./ai-chain.server-D7XpPXa2.mjs");
	const { sensitiveFor } = await import("./ai-sensitivity-GdXzjggN.mjs");
	const { getRequest } = await import("./server-BYuUwks4.mjs").then((n) => n.i).then((n) => n.t);
	const h = getRequest()?.headers;
	const { value, source, tried } = await withAiSource(fn, aiKeysOverrides(h?.get("x-ai-keys")), sensitiveFor(task, data, h?.get("x-ai-sensitive")));
	if (!value || typeof value !== "object" || !("ok" in value)) return value;
	return {
		...value,
		...source ? { source } : {},
		...tried.length ? { tried } : {}
	};
}
var aiExtract_createServerFn_handler = createServerRpc({
	id: "1453a21a4491fc7bec8ad067eb310e9b22376f2bd30a0340c16bfdf1dee2689b",
	name: "aiExtract",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiExtract.__executeServer(opts));
var aiExtract = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({
	images: arrayType(img).min(1).max(4),
	template: enumType([
		"vat",
		"xe",
		"sodo"
	]).optional()
}).parse(d)).handler(aiExtract_createServerFn_handler, async ({ data }) => tracked("aiExtract", data, async () => {
	const { extractFromImages, toFail, aiGate } = await import("./ai.server-BlPd7ITf.mjs");
	const limited = await aiGate();
	if (limited) return limited;
	try {
		return {
			ok: true,
			data: await extractFromImages(data.images, data.template)
		};
	} catch (e) {
		console.error(aiErrorLine(e));
		return toFail(e);
	}
}));
var aiText_createServerFn_handler = createServerRpc({
	id: "56db84a888ffaeaaab3462275df7b64e74b44521d4436490ac79509b4b855c40",
	name: "aiText",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiText.__executeServer(opts));
var aiText = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({
	task: enumType([
		"translate",
		"summarize",
		"solve",
		"handwrite"
	]),
	text: stringType().max(3e4).optional(),
	images: arrayType(img).max(4).optional(),
	lang: stringType().max(40).optional()
}).refine((v) => v.text?.trim() || v.images?.length, "empty").parse(d)).handler(aiText_createServerFn_handler, async ({ data }) => tracked("aiText", data, async () => {
	const { runTextTask, toFail, aiGate } = await import("./ai.server-BlPd7ITf.mjs");
	const limited = await aiGate();
	if (limited) return limited;
	try {
		return {
			ok: true,
			text: await runTextTask(data.task, data)
		};
	} catch (e) {
		console.error(aiErrorLine(e));
		return toFail(e);
	}
}));
var aiRows_createServerFn_handler = createServerRpc({
	id: "8409476496bea21a8699cd409cbee795dd07ebd0d8433c5decd4a798620bf15b",
	name: "aiRows",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiRows.__executeServer(opts));
var aiRows = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ images: arrayType(img).min(1).max(4) }).parse(d)).handler(aiRows_createServerFn_handler, async ({ data }) => tracked("aiRows", data, async () => {
	const { rowsFromImages, toFail, aiGate } = await import("./ai.server-BlPd7ITf.mjs");
	const limited = await aiGate();
	if (limited) return limited;
	try {
		return {
			ok: true,
			data: await rowsFromImages(data.images)
		};
	} catch (e) {
		console.error(aiErrorLine(e));
		return toFail(e);
	}
}));
var aiTable_createServerFn_handler = createServerRpc({
	id: "fee9b6c827c57709b7fa5d29bb1e9186399d74aefeb66a06a34263447dde1f67",
	name: "aiTable",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiTable.__executeServer(opts));
var aiTable = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ images: arrayType(img).min(1).max(4) }).parse(d)).handler(aiTable_createServerFn_handler, async ({ data }) => tracked("aiTable", data, async () => {
	const { rowsFromImages, toFail, aiGate } = await import("./ai.server-BlPd7ITf.mjs");
	const limited = await aiGate();
	if (limited) return limited;
	const { rowsToGrid } = await import("./columns-CKy-JpGD.mjs");
	try {
		const r = await rowsFromImages(data.images);
		return {
			ok: true,
			data: {
				title: r.title,
				rows: rowsToGrid(r.rows)
			}
		};
	} catch (e) {
		console.error(aiErrorLine(e));
		return toFail(e);
	}
}));
var aiLayout_createServerFn_handler = createServerRpc({
	id: "40eea221df3652422361115215091d174916a19c57ecb22f77d6664f33c524c6",
	name: "aiLayout",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiLayout.__executeServer(opts));
var aiLayout = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ images: arrayType(img).min(1).max(4) }).parse(d)).handler(aiLayout_createServerFn_handler, async ({ data }) => tracked("aiLayout", data, async () => {
	const { layoutFromImages, toFail, aiGate } = await import("./ai.server-BlPd7ITf.mjs");
	const limited = await aiGate();
	if (limited) return limited;
	try {
		return {
			ok: true,
			data: await layoutFromImages(data.images)
		};
	} catch (e) {
		console.error(aiErrorLine(e));
		return toFail(e);
	}
}));
var aiDocAsk_createServerFn_handler = createServerRpc({
	id: "280c0f12ccaa87a6526d913e064908c02360938c46115eaad9cbad77b3fe7a2b",
	name: "aiDocAsk",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiDocAsk.__executeServer(opts));
var aiDocAsk = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({
	question: stringType().trim().min(1).max(1e3),
	pages: arrayType(stringType().max(5e4)).min(1).max(60)
}).parse(d)).handler(aiDocAsk_createServerFn_handler, async ({ data }) => tracked("aiDocAsk", data, async () => {
	const { answerDocQuestion, toFail, aiGate } = await import("./ai.server-BlPd7ITf.mjs");
	const limited = await aiGate();
	if (limited) return limited;
	const { chunkDocument, selectChunks, buildContext } = await import("./doc-qa-DibGoYZN.mjs");
	try {
		const chunks = selectChunks(chunkDocument(data.pages.map((text) => ({ text }))), data.question);
		if (!chunks.length) return {
			ok: false,
			code: 422,
			message: "Tài liệu chưa có chữ. Hãy nhận chữ (OCR/AI) trước rồi hỏi lại."
		};
		const r = await answerDocQuestion(data.question, buildContext(chunks));
		return {
			ok: true,
			answer: r.answer,
			pages: r.pages,
			usedPages: [...new Set(chunks.map((c) => c.page))]
		};
	} catch (e) {
		console.error(aiErrorLine(e));
		return toFail(e);
	}
}));
var aiClassify_createServerFn_handler = createServerRpc({
	id: "53a4f104cd1c70577f4c82bb90053dfe68e795719b2f232b2bf3cfbbe723f46a",
	name: "aiClassify",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiClassify.__executeServer(opts));
var aiClassify = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ images: arrayType(img).min(1).max(2) }).parse(d)).handler(aiClassify_createServerFn_handler, async ({ data }) => tracked("aiClassify", data, async () => {
	const { classifyImages, toFail, aiGate } = await import("./ai.server-BlPd7ITf.mjs");
	const limited = await aiGate();
	if (limited) return limited;
	try {
		return {
			ok: true,
			data: await classifyImages(data.images)
		};
	} catch (e) {
		console.error(aiErrorLine(e));
		return toFail(e);
	}
}));
var aiTranslateBlocks_createServerFn_handler = createServerRpc({
	id: "92c12948b77e36ae0d6df5dfcfbf3ce549377e5dcd880612d491f718bdea9bb7",
	name: "aiTranslateBlocks",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiTranslateBlocks.__executeServer(opts));
var aiTranslateBlocks = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({
	texts: arrayType(stringType().max(4e3)).min(1).max(200),
	lang: stringType().min(1).max(40)
}).parse(d)).handler(aiTranslateBlocks_createServerFn_handler, async ({ data }) => tracked("aiTranslateBlocks", data, async () => {
	const { translateBlocks, toFail, aiGate } = await import("./ai.server-BlPd7ITf.mjs");
	const limited = await aiGate();
	if (limited) return limited;
	try {
		return {
			ok: true,
			texts: await translateBlocks(data.texts, data.lang)
		};
	} catch (e) {
		console.error(aiErrorLine(e));
		return toFail(e);
	}
}));
var aiPersonGreen_createServerFn_handler = createServerRpc({
	id: "6db13cc0879a96b11a9842037feb4ee8580102b2c161116c256fdec3b86b4a87",
	name: "aiPersonGreen",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiPersonGreen.__executeServer(opts));
var aiPersonGreen = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ image: img }).parse(d)).handler(aiPersonGreen_createServerFn_handler, async ({ data }) => tracked("aiPersonGreen", data, async () => {
	const { greenScreenPerson, toFail, aiGate } = await import("./ai.server-BlPd7ITf.mjs");
	const limited = await aiGate();
	if (limited) return limited;
	try {
		return {
			ok: true,
			image: await greenScreenPerson(data.image)
		};
	} catch (e) {
		console.error(aiErrorLine(e));
		return toFail(e);
	}
}));
var aiReceipt_createServerFn_handler = createServerRpc({
	id: "0ca6e7554fc3f33aecb540529f35ca3c25c7cc60e65d242a45ec1ee9d3492afb",
	name: "aiReceipt",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiReceipt.__executeServer(opts));
var aiReceipt = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ image: img }).parse(d)).handler(aiReceipt_createServerFn_handler, async ({ data }) => tracked("aiReceipt", data, async () => {
	const { receiptFromImage, toFail, aiGate } = await import("./ai.server-BlPd7ITf.mjs");
	const limited = await aiGate();
	if (limited) return limited;
	try {
		return {
			ok: true,
			data: await receiptFromImage(data.image)
		};
	} catch (e) {
		console.error(aiErrorLine(e));
		return toFail(e);
	}
}));
var aiPaperCorners_createServerFn_handler = createServerRpc({
	id: "50d37df7685c56c9fbdeb09183eab242f1002b2926c86996bd696b307e77d0fe",
	name: "aiPaperCorners",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiPaperCorners.__executeServer(opts));
var aiPaperCorners = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ image: img }).parse(d)).handler(aiPaperCorners_createServerFn_handler, async ({ data }) => tracked("aiPaperCorners", data, async () => {
	const { paperCornersFromImage, toFail, aiGate } = await import("./ai.server-BlPd7ITf.mjs");
	const limited = await aiGate();
	if (limited) return limited;
	try {
		return {
			ok: true,
			data: await paperCornersFromImage(data.image)
		};
	} catch (e) {
		console.error(aiErrorLine(e));
		return toFail(e);
	}
}));
var aiPhotoCheck_createServerFn_handler = createServerRpc({
	id: "d862f1b45ce22fc1327a146114ddb240c9906758a402c31bd89063f3e24b2191",
	name: "aiPhotoCheck",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiPhotoCheck.__executeServer(opts));
var aiPhotoCheck = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ image: img }).parse(d)).handler(aiPhotoCheck_createServerFn_handler, async ({ data }) => tracked("aiPhotoCheck", data, async () => {
	const { checkDocPhoto, toFail, aiGate } = await import("./ai.server-BlPd7ITf.mjs");
	const limited = await aiGate();
	if (limited) return limited;
	try {
		return {
			ok: true,
			data: await checkDocPhoto(data.image)
		};
	} catch (e) {
		console.error(aiErrorLine(e));
		return toFail(e);
	}
}));
var aiScanDiagnose_createServerFn_handler = createServerRpc({
	id: "a7c4e12c7d4bceefff8bdb2102e80eefafe878a9712152d19cf39bf8d137fcbe",
	name: "aiScanDiagnose",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiScanDiagnose.__executeServer(opts));
var aiScanDiagnose = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({
	image: stringType().startsWith("data:image/").max(MAX_DATA_CHARS),
	version: stringType().max(200)
}).parse(d)).handler(aiScanDiagnose_createServerFn_handler, async ({ data }) => tracked("aiScanDiagnose", data, async () => {
	const { diagnoseScan, toFail, aiGate } = await import("./ai.server-BlPd7ITf.mjs");
	const limited = await aiGate();
	if (limited) return limited;
	try {
		const d = normalizeDiagnosis(await diagnoseScan(data.image), data.version);
		console.log(diagLogLine(data.version, d));
		return {
			ok: true,
			data: d
		};
	} catch (e) {
		const f = toFail(e);
		console.log(diagLogLine(data.version, null, f.code));
		return f;
	}
}));
var aiKeyCheck_createServerFn_handler = createServerRpc({
	id: "3cc5d315fc0705890be69eb9a4146e5e25a5b69a7f7976a6be3c4e4b75a7d087",
	name: "aiKeyCheck",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiKeyCheck.__executeServer(opts));
var aiKeyCheck = createServerFn({ method: "POST" }).middleware([aiKeysMw]).inputValidator((d) => objectType({ provider: enumType([
	"lovable",
	"claude",
	"mistral",
	"gemini"
]) }).parse(d)).handler(aiKeyCheck_createServerFn_handler, async ({ data }) => tracked("aiKeyCheck", data, async () => {
	const { pingProvider } = await import("./ai.server-BlPd7ITf.mjs");
	const { aiEnv, errorCode, providerOrder } = await import("./ai-chain.server-D7XpPXa2.mjs");
	if (!providerOrder({}, {
		...aiEnv(),
		AI_PROVIDERS: data.provider
	}).length) return {
		ok: false,
		status: "no-key",
		code: 401
	};
	try {
		await pingProvider(data.provider);
		return {
			ok: true,
			status: "ready"
		};
	} catch (e) {
		const code = errorCode(e);
		return {
			ok: false,
			code,
			status: code === 401 || code === 403 ? "bad-key" : code === 402 || code === 429 ? "quota" : "error"
		};
	}
}));
var aiProviders_createServerFn_handler = createServerRpc({
	id: "b7955cf62ddfdb3b49e42ebc7c3a1fbfc7e7891d9b33db3970e46e6401cad67e",
	name: "aiProviders",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiProviders.__executeServer(opts));
var aiProviders = createServerFn({ method: "POST" }).middleware([aiKeysMw]).handler(aiProviders_createServerFn_handler, async () => {
	const { ALL_PROVIDERS, FREE_PROVIDERS, PROVIDER_KEY_ENV, PROVIDER_LABEL, aiKeysOverrides } = await import("./ai-chain.server-D7XpPXa2.mjs");
	const { getRequest } = await import("./server-BYuUwks4.mjs").then((n) => n.i).then((n) => n.t);
	const user = aiKeysOverrides(getRequest()?.headers.get("x-ai-keys")) ?? {};
	const server = typeof processModule !== "undefined" ? processModule.env : {};
	const wanted = (user["AI_PROVIDERS"] ?? server["AI_PROVIDERS"] ?? "").split(",").map((s) => s.trim()).filter((s) => ALL_PROVIDERS.includes(s));
	return {
		ok: true,
		providers: [.../* @__PURE__ */ new Set([...wanted, ...ALL_PROVIDERS])].map((id) => {
			const env = PROVIDER_KEY_ENV[id], keySource = user[env]?.trim() ? "user" : server[env]?.trim() ? "server" : null;
			return {
				id,
				label: PROVIDER_LABEL[id],
				free: FREE_PROVIDERS.has(id),
				keySource,
				enabled: !wanted.length || wanted.includes(id)
			};
		})
	};
});
//#endregion
export { aiClassify_createServerFn_handler, aiDocAsk_createServerFn_handler, aiExtract_createServerFn_handler, aiKeyCheck_createServerFn_handler, aiLayout_createServerFn_handler, aiPaperCorners_createServerFn_handler, aiPersonGreen_createServerFn_handler, aiPhotoCheck_createServerFn_handler, aiProviders_createServerFn_handler, aiReceipt_createServerFn_handler, aiRows_createServerFn_handler, aiScanDiagnose_createServerFn_handler, aiTable_createServerFn_handler, aiText_createServerFn_handler, aiTranslateBlocks_createServerFn_handler };
