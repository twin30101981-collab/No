import { n as getSettings } from "./settings-DDlMLZCe.mjs";
import { L as renderPageUrl, _ as detectQuadInfo, q as targetLong, r as PREVIEW_LONG, z as renderQuickUrl } from "./image-DFWRNlNd.mjs";
import { t as EDGE_WARNING } from "./batch-review-Be3azLyj.mjs";
import { gradeOf } from "./post-capture-metrics-X7ExzflM.mjs";
import { t as pmapOrdered } from "./pmap-BY7K0bZd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/import-pipeline-B6K4tiBD.js
/** Trang cần đi dây chuyền: ảnh CHỤP (importKind "photo") chưa có khung. Ảnh phẳng/chụp màn hình, trang PDF giữ nguyên. */
var needsPipeline = (p) => p.importKind === "photo" && !p.edit.quad;
async function processImported(pages, onProgress) {
	const todo = pages.filter(needsPipeline);
	if (!todo.length) return pages;
	const st = getSettings();
	const full = targetLong(st.quality);
	const lanes = Math.min(3, Math.max(1, (typeof navigator !== "undefined" ? navigator.hardwareConcurrency || 2 : 2) - 1));
	const out = /* @__PURE__ */ new Map();
	let done = 0;
	onProgress?.(0, todo.length);
	await pmapOrdered(todo, lanes, async (p) => {
		const info = await detectQuadInfo(p.orig).catch(() => ({
			quad: null,
			sure: false
		}));
		await gradeOf(p.orig).catch(() => null);
		const edit = {
			...p.edit,
			quad: info.quad ?? void 0,
			filter: st.defaultFilter
		};
		const pre = Math.min(PREVIEW_LONG, full);
		const src = (full > 1200 ? await renderQuickUrl(p.orig, edit, pre) : null) ?? await renderPageUrl(p.orig, edit, pre);
		const next = {
			...p,
			edit,
			src,
			status: full > 1200 ? "dang" : "xong"
		};
		if (!info.quad || !info.sure) next.warnings = [.../* @__PURE__ */ new Set([...p.warnings ?? [], EDGE_WARNING])];
		return next;
	}, (r) => {
		out.set(r.id, r);
		onProgress?.(++done, todo.length);
	});
	return pages.map((p) => out.get(p.id) ?? p);
}
//#endregion
export { processImported };
