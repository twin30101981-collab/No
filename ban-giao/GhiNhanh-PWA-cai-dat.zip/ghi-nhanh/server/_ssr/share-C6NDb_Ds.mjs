import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { r as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/share-C6NDb_Ds.js
var share_exports = /* @__PURE__ */ __exportAll({
	canShareThisFile: () => canShareThisFile,
	classifyShareError: () => classifyShareError,
	offerTapToShare: () => offerTap,
	shareOrSave: () => shareOrSave,
	tryShare: () => tryShare
});
/** Phân loại lỗi navigator.share: AbortError = người dùng đóng bảng; NotAllowedError = hết "quyền chia sẻ" của lần chạm. */
function classifyShareError(e) {
	const n = e?.name;
	if (n === "AbortError") return "cancelled";
	if (n === "NotAllowedError") return "needs-tap";
	return "failed";
}
/** Máy có bảng chia sẻ VÀ chấp nhận đúng loại tệp này (nhiều máy từ chối ZIP/DOCX/XLSX). */
function canShareThisFile(file) {
	try {
		return typeof navigator !== "undefined" && typeof navigator.share === "function" && !!navigator.canShare?.({ files: [file] });
	} catch {
		return false;
	}
}
async function tryShare(file, data = {}) {
	if (!canShareThisFile(file)) return "unsupported";
	try {
		await navigator.share({
			files: [file],
			title: data.title ?? file.name,
			...data.text ? { text: data.text } : {}
		});
		return "shared";
	} catch (e) {
		return classifyShareError(e);
	}
}
/** Tệp đã dựng xong nhưng lần chạm đã hết hiệu lực: hiện thẻ để người dùng chạm lần 2 (chạm mới = quyền mới). */
function offerTap(file, data, save) {
	const big = {
		minHeight: 40,
		padding: "0 14px",
		fontSize: 14,
		fontWeight: 600
	};
	toast("Tệp đã sẵn sàng", {
		actionButtonStyle: big,
		cancelButtonStyle: big,
		description: `“${file.name}” — chạm Chia sẻ để chọn Zalo, email…`,
		duration: 2e4,
		action: {
			label: "Chia sẻ",
			onClick: () => {
				tryShare(file, data).then((r) => {
					if (r === "unsupported" || r === "failed" || r === "needs-tap") {
						save(file, file.name);
						toast.info(`Không mở được bảng chia sẻ — đã lưu “${file.name}” về máy`);
					}
				});
			}
		},
		cancel: {
			label: "Lưu về máy",
			onClick: () => {
				save(file, file.name);
				toast.success(`Đã lưu “${file.name}”`);
			}
		}
	});
}
/** Chia sẻ, hoặc lưu về máy kèm thông báo rõ ràng — không bao giờ để nút "không làm gì". */
async function shareOrSave(blob, name, save, data = {}) {
	const file = new File([blob], name, { type: blob.type });
	const r = await tryShare(file, data);
	if (r === "shared" || r === "cancelled") return r;
	if (r === "needs-tap") {
		offerTap(file, data, save);
		return "needs-tap";
	}
	save(blob, name);
	if (r === "unsupported") {
		const phone = typeof navigator !== "undefined" && typeof navigator.share === "function";
		toast.info(phone ? `Máy không chia sẻ được loại tệp này — đã lưu “${name}” về máy` : `Đã lưu “${name}”`);
	} else toast.error("Không mở được bảng chia sẻ", { description: `Đã lưu “${name}” về máy để bạn gửi thủ công.` });
	return "downloaded";
}
//#endregion
export { tryShare as i, offerTap as n, share_exports as r, canShareThisFile as t };
