import { S as createFileRoute, x as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/doc._id-P7iptWfN.js
var $$splitComponentImporter = () => import("./doc._id-B3wmy5G7.mjs");
var Route = createFileRoute("/doc/$id")({
	validateSearch: (s) => ({
		tool: typeof s["tool"] === "string" ? s["tool"] : void 0,
		run: typeof s["run"] === "string" ? s["run"] : void 0,
		review: s["review"] === "1" || s["review"] === 1 ? "1" : void 0
	}),
	head: () => ({ meta: [
		{ title: "Xem tài liệu — Ghi Nhanh" },
		{
			name: "description",
			content: "Chỉnh trang, cắt thẳng, lọc ảnh, ký tên, nhận chữ và xuất PDF."
		},
		{
			property: "og:title",
			content: "Xem tài liệu — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Chỉnh trang, cắt thẳng, lọc ảnh, ký tên, nhận chữ và xuất PDF."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		},
		{
			name: "robots",
			content: "noindex"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
