import { o as __toESM } from "../_runtime.mjs";
import { n as require_pako } from "../_libs/pako+pdf-lib__fontkit+unenv.mjs";
import { t as require_UTIF } from "../_libs/utif2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tiff-decode-BuyiEdCy.js
var import_pako = /* @__PURE__ */ __toESM(require_pako());
var import_UTIF = /* @__PURE__ */ __toESM(require_UTIF());
/**
* CS-11: utif2 lấy pako bằng `require("pako")`, nếu không có thì `self.pako`. Trong gói build (ESM) không có require
* → TIFF nén deflate báo lỗi. Gán pako toàn cục TRƯỚC khi nạp utif2 (tiff-decode.ts import tệp này trước).
* Phải là giá trị được dùng (không phải import chỉ để chạy): package.json có "sideEffects": false → Rollup bỏ import trần.
*/
var g = globalThis;
var TIFF_PAKO = g.pako ??= import_pako.default;
var MAX_SIDE = 4096;
var MAX_AREA = 16e6;
/** Đầu tệp TIFF: "II*\0" (little-endian) hoặc "MM\0*" (big-endian); BigTIFF dùng 43 thay 42. */
function isTiffBytes(b) {
	if (b.length < 4) return false;
	return b[0] === 73 && b[1] === 73 && (b[2] === 42 || b[2] === 43) && b[3] === 0 || b[0] === 77 && b[1] === 77 && b[2] === 0 && (b[3] === 42 || b[3] === 43);
}
/** Thu nhỏ RGBA bằng trung bình hộp (giữ nét chữ tốt hơn lấy mẫu gần nhất). */
function downscaleRgba(src, w, h, tw, th) {
	const out = new Uint8Array(tw * th * 4);
	for (let y = 0; y < th; y++) {
		const y0 = Math.floor(y * h / th), y1 = Math.max(y0 + 1, Math.floor((y + 1) * h / th));
		for (let x = 0; x < tw; x++) {
			const x0 = Math.floor(x * w / tw), x1 = Math.max(x0 + 1, Math.floor((x + 1) * w / tw));
			let r = 0, g = 0, b = 0, a = 0;
			for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) {
				const p = (yy * w + xx) * 4;
				r += src[p];
				g += src[p + 1];
				b += src[p + 2];
				a += src[p + 3];
			}
			const n = (y1 - y0) * (x1 - x0), q = (y * tw + x) * 4;
			out[q] = Math.round(r / n);
			out[q + 1] = Math.round(g / n);
			out[q + 2] = Math.round(b / n);
			out[q + 3] = Math.round(a / n);
		}
	}
	return out;
}
/** Trộn kênh trong suốt lên nền trắng (JPEG không có alpha: vùng trong suốt sẽ thành đen). */
function flattenOnWhite(d) {
	for (let p = 3; p < d.length; p += 4) {
		const a = d[p];
		if (a === 255) continue;
		const k = 255 - a;
		d[p - 3] = Math.round((d[p - 3] * a + 255 * k) / 255);
		d[p - 2] = Math.round((d[p - 2] * a + 255 * k) / 255);
		d[p - 1] = Math.round((d[p - 1] * a + 255 * k) / 255);
		d[p] = 255;
	}
	return d;
}
/** Cỡ đích sau khi kẹp cạnh dài và diện tích. */
function fitSize(w, h, maxSide = MAX_SIDE, maxArea = MAX_AREA) {
	const s = Math.min(1, maxSide / Math.max(w, h), Math.sqrt(maxArea / (w * h)));
	return s >= 1 ? [w, h] : [Math.max(1, Math.round(w * s)), Math.max(1, Math.round(h * s))];
}
/** Giải mọi trang của tệp TIFF thành RGBA. `total` = số trang trong tệp (có thể > số trang trả về). */
function decodeTiffPages(buf, o = {}) {
	if (!isTiffBytes(new Uint8Array(buf, 0, Math.min(4, buf.byteLength)))) throw new Error("Không phải tệp TIFF");
	if (!TIFF_PAKO) throw new Error("Thiếu bộ giải nén");
	const ifds = import_UTIF.default.decode(buf).filter((ifd) => {
		const sub = ifd["t254"];
		return !(sub && sub[0] & 1) && ifd["t256"] && ifd["t257"];
	});
	if (!ifds.length) throw new Error("Tệp TIFF không có trang ảnh");
	const pages = [];
	for (const ifd of ifds.slice(0, o.maxPages ?? 100)) {
		import_UTIF.default.decodeImage(buf, ifd, ifds);
		const w = ifd.width, h = ifd.height;
		if (!w || !h) continue;
		let data = flattenOnWhite(import_UTIF.default.toRGBA8(ifd));
		const [tw, th] = fitSize(w, h, o.maxSide, o.maxArea);
		if (tw !== w || th !== h) data = downscaleRgba(data, w, h, tw, th);
		ifd.data = void 0;
		pages.push({
			width: tw,
			height: th,
			data
		});
	}
	if (!pages.length) throw new Error("Tệp TIFF không có trang ảnh");
	return {
		pages,
		total: ifds.length
	};
}
//#endregion
export { decodeTiffPages };
