import { r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { t as SCAN_ERRORS } from "./scan-errors-Bcd_8AUe.mjs";
import { r as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/errors-DKvrPJ4v.js
var errors_DKvrPJ4v_exports = /* @__PURE__ */ __exportAll({
	a: () => userMessage,
	i: () => showError,
	n: () => installGlobalErrorToasts,
	r: () => isVietnamese,
	t: () => errors_exports
});
var errors_exports = /* @__PURE__ */ __exportAll$1({
	GENERIC_ERROR: () => GENERIC_ERROR,
	friendlyError: () => friendlyError,
	installGlobalErrorToasts: () => installGlobalErrorToasts,
	isVietnamese: () => isVietnamese,
	showError: () => showError,
	userMessage: () => userMessage
});
/** FX-03: có chữ cái tiếng Việt có dấu → coi là thông điệp app đã viết cho người dùng. */
var VI_CHARS = /[ăâđêôơưàáạảãằắặẳẵầấậẩẫèéẹẻẽềếệểễìíịỉĩòóọỏõồốộổỗờớợởỡùúụủũừứựửữỳýỵỷỹ]/i;
var isVietnamese = (s) => VI_CHARS.test(s);
var GENERIC_ERROR = "Đã có lỗi xảy ra";
/** Chuyển lỗi kỹ thuật thành câu dễ hiểu + gợi ý cách xử lý. */
function friendlyError(e) {
	const name = e?.name ?? "";
	const msg = String(e?.message ?? e ?? "");
	if (name === "EncryptedPdf") return {
		title: "PDF có mật khẩu hoặc được mã hoá",
		hint: "Hãy mở khoá PDF trước, hoặc dùng công cụ “PDF → ảnh”."
	};
	if (name === "IdbWriteError") return {
		title: "Chưa lưu được vào bộ nhớ máy",
		hint: "Dữ liệu cũ vẫn giữ nguyên. Hãy thử lại; nếu vẫn lỗi, kiểm tra dung lượng trống."
	};
	if (name === "XlsxError") {
		const x = SCAN_ERRORS.XLSX_UNREADABLE;
		return {
			title: x.message.replace(/\.$/, ""),
			hint: x.hint
		};
	}
	if (name === "NotAllowedError" || /permission/i.test(msg)) return {
		title: "Chưa được cấp quyền",
		hint: "Mở cài đặt trình duyệt và cho phép camera/tệp cho trang này."
	};
	if (name === "NotFoundError" || /no camera|device not found/i.test(msg)) return {
		title: "Không tìm thấy camera",
		hint: "Dùng nút Nhập ảnh để chọn ảnh có sẵn."
	};
	if (name === "NotReadableError") return {
		title: "Camera đang bận",
		hint: "Đóng ứng dụng khác đang dùng camera rồi thử lại."
	};
	if (name === "QuotaExceededError" || /quota/i.test(msg)) return {
		title: "Bộ nhớ máy đã đầy",
		hint: "Xoá bớt tài liệu hoặc sao lưu ra tệp rồi xoá."
	};
	if (/hết lượt ai/i.test(msg)) return {
		title: "Đã hết lượt AI trong giờ này",
		hint: "Thử lại sau ít phút. Quét, cắt, xuất PDF vẫn dùng bình thường."
	};
	if (name === "OcrUnavailableError" || /importscripts|traineddata|failed to load/i.test(msg)) return {
		title: "Chưa tải được gói nhận chữ",
		hint: "Lần đầu cần mạng. Khi có mạng, vào Tôi → “Tải sẵn để mở app & nhận chữ khi mất mạng”, rồi thử lại."
	};
	if (isVietnamese(msg) && msg.length <= 240) return {
		title: msg.trim().replace(/\.$/, ""),
		hint: "Thử lại. Nếu vẫn lỗi, tải lại trang."
	};
	if (/network|fetch|load failed/i.test(msg)) return {
		title: "Mất kết nối mạng",
		hint: "Nhận chữ lần đầu cần mạng để tải dữ liệu ngôn ngữ. Kiểm tra mạng và thử lại."
	};
	if (/decode|image|corrupt/i.test(msg)) return {
		title: "Không đọc được ảnh",
		hint: "Tệp có thể bị hỏng hoặc không phải ảnh. Thử tệp khác."
	};
	if (/json/i.test(msg)) return {
		title: "Tệp không đúng định dạng",
		hint: "Hãy chọn tệp sao lưu tạo từ Ghi Nhanh."
	};
	return {
		title: GENERIC_ERROR,
		hint: "Thử lại. Nếu vẫn lỗi, tải lại trang."
	};
}
/**
* FX-03: MỘT cửa cho câu lỗi hiện lên giao diện — thay mẫu `e instanceof Error ? e.message : "…"`
* (in nguyên "Failed to fetch", "toBlob"… của trình duyệt/thư viện). Luôn trả tiếng Việt:
* thông điệp tiếng Việt của app giữ nguyên; lỗi kỹ thuật đã biết → câu dễ hiểu; còn lại → `fallback`.
*/
function userMessage(e, fallback) {
	const msg = String(e?.message ?? (typeof e === "string" ? e : "")).trim();
	if (msg && isVietnamese(msg) && msg.length <= 240) return msg;
	if (msg) console.warn("[FX-03] lỗi kỹ thuật:", msg);
	const f = friendlyError(e);
	return f.title === "Đã có lỗi xảy ra" ? fallback : f.title;
}
function showError(e, context) {
	console.error(e);
	const f = friendlyError(e);
	toast.error(context ? `${context}: ${f.title}` : f.title, { description: f.hint });
}
/** Bắt mọi lỗi chưa xử lý và hiện thông báo dễ hiểu. */
function installGlobalErrorToasts() {
	const onRej = (ev) => {
		if (ev.reason?.name === "AbortError") return;
		showError(ev.reason);
	};
	window.addEventListener("unhandledrejection", onRej);
	return () => window.removeEventListener("unhandledrejection", onRej);
}
//#endregion
export { userMessage as a, showError as i, installGlobalErrorToasts as n, isVietnamese as r, errors_DKvrPJ4v_exports as t };
