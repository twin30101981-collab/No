//#region node_modules/.nitro/vite/services/ssr/assets/user-recipe-DhO7F1JT.js
var KEY = "ghi-nhanh:user-recipes";
/** Cần ít nhất N lần chọn tay cùng một bộ lọc mới tin là sở thích. */
var MIN_PICKS = 1;
/** Ghi một lựa chọn tay (bất biến). Bỏ qua loại rỗng. */
function recordChoice(all, docKind, filter) {
	if (!docKind) return all;
	const forKind = all[docKind] ?? {};
	return {
		...all,
		[docKind]: {
			...forKind,
			[filter]: (forKind[filter] ?? 0) + 1
		}
	};
}
/** Bộ lọc người dùng hay chọn nhất cho loại này (≥ MIN_PICKS lần); hoà → không ưu tiên. */
function preferredFilter(all, docKind) {
	if (!docKind) return null;
	const forKind = all[docKind];
	if (!forKind) return null;
	let best = null;
	let bestN = 0;
	let tie = false;
	for (const [f, n] of Object.entries(forKind)) if (n > bestN) {
		best = f;
		bestN = n;
		tie = false;
	} else if (n === bestN) tie = true;
	return best && !tie && bestN >= 1 ? best : null;
}
function loadChoices() {
	try {
		const raw = globalThis.localStorage?.getItem(KEY);
		if (!raw) return {};
		const v = JSON.parse(raw);
		return v && typeof v === "object" && !Array.isArray(v) ? v : {};
	} catch {
		return {};
	}
}
function saveChoices(all) {
	try {
		globalThis.localStorage?.setItem(KEY, JSON.stringify(all));
	} catch {}
}
/** Ghi một lựa chọn tay vào kho (đọc → cộng → lưu). */
function learnChoice(docKind, filter) {
	saveChoices(recordChoice(loadChoices(), docKind, filter));
}
//#endregion
export { MIN_PICKS, learnChoice, loadChoices, preferredFilter, recordChoice, saveChoices };
