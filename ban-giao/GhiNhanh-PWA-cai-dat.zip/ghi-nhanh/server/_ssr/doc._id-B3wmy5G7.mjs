import { o as __toESM } from "../_runtime.mjs";
import { n as init_performance, r as performance_default } from "../_libs/canvg+[...].mjs";
import { T as useNavigate, _ as useBlocker, w as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as createSsrRpc } from "./createSsrRpc-CVjuB6nW.mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CwccI41b.mjs";
import { i as getVaultKey } from "./vault-CuGqX6h0.mjs";
import { isSensitiveDoc, n as summarize, setAiSensitivity, t as findSensitive } from "./ai-sensitivity-GdXzjggN.mjs";
import { a as guardImage, o as imageVersion, r as diagFallback, s as matchesVersion, t as DIAG_LABEL } from "./scan-diagnose-HshWtdyP.mjs";
import { i as stringType, n as enumType, r as objectType } from "../_libs/zod.mjs";
import { a as aiLayout, d as aiScanDiagnose, n as aiDocAsk, p as aiText, r as aiExtract } from "./ai.functions-CpS7iAgj.mjs";
import { n as classifyAiFailure, r as isAutoRetryable, t as SCAN_ERRORS } from "./scan-errors-Bcd_8AUe.mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { a as userMessage, i as showError } from "./errors-DKvrPJ4v.mjs";
import { f as useUser } from "./auth-BEi9IFUJ.mjs";
import { $ as Link2, C as SlidersHorizontal, Ct as FileText, Ft as EllipsisVertical, Gt as CircleQuestionMark, It as Download, J as Lock, K as Monitor, M as RotateCw, Mt as EyeOff, N as RotateCcw, O as ScanText, P as RefreshCw, Pt as Eraser, Qt as Brush, Rt as Crop, S as Smartphone, T as Send, U as PenLine, Ut as ClipboardPaste, X as LoaderCircle, Xt as Check, Y as LockOpen, Zt as Camera, b as Sparkles, bt as FolderDown, d as TriangleAlert, f as Trash2, ft as Hand, gt as Folder, it as Languages, jt as Eye, k as ScanSearch, kt as FileDown, l as Undo2, m as Tags, nn as ArrowLeft, o as WandSparkles, ot as ImagePlus, pt as GripVertical, r as X, rn as ArrowDown, rt as Laptop, tn as ArrowUp, tt as LayoutGrid, u as Type, w as Share2, wt as FileSpreadsheet, z as Plus, zt as Copy } from "../_libs/lucide-react.mjs";
import { c as srcBytes$1 } from "./disk-pack-ZdDKsocx.mjs";
import { c as unlocked, l as useLockTick, n as getSettings, r as hashPin, t as getPinSalt, u as useSettings } from "./settings-DDlMLZCe.mjs";
import { D as useDocs, c as getDocs, d as mutateDoc, g as pageBadge, i as deleteDocs, o as docText, t as FILTER_LABEL, v as pendingPageCount } from "./db-CclUQaLE.mjs";
import { d as getLibrary, s as createFolder, u as ensureTag } from "./library-BIMZUn1d.mjs";
import { t as useServerFn } from "./useServerFn-CrZF2pjq.mjs";
import { i as useQueuedServerFn, n as reportAiResult } from "./ai-queue-DZjZmUCT.mjs";
import { i as downloadBaseline, l as slowWarningText, o as readBaseline, s as readPerf, u as slowWarnings } from "./perf-stats-C5jrVSN8.mjs";
import { i as newScanSession, r as logScan } from "./scan-log-DnWLrMlu.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { A as loadImg, F as releaseRenderCache, I as renderPage, K as stamp, M as normalizeFilter, R as renderPreview, S as enhanceForOcr, W as smallGray, Y as toJpeg, a as TOOL_LABEL, d as curveAt, i as TOOL_KEYS, l as compress, o as buildPageCurve, s as clampLevel, t as LEVEL_LABEL, w as fileToDataUrl, x as edgeCurves, y as detectTextLines } from "./image-DFWRNlNd.mjs";
import { i as healPending, n as bgQueue } from "./runner-CZAn6hg6.mjs";
import { S as shareOrDownload, _ as readyDocs, a as compressPage, c as download, f as pageNumberText, i as canvasToTempUrl, n as PDF_SIZES, o as dataUrlToBlob, r as canvasToPageUrl, s as docToPdf, t as NUMBER_STYLES, u as imagesToPdf, x as safeName, y as revokeTemp } from "./files-CTF11Arr.mjs";
import { n as confirmDialog, r as pinDialog } from "./dialog-IcUxZaUZ.mjs";
import { a as IMAGE_ACCEPT, d as readClipboardImages, f as needsCornerHint, i as FILE_ACCEPT, l as isEditingText, n as pickFiles, t as filesToPages, u as isImageFile } from "./importer-BUHDogNt.mjs";
import { a as recognize, o as recognizeWordBoxes, s as recognizeWords, t as classify } from "./ocr-CLa2avjZ.mjs";
import { t as Input } from "./input-T4LKa1EA.mjs";
import { n as checkTemplateFields, o as templateByType, t as VN_TEMPLATES } from "./vn-templates-Br-nZelc.mjs";
import { a as uploadAll } from "./cloud-sync-DGtKTTqz.mjs";
import { i as zip, t as rowsToXlsx } from "./xlsx-CvpeQh6I.mjs";
import { n as checkQuality } from "./quality-B8m69IKS.mjs";
import { n as suggestFilter, t as shouldSuggest } from "./filter-suggest-C3Br7JC3.mjs";
import { a as decisionNote, c as needsReview, i as applyEditToPages, l as reviewReason, n as TAB_LABEL, o as filterPages, r as applyEditQueued, s as markChecked, u as reviewTargets } from "./batch-review-Be3azLyj.mjs";
import { postCaptureWithMetrics } from "./post-capture-metrics-X7ExzflM.mjs";
import { processImported } from "./import-pipeline-B6K4tiBD.mjs";
import { i as useOcrJobs, n as ocrQueue, t as firstOcrFailure } from "./ocr-queue-Dg31Dfup.mjs";
import { t as aiUnavailable } from "./offline-extract-CYJH6W2G.mjs";
import { PDF_PAPER_LABEL } from "./pdf-page-11Gerqi0.mjs";
import { f as registerSource } from "./history-ZPjFrOJG.mjs";
import { r as checkPassword, s as linkStatus, t as EXPIRY_OPTIONS, u as shareUrl } from "./share-links-s-_jx_4k.mjs";
import { i as tryShare, n as offerTap, t as canShareThisFile } from "./share-C6NDb_Ds.mjs";
import { t as Route } from "./doc._id-P7iptWfN.mjs";
import { r as usePreview, t as inPreviewWindow } from "./preview-src-DrbqV_z6.mjs";
import { n as usePageThumb } from "./thumbs-Bxe3hgYK.mjs";
import { a as TagPicker, i as TagChip, r as FolderPicker } from "./library-ui-BCoN_d8a.mjs";
import { _ as useFindQuad, a as canRedo, c as clampPan, d as isDirty, f as redo, g as undo, h as startSession, i as boxFromOcrWord, l as edgeCutCheck, m as saveSession, n as actualScale, o as canUndo, p as resetSession, r as applyEdit, s as centerOn, t as CropEditor, u as fitScale } from "./crop-editor-CWKLJmf0.mjs";
import { a as newRoomCode, i as joinRoom, o as pairUrl, s as remaining, t as Assembler } from "./pair-DrmeGriq.mjs";
import { t as useImagePaste } from "./use-image-paste-FdMZgoID.mjs";
import { a as refundQuotaSlot, c as splitCitations, i as loadHistory, l as takeQuotaSlot, n as driveReady, o as saveHistory, r as getQuota, s as saveToDrive, t as clearHistory } from "./drive-B45FnGmw.mjs";
import { t as imagesToWord } from "./word-DdGqJXaY.mjs";
import { a as savedFolder, i as forgetFolder, n as folderForSave, o as writeToFolder, r as folderSupported, t as folderError } from "./save-folder-C_BrHL5X.mjs";
import { t as ExportReview } from "./export-review-DWV3zMTm.mjs";
import { n as revokeShareLink } from "./share-view.functions-Z0Oopxol.mjs";
import { t as Slider } from "./slider-BjtFJp27.mjs";
import { t as require_lib } from "../_libs/qrcode.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/doc._id-B3wmy5G7.js
init_performance();
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_lib = /* @__PURE__ */ __toESM(require_lib());
var clamp = (i, n) => n <= 0 ? 0 : Math.max(0, Math.min(n - 1, i));
/** Dời trang `from` tới vị trí `to`; trang đang xem đi theo đúng trang đó. */
function movePage(pages, from, to, active) {
	const n = pages.length;
	if (from < 0 || from >= n) return {
		pages,
		active: clamp(active, n)
	};
	const t = clamp(to, n);
	if (t === from) return {
		pages,
		active: clamp(active, n)
	};
	const ps = [...pages];
	const [x] = ps.splice(from, 1);
	ps.splice(t, 0, x);
	let a = active;
	if (active === from) a = t;
	else if (from < active && t >= active) a = active - 1;
	else if (from > active && t <= active) a = active + 1;
	return {
		pages: ps,
		active: clamp(a, n)
	};
}
/** Xóa trang `i`; giữ trang đang xem (hoặc trang liền kề). */
function removePage(pages, i, active) {
	if (i < 0 || i >= pages.length) return {
		pages,
		active: clamp(active, pages.length)
	};
	const ps = pages.filter((_, k) => k !== i);
	return {
		pages: ps,
		active: clamp(i < active ? active - 1 : active, ps.length)
	};
}
/** Chèn trang mới ngay sau `after` (‑1 = đầu); trang đang xem chuyển tới trang mới đầu tiên. */
function insertPages(pages, added, after) {
	if (!added.length) return {
		pages,
		active: clamp(after, pages.length)
	};
	const at = Math.max(0, Math.min(pages.length, after + 1));
	return {
		pages: [
			...pages.slice(0, at),
			...added,
			...pages.slice(at)
		],
		active: at
	};
}
/** Nhân bản trang `i` (cần hàm tạo id mới), đặt ngay sau bản gốc. */
function duplicatePage(pages, i, clone) {
	if (i < 0 || i >= pages.length) return {
		pages,
		active: clamp(i, pages.length)
	};
	return insertPages(pages, [clone(pages[i])], i);
}
/** Bật/tắt một id trong tập chọn. */
function toggleId(sel, id) {
	return sel.includes(id) ? sel.filter((x) => x !== id) : [...sel, id];
}
/** Xoá mọi trang có id trong tập; giữ trang đang xem hợp lệ. */
function removePages(pages, ids, active) {
	if (!ids.size) return {
		pages,
		active: clamp(active, pages.length)
	};
	const ps = pages.filter((p) => !ids.has(p.id));
	const removedBefore = pages.slice(0, active).filter((p) => ids.has(p.id)).length;
	return {
		pages: ps,
		active: clamp(active - removedBefore, ps.length)
	};
}
/** Nhân bản mọi trang có id trong tập (theo thứ tự hiện tại), đặt sau bản gốc. */
function duplicatePages(pages, ids, clone, active) {
	if (!ids.size) return {
		pages,
		active: clamp(active, pages.length)
	};
	const ps = [];
	for (const p of pages) {
		ps.push(p);
		if (ids.has(p.id)) ps.push(clone(p));
	}
	const addedBefore = pages.slice(0, active).filter((p) => ids.has(p.id)).length;
	return {
		pages: ps,
		active: clamp(active + addedBefore, ps.length)
	};
}
/** Phần trăm tiến độ 0–100; total 0 → 100 (không còn việc). */
function progressPct(pending, total) {
	if (total <= 0) return 100;
	const done = Math.max(0, total - Math.max(0, pending));
	return Math.round(done / total * 100);
}
function changedFields(b, m) {
	const out = {};
	const keys = /* @__PURE__ */ new Set([...Object.keys(b), ...Object.keys(m)]);
	for (const k of keys) if (b[k] !== m[k]) out[k] = m[k];
	return out;
}
function rebasePages(base, mine, latest) {
	if (base === latest) return mine;
	const baseById = new Map(base.map((p) => [p.id, p]));
	const latestById = new Map(latest.map((p) => [p.id, p]));
	const out = [];
	for (const m of mine) {
		const b = baseById.get(m.id);
		const l = latestById.get(m.id);
		if (!b) {
			out.push(m);
			continue;
		}
		if (!l) continue;
		if (b === m) {
			out.push(l);
			continue;
		}
		if (l === b) {
			out.push(m);
			continue;
		}
		const diff = changedFields(b, m);
		const merged = {
			...l,
			...diff
		};
		for (const k of Object.keys(diff)) if (diff[k] === void 0) delete merged[k];
		out.push(merged);
	}
	const seen = new Set(out.map((p) => p.id));
	for (const l of latest) if (!baseById.has(l.id) && !seen.has(l.id)) out.push(l);
	return out;
}
/** Thang chuẩn hoá cho từng chỉ số (chênh bằng thang = khoảng cách 1). */
var SCALE = {
	blur: 40,
	glare: .05,
	skew: 6,
	brightness: 60,
	contrast: 30
};
var WEIGHT = {
	blur: .2,
	glare: .2,
	skew: .1,
	brightness: .3,
	contrast: .2
};
var SIMILAR_THRESHOLD = .35;
function pageDistance(a, b) {
	let s = 0;
	for (const k of Object.keys(SCALE)) {
		const d = (k === "skew" ? Math.abs(a[k]) - Math.abs(b[k]) : a[k] - b[k]) / SCALE[k];
		s += WEIGHT[k] * Math.min(1, d * d);
	}
	return Math.sqrt(s);
}
/** Trang tương tự trang nguồn (không gồm chính nó), gần nhất trước. Thiếu số đo → bỏ qua. */
function findSimilar(sourceId, metrics, threshold = SIMILAR_THRESHOLD) {
	const src = metrics.get(sourceId);
	if (!src) return [];
	const out = [];
	for (const [id, m] of metrics) {
		if (id === sourceId) continue;
		const distance = pageDistance(src, m);
		if (distance <= threshold) out.push({
			pageId: id,
			distance
		});
	}
	return out.sort((x, y) => x.distance - y.distance);
}
function BatchReview({ doc, reviews, onSavePage, onClose, onOpenPage }) {
	const [ids] = (0, import_react.useState)(() => reviewTargets(doc.pages, reviews).map((i) => doc.pages[i].id));
	const [pos, setPos] = (0, import_react.useState)(0);
	const [done, setDone] = (0, import_react.useState)({});
	const [crop, setCrop] = (0, import_react.useState)(false);
	const page = (0, import_react.useMemo)(() => doc.pages.find((p) => p.id === ids[pos]), [
		doc.pages,
		ids,
		pos
	]);
	const index = page ? doc.pages.indexOf(page) : -1;
	const left = ids.filter((id) => !done[id]).length;
	const next = () => {
		const after = ids.findIndex((id, k) => k > pos && !done[id]);
		const any = after >= 0 ? after : ids.findIndex((id, k) => k !== pos && !done[id]);
		if (any < 0) {
			toast.success("Đã xem lại xong các trang");
			onClose();
			return;
		}
		setPos(any);
	};
	if (!ids.length || !page) return null;
	const keep = async () => {
		setDone((d) => ({
			...d,
			[page.id]: "giu"
		}));
		await onSavePage(markChecked(page), false);
		next();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Xem lại theo lô",
		className: "fixed inset-0 z-50 flex flex-col bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-2 border-b border-border px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-sm font-semibold",
						children: [
							"Xem lại ",
							pos + 1,
							"/",
							ids.length,
							" · trang ",
							index + 1
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						"data-testid": "review-left",
						children: left ? `Còn ${left} trang cần xem` : "Đã xem hết"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "glass",
					size: "sm",
					onClick: onClose,
					children: "Đóng"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 flex-col items-center gap-3 overflow-auto p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: page.src,
					alt: `Trang ${index + 1}`,
					className: "max-h-[56dvh] max-w-full rounded-lg object-contain shadow"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-md text-center text-sm",
					"data-testid": "review-reason",
					children: done[page.id] === "sua" ? "Đã sửa khung — ảnh đầy đủ đang được dựng ở nền." : reviewReason(page, reviews[page.id]) || "Trang này ổn."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "grid grid-cols-3 gap-2 border-t border-border p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "glass",
						onClick: () => setCrop(true),
						children: "Sửa khung"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "glass",
						onClick: () => void keep(),
						children: "Giữ nguyên"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: next,
						children: "Trang kế"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "col-span-3 py-1 text-xs text-muted-foreground underline",
						onClick: () => {
							onClose();
							onOpenPage(index);
						},
						children: "Mở trang này để chỉnh đầy đủ (lọc, xoay…)"
					})
				]
			}),
			crop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CropEditor, {
				src: page.orig,
				quad: page.edit.quad,
				paper: page.edit.paper,
				onClose: () => setCrop(false),
				onApply: (quad, paper) => {
					setCrop(false);
					setDone((d) => ({
						...d,
						[page.id]: "sua"
					}));
					onSavePage(applyEditQueued(page, {
						quad,
						paper
					}), true);
					next();
				}
			})
		]
	});
}
/** Two drag points (any order, any bounds) → clamped fractional rect. */
function rectFromPoints(a, b) {
	const c = (v) => Math.min(1, Math.max(0, v));
	const x0 = c(Math.min(a.x, b.x)), x1 = c(Math.max(a.x, b.x));
	const y0 = c(Math.min(a.y, b.y)), y1 = c(Math.max(a.y, b.y));
	return {
		x: x0,
		y: y0,
		w: x1 - x0,
		h: y1 - y0
	};
}
/** Too small to hold readable text (under ~2% of a side). */
var tooSmall = (r) => r.w < .02 || r.h < .02;
/** Fractional rect → pixel box, with a little padding so edge letters are not cut. */
function regionPixels(r, W, H, pad = .01) {
	const x = Math.max(0, Math.floor((r.x - pad) * W)), y = Math.max(0, Math.floor((r.y - pad) * H));
	const x1 = Math.min(W, Math.ceil((r.x + r.w + pad) * W)), y1 = Math.min(H, Math.ceil((r.y + r.h + pad) * H));
	return {
		x,
		y,
		w: x1 - x,
		h: y1 - y
	};
}
/** Crop the region, upscaling small crops so OCR sees letters at a useful size. */
async function cropRegion(src, r) {
	const img = await loadImg(src);
	const b = regionPixels(r, img.naturalWidth, img.naturalHeight);
	const s = Math.min(3, Math.max(1, 1200 / Math.max(b.w, b.h)));
	const c = document.createElement("canvas");
	c.width = Math.round(b.w * s);
	c.height = Math.round(b.h * s);
	const ctx = c.getContext("2d");
	ctx.imageSmoothingQuality = "high";
	ctx.drawImage(img, b.x, b.y, b.w, b.h, 0, 0, c.width, c.height);
	return toJpeg(c, .95);
}
/** Full-screen: drag a box on the page, read text only inside it. */
function RegionOcr({ src, onClose, onAppend }) {
	const box = (0, import_react.useRef)(null);
	const start = (0, import_react.useRef)(null);
	const [r, setR] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [text, setText] = (0, import_react.useState)(null);
	const pt = (e) => {
		const b = box.current.getBoundingClientRect();
		return {
			x: (e.clientX - b.left) / b.width,
			y: (e.clientY - b.top) / b.height
		};
	};
	const read = async () => {
		if (!r || tooSmall(r)) {
			toast("Kéo một khung bao quanh đoạn chữ cần đọc");
			return;
		}
		setBusy(true);
		try {
			const t = await recognize(await cropRegion(src, r));
			setText(t);
			if (!t) toast("Không thấy chữ trong vùng này — thử khung rộng hơn");
		} catch (e) {
			showError(e, "Nhận chữ vùng chọn");
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex flex-col bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between gap-2 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "glass",
						size: "icon",
						"aria-label": "Đóng",
						onClick: onClose,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold",
						children: "Kéo khung quanh đoạn chữ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-10" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex min-h-0 flex-1 items-center justify-center p-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: box,
					className: "relative max-h-full touch-none select-none",
					onPointerDown: (e) => {
						e.target.setPointerCapture?.(e.pointerId);
						start.current = pt(e);
						setR(null);
						setText(null);
					},
					onPointerMove: (e) => {
						if (start.current) setR(rectFromPoints(start.current, pt(e)));
					},
					onPointerUp: () => {
						start.current = null;
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src,
						alt: "Trang tài liệu",
						draggable: false,
						className: "block max-h-[60dvh] w-auto rounded-md"
					}), r && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pointer-events-none absolute rounded-sm border-2 border-primary bg-primary/15",
						style: {
							left: `${r.x * 100}%`,
							top: `${r.y * 100}%`,
							width: `${r.w * 100}%`,
							height: `${r.h * 100}%`
						}
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 p-3 pb-[calc(env(safe-area-inset-bottom)+0.75rem)]",
				children: [text != null && text !== "" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: text,
					onChange: (e) => setText(e.target.value),
					className: "h-28 w-full rounded-[12px] border border-border bg-card p-3 text-sm leading-6 outline-none focus:ring-2 focus:ring-ring"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "glass",
						onClick: () => {
							navigator.clipboard.writeText(text);
							toast("Đã sao chép");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), " Sao chép"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "glass",
						onClick: () => {
							onAppend(text);
							toast.success("Đã thêm vào chữ của trang");
						},
						children: "Thêm vào trang"
					})]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					className: "w-full",
					disabled: busy || !r,
					onClick: () => void read(),
					children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanText, {}), " Đọc chữ trong khung"]
				})]
			})
		]
	});
}
/** Fill boxes with solid black, alpha 255 (pure, in place). Nothing of the original survives inside a box. */
function redactPixels(d, w, h, regions) {
	for (const r of regions) {
		const b = regionPixels(r, w, h, 0);
		for (let y = b.y; y < b.y + b.h; y++) for (let x = b.x; x < b.x + b.w; x++) {
			const i = (y * w + x) * 4;
			d[i] = 0;
			d[i + 1] = 0;
			d[i + 2] = 0;
			d[i + 3] = 255;
		}
	}
	return d;
}
/** Burn black boxes into the page pixels (not an overlay) and re-encode, so the hidden content cannot be recovered. */
async function applyRedactions(src, regions) {
	const img = await loadImg(src);
	const c = document.createElement("canvas");
	c.width = img.naturalWidth;
	c.height = img.naturalHeight;
	const ctx = c.getContext("2d", { willReadFrequently: true });
	ctx.drawImage(img, 0, 0);
	const data = ctx.getImageData(0, 0, c.width, c.height);
	redactPixels(data.data, c.width, c.height, regions);
	ctx.putImageData(data, 0, 0);
	return canvasToPageUrl(c, "image/jpeg", .92);
}
/** Drag black boxes over sensitive info; on save they are burned into the image for good. */
function RedactEditor({ src, onClose, onApply }) {
	const box = (0, import_react.useRef)(null);
	const start = (0, import_react.useRef)(null);
	const [boxes, setBoxes] = (0, import_react.useState)([]);
	const [cur, setCur] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [finding, setFinding] = (0, import_react.useState)(false);
	const pt = (e) => {
		const b = box.current.getBoundingClientRect();
		return {
			x: (e.clientX - b.left) / b.width,
			y: (e.clientY - b.top) / b.height
		};
	};
	const all = cur ? [...boxes, cur] : boxes;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "scan-screen fixed inset-0 z-50 mx-auto flex max-w-[430px] flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-3 pt-[max(0.75rem,env(safe-area-inset-top))] pb-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: "scan-icon",
						onClick: onClose,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}), " Hủy"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm font-semibold",
						children: "Che thông tin"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: "scan-icon",
						disabled: !boxes.length,
						onClick: () => setBoxes((b) => b.slice(0, -1)),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, {}), " Hoàn tác"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid min-h-0 flex-1 place-items-center p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: box,
					className: "relative touch-none select-none",
					onPointerDown: (e) => {
						e.target.setPointerCapture?.(e.pointerId);
						start.current = pt(e);
					},
					onPointerMove: (e) => {
						if (start.current) setCur(rectFromPoints(start.current, pt(e)));
					},
					onPointerUp: () => {
						start.current = null;
						if (cur && !tooSmall(cur)) setBoxes((b) => [...b, cur]);
						setCur(null);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src,
						alt: "Trang",
						draggable: false,
						className: "block max-h-[62dvh] max-w-full"
					}), all.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pointer-events-none absolute bg-foreground",
						style: {
							left: `${r.x * 100}%`,
							top: `${r.y * 100}%`,
							width: `${r.w * 100}%`,
							height: `${r.h * 100}%`
						}
					}, i))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs opacity-80",
						children: "Kéo khung lên số CCCD, số tài khoản, địa chỉ… Khối đen được in hẳn vào ảnh, không gỡ ra được."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "glass",
						className: "mb-2 w-full",
						disabled: finding || busy,
						onClick: async () => {
							setFinding(true);
							try {
								const [{ words }, img] = await Promise.all([recognizeWords(src), loadImg(src)]);
								const found = findSensitive(words, img.naturalWidth, img.naturalHeight);
								if (!found.length) {
									toast("Không thấy số CCCD, điện thoại hay tài khoản — kéo khung thủ công nếu cần");
									return;
								}
								setBoxes((b) => [...b, ...found.map((f) => f.region)]);
								toast.success(`Đã đánh dấu ${summarize(found)} — kiểm tra lại rồi bấm Che`);
							} catch (e) {
								showError(e, "Tự tìm thông tin nhạy cảm");
							} finally {
								setFinding(false);
							}
						},
						children: [
							finding ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WandSparkles, {}),
							" ",
							finding ? "Đang đọc trang…" : "Tự tìm số CCCD, điện thoại, tài khoản"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "w-full",
						disabled: !boxes.length || busy,
						onClick: async () => {
							if (!await confirmDialog(`Che vĩnh viễn ${boxes.length} vùng?`, {
								message: "Ảnh gốc của trang cũng bị thay; chữ đã nhận của trang sẽ được xóa để không lộ thông tin.",
								okText: "Che",
								danger: true
							})) return;
							setBusy(true);
							try {
								await onApply(await applyRedactions(src, boxes));
								toast.success("Đã che thông tin");
							} catch (e) {
								showError(e, "Che thông tin");
							} finally {
								setBusy(false);
							}
						},
						children: [
							busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : null,
							" Che ",
							boxes.length ? `${boxes.length} vùng` : ""
						]
					})
				]
			})
		]
	});
}
function ycc(r, g, b) {
	return [
		.299 * r + .587 * g + .114 * b,
		-.1687 * r - .3313 * g + .5 * b,
		.5 * r - .4187 * g - .0813 * b
	];
}
function median(a) {
	if (!a.length) return 0;
	a.sort((x, y) => x - y);
	return a[a.length >> 1];
}
function estimatePaper(d) {
	const n = d.length >> 2, step = Math.max(1, Math.floor(n / 2e4));
	const ys = [];
	for (let p = 0; p < n; p += step) {
		const i = p * 4;
		ys.push(.299 * d[i] + .587 * d[i + 1] + .114 * d[i + 2]);
	}
	const cut = median(ys.slice()) - 10;
	const Y = [], Cb = [], Cr = [];
	for (let p = 0; p < n; p += step) {
		const i = p * 4, c = ycc(d[i], d[i + 1], d[i + 2]);
		if (c[0] >= cut) {
			Y.push(c[0]);
			Cb.push(c[1]);
			Cr.push(c[2]);
		}
	}
	return {
		y: median(Y),
		cb: median(Cb),
		cr: median(Cr)
	};
}
function hueOf(cb, cr) {
	const a = Math.atan2(cr, cb) * 180 / Math.PI;
	if (a > -45 && a <= 45) return "blue";
	if (a > 45 && a <= 75) return "purple";
	if (a > 75 || a <= -150) return "red";
	return "green";
}
function classifyInk(img, o = {}) {
	const { inkDelta = 40, chromaMin = 18, hues = [
		"blue",
		"red",
		"purple"
	] } = o;
	const d = img.data, n = img.width * img.height, paper = estimatePaper(d);
	const mask = new Uint8Array(n);
	let hand = 0, print = 0;
	for (let p = 0; p < n; p++) {
		const i = p * 4, [y, cb, cr] = ycc(d[i], d[i + 1], d[i + 2]);
		const dcb = cb - paper.cb, dcr = cr - paper.cr;
		if (Math.hypot(dcb, dcr) >= chromaMin && paper.y - y > inkDelta * .4 && hues.includes(hueOf(dcb, dcr))) {
			mask[p] = 2;
			hand++;
		} else if (paper.y - y > inkDelta) {
			mask[p] = 1;
			print++;
		}
	}
	return {
		mask,
		paper,
		handShare: hand / n,
		printShare: print / n
	};
}
/** Nở mặt nạ viết tay 1 điểm để xóa cả viền nhòe quanh nét. */
function dilateHand(mask, w, h, r = 1) {
	const out = mask.slice();
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		if (mask[y * w + x] !== 2) continue;
		for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
			const yy = y + dy, xx = x + dx;
			if (yy >= 0 && yy < h && xx >= 0 && xx < w && mask[yy * w + xx] === 0) out[yy * w + xx] = 2;
		}
	}
	return out;
}
/**
* G4-09 — Xóa viết tay, bước 2: lọc theo độ dày nét, tạo bản đề sạch.
*
* Nét mực (kể cả mực đen) được tách thành từng mảng liền. Độ dày nét mỗi mảng =
* 2 × khoảng cách lớn nhất từ trong nét ra giấy (biến đổi khoảng cách chessboard).
* Độ dày "chữ in" là trung vị có trọng số diện tích; mảng nào lệch quá tỉ lệ cho phép
* (bút bi mảnh hơn, bút dạ dày hơn) được coi là viết tay. `cleanSheet` gộp cả lọc màu
* (G4-08) và lọc độ dày để tạo bản đề sạch.
*/
/** Khoảng cách từ mỗi điểm mực tới giấy gần nhất (hai lượt, 8 hướng). */
function distanceMap(ink, w, h) {
	const D = new Uint16Array(w * h), BIG = 65535;
	for (let p = 0; p < w * h; p++) D[p] = ink[p] ? BIG : 0;
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		const p = y * w + x;
		if (!D[p]) continue;
		let m = D[p];
		if (x > 0) m = Math.min(m, D[p - 1] + 1);
		else m = 1;
		if (y > 0) {
			m = Math.min(m, D[p - w] + 1);
			if (x > 0) m = Math.min(m, D[p - w - 1] + 1);
			if (x < w - 1) m = Math.min(m, D[p - w + 1] + 1);
		} else m = 1;
		D[p] = m;
	}
	for (let y = h - 1; y >= 0; y--) for (let x = w - 1; x >= 0; x--) {
		const p = y * w + x;
		if (!D[p]) continue;
		let m = D[p];
		if (x < w - 1) m = Math.min(m, D[p + 1] + 1);
		else m = 1;
		if (y < h - 1) {
			m = Math.min(m, D[p + w] + 1);
			if (x < w - 1) m = Math.min(m, D[p + w + 1] + 1);
			if (x > 0) m = Math.min(m, D[p + w - 1] + 1);
		} else m = 1;
		D[p] = m;
	}
	return D;
}
/** Gán nhãn mảng liền (8 hướng) và đo độ dày nét từng mảng. */
function measureStrokes(ink, w, h) {
	const D = distanceMap(ink, w, h), label = new Int32Array(w * h).fill(-1);
	const strokes = [], stack = [];
	for (let s = 0; s < w * h; s++) {
		if (!ink[s] || label[s] >= 0) continue;
		const id = strokes.length;
		let area = 0, maxD = 0;
		label[s] = id;
		stack.push(s);
		while (stack.length) {
			const p = stack.pop(), x = p % w, y = (p - x) / w;
			area++;
			if (D[p] > maxD) maxD = D[p];
			for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
				const xx = x + dx, yy = y + dy;
				if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
				const q = yy * w + xx;
				if (ink[q] && label[q] < 0) {
					label[q] = id;
					stack.push(q);
				}
			}
		}
		strokes.push({
			id,
			area,
			width: 2 * maxD - 1
		});
	}
	return {
		label,
		strokes
	};
}
/** Độ dày nét chủ đạo (trung vị theo diện tích, bỏ chấm nhỏ < minArea). */
function dominantWidth(strokes, minArea = 6) {
	const s = strokes.filter((k) => k.area >= minArea).sort((a, b) => a.width - b.width);
	const total = s.reduce((t, k) => t + k.area, 0);
	let acc = 0;
	for (const k of s) {
		acc += k.area;
		if (acc >= total / 2) return k.width;
	}
	return 0;
}
/** Mặt nạ 1 = mảng nét có độ dày lệch khỏi chữ in (coi là viết tay). */
function oddWidthMask(ink, w, h, o = {}) {
	const { tolerance = 1.6, minArea = 6 } = o;
	const { label, strokes } = measureStrokes(ink, w, h);
	const ref = o.refWidth ?? dominantWidth(strokes, minArea);
	const odd = new Uint8Array(strokes.length);
	if (ref > 0) for (const k of strokes) {
		if (k.area < minArea) continue;
		const r = k.width / ref;
		if (r > tolerance || r < 1 / tolerance) odd[k.id] = 1;
	}
	const out = new Uint8Array(w * h);
	for (let p = 0; p < out.length; p++) if (label[p] >= 0 && odd[label[p]]) out[p] = 1;
	return {
		mask: out,
		refWidth: ref,
		strokes: strokes.length
	};
}
/** Mặt nạ 0/1 nét viết tay (màu + độ dày) — dùng làm gợi ý để người dùng chỉnh tay. */
function handMask(img, o = {}) {
	const { byColor = true, byWidth = true } = o, { width: w, height: h } = img;
	const { mask } = classifyInk(img), hand = new Uint8Array(w * h);
	if (byColor) {
		for (let p = 0; p < hand.length; p++) if (mask[p] === 2) hand[p] = 2;
	}
	if (byWidth) {
		const ink = new Uint8Array(w * h);
		for (let p = 0; p < ink.length; p++) ink[p] = mask[p] === 1 ? 1 : 0;
		const r = oddWidthMask(ink, w, h, o);
		for (let p = 0; p < hand.length; p++) if (r.mask[p]) hand[p] = 2;
	}
	const m = dilateHand(hand, w, h, 1);
	let any = false;
	for (let p = 0; p < m.length; p++) {
		m[p] = m[p] === 2 ? 1 : 0;
		if (m[p]) any = true;
	}
	return any ? m : null;
}
/** Rasterise strokes into a 0/1 mask (w*h). Eraser strokes clear. Segments are filled densely so fast swipes leave no gaps. */
function strokesToMask(strokes, w, h) {
	const m = new Uint8Array(w * h);
	for (const s of strokes) {
		const rad = Math.max(1, s.r * w), v = s.erase ? 0 : 1;
		const dot = (cx, cy) => {
			const x0 = Math.max(0, Math.floor(cx - rad)), x1 = Math.min(w - 1, Math.ceil(cx + rad));
			const y0 = Math.max(0, Math.floor(cy - rad)), y1 = Math.min(h - 1, Math.ceil(cy + rad));
			for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) if ((x - cx) ** 2 + (y - cy) ** 2 <= rad * rad) m[y * w + x] = v;
		};
		const p = s.pts.map((q) => ({
			x: q.x * w,
			y: q.y * h
		}));
		if (p.length === 1) dot(p[0].x, p[0].y);
		for (let i = 1; i < p.length; i++) {
			const a = p[i - 1], b = p[i], n = Math.max(1, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / Math.max(1, rad / 2)));
			for (let k = 0; k <= n; k++) dot(a.x + (b.x - a.x) * k / n, a.y + (b.y - a.y) * k / n);
		}
	}
	return m;
}
var maskArea = (m) => {
	let n = 0;
	for (let i = 0; i < m.length; i++) n += m[i];
	return n;
};
/**
* Classical inpainting (G3-24): onion-peel fill from the mask edge inward — each ring takes the
* distance-weighted mean of already-known pixels within radius 3 — then a few smoothing passes inside
* the mask only. Unmasked pixels are never changed. Cost scales with masked area, not image size.
*/
function inpaint(d, w, h, mask, smooth = 4) {
	const m = mask.slice();
	const R = 3;
	let todo = [];
	for (let i = 0; i < m.length; i++) if (m[i]) todo.push(i);
	const all = todo.slice();
	while (todo.length) {
		const ring = [], rest = [];
		for (const i of todo) {
			const x = i % w, y = i / w | 0;
			let edge = false;
			for (let dy = -1; dy <= 1 && !edge; dy++) for (let dx = -1; dx <= 1; dx++) {
				const nx = x + dx, ny = y + dy;
				if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
				if (!m[ny * w + nx]) {
					edge = true;
					break;
				}
			}
			(edge ? ring : rest).push(i);
		}
		if (!ring.length) break;
		const out = new Float32Array(ring.length * 3);
		ring.forEach((i, k) => {
			const x = i % w, y = i / w | 0;
			let r = 0, g = 0, b = 0, ws = 0;
			for (let dy = -3; dy <= R; dy++) for (let dx = -3; dx <= R; dx++) {
				const nx = x + dx, ny = y + dy;
				if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
				const j = ny * w + nx;
				if (m[j]) continue;
				const wt = 1 / (dx * dx + dy * dy);
				r += d[j * 4] * wt;
				g += d[j * 4 + 1] * wt;
				b += d[j * 4 + 2] * wt;
				ws += wt;
			}
			out[k * 3] = r / ws;
			out[k * 3 + 1] = g / ws;
			out[k * 3 + 2] = b / ws;
		});
		ring.forEach((i, k) => {
			d[i * 4] = out[k * 3];
			d[i * 4 + 1] = out[k * 3 + 1];
			d[i * 4 + 2] = out[k * 3 + 2];
			d[i * 4 + 3] = 255;
			m[i] = 0;
		});
		todo = rest;
	}
	for (let s = 0; s < smooth; s++) {
		const tmp = new Float32Array(all.length * 3);
		all.forEach((i, k) => {
			const x = i % w, y = i / w | 0;
			let n = 0;
			for (const [dx, dy] of [
				[0, 0],
				[1, 0],
				[-1, 0],
				[0, 1],
				[0, -1]
			]) {
				const nx = x + dx, ny = y + dy;
				if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
				const j = (ny * w + nx) * 4;
				tmp[k * 3] += d[j];
				tmp[k * 3 + 1] += d[j + 1];
				tmp[k * 3 + 2] += d[j + 2];
				n++;
			}
			tmp[k * 3] /= n;
			tmp[k * 3 + 1] /= n;
			tmp[k * 3 + 2] /= n;
		});
		all.forEach((i, k) => {
			d[i * 4] = tmp[k * 3];
			d[i * 4 + 1] = tmp[k * 3 + 1];
			d[i * 4 + 2] = tmp[k * 3 + 2];
		});
	}
	return d;
}
/** YCbCr skin test (Chai & Ngan range), tolerant of warm indoor light. */
var isSkin = (r, g, b) => {
	const cb = 128 - .168736 * r - .331264 * g + .5 * b, cr = 128 + .5 * r - .418688 * g - .081312 * b;
	return cr >= 135 && cr <= 180 && cb >= 80 && cb <= 128 && r > 60 && r > b;
};
/**
* G3-25: suggest finger areas holding a book open — skin-coloured blobs connected to the image border,
* reaching no deeper than `depth` of the image, at least `minArea` of it. Grown by `grow` px so the fill
* covers soft edges. Returns null when nothing found.
*/
function suggestFingers(d, w, h, { depth = .25, minArea = .002, grow = 0 } = {}) {
	const skin = new Uint8Array(w * h);
	for (let i = 0; i < skin.length; i++) skin[i] = isSkin(d[i * 4], d[i * 4 + 1], d[i * 4 + 2]) ? 1 : 0;
	const lab = new Int32Array(w * h), out = new Uint8Array(w * h);
	let id = 0, found = false;
	const g = grow || Math.max(2, Math.round(Math.min(w, h) * .008));
	for (let s = 0; s < skin.length; s++) {
		if (!skin[s] || lab[s]) continue;
		id++;
		const px = [s];
		lab[s] = id;
		let border = false, x0 = w, x1 = 0, y0 = h, y1 = 0;
		for (let k = 0; k < px.length; k++) {
			const i = px[k], x = i % w, y = i / w | 0;
			if (x === 0 || y === 0 || x === w - 1 || y === h - 1) border = true;
			x0 = Math.min(x0, x);
			x1 = Math.max(x1, x);
			y0 = Math.min(y0, y);
			y1 = Math.max(y1, y);
			for (const j of [
				x > 0 ? i - 1 : -1,
				x < w - 1 ? i + 1 : -1,
				y > 0 ? i - w : -1,
				y < h - 1 ? i + w : -1
			]) if (j >= 0 && skin[j] && !lab[j]) {
				lab[j] = id;
				px.push(j);
			}
		}
		if (!border || px.length < minArea * w * h) continue;
		if ((x1 - x0) / w > depth && (y1 - y0) / h > depth) continue;
		found = true;
		for (const i of px) {
			const x = i % w, y = i / w | 0;
			for (let dy = -g; dy <= g; dy++) for (let dx = -g; dx <= g; dx++) {
				const nx = x + dx, ny = y + dy;
				if (nx >= 0 && ny >= 0 && nx < w && ny < h) out[ny * w + nx] = 1;
			}
		}
	}
	return found ? out : null;
}
var SIZES = [
	.01,
	.025,
	.05
];
/** Paint over smudges, fingers or stray marks; the painted area is filled with the paper colour around it. */
function EraseEditor({ src, onClose, onApply }) {
	const box = (0, import_react.useRef)(null);
	const [strokes, setStrokes] = (0, import_react.useState)([]);
	const [cur, setCur] = (0, import_react.useState)(null);
	const [size, setSize] = (0, import_react.useState)(1);
	const [erase, setErase] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [hint, setHint] = (0, import_react.useState)(null);
	const [finding, setFinding] = (0, import_react.useState)(false);
	const hintRef = (0, import_react.useRef)(hint);
	hintRef.current = hint;
	(0, import_react.useEffect)(() => () => revokeTemp(hintRef.current?.url), []);
	const pt = (e) => {
		const b = box.current.getBoundingClientRect();
		return {
			x: Math.min(1, Math.max(0, (e.clientX - b.left) / b.width)),
			y: Math.min(1, Math.max(0, (e.clientY - b.top) / b.height))
		};
	};
	const all = cur ? [...strokes, cur] : strokes;
	const painted = !!hint || strokes.some((s) => !s.erase);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "scan-screen fixed inset-0 z-50 mx-auto flex max-w-[430px] flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-3 pt-[max(0.75rem,env(safe-area-inset-top))] pb-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: "scan-icon",
						onClick: onClose,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}), " Hủy"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm font-semibold",
						children: "Tẩy vết"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: "scan-icon",
						disabled: !strokes.length,
						onClick: () => setStrokes((s) => s.slice(0, -1)),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, {}), " Hoàn tác"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid min-h-0 flex-1 place-items-center p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: box,
					className: "relative touch-none select-none",
					onPointerDown: (e) => {
						e.target.setPointerCapture?.(e.pointerId);
						setCur({
							pts: [pt(e)],
							r: SIZES[size],
							erase
						});
					},
					onPointerMove: (e) => {
						if (cur) setCur({
							...cur,
							pts: [...cur.pts, pt(e)]
						});
					},
					onPointerUp: () => {
						if (cur) setStrokes((s) => [...s, cur]);
						setCur(null);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src,
							alt: "Trang",
							draggable: false,
							className: "block max-h-[62dvh] max-w-full"
						}),
						hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: hint.url,
							alt: "",
							className: "pointer-events-none absolute inset-0 h-full w-full opacity-50"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							className: "pointer-events-none absolute inset-0 h-full w-full",
							viewBox: "0 0 1000 1000",
							preserveAspectRatio: "none",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mask", {
								id: "erase-m",
								maskUnits: "userSpaceOnUse",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
									width: "1000",
									height: "1000",
									fill: "black"
								}), all.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
									points: s.pts.map((p) => `${p.x * 1e3},${p.y * 1e3}`).join(" "),
									fill: "none",
									stroke: s.erase ? "black" : "white",
									strokeWidth: s.r * 2e3,
									strokeLinecap: "round",
									strokeLinejoin: "round",
									vectorEffect: "none"
								}, i))]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								width: "1000",
								height: "1000",
								className: "fill-destructive",
								opacity: .5,
								mask: "url(#erase-m)"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs opacity-80",
						children: "Tô đỏ lên vết bẩn, ngón tay hay nét thừa. Vùng tô sẽ được lấp nền liền mạch theo vùng xung quanh."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: erase ? "glass" : "default",
								size: "sm",
								onClick: () => setErase(false),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brush, {}), " Tô"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: erase ? "default" : "glass",
								size: "sm",
								onClick: () => setErase(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, {}), " Bỏ tô"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "ml-auto flex gap-1",
								"aria-label": "Cỡ cọ",
								children: SIZES.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									"aria-label": `Cỡ ${i + 1}`,
									onClick: () => setSize(i),
									className: `grid h-8 w-8 place-items-center rounded-full border ${size === i ? "border-primary" : "border-transparent"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-current",
										style: {
											width: 6 + i * 6,
											height: 6 + i * 6
										}
									})
								}, i))
							})
						]
					}),
					["finger", "hand"].map((kind) => hint && hint.kind !== kind ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "glass",
						className: "mb-2 w-full",
						disabled: finding || busy,
						onClick: async () => {
							if (hint) {
								revokeTemp(hint.url);
								setHint(null);
								return;
							}
							setFinding(true);
							try {
								const img = await loadImg(src);
								const k = Math.min(1, (kind === "hand" ? 1600 : 800) / Math.max(img.naturalWidth, img.naturalHeight));
								const w = Math.round(img.naturalWidth * k), h = Math.round(img.naturalHeight * k);
								const c = document.createElement("canvas");
								c.width = w;
								c.height = h;
								const ctx = c.getContext("2d", { willReadFrequently: true });
								ctx.drawImage(img, 0, 0, w, h);
								const data = ctx.getImageData(0, 0, w, h);
								const m = kind === "hand" ? handMask(data) : suggestFingers(data.data, w, h);
								if (!m) {
									toast(kind === "hand" ? "Không thấy chữ viết tay khác chữ in — tô tay nếu cần" : "Không thấy ngón tay ở mép trang — tô tay nếu cần");
									return;
								}
								const o = ctx.createImageData(w, h);
								for (let i = 0; i < m.length; i++) if (m[i]) o.data.set([
									230,
									40,
									40,
									255
								], i * 4);
								ctx.putImageData(o, 0, 0);
								const hintUrl = await canvasToTempUrl(c);
								setHint((old) => {
									revokeTemp(old?.url);
									return {
										mask: m,
										w,
										h,
										url: hintUrl,
										kind
									};
								});
								toast.success(kind === "hand" ? "Đã đánh dấu chữ viết tay — Tô để thêm, Bỏ tô để giữ lại, rồi bấm Tẩy" : "Đã đánh dấu ngón tay — dùng Bỏ tô để sửa rồi bấm Tẩy");
							} catch (e) {
								showError(e, kind === "hand" ? "Tìm chữ viết tay" : "Tìm ngón tay");
							} finally {
								setFinding(false);
							}
						},
						children: [
							finding ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : kind === "hand" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hand, {}),
							" ",
							hint ? kind === "hand" ? "Bỏ gợi ý chữ viết tay" : "Bỏ gợi ý ngón tay" : kind === "hand" ? "Tự tìm chữ viết tay (tạo bản đề sạch)" : "Tự tìm ngón tay ở mép sách"
						]
					}, kind)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "w-full",
						disabled: !painted || busy,
						onClick: async () => {
							setBusy(true);
							try {
								const img = await loadImg(src);
								const w = img.naturalWidth, h = img.naturalHeight;
								const m = strokesToMask(strokes, w, h);
								if (hint) {
									for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (hint.mask[Math.min(hint.h - 1, y * hint.h / h | 0) * hint.w + Math.min(hint.w - 1, x * hint.w / w | 0)]) m[y * w + x] = 1;
									const er = strokesToMask(strokes.filter((s) => s.erase).map((s) => ({
										...s,
										erase: false
									})), w, h);
									for (let i = 0; i < m.length; i++) if (er[i]) m[i] = 0;
								}
								if (!maskArea(m)) {
									toast("Chưa tô vùng nào");
									return;
								}
								const c = document.createElement("canvas");
								c.width = w;
								c.height = h;
								const ctx = c.getContext("2d", { willReadFrequently: true });
								ctx.drawImage(img, 0, 0);
								const data = ctx.getImageData(0, 0, w, h);
								inpaint(data.data, w, h, m);
								ctx.putImageData(data, 0, 0);
								await onApply(await canvasToPageUrl(c, "image/jpeg", .92));
								toast.success("Đã tẩy vùng tô");
							} catch (e) {
								showError(e, "Tẩy vết");
							} finally {
								setBusy(false);
							}
						},
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : null, " Tẩy vùng đã tô"]
					})
				]
			})
		]
	});
}
var KEY$1 = "ghinhanh.signatures";
var cache = null;
var subs = /* @__PURE__ */ new Set();
function read() {
	if (cache) return cache;
	try {
		cache = typeof localStorage === "undefined" ? [] : JSON.parse(localStorage.getItem(KEY$1) || "[]");
	} catch {
		cache = [];
	}
	return cache;
}
function write(list) {
	cache = list;
	try {
		localStorage.setItem(KEY$1, JSON.stringify(list));
	} catch {
		throw new Error("Bộ nhớ máy đầy — xóa bớt chữ ký cũ rồi thử lại.");
	}
	subs.forEach((f) => f());
}
var EMPTY = [];
function useSignatures() {
	return (0, import_react.useSyncExternalStore)((f) => {
		subs.add(f);
		return () => {
			subs.delete(f);
		};
	}, read, () => EMPTY);
}
function addSignature(s) {
	const sig = {
		...s,
		id: Math.random().toString(36).slice(2, 10),
		createdAt: Date.now()
	};
	write([sig, ...read()].slice(0, 8));
	return sig;
}
function removeSignature(id) {
	write(read().filter((s) => s.id !== id));
}
/** Bounding box of pixels with alpha > threshold in RGBA data; null when blank. */
function inkBox(data, w, h, thr = 8) {
	let x0 = w, y0 = h, x1 = -1, y1 = -1;
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (data[(y * w + x) * 4 + 3] > thr) {
		if (x < x0) x0 = x;
		if (x > x1) x1 = x;
		if (y < y0) y0 = y;
		if (y > y1) y1 = y;
	}
	return x1 < 0 ? null : {
		x: x0,
		y: y0,
		w: x1 - x0 + 1,
		h: y1 - y0 + 1
	};
}
/** Trim a drawn canvas to its ink (+padding). Returns null if nothing was drawn. */
function trimCanvas(c, pad = 6) {
	const b = inkBox(c.getContext("2d").getImageData(0, 0, c.width, c.height).data, c.width, c.height);
	if (!b) return null;
	const x = Math.max(0, b.x - pad), y = Math.max(0, b.y - pad);
	const w = Math.min(c.width - x, b.w + pad * 2), h = Math.min(c.height - y, b.h + pad * 2);
	const o = document.createElement("canvas");
	o.width = w;
	o.height = h;
	o.getContext("2d").drawImage(c, x, y, w, h, 0, 0, w, h);
	const src = o.toDataURL("image/png");
	o.width = 0;
	return {
		src,
		w,
		h
	};
}
/** Keep a placement inside the page and its width within [min, 1]; aspect is preserved via `ratio` (h/w in page fractions). */
function clampPlacement(p, ratio, min = .06) {
	const w = Math.min(1, Math.max(min, p.w));
	let h = w * ratio;
	let ww = w;
	if (h > 1) {
		h = 1;
		ww = h / ratio;
	}
	return {
		w: ww,
		h,
		x: Math.min(1 - ww, Math.max(0, p.x)),
		y: Math.min(1 - h, Math.max(0, p.y))
	};
}
/** Draw signatures onto a page; returns a registered JPEG object URL (R1.4: không còn data URL). */
async function applySignatures(base, items) {
	const page = await loadImg(base);
	const c = document.createElement("canvas");
	c.width = page.naturalWidth;
	c.height = page.naturalHeight;
	const ctx = c.getContext("2d");
	ctx.drawImage(page, 0, 0);
	for (const it of items) {
		const s = await loadImg(it.src);
		const w = it.at.w * c.width, h = it.at.h * c.height;
		ctx.save();
		ctx.translate(it.at.x * c.width + w / 2, it.at.y * c.height + h / 2);
		ctx.rotate(it.at.r ?? 0);
		ctx.drawImage(s, -w / 2, -h / 2, w, h);
		ctx.restore();
	}
	return canvasToPageUrl(c, "image/jpeg", .92);
}
/** Keep a free (any-aspect) box inside the page; width/height each within [min, 1]. */
function clampBox(p, min = .03, aspect = 1.414) {
	let w = Math.min(1, Math.max(min, p.w)), h = Math.min(1, Math.max(min, p.h));
	const c = Math.abs(Math.cos(p.r ?? 0)), s = Math.abs(Math.sin(p.r ?? 0));
	let bw = c * w + s * h * aspect, bh = s * w / aspect + c * h;
	const k = Math.min(1, 1 / bw, 1 / bh);
	if (k < 1) {
		w *= k;
		h *= k;
		bw *= k;
		bh *= k;
	}
	const cx = Math.min(1 - bw / 2, Math.max(bw / 2, p.x + p.w / 2)), cy = Math.min(1 - bh / 2, Math.max(bh / 2, p.y + p.h / 2));
	return {
		...p,
		w,
		h,
		x: cx - w / 2,
		y: cy - h / 2
	};
}
/** Edge handles stretch one axis independently; the corner handle keeps the current aspect. dx/dy are page fractions. */
function resizeBy(at, handle, dx, dy, min = .03) {
	let { x, y, w, h } = at;
	if (handle === "e") w = Math.max(min, w + dx);
	else if (handle === "w") {
		const nw = Math.max(min, w - dx);
		x += w - nw;
		w = nw;
	} else if (handle === "s") h = Math.max(min, h + dy);
	else if (handle === "n") {
		const nh = Math.max(min, h - dy);
		y += h - nh;
		h = nh;
	} else {
		const k = at.h / at.w;
		let nw = Math.max(min, w + Math.max(dx, dy / k));
		nw = Math.min(nw, 1 - x, (1 - y) / k);
		w = Math.max(min, nw);
		h = w * k;
	}
	return clampBox({
		...at,
		x,
		y,
		w: Math.min(1, w),
		h: Math.min(1, h)
	}, min);
}
/** Two-finger gesture: scale around the box centre (aspect kept) and add rotation. */
function pinchBy(at, scale, dAngle, min = .03, aspect = 1.414) {
	const k = at.h / at.w;
	let w = Math.max(min, at.w * scale), h = w * k;
	if (w > 1) {
		w = 1;
		h = k;
	}
	if (h > 1) {
		h = 1;
		w = 1 / k;
	}
	const cx = at.x + at.w / 2, cy = at.y + at.h / 2;
	return clampBox({
		...at,
		w,
		h,
		x: cx - w / 2,
		y: cy - h / 2,
		r: (at.r ?? 0) + dAngle
	}, min, aspect);
}
/** Remove isolated alpha specks (connected components smaller than `minArea` px) — clean transparent edges. */
function despeckleAlpha(d, w, h, minArea = 12, thr = 24) {
	const lab = new Int32Array(w * h);
	const stack = [];
	let removed = 0;
	for (let s = 0; s < w * h; s++) {
		if (lab[s] || d[s * 4 + 3] <= thr) continue;
		const comp = [];
		stack.push(s);
		lab[s] = 1;
		while (stack.length) {
			const i = stack.pop();
			comp.push(i);
			const x = i % w, y = i / w | 0;
			for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
				const nx = x + ox, ny = y + oy;
				if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
				const j = ny * w + nx;
				if (!lab[j] && d[j * 4 + 3] > thr) {
					lab[j] = 1;
					stack.push(j);
				}
			}
		}
		if (comp.length < minArea) for (const i of comp) {
			d[i * 4 + 3] = 0;
			removed++;
		}
	}
	for (let i = 0; i < w * h; i++) if (d[i * 4 + 3] <= thr) d[i * 4 + 3] = 0;
	return removed;
}
/** Paper brightness per pixel: max luminance in coarse blocks, then bilinear-smoothed (handles shadows/uneven light). */
function paperLevel(lum, w, h, block = 16) {
	const bw = Math.ceil(w / block), bh = Math.ceil(h / block);
	const m = new Float32Array(bw * bh);
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		const i = (y / block | 0) * bw + (x / block | 0);
		if (lum[y * w + x] > m[i]) m[i] = lum[y * w + x];
	}
	const out = new Float32Array(w * h);
	for (let y = 0; y < h; y++) {
		const fy = Math.min(bh - 1, Math.max(0, y / block - .5)), y0 = fy | 0, y1 = Math.min(bh - 1, y0 + 1), ty = fy - y0;
		for (let x = 0; x < w; x++) {
			const fx = Math.min(bw - 1, Math.max(0, x / block - .5)), x0 = fx | 0, x1 = Math.min(bw - 1, x0 + 1), tx = fx - x0;
			const a = m[y0 * bw + x0] * (1 - tx) + m[y0 * bw + x1] * tx, b = m[y1 * bw + x0] * (1 - tx) + m[y1 * bw + x1] * tx;
			out[y * w + x] = a * (1 - ty) + b * ty;
		}
	}
	return out;
}
var smooth = (a, b, v) => {
	const t = Math.min(1, Math.max(0, (v - a) / (b - a)));
	return t * t * (3 - 2 * t);
};
/** In-place: paper → transparent, ink keeps its hue (deepened slightly so pale pen reads well). */
function extractInk(d, w, h, lo = .12, hi = .38) {
	const lum = new Float32Array(w * h);
	for (let i = 0; i < w * h; i++) lum[i] = .299 * d[i * 4] + .587 * d[i * 4 + 1] + .114 * d[i * 4 + 2];
	const bg = paperLevel(lum, w, h);
	for (let i = 0; i < w * h; i++) {
		const a = smooth(lo, hi, bg[i] > 1 ? (bg[i] - lum[i]) / bg[i] : 0);
		const k = .75;
		d[i * 4] *= k;
		d[i * 4 + 1] *= k;
		d[i * 4 + 2] *= k;
		d[i * 4 + 3] = Math.round(a * 255);
	}
	return d;
}
/** Photo of a signature on paper → trimmed transparent PNG. */
async function signatureFromPhoto(file) {
	const img = await loadImg(await fileToDataUrl(file));
	const s = Math.min(1, 1400 / Math.max(img.naturalWidth, img.naturalHeight));
	const c = document.createElement("canvas");
	c.width = Math.round(img.naturalWidth * s);
	c.height = Math.round(img.naturalHeight * s);
	const ctx = c.getContext("2d", { willReadFrequently: true });
	ctx.drawImage(img, 0, 0, c.width, c.height);
	const data = ctx.getImageData(0, 0, c.width, c.height);
	extractInk(data.data, c.width, c.height);
	despeckleAlpha(data.data, c.width, c.height, Math.max(12, Math.round(c.width * c.height / 4e4)));
	ctx.putImageData(data, 0, 0);
	return trimCanvas(c, 10);
}
var KEY = /^(ký|ky|kí|ki)$|người\s*ký|giám\s*đốc|giam\s*doc|xác\s*nhận|đại\s*diện|người\s*lập|kế\s*toán|thủ\s*trưởng|chữ\s*ký|signature|sign/i;
var isSignLabel = (s) => KEY.test(s.normalize("NFC").trim().replace(/[.,:;()]/g, ""));
/** Tìm đoạn kẻ ngang mảnh (≤ maxThick px), cho phép khe hở (đường chấm chấm), dài ≥ minFrac bề rộng ảnh. */
function detectRuleLines(gray, w, h, opts = {}) {
	const dark = opts.dark ?? 150, minLen = Math.max(12, (opts.minFrac ?? .12) * w), gap = opts.gap ?? Math.max(4, Math.round(w / 70)), maxThick = opts.maxThick ?? Math.max(3, Math.round(h / 300));
	const raw = [];
	for (let y = 0; y < h; y++) {
		let start = -1, last = -1, ink = 0;
		const flush = () => {
			if (start >= 0 && last - start + 1 >= minLen && ink / (last - start + 1) >= .35) raw.push({
				x0: start,
				x1: last,
				y
			});
			start = -1;
			ink = 0;
		};
		for (let x = 0; x < w; x++) if (gray[y * w + x] < dark) {
			if (start < 0) start = x;
			else if (x - last > gap) {
				flush();
				start = x;
			}
			last = x;
			ink++;
		}
		flush();
	}
	raw.sort((a, b) => a.y - b.y || a.x0 - b.x0);
	const groups = [];
	for (const r of raw) {
		const g = groups.find((q) => r.y - q.y1 <= 1 && r.x0 < q.x1 && r.x1 > q.x0);
		if (g) {
			g.y1 = r.y;
			g.x0 = Math.min(g.x0, r.x0);
			g.x1 = Math.max(g.x1, r.x1);
		} else groups.push({
			x0: r.x0,
			x1: r.x1,
			y0: r.y,
			y1: r.y
		});
	}
	const lines = [];
	for (const g of groups) {
		if (g.y1 - g.y0 + 1 > maxThick) continue;
		const band = (ya, yb) => {
			let ink = 0, tot = 0;
			for (let y = Math.max(0, ya); y < Math.min(h, yb); y++) for (let x = g.x0; x <= g.x1; x += 2) {
				tot++;
				if (gray[y * w + x] < dark) ink++;
			}
			return tot ? ink / tot : 0;
		};
		const near = Math.max(3, Math.round(h * .008)), far = Math.round(h * .03);
		if (band(g.y0 - near - 1, g.y0 - 1) > .03 || band(g.y1 + 2, g.y1 + 2 + near) > .06 || band(g.y0 - far, g.y0 - near) > .08) continue;
		lines.push({
			x0: g.x0,
			x1: g.x1,
			y: (g.y0 + g.y1) / 2
		});
	}
	return lines;
}
/** Kết hợp đường kẻ + nhãn → danh sách gợi ý đã xếp hạng (điểm cao trước), theo phần trang. */
function suggestSignSpots(lines, words, w, h, max = 4) {
	const labels = words.filter((t) => isSignLabel(t.str));
	for (let i = 0; i + 1 < words.length; i++) {
		const a = words[i], b = words[i + 1];
		if (Math.abs(a.y - b.y) < a.h && isSignLabel(`${a.str} ${b.str}`) && !labels.includes(a) && !labels.includes(b)) labels.push({
			str: `${a.str} ${b.str}`,
			x: a.x,
			y: Math.min(a.y, b.y),
			w: b.x + b.w - a.x,
			h: Math.max(a.h, b.h)
		});
	}
	const spots = [];
	const sigH = h * .07;
	const used = /* @__PURE__ */ new Set();
	for (const l of lines) {
		const len = l.x1 - l.x0;
		let score = 1 + Math.min(1, len / (w * .3));
		const lab = labels.find((t) => {
			const cx = t.x + t.w / 2, cy = t.y + t.h / 2;
			const sameRow = Math.abs(cy - l.y) < Math.max(t.h, h * .02) && t.x + t.w <= l.x0 + len * .2 && l.x0 - (t.x + t.w) < w * .25;
			const near = cx > l.x0 - w * .08 && cx < l.x1 + w * .08 && Math.abs(cy - l.y) < h * .12;
			return sameRow || near;
		});
		if (lab) {
			score += 3;
			used.add(lab);
		}
		const bw = Math.min(len, w * .34);
		spots.push({
			x: (l.x0 + (len - bw) / 2) / w,
			y: (l.y - sigH) / h,
			w: bw / w,
			h: sigH / h,
			score,
			source: lab ? "both" : "line"
		});
	}
	for (const t of labels) {
		if (used.has(t)) continue;
		const bw = w * .3, cx = t.x + t.w / 2;
		spots.push({
			x: Math.min(1 - bw / w, Math.max(0, (cx - bw / 2) / w)),
			y: Math.min(1 - sigH / h, (t.y + t.h + h * .01) / h),
			w: bw / w,
			h: sigH / h,
			score: 2.5,
			source: "label"
		});
	}
	for (const s of spots) s.score += s.y * 1.5;
	spots.sort((a, b) => b.score - a.score);
	const out = [];
	for (const s of spots) if (!out.some((o) => Math.abs(o.x - s.x) < .08 && Math.abs(o.y - s.y) < .04)) out.push(s);
	return out.slice(0, max);
}
/** Đặt chữ ký (tỉ lệ cao/rộng theo phần trang = ratio) vào gợi ý: chân chữ ký chạm dòng, căn giữa, vừa bề rộng. */
function anchorTo(spot, ratio) {
	let w = spot.w, h = w * ratio;
	const maxH = spot.h * 1.6;
	if (h > maxH) {
		h = maxH;
		w = h / ratio;
	}
	const cx = spot.x + spot.w / 2, bottom = spot.y + spot.h;
	return {
		x: Math.min(1 - w, Math.max(0, cx - w / 2)),
		y: Math.min(1 - h, Math.max(0, bottom - h * .92)),
		w,
		h
	};
}
/** Ảnh → mảng xám thu nhỏ (tối đa `max` px cạnh dài). Chạy trên trình duyệt. */
function grayOf(img, max = 1e3) {
	const W = img.naturalWidth || img.width, H = img.naturalHeight || img.height;
	const k = Math.min(1, max / Math.max(W, H));
	const w = Math.max(1, Math.round(W * k)), h = Math.max(1, Math.round(H * k));
	const c = document.createElement("canvas");
	c.width = w;
	c.height = h;
	const g = c.getContext("2d", { willReadFrequently: true });
	g.drawImage(img, 0, 0, w, h);
	const d = g.getImageData(0, 0, w, h).data;
	const out = new Uint8Array(w * h);
	for (let i = 0; i < w * h; i++) out[i] = (d[i * 4] * 299 + d[i * 4 + 1] * 587 + d[i * 4 + 2] * 114) / 1e3;
	return {
		gray: out,
		w,
		h,
		canvas: c
	};
}
var EDGE = {
	n: "left-1/2 -top-2.5 -translate-x-1/2 h-2.5 w-6 cursor-ns-resize",
	s: "left-1/2 -bottom-2.5 -translate-x-1/2 h-2.5 w-6 cursor-ns-resize",
	e: "top-1/2 -right-2.5 -translate-y-1/2 w-2.5 h-6 cursor-ew-resize",
	w: "top-1/2 -left-2.5 -translate-y-1/2 w-2.5 h-6 cursor-ew-resize"
};
/** Pick saved signatures, drop them on the page, drag to move and pull the corner to resize. */
function SignaturePlacer({ src, onClose, onApply, onFreehand }) {
	const sigs = useSignatures();
	const box = (0, import_react.useRef)(null);
	const img = (0, import_react.useRef)(null);
	const [aspect, setAspect] = (0, import_react.useState)(1.414);
	const [placed, setPlaced] = (0, import_react.useState)([]);
	const [sel, setSel] = (0, import_react.useState)(null);
	const [newPad, setNewPad] = (0, import_react.useState)(sigs.length === 0);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const drag = (0, import_react.useRef)(null);
	const touches = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const pinch = (0, import_react.useRef)(null);
	const geo = () => {
		const [p1, p2] = [...touches.current.values()];
		return {
			d: Math.hypot(p2.x - p1.x, p2.y - p1.y) || 1,
			a: Math.atan2(p2.y - p1.y, p2.x - p1.x)
		};
	};
	const ratioOf = (s, a = aspect) => s.h / s.w / a;
	const syncAspect = (el) => {
		if (!el || !el.complete || !el.naturalWidth) return;
		const a = el.naturalHeight / el.naturalWidth;
		setAspect((old) => {
			if (Math.abs(old - a) < 1e-4) return old;
			setPlaced((l) => l.map((p) => ({
				...p,
				at: {
					...clampPlacement(p.at, ratioOf(p.sig, a)),
					r: p.at.r
				}
			})));
			return a;
		});
	};
	(0, import_react.useEffect)(() => {
		syncAspect(img.current);
	}, [src]);
	const [spots, setSpots] = (0, import_react.useState)([]);
	const [reading, setReading] = (0, import_react.useState)(false);
	const scan = (words = []) => {
		const el = img.current;
		if (!el?.complete || !el.naturalWidth) return null;
		const g = grayOf(el, 1e3);
		setSpots(suggestSignSpots(detectRuleLines(g.gray, g.w, g.h), words, g.w, g.h));
		return g;
	};
	(0, import_react.useEffect)(() => {
		scan();
	}, [src]);
	const readLabels = async () => {
		const g = scan();
		if (!g) return;
		setReading(true);
		try {
			const { ocrSession } = await import("./ocr-CLa2avjZ.mjs").then((n) => n.r).then((n) => n.r);
			const s = await ocrSession();
			try {
				const ws = (await s.words(g.canvas)).words.map((t) => ({
					str: t.str,
					x: t.x,
					y: -t.y - t.h / 2,
					w: t.w,
					h: t.h
				}));
				const out = suggestSignSpots(detectRuleLines(g.gray, g.w, g.h), ws, g.w, g.h);
				setSpots(out);
				toast(out.length ? `Tìm thấy ${out.length} chỗ ký` : "Không thấy dòng ký trên trang");
			} finally {
				await s.close();
			}
		} catch (e) {
			showError(e, "Đọc nhãn chỗ ký");
		} finally {
			setReading(false);
		}
	};
	const anchor = (spot) => {
		const cur = placed.find((p) => p.key === sel) ?? placed[placed.length - 1];
		if (cur) {
			setPlaced((l) => l.map((p) => p.key === cur.key ? {
				...p,
				at: { ...clampBox({
					...anchorTo(spot, ratioOf(p.sig)),
					r: 0
				}, .03, aspect) }
			} : p));
			setSel(cur.key);
			return;
		}
		const s0 = sigs[0];
		if (!s0) {
			setNewPad(true);
			return;
		}
		const key = Math.random().toString(36).slice(2);
		setPlaced((p) => [...p, {
			key,
			sig: s0,
			at: clampBox({
				...anchorTo(spot, ratioOf(s0)),
				r: 0
			}, .03, aspect)
		}]);
		setSel(key);
	};
	const endDrag = (e) => {
		if (e) touches.current.delete(e.pointerId);
		if (touches.current.size < 2) pinch.current = null;
		drag.current = null;
	};
	const put = (sig) => {
		const key = Math.random().toString(36).slice(2);
		setPlaced((p) => [...p, {
			key,
			sig,
			at: clampPlacement({
				x: .55,
				y: .75,
				w: .32,
				h: 0
			}, ratioOf(sig))
		}]);
		setSel(key);
	};
	const onDown = (e, p, mode) => {
		e.stopPropagation();
		setSel(p.key);
		if (e.pointerType === "touch" && mode === "move") {
			touches.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			if (touches.current.size === 2) {
				drag.current = null;
				pinch.current = {
					key: p.key,
					...geo(),
					at: p.at
				};
				return;
			}
		}
		e.currentTarget.setPointerCapture?.(e.pointerId);
		drag.current = {
			key: p.key,
			mode,
			px: e.clientX,
			py: e.clientY,
			at: p.at
		};
	};
	const onMove = (e) => {
		if (touches.current.has(e.pointerId)) touches.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
		const pz = pinch.current;
		if (pz && touches.current.size >= 2) {
			const g = geo();
			setPlaced((l) => l.map((p) => p.key !== pz.key ? p : {
				...p,
				at: pinchBy(pz.at, g.d / pz.d, g.a - pz.a, .03, aspect)
			}));
			return;
		}
		const d = drag.current;
		if (!d || !box.current) return;
		const r = box.current.getBoundingClientRect();
		const dx = (e.clientX - d.px) / r.width, dy = (e.clientY - d.py) / r.height;
		setPlaced((list) => list.map((p) => p.key !== d.key ? p : {
			...p,
			at: d.mode === "move" ? clampBox({
				...d.at,
				x: d.at.x + dx,
				y: d.at.y + dy
			}, .03, aspect) : resizeBy(d.at, d.mode, dx, dy)
		}));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "scan-screen fixed inset-0 z-50 mx-auto flex max-w-[430px] flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-3 pt-[max(0.75rem,env(safe-area-inset-top))] pb-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: "scan-icon",
						onClick: onClose,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}), " Hủy"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm font-semibold",
						children: "Chèn chữ ký"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: "scan-icon",
						onClick: onFreehand,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, {}), " Vẽ tay"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid min-h-0 flex-1 place-items-center p-4",
				onPointerMove: onMove,
				onPointerUp: endDrag,
				onPointerCancel: endDrag,
				onLostPointerCapture: endDrag,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: box,
					className: "relative touch-none select-none",
					onPointerDown: () => setSel(null),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							ref: img,
							src,
							alt: "Trang",
							draggable: false,
							onLoad: (e) => {
								syncAspect(e.currentTarget);
								scan();
							},
							className: "block max-h-[52dvh] max-w-full"
						}),
						spots.map((sp, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "sign-spot pointer-events-none absolute",
							style: {
								left: `${sp.x * 100}%`,
								top: `${sp.y * 100}%`,
								width: `${sp.w * 100}%`,
								height: `${sp.h * 100}%`
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"data-testid": "sign-spot",
								"aria-label": `Neo chữ ký vào chỗ ký ${i + 1}`,
								className: "sign-spot-tag pointer-events-auto",
								onPointerDown: (e) => e.stopPropagation(),
								onClick: (e) => {
									e.stopPropagation();
									anchor(sp);
								},
								children: "Ký ở đây"
							})
						}, i)),
						placed.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `absolute ${sel === p.key ? "outline outline-2 outline-primary" : ""}`,
							style: {
								left: `${p.at.x * 100}%`,
								top: `${p.at.y * 100}%`,
								width: `${p.at.w * 100}%`,
								height: `${p.at.h * 100}%`,
								transform: p.at.r ? `rotate(${p.at.r}rad)` : void 0
							},
							"data-testid": "sig-placed",
							onPointerDown: (e) => onDown(e, p, "move"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: p.sig.src,
								alt: "Chữ ký",
								draggable: false,
								className: "pointer-events-none h-full w-full"
							}), sel === p.key && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									"aria-label": "Bỏ chữ ký này",
									className: "absolute -left-3 -top-3 grid size-6 place-items-center rounded-full bg-destructive text-destructive-foreground",
									onPointerDown: (e) => {
										e.stopPropagation();
										setPlaced((l) => l.filter((x) => x.key !== p.key));
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-label": "Kéo góc để đổi cỡ giữ tỉ lệ",
									className: "absolute -bottom-3 -right-3 size-6 cursor-nwse-resize rounded-full border-2 border-card bg-primary",
									onPointerDown: (e) => onDown(e, p, "se")
								}),
								Object.keys(EDGE).map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-label": `Kéo cạnh ${h} để kéo giãn`,
									className: `absolute rounded-full border border-card bg-primary ${EDGE[h]}`,
									onPointerDown: (e) => onDown(e, p, h)
								}, h)),
								p.at.r ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									"aria-label": "Bỏ xoay",
									className: "absolute -right-3 -top-3 grid size-6 place-items-center rounded-full bg-card text-[10px] text-card-foreground",
									onPointerDown: (e) => {
										e.stopPropagation();
										setPlaced((l) => l.map((x) => x.key === p.key ? {
											...x,
											at: {
												...x.at,
												r: 0
											}
										} : x));
									},
									children: "0°"
								}) : null
							] })]
						}, p.key))
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center gap-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "opacity-80",
							children: spots.length ? `${spots.length} chỗ ký gợi ý — chạm khung nét đứt để neo` : "Chưa thấy dòng ký"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "glass",
							className: "ml-auto",
							disabled: reading,
							onClick: readLabels,
							children: [reading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : null, " Đọc nhãn"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs opacity-80",
						children: "Chạm chữ ký để chèn · kéo để di chuyển · chấm góc: đổi cỡ giữ tỉ lệ · vạch cạnh: kéo giãn · 2 ngón: phóng/xoay"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 overflow-x-auto pb-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "grid h-16 w-24 shrink-0 place-items-center rounded-[10px] border border-dashed border-border bg-card text-xs text-card-foreground",
								onClick: () => setNewPad(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Ký mới"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "grid h-16 w-24 shrink-0 place-items-center rounded-[10px] border border-dashed border-border bg-card text-xs text-card-foreground",
								disabled: busy,
								onClick: async () => {
									const [f] = await pickFiles("image/*", false);
									if (!f) return;
									setBusy(true);
									try {
										const t = await signatureFromPhoto(f);
										if (!t) {
											toast("Không thấy nét mực — chụp chữ ký trên giấy trắng, đủ sáng");
											return;
										}
										const sig = addSignature(t);
										toast.success("Đã tách chữ ký và lưu vào kho");
										put(sig);
									} catch (e) {
										showError(e, "Tạo chữ ký từ ảnh");
									} finally {
										setBusy(false);
									}
								},
								children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }), "Từ ảnh chụp"]
							}),
							sigs.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "grid h-16 w-24 place-items-center rounded-[10px] bg-card p-1.5",
									onClick: () => put(s),
									"aria-label": "Chèn chữ ký",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: s.src,
										alt: "",
										className: "max-h-full max-w-full"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									"aria-label": "Xóa khỏi kho",
									className: "absolute right-0.5 top-0.5 rounded-full bg-background/80 p-1",
									onClick: async () => {
										if (await confirmDialog("Xóa chữ ký này khỏi kho?", { okText: "Xóa" })) removeSignature(s.id);
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" })
								})]
							}, s.id))
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "mt-1 w-full",
						disabled: !placed.length || busy,
						onClick: async () => {
							setBusy(true);
							try {
								await onApply(await applySignatures(src, placed.map((p) => ({
									src: p.sig.src,
									at: p.at
								}))));
							} catch (e) {
								showError(e, "Chèn chữ ký");
							} finally {
								setBusy(false);
							}
						},
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : null, " Lưu vào trang"]
					})
				]
			}),
			newPad && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewSignature, {
				onClose: () => setNewPad(false),
				onSaved: (s) => {
					setNewPad(false);
					put(s);
				}
			})
		]
	});
}
function NewSignature({ onClose, onSaved }) {
	const cv = (0, import_react.useRef)(null);
	const last = (0, import_react.useRef)(null);
	const [color, setColor] = (0, import_react.useState)("#0A2540");
	(0, import_react.useEffect)(() => {
		const c = cv.current;
		if (c) {
			c.width = 900;
			c.height = 360;
		}
	}, []);
	const pt = (e) => {
		const c = cv.current;
		const r = c.getBoundingClientRect();
		return [(e.clientX - r.left) / r.width * c.width, (e.clientY - r.top) / r.height * c.height];
	};
	const draw = (e) => {
		if (!last.current) return;
		const ctx = cv.current.getContext("2d");
		const p = pt(e);
		ctx.lineCap = "round";
		ctx.lineJoin = "round";
		ctx.strokeStyle = color;
		ctx.lineWidth = 7;
		ctx.beginPath();
		ctx.moveTo(...last.current);
		ctx.lineTo(...p);
		ctx.stroke();
		last.current = p;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[60] grid place-items-center bg-background/80 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-[400px] rounded-[16px] bg-card p-4 text-card-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "Ký vào khung"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
					ref: cv,
					className: "mt-3 aspect-[5/2] w-full touch-none rounded-[10px] border border-border bg-background",
					onPointerDown: (e) => {
						e.target.setPointerCapture(e.pointerId);
						last.current = pt(e);
					},
					onPointerMove: draw,
					onPointerUp: () => last.current = null
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex items-center gap-2",
					children: [[
						"#0A2540",
						"#1D4ED8",
						"#C1121F"
					].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						"aria-label": `Màu ${c}`,
						onClick: () => setColor(c),
						style: { background: c },
						className: `size-7 rounded-full border-2 ${color === c ? "border-primary" : "border-card"}`
					}, c)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "glass",
						className: "ml-auto",
						onClick: () => {
							const c = cv.current;
							c?.getContext("2d")?.clearRect(0, 0, c.width, c.height);
						},
						children: "Xóa"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "glass",
						onClick: onClose,
						children: "Hủy"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							const t = cv.current && trimCanvas(cv.current);
							if (!t) {
								toast("Hãy ký vào khung trước");
								return;
							}
							try {
								onSaved(addSignature(t));
								toast.success("Đã lưu vào kho chữ ký");
							} catch (e) {
								showError(e, "Lưu chữ ký");
							}
						},
						children: "Lưu vào kho"
					})]
				})
			]
		})
	});
}
/** Hàng đợi theo thứ tự tới; mục mới tên "Ảnh n" theo số thứ tự đã nhận trong phiên. */
function queueReduce(list, a) {
	if (a.type === "clear") return list.filter((x) => x.state === "receiving" || x.state === "waiting" || x.state === "adding");
	const set = (id, f) => list.map((x) => x.id === id ? f(x) : x);
	if (!list.some((x) => x.id === a.id)) {
		if (a.type === "progress" || a.type === "received") {
			const item = {
				id: a.id,
				state: a.type === "received" ? "waiting" : "receiving",
				pct: a.type === "received" ? 1 : a.pct,
				name: `Ảnh ${list.length + 1}`
			};
			return [...list, item];
		}
		return list;
	}
	switch (a.type) {
		case "progress": return set(a.id, (x) => x.state === "receiving" ? {
			...x,
			pct: Math.max(x.pct, a.pct)
		} : x);
		case "received": return set(a.id, (x) => ({
			...x,
			state: "waiting",
			pct: 1
		}));
		case "adding": return set(a.id, (x) => ({
			...x,
			state: "adding"
		}));
		case "done": return set(a.id, (x) => ({
			...x,
			state: "done"
		}));
		case "fail": return set(a.id, (x) => ({
			...x,
			state: "fail"
		}));
	}
	return list;
}
var QUEUE_LABEL = {
	receiving: "đang nhận",
	waiting: "chờ thêm vào tài liệu",
	adding: "đang dò khung, thêm vào tài liệu",
	done: "đã thêm vào tài liệu",
	fail: "chưa thêm được"
};
/** data:image/...;base64 → File (đi qua filesToPages như ảnh chọn từ máy). */
function dataUrlToFile(dataUrl, name) {
	const m = dataUrl.match(/^data:(image\/[a-z0-9.+-]+);base64,(.*)$/i);
	if (!m) throw new Error("Ảnh từ điện thoại không hợp lệ");
	const bin = atob(m[2]), u8 = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
	const ext = m[1].toLowerCase().includes("png") ? "png" : "jpg";
	return new File([u8], `${name.replace(/\s+/g, "-")}.${ext}`, { type: m[1] });
}
function PairDocBody({ st, onStop }) {
	const expired = !!st.room && st.left === 0 && !st.phone && st.queue.length === 0;
	const done = st.queue.filter((x) => x.state === "done").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 text-center",
		children: [
			!st.phone && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Mở camera trên điện thoại, quét mã này. Ảnh chụp sẽ vào thẳng tài liệu này, cuối tài liệu."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid aspect-square w-56 place-items-center rounded-xl border bg-card p-3",
				children: expired ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Mã đã hết hạn"
				}) : st.qr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: st.qr,
					alt: "Mã QR ghép điện thoại",
					className: "w-full"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Đang tạo mã…"
				})
			})] }),
			st.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "status",
				className: "flex items-center justify-center gap-2 rounded-lg bg-primary/10 p-3 font-medium text-primary",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, {
						className: "h-5 w-5",
						"aria-hidden": true
					}),
					" Đã nối với ",
					st.phone.device,
					done ? ` · đã thêm ${done} ảnh` : ""
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "status",
				className: "flex items-center justify-center gap-2 text-sm text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Laptop, {
					className: "h-4 w-4",
					"aria-hidden": true
				}), expired ? "Tạo mã mới để thử lại" : `Đang chờ điện thoại… mã còn ${Math.floor(st.left / 6e4)}:${String(Math.floor(st.left / 1e3) % 60).padStart(2, "0")}`]
			}),
			st.queue.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1 text-left text-sm",
				"aria-live": "polite",
				"data-testid": "pair-queue",
				children: st.queue.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2",
					children: [
						x.state === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "h-4 w-4 text-primary",
							"aria-hidden": true
						}) : x.state === "fail" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							children: "!"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							className: "h-4 w-4 animate-spin",
							"aria-hidden": true
						}),
						x.name,
						": ",
						x.state === "receiving" ? `${QUEUE_LABEL.receiving} ${Math.round(x.pct * 100)}%` : QUEUE_LABEL[x.state]
					]
				}, x.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap justify-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "glass",
						onClick: st.fresh,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
							className: "mr-1 h-4 w-4",
							"aria-hidden": true
						}), "Tạo mã mới"]
					}),
					st.queue.some((x) => x.state === "done" || x.state === "fail") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "glass",
						onClick: st.clear,
						children: "Xoá danh sách đã xong"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: onStop,
						children: "Ngắt kết nối"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Không cần đăng nhập. Phòng chỉ tồn tại khi tài liệu này đang mở; ảnh không lưu trên máy chủ. Đóng bảng này, điện thoại vẫn gửi được."
			})
		]
	});
}
/** `active` bật = tạo phòng + nghe ảnh; `onImage` thêm 1 ảnh vào tài liệu, trả true khi đã thêm. Ảnh tới được xếp hàng, thêm lần lượt. */
function usePairDoc(active, onImage) {
	const [room, setRoom] = (0, import_react.useState)(null);
	const [qr, setQr] = (0, import_react.useState)("");
	const [peers, setPeers] = (0, import_react.useState)([]);
	const [now, setNow] = (0, import_react.useState)(Date.now());
	const [queue, dispatch] = (0, import_react.useReducer)(queueReduce, []);
	const cb = (0, import_react.useRef)(onImage);
	cb.current = onImage;
	const chain = (0, import_react.useRef)(Promise.resolve());
	const count = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		if (active && !room) setRoom({
			code: newRoomCode(),
			created: Date.now()
		});
		if (!active) {
			setRoom(null);
			setPeers([]);
		}
	}, [active, room]);
	(0, import_react.useEffect)(() => {
		if (!active) return;
		const t = setInterval(() => setNow(Date.now()), 1e3);
		return () => clearInterval(t);
	}, [active]);
	(0, import_react.useEffect)(() => {
		if (!room) return;
		let off = false;
		import_lib.toDataURL(pairUrl(location.origin, room.code, room.created), {
			margin: 1,
			width: 320
		}).then((u) => {
			if (!off) setQr(u);
		});
		setPeers([]);
		const asm = new Assembler();
		const r = joinRoom(room.code, {
			role: "desktop",
			device: "Máy tính"
		}, setPeers, void 0, (ch) => {
			ch.on("broadcast", { event: "part" }, ({ payload }) => {
				const p = payload;
				const done = asm.push(p);
				if (!done) {
					const pr = asm.progress(p.id);
					if (pr !== null) dispatch({
						type: "progress",
						id: p.id,
						pct: pr
					});
					return;
				}
				dispatch({
					type: "received",
					id: done.id
				});
				ch.send({
					type: "broadcast",
					event: "ack",
					payload: { id: done.id }
				});
				const n = ++count.current;
				chain.current = chain.current.then(async () => {
					dispatch({
						type: "adding",
						id: done.id
					});
					try {
						dispatch({
							type: await cb.current(dataUrlToFile(done.dataUrl, `Từ điện thoại ${n}`)) ? "done" : "fail",
							id: done.id
						});
					} catch {
						dispatch({
							type: "fail",
							id: done.id
						});
					}
				});
			});
		});
		return () => {
			off = true;
			r.leave();
		};
	}, [room]);
	return {
		room,
		qr,
		phone: peers.find((p) => p.role === "phone"),
		queue,
		left: room ? remaining(room.created, now) : 0,
		fresh: () => {
			setQr("");
			setRoom({
				code: newRoomCode(),
				created: Date.now()
			});
		},
		clear: () => dispatch({ type: "clear" })
	};
}
var INSERT_POS_LABEL = {
	start: "Đầu tài liệu",
	after: "Sau trang đang xem",
	end: "Cuối tài liệu"
};
/** Chỉ số “chèn sau trang này” (‑1 = đầu) tương ứng với vị trí chọn. */
function afterIndex(pos, active, count) {
	if (pos === "start") return -1;
	if (pos === "end") return count - 1;
	return active;
}
/** Chèn trang mới theo vị trí chọn; trang đang xem chuyển tới trang mới đầu tiên. */
function insertPagesAt(pages, added, pos, active) {
	return insertPages(pages, added, afterIndex(pos, active, pages.length));
}
/** 5 nguồn nhập trang trong bảng Thêm. */
var ADD_SOURCES = [
	"library",
	"camera",
	"pdf",
	"paste",
	"scan"
];
var ADD_SOURCE_LABEL = {
	library: "Thư viện ảnh",
	camera: "Chụp ảnh",
	pdf: "Tệp PDF (tách trang)",
	paste: "Dán ảnh đã sao chép",
	scan: "Quét thêm bằng camera"
};
/** Tệp nhận được khi kéo-thả vào cửa sổ: ảnh hoặc PDF. */
function filesFromDrop(data) {
	if (!data?.files?.length) return [];
	return Array.from(data.files).filter((f) => isImageFile(f) || f.type === "application/pdf" || /\.pdf$/i.test(f.name));
}
/** Có đang kéo tệp (không phải kéo trang trong lưới) qua cửa sổ không. */
function isFileDrag(e) {
	return !!e.dataTransfer && Array.from(e.dataTransfer.types).includes("Files");
}
function docShortcut(key) {
	if (key === "Delete" || key === "Backspace") return "delete";
	if (key === "ArrowLeft") return "prev";
	if (key === "ArrowRight") return "next";
	if (key === "r" || key === "R") return "rotate";
	return null;
}
/** Không để màn hình trắng khi một phần giao diện gặp lỗi bất ngờ. */
var SafeBoundary = class extends import_react.Component {
	state = { err: false };
	static getDerivedStateFromError() {
		return { err: true };
	}
	componentDidCatch(e) {
		logScan({
			code: "UI_CRASH",
			message: e.message
		});
	}
	render() {
		if (!this.state.err) return this.props.children;
		const { title = "Phần AI gặp sự cố.", onClose, overlay } = this.props;
		const card = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "alert",
			className: "rounded-[12px] bg-destructive/10 p-4 text-sm text-destructive",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs",
					children: "Tài liệu của bạn vẫn an toàn. Hãy thử lại."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => this.setState({ err: false }),
						children: "Thử lại"
					}), onClose && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: onClose,
						children: "Đóng"
					})]
				})
			]
		});
		return overlay ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-50 flex items-center justify-center bg-background p-4",
			children: card
		}) : card;
	}
};
/** Trường quan trọng theo loại tài liệu (so khớp không phân biệt hoa thường, theo từ khoá). */
var REQUIRED_FIELDS = {
	"Biên bản": [
		"Ngày",
		"Nội dung",
		"Thành phần|Bên|Người"
	],
	"Hoá đơn": [
		"Số tiền|Tổng",
		"Ngày",
		"Bên bán|Người bán|Đơn vị bán"
	],
	"Biên lai": ["Số tiền|Tổng", "Ngày"],
	"Hợp đồng": ["Các bên|Bên", "Ngày ký|Ngày"],
	"CCCD/Hộ chiếu": [
		"Họ tên",
		"Số giấy tờ|Số",
		"Ngày sinh"
	],
	"Danh thiếp": ["Họ tên", "Điện thoại|Email"]
};
var norm = (s) => s.normalize("NFC").toLowerCase();
function isExtraction(x) {
	const o = x;
	return !!o && typeof o === "object" && typeof o.type === "string" && typeof o.title === "string" && typeof o.summary === "string" && Array.isArray(o.keyPoints) && typeof o.confidence === "number" && Array.isArray(o.tags) && Array.isArray(o.fields) && o.fields.every((f) => !!f && typeof f.label === "string" && typeof f.value === "string");
}
function checkExtraction(x) {
	if (!isExtraction(x)) return {
		valid: false,
		verdict: "review",
		checks: [],
		missing: [],
		empty: true
	};
	const filled = x.fields.filter((f) => f.value.trim());
	const empty = !filled.length && !x.summary.trim() && !x.keyPoints.some((k) => k.trim());
	const tpl = templateByType(x.type);
	const tc = tpl ? checkTemplateFields(tpl, filled) : null;
	const req = tc ? tc.required : REQUIRED_FIELDS[x.type] ?? [];
	const checks = filled.map((f) => ({
		label: f.label,
		value: f.value,
		ok: !/[?…]{2,}|không rõ|không đọc/i.test(f.value) && !tc?.bad.includes(f.label)
	}));
	const missing = req.filter((alts) => !filled.some((f) => alts.split("|").some((a) => norm(f.label).includes(norm(a))))).map((a) => a.split("|")[0]);
	missing.forEach((m) => checks.push({
		label: m,
		value: "",
		ok: false
	}));
	return {
		valid: true,
		verdict: !empty && !missing.length && checks.every((c) => c.ok) && x.confidence >= .6 ? "accept" : "review",
		checks,
		missing,
		empty,
		notes: tc?.notes ?? []
	};
}
var SUGGEST = [
	"Tóm tắt nội dung chính",
	"Có những số tiền nào?",
	"Hạn chót / ngày quan trọng là gì?"
];
/** Chat hỏi đáp với tài liệu (G3-11). onPage: nhảy tới trang được trích dẫn (0-based). */
function DocChat({ doc, onPage }) {
	const ask = useServerFn(aiDocAsk);
	const [msgs, setMsgs] = (0, import_react.useState)([]);
	const [q, setQ] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [quota, setQuota] = (0, import_react.useState)(() => getQuota());
	const end = (0, import_react.useRef)(null);
	const hasText = doc.pages.some((p) => p.text?.trim());
	(0, import_react.useEffect)(() => {
		setMsgs(loadHistory(doc.id));
		setQuota(getQuota());
	}, [doc.id]);
	(0, import_react.useEffect)(() => {
		end.current?.scrollIntoView({ block: "end" });
	}, [msgs.length, busy]);
	const push = (m) => setMsgs((list) => saveHistory(doc.id, [...list, m]));
	async function send(text = q) {
		const question = text.trim();
		if (!question || busy) return;
		if (!hasText) {
			toast("Tài liệu chưa có chữ. Hãy nhận chữ (OCR/AI) trước.");
			return;
		}
		const slot = takeQuotaSlot();
		if (!slot) {
			toast.error(`Đã hết ${quota.limit} lượt hỏi hôm nay. Mai hỏi tiếp nhé.`);
			return;
		}
		setQuota(slot);
		setQ("");
		setBusy(true);
		push({
			role: "user",
			text: question,
			at: Date.now()
		});
		try {
			const r = await ask({ data: {
				question,
				pages: doc.pages.map((p) => (p.text ?? "").slice(0, 5e4)).slice(0, 60)
			} });
			reportAiResult(r);
			if (r.ok) push({
				role: "ai",
				text: r.answer,
				pages: r.pages,
				at: Date.now()
			});
			else {
				refundQuotaSlot();
				setQuota(getQuota());
				push({
					role: "ai",
					text: r.message,
					at: Date.now(),
					error: true
				});
			}
		} catch {
			refundQuotaSlot();
			setQuota(getQuota());
			push({
				role: "ai",
				text: "Không kết nối được AI. Kiểm tra mạng rồi hỏi lại.",
				at: Date.now(),
				error: true
			});
		} finally {
			setBusy(false);
		}
	}
	async function clear() {
		if (!await confirmDialog("Xoá lịch sử hỏi đáp?", {
			message: "Chỉ xoá trên máy này.",
			okText: "Xoá"
		})) return;
		clearHistory(doc.id);
		setMsgs([]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 flex flex-col gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-[0.6875rem] text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"Còn ",
					quota.left,
					"/",
					quota.limit,
					" lượt hỏi hôm nay"
				] }), msgs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => void clear(),
					className: "flex items-center gap-1 font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Xoá lịch sử"]
				})]
			}),
			!hasText && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-[10px] bg-muted p-3 text-xs text-muted-foreground",
				children: "Tài liệu chưa có chữ. Mở “Nhận diện chữ” để đọc chữ các trang, rồi quay lại hỏi."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-h-[42vh] space-y-2 overflow-y-auto",
				"aria-live": "polite",
				children: [
					msgs.length === 0 && hasText && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-center text-xs text-muted-foreground",
							children: "Hỏi bất cứ điều gì về tài liệu này. AI chỉ trả lời từ nội dung tài liệu và ghi rõ trang."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap justify-center gap-1.5",
							children: SUGGEST.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => void send(s),
								className: "rounded-full border border-border px-2.5 py-1 text-[0.6875rem] font-semibold text-primary",
								children: s
							}, s))
						})]
					}),
					msgs.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: m.role === "user" ? "flex justify-end" : "flex justify-start",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `max-w-[88%] rounded-[12px] px-3 py-2 text-sm leading-6 ${m.role === "user" ? "bg-primary text-primary-foreground" : m.error ? "bg-destructive/10 text-destructive" : "bg-muted"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "whitespace-pre-wrap",
								children: m.role === "ai" && !m.error ? splitCitations(m.text).map((part, k) => part.t === "text" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: part.v }, k) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => part.v >= 1 && part.v <= doc.pages.length && onPage?.(part.v - 1),
									className: "mx-0.5 rounded-full bg-card px-1.5 text-[0.6875rem] font-semibold text-primary",
									children: ["Trang ", part.v]
								}, k)) : m.text
							}), m.role === "ai" && !m.error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								"aria-label": "Sao chép câu trả lời",
								onClick: () => {
									navigator.clipboard.writeText(m.text);
									toast("Đã sao chép");
								},
								className: "mt-1 flex items-center gap-1 text-[0.6875rem] text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3" }), " Sao chép"]
							})]
						})
					}, i)),
					busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }), " AI đang đọc tài liệu…"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: end })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					send();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: q,
					onChange: (e) => setQ(e.target.value),
					maxLength: 1e3,
					rows: 2,
					placeholder: "Nhập câu hỏi…",
					disabled: !hasText || quota.left <= 0,
					onKeyDown: (e) => {
						if (e.key === "Enter" && !e.shiftKey) {
							e.preventDefault();
							send();
						}
					},
					className: "min-w-0 flex-1 resize-none rounded-[10px] border border-input bg-background px-3 py-2 text-sm outline-none focus:border-primary"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "icon",
					"aria-label": "Gửi câu hỏi",
					disabled: busy || !q.trim() || !hasText || quota.left <= 0,
					children: busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {})
				})]
			})
		]
	});
}
/** G3-15: dịch đè bản dịch lên ảnh trang, xem trước và xuất ảnh/PDF. */
function TranslateOverlayPanel({ doc, page, lang }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [out, setOut] = (0, import_react.useState)(null);
	const base = `${safeName(doc.name)}-trang-${page + 1}-dich`;
	async function run() {
		setBusy(true);
		setOut(null);
		try {
			const { translateImage, renderOverlay } = await import("./translate-overlay-Cd_yt33V.mjs");
			const src = doc.pages[page].src;
			const r = await translateImage(src, lang);
			if (r.error) toast.error(r.error);
			if (r.blocks.length) setOut(await renderOverlay(src, r.blocks));
		} catch (e) {
			showError(e);
		} finally {
			setBusy(false);
		}
	}
	async function addPage() {
		if (!out) return;
		const after = doc.pages[page]?.id;
		const added = {
			id: crypto.randomUUID(),
			src: out,
			orig: out,
			edit: {
				rotation: 0,
				filter: "original",
				brightness: 0,
				contrast: 0
			}
		};
		await mutateDoc(doc.id, (d) => {
			const pages = [...d.pages];
			const at = pages.findIndex((x) => x.id === after);
			pages.splice(at < 0 ? pages.length : at + 1, 0, added);
			return {
				...d,
				pages
			};
		}, true);
		toast.success("Đã thêm trang dịch ngay sau trang gốc");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 rounded-[12px] border border-border p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "glass",
			size: "sm",
			className: "w-full",
			disabled: busy,
			onClick: () => void run(),
			children: [
				busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Languages, {}),
				" ",
				busy ? "Đang đọc chữ và dịch…" : `Dịch đè lên ảnh trang ${page + 1}`
			]
		}), out && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: out,
			alt: "Trang đã dịch đè",
			className: "mt-3 w-full rounded-[10px] border border-border"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 grid grid-cols-3 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					size: "sm",
					onClick: () => void dataUrlToBlob(out).then((b) => download(b, `${base}.jpg`)),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), " Ảnh"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					size: "sm",
					onClick: () => void imagesToPdf([out], { name: base }).then((b) => download(b, `${base}.pdf`)),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {}), " PDF"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					size: "sm",
					onClick: () => void addPage(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Thêm trang"]
				})
			]
		})] })]
	});
}
var TABS = [
	["extract", "Trích xuất"],
	["handwrite", "Viết tay"],
	["summarize", "Tóm tắt"],
	["translate", "Dịch"],
	["solve", "Giải bài"],
	["ask", "Hỏi đáp"]
];
var LANGS = [
	"tiếng Anh",
	"tiếng Việt",
	"tiếng Trung",
	"tiếng Nhật",
	"tiếng Hàn",
	"tiếng Pháp"
];
var DEFAULT_NAME = /^\S.* \d{2}-\d{2} \d{2}:\d{2}$/;
/** Ảnh gửi cho AI được thu nhỏ để nhanh và tiết kiệm (tối đa 4 trang). */
var prepImages = (doc, pages) => Promise.all(pages.slice(0, 4).map((i) => compress(doc.pages[i].src, 1400, .75)));
var withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(/* @__PURE__ */ new Error("timeout")), ms))]);
var RETAKE_TIPS = [
	"Đưa điện thoại gần hơn",
	"Giữ điện thoại thẳng, song song với giấy",
	"Tránh đèn phản chiếu lên giấy",
	"Đưa toàn bộ biên bản vào khung",
	"Giữ điện thoại ổn định khi chụp"
];
function AiPanel({ doc, active, initial = "extract", autoRun = false }) {
	const ran = (0, import_react.useRef)(false);
	const [tab, setTab] = (0, import_react.useState)(initial);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [blocked, setBlocked] = (0, import_react.useState)("");
	const [quality, setQuality] = (0, import_react.useState)([]);
	const [sel, setSel] = (0, import_react.useState)([active]);
	const [failure, setFailure] = (0, import_react.useState)(null);
	const [check, setCheck] = (0, import_react.useState)(null);
	const [stage, setStage] = (0, import_react.useState)("");
	const [preview, setPreview] = (0, import_react.useState)(false);
	const [res, setRes] = (0, import_react.useState)(null);
	const [lang, setLang] = (0, import_react.useState)(LANGS[0]);
	const [tpl, setTpl] = (0, import_react.useState)("");
	const [out, setOut] = (0, import_react.useState)({});
	const extractFn = useQueuedServerFn(aiExtract, "Trích xuất AI");
	const textFn = useQueuedServerFn(aiText, "Xử lý chữ AI");
	const pages = sel.length ? [...sel].sort((a, b) => a - b) : [active];
	const toggle = (i) => setSel((s) => s.includes(i) ? s.filter((x) => x !== i) : s.length >= 4 ? (toast("Chọn tối đa 4 trang"), s) : [...s, i]);
	const fields = Object.entries(doc.fields ?? {});
	function fail(r) {
		toast.error(r.message);
		if (r.code === 402 || r.code === 403) setBlocked(r.message);
	}
	/** Image Quality Gate: trả về false nếu người dùng chọn chụp lại. */
	async function gate(session) {
		setQuality([]);
		const bad = (await Promise.all(pages.map(async (i) => ({
			i,
			r: await checkQuality(doc.pages[i].src).catch(() => null)
		})))).filter((x) => x.r && x.r.level !== "ok");
		bad.forEach((x) => logScan({
			scanSessionId: session,
			code: x.r.issues[0].code,
			message: `Trang ${x.i + 1}: ${x.r.level}`,
			imageResolution: `${x.r.metrics.width}x${x.r.metrics.height}`,
			imageQualityScore: x.r.score,
			blurScore: x.r.metrics.blur,
			skewAngle: x.r.metrics.skew,
			glareScore: x.r.metrics.glare,
			meta: x.r.metrics
		}));
		setQuality(bad.flatMap((x) => x.r.issues.map((s) => `Trang ${x.i + 1}: ${s.message}`)));
		const rejected = bad.filter((x) => x.r.level === "reject");
		if (!rejected.length) return true;
		return confirmDialog("Ảnh chưa đạt chất lượng", {
			message: rejected.flatMap((x) => x.r.issues.filter((s) => s.level === "reject").map((s) => `Trang ${x.i + 1}: ${s.message}`)).join("\n") + "\n\nNên chụp lại để AI đọc chính xác hơn.",
			okText: "Vẫn gửi AI"
		});
	}
	/** Ghi kết quả trích xuất (AI hoặc trên máy) vào tài liệu + hiện bảng kiểm. */
	async function applyExtraction(x, checked, local) {
		setCheck(checked);
		const next = {
			...doc,
			kind: x.type,
			fields: Object.fromEntries(x.fields.filter((f) => f.value.trim()).map((f) => [f.label, f.value])),
			tags: [.../* @__PURE__ */ new Set([...doc.tags ?? [], ...x.tags])]
		};
		x.tags.forEach(ensureTag);
		if (DEFAULT_NAME.test(doc.name) && x.title) next.name = x.title;
		if ((doc.folder === "Chung" || !doc.folder) && x.type !== "Khác") {
			if (!getLibrary().folders.includes(x.type.replace(/\//g, "-"))) createFolder(x.type.replace(/\//g, "-"));
			next.folder = x.type.replace(/\//g, "-");
		}
		await mutateDoc(doc.id, (d) => ({
			...d,
			kind: next.kind,
			fields: next.fields ?? {},
			tags: [.../* @__PURE__ */ new Set([...d.tags ?? [], ...x.tags])],
			name: d.name === doc.name ? next.name : d.name,
			folder: d.folder === doc.folder ? next.folder : d.folder
		}), true);
		setOut((o) => ({
			...o,
			extract: x.summary
		}));
		setRes({
			title: x.title,
			type: x.type,
			points: x.keyPoints ?? [],
			conf: x.confidence ?? 0,
			local
		});
		if (local) toast.warning("AI không dùng được — đã trích cơ bản trên máy (không AI).", { description: "Hãy kiểm tra lại các trường." });
		else if (checked.verdict === "review") toast.warning("Một số thông tin chưa được nhận diện chính xác. Vui lòng kiểm tra lại.");
		else toast.success(`Nhận dạng: ${x.type}`, { description: next.name !== doc.name ? `Đã đặt tên "${next.name}"` : void 0 });
	}
	/** AI-03: đường không AI — chữ OCR sẵn có của trang (hoặc OCR trên máy) → trường cơ bản theo mẫu. false = không đọc được gì. */
	async function extractLocally(why) {
		console.warn("extract: AI không dùng được, trích trên máy —", why);
		setStage("Đang đọc trên máy (không AI)…");
		let text = pages.map((i) => doc.pages[i].text ?? "").join("\n").trim();
		if (!text) {
			const { recognize } = await import("./ocr-CLa2avjZ.mjs").then((n) => n.r).then((n) => n.r);
			text = (await Promise.all(pages.map((i) => recognize(doc.pages[i].src).catch(() => "")))).join("\n").trim();
		}
		const { extractFromText } = await import("./offline-extract-CYJH6W2G.mjs").then((n) => n.n);
		const x = extractFromText(text, tpl || void 0);
		const checked = checkExtraction(x);
		if (checked.empty) return false;
		await applyExtraction(x, checked, true);
		return true;
	}
	async function extract() {
		if (typeof navigator !== "undefined" && navigator.onLine === false) {
			setBusy(true);
			setFailure(null);
			setCheck(null);
			try {
				if (!await extractLocally("đang mất mạng")) setFailure({
					code: "AI_EMPTY_RESULT",
					retake: true,
					diag: []
				});
			} catch (e) {
				console.error(e);
				setFailure({
					code: "AI_EXTRACTION_FAILED",
					retake: true,
					diag: []
				});
			} finally {
				setBusy(false);
				setStage("");
			}
			return;
		}
		if (/cccd|căn cước|hộ chiếu|cmnd/i.test(`${doc.kind} ${doc.name} ${docText(doc)}`) && !await confirmDialog("Gửi giấy tờ tuỳ thân cho AI?", {
			message: "Ảnh có thể chứa thông tin cá nhân (CCCD/hộ chiếu). Ảnh chỉ được dùng để đọc thông tin, không lưu lại trên máy chủ.",
			okText: "Gửi"
		})) return;
		setBusy(true);
		setFailure(null);
		setCheck(null);
		const session = newScanSession();
		const q0 = await checkQuality(doc.pages[pages[0]].src).catch(() => null);
		const base = {
			scanSessionId: session,
			imageResolution: q0 ? `${q0.metrics.width}x${q0.metrics.height}` : void 0,
			imageQualityScore: q0?.score,
			blurScore: q0?.metrics.blur,
			skewAngle: q0?.metrics.skew,
			glareScore: q0?.metrics.glare
		};
		try {
			if (!await gate(session)) {
				setFailure({
					code: "SCAN_IMAGE_TOO_BLURRY",
					retake: true,
					diag: quality
				});
				return;
			}
			let r = null;
			let lastFail = null;
			let lastCode = "AI_EXTRACTION_FAILED";
			let checked = null;
			for (let attempt = 1; attempt <= 2; attempt++) {
				const t0 = Date.now();
				try {
					setStage(attempt === 1 ? "AI đang đọc…" : "Đang làm rõ ảnh và đọc lại…");
					const images = attempt === 1 ? await prepImages(doc, pages) : await Promise.all(pages.slice(0, 4).map((i) => enhanceForOcr(doc.pages[i].src)));
					r = await withTimeout(extractFn({ data: {
						images,
						...tpl ? { template: tpl } : {}
					} }), 9e4);
				} catch (e) {
					r = {
						ok: false,
						code: 0,
						message: String(e?.message ?? "")
					};
					console.error(e);
				}
				if (r.ok) {
					checked = checkExtraction(r.data);
					if (checked.valid && !checked.empty) {
						logScan({
							...base,
							code: "AI_OK",
							message: checked.verdict,
							attempt,
							retryCount: attempt - 1,
							aiStatus: "ok",
							ms: Date.now() - t0
						});
						break;
					}
					lastCode = checked.valid ? "AI_EMPTY_RESULT" : "AI_INVALID_RESPONSE";
				} else {
					lastCode = classifyAiFailure(r.code, r.message);
					lastFail = {
						ok: false,
						code: r.code
					};
				}
				logScan({
					...base,
					code: lastCode,
					message: r.ok ? lastCode : r.message,
					attempt,
					retryCount: attempt - 1,
					aiStatus: "fail",
					ms: Date.now() - t0
				});
				if (!r.ok && (r.code === 402 || r.code === 403)) setBlocked(r.message);
				if (attempt <= 1 && isAutoRetryable(lastCode)) {
					toast("AI đọc chưa được, đang làm rõ ảnh và thử lại…");
					continue;
				}
				r = null;
				break;
			}
			if ((!r || !r.ok) && lastFail && aiUnavailable(lastFail) && await extractLocally(`mã ${lastFail.code}`)) return;
			if (!r || !r.ok || !checked) {
				setFailure({
					code: lastCode,
					retake: isAutoRetryable(lastCode),
					diag: quality
				});
				return;
			}
			await applyExtraction(r.data, checked, false);
		} catch (e) {
			console.error(e);
			logScan({
				...base,
				code: "AI_EXTRACTION_FAILED",
				message: String(e?.message ?? e),
				aiStatus: "crash"
			});
			setFailure({
				code: "AI_EXTRACTION_FAILED",
				retake: true,
				diag: quality
			});
		} finally {
			setBusy(false);
			setStage("");
		}
	}
	(0, import_react.useEffect)(() => {
		if (autoRun && !ran.current) {
			ran.current = true;
			extract();
		}
	}, [autoRun]);
	async function textTask(task) {
		setBusy(true);
		try {
			const text = pages.map((i) => doc.pages[i].text ?? "").join("\n").trim();
			const r = await textFn({ data: {
				task,
				lang,
				...text && task !== "handwrite" ? { text } : { images: await prepImages(doc, pages) }
			} });
			if (!r.ok) return fail(r);
			setOut((o) => ({
				...o,
				[task]: r.text
			}));
		} catch (e) {
			toast.error("Không gửi được yêu cầu. Kiểm tra mạng rồi thử lại.");
			console.error(e);
		} finally {
			setBusy(false);
		}
	}
	const setField = (k, v, nk = k) => {
		mutateDoc(doc.id, (d) => {
			const entries = Object.entries(d.fields ?? {});
			const next = entries.some(([a]) => a === k) ? entries.flatMap(([a, b]) => a === k ? v === null ? [] : [[nk, v]] : [[a, b]]) : [...entries, [nk, v ?? ""]];
			return {
				...d,
				fields: Object.fromEntries(next)
			};
		});
	};
	const exportCsv = () => {
		download(rowsToXlsx([["Trường", "Giá trị"], ...fields.map(([k, v]) => [k, v])], "Thong tin", false), `${safeName(doc.name)}-thong-tin.xlsx`);
	};
	const result = out[tab];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-h-[70vh] overflow-y-auto",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-1 sm:grid-cols-6 rounded-[12px] bg-muted p-1",
				children: TABS.map(([t, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setTab(t),
					className: `rounded-[9px] py-1.5 text-xs font-semibold ${tab === t ? "bg-card text-primary shadow-sm" : "text-muted-foreground"}`,
					children: l
				}, t))
			}),
			tab === "ask" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocChat, { doc }),
			tab !== "ask" && doc.pages.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-1.5 text-[0.6875rem] font-semibold text-muted-foreground",
					children: [
						"Chọn trang gửi cho AI (",
						pages.length,
						"/4)"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 overflow-x-auto pb-1",
					children: doc.pages.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => toggle(i),
						"aria-pressed": sel.includes(i),
						className: `relative h-16 w-12 shrink-0 overflow-hidden rounded-[8px] border-2 ${sel.includes(i) ? "border-primary" : "border-transparent opacity-60"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: p.thumb ?? p.src,
							alt: `Trang ${i + 1}`,
							className: "size-full object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute bottom-0 inset-x-0 bg-background/80 text-[0.625rem] font-semibold",
							children: i + 1
						})]
					}, i))
				})]
			}),
			tab === "extract" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				role: "radiogroup",
				"aria-label": "Mẫu giấy tờ",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 text-[0.6875rem] font-semibold text-muted-foreground",
					children: "Mẫu giấy tờ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: [["", "Tự nhận"], ...VN_TEMPLATES.map((t) => [t.id, t.label])].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						role: "radio",
						"aria-checked": tpl === id,
						onClick: () => setTpl(id),
						className: `rounded-full border px-2.5 py-1 text-[0.6875rem] font-semibold ${tpl === id ? "border-primary text-primary" : "border-border text-muted-foreground"}`,
						children: label
					}, id))
				})]
			}),
			tab === "translate" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-1.5",
				children: LANGS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setLang(l),
					className: `rounded-full border px-2.5 py-1 text-[0.6875rem] font-semibold ${lang === l ? "border-primary text-primary" : "border-border text-muted-foreground"}`,
					children: l
				}, l))
			}),
			tab === "translate" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TranslateOverlayPanel, {
				doc,
				page: pages[0],
				lang
			}),
			quality.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 list-disc space-y-0.5 rounded-[10px] bg-muted p-3 pl-6 text-xs text-muted-foreground",
				children: quality.map((q, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: q }, i))
			}),
			blocked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 rounded-[10px] bg-destructive/10 p-3 text-xs text-destructive",
				children: blocked
			}),
			tab !== "ask" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "mt-3 w-full",
				disabled: busy || !!blocked,
				onClick: () => tab === "extract" ? extract() : textTask(tab),
				children: [
					busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}),
					" ",
					busy ? stage || "AI đang đọc…" : TABS.find(([t]) => t === tab)[1] + " bằng AI"
				]
			}),
			tab === "extract" && failure && !busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "alert",
				className: "mt-3 rounded-[12px] border border-destructive/30 bg-destructive/10 p-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-1.5 font-semibold text-destructive",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4" }), " Chưa thể trích xuất"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs",
						children: [
							SCAN_ERRORS[failure.code].message,
							" ",
							SCAN_ERRORS[failure.code].hint
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[0.6875rem] font-semibold text-muted-foreground",
						children: "Nguyên nhân có thể:"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "list-disc pl-5 text-xs text-muted-foreground",
						children: (failure.diag.length ? failure.diag : [
							"Ảnh bị mờ",
							"Biên bản bị nghiêng",
							"Có vùng chói",
							"Ánh sáng không đủ",
							"Chữ quá nhỏ"
						]).map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t }, i))
					}),
					failure.retake && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[0.6875rem] font-semibold text-muted-foreground",
						children: "Khi chụp lại:"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "list-disc pl-5 text-xs text-muted-foreground",
						children: RETAKE_TIPS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t }, t))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-[0.625rem] text-muted-foreground",
						children: ["Mã lỗi: ", failure.code]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/scan",
									search: { doc: doc.id },
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {}), " Chụp lại"]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "glass",
								disabled: !!blocked,
								onClick: () => void extract(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), " Thử lại"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "ghost",
								className: "col-span-2",
								onClick: () => setPreview((v) => !v),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {}),
									" ",
									preview ? "Ẩn ảnh" : "Xem ảnh đã chụp"
								]
							})
						]
					})
				]
			}),
			tab === "extract" && (preview || check && res) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				children: [check && res && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "ghost",
					className: "w-full",
					onClick: () => setPreview((v) => !v),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {}),
						" ",
						preview ? "Ẩn ảnh gốc" : "Xem ảnh gốc để đối chiếu"
					]
				}), preview && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex gap-2 overflow-x-auto",
					children: pages.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: doc.pages[i].orig || doc.pages[i].src,
						alt: `Ảnh gốc trang ${i + 1}`,
						className: "max-h-[45vh] rounded-[10px] border object-contain"
					}, i))
				})]
			}),
			tab === "extract" && check && res && check.checks.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 rounded-[12px] bg-muted p-3 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 font-semibold",
						children: check.verdict === "accept" ? "Kết quả đã qua kiểm tra" : "⚠️ Một số thông tin chưa được nhận diện chính xác. Vui lòng kiểm tra lại."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-0.5",
						children: check.checks.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-1.5",
							children: [
								c.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-primary" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: "size-3.5 text-destructive" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold",
									children: c.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate text-muted-foreground",
									children: c.value || "chưa có — hãy bổ sung bên dưới"
								})
							]
						}, i))
					}),
					check.notes?.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-semibold text-destructive",
						children: n
					}, n)),
					check.missing.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "glass",
						className: "mt-2 w-full",
						onClick: () => check.missing.forEach((m) => !fields.some(([k]) => k === m) && setField(m, "")),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Thêm trường còn thiếu để sửa"]
					})
				]
			}),
			tab === "extract" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 space-y-2",
				children: [
					res && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "document-row space-y-2 rounded-[12px] p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-1.5 text-[0.6875rem] font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-secondary px-2 py-0.5 text-primary",
									children: res.type
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: res.local ? "Đọc trên máy (không AI)" : `Độ chắc chắn ${Math.round(res.conf * 100)}%`
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "min-w-0 flex-1 text-sm font-semibold",
									children: res.title
								}), res.title && doc.name !== res.title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "glass",
									onClick: () => void mutateDoc(doc.id, (d) => ({
										...d,
										name: res.title
									}), true).then(() => toast.success("Đã đổi tên")),
									children: "Dùng tên này"
								})]
							}),
							result && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: result
							}),
							res.points.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "list-disc space-y-0.5 pl-4 text-xs",
								children: res.points.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t }, i))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "ghost",
								className: "w-full",
								onClick: () => {
									navigator.clipboard.writeText([
										res.title,
										result,
										...res.points.map((t) => "- " + t)
									].filter(Boolean).join("\n"));
									toast("Đã sao chép nội dung chính");
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), " Chép nội dung chính"]
							})
						]
					}),
					fields.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "document-row rounded-[12px] p-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									defaultValue: k,
									onBlur: (e) => e.target.value.trim() && e.target.value !== k && setField(k, v, e.target.value.trim()),
									className: "min-w-0 flex-1 bg-transparent text-[0.6875rem] font-semibold text-muted-foreground outline-none"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									"aria-label": "Sao chép",
									onClick: () => {
										navigator.clipboard.writeText(v);
										toast("Đã sao chép " + k);
									},
									className: "p-1 text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									"aria-label": "Xoá trường",
									onClick: () => setField(k, null),
									className: "p-1 text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							defaultValue: v,
							onBlur: (e) => e.target.value !== v && setField(k, e.target.value),
							className: "mt-1 h-9 text-sm"
						})]
					}, k)),
					fields.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2 pt-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "glass",
								size: "sm",
								onClick: () => setField(`Trường ${fields.length + 1}`, ""),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Thêm"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "glass",
								size: "sm",
								onClick: () => {
									navigator.clipboard.writeText(fields.map(([k, v]) => `${k}: ${v}`).join("\n"));
									toast("Đã sao chép tất cả");
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), " Chép hết"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "glass",
								size: "sm",
								onClick: exportCsv,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, {}), " Excel"]
							})
						]
					}),
					!fields.length && !busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-4 text-center text-xs text-muted-foreground",
						children: "AI sẽ nhận dạng loại giấy tờ, lấy các thông tin quan trọng, tự đặt tên và gợi ý thẻ, thư mục."
					})
				]
			}),
			tab !== "extract" && tab !== "ask" && result && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-4 max-h-[40vh] overflow-auto whitespace-pre-wrap rounded-[12px] bg-muted p-3 font-sans text-sm leading-6",
					children: result
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					size: "sm",
					className: "mt-2 w-full",
					onClick: () => {
						navigator.clipboard.writeText(result);
						toast("Đã sao chép");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), " Sao chép"]
				}),
				tab === "handwrite" && pages.length === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					size: "sm",
					className: "mt-2 w-full",
					onClick: () => void mutateDoc(doc.id, (d) => ({
						...d,
						pages: d.pages.map((p) => p.id === doc.pages[pages[0]]?.id ? {
							...p,
							text: result.replace(/⟦\?⟧/g, "")
						} : p)
					}), true).then(() => toast.success("Đã lưu làm chữ của trang")),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), " Lưu làm chữ của trang"]
				})
			] })
		]
	});
}
/** Dependency-free .pptx / Markdown / TXT export: one page image per slide, text in speaker notes. */
var x = (s) => s.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
var W = 12192e3;
var H = 6858e3;
/** Fit image (w×h px) inside slide, centered. Pure. */
function fitBox(w, h) {
	const s = Math.min(W / w, H / h);
	const cx = Math.round(w * s), cy = Math.round(h * s);
	return {
		x: Math.round((W - cx) / 2),
		y: Math.round((H - cy) / 2),
		cx,
		cy
	};
}
var NS = "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\"";
var REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
var rels = (items) => `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${items.map(([id, t, tg]) => `<Relationship Id="${id}" Type="${REL}/${t}" Target="${tg}"/>`).join("")}</Relationships>`;
var emptyTree = `<p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:spTree></p:cSld>`;
function slidesToPptx(slides, title) {
	const f = [];
	slides.length;
	f.push(["[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="jpeg" ContentType="image/jpeg"/><Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/><Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/><Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/><Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/><Override PartName="/ppt/theme/theme2.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/><Override PartName="/ppt/notesMasters/notesMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.notesMaster+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>${slides.map((_, i) => `<Override PartName="/ppt/slides/slide${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/><Override PartName="/ppt/notesSlides/notesSlide${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.notesSlide+xml"/>`).join("")}</Types>`]);
	f.push(["_rels/.rels", rels([[
		"rId1",
		"officeDocument",
		"ppt/presentation.xml"
	]]).replace("</Relationships>", `<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>`)]);
	f.push(["docProps/core.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>${x(title)}</dc:title><dc:creator>Ghi Nhanh</dc:creator></cp:coreProperties>`]);
	f.push(["ppt/presentation.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentation ${NS}><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:notesMasterIdLst><p:notesMasterId r:id="rId3"/></p:notesMasterIdLst><p:sldIdLst>${slides.map((_, i) => `<p:sldId id="${256 + i}" r:id="rId${10 + i}"/>`).join("")}</p:sldIdLst><p:sldSz cx="${W}" cy="${H}"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>`]);
	f.push(["ppt/_rels/presentation.xml.rels", rels([
		[
			"rId1",
			"slideMaster",
			"slideMasters/slideMaster1.xml"
		],
		[
			"rId2",
			"theme",
			"theme/theme1.xml"
		],
		[
			"rId3",
			"notesMaster",
			"notesMasters/notesMaster1.xml"
		],
		...slides.map((_, i) => [
			`rId${10 + i}`,
			"slide",
			`slides/slide${i + 1}.xml`
		])
	])]);
	f.push(["ppt/slideMasters/slideMaster1.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldMaster ${NS}>${emptyTree}<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/><p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst></p:sldMaster>`]);
	f.push(["ppt/slideMasters/_rels/slideMaster1.xml.rels", rels([[
		"rId1",
		"slideLayout",
		"../slideLayouts/slideLayout1.xml"
	], [
		"rId2",
		"theme",
		"../theme/theme1.xml"
	]])]);
	f.push(["ppt/slideLayouts/slideLayout1.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldLayout ${NS} type="blank">${emptyTree}<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>`]);
	f.push(["ppt/slideLayouts/_rels/slideLayout1.xml.rels", rels([[
		"rId1",
		"slideMaster",
		"../slideMasters/slideMaster1.xml"
	]])]);
	f.push(["ppt/notesMasters/notesMaster1.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:notesMaster ${NS}>${emptyTree}<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/></p:notesMaster>`]);
	f.push(["ppt/notesMasters/_rels/notesMaster1.xml.rels", rels([[
		"rId1",
		"theme",
		"../theme/theme2.xml"
	]])]);
	f.push(["ppt/theme/theme1.xml", THEME]);
	f.push(["ppt/theme/theme2.xml", THEME]);
	slides.forEach((s, i) => {
		const k = i + 1, b = fitBox(s.w, s.h);
		f.push([`ppt/media/image${k}.jpeg`, s.jpeg]);
		f.push([`ppt/slides/slide${k}.xml`, `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld ${NS}><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/><p:pic><p:nvPicPr><p:cNvPr id="2" name="Trang ${k}"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="rId2"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x="${b.x}" y="${b.y}"/><a:ext cx="${b.cx}" cy="${b.cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>`]);
		f.push([`ppt/slides/_rels/slide${k}.xml.rels`, rels([
			[
				"rId1",
				"slideLayout",
				"../slideLayouts/slideLayout1.xml"
			],
			[
				"rId2",
				"image",
				`../media/image${k}.jpeg`
			],
			[
				"rId3",
				"notesSlide",
				`../notesSlides/notesSlide${k}.xml`
			]
		])]);
		const paras = (s.text ?? "").split("\n").map((l) => `<a:p><a:r><a:rPr lang="vi-VN"/><a:t>${x(l)}</a:t></a:r></a:p>`).join("") || "<a:p/>";
		f.push([`ppt/notesSlides/notesSlide${k}.xml`, `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:notes ${NS}><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/><p:sp><p:nvSpPr><p:cNvPr id="2" name="Ghi chú"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/>${paras}</p:txBody></p:sp></p:spTree></p:cSld></p:notes>`]);
		f.push([`ppt/notesSlides/_rels/notesSlide${k}.xml.rels`, rels([[
			"rId1",
			"notesMaster",
			"../notesMasters/notesMaster1.xml"
		], [
			"rId2",
			"slide",
			`../slides/slide${k}.xml`
		]])]);
	});
	return zip(f, "application/vnd.openxmlformats-officedocument.presentationml.presentation");
}
/** Markdown: title, one section per page with its recognised text. Pure. */
function docToMarkdown(name, pages) {
	const esc = (l) => l.replace(/^(\s*)([#>*+-]|\d+\.)(\s)/, "$1\\$2$3");
	return `# ${name}\n\n` + pages.map((p, i) => `## Trang ${i + 1}\n\n${(p.text ?? "").trim() ? (p.text ?? "").trim().split("\n").map(esc).join("  \n") : "_(chưa nhận chữ)_"}\n`).join("\n");
}
/** Plain text with page separators; CRLF + BOM so Windows Notepad shows Vietnamese right. Pure. */
function docToTxt(pages) {
	return "﻿" + pages.map((p, i) => `--- Trang ${i + 1} ---\r\n${(p.text ?? "").trim().replace(/\r?\n/g, "\r\n")}`).join("\r\n\r\n") + "\r\n";
}
/** Data URL → JPEG bytes + size (browser). */
async function pageToSlide(src, text) {
	const img = new Image();
	img.src = src;
	await img.decode();
	const c = document.createElement("canvas");
	c.width = img.naturalWidth;
	c.height = img.naturalHeight;
	const g = c.getContext("2d");
	g.fillStyle = "#fff";
	g.fillRect(0, 0, c.width, c.height);
	g.drawImage(img, 0, 0);
	const blob = await new Promise((r) => c.toBlob((b) => r(b), "image/jpeg", .88));
	return {
		jpeg: new Uint8Array(await blob.arrayBuffer()),
		w: c.width,
		h: c.height,
		text
	};
}
var THEME = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Ghi Nhanh"><a:themeElements><a:clrScheme name="G"><a:dk1><a:srgbClr val="000000"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="1F2937"/></a:dk2><a:lt2><a:srgbClr val="F3F4F6"/></a:lt2><a:accent1><a:srgbClr val="2563EB"/></a:accent1><a:accent2><a:srgbClr val="16A34A"/></a:accent2><a:accent3><a:srgbClr val="EA580C"/></a:accent3><a:accent4><a:srgbClr val="9333EA"/></a:accent4><a:accent5><a:srgbClr val="0891B2"/></a:accent5><a:accent6><a:srgbClr val="DC2626"/></a:accent6><a:hlink><a:srgbClr val="2563EB"/></a:hlink><a:folHlink><a:srgbClr val="7C3AED"/></a:folHlink></a:clrScheme><a:fontScheme name="G"><a:majorFont><a:latin typeface="Arial"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="Arial"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme><a:fmtScheme name="G"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst><a:lnStyleLst><a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>`;
/** G4-21: send a document to other services (email, Zalo, system share). Pure helpers + thin browser glue. */
/** mailto: link with subject/body; body trimmed so the URL stays under common client limits (~1800 chars). */
function mailtoUrl(opts) {
	const to = (opts.to ?? "").split(/[,;\s]+/).filter((e) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)).join(",");
	let body = opts.body ?? "";
	const base = `mailto:${encodeURIComponent(to).replace(/%2C/g, ",")}?subject=${encodeURIComponent(opts.subject)}`;
	const max = 1800 - base.length - 6;
	while (body && encodeURIComponent(body).length > max) body = body.slice(0, Math.floor(body.length * .9));
	if (body !== (opts.body ?? "")) body = body.trimEnd() + "…";
	return body ? `${base}&body=${encodeURIComponent(body)}` : base;
}
/** Zalo share page for a public link (Zalo has no web API for files; files go through the system share sheet). */
function zaloShareUrl(link) {
	return `https://zalo.me/share?url=${encodeURIComponent(link)}`;
}
/** Zalo trên máy tính chạy ở web: kéo tệp đã tải vào khung chat (Zalo không có API gửi tệp từ web khác). */
var ZALO_WEB_URL = "https://chat.zalo.me/";
/** Default message body for a document. */
function sendMessage(name, pages, link) {
	return [
		`Gửi bạn tài liệu "${name}" (${pages} trang).`,
		link ? `Xem tại: ${link}` : "Tệp PDF đính kèm.",
		"",
		"— Gửi từ Ghi Nhanh"
	].join("\n");
}
/**
* Send a file. With a share sheet (phones), files are attached directly — the user picks Mail, Zalo, Messenger…
* Without it (desktop), the file is saved and the mail app opens so the user attaches it.
*/
async function sendFile(target, blob, name, meta) {
	const file = new File([blob], name, { type: blob.type || "application/pdf" });
	const text = sendMessage(meta.title, meta.pages, meta.link);
	if (target === "zalo" && meta.link) {
		window.open(zaloShareUrl(meta.link), "_blank", "noopener");
		return "shared";
	}
	if (canShareThisFile(file)) {
		if (target === "email" && meta.to) navigator.clipboard?.writeText(meta.to).then(() => {
			toast.info(`Đã chép ${meta.to} — dán vào ô Người nhận`);
		}, () => {
			toast.info(`Người nhận: ${meta.to} — nhập vào ô Người nhận`);
		});
		const r = await tryShare(file, {
			title: meta.title,
			text
		});
		if (r === "shared") return "shared";
		if (r === "cancelled") return "cancelled";
		if (r === "needs-tap") {
			offerTap(file, {
				title: meta.title,
				text
			}, download);
			return "pending";
		}
	}
	download(blob, name);
	if (target === "email") {
		window.location.href = mailtoUrl({
			to: meta.to,
			subject: meta.title,
			body: sendMessage(meta.title, meta.pages, meta.link) + `\n\n(Đính kèm tệp ${name} vừa tải về.)`
		});
		toast.info("Đã tải PDF — đính kèm vào thư vừa mở");
	} else if (target === "zalo") toast(`Đã tải “${name}”`, {
		description: "Mở Zalo trên máy tính rồi kéo tệp vừa tải vào khung chat.",
		duration: 2e4,
		action: {
			label: "Mở Zalo",
			onClick: () => {
				window.open(ZALO_WEB_URL, "_blank", "noopener");
			}
		},
		actionButtonStyle: {
			minHeight: 40,
			padding: "0 14px",
			fontSize: 14,
			fontWeight: 600
		}
	});
	else toast.info("Máy này không có bảng chia sẻ — đã tải PDF về");
	return "fallback";
}
/** TF-03: "Lưu vào thư mục" — nhớ thư mục mặc định; chỉ hiện khi trình duyệt hỗ trợ (Chrome/Edge PC). */
function SaveFolderRow({ getBlob, name, busy, onBusy, onError }) {
	const [ok, setOk] = (0, import_react.useState)(false);
	const [folder, setFolder] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!folderSupported()) return;
		setOk(true);
		savedFolder().then((h) => setFolder(h?.name ?? null));
	}, []);
	if (!ok) return null;
	async function save(change) {
		onBusy(true);
		try {
			const dir = await folderForSave({ change });
			if (!dir) {
				toast("Chưa lưu: bạn chưa chọn thư mục hoặc chưa cho phép ghi.");
				return;
			}
			setFolder(dir.name);
			const used = await writeToFolder(dir, await getBlob(), name);
			toast.success(`Đã lưu “${used}” vào thư mục “${dir.name}”`);
		} catch (e) {
			if (e?.name && /NotAllowed|Security|Quota|NotFound|InvalidState/.test(e.name)) {
				toast.error(folderError(e));
				if (/NotFound|InvalidState/.test(e.name)) {
					await forgetFolder();
					setFolder(null);
				}
			} else onError(e);
		} finally {
			onBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-2 flex gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			className: "min-w-0 flex-1",
			disabled: busy,
			variant: "glass",
			onClick: () => void save(false),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderDown, { className: "shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate",
				children: folder ? `Lưu vào thư mục “${folder}”` : "Lưu vào thư mục…"
			})]
		}), folder && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			disabled: busy,
			variant: "glass",
			"aria-label": "Đổi thư mục lưu",
			onClick: () => void save(true),
			children: "Đổi"
		})]
	});
}
var load = (src) => new Promise((ok, bad) => {
	const i = new Image();
	i.onload = () => ok(i);
	i.onerror = () => bad(/* @__PURE__ */ new Error("Không đọc được ảnh trang"));
	i.src = src;
});
var toBlob = (c, type, q) => new Promise((ok, bad) => c.toBlob((b) => b ? ok(b) : bad(/* @__PURE__ */ new Error("Ảnh quá lớn để tạo")), type, q));
/** Sharp lossless PNG of one page. */
async function pageToPng(src) {
	const i = await load(src);
	const c = document.createElement("canvas");
	c.width = i.naturalWidth;
	c.height = i.naturalHeight;
	c.getContext("2d").drawImage(i, 0, 0);
	const b = await toBlob(c, "image/png");
	c.width = 0;
	return b;
}
/** All pages stacked into one tall JPG for messaging apps; width capped and total height kept under canvas limits. */
async function pagesToLongImage(srcs, width = 1080) {
	const imgs = await Promise.all(srcs.map(load));
	const gap = 16;
	let w = width;
	let h = imgs.reduce((s, i) => s + Math.round(i.naturalHeight * (w / i.naturalWidth)), 0) + gap * (imgs.length - 1);
	const MAX = 16e3;
	if (h > MAX) {
		const k = MAX / h;
		w = Math.round(w * k);
		h = MAX;
	}
	const c = document.createElement("canvas");
	c.width = w;
	c.height = h;
	const g = c.getContext("2d");
	g.fillStyle = "#ffffff";
	g.fillRect(0, 0, w, h);
	let y = 0;
	for (const i of imgs) {
		const ih = Math.round(i.naturalHeight * (w / i.naturalWidth));
		g.drawImage(i, 0, y, w, ih);
		y += ih + gap;
	}
	const b = await toBlob(c, "image/jpeg", .85);
	c.width = 0;
	return b;
}
/** ZIP with every page as its own JPG (stored, not recompressed). */
async function pagesToZip(srcs, base) {
	const files = [];
	for (let k = 0; k < srcs.length; k++) {
		const b = await (await fetch(srcs[k])).blob();
		const ext = b.type.includes("png") ? "png" : "jpg";
		files.push([`${base}-trang-${String(k + 1).padStart(2, "0")}.${ext}`, new Uint8Array(await b.arrayBuffer())]);
	}
	return zip(files, "application/zip");
}
var ID_PURPOSES = [
	"Hồ sơ ngân hàng",
	"Nộp hồ sơ xin việc",
	"Đăng ký dịch vụ",
	"Thủ tục hành chính"
];
var ID_RE = /cccd|căn cước|cmnd|chứng minh|hộ chiếu|thẻ id/i;
/** True when the document looks like a personal ID (CCCD/CMND/passport). */
function isIdDoc(doc, text = "") {
	return ID_RE.test(`${doc.kind} ${doc.name} ${text}`);
}
/** "CHỈ DÙNG CHO MỤC ĐÍCH … · dd/mm/yyyy". Empty purpose → empty string (no watermark). */
function idWatermarkText(purpose, date) {
	const p = purpose.replace(/\s+/g, " ").trim().replace(/^chỉ dùng cho( mục đích)?\s*/i, "");
	if (!p) return "";
	const base = `CHỈ DÙNG CHO MỤC ĐÍCH ${p.toLocaleUpperCase("vi-VN")}`;
	if (!date) return base;
	return `${base} · ${`${String(date.getDate()).padStart(2, "0")}/${String(date.getMonth() + 1).padStart(2, "0")}/${date.getFullYear()}`}`;
}
/** Diagonal rows positions covering a w×h image rotated by `angle` (pure; tested). */
function tileRows(w, h, step) {
	const diag = Math.ceil(Math.hypot(w, h));
	const rows = [];
	for (let y = -diag / 2; y <= diag / 2; y += step) rows.push(Math.round(y));
	return {
		diag,
		rows
	};
}
/** Bake a repeating diagonal watermark into the image so it cannot be cropped away. */
async function stampIdWatermark(src, text) {
	if (!text) return src;
	const img = await loadImg(src);
	const w = img.naturalWidth, h = img.naturalHeight;
	const c = document.createElement("canvas");
	c.width = w;
	c.height = h;
	const ctx = c.getContext("2d");
	ctx.drawImage(img, 0, 0);
	const fs = Math.max(14, Math.round(Math.min(w, h) / 28));
	ctx.font = `bold ${fs}px sans-serif`;
	ctx.textBaseline = "middle";
	const unit = `${text}     `;
	const uw = Math.max(1, ctx.measureText(unit).width);
	const { diag, rows } = tileRows(w, h, fs * 3.2);
	ctx.save();
	ctx.translate(w / 2, h / 2);
	ctx.rotate(-Math.PI / 6);
	ctx.fillStyle = "rgba(200, 30, 30, 0.28)";
	ctx.strokeStyle = "rgba(255, 255, 255, 0.35)";
	ctx.lineWidth = Math.max(1, fs / 14);
	rows.forEach((y, i) => {
		const off = i % 2 * (uw / 2);
		for (let x = -diag / 2 - off; x < diag / 2; x += uw) {
			ctx.strokeText(unit, x, y);
			ctx.fillText(unit, x, y);
		}
	});
	ctx.restore();
	return canvasToPageUrl(c, "image/jpeg", .92);
}
var createShareLink = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	localId: stringType().min(1).max(200),
	expiry: enumType(EXPIRY_OPTIONS.map((o) => o.id)),
	password: stringType().max(64).default("")
}).parse(d)).handler(createSsrRpc("f631e086e864b55a802d3846676e9c76d6b0d78df3ae21524dfa509bbf1a00b3"));
var listShareLinks = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ localId: stringType().min(1).max(200) }).parse(d)).handler(createSsrRpc("041fdf35b19bf4c65096476bcea235fc14bc14efac887da12e7c9bb40c9cd5f8"));
function ShareLinkPanel({ doc }) {
	const { user, ready } = useUser();
	const create = useServerFn(createShareLink);
	const [expiry, setExpiry] = (0, import_react.useState)("7d");
	const [pw, setPw] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [url, setUrl] = (0, import_react.useState)("");
	const pwErr = checkPassword(pw);
	const list = useServerFn(listShareLinks);
	const revoke = useServerFn(revokeShareLink);
	const [links, setLinks] = (0, import_react.useState)([]);
	const refresh = () => list({ data: { localId: doc.id } }).then(setLinks).catch(() => {});
	(0, import_react.useEffect)(() => {
		if (user) refresh();
	}, [user, doc.id]);
	async function doRevoke(id) {
		if (!await confirmDialog("Thu hồi liên kết?", {
			message: "Người đang có liên kết sẽ không xem được nữa.",
			okText: "Thu hồi",
			danger: true
		})) return;
		const r = await revoke({ data: { id } }).catch(() => ({
			ok: false,
			message: "Chưa thu hồi được, thử lại sau."
		}));
		if (r.ok) {
			toast.success("Đã thu hồi");
			refresh();
		} else showError(new Error(r.message), r.message);
	}
	async function make() {
		if (doc.locked) {
			toast("Tài liệu khoá PIN không lên mây nên không tạo được liên kết. Mở khoá trước.");
			return;
		}
		setBusy(true);
		setUrl("");
		try {
			if ((await uploadAll([doc])).upFailed.length) throw new Error("Chưa tải được tài liệu lên mây. Kiểm tra mạng rồi thử lại.");
			const r = await create({ data: {
				localId: doc.id,
				expiry,
				password: pw
			} });
			if (!r.ok) throw new Error(r.message);
			const u = shareUrl(window.location.origin, r.token);
			setUrl(u);
			await navigator.clipboard?.writeText(u).catch(() => {});
			toast.success("Đã tạo và chép liên kết");
			refresh();
		} catch (e) {
			showError(e, "Chưa tạo được liên kết");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 rounded-xl border border-border p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex items-center gap-2 text-sm font-semibold",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "size-4 text-primary" }), " Chia sẻ bằng liên kết"]
		}), !ready ? null : !user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-xs text-muted-foreground",
			children: ["Cần đăng nhập để tạo liên kết. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/auth",
				className: "font-semibold text-primary",
				children: "Đăng nhập"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: "Tài liệu được tải lên mây; ai có liên kết (và mật khẩu, nếu đặt) xem được đến khi hết hạn."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex flex-wrap gap-2",
				children: EXPIRY_OPTIONS.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: expiry === o.id ? "default" : "glass",
					onClick: () => setExpiry(o.id),
					children: o.label
				}, o.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				className: "mt-2 h-11",
				type: "password",
				autoComplete: "new-password",
				placeholder: "Mật khẩu (không bắt buộc)",
				value: pw,
				onChange: (e) => setPw(e.target.value)
			}),
			pwErr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-destructive",
				children: pwErr
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "mt-2 w-full",
				disabled: busy || !!pwErr,
				onClick: make,
				children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, {}), " Tạo liên kết"]
			}),
			url ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "h-11",
					readOnly: true,
					value: url,
					onFocus: (e) => e.currentTarget.select()
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "glass",
					"aria-label": "Chép liên kết",
					onClick: () => navigator.clipboard?.writeText(url).then(() => toast.success("Đã chép")),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {})
				})]
			}) : null,
			links.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2",
				children: links.map((l) => {
					const st = linkStatus(l, Date.now());
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1 truncate",
							children: [
								"…/s/",
								l.token.slice(0, 6),
								" · ",
								st === "active" ? l.expires_at ? `hết hạn ${new Date(l.expires_at).toLocaleString("vi-VN")}` : "không hết hạn" : st === "expired" ? "đã hết hạn" : "đã thu hồi",
								l.hasPassword ? " · có mật khẩu" : ""
							]
						}), st === "active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "glass",
							className: "text-destructive",
							onClick: () => doRevoke(l.id),
							children: "Thu hồi"
						}) : null]
					}, l.id);
				})
			}) : null
		] })]
	});
}
/** S15f2: lớp trung gian cho nguồn ảnh trang — chấp nhận cả data URL lẫn blob: URL.
*  Bước đệm trước khi bộ nhớ chuyển hẳn sang Blob/object URL (S15f3): mọi chỗ cần base64
*  (AI, chia sẻ, đồng bộ) phải đi qua srcToDataUrl thay vì giả định chuỗi "data:". */
var isDataUrl = (s) => s.startsWith("data:");
function dataUrlBlob(u) {
	const i = u.indexOf(",");
	const meta = u.slice(5, i);
	const body = u.slice(i + 1);
	if (meta.endsWith(";base64")) {
		const raw = atob(body);
		const a = new Uint8Array(raw.length);
		for (let k = 0; k < raw.length; k++) a[k] = raw.charCodeAt(k);
		return new Blob([a], { type: meta.replace(";base64", "") || "image/jpeg" });
	}
	return new Blob([decodeURIComponent(body)], { type: meta || "text/plain" });
}
async function srcToBlob(s) {
	if (isDataUrl(s)) return dataUrlBlob(s);
	const r = await fetch(s);
	if (!r.ok) throw new Error(`Không đọc được ảnh (${r.status})`);
	return r.blob();
}
async function srcToDataUrl(s) {
	if (isDataUrl(s)) return s;
	const b = await srcToBlob(s);
	const buf = new Uint8Array(await b.arrayBuffer());
	let bin = "";
	for (let i = 0; i < buf.length; i += 32768) bin += String.fromCharCode(...buf.subarray(i, i + 32768));
	return `data:${b.type || "image/jpeg"};base64,${btoa(bin)}`;
}
/** Ước lượng số byte ảnh (data URL: theo base64; blob: không biết → -1). */
function srcBytes(s) {
	if (!isDataUrl(s)) return -1;
	const k = s.indexOf(",");
	return k < 0 ? 0 : Math.floor((s.length - k - 1) * .75);
}
var imgSize = (src) => new Promise((ok) => {
	const i = new Image();
	i.onload = () => ok({
		width: i.naturalWidth,
		height: i.naturalHeight
	});
	i.onerror = () => ok({
		width: 0,
		height: 0
	});
	i.src = src;
});
var dataBytes = (src) => Math.max(0, srcBytes(src));
/** S12b – chẩn đoán AI cho trang hiện tại: chỉ chạy khi bấm, hỏi xác nhận, kết quả gắn phiên bản ảnh. */
function ScanDiagnosePanel({ pageId, filter, src }) {
	const fn = useQueuedServerFn(aiScanDiagnose, "Chẩn đoán ảnh quét");
	const version = (0, import_react.useMemo)(() => imageVersion(pageId, filter, src), [
		pageId,
		filter,
		src
	]);
	const [res, setRes] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [msg, setMsg] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setMsg("");
	}, [version]);
	const shown = matchesVersion(res, version) ? res : null;
	const run = async () => {
		setMsg("");
		const online = typeof navigator === "undefined" || navigator.onLine;
		const data = await srcToDataUrl(src).catch(() => "");
		if (!data) {
			setMsg("Không đọc được ảnh trang.");
			return;
		}
		const g = guardImage({
			...await imgSize(data),
			bytes: dataBytes(data),
			online
		});
		if (!g.ok) {
			setMsg(online ? g.reason : diagFallback("offline"));
			return;
		}
		if (!await confirmDialog("Gửi ảnh trang này cho AI?", {
			message: "Ảnh được gửi đi để tìm bóng tối, rác mép, chữ bị cắt và dòng nghiêng. Nội dung không được lưu trong nhật ký.",
			okText: "Gửi"
		})) return;
		setBusy(true);
		try {
			const r = await fn({ data: {
				image: data,
				version
			} });
			if (r.ok) setRes(r.data);
			else setMsg(r.code === 402 || r.code === 429 ? diagFallback(r.code) : r.message);
		} catch {
			setMsg(diagFallback(navigator.onLine ? 500 : "offline"));
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3 rounded-2xl border bg-card p-3 text-card-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold",
					children: "Chẩn đoán AI"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "glass",
					disabled: busy,
					onClick: run,
					children: [
						busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanSearch, {}),
						" ",
						shown ? "Chẩn đoán lại" : "Chẩn đoán"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "outline",
				className: "text-foreground",
				onClick: () => downloadBaseline(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), " Xuất số đo"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowPerfNotice, {}),
			msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				role: "status",
				children: msg
			}),
			res && !shown && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Ảnh đã đổi – kết quả cũ không còn áp dụng."
			}),
			shown && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative overflow-hidden rounded-lg border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src,
						alt: "Trang đang chẩn đoán",
						className: "block w-full"
					}), shown.issues.flatMap((it, a) => it.regions.map((q, b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						"aria-label": DIAG_LABEL[it.group],
						className: "absolute rounded-sm border-2 border-destructive bg-destructive/10",
						style: {
							left: `${q.x * 100}%`,
							top: `${q.y * 100}%`,
							width: `${q.w * 100}%`,
							height: `${q.h * 100}%`
						}
					}, `${a}-${b}`)))]
				}),
				shown.issues.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "Không thấy lỗi đáng kể."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-1.5 text-sm",
					children: shown.issues.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: DIAG_LABEL[it.group]
						}),
						" · nặng ",
						Math.round(it.severity * 100),
						"% · tin cậy ",
						Math.round(it.confidence * 100),
						"%",
						it.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted-foreground",
							children: it.note
						})
					] }, it.group))
				}),
				shown.summary && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: shown.summary
				})
			] })
		]
	});
}
/** B16: so số đo hiện tại với mốc đã lưu; cảnh báo khi một mốc chậm hơn 20%. */
function SlowPerfNotice() {
	const warnings = (0, import_react.useMemo)(() => {
		const base = readBaseline();
		return base ? slowWarnings(readPerf(), base) : [];
	}, []);
	if (!warnings.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "alert",
		className: "rounded-lg border border-amber-500/40 bg-amber-500/10 p-2 text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex items-center gap-1 font-medium",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-3.5" }), " Máy đang chậm hơn mốc đo trước"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-1 list-inside list-disc text-muted-foreground",
			children: warnings.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: slowWarningText(w) }, w.kind))
		})]
	});
}
function comparePosition(clientX, left, width) {
	if (width <= 0) return 50;
	return Math.min(100, Math.max(0, (clientX - left) / width * 100));
}
/** R1.2 – giữ nút “Xem gốc” thì thanh chia dồn hết sang phải (thấy 100% ảnh gốc); thả ra trở về vị trí cũ. */
function effectivePosition(position, holdOriginal) {
	return holdOriginal ? 100 : position;
}
function ImageCompare({ before, after, loading = false, holdOriginal = false }) {
	const frame = (0, import_react.useRef)(null);
	const [rawPosition, setPosition] = (0, import_react.useState)(50);
	const position = effectivePosition(rawPosition, holdOriginal);
	function move(clientX) {
		const rect = frame.current?.getBoundingClientRect();
		if (rect) setPosition(comparePosition(clientX, rect.left, rect.width));
	}
	function onPointerMove(event) {
		if (event.currentTarget.hasPointerCapture(event.pointerId)) move(event.clientX);
	}
	function onKeyDown(event) {
		if (event.key !== "ArrowLeft" && event.key !== "ArrowRight" && event.key !== "Home" && event.key !== "End") return;
		event.preventDefault();
		if (event.key === "Home") setPosition(0);
		else if (event.key === "End") setPosition(100);
		else setPosition((value) => Math.min(100, Math.max(0, value + (event.key === "ArrowLeft" ? -5 : 5))));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: frame,
		className: "relative isolate h-48 w-full touch-none overflow-hidden rounded-lg bg-editor select-none",
		onPointerDown: (event) => {
			event.currentTarget.setPointerCapture(event.pointerId);
			move(event.clientX);
		},
		onPointerMove,
		onPointerUp: (event) => event.currentTarget.releasePointerCapture(event.pointerId),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: after,
				alt: "Ảnh sau khi lọc",
				className: "absolute inset-0 size-full object-contain",
				draggable: false
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 overflow-hidden",
				style: { clipPath: `inset(0 ${100 - position}% 0 0)` },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: before,
					alt: "Ảnh gốc trước khi lọc",
					className: "size-full object-contain",
					draggable: false
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute left-2 top-2 rounded bg-foreground/75 px-2 py-1 text-[0.625rem] font-bold text-background",
				children: "Gốc"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute right-2 top-2 rounded bg-foreground/75 px-2 py-1 text-[0.625rem] font-bold text-background",
				children: "Sau"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-y-0 w-px bg-primary-foreground shadow-sm",
				style: { left: `${position}%` }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "slider",
				"aria-label": "So sánh ảnh gốc và ảnh sau khi lọc",
				"aria-valuemin": 0,
				"aria-valuemax": 100,
				"aria-valuenow": Math.round(position),
				tabIndex: 0,
				onKeyDown,
				className: "absolute top-1/2 grid size-10 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border-2 border-primary-foreground bg-primary text-primary-foreground shadow-lg outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
				style: { left: `${position}%` },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GripVertical, { className: "size-5" })
			}),
			loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-x-0 bottom-0 h-1 animate-pulse bg-primary",
				"aria-label": "Đang cập nhật ảnh xem trước"
			})
		]
	});
}
/** Ngưỡng võng tương đối coi là "cong rõ" (2 % chiều dài cạnh / chiều cao trang). */
var FULL_BEND = .02;
/** Dưới độ tin cậy này không đề xuất (trang gần phẳng hoặc tín hiệu mâu thuẫn). */
var SUGGEST_MIN_CONFIDENCE = .35;
/**
* Đo độ cong của trang trong ảnh RGBA (nên dùng bản thu nhỏ ≤ 800 px cho nhanh —
* toạ độ chuẩn hoá nên kết quả tương đương ảnh gốc). quad: 4 góc chuẩn hoá 0..1.
*/
function suggestDewarp(d, W, H, quad) {
	const q = quad.map(([x, y]) => [x * W, y * H]);
	const curves = edgeCurves(d, W, H, q);
	let edgeBend = 0, edges = 0;
	curves.forEach((c, s) => {
		if (!c) return;
		const a = q[s], b = q[(s + 1) % 4];
		const len = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
		const peak = Math.max(...[
			.25,
			.5,
			.75
		].map((t) => Math.abs(curveAt(c, t))));
		edgeBend = Math.max(edgeBend, peak / len);
		edges++;
	});
	const { g, w, h } = smallGray(d, W, H);
	const lineBend = buildPageCurve(detectTextLines(g, w, h))?.bend ?? 0;
	const eConf = Math.min(1, edgeBend / FULL_BEND) * (edges ? .6 + .1 * edges : 0);
	const lConf = Math.min(1, lineBend / FULL_BEND);
	const confidence = Math.round((1 - (1 - eConf) * (1 - lConf)) * 100) / 100;
	return {
		curved: confidence >= SUGGEST_MIN_CONFIDENCE,
		confidence,
		edgeBend,
		lineBend,
		edges
	};
}
/** Chế độ shader cho từng nhóm bộ lọc (xấp xỉ một pass trên GPU). */
var GL_MODE = {
	tone: 0,
	gray: 1,
	mono: 2,
	vivid: 3,
	magic: 4
};
/** Kẹp cấp độ bộ lọc về 0–100 (mặc định 100 khi thiếu/không hợp lệ). */
function clampFilterLevel(v) {
	if (v === void 0 || v === null || !Number.isFinite(v)) return 100;
	return Math.max(0, Math.min(100, Math.round(v)));
}
/** Bộ lọc cần pipeline CPU nhiều pass — GPU chỉ xem trước gần đúng. */
var CPU_ONLY = /* @__PURE__ */ new Set(["shadow", "denoise"]);
function filterShaderParams(rawFilter, level, brightness = 0, contrast = 0) {
	const filter = normalizeFilter(rawFilter);
	const mix = clampFilterLevel(level) / 100;
	const bright = Math.max(-80, Math.min(80, brightness)) / 255;
	const k = Math.max(-80, Math.min(80, contrast));
	let mode = GL_MODE.tone;
	if (filter === "gray") mode = GL_MODE.gray;
	else if (filter === "mono" || filter === "ink") mode = GL_MODE.mono;
	else if (filter === "vivid" || filter === "bright" || filter === "eco") mode = GL_MODE.vivid;
	else if (filter !== "original") mode = GL_MODE.magic;
	return {
		mode,
		mix,
		bright,
		contrast: k,
		cpuOnly: CPU_ONLY.has(filter)
	};
}
var VS300 = `#version 300 es
in vec2 p; out vec2 uv;
void main(){ uv = vec2(p.x * 0.5 + 0.5, 0.5 - p.y * 0.5); gl_Position = vec4(p, 0.0, 1.0); }`;
var FS300 = `#version 300 es
precision highp float;
uniform sampler2D t; uniform int mode; uniform float mixv; uniform float bright; uniform float contrast;
in vec2 uv; out vec4 o;
void main(){
  vec3 c = texture(t, uv).rgb;
  vec3 f = c;
  float y = dot(c, vec3(0.3, 0.59, 0.11));
  if (mode == 1) { f = vec3(y); }
  else if (mode == 2) { f = vec3(step(0.55, y) * 0.98 + 0.02); }
  else if (mode == 3) { f = clamp(y + (c - y) * 1.35 + 0.03, 0.0, 1.0); }
  else if (mode == 4) {
    float w = 0.86;
    float t2 = clamp((y - 0.02) / max(0.12, w - 0.02), 0.0, 1.0);
    float ny = pow(t2, 1.5);
    float sat = max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));
    f = sat > 0.14 && y < 0.92 ? clamp(y + (c - y) * 1.3, 0.0, 1.0) * (ny / max(y, 0.004)) : vec3(ny);
  }
  f = clamp((f - 0.5) * (1.0 + contrast / 80.0) + 0.5 + bright, 0.0, 1.0);
  o = vec4(mix(c, f, mixv), 1.0);
}`;
var cachedSupport = null;
/** Kiểm tra WebGL2 (lưu kết quả). */
function filterGlSupport() {
	if (cachedSupport) return cachedSupport;
	try {
		if (typeof document === "undefined") cachedSupport = {
			ok: false,
			reason: "no-dom"
		};
		else {
			const c = document.createElement("canvas");
			const gl = c.getContext("webgl2");
			cachedSupport = gl ? { ok: true } : {
				ok: false,
				reason: "no-webgl2"
			};
			gl?.getExtension("WEBGL_lose_context")?.loseContext();
			c.width = c.height = 0;
		}
	} catch {
		cachedSupport = {
			ok: false,
			reason: "error"
		};
	}
	return cachedSupport;
}
function compile300(gl, type, src) {
	const s = gl.createShader(type);
	gl.shaderSource(s, src);
	gl.compileShader(s);
	if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) || "shader");
	return s;
}
/** Đếm lượt dựng để kiểm chứng hiệu năng (globalThis.__r24). */
var r24Stats = {
	draws: 0,
	lastMs: 0,
	fallback: 0
};
if (typeof globalThis !== "undefined") globalThis.__r24 = r24Stats;
/**
* Dựng xem trước bộ lọc trên GPU ra canvas ≤ max px cạnh dài.
* Trả null khi: không có WebGL2, bộ lọc cpuOnly, hoặc lỗi — nơi gọi rơi về CPU.
*/
function filterPreviewGL(img, rawFilter, level, brightness = 0, contrast = 0, max = 1280) {
	if (!filterGlSupport().ok) {
		r24Stats.fallback++;
		return null;
	}
	const p = filterShaderParams(rawFilter, level, brightness, contrast);
	if (p.cpuOnly) {
		r24Stats.fallback++;
		return null;
	}
	const sw = img.width ?? 0, sh = img.height ?? 0;
	if (!sw || !sh) return null;
	const s = Math.min(1, max / Math.max(sw, sh));
	const ow = Math.max(1, Math.round(sw * s)), oh = Math.max(1, Math.round(sh * s));
	const c = document.createElement("canvas");
	c.width = ow;
	c.height = oh;
	if (!drawFilterGL(c, img, p)) {
		r24Stats.fallback++;
		return null;
	}
	return c;
}
/**
* CS-18: lõi vẽ bộ lọc một pass lên canvas WebGL2 (DOM hoặc OffscreenCanvas — dùng được trong Worker), cỡ = cỡ canvas.
* false = không có WebGL2 / lỗi shader / lỗi vẽ.
*/
function drawFilterGL(c, img, p) {
	const ow = c.width, oh = c.height;
	const gl = c.getContext("webgl2", {
		preserveDrawingBuffer: true,
		premultipliedAlpha: false,
		antialias: false
	});
	if (!gl) return false;
	const t0 = performance_default.now();
	try {
		const prog = gl.createProgram();
		gl.attachShader(prog, compile300(gl, gl.VERTEX_SHADER, VS300));
		gl.attachShader(prog, compile300(gl, gl.FRAGMENT_SHADER, FS300));
		gl.linkProgram(prog);
		if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return false;
		gl.useProgram(prog);
		const buf = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, buf);
		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
			-1,
			-1,
			1,
			-1,
			-1,
			1,
			1,
			1
		]), gl.STATIC_DRAW);
		const loc = gl.getAttribLocation(prog, "p");
		gl.enableVertexAttribArray(loc);
		gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
		const tex = gl.createTexture();
		gl.bindTexture(gl.TEXTURE_2D, tex);
		gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
		gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);
		const u = (n) => gl.getUniformLocation(prog, n);
		gl.uniform1i(u("t"), 0);
		gl.uniform1i(u("mode"), p.mode);
		gl.uniform1f(u("mixv"), p.mix);
		gl.uniform1f(u("bright"), p.bright);
		gl.uniform1f(u("contrast"), p.contrast);
		gl.viewport(0, 0, ow, oh);
		gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
		if (gl.getError() !== gl.NO_ERROR) return false;
		r24Stats.draws++;
		r24Stats.lastMs = Math.round((performance_default.now() - t0) * 10) / 10;
		return true;
	} catch {
		return false;
	} finally {
		if (typeof HTMLCanvasElement !== "undefined" && c instanceof HTMLCanvasElement) gl.getExtension("WEBGL_lose_context")?.loseContext();
	}
}
/** Ba biến thể mặc định: Sắc nét (chữ), Màu đậm (giữ màu), Đen trắng (nhẹ tệp). */
function buildVariants(m) {
	const dark = m ? m.brightness < 90 : false;
	const lowContrast = m ? m.contrast < 40 : false;
	return [
		{
			id: "sharp",
			label: "Sắc nét",
			desc: "Chữ rõ, nền sạch — hợp giấy tờ thuần chữ.",
			edit: {
				filter: "sharp",
				level: 100,
				brightness: dark ? 15 : 0,
				contrast: lowContrast ? 15 : 5
			}
		},
		{
			id: "vivid",
			label: "Màu đậm",
			desc: "Giữ màu con dấu, ảnh — hợp giấy tờ có dấu đỏ.",
			edit: {
				filter: "vivid",
				level: 100,
				brightness: dark ? 10 : 0,
				contrast: 10
			}
		},
		{
			id: "mono",
			label: "Đen trắng",
			desc: "Nhẹ tệp nhất, in rõ — hợp hợp đồng, biểu mẫu.",
			edit: {
				filter: "mono",
				level: 100,
				brightness: dark ? 20 : 5,
				contrast: 20
			}
		}
	];
}
/** Biến thể có khớp bản nháp hiện tại không (để tô nút đang chọn). */
function variantActive(v, d) {
	return d.filter === v.edit.filter && (d.level ?? 100) === v.edit.level && d.brightness === v.edit.brightness && d.contrast === v.edit.contrast;
}
/** P4/TD-09: đo độ cong trang trên bản thu nhỏ ≤ 640 px của ảnh gốc (nhanh, không chạm ảnh lớn). */
async function measureCurve(orig, quad) {
	const img = await new Promise((res, rej) => {
		const i = new Image();
		i.onload = () => res(i);
		i.onerror = () => rej(/* @__PURE__ */ new Error("load"));
		i.src = orig;
	});
	const s = Math.min(1, 640 / Math.max(img.naturalWidth, img.naturalHeight));
	const w = Math.max(8, Math.round(img.naturalWidth * s)), h = Math.max(8, Math.round(img.naturalHeight * s));
	const c = document.createElement("canvas");
	c.width = w;
	c.height = h;
	const ctx = c.getContext("2d", { willReadFrequently: true });
	ctx.drawImage(img, 0, 0, w, h);
	return suggestDewarp(ctx.getImageData(0, 0, w, h).data, w, h, quad);
}
/** Xem ảnh đã dựng đầy đủ: vừa khung hoặc 100% (1 điểm ảnh = 1 điểm màn hình), kéo để dịch. */
function ZoomView({ src, loading }) {
	const frame = (0, import_react.useRef)(null);
	const drag = (0, import_react.useRef)(null);
	const [view, setView] = (0, import_react.useState)({
		w: 0,
		h: 0
	});
	const [nat, setNat] = (0, import_react.useState)({
		w: 0,
		h: 0
	});
	const [actual, setActual] = (0, import_react.useState)(false);
	const [pan, setPan] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	(0, import_react.useEffect)(() => {
		const el = frame.current;
		if (!el) return;
		const measure = () => setView({
			w: el.clientWidth,
			h: el.clientHeight
		});
		measure();
		const ro = new ResizeObserver(measure);
		ro.observe(el);
		return () => ro.disconnect();
	}, []);
	const dpr = typeof window === "undefined" ? 1 : window.devicePixelRatio || 1;
	const scale = actual ? actualScale(dpr) : fitScale(view, nat);
	const at = clampPan(actual ? pan : {
		x: 0,
		y: 0
	}, view, nat, scale);
	function toggle(next) {
		setActual(next);
		if (next) setPan(centerOn({
			x: .5,
			y: .5
		}, view, nat, actualScale(dpr)));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 flex gap-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: actual ? "glass" : "default",
				className: "rounded-full",
				"aria-pressed": !actual,
				onClick: () => toggle(false),
				children: "Vừa khung"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: actual ? "default" : "glass",
				className: "rounded-full",
				"aria-pressed": actual,
				onClick: () => toggle(true),
				children: "100%"
			}),
			loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "self-center text-xs opacity-70",
				children: "Đang dựng ảnh đầy đủ…"
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: frame,
		className: "relative h-[44dvh] w-full touch-none select-none overflow-hidden rounded-lg bg-editor",
		onPointerDown: (e) => {
			if (!actual) return;
			e.currentTarget.setPointerCapture(e.pointerId);
			drag.current = {
				x: e.clientX,
				y: e.clientY,
				px: at.x,
				py: at.y
			};
		},
		onPointerMove: (e) => {
			const d = drag.current;
			if (d) setPan(clampPan({
				x: d.px + e.clientX - d.x,
				y: d.py + e.clientY - d.y
			}, view, nat, scale));
		},
		onPointerUp: (e) => {
			drag.current = null;
			if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
		},
		onPointerCancel: () => {
			drag.current = null;
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: "Ảnh đã chỉnh, dựng đầy đủ",
			draggable: false,
			onLoad: (e) => setNat({
				w: e.currentTarget.naturalWidth,
				h: e.currentTarget.naturalHeight
			}),
			className: "absolute max-w-none",
			style: nat.w > 0 ? {
				left: at.x,
				top: at.y,
				width: nat.w * scale,
				height: nat.h * scale
			} : { visibility: "hidden" }
		})
	})] });
}
/** S13b – Chỉnh tay: mọi thay đổi nằm trong bản nháp; chỉ khi bấm Lưu mới ghi vào trang (Hủy/rời màn hình không đổi gì). */
/** R1.1 – Một cửa chỉnh (TD-11/12): bộ lọc, ánh sáng, cắt, xoay, công cụ 3 mức đều ở đây; chỉ ghi khi bấm Lưu / Áp tất cả / Trang tương tự. */
function AdjustEditor({ page, onClose, onApply, onApplyAll, onApplySimilar, extra }) {
	const [s, setS] = (0, import_react.useState)(() => startSession(page.edit));
	const [mode, setMode] = (0, import_react.useState)("compare");
	const [holdOriginal, setHoldOriginal] = (0, import_react.useState)(false);
	const [preview, setPreview] = (0, import_react.useState)(page.src);
	const [previewing, setPreviewing] = (0, import_react.useState)(false);
	const [full, setFull] = (0, import_react.useState)(page.src);
	const [fullBusy, setFullBusy] = (0, import_react.useState)(false);
	const [crop, setCrop] = (0, import_react.useState)(false);
	const [live, setLive] = (0, import_react.useState)({});
	const d = s.draft;
	const liveRef = (0, import_react.useRef)(live);
	liveRef.current = live;
	function commitLive(key) {
		const v = liveRef.current[key];
		if (v === void 0) return;
		setLive((l) => {
			const { [key]: _drop, ...rest } = l;
			return rest;
		});
		setS((cur) => applyEdit(cur, key === "b" ? { brightness: v } : key === "c" ? { contrast: v } : { level: v }));
	}
	const glImg = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		let current = true;
		if (!filterGlSupport().ok) return;
		loadImg(page.orig).then((img) => {
			if (current) glImg.current = img;
		}).catch(() => {});
		return () => {
			current = false;
			glImg.current = null;
		};
	}, [page.orig]);
	/** Xem trước tức thì trên GPU trong lúc kéo thanh; ảnh đầy đủ chỉ dựng khi thả tay. */
	function glPreview(lv) {
		const img = glImg.current;
		if (!img) return;
		if (filterShaderParams(d.filter, lv, live.b ?? d.brightness, live.c ?? d.contrast).cpuOnly) return;
		const c = filterPreviewGL(img, d.filter, lv, live.b ?? d.brightness, live.c ?? d.contrast);
		if (c) {
			setPreview(c.toDataURL("image/jpeg", .85));
			c.width = 0;
		}
	}
	const [suggest, setSuggest] = (0, import_react.useState)(null);
	const [metrics, setMetrics] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let current = true;
		checkQuality(page.orig, { cropped: true }).then((r) => {
			if (current) {
				setMetrics(r.metrics);
				setSuggest(suggestFilter(r.metrics));
			}
		}).catch(() => {});
		return () => {
			current = false;
		};
	}, [page.orig]);
	const variants = buildVariants(metrics);
	/** R3.2: chọn biến thể = 1 chạm → áp toàn bộ thông số vào bản nháp. */
	function pickVariant(v) {
		setLive({});
		setS((cur) => applyEdit(cur, { ...v.edit }));
	}
	const transfer = () => ({
		filter: d.filter,
		brightness: d.brightness,
		contrast: d.contrast
	});
	const dirtyRef = (0, import_react.useRef)(false);
	dirtyRef.current = isDirty(s);
	const blocker = useBlocker({
		shouldBlockFn: () => dirtyRef.current,
		withResolver: true
	});
	(0, import_react.useEffect)(() => {
		if (blocker.status !== "blocked") return;
		confirmDialog("Bỏ các thay đổi chưa lưu?", {
			message: "Trang giữ nguyên như đã lưu.",
			okText: "Bỏ thay đổi",
			danger: true
		}).then((ok) => ok ? blocker.proceed?.() : blocker.reset?.());
	}, [
		blocker.status,
		blocker.proceed,
		blocker.reset
	]);
	(0, import_react.useEffect)(() => {
		if (mode !== "compare") return;
		let current = true;
		setPreviewing(true);
		const timer = window.setTimeout(() => {
			renderPreview(page.orig, d).then((src) => {
				if (current) setPreview(src);
			}).catch((error) => {
				if (current) showError(error, "Không xem trước được");
			}).finally(() => {
				if (current) setPreviewing(false);
			});
		}, 60);
		return () => {
			current = false;
			window.clearTimeout(timer);
		};
	}, [
		page.orig,
		d,
		mode
	]);
	(0, import_react.useEffect)(() => {
		if (mode !== "zoom") return;
		let current = true;
		setFullBusy(true);
		const timer = window.setTimeout(() => {
			renderPage(page.orig, d).then((src) => {
				if (current) setFull(src);
			}).catch((error) => {
				if (current) showError(error, "Không dựng được ảnh đầy đủ");
			}).finally(() => {
				if (current) setFullBusy(false);
			});
		}, 300);
		return () => {
			current = false;
			window.clearTimeout(timer);
		};
	}, [
		page.orig,
		d,
		mode
	]);
	const [boxes, setBoxes] = (0, import_react.useState)(null);
	const [ocrBusy, setOcrBusy] = (0, import_react.useState)(false);
	async function scanBoxes() {
		setOcrBusy(true);
		try {
			const r = await recognizeWordBoxes(page.orig);
			setBoxes(r.words.map((w) => boxFromOcrWord(w, r.size)).filter((b) => !!b));
		} catch (e) {
			showError(e, "Không đọc được chữ");
		} finally {
			setOcrBusy(false);
		}
	}
	const cutCheck = boxes ? edgeCutCheck(d.quad, boxes) : null;
	const [curve, setCurve] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!page.edit.quad || page.edit.flatten !== void 0) return;
		let current = true;
		measureCurve(page.orig, page.edit.quad).then((r) => {
			if (current && r?.curved) setCurve(r);
		}).catch(() => {});
		return () => {
			current = false;
		};
	}, [
		page.orig,
		page.edit.quad,
		page.edit.flatten
	]);
	async function cancel() {
		if (isDirty(s) && !await confirmDialog("Bỏ các thay đổi chưa lưu?", {
			message: "Trang giữ nguyên như đã lưu.",
			okText: "Bỏ thay đổi",
			danger: true
		})) return;
		onClose();
	}
	function save() {
		const r = saveSession(s);
		if (!r.changed) {
			onClose();
			return;
		}
		onApply(r.edit);
	}
	const b = live.b ?? d.brightness, c = live.c ?? d.contrast;
	const lv = live.lv ?? clampFilterLevel(d.level);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "scan-screen fixed inset-0 z-50 mx-auto flex max-w-[430px] flex-col overflow-y-auto",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-3 pt-[max(0.75rem,env(safe-area-inset-top))] pb-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: "scan-icon",
						onClick: () => void cancel(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}), " Hủy"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-sm font-semibold",
						children: ["Chỉnh tay", isDirty(s) ? " •" : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: save,
						children: "Lưu"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex gap-1.5",
					role: "group",
					"aria-label": "Kiểu xem",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: mode === "compare" ? "default" : "glass",
						className: "rounded-full",
						"aria-pressed": mode === "compare",
						onClick: () => setMode("compare"),
						children: "So sánh"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: mode === "zoom" ? "default" : "glass",
						className: "rounded-full",
						"aria-pressed": mode === "zoom",
						onClick: () => setMode("zoom"),
						children: "Xem chữ nhỏ"
					})]
				}), mode === "compare" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageCompare, {
					before: page.orig,
					after: preview,
					loading: previewing,
					holdOriginal
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "glass",
					className: "mt-2 w-full select-none touch-none rounded-full",
					"aria-pressed": holdOriginal,
					onPointerDown: () => setHoldOriginal(true),
					onPointerUp: () => setHoldOriginal(false),
					onPointerLeave: () => setHoldOriginal(false),
					onPointerCancel: () => setHoldOriginal(false),
					onKeyDown: (e) => {
						if (e.key === " " || e.key === "Enter") setHoldOriginal(true);
					},
					onKeyUp: () => setHoldOriginal(false),
					onBlur: () => setHoldOriginal(false),
					children: "Giữ để xem ảnh gốc"
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomView, {
					src: full,
					loading: fullBusy
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-3 gap-2 px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "glass",
						disabled: !canUndo(s),
						onClick: () => setS(undo(s)),
						children: "Hoàn tác"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "glass",
						disabled: !canRedo(s),
						onClick: () => setS(redo(s)),
						children: "Làm lại"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "glass",
						disabled: !isDirty(s),
						onClick: () => setS(resetSession(s)),
						children: "Đặt lại"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 grid grid-cols-2 gap-2 px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					onClick: () => setCrop(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crop, {}), " Cắt / 4 góc"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					onClick: () => setS(applyEdit(s, { rotation: (d.rotation + 90) % 360 })),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, {}), " Xoay 90°"]
				})]
			}),
			curve && d.flatten === void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 px-4",
				"data-testid": "dewarp-suggest",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-muted px-3 py-2 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-semibold",
							children: [
								"Trang hơi cong (độ tin cậy ~",
								Math.round(curve.confidence * 100),
								"%)"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 opacity-70",
							children: "Nắn phẳng giúp chữ thẳng hàng, dễ đọc và xuất PDF đẹp hơn."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => {
									setS((cur) => applyEdit(cur, { flatten: true }));
									setCurve(null);
								},
								children: "Nắn phẳng"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "glass",
								onClick: () => {
									setS((cur) => applyEdit(cur, { flatten: false }));
									setCurve(null);
								},
								children: "Giữ nguyên"
							})]
						})
					]
				})
			}),
			d.flatten !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center justify-between rounded-lg bg-muted px-3 py-2 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: d.flatten ? "Đang nắn phẳng trang cong." : "Đã tắt nắn phẳng — giữ độ cong tự nhiên." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => setS((cur) => applyEdit(cur, { flatten: void 0 })),
						children: "Tự động"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 px-4",
				"aria-live": "polite",
				children: !cutCheck ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					className: "w-full",
					disabled: ocrBusy,
					onClick: () => void scanBoxes(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanText, {}),
						" ",
						ocrBusy ? "Đang đọc chữ…" : "Kiểm chữ bị cắt mép"
					]
				}) : cutCheck.safe ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-lg bg-muted px-3 py-2 text-xs",
					children: [
						"Khung cắt không lẹm vào chữ nào (",
						boxes.length,
						" từ đã kiểm)."
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-2 rounded-lg bg-destructive/15 px-3 py-2 text-xs text-destructive",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 shrink-0" }),
						" Khung cắt đi qua ",
						cutCheck.cut.length,
						" từ ở mép — mở Cắt / 4 góc để nới khung."
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mt-2 overflow-hidden rounded-lg",
					"data-testid": "cut-overlay",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: page.orig,
						alt: "Vị trí chữ bị cắt",
						className: "block w-full"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						className: "absolute inset-0 size-full",
						viewBox: "0 0 1 1",
						preserveAspectRatio: "none",
						"aria-hidden": true,
						children: [d.quad && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
							points: d.quad.map((p) => p.join(",")).join(" "),
							fill: "none",
							className: "stroke-primary",
							strokeWidth: .004
						}), cutCheck.cut.map((c) => {
							const bx = boxes[c.index];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								"data-cut": true,
								x: bx.x,
								y: bx.y,
								width: bx.w,
								height: bx.h,
								className: "fill-destructive/40 stroke-destructive",
								strokeWidth: .003
							}, c.index);
						})]
					})]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 space-y-2 px-4",
				"data-testid": "tool-strip",
				"aria-label": "Công cụ 3 mức",
				children: TOOL_KEYS.map((k) => {
					const lv = clampLevel(d.tools?.[k]);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							id: `tool-${k}`,
							className: "text-xs font-semibold",
							children: TOOL_LABEL[k]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-1",
							role: "radiogroup",
							"aria-labelledby": `tool-${k}`,
							children: LEVEL_LABEL.map((name, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								role: "radio",
								"aria-checked": lv === i,
								variant: lv === i ? "default" : "glass",
								className: "h-7 rounded-full px-2.5 text-xs",
								onClick: () => setS((cur) => applyEdit(cur, { tools: {
									...cur.draft.tools,
									[k]: i
								} })),
								children: name
							}, name))
						})]
					}, k);
				})
			}),
			shouldSuggest(suggest, d.filter) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					"data-testid": "filter-suggest",
					onClick: () => setS((cur) => applyEdit(cur, { filter: suggest.filter })),
					className: "flex w-full items-center gap-2 rounded-[10px] border border-primary/40 bg-primary/5 px-3 py-2 text-left text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"Gợi ý: ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: FILTER_LABEL[suggest.filter] }),
						" — ",
						suggest.reason,
						" (độ tin cậy ~",
						Math.round(suggest.confidence * 100),
						"%)"
					] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 px-4",
				"data-testid": "variant-strip",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1.5 text-xs font-semibold",
					children: "Phương án khác — chạm để đổi ngay"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: variants.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						"data-testid": `variant-${v.id}`,
						"aria-pressed": variantActive(v, d),
						onClick: () => pickVariant(v),
						className: `rounded-[10px] border px-2 py-2 text-left ${variantActive(v, d) ? "border-primary bg-primary/10" : "border-border bg-muted text-foreground"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs font-semibold",
							children: v.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 block text-[10px] leading-snug opacity-70",
							children: v.desc
						})]
					}, v.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex shrink-0 gap-2 overflow-x-auto px-4 pb-1 [scrollbar-width:none]",
				"data-testid": "filter-strip",
				children: Object.keys(FILTER_LABEL).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: d.filter === f ? "default" : "glass",
					className: "shrink-0 rounded-full",
					onClick: () => setS(applyEdit(s, { filter: f })),
					children: FILTER_LABEL[f]
				}, f))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						id: "adj-brightness-label",
						className: "mt-4 block text-xs font-semibold",
						children: [
							"Độ sáng (",
							b,
							")"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						"aria-labelledby": "adj-brightness-label",
						className: "mt-2",
						onPointerCancel: () => commitLive("b"),
						min: -80,
						max: 80,
						step: 5,
						value: [b],
						onValueChange: ([v]) => setLive((l) => ({
							...l,
							b: v ?? 0
						})),
						onValueCommit: ([v]) => {
							setLive((l) => {
								const { b: _drop, ...rest } = l;
								return rest;
							});
							setS((cur) => applyEdit(cur, { brightness: v ?? 0 }));
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						id: "adj-contrast-label",
						className: "mt-4 block text-xs font-semibold",
						children: [
							"Tương phản (",
							c,
							")"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						"aria-labelledby": "adj-contrast-label",
						className: "mt-2",
						onPointerCancel: () => commitLive("c"),
						min: -80,
						max: 80,
						step: 5,
						value: [c],
						onValueChange: ([v]) => setLive((l) => ({
							...l,
							c: v ?? 0
						})),
						onValueCommit: ([v]) => {
							setLive((l) => {
								const { c: _drop, ...rest } = l;
								return rest;
							});
							setS((cur) => applyEdit(cur, { contrast: v ?? 0 }));
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						id: "adj-level-label",
						className: "mt-4 block text-xs font-semibold",
						children: [
							"Cấp độ bộ lọc (",
							lv,
							")"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						"aria-labelledby": "adj-level-label",
						className: "mt-2",
						min: 0,
						max: 100,
						step: 5,
						value: [lv],
						"data-testid": "filter-level",
						onPointerCancel: () => commitLive("lv"),
						onValueChange: ([v]) => {
							const n = clampFilterLevel(v);
							setLive((l) => ({
								...l,
								lv: n
							}));
							glPreview(n);
						},
						onValueCommit: ([v]) => {
							const n = clampFilterLevel(v);
							setLive((l) => {
								const { lv: _drop, ...rest } = l;
								return rest;
							});
							setS((cur) => applyEdit(cur, { level: n }));
						}
					}),
					(onApplyAll || onApplySimilar) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-2 gap-2",
						children: [onApplyAll && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "glass",
							onClick: () => onApplyAll(transfer()),
							children: "Áp tất cả trang"
						}), onApplySimilar && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "glass",
							onClick: () => onApplySimilar(transfer()),
							children: "Trang tương tự"
						})]
					}),
					extra && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: extra
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs opacity-70",
						children: "Chưa bấm Lưu thì trang đã lưu không thay đổi. Ảnh gốc luôn được giữ để hoàn tác."
					})
				]
			}),
			crop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CropEditor, {
				src: page.orig,
				quad: d.quad,
				paper: d.paper,
				applyLabel: "Dùng khung này",
				onClose: () => setCrop(false),
				onApply: (quad, paper) => {
					setCrop(false);
					setS((cur) => applyEdit(cur, {
						quad,
						paper
					}));
				}
			})
		]
	});
}
function LazyPage({ src, on, alt, thumb }) {
	const url = usePreview(src, on, thumb);
	if (!url) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "aspect-[3/4] h-full max-h-full max-w-full animate-pulse rounded-[4px] bg-muted",
		"aria-label": alt
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: url,
		alt,
		decoding: "async",
		className: "page-shadow max-h-full max-w-full rounded-[4px] object-contain"
	});
}
/** B14: ô ảnh trong dải trang/bảng sắp xếp dùng ảnh thu nhỏ riêng — không giải mã ảnh lớn. */
function StripThumb({ doc, i, className }) {
	const t = usePageThumb(doc, i);
	if (!t) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `animate-pulse bg-muted ${className}` });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: t,
		alt: "",
		loading: "lazy",
		decoding: "async",
		className
	});
}
var reviewCache = /* @__PURE__ */ new Map();
var qualityCache = /* @__PURE__ */ new Map();
var TOOL_PANEL = {
	ocr: "ocr",
	pages: "pages",
	rotate: "pages",
	export: "export",
	sign: "sign",
	draw: "draw",
	filter: "filter",
	"ai-extract": "ai",
	"ai-summarize": "ai-summarize",
	"ai-translate": "ai-translate",
	"ai-solve": "ai-solve"
};
function DocView() {
	const { id } = Route.useParams();
	const { tool, run, review } = Route.useSearch();
	const { docs, ready } = useDocs();
	const settings = useSettings();
	const doc = docs.find((d) => d.id === id);
	const [open, setOpen] = (0, import_react.useState)(false);
	const lockTick = useLockTick();
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [lockTick]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin text-primary" })
	});
	if (!doc) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center p-8 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display font-semibold",
			children: "Không tìm thấy tài liệu"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "mt-3 inline-block text-sm font-semibold text-primary",
			children: "Về trang chủ"
		})] })
	});
	if (doc.locked && settings.pin && !unlocked.has(doc.id) && !open) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PinGate, {
		onOk: () => {
			unlocked.add(doc.id);
			setOpen(true);
		},
		hash: settings.pin
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
		doc,
		initial: tool ? TOOL_PANEL[tool] ?? null : null,
		autoRun: run === "1",
		startReview: review === "1"
	});
}
function PinGate({ hash, onOk }) {
	const [pin, setPin] = (0, import_react.useState)("");
	async function check(v) {
		setPin(v);
		if (v.length >= 4 && await hashPin(v) === hash) {
			const { unlockVault } = await import("./db-CclUQaLE.mjs").then((n) => n.r).then((n) => n.n);
			if (await unlockVault(v, getPinSalt())) onOk();
			else {
				toast.error("Không giải mã được tài liệu");
				setPin("");
			}
		} else if (v.length >= 6) {
			toast.error("Sai mã PIN");
			setPin("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "app-shell grid min-h-dvh place-items-center px-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-[320px] text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "mx-auto size-10 text-primary" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 font-display text-lg font-semibold",
					children: "Tài liệu đã khóa"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Nhập mã PIN để mở"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					autoFocus: true,
					inputMode: "numeric",
					type: "password",
					value: pin,
					maxLength: 6,
					onChange: (e) => check(e.target.value.replace(/\D/g, "")),
					className: "mt-5 h-14 text-center text-2xl tracking-[0.5em]"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "mt-5 inline-block text-sm font-semibold text-primary",
					children: "Quay lại"
				})
			]
		})
	});
}
function Editor({ doc, initial, autoRun = false, startReview = false }) {
	const navigate = useNavigate();
	const [active, setActive] = (0, import_react.useState)(0);
	const activeRef = (0, import_react.useRef)(active);
	activeRef.current = active;
	const [panel, setPanel] = (0, import_react.useState)(initial);
	const [busy, setBusy] = (0, import_react.useState)("");
	const busyRef = (0, import_react.useRef)(busy);
	busyRef.current = busy;
	const [review, setReview] = (0, import_react.useState)(null);
	const scroller = (0, import_react.useRef)(null);
	const page = doc.pages[Math.min(active, doc.pages.length - 1)];
	(0, import_react.useEffect)(() => () => releaseRenderCache(), []);
	const sensitiveDoc = isSensitiveDoc(doc);
	setAiSensitivity(sensitiveDoc);
	(0, import_react.useEffect)(() => {
		setAiSensitivity(sensitiveDoc);
		return () => setAiSensitivity(null);
	}, [sensitiveDoc]);
	const save = (patch) => {
		const base = doc;
		return mutateDoc(base.id, (d) => ({
			...d,
			...patch,
			...patch.pages ? { pages: rebasePages(base.pages, patch.pages, d.pages) } : {}
		}), true);
	};
	const [batch, setBatch] = (0, import_react.useState)(startReview);
	const closeBatch = () => {
		setBatch(false);
		if (startReview) navigate({
			to: "/doc/$id",
			params: { id: doc.id },
			search: {},
			replace: true
		});
	};
	const saveChain = (0, import_react.useRef)(Promise.resolve());
	/** CS-07: ghi một chỉnh sửa cho nhiều trang trên bản MỚI NHẤT, dựng ảnh ở nền; không xếp được việc nền → dựng ngay (dự phòng). */
	async function saveEditsQueued(edit, ids) {
		const next = await mutateDoc(doc.id, (cur) => ({
			...cur,
			pages: applyEditToPages(cur.pages, edit, ids)
		}), true);
		if (!next) return;
		const queued = await healPending([next]);
		const want = next.pages.filter((p) => (!ids || ids.has(p.id)) && p.status === "dang").length;
		if (queued < want && bgQueue.list().filter((j) => j.kind === "finish" && next.pages.some((p) => p.id === j.pageId)).length < want) {
			const pages = [];
			for (const p of next.pages) pages.push(!ids || ids.has(p.id) ? {
				...p,
				src: await renderPage(p.orig, p.edit),
				status: "xong"
			} : p);
			await mutateDoc(doc.id, (now) => ({
				...now,
				pages: now.pages.map((x) => pages.find((y) => y.id === x.id && (!ids || ids.has(x.id))) ?? x)
			}), true);
		}
	}
	const savePageNow = (p, rebuild) => saveChain.current = saveChain.current.then(async () => {
		const next = await mutateDoc(doc.id, (cur) => ({
			...cur,
			pages: cur.pages.map((x) => x.id === p.id ? p : x)
		}), true);
		if (!next) return;
		if (rebuild && !await healPending([next])) {
			const src = await renderPage(p.orig, p.edit);
			await mutateDoc(doc.id, (now) => ({
				...now,
				pages: now.pages.map((x) => x.id === p.id ? {
					...x,
					src,
					status: "xong"
				} : x)
			}), true);
		}
	}).catch((e) => showError(e, "Chưa lưu được trang"));
	async function editPage(i, edit) {
		const p = doc.pages[i];
		const next = {
			...p.edit,
			...edit
		};
		const src = await renderPage(p.orig, next);
		await save({ pages: doc.pages.map((x, k) => k === i ? {
			...x,
			edit: next,
			src,
			manual: true
		} : x) });
		if (edit.filter && edit.filter !== p.edit.filter) {
			const kind = doc.fields?.["docType"] ?? doc.kind;
			import("./user-recipe-DhO7F1JT.mjs").then((m) => m.learnChoice(kind, edit.filter));
		}
	}
	const [reviews, setReviews] = (0, import_react.useState)({});
	const [tab, setTab] = (0, import_react.useState)("all");
	const [selecting, setSelecting] = (0, import_react.useState)(false);
	const [selected, setSelected] = (0, import_react.useState)([]);
	const [drag, setDrag] = (0, import_react.useState)(null);
	const pagesRef = (0, import_react.useRef)(doc.pages);
	pagesRef.current = doc.pages;
	const pageKey = doc.pages.map((p) => `${p.id}:${p.edit.filter}`).join("|");
	(0, import_react.useEffect)(() => {
		let current = true;
		(async () => {
			for (const p of pagesRef.current) {
				const key = `${p.id}:${p.edit.filter}`;
				let r = reviewCache.get(key);
				if (!r) try {
					let q = qualityCache.get(p.id);
					if (!q || q.orig !== p.orig) {
						const c = await checkQuality(p.orig, { cropped: true });
						q = {
							orig: p.orig,
							score: c.score,
							metrics: c.metrics
						};
						qualityCache.set(p.id, q);
					}
					r = {
						score: q.score,
						note: decisionNote(q.metrics, p.edit.filter)
					};
					reviewCache.set(key, r);
				} catch {
					continue;
				}
				if (!current) return;
				const found = r;
				setReviews((prev) => prev[p.id] === found ? prev : {
					...prev,
					[p.id]: found
				});
			}
		})();
		return () => {
			current = false;
		};
	}, [pageKey]);
	const shownPages = filterPages(doc.pages, reviews, tab);
	const activeReview = page ? reviews[page.id] : void 0;
	const layoutFn = useQueuedServerFn(aiLayout, "Đọc bố cục");
	const findQuad = useFindQuad();
	const saveWord = async (text) => {
		const r = await imagesToWord(doc.pages.map((p) => p.src), doc.name, layoutFn, text);
		setReview({
			kind: "word",
			title: doc.name,
			blocks: r.blocks,
			note: r.note,
			source: {
				kind: "Tài liệu → Word",
				name: `${safeName(doc.name)}.pdf`,
				lazy: registerSource(() => docToPdf(doc)),
				details: [`${doc.pages.length} trang ảnh`]
			}
		});
	};
	const run = (label, fn) => async () => {
		setBusy(label);
		try {
			await fn();
		} catch (e) {
			showError(e, label);
		} finally {
			setBusy("");
		}
	};
	const importing = (0, import_react.useRef)(false);
	const [insertPos, setInsertPos] = (0, import_react.useState)("after");
	const posRef = (0, import_react.useRef)(insertPos);
	posRef.current = insertPos;
	async function insertImages(files, pos) {
		if (!files.length || importing.current) return false;
		importing.current = true;
		setBusy("Đang nhập ảnh…");
		try {
			const stats = { skipped: 0 };
			const raw = await filesToPages(files, stats);
			if (!raw.length) {
				if (stats.skipped) toast.info("Đã bỏ qua ảnh trùng, không thêm trang nào");
				else toast.error("Không có ảnh hoặc PDF hợp lệ");
				return false;
			}
			const pages = await processImported(raw, (d, t) => setBusy(`Đang dò khung ${d}/${t} ảnh…`));
			const where = pos ?? posRef.current;
			const box = {};
			const saved = await mutateDoc(doc.id, (current) => {
				box.before = new Set(current.pages.map((p) => p.id));
				box.r = insertPagesAt(current.pages, pages, where, active);
				return {
					...current,
					pages: box.r.pages
				};
			}, true);
			if (!saved || !box.r || !box.before) return false;
			const before = box.before;
			setActive(box.r.active);
			postCaptureWithMetrics(saved, before, false, { heal: true });
			const at = where === "start" ? "đầu tài liệu" : where === "end" ? "cuối tài liệu" : `sau trang ${active + 1}`;
			toast.success(`Đã chèn ${pages.length} trang vào ${at}`);
			return true;
		} catch (error) {
			toast.error(userMessage(error, "Không nhập được ảnh"));
			return false;
		} finally {
			importing.current = false;
			setBusy("");
		}
	}
	async function pasteImages() {
		try {
			await insertImages(await readClipboardImages());
		} catch (error) {
			toast.error(userMessage(error, "Không dán được ảnh"));
		}
	}
	useImagePaste(insertImages, !busy && (panel === null || panel === "pages"));
	const [pairOn, setPairOn] = (0, import_react.useState)(false);
	const insRef = (0, import_react.useRef)(insertImages);
	insRef.current = insertImages;
	const pair = usePairDoc(pairOn, async (f) => {
		while (importing.current) await new Promise((r) => setTimeout(r, 300));
		return insRef.current([f], "end");
	});
	const [dragOver, setDragOver] = (0, import_react.useState)(false);
	const insertRef = (0, import_react.useRef)(insertImages);
	insertRef.current = insertImages;
	(0, import_react.useEffect)(() => {
		let depth = 0;
		const onEnter = (e) => {
			if (isFileDrag(e)) {
				depth++;
				setDragOver(true);
			}
		};
		const onLeave = (e) => {
			if (isFileDrag(e) && --depth <= 0) {
				depth = 0;
				setDragOver(false);
			}
		};
		const onOver = (e) => {
			if (isFileDrag(e)) e.preventDefault();
		};
		const onDrop = (e) => {
			if (!isFileDrag(e)) return;
			e.preventDefault();
			depth = 0;
			setDragOver(false);
			insertRef.current(filesFromDrop(e.dataTransfer));
		};
		window.addEventListener("dragenter", onEnter);
		window.addEventListener("dragleave", onLeave);
		window.addEventListener("dragover", onOver);
		window.addEventListener("drop", onDrop);
		return () => {
			window.removeEventListener("dragenter", onEnter);
			window.removeEventListener("dragleave", onLeave);
			window.removeEventListener("dragover", onOver);
			window.removeEventListener("drop", onDrop);
		};
	}, []);
	const panelRef = (0, import_react.useRef)(panel);
	panelRef.current = panel;
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.ctrlKey || e.metaKey || e.altKey) return;
			if (isEditingText(e.target)) return;
			const p = panelRef.current;
			if (p !== null && p !== "pages" && p !== "add") return;
			const action = docShortcut(e.key);
			if (!action) return;
			const d = getDocs().find((x) => x.id === doc.id);
			if (!d || busyRef.current) return;
			e.preventDefault();
			if (action === "prev" || action === "next") {
				const i = Math.max(0, Math.min(d.pages.length - 1, activeRef.current + (action === "next" ? 1 : -1)));
				setActive(i);
				goTo(i);
			} else if (action === "delete") {
				if (d.pages.length <= 1) {
					toast("Tài liệu cần ít nhất 1 trang");
					return;
				}
				const r = removePage(d.pages, activeRef.current, activeRef.current);
				const gone = d.pages[activeRef.current]?.id;
				mutateDoc(d.id, (x) => ({
					...x,
					pages: x.pages.filter((y) => y.id !== gone)
				}), true);
				setActive(r.active);
				toast.success(`Đã xoá trang ${activeRef.current + 1}`);
			} else {
				const i = activeRef.current;
				const pg = d.pages[i];
				(async () => {
					const edit = {
						...pg.edit,
						rotation: (pg.edit.rotation + 90) % 360
					};
					const src = await renderPage(pg.orig, edit);
					await mutateDoc(d.id, (x) => ({
						...x,
						pages: x.pages.map((y) => y.id === pg.id ? {
							...y,
							edit,
							src,
							manual: true
						} : y)
					}), true);
				})();
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [doc.id]);
	/** One-tap corner detection without opening the crop editor; saves all pages in one write. */
	async function autoCorners(all) {
		const idx = all ? doc.pages.map((_, i) => i) : [active];
		const pages = [...doc.pages];
		let ok = 0, ai = 0;
		for (const i of idx) {
			const p = pages[i];
			const r = await findQuad(p.orig);
			if (!r.q) continue;
			const edit = {
				...p.edit,
				quad: r.q
			};
			pages[i] = {
				...p,
				edit,
				src: await renderPage(p.orig, edit)
			};
			ok++;
			if (r.how === "ai") ai++;
		}
		if (ok) await save({ pages });
		if (!ok) toast("Không tự nhận được mép giấy, hãy bấm Cắt để kéo góc bằng tay");
		else toast(`Đã dò góc ${ok}/${idx.length} trang${ai ? " (có dùng AI — kiểm tra lại)" : ""}`);
	}
	function goTo(i) {
		scroller.current?.scrollTo({
			left: i * scroller.current.clientWidth,
			behavior: "smooth"
		});
	}
	const ocrJobs = useOcrJobs().filter((j) => j.docId === doc.id);
	(0, import_react.useSyncExternalStore)((fn) => bgQueue.subscribe(fn), () => bgQueue.size);
	const pageIds = new Set(doc.pages.map((p) => p.id));
	const pendingJobs = bgQueue.list().filter((j) => pageIds.has(j.pageId)).length + ocrJobs.length;
	const pendingPages = pendingPageCount(doc.pages);
	const busyCount = Math.max(pendingJobs, pendingPages);
	const pct = progressPct(busyCount, Math.max(doc.pages.length, busyCount));
	const startDrag = (i) => (e) => {
		e.preventDefault();
		e.stopPropagation();
		let cur = {
			from: i,
			over: i
		};
		setDrag(cur);
		const move = (ev) => {
			const el = document.elementFromPoint(ev.clientX, ev.clientY)?.closest("[data-page-idx]");
			const over = el ? Number(el.dataset["pageIdx"]) : cur.over;
			if (Number.isInteger(over) && over !== cur.over) {
				cur = {
					...cur,
					over
				};
				setDrag(cur);
			}
		};
		const end = (ev) => {
			window.removeEventListener("pointermove", move);
			window.removeEventListener("pointerup", end);
			window.removeEventListener("pointercancel", end);
			setDrag(null);
			if (ev.type === "pointerup" && cur.over !== cur.from) {
				const r = movePage(doc.pages, cur.from, cur.over, active);
				save({ pages: r.pages });
				setActive(r.active);
			}
		};
		window.addEventListener("pointermove", move);
		window.addEventListener("pointerup", end);
		window.addEventListener("pointercancel", end);
	};
	/** Queue OCR in the background; the user can keep editing or leave — results save themselves. */
	function ocr(all) {
		const idx = all ? doc.pages.map((_, i) => i) : [active];
		const tasks = ocrQueue().add(idx.map((i) => ({
			docId: doc.id,
			pageId: doc.pages[i].id,
			label: `${doc.name} · trang ${i + 1}`,
			src: doc.pages[i].src
		})));
		toast(`Đã xếp ${idx.length} trang vào hàng nhận chữ`);
		Promise.allSettled(tasks).then(async (rs) => {
			const failed = firstOcrFailure(rs);
			if (failed) showError(failed, "Nhận chữ");
			if (!rs.some((r) => r.status === "fulfilled")) return;
			const named = {};
			if (!await mutateDoc(doc.id, (cur) => {
				const c = classify(docText(cur));
				named.title = c.title;
				named.auto = /^\S.* \d{2}-\d{2} \d{2}:\d{2}$/.test(cur.name) && c.title;
				return {
					...cur,
					kind: cur.kind === "Tài liệu" || cur.kind === "Nhập" ? c.kind : cur.kind,
					...named.auto ? { name: c.title } : {}
				};
			}, true)) return;
			const { auto, title } = named;
			toast.success(auto ? `Đã nhận chữ và tự đặt tên: ${title}` : "Đã nhận chữ xong");
		});
	}
	if (!page) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "app-shell grid min-h-dvh place-items-center p-8 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-semibold",
			children: "Tài liệu chưa có trang nào"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-4",
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/scan",
				search: { doc: doc.id },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {}), " Quét thêm trang"]
			})
		})] })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "app-shell flex h-dvh flex-col overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex h-full w-full max-w-[430px] flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportReview, {
						review,
						onClose: () => setReview(null)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-2 px-3 pt-[max(0.75rem,env(safe-area-inset-top))] pb-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "glass",
								size: "icon",
								"aria-label": "Quay lại",
								onClick: () => navigate({ to: "/" }),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "min-w-0 text-left",
								onClick: () => setPanel("menu"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-display text-[0.9375rem] font-semibold",
										children: doc.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[0.6875rem] text-muted-foreground",
										children: [
											"Trang ",
											active + 1,
											"/",
											doc.pages.length,
											" · ",
											doc.kind,
											busyCount > 0 ? ` · đang xử lý ${pct}%` : ""
										]
									}),
									activeReview && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-[0.6875rem] text-muted-foreground",
										"data-testid": "decision-note",
										children: [
											activeReview.note,
											" · ",
											activeReview.score,
											"/100"
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "glass",
								size: "icon",
								"aria-label": "Tùy chọn",
								onClick: () => setPanel("menu"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EllipsisVertical, {})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: scroller,
						onScroll: (e) => setActive(Math.round(e.currentTarget.scrollLeft / e.currentTarget.clientWidth)),
						className: "flex min-h-0 flex-1 snap-x snap-mandatory overflow-x-auto [scrollbar-width:none]",
						children: doc.pages.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-full w-full shrink-0 snap-center place-items-center p-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LazyPage, {
								src: p.src,
								on: inPreviewWindow(i, active),
								alt: `Trang ${i + 1}`,
								thumb: p.thumb
							})
						}, p.id))
					}),
					busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mx-auto mb-2 flex items-center gap-2 rounded-full bg-foreground px-3 py-1.5 text-xs font-semibold text-background",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }), busy]
					}),
					!busy && needsCornerHint(page) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-4 pb-1 text-center text-xs text-muted-foreground",
						"data-testid": "corner-hint",
						children: "Ảnh nhập chưa được cắt khung — bấm “Tự dò góc” để cắt và nắn."
					}),
					!busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-center gap-2 px-4 pb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "glass",
							className: "rounded-full",
							onClick: run("Đang dò góc…", () => autoCorners(false)),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WandSparkles, {}), " Tự dò góc"]
						}), doc.pages.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "glass",
							className: "rounded-full",
							onClick: run("Đang dò góc mọi trang…", () => autoCorners(true)),
							children: "Mọi trang"
						})]
					}),
					!batch && reviewTargets(doc.pages, reviews).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-center px-4 pb-1.5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setBatch(true),
							className: "rounded-full bg-amber-500 px-3 py-1 text-xs font-semibold text-white",
							children: [
								"Xem lại ",
								reviewTargets(doc.pages, reviews).length,
								" trang"
							]
						})
					}),
					doc.pages.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-center gap-1.5 px-4 pb-1.5",
						role: "tablist",
						"aria-label": "Lọc trang",
						children: [
							"all",
							"review",
							"manual"
						].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							role: "tab",
							"aria-selected": tab === t,
							onClick: () => setTab(t),
							className: `rounded-full px-3 py-1 text-xs font-semibold ${tab === t ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`,
							children: [TAB_LABEL[t], t === "review" ? ` (${filterPages(doc.pages, reviews, "review").length})` : ""]
						}, t))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-center gap-1.5 overflow-x-auto px-4 pb-2 [scrollbar-width:none]",
						children: [shownPages.map((i) => {
							const p = doc.pages[i];
							const r = reviews[p.id];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => goTo(i),
								"aria-label": `Trang ${i + 1}${r && needsReview(r.score) ? " — cần xem lại" : ""}`,
								className: `relative h-12 w-9 shrink-0 overflow-hidden rounded-[5px] border-2 ${i === active ? "border-primary" : "border-transparent opacity-70"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StripThumb, {
									doc,
									i,
									className: "h-full w-full object-cover"
								}), r && needsReview(r.score) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute inset-x-0 bottom-0 bg-warning px-0.5 text-center text-[0.5rem] font-bold leading-tight text-warning-foreground",
									children: "Xem lại"
								})]
							}, p.id);
						}), shownPages.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "py-3 text-xs text-muted-foreground",
							children: "Không có trang nào."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "bottom-nav grid grid-cols-8 px-1 pb-[env(safe-area-inset-bottom)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crop, {}),
								label: "Cắt",
								onClick: () => setPanel("crop")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, {}),
								label: "Xoay",
								onClick: run("Đang xoay…", () => editPage(active, { rotation: (page.edit.rotation + 90) % 360 }))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {}),
								label: "Lọc",
								onClick: () => setPanel("filter")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, {}),
								label: "Ký/Vẽ",
								onClick: () => setPanel("sign")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Type, {}),
								label: "Chữ",
								onClick: () => setPanel("ocr")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}),
								label: "AI",
								onClick: () => setPanel("ai")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "col-span-2 grid grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, {}),
										label: "Xuất",
										primary: true,
										note: pendingPages > 0 ? `còn ${pendingPages}` : void 0,
										aria: pendingPages > 0 ? `Xuất — còn ${pendingPages} trang đang xử lý (${pct}%)` : void 0,
										onClick: () => {
											if (!doc) return;
											import("./quick-export-Bj-jGh2q.mjs").then(async ({ quickExportPdf, reviewReminder }) => {
												try {
													const [fresh] = await readyDocs([doc]);
													await quickExportPdf(fresh, reviews);
													toast.success("Đã lưu PDF");
													const remind = reviewReminder(reviews);
													if (remind) toast(remind, { action: {
														label: "Xem lại",
														onClick: () => setTab("review")
													} });
												} catch (e) {
													showError(e, "Không tạo được PDF");
												}
											});
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EllipsisVertical, {}),
										label: "Tùy chọn",
										onClick: () => {
											readyDocs([doc]).then(() => setPanel("export"));
										}
									}),
									" "
								]
							})
						]
					})
				]
			}),
			batch && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BatchReview, {
				doc,
				reviews,
				onSavePage: savePageNow,
				onClose: closeBatch,
				onOpenPage: (i) => {
					setActive(i);
					goTo(i);
				}
			}),
			panel === "crop" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CropEditor, {
				src: page.orig,
				quad: page.edit.quad,
				paper: page.edit.paper,
				onClose: () => setPanel(null),
				onApply: async (quad, paper) => {
					setPanel(null);
					await run("Đang cắt thẳng…", () => editPage(active, {
						quad,
						paper
					}))();
				}
			}),
			panel === "region" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RegionOcr, {
				src: page.src,
				onClose: () => setPanel("ocr"),
				onAppend: (t) => void save({ pages: doc.pages.map((x, k) => k === active ? {
					...x,
					text: x.text ? `${x.text}\n${t}` : t
				} : x) })
			}),
			panel === "redact" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedactEditor, {
				src: page.src,
				onClose: () => setPanel(null),
				onApply: async (src) => {
					setPanel(null);
					await save({ pages: doc.pages.map((x, k) => k === active ? {
						id: x.id,
						orig: src,
						src,
						edit: {
							rotation: 0,
							filter: "original",
							brightness: 0,
							contrast: 0
						}
					} : x) });
				}
			}),
			panel === "erase" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EraseEditor, {
				src: page.src,
				onClose: () => setPanel(null),
				onApply: async (src) => {
					setPanel(null);
					await save({ pages: doc.pages.map((x, k) => k === active ? {
						...x,
						orig: src,
						src,
						edit: {
							rotation: 0,
							filter: "original",
							brightness: 0,
							contrast: 0
						}
					} : x) });
				}
			}),
			panel === "sign" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignaturePlacer, {
				src: page.src,
				onClose: () => setPanel(null),
				onFreehand: () => setPanel("pen"),
				onApply: async (src) => {
					setPanel(null);
					await save({ pages: doc.pages.map((x, k) => k === active ? {
						...x,
						orig: src,
						src,
						edit: {
							rotation: 0,
							filter: "original",
							brightness: 0,
							contrast: 0
						}
					} : x) });
					toast.success("Đã chèn chữ ký");
				}
			}),
			(panel === "pen" || panel === "draw") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrawPad, {
				page,
				highlight: panel === "draw",
				onClose: () => setPanel(null),
				onApply: async (overlay) => {
					setPanel(null);
					let src;
					try {
						src = await stamp(page.src, overlay);
					} finally {
						revokeTemp(overlay);
					}
					await save({ pages: doc.pages.map((x, k) => k === active ? {
						...x,
						orig: src,
						src,
						edit: {
							rotation: 0,
							filter: "original",
							brightness: 0,
							contrast: 0
						}
					} : x) });
				}
			}),
			(panel === "adjust" || panel === "filter") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SafeBoundary, {
				overlay: true,
				title: "Màn chỉnh sửa gặp sự cố.",
				onClose: () => setPanel(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdjustEditor, {
					page,
					onClose: () => setPanel(null),
					onApply: async (edit) => {
						setPanel(null);
						await run("Đang lưu chỉnh sửa…", () => editPage(active, edit))();
					},
					onApplyAll: doc.pages.length > 1 ? async (edit) => {
						setPanel(null);
						await run("Đang áp dụng cho tất cả…", () => saveEditsQueued(edit))();
						toast.success(`Đã áp dụng cho ${doc.pages.length} trang — ảnh đang được dựng ở nền`);
					} : void 0,
					onApplySimilar: doc.pages.length > 1 ? async (edit) => {
						setPanel(null);
						await run("Đang tìm trang tương tự…", async () => {
							const metrics = /* @__PURE__ */ new Map();
							for (const p of doc.pages) try {
								metrics.set(p.id, (await checkQuality(p.orig, { cropped: true })).metrics);
							} catch {}
							const ids = /* @__PURE__ */ new Set([page.id, ...findSimilar(page.id, metrics).map((m) => m.pageId)]);
							await saveEditsQueued(edit, ids);
							toast.success(ids.size > 1 ? `Đã áp dụng cho ${ids.size} trang tương tự` : "Không thấy trang tương tự — chỉ áp trang này");
						})();
					} : void 0,
					extra: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanDiagnosePanel, {
						pageId: page.id,
						filter: page.edit.filter,
						src: page.src
					})
				})
			}, page.id),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				open: panel === "ocr",
				onClose: () => setPanel(null),
				title: "Nhận diện chữ",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "flex-1",
							onClick: () => ocr(false),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WandSparkles, {}), " Trang này"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "glass",
							className: "flex-1",
							onClick: () => ocr(true),
							children: "Tất cả trang"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "glass",
						className: "mt-2 w-full",
						onClick: () => setPanel("region"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crop, {}), " Chọn vùng để nhận chữ"]
					}),
					ocrJobs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-center justify-between rounded-[10px] bg-muted px-3 py-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [ocrJobs.length, " trang đang chờ/đang đọc — có thể đóng bảng này, chữ tự lưu."] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "glass",
							size: "sm",
							onClick: () => void ocrQueue().cancel((j) => j.docId === doc.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}), " Hủy"]
						})]
					}),
					page.text != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: page.text,
						onChange: (e) => save({ pages: doc.pages.map((x, k) => k === active ? {
							...x,
							text: e.target.value
						} : x) }),
						className: "mt-3 h-48 w-full rounded-[12px] border border-border bg-card p-3 text-sm leading-6 outline-none focus:ring-2 focus:ring-ring"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "glass",
								size: "sm",
								onClick: () => {
									navigator.clipboard.writeText(docText(doc));
									toast("Đã sao chép");
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), " Sao chép"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "glass",
								size: "sm",
								disabled: !!busy,
								onClick: run("Đang dựng tệp Word…", () => saveWord(docText(doc))),
								children: "Word"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "glass",
								size: "sm",
								onClick: () => download(new Blob([docToTxt(doc.pages)], { type: "text/plain;charset=utf-8" }), `${safeName(doc.name)}.txt`),
								children: "TXT"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "glass",
								size: "sm",
								onClick: () => download(new Blob([docToMarkdown(doc.name, doc.pages)], { type: "text/markdown;charset=utf-8" }), `${safeName(doc.name)}.md`),
								children: "Markdown"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "glass",
								size: "sm",
								className: "col-span-2",
								disabled: !!busy,
								onClick: run("Đang dựng tệp PowerPoint…", async () => {
									const slides = [];
									for (const p of doc.pages) slides.push(await pageToSlide(p.src, p.text));
									download(slidesToPptx(slides, doc.name), `${safeName(doc.name)}.pptx`);
									toast("Đã xuất PowerPoint — chữ nằm ở phần ghi chú mỗi trang");
								}),
								children: "PowerPoint"
							})
						]
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				open: panel === "pages",
				onClose: () => {
					setPanel(null);
					setSelected([]);
				},
				title: `Sắp xếp ${doc.pages.length} trang${busyCount > 0 ? ` · đang xử lý ${pct}%` : ""}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: selecting ? `Đã chọn ${selected.length} trang` : "Kéo thả để đổi thứ tự"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: selecting ? "default" : "glass",
							onClick: () => {
								setSelecting(!selecting);
								setSelected([]);
							},
							children: selecting ? "Xong" : "Chọn"
						})]
					}),
					selecting && selected.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "glass",
								disabled: !!busy,
								onClick: run("Đang xoay các trang đã chọn…", async () => {
									for (const id of selected) {
										const i = doc.pages.findIndex((p) => p.id === id);
										if (i >= 0) await editPage(i, { rotation: (doc.pages[i].edit.rotation + 90) % 360 });
									}
									setSelected([]);
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, {}), " Xoay"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "glass",
								onClick: () => {
									const r = duplicatePages(doc.pages, new Set(selected), (x) => ({
										...x,
										id: crypto.randomUUID()
									}), active);
									save({ pages: r.pages }).then((d) => d && healPending([d]));
									setActive(r.active);
									setSelected([]);
									toast.success(`Đã nhân bản ${selected.length} trang`);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), " Nhân bản"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "glass",
								disabled: selected.length >= doc.pages.length,
								onClick: () => {
									const r = removePages(doc.pages, new Set(selected), active);
									save({ pages: r.pages });
									setActive(r.active);
									setSelected([]);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Xóa"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid max-h-[50vh] grid-cols-3 gap-2.5 overflow-y-auto",
						children: [doc.pages.map((p, i) => {
							const isSel = selected.includes(p.id);
							const processing = bgQueue.has(p.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								"data-page-idx": i,
								draggable: !selecting && !drag,
								onDragStart: (e) => {
									if (drag) {
										e.preventDefault();
										return;
									}
									e.dataTransfer.setData("text/plain", String(i));
									e.dataTransfer.effectAllowed = "move";
								},
								onDragOver: (e) => {
									if (!selecting) {
										e.preventDefault();
										e.dataTransfer.dropEffect = "move";
									}
								},
								onDrop: (e) => {
									if (selecting) return;
									e.preventDefault();
									const from = Number(e.dataTransfer.getData("text/plain"));
									if (Number.isInteger(from) && from !== i) {
										const r = movePage(doc.pages, from, i, active);
										save({ pages: r.pages });
										setActive(r.active);
									}
								},
								onClick: selecting ? () => setSelected((s) => toggleId(s, p.id)) : void 0,
								className: `document-row rounded-[10px] p-1.5 ${selecting ? "cursor-pointer" : "cursor-grab"} ${isSel ? "ring-2 ring-primary" : ""} ${drag?.from === i ? "opacity-50" : ""} ${drag && drag.over === i && drag.from !== i ? "ring-2 ring-primary ring-offset-2" : ""}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative aspect-[3/4] overflow-hidden rounded-[6px] bg-muted",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StripThumb, {
											doc,
											i,
											className: "h-full w-full object-cover"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "absolute left-1 top-1 rounded bg-foreground px-1.5 text-[0.625rem] font-bold text-background",
											children: i + 1
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TileBadge, {
											b: pageBadge(p) ?? (processing ? {
												kind: "dang",
												text: "Đang xử lý…"
											} : null),
											n: i + 1
										}),
										!selecting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"data-grip": true,
											"aria-label": `Kéo để đổi chỗ trang ${i + 1}`,
											onPointerDown: startDrag(i),
											style: { touchAction: "none" },
											className: "absolute right-0.5 top-0.5 grid size-8 cursor-grab place-items-center rounded-md bg-background/80 text-muted-foreground active:cursor-grabbing [&_svg]:size-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GripVertical, {})
										}),
										selecting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `absolute right-1 top-1 grid size-5 place-items-center rounded-full border text-[0.625rem] font-bold ${isSel ? "border-primary bg-primary text-primary-foreground" : "border-muted-foreground/50 bg-background/70 text-transparent"}`,
											children: "✓"
										})
									]
								}), !selecting && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 grid grid-cols-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
											label: "Lên",
											disabled: !i,
											onClick: () => {
												const r = movePage(doc.pages, i, i - 1, active);
												save({ pages: r.pages });
												setActive(r.active);
											},
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, {})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
											label: "Xuống",
											disabled: i === doc.pages.length - 1,
											onClick: () => {
												const r = movePage(doc.pages, i, i + 1, active);
												save({ pages: r.pages });
												setActive(r.active);
											},
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, {})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
											label: "Xoay",
											onClick: run("Đang xoay…", () => editPage(i, { rotation: (p.edit.rotation + 90) % 360 })),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, {})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
											label: "Nhân bản",
											onClick: () => {
												const r = duplicatePage(doc.pages, i, (x) => ({
													...x,
													id: crypto.randomUUID()
												}));
												save({ pages: r.pages }).then((d) => d && healPending([d]));
												setActive(r.active);
												toast.success(`Đã nhân bản trang ${i + 1}`);
											},
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
											label: "Xóa",
											disabled: doc.pages.length <= 1,
											onClick: () => {
												const r = removePage(doc.pages, i, active);
												save({ pages: r.pages });
												setActive(r.active);
											},
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
										})
									]
								})]
							}, p.id);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							"aria-label": "Thêm trang",
							disabled: !!busy,
							onClick: () => setPanel("add"),
							className: "grid aspect-[3/4] place-items-center rounded-[10px] border-2 border-dashed border-muted-foreground/40 text-muted-foreground disabled:opacity-40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex flex-col items-center gap-1 text-xs font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-6" }), " Thêm"]
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "glass",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/scan",
									search: { doc: doc.id },
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {}), " Quét thêm"]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "glass",
								disabled: !!busy,
								onClick: () => setPanel("add"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {}), " Nhập thêm"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "glass",
								className: "col-span-2",
								disabled: !!busy,
								onClick: () => void pasteImages(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, {}), " Dán ảnh"]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				open: panel === "add",
				onClose: () => setPanel(null),
				title: "Thêm trang",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-xs font-semibold text-muted-foreground",
						children: "Vị trí chèn"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-3 flex gap-2",
						children: [
							"start",
							"after",
							"end"
						].map((pos) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: insertPos === pos ? "default" : "glass",
							onClick: () => setInsertPos(pos),
							children: pos === "after" ? `Sau trang ${active + 1}` : INSERT_POS_LABEL[pos]
						}, pos))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: ADD_SOURCES.map((src) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "glass",
							disabled: !!busy,
							className: src === "scan" ? "col-span-2" : "",
							onClick: async () => {
								if (src === "scan") {
									setPanel(null);
									navigate({
										to: "/scan",
										search: { doc: doc.id }
									});
									return;
								}
								if (src === "paste") {
									setPanel(null);
									await pasteImages();
									return;
								}
								const files = await pickFiles(src === "pdf" ? "application/pdf" : src === "camera" ? IMAGE_ACCEPT : FILE_ACCEPT, true, src === "camera" ? "environment" : void 0);
								if (files.length) {
									setPanel(null);
									await insertImages(files);
								}
							},
							children: [
								src === "library" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {}),
								src === "camera" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {}),
								src === "pdf" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, {}),
								src === "paste" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, {}),
								src === "scan" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {}),
								ADD_SOURCE_LABEL[src]
							]
						}, src))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "glass",
						className: "mt-2 w-full",
						onClick: () => {
							setPairOn(true);
							setPanel("pair");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, {}), "Chụp bằng điện thoại (quét mã QR)"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted-foreground",
						children: "Mẹo: kéo-thả ảnh/PDF vào cửa sổ, hoặc dùng phím Delete xoá trang, ←/→ chuyển trang, R xoay."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: panel === "pair",
				onClose: () => setPanel(null),
				title: "Chụp bằng điện thoại",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PairDocBody, {
					st: pair,
					onStop: () => {
						setPairOn(false);
						setPanel(null);
					}
				})
			}),
			pairOn && panel !== "pair" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setPanel("pair"),
				className: "fixed bottom-20 left-3 z-40 flex items-center gap-2 rounded-full border bg-background px-3 py-2 text-sm shadow-lg",
				"data-testid": "pair-chip",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, {
					className: "h-4 w-4",
					"aria-hidden": true
				}), pair.phone ? `Điện thoại đã nối · ${pair.queue.filter((x) => x.state === "done").length} ảnh` : "Chờ điện thoại"]
			}),
			dragOver && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none fixed inset-0 z-[60] grid place-items-center bg-foreground/30 p-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid size-full place-items-center rounded-[22px] border-4 border-dashed border-background/80",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-full bg-background px-5 py-2.5 font-display font-semibold text-foreground shadow-lg",
						children: "Thả ảnh hoặc PDF để thêm trang"
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: !!panel?.startsWith("ai"),
				onClose: () => setPanel(null),
				title: "Trợ lý AI",
				children: panel?.startsWith("ai") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SafeBoundary, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiPanel, {
					doc,
					active,
					initial: panel === "ai" ? "extract" : panel.slice(3),
					autoRun: autoRun && panel === "ai"
				}) })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: panel === "export",
				onClose: () => setPanel(null),
				title: "Xuất & chia sẻ",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportPanel, {
					doc,
					page
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: panel === "menu",
				onClose: () => setPanel(null),
				title: "Tài liệu",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuPanel, {
					doc,
					onPages: () => setPanel("pages"),
					onDraw: () => setPanel("draw"),
					onRedact: () => setPanel("redact"),
					onErase: () => setPanel("erase"),
					onSharpen: () => {
						setPanel(null);
						(async () => {
							const id = toast.loading("Đang làm nét HD… 0%");
							try {
								const { enhanceDataUrl } = await import("./sr-enhance-CAa0f4ey.mjs");
								const r = await enhanceDataUrl(page.src, { onProgress: (p) => toast.loading(`Đang làm nét HD… ${p}%`, { id }) });
								await save({ pages: doc.pages.map((x, k) => k === active ? {
									...x,
									orig: r.src,
									src: r.src,
									edit: {
										rotation: 0,
										filter: "original",
										brightness: 0,
										contrast: 0
									}
								} : x) });
								toast.success(`Đã làm nét HD (${r.width}×${r.height}${r.method === "classic" ? ", cách cổ điển" : ""})`, { id });
							} catch (e) {
								toast.dismiss(id);
								showError(e, "Làm nét HD");
							}
						})();
					},
					onMoire: () => {
						setPanel(null);
						(async () => {
							const id = toast.loading("Đang khử vân màn hình…");
							try {
								const { removeMoireDataUrl } = await import("./importer-BUHDogNt.mjs").then((n) => n.p);
								const r = await removeMoireDataUrl(page.src);
								await save({ pages: doc.pages.map((x, k) => k === active ? {
									...x,
									orig: r.src,
									src: r.src,
									edit: {
										rotation: 0,
										filter: "original",
										brightness: 0,
										contrast: 0
									}
								} : x) });
								toast.success(r.before < 1.5 ? "Ảnh gần như không có vân, đã làm mịn nhẹ" : "Đã khử vân màn hình", { id });
							} catch (e) {
								toast.dismiss(id);
								showError(e, "Khử vân màn hình");
							}
						})();
					},
					onDeleted: () => navigate({ to: "/" })
				})
			})
		]
	});
}
function Tool({ icon, label, onClick, primary, note, aria }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick,
		"aria-label": aria,
		className: `relative flex h-16 flex-col items-center justify-center gap-1 whitespace-nowrap text-[0.65625rem] font-semibold [&_svg]:size-5 ${primary ? "text-primary" : ""}`,
		children: [
			icon,
			label,
			note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute right-0.5 top-1 rounded-full bg-amber-500 px-1 text-[0.5625rem] font-bold leading-4 text-white",
				children: note
			})
		]
	});
}
/** CS-08: nhãn trạng thái trên ô trang; có lý do (lỗi, xem lại, tự lọc) thì chạm để đọc. */
var BADGE_CLS = {
	cho: "bg-foreground/70 text-background",
	dang: "bg-foreground/70 text-background",
	"xem-lai": "bg-amber-500 text-white",
	loi: "bg-destructive text-destructive-foreground",
	"tu-loc": "bg-primary/85 text-primary-foreground"
};
function TileBadge({ b, n }) {
	if (!b) return null;
	const cls = `absolute inset-x-0 bottom-0 min-h-6 px-1 text-center text-[0.625rem] font-semibold leading-6 ${BADGE_CLS[b.kind]}`;
	if (!b.reason) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		"data-badge": b.kind,
		className: cls,
		children: b.text
	});
	const show = (e) => {
		e.stopPropagation();
		(b.kind === "loi" ? toast.error : toast)(`Trang ${n}: ${b.text}`, { description: b.reason });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"data-badge": b.kind,
		onClick: show,
		"aria-label": `Trang ${n}: ${b.text} — xem lý do`,
		className: cls,
		children: [b.text, " ⓘ"]
	});
}
function IconBtn({ children, label, onClick, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		"aria-label": label,
		disabled,
		onClick,
		className: "grid h-8 place-items-center text-muted-foreground disabled:opacity-30 [&_svg]:size-4",
		children
	});
}
function Sheet({ open, onClose, title, children }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			"aria-label": "Đóng",
			className: "absolute inset-0 bg-foreground/30",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sheet rise relative w-full max-w-[430px] rounded-t-[22px] px-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-3 h-1 w-10 rounded-full bg-muted-foreground/30" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display font-semibold",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						"aria-label": "Đóng",
						onClick: onClose,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					})]
				}),
				children
			]
		})]
	});
}
function ExportPanel({ doc, page }) {
	const [paper, setPaper] = (0, import_react.useState)("fit");
	(0, import_react.useEffect)(() => {
		setPaper(getSettings().pdfPage ?? "fit");
	}, []);
	const [watermark, setWatermark] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [sendTo, setSendTo] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [review, setReview] = (0, import_react.useState)(null);
	const layoutFn = useQueuedServerFn(aiLayout, "Đọc bố cục");
	const [size, setSizeRaw] = (0, import_react.useState)("balanced");
	(0, import_react.useEffect)(() => {
		const v = localStorage.getItem("gn.pdfSize");
		if (v && v in PDF_SIZES) setSizeRaw(v);
	}, []);
	const setSize = (v) => {
		setSizeRaw(v);
		localStorage.setItem("gn.pdfSize", v);
	};
	const [bw, setBw] = (0, import_react.useState)(false);
	const [mrc, setMrcRaw] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			setMrcRaw(localStorage.getItem("gn.pdfMrc") === "1");
		} catch {}
	}, []);
	const setMrc = (v) => {
		setMrcRaw(v);
		try {
			localStorage.setItem("gn.pdfMrc", v ? "1" : "0");
		} catch {}
	};
	const [est, setEst] = (0, import_react.useState)("");
	const [numbers, setNumbers] = (0, import_react.useState)(false);
	const [numberStyle, setNumberStyle] = (0, import_react.useState)("Trang n/N");
	const [header, setHeader] = (0, import_react.useState)("");
	const [footer, setFooter] = (0, import_react.useState)("");
	const opts = {
		paper,
		size,
		bw,
		mrc,
		watermark: watermark.trim() || void 0,
		password: password.trim() || void 0,
		marks: {
			numbers,
			numberStyle,
			header,
			footer
		}
	};
	(0, import_react.useEffect)(() => {
		let off = false;
		setEst("");
		(async () => {
			await compressPage(doc.pages[0].src, size, bw);
			const bytes = doc.pages.reduce((n, p) => n + srcBytes$1(p.src), 0);
			if (!off) setEst(bytes > 1e6 ? `${(bytes / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1e3))} KB`);
		})().catch(() => {});
		return () => {
			off = true;
		};
	}, [
		doc,
		size,
		bw
	]);
	const isId = isIdDoc(doc, docText(doc));
	const [idOn, setIdOn] = (0, import_react.useState)(isId);
	const [purpose, setPurpose] = (0, import_react.useState)("");
	const markText = idOn ? idWatermarkText(purpose, /* @__PURE__ */ new Date()) : "";
	const marked = async (srcs) => {
		if (idOn && !markText) throw new Error("Nhập mục đích sử dụng để đóng hình mờ CCCD (hoặc tắt hình mờ).");
		return markText ? Promise.all(srcs.map((s) => stampIdWatermark(s, markText))) : srcs;
	};
	const pdfOut = async () => {
		const srcs = await marked(doc.pages.map((p) => p.src));
		return docToPdf({
			...doc,
			pages: doc.pages.map((p, i) => ({
				...p,
				src: srcs[i]
			}))
		}, {
			...opts,
			fromOrig: !markText
		});
	};
	const pageSrc = async () => (await marked([page.src]))[0];
	const name = `${safeName(doc.name)}.pdf`;
	const go = (fn) => async () => {
		setBusy(true);
		try {
			await fn();
		} catch (e) {
			showError(e, "Không tạo được tập tin");
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: [
				"fit",
				"a4",
				"letter"
			].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: paper === p ? "default" : "glass",
				onClick: () => setPaper(p),
				children: PDF_PAPER_LABEL[p]
			}, p))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-wrap gap-2",
			children: [
				Object.keys(PDF_SIZES).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: size === s ? "default" : "glass",
					onClick: () => setSize(s),
					children: PDF_SIZES[s].label
				}, s)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: bw ? "default" : "glass",
					onClick: () => setBw(!bw),
					children: "Đen trắng"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: mrc && !bw ? "default" : "glass",
					disabled: bw || paper !== "fit",
					onClick: () => setMrc(!mrc),
					children: "HD nhẹ"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-xs text-muted-foreground",
			children: [
				"Dung lượng ước tính: ",
				est || "đang tính…",
				bw ? " · đen trắng hợp với giấy chữ, không hợp ảnh màu" : "",
				mrc && !bw && paper === "fit" ? " · HD nhẹ: chữ sắc như bản in, nền nén thấp — thực tế nhỏ hơn số ước tính (trang ảnh chụp giữ nguyên)" : ""
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 rounded-xl border border-border p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: "Hình mờ giấy tờ tùy thân"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: idOn ? "default" : "glass",
					onClick: () => setIdOn(!idOn),
					children: idOn ? "Đang bật" : "Bật"
				})]
			}), idOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: "Chữ đỏ lặp kín ảnh, không cắt bỏ được — người nhận chỉ dùng được đúng mục đích bạn ghi."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex flex-wrap gap-2",
					children: ID_PURPOSES.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: purpose === x ? "default" : "glass",
						onClick: () => setPurpose(x),
						children: x
					}, x))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-2 h-11",
					placeholder: "Hoặc ghi mục đích, ví dụ: mở tài khoản VCB",
					value: purpose,
					onChange: (e) => setPurpose(e.target.value)
				}),
				markText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs font-medium text-destructive",
					children: markText
				}) : null
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: isId ? "Nên bật khi gửi ảnh CCCD cho người khác." : "Dùng khi gửi ảnh CCCD, hộ chiếu cho người khác."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			className: "mt-3 h-11",
			placeholder: "Hình mờ (tùy chọn), ví dụ: BẢN SAO",
			value: watermark,
			onChange: (e) => setWatermark(e.target.value)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			className: "mt-2 h-11",
			type: "password",
			placeholder: "Mật khẩu PDF (tùy chọn)",
			value: password,
			onChange: (e) => setPassword(e.target.value)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 rounded-xl border border-border p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold",
						children: "Số trang"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: numbers ? "default" : "glass",
						onClick: () => setNumbers(!numbers),
						children: numbers ? "Đang bật" : "Bật"
					})]
				}),
				numbers ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex flex-wrap gap-2",
					children: NUMBER_STYLES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: numberStyle === s ? "default" : "glass",
						onClick: () => setNumberStyle(s),
						children: pageNumberText(s, 1, doc.pages.length)
					}, s))
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-2 h-11",
					placeholder: "Đầu trang (tùy chọn), ví dụ: {ten}",
					value: header,
					onChange: (e) => setHeader(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-2 h-11",
					placeholder: "Chân trang (tùy chọn), ví dụ: Ngày {ngay}",
					value: footer,
					onChange: (e) => setFooter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: [
						"Mã tự điền: ",
						"{ten}",
						" tên tài liệu, ",
						"{ngay}",
						" ngày hôm nay, ",
						"{trang}",
						" / ",
						"{tong}",
						" số trang."
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid grid-cols-2 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					disabled: busy,
					onClick: go(async () => {
						await shareOrDownload(await pdfOut(), name);
					}),
					children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, {}), " Chia sẻ PDF"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					disabled: busy,
					variant: "glass",
					onClick: go(async () => {
						download(await pdfOut(), name);
						toast.success("Đã lưu PDF");
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, {}), " Lưu PDF"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: busy,
					variant: "glass",
					onClick: go(async () => {
						await shareOrDownload(await dataUrlToBlob(await pageSrc()), `${safeName(doc.name)}-trang.jpg`);
					}),
					children: "Ảnh JPG"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: busy,
					variant: "glass",
					onClick: go(async () => {
						await shareOrDownload(await pageToPng(await pageSrc()), `${safeName(doc.name)}-trang.png`);
					}),
					children: "Ảnh PNG rõ nét"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: busy,
					variant: "glass",
					onClick: go(async () => {
						await shareOrDownload(await pagesToLongImage(await marked(doc.pages.map((p) => p.src))), `${safeName(doc.name)}-anh-dai.jpg`);
					}),
					children: "Ảnh dài ghép trang"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: busy,
					variant: "glass",
					onClick: go(async () => {
						download(await pagesToZip(await marked(doc.pages.map((p) => p.src)), safeName(doc.name)), `${safeName(doc.name)}-anh.zip`);
						toast.success("Đã lưu tệp nén");
					}),
					children: "Tệp nén mọi trang"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: busy,
					variant: "glass",
					onClick: go(async () => {
						const { buildBundle } = await import("./export-bundle-DTDgvJ_l.mjs");
						download(await buildBundle(safeName(doc.name), await pdfOut(), await marked(doc.pages.map((p) => p.src)), docText(doc)), `${safeName(doc.name)}-goi-day-du.zip`);
						toast.success("Đã lưu gói PDF + ảnh + chữ");
					}),
					children: "Gói đầy đủ (ZIP)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					disabled: busy,
					variant: "glass",
					onClick: go(async () => {
						const r = await imagesToWord(doc.pages.map((p) => p.src), doc.name, layoutFn, docText(doc));
						setReview({
							kind: "word",
							title: doc.name,
							blocks: r.blocks,
							note: r.note,
							source: {
								kind: "Tài liệu → Word",
								name: `${safeName(doc.name)}.pdf`,
								lazy: registerSource(() => docToPdf(doc)),
								details: [`${doc.pages.length} trang ảnh`]
							}
						});
					}),
					children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, {}), " Word"]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 rounded-xl border border-border p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: "Gửi tới"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: "Gửi PDF qua email, Zalo hoặc ứng dụng khác trên máy. Trên máy tính, tệp được tải về rồi mở thư để bạn đính kèm."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-2 h-11",
					type: "email",
					placeholder: "Email người nhận (tùy chọn)",
					value: sendTo,
					onChange: (e) => setSendTo(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 grid grid-cols-3 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: busy,
							variant: "glass",
							onClick: go(async () => {
								await sendFile("email", await pdfOut(), name, {
									title: doc.name,
									pages: doc.pages.length,
									to: sendTo
								});
							}),
							children: "Email"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: busy,
							variant: "glass",
							onClick: go(async () => {
								await sendFile("zalo", await pdfOut(), name, {
									title: doc.name,
									pages: doc.pages.length
								});
							}),
							children: "Zalo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: busy,
							variant: "glass",
							onClick: go(async () => {
								await sendFile("system", await pdfOut(), name, {
									title: doc.name,
									pages: doc.pages.length
								});
							}),
							children: "Khác…"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveFolderRow, {
					getBlob: pdfOut,
					name,
					busy,
					onBusy: setBusy,
					onError: (e) => showError(e, "Không lưu được vào thư mục")
				}),
				driveReady() && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-2 w-full",
					disabled: busy,
					variant: "glass",
					onClick: go(async () => {
						const r = await saveToDrive(await pdfOut(), name);
						toast.success("Đã lưu vào Google Drive › Ghi Nhanh", { action: {
							label: "Mở",
							onClick: () => window.open(r.link, "_blank", "noopener")
						} });
					}),
					children: "Lưu vào Google Drive"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShareLinkPanel, { doc }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportReview, {
			review,
			onClose: () => setReview(null)
		})
	] });
}
function MenuPanel({ doc, onPages, onDraw, onRedact, onErase, onSharpen, onMoire, onDeleted }) {
	const s = useSettings();
	const [name, setName] = (0, import_react.useState)(doc.name);
	const [pick, setPick] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: "text-xs font-semibold",
			children: "Tên tài liệu"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			className: "mt-1 h-11",
			value: name,
			onChange: (e) => setName(e.target.value),
			onBlur: () => name.trim() && mutateDoc(doc.id, (d) => ({
				...d,
				name: name.trim()
			}), true)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: "mt-3 block text-xs font-semibold",
			children: "Thư mục"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: () => setPick("folder"),
			className: "glass-field mt-1 flex h-11 w-full items-center gap-2 rounded-md px-3 text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Folder, { className: "size-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate",
				children: doc.folder.replace(/\//g, " › ")
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: "mt-3 block text-xs font-semibold",
			children: "Thẻ"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1 flex flex-wrap items-center gap-1.5",
			children: [(doc.tags ?? []).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagChip, {
				name: t,
				onRemove: () => void mutateDoc(doc.id, (d) => ({
					...d,
					tags: (d.tags ?? []).filter((x) => x !== t)
				}), true)
			}, t)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "glass",
				size: "sm",
				className: "h-7 text-[0.6875rem]",
				onClick: () => setPick("tags"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tags, {}), " Gắn thẻ"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderPicker, {
			open: pick === "folder",
			onOpenChange: (o) => setPick(o ? "folder" : null),
			value: doc.folder,
			onPick: (f) => {
				mutateDoc(doc.id, (d) => ({
					...d,
					folder: f
				}), true);
				setPick(null);
				toast.success(`Đã chuyển vào "${f}"`);
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagPicker, {
			open: pick === "tags",
			onOpenChange: (o) => setPick(o ? "tags" : null),
			value: doc.tags ?? [],
			onChange: (tags) => void mutateDoc(doc.id, (d) => ({
				...d,
				tags
			}), true)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid grid-cols-2 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					onClick: onPages,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, {}), " Sắp xếp trang"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					onClick: onDraw,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, {}), " Tô sáng"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					onClick: onRedact,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, {}), " Che thông tin"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					onClick: onErase,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, {}), " Tẩy vết"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					onClick: onSharpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}), " Làm nét HD"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					onClick: onMoire,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monitor, {}), " Khử vân màn hình"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					onClick: () => {
						if (!s.pin) {
							toast("Đặt mã PIN trong mục Tôi trước");
							return;
						}
						if (!doc.locked && !getVaultKey()) {
							(async () => {
								const v = await pinDialog("Nhập mã PIN", "Để mã hoá tài liệu này trên máy.");
								if (!v) return;
								if (await hashPin(v) !== s.pin) {
									toast.error("Sai mã PIN");
									return;
								}
								const { unlockVault } = await import("./db-CclUQaLE.mjs").then((n) => n.r).then((n) => n.n);
								await unlockVault(v, getPinSalt());
								unlocked.add(doc.id);
								await mutateDoc(doc.id, (d) => ({
									...d,
									locked: true
								}), true);
								toast("Đã khóa và mã hoá tài liệu");
							})();
							return;
						}
						mutateDoc(doc.id, (d) => ({
							...d,
							locked: !doc.locked
						}), true);
						toast(doc.locked ? "Đã mở khóa" : "Đã khóa tài liệu");
					},
					children: [
						doc.locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockOpen, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {}),
						" ",
						doc.locked ? "Mở khóa" : "Khóa PIN"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "glass",
					className: "text-destructive",
					onClick: async () => {
						if (await confirmDialog("Chuyển vào thùng rác?", {
							message: "Có thể khôi phục lại trong thùng rác.",
							okText: "Xóa",
							danger: true
						})) {
							await deleteDocs([doc.id]);
							onDeleted();
						}
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Xóa"]
				})
			]
		})
	] });
}
function DrawPad({ page, highlight, onClose, onApply }) {
	/** R1.3: lớp vẽ đi qua Blob/object URL, không qua base64. */
	async function saveOverlay(c) {
		try {
			onApply(await canvasToTempUrl(c, "image/png"));
		} catch (e) {
			toast.error(userMessage(e, "Không lưu được nét vẽ"));
		}
	}
	const cv = (0, import_react.useRef)(null);
	const img = (0, import_react.useRef)(null);
	const [color, setColor] = (0, import_react.useState)(highlight ? "#FFD60A" : "#0A2540");
	const [mode, setMode] = (0, import_react.useState)(highlight ? "hl" : "pen");
	const last = (0, import_react.useRef)(null);
	function setup() {
		const c = cv.current, i = img.current;
		if (!c || !i) return;
		c.width = i.naturalWidth;
		c.height = i.naturalHeight;
	}
	function pt(e) {
		const c = cv.current;
		const r = c.getBoundingClientRect();
		return [(e.clientX - r.left) / r.width * c.width, (e.clientY - r.top) / r.height * c.height];
	}
	function draw(e) {
		if (!last.current) return;
		const c = cv.current;
		const ctx = c.getContext("2d");
		const p = pt(e);
		ctx.lineCap = "round";
		ctx.lineJoin = "round";
		ctx.strokeStyle = color;
		ctx.globalAlpha = mode === "hl" ? .35 : 1;
		ctx.globalCompositeOperation = mode === "hl" ? "darken" : "source-over";
		ctx.lineWidth = (mode === "hl" ? .03 : .006) * c.width;
		ctx.beginPath();
		ctx.moveTo(...last.current);
		ctx.lineTo(...p);
		ctx.stroke();
		last.current = p;
	}
	const colors = mode === "hl" ? [
		"#FFD60A",
		"#7CF5D7",
		"#FF8FA3"
	] : [
		"#0A2540",
		"#1D4ED8",
		"#C1121F"
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "scan-screen fixed inset-0 z-50 mx-auto flex max-w-[430px] flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-3 pt-[max(0.75rem,env(safe-area-inset-top))] pb-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: "scan-icon",
						onClick: onClose,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}), " Hủy"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm font-semibold",
						children: mode === "hl" ? "Tô sáng" : "Ký tên / ghi chú"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "scan-icon",
						onClick: () => {
							const c = cv.current;
							c?.getContext("2d")?.clearRect(0, 0, c.width, c.height);
						},
						children: "Xóa"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid flex-1 place-items-center p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						ref: img,
						src: page.src,
						alt: "Trang",
						onLoad: setup,
						className: "block max-h-[64dvh] max-w-full select-none",
						draggable: false
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
						ref: cv,
						className: "absolute inset-0 h-full w-full touch-none",
						onPointerDown: (e) => {
							e.target.setPointerCapture(e.pointerId);
							last.current = pt(e);
						},
						onPointerMove: draw,
						onPointerUp: () => last.current = null
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: mode === "pen" ? "default" : "glass",
						onClick: () => {
							setMode("pen");
							setColor("#0A2540");
						},
						children: "Bút"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: mode === "hl" ? "default" : "glass",
						onClick: () => {
							setMode("hl");
							setColor("#FFD60A");
						},
						children: "Tô sáng"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-1 justify-center gap-2",
						children: colors.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							"aria-label": `Màu ${c}`,
							onClick: () => setColor(c),
							style: { background: c },
							className: `size-7 rounded-full border-2 ${color === c ? "border-primary" : "border-card"}`
						}, c))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => cv.current && void saveOverlay(cv.current),
						children: "Lưu"
					})
				]
			})
		]
	});
}
//#endregion
export { DocView as component };
