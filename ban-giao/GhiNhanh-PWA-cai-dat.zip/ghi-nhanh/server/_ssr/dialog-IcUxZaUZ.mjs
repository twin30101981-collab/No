import { o as __toESM } from "../_runtime.mjs";
import { D as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dialog-IcUxZaUZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var current = null;
var listeners = /* @__PURE__ */ new Set();
function open(req) {
	return new Promise((resolve) => {
		current?.resolve(null);
		current = {
			...req,
			resolve: (v) => {
				current = null;
				listeners.forEach((l) => l());
				resolve(v);
			}
		};
		listeners.forEach((l) => l());
	});
}
/** Hộp thoại xác nhận riêng của app (thay window.confirm). */
var confirmDialog = (title, o = {}) => open({
	kind: "confirm",
	title,
	...o
}).then(Boolean);
/** Hộp thoại hai lựa chọn + Huỷ (BL-01: Gộp / Thay thế). Trả "ok" | "alt" | null khi huỷ. */
var choiceDialog = (title, o) => open({
	kind: "choice",
	title,
	...o
}).then((v) => v === "ok" || v === "alt" ? v : null);
/** Hộp thoại nhập chữ (thay window.prompt). Trả null khi huỷ. */
var promptDialog = (title, o = {}) => open({
	kind: "prompt",
	title,
	...o
}).then((v) => typeof v === "string" ? v.trim() || null : null);
/** Nhập mã PIN dạng số 4–6 chữ số. */
var pinDialog = (title, message) => open({
	kind: "pin",
	title,
	...message ? { message } : {}
}).then((v) => typeof v === "string" ? v : null);
function useDialogState() {
	const [, tick] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const l = () => tick((n) => n + 1);
		listeners.add(l);
		return () => {
			listeners.delete(l);
		};
	}, []);
	return current;
}
//#endregion
export { useDialogState as a, promptDialog as i, confirmDialog as n, pinDialog as r, choiceDialog as t };
