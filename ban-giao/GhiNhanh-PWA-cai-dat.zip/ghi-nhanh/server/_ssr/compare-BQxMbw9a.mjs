import { o as __toESM } from "../_runtime.mjs";
import { n as init_performance, r as performance_default } from "../_libs/canvg+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as aiExtract } from "./ai.functions-CpS7iAgj.mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { a as userMessage, i as showError } from "./errors-DKvrPJ4v.mjs";
import { B as Play, It as Download, X as LoaderCircle, b as Sparkles, ot as ImagePlus } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-CZvf2xHx.mjs";
import { i as useQueuedServerFn } from "./ai-queue-DZjZmUCT.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { A as loadImg, C as estimateSkew, J as tilt, T as glare, V as sharpness, j as normalize, l as compress, p as detectPaper } from "./image-DFWRNlNd.mjs";
import { c as download } from "./files-CTF11Arr.mjs";
import { n as pickFiles } from "./importer-BUHDogNt.mjs";
import { a as recognize } from "./ocr-CLa2avjZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/compare-BQxMbw9a.js
init_performance();
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Mục 3 — So sánh Ghi Nhanh với CamScanner.
* Đo cùng một bộ chỉ số trên hai ảnh của cùng một tờ biên bản rồi chấm thắng/thua theo từng tiêu chí.
*/
function stats(img) {
	const s = 400 / Math.max(img.naturalWidth, img.naturalHeight);
	const w = Math.max(8, Math.round(img.naturalWidth * s)), h = Math.max(8, Math.round(img.naturalHeight * s));
	const c = document.createElement("canvas");
	c.width = w;
	c.height = h;
	const ctx = c.getContext("2d", { willReadFrequently: true });
	ctx.drawImage(img, 0, 0, w, h);
	const d = ctx.getImageData(0, 0, w, h).data;
	const n = w * h;
	let sum = 0, sq = 0, dark = 0;
	const L = new Float32Array(n);
	for (let i = 0, p = 0; i < d.length; i += 4, p++) {
		const l = .299 * d[i] + .587 * d[i + 1] + .114 * d[i + 2];
		L[p] = l;
		sum += l;
		sq += l * l;
		if (l < 50) dark++;
	}
	const mean = sum / n;
	let ink = 0;
	for (let p = 0; p < n; p++) if (L[p] < mean - 40) ink++;
	return {
		c,
		mean,
		std: Math.sqrt(Math.max(0, sq / n - mean * mean)),
		darkShare: dark / n,
		inkShare: ink / n
	};
}
async function analyze(src) {
	const t0 = performance_default.now();
	const img = await loadImg(src);
	const W = img.naturalWidth, H = img.naturalHeight;
	const det = detectPaper(img, W, H);
	const st = stats(img);
	const skew = estimateSkew(st.c);
	st.c.width = 0;
	return {
		width: W,
		height: H,
		edgeFound: !!det,
		edgeScore: det ? +det.score.toFixed(2) : 0,
		perspective: det ? +tilt(det.quad).toFixed(3) : 0,
		skewDeg: +Math.abs(skew).toFixed(2),
		blur: Math.round(sharpness(img, W, H)),
		contrast: Math.round(st.std),
		brightness: Math.round(st.mean),
		glare: +glare(img, W, H).toFixed(4),
		darkShare: +st.darkShare.toFixed(3),
		inkShare: +st.inkShare.toFixed(3),
		analyzeMs: Math.round(performance_default.now() - t0)
	};
}
async function runOcr(src) {
	const t0 = performance_default.now();
	const text = await recognize(src) || "";
	return {
		ocrText: text,
		ocrChars: text.replace(/\s/g, "").length,
		ocrWords: text.split(/\s+/).filter((w) => w.length > 1).length,
		ocrMs: Math.round(performance_default.now() - t0)
	};
}
var cmp = (a, b, higherBetter, tol = .05) => {
	if (!isFinite(a) || !isFinite(b)) return "na";
	const m = Math.max(Math.abs(a), Math.abs(b), 1e-9);
	if (Math.abs(a - b) / m <= tol) return "tie";
	return a > b === higherBetter ? "gn" : "cs";
};
var pct = (v) => `${(v * 100).toFixed(1)}%`;
/** Bảng tiêu chí đúng thứ tự mục 3.2. */
function buildRows(g, c) {
	const lowLight = (m) => m.brightness * (1 - m.darkShare);
	const smallText = (m) => m.blur * Math.min(1, Math.min(m.width, m.height) / 1500);
	const rows = [
		{
			key: "edge",
			label: "Nhận diện mép giấy",
			target: "Ổn định",
			gn: g.edgeFound ? `Có (${g.edgeScore})` : "Không thấy",
			cs: c.edgeFound ? `Có (${c.edgeScore})` : "Không thấy / đã cắt sát",
			verdict: g.edgeFound === c.edgeFound ? "tie" : g.edgeFound ? "gn" : "cs"
		},
		{
			key: "persp",
			label: "Căn chỉnh phối cảnh",
			target: "Tự động",
			gn: g.perspective.toFixed(3),
			cs: c.perspective.toFixed(3),
			verdict: cmp(g.perspective, c.perspective, false, .15)
		},
		{
			key: "skew",
			label: "Độ nghiêng",
			target: "Tự động deskew",
			gn: `${g.skewDeg}°`,
			cs: `${c.skewDeg}°`,
			verdict: Math.abs(g.skewDeg - c.skewDeg) < .3 ? "tie" : g.skewDeg < c.skewDeg ? "gn" : "cs"
		},
		{
			key: "blur",
			label: "Độ nét",
			target: "Tối ưu OCR",
			gn: String(g.blur),
			cs: String(c.blur),
			verdict: cmp(g.blur, c.blur, true)
		},
		{
			key: "contrast",
			label: "Độ tương phản",
			target: "Tự động điều chỉnh",
			gn: String(g.contrast),
			cs: String(c.contrast),
			verdict: cmp(g.contrast, c.contrast, true)
		},
		{
			key: "glare",
			label: "Chói đèn",
			target: "Phát hiện/cảnh báo",
			gn: pct(g.glare),
			cs: pct(c.glare),
			verdict: Math.abs(g.glare - c.glare) < .002 ? "tie" : g.glare < c.glare ? "gn" : "cs"
		},
		{
			key: "lowlight",
			label: "Ánh sáng yếu",
			target: "Tăng khả năng đọc",
			gn: `${g.brightness} / tối ${pct(g.darkShare)}`,
			cs: `${c.brightness} / tối ${pct(c.darkShare)}`,
			verdict: cmp(lowLight(g), lowLight(c), true)
		},
		{
			key: "small",
			label: "Chữ nhỏ",
			target: "Ưu tiên OCR",
			gn: `${Math.round(smallText(g))}`,
			cs: `${Math.round(smallText(c))}`,
			verdict: cmp(smallText(g), smallText(c), true)
		},
		{
			key: "output",
			label: "Chất lượng ảnh đầu ra",
			target: "Không làm mất chữ",
			gn: `${g.width}×${g.height}, nét chữ ${pct(g.inkShare)}`,
			cs: `${c.width}×${c.height}, nét chữ ${pct(c.inkShare)}`,
			verdict: g.ocrChars != null && c.ocrChars != null ? cmp(g.ocrChars, c.ocrChars, true) : cmp(g.inkShare, c.inkShare, true)
		},
		{
			key: "speed",
			label: "Tốc độ xử lý",
			target: "Tối ưu",
			gn: `${g.analyzeMs + (g.ocrMs ?? 0)} ms`,
			cs: `${c.analyzeMs + (c.ocrMs ?? 0)} ms`,
			verdict: cmp(g.analyzeMs + (g.ocrMs ?? 0), c.analyzeMs + (c.ocrMs ?? 0), false, .1)
		}
	];
	const ai = (m) => m.aiError ? `Lỗi: ${m.aiError}` : m.aiFields != null ? `${m.aiFields} trường, tin cậy ${Math.round((m.aiConfidence ?? 0) * 100)}%, ${m.aiMs} ms` : "Chưa chạy";
	const aiScore = (m) => m.aiFields == null || m.aiError ? NaN : m.aiFields * (m.aiConfidence ?? 0);
	rows.push({
		key: "ai",
		label: "AI trích xuất",
		target: "Tăng độ chính xác",
		gn: ai(g),
		cs: ai(c),
		verdict: cmp(aiScore(g), aiScore(c), true)
	});
	return rows;
}
/** Độ trùng khớp chữ OCR giữa hai ảnh (Jaccard trên từ), giúp đối chiếu nội dung. */
function textAgreement(a = "", b = "") {
	const t = (s) => new Set(s.toLowerCase().normalize("NFC").split(/[^\p{L}\p{N}]+/u).filter((w) => w.length > 1));
	const A = t(a), B = t(b);
	if (!A.size && !B.size) return 0;
	let i = 0;
	A.forEach((w) => {
		if (B.has(w)) i++;
	});
	return i / (A.size + B.size - i);
}
function reportMarkdown(cond, rows, g, c) {
	const v = {
		gn: "Ghi Nhanh tốt hơn",
		cs: "CamScanner tốt hơn",
		tie: "Ngang nhau",
		na: "—"
	};
	return [
		`# Báo cáo so sánh Ghi Nhanh – CamScanner`,
		``,
		`- Thời gian: ${(/* @__PURE__ */ new Date()).toLocaleString("vi-VN")}`,
		`- Điều kiện chụp: ${cond || "(không ghi)"}`,
		`- Thiết bị: ${navigator.userAgent}`,
		`- Độ trùng khớp chữ OCR: ${pct(textAgreement(g.ocrText, c.ocrText))}`,
		``,
		`| Tiêu chí | Ghi Nhanh | CamScanner | Kết luận | Mục tiêu nâng cấp |`,
		`|---|---|---|---|---|`,
		...rows.map((r) => `| ${r.label} | ${r.gn} | ${r.cs} | ${v[r.verdict]} | ${r.target} |`),
		``,
		`Tổng: Ghi Nhanh thắng ${rows.filter((r) => r.verdict === "gn").length}, CamScanner thắng ${rows.filter((r) => r.verdict === "cs").length}, hoà ${rows.filter((r) => r.verdict === "tie").length}.`,
		``,
		`## Số liệu thô`,
		"```json",
		JSON.stringify({
			ghiNhanh: {
				...g,
				ocrText: void 0
			},
			camScanner: {
				...c,
				ocrText: void 0
			}
		}, null, 2),
		"```"
	].join("\n");
}
var CONDITIONS = [
	"Ánh sáng tốt",
	"Ánh sáng yếu",
	"Đèn chiếu trực tiếp",
	"Phản sáng/chói",
	"Giấy nghiêng",
	"Giấy cong",
	"Chữ nhỏ",
	"Chữ viết tay",
	"Ảnh hơi mờ",
	"Khoảng cách xa"
];
var VERDICT = {
	gn: {
		text: "Ghi Nhanh",
		cls: "bg-primary/15 text-primary"
	},
	cs: {
		text: "CamScanner",
		cls: "bg-destructive/15 text-destructive"
	},
	tie: {
		text: "Ngang",
		cls: "bg-muted text-muted-foreground"
	},
	na: {
		text: "—",
		cls: "bg-muted text-muted-foreground"
	}
};
function Compare() {
	const [gn, setGn] = (0, import_react.useState)();
	const [cs, setCs] = (0, import_react.useState)();
	const [mg, setMg] = (0, import_react.useState)();
	const [mc, setMc] = (0, import_react.useState)();
	const [cond, setCond] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)("");
	const extract = useQueuedServerFn(aiExtract, "Trích xuất AI");
	const pick = async (set) => {
		try {
			const [f] = await pickFiles("image/*", false);
			if (!f) return;
			set(await normalize(f, 2600, .92));
			setMg(void 0);
			setMc(void 0);
		} catch (e) {
			showError(e, "Không mở được ảnh");
		}
	};
	const measure = async () => {
		if (!gn || !cs) {
			toast.error("Hãy chọn đủ 2 ảnh của cùng một tờ biên bản.");
			return;
		}
		try {
			setBusy("Đang đo chất lượng ảnh…");
			const [a, b] = await Promise.all([analyze(gn), analyze(cs)]);
			setBusy("Đang đọc chữ (OCR) ảnh Ghi Nhanh…");
			const oa = await runOcr(gn).catch(() => ({}));
			setBusy("Đang đọc chữ (OCR) ảnh CamScanner…");
			const ob = await runOcr(cs).catch(() => ({}));
			setMg({
				...a,
				...oa
			});
			setMc({
				...b,
				...ob
			});
		} catch (e) {
			showError(e, "Không đo được ảnh");
		} finally {
			setBusy("");
		}
	};
	const ai = async () => {
		if (!gn || !cs || !mg || !mc) return;
		const one = async (src) => {
			const t0 = performance_default.now();
			try {
				const r = await extract({ data: { images: [await compress(src, 1600, .8)] } });
				if (!r.ok) return { aiError: r.message };
				return {
					aiFields: r.data.fields.filter((f) => f.value.trim()).length,
					aiConfidence: r.data.confidence,
					aiMs: Math.round(performance_default.now() - t0)
				};
			} catch (e) {
				return { aiError: userMessage(e, "Không gọi được AI") };
			}
		};
		setBusy("AI đang trích xuất ảnh Ghi Nhanh…");
		const a = await one(gn);
		if (a.aiError) {
			setMg({
				...mg,
				...a
			});
			setBusy("");
			toast.error(a.aiError);
			return;
		}
		setBusy("AI đang trích xuất ảnh CamScanner…");
		const b = await one(cs);
		setMg({
			...mg,
			...a
		});
		setMc({
			...mc,
			...b
		});
		setBusy("");
	};
	const rows = mg && mc ? buildRows(mg, mc) : [];
	const save = () => {
		if (!mg || !mc) return;
		download(new Blob([reportMarkdown(cond.join(", "), rows, mg, mc)], { type: "text/markdown" }), `so-sanh-camscanner-${Date.now()}.md`);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "So sánh với CamScanner",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 px-5 pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						"Chụp ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "cùng một tờ biên bản" }),
						", cùng vị trí và ánh sáng bằng Ghi Nhanh và CamScanner, rồi chọn hai ảnh dưới đây."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [[
						"Ghi Nhanh",
						gn,
						setGn
					], [
						"CamScanner",
						cs,
						setCs
					]].map(([label, src, set]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => pick(set),
						className: "flex aspect-[3/4] flex-col items-center justify-center gap-2 overflow-hidden rounded-2xl border border-dashed border-border bg-card text-sm",
						children: src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src,
							alt: `Ảnh ${label}`,
							className: "h-full w-full object-contain"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-6 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Ảnh ", label] })] })
					}, label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm font-medium",
					children: "Điều kiện chụp"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: CONDITIONS.map((c) => {
						const on = cond.includes(c);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setCond(on ? cond.filter((x) => x !== c) : [...cond, c]),
							className: `rounded-full border px-3 min-h-10 text-xs ${on ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card"}`,
							children: c
						}, c);
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: measure,
						disabled: !!busy || !gn || !cs,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}), " Đo & so sánh"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						onClick: ai,
						disabled: !!busy || !mg,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}), " So sánh AI"]
					})]
				}),
				busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-2 text-sm text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), busy]
				}),
				rows.length > 0 && mg && mc && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3 pb-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-hidden rounded-2xl border border-border bg-card",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "bg-muted text-left",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "p-2",
											children: "Tiêu chí"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "p-2",
											children: "Ghi Nhanh"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "p-2",
											children: "CamScanner"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "p-2",
											children: "Tốt hơn"
										})
									] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-border align-top",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "p-2 font-medium",
											children: [r.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-normal text-muted-foreground",
												children: r.target
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-2",
											children: r.gn
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-2",
											children: r.cs
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `rounded-full px-2 py-0.5 ${VERDICT[r.verdict].cls}`,
												children: VERDICT[r.verdict].text
											})
										})
									]
								}, r.key)) })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm",
							children: [
								"Ghi Nhanh thắng ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: rows.filter((r) => r.verdict === "gn").length }),
								" · CamScanner thắng ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: rows.filter((r) => r.verdict === "cs").length }),
								" · Hoà ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: rows.filter((r) => r.verdict === "tie").length }),
								" · Trùng khớp chữ ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [Math.round(textAgreement(mg.ocrText, mc.ocrText) * 100), "%"] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							className: "w-full",
							onClick: save,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), " Tải báo cáo so sánh"]
						})
					]
				})
			]
		})
	});
}
//#endregion
export { Compare as component };
