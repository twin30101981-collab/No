import { o as __toESM } from "../_runtime.mjs";
import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { D as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as whenScanIdle } from "./priority-gate-CeFvd7IG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ocr-queue-Dg31Dfup.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var ocr_queue_exports = /* @__PURE__ */ __exportAll({
	CancelledError: () => CancelledError,
	OcrQueue: () => OcrQueue,
	firstOcrFailure: () => firstOcrFailure,
	ocrLanes: () => ocrLanes,
	ocrQueue: () => ocrQueue,
	saveOcrText: () => saveOcrText,
	useOcrJobs: () => useOcrJobs
});
var CancelledError = class extends Error {
	constructor() {
		super("Đã hủy nhận chữ");
		this.name = "CancelledError";
	}
};
/** OCR queue (1..N parallel lanes) with cancel + progress. Runner is injected so the logic is testable without Tesseract. */
var OcrQueue = class {
	runner;
	onDone;
	concurrency;
	idle;
	jobs = [];
	listeners = /* @__PURE__ */ new Set();
	snap = [];
	waiters = /* @__PURE__ */ new Map();
	done = 0;
	constructor(runner, onDone, concurrency = 1, idle = whenScanIdle) {
		this.runner = runner;
		this.onDone = onDone;
		this.concurrency = concurrency;
		this.idle = idle;
	}
	emit() {
		this.snap = this.jobs.map((j) => ({ ...j }));
		this.listeners.forEach((l) => l());
	}
	subscribe = (l) => {
		this.listeners.add(l);
		return () => {
			this.listeners.delete(l);
		};
	};
	snapshot = () => this.snap;
	/** Queue pages; a page already queued is not added twice. Resolves per page with its text. */
	add(items) {
		const out = [];
		for (const it of items) {
			const dup = this.jobs.find((j) => j.docId === it.docId && j.pageId === it.pageId);
			const id = dup?.id ?? `${it.docId}:${it.pageId}:${Math.random().toString(36).slice(2, 7)}`;
			if (!dup) this.jobs.push({
				...it,
				id,
				status: "queued",
				progress: 0
			});
			out.push(new Promise((ok, fail) => {
				const prev = this.waiters.get(id);
				this.waiters.set(id, {
					ok: (t) => {
						prev?.ok(t);
						ok(t);
					},
					fail: (e) => {
						prev?.fail(e);
						fail(e);
					}
				});
			}));
		}
		this.emit();
		this.pump();
		return out;
	}
	/** S7: nhiều làn chạy song song; mỗi làn có runner (Worker Tesseract) riêng. */
	lanes = [];
	pump() {
		while (this.lanes.length < this.concurrency) this.lanes.push({
			r: null,
			job: null,
			abort: null
		});
		for (const lane of this.lanes) if (!lane.job) this.runLane(lane);
	}
	async runLane(lane) {
		for (let job = (await this.idle(), this.jobs.find((j) => j.status === "queued")); job; job = (await this.idle(), this.jobs.find((j) => j.status === "queued"))) {
			lane.job = job;
			job.status = "running";
			this.emit();
			const r = lane.r ??= this.runner();
			let text = null, err = null;
			const stop = new Promise((_, rej) => {
				lane.abort = () => rej(new CancelledError());
			});
			try {
				const src = job.latest ? await Promise.race([job.latest().catch(() => job.src), stop]) : job.src;
				text = await Promise.race([r.run(src, (p) => {
					job.progress = p;
					this.emit();
				}), stop]);
			} catch (e) {
				err = e;
			}
			lane.abort = null;
			lane.job = null;
			if (!this.jobs.includes(job)) continue;
			this.jobs = this.jobs.filter((j) => j !== job);
			const w = this.waiters.get(job.id);
			this.waiters.delete(job.id);
			if (err != null) w?.fail(err);
			else {
				this.done++;
				try {
					await this.onDone(job, text);
					w?.ok(text);
				} catch (e) {
					w?.fail(e);
				}
			}
			if (!this.jobs.length) this.done = 0;
			this.emit();
		}
	}
	/** Cancel matching jobs (all if no filter). A running job stops its worker. */
	async cancel(match = () => true) {
		const hit = this.jobs.filter(match);
		if (!hit.length) return;
		this.jobs = this.jobs.filter((j) => !hit.includes(j));
		for (const j of hit) {
			this.waiters.get(j.id)?.fail(new CancelledError());
			this.waiters.delete(j.id);
		}
		if (!this.jobs.length) this.done = 0;
		this.emit();
		const stopping = this.lanes.filter((l) => l.job && hit.includes(l.job));
		for (const l of stopping) {
			l.abort?.();
			const r = l.r;
			l.r = null;
			if (r) await r.abort();
		}
	}
};
var queue = null;
function ocrQueue() {
	return queue ??= new OcrQueue(tesseractRunner, saveOcrText, ocrLanes());
}
/** Ghi chữ nhận được vào trang. BL-05a: qua mutateDoc (bản mới nhất) — không đè ảnh/việc nền ghi cùng lúc. */
async function saveOcrText(job, text) {
	const { mutateDoc } = await import("./db-CclUQaLE.mjs").then((n) => n.r).then((n) => n.n);
	await mutateDoc(job.docId, (d) => d.pages.some((p) => p.id === job.pageId) ? {
		...d,
		pages: d.pages.map((p) => p.id === job.pageId ? {
			...p,
			text
		} : p)
	} : null);
}
/** HM-07: lỗi đầu tiên (không phải hủy) trong kết quả một đợt nhận chữ — kể cả khi TẤT CẢ trang đều lỗi. */
function firstOcrFailure(rs) {
	return rs.find((r) => r.status === "rejected" && !(r.reason instanceof CancelledError))?.reason;
}
/** S7: 2 làn khi máy có ≥4 nhân, ngược lại 1 (Tesseract tốn RAM ~100 MB/Worker). */
function ocrLanes(cores = typeof navigator !== "undefined" ? navigator.hardwareConcurrency || 2 : 2) {
	return cores >= 4 ? 2 : 1;
}
var laneNo = 0;
function tesseractRunner() {
	const n = laneNo++;
	const eng = async () => {
		const m = await import("./ocr-worker-DbwCMwXG.mjs").then((n) => n.t).then((n) => n.t);
		return n === 0 ? m.sharedOcr() : m.extraOcr();
	};
	let mine = null;
	return {
		async run(src, onProgress) {
			const { currentLang } = await import("./ocr-worker-DbwCMwXG.mjs").then((n) => n.t).then((n) => n.t);
			const r = await (await (mine ??= eng())).run(await currentLang(), src, { onProgress });
			return String(r.data.text).trim();
		},
		async abort() {
			if (mine) await (await mine).reset();
		}
	};
}
var EMPTY = [];
function useOcrJobs() {
	return (0, import_react.useSyncExternalStore)((l) => ocrQueue().subscribe(l), () => ocrQueue().snapshot(), () => EMPTY);
}
//#endregion
export { useOcrJobs as i, ocrQueue as n, ocr_queue_exports as r, firstOcrFailure as t };
