//#region node_modules/.nitro/vite/services/ssr/assets/tool-usage-C3cHF8xW.js
/**
* FX-02: màn Công cụ gọn — đếm số lần dùng từng công cụ (nhóm "Hay dùng") và tìm công cụ không dấu.
* Chỉ lưu tên công cụ + số lần trên máy (localStorage), không lưu tệp hay nội dung.
*/
var KEY = "ghi-nhanh:tool-uses";
function readUses() {
	try {
		const v = JSON.parse(localStorage.getItem(KEY) ?? "{}");
		return v && typeof v === "object" && !Array.isArray(v) ? v : {};
	} catch {
		return {};
	}
}
function recordUse(label) {
	try {
		const u = readUses();
		u[label] = (u[label] ?? 0) + 1;
		localStorage.setItem(KEY, JSON.stringify(u));
	} catch {}
}
/** Tối đa n công cụ đã dùng (≥ 1 lần), nhiều lần trước; bằng nhau giữ thứ tự trong `labels`. Chỉ trả nhãn còn tồn tại. */
function topUsed(labels, n = 4, uses = readUses()) {
	return labels.map((l, i) => ({
		l,
		i,
		c: uses[l] ?? 0
	})).filter((x) => x.c > 0).sort((a, b) => b.c - a.c || a.i - b.i).slice(0, n).map((x) => x.l);
}
/** Gấp chữ để tìm: thường, bỏ dấu tiếng Việt (đ → d), gộp khoảng trắng. */
function fold(s) {
	return s.normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/gi, "d").toLowerCase().replace(/\s+/g, " ").trim();
}
/** Khớp khi mọi từ của truy vấn có trong nhãn (không dấu, không phân biệt hoa thường). */
function matchTool(label, query) {
	const q = fold(query);
	if (!q) return true;
	const l = fold(label);
	return q.split(" ").every((w) => l.includes(w));
}
//#endregion
export { topUsed as i, readUses as n, recordUse as r, matchTool as t };
