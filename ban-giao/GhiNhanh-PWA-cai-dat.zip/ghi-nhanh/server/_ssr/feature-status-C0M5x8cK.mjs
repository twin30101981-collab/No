import { o as __toESM } from "../_runtime.mjs";
import { D as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/feature-status-C0M5x8cK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var mb = (n) => n >= 1e9 ? `${(n / 1e9).toFixed(1)} GB` : `${Math.round(n / 1e6)} MB`;
/** Hàm thuần: môi trường → bảng tình trạng (thứ tự cố định). */
function featureStatuses(e) {
	const rows = [];
	rows.push(e.online ? {
		id: "mang",
		label: "Mạng",
		state: "ok",
		detail: "Đang có mạng"
	} : {
		id: "mang",
		label: "Mạng",
		state: "off",
		detail: "Đang mất mạng — quét, cắt, xuất PDF vẫn dùng được; AI, đồng bộ, đăng nhập chờ có mạng"
	});
	rows.push(e.camera ? {
		id: "quet",
		label: "Quét & xuất PDF",
		state: "ok",
		detail: "Chạy trên máy, không cần mạng"
	} : {
		id: "quet",
		label: "Quét & xuất PDF",
		state: "warn",
		detail: "Không thấy camera — dùng Nhập ảnh; xuất PDF vẫn dùng được"
	});
	rows.push(e.ocrOffline ? {
		id: "ocr",
		label: "Nhận chữ (OCR)",
		state: "ok",
		detail: "Đã tải sẵn — dùng được cả khi mất mạng"
	} : e.online ? {
		id: "ocr",
		label: "Nhận chữ (OCR)",
		state: "warn",
		detail: "Lần đầu cần mạng để tải gói nhận chữ — bấm “Tải sẵn” ở mục Xuất & nhận chữ"
	} : {
		id: "ocr",
		label: "Nhận chữ (OCR)",
		state: "off",
		detail: "Chưa tải gói nhận chữ và đang mất mạng"
	});
	const ask = `Hỏi tài liệu còn ${e.askLeft}/${e.askLimit} lượt hôm nay`;
	rows.push(!e.online ? {
		id: "ai",
		label: "AI (trích xuất, dịch, tóm tắt…)",
		state: "off",
		detail: "Cần mạng — việc AI sẽ chờ tới khi có mạng"
	} : e.aiErrorRate != null && e.aiErrorRate > .5 ? {
		id: "ai",
		label: "AI (trích xuất, dịch, tóm tắt…)",
		state: "warn",
		detail: `Gần đây lỗi nhiều (${Math.round(e.aiErrorRate * 100)}%) — máy chủ AI có thể đang quá tải hoặc hết lượt · ${ask}`
	} : {
		id: "ai",
		label: "AI (trích xuất, dịch, tóm tắt…)",
		state: e.askLeft > 0 ? "ok" : "warn",
		detail: `Tối đa 60 lượt/giờ · ${ask}`
	});
	rows.push(!e.cloud ? {
		id: "dongbo",
		label: "Đăng nhập & đồng bộ",
		state: "off",
		detail: "Bản này chưa cấu hình máy chủ đám mây — tài liệu chỉ lưu trên máy"
	} : !e.signedIn ? {
		id: "dongbo",
		label: "Đăng nhập & đồng bộ",
		state: "warn",
		detail: "Chưa đăng nhập (không bắt buộc) — đăng nhập để đồng bộ và chia sẻ liên kết"
	} : {
		id: "dongbo",
		label: "Đăng nhập & đồng bộ",
		state: e.online ? "ok" : "warn",
		detail: e.online ? "Đã đăng nhập" : "Đã đăng nhập — đồng bộ chờ có mạng"
	});
	rows.push(e.drive ? {
		id: "drive",
		label: "Google Drive",
		state: e.online ? "ok" : "warn",
		detail: e.online ? "Đã cấu hình" : "Cần mạng"
	} : {
		id: "drive",
		label: "Google Drive",
		state: "off",
		detail: "Chưa cấu hình cho ứng dụng — nút Lưu vào Drive được ẩn"
	});
	rows.push(e.share ? {
		id: "chiase",
		label: "Chia sẻ sang ứng dụng khác",
		state: "ok",
		detail: "Có bảng chia sẻ của máy"
	} : {
		id: "chiase",
		label: "Chia sẻ sang ứng dụng khác",
		state: "warn",
		detail: "Trình duyệt không có bảng chia sẻ — tệp sẽ được lưu về máy"
	});
	if (!e.storage || !e.storage.quota) rows.push({
		id: "bonho",
		label: "Bộ nhớ máy",
		state: "warn",
		detail: "Trình duyệt không cho biết dung lượng"
	});
	else {
		const r = e.storage.usage / e.storage.quota;
		const d = `Đã dùng ${mb(e.storage.usage)} / ${mb(e.storage.quota)} (${Math.round(r * 100)}%)`;
		rows.push({
			id: "bonho",
			label: "Bộ nhớ máy",
			state: r >= .9 ? "off" : r >= .75 ? "warn" : "ok",
			detail: r >= .75 ? `${d} — xoá bớt hoặc sao lưu ra tệp` : d
		});
	}
	return rows;
}
var onlineNow = () => typeof navigator === "undefined" || navigator.onLine !== false;
function subscribeOnline(cb) {
	window.addEventListener("online", cb);
	window.addEventListener("offline", cb);
	return () => {
		window.removeEventListener("online", cb);
		window.removeEventListener("offline", cb);
	};
}
var useOnline = () => (0, import_react.useSyncExternalStore)(subscribeOnline, onlineNow, () => true);
/** Thu thập môi trường thật trên trình duyệt (phần không đồng bộ: dung lượng). */
async function gatherFeatureEnv(base) {
	let storage = null;
	try {
		const s = await navigator.storage?.estimate?.();
		if (s?.quota) storage = {
			usage: s.usage ?? 0,
			quota: s.quota
		};
	} catch {}
	return {
		...base,
		camera: !!navigator.mediaDevices?.getUserMedia,
		share: typeof navigator.share === "function",
		storage
	};
}
//#endregion
export { gatherFeatureEnv as n, useOnline as r, featureStatuses as t };
