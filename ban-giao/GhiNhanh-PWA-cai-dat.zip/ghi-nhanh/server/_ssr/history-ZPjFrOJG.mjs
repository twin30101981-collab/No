import { o as __toESM } from "../_runtime.mjs";
import { D as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { E as uid, h as openDb } from "./db-CclUQaLE.mjs";
import { i as zip, n as sheetsToXlsx } from "./xlsx-CvpeQh6I.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/history-ZPjFrOJG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/** Real .docx writer (no dependency): headings, paragraphs, lists, bordered tables, Vietnamese text. */
var block = (kind, text = "", extra = {}) => ({
	kind,
	level: 1,
	text,
	align: "left",
	bold: false,
	rows: [],
	...extra
});
var x = (s) => s.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
var run$1 = (t, bold = false, size) => `<w:r><w:rPr>${bold ? "<w:b/>" : ""}${size ? `<w:sz w:val="${size}"/>` : ""}</w:rPr><w:t xml:space="preserve">${x(t)}</w:t></w:r>`;
var jc = (a) => a === "justify" ? "both" : a;
function para(b) {
	if (b.kind === "heading") return `<w:p><w:pPr><w:pStyle w:val="Heading${Math.min(3, Math.max(1, b.level || 1))}"/><w:jc w:val="${jc(b.align)}"/></w:pPr>${run$1(b.text)}</w:p>`;
	if (b.kind === "bullet" || b.kind === "number") return `<w:p><w:pPr><w:pStyle w:val="ListParagraph"/><w:numPr><w:ilvl w:val="0"/><w:numId w:val="${b.kind === "bullet" ? 1 : 2}"/></w:numPr></w:pPr>${run$1(b.text, b.bold)}</w:p>`;
	return `<w:p><w:pPr><w:jc w:val="${jc(b.align)}"/></w:pPr>${b.text.split("\n").map((l, i) => (i ? "<w:r><w:br/></w:r>" : "") + run$1(l, b.bold)).join("")}</w:p>`;
}
var NUM = /^[-+]?\(?[$]?\d[\d.,]*\)?\s*(%|₫)?$/;
function table(rows, merges = [], red = []) {
	const n = Math.max(1, ...rows.map((r) => r.length)), w = Math.floor(9e3 / n), sz = n > 8 ? 18 : n > 5 ? 22 : void 0;
	const reds = new Set(red);
	const at = /* @__PURE__ */ new Map();
	for (const m of merges ?? []) for (let r = m.r; r < m.r + m.rs; r++) for (let c = m.c; c < m.c + m.cs; c++) at.set(`${r},${c}`, {
		m,
		top: r === m.r
	});
	const bd = [
		"top",
		"left",
		"bottom",
		"right",
		"insideH",
		"insideV"
	].map((s) => `<w:${s} w:val="single" w:sz="4" w:color="808080"/>`).join("");
	const cell = (ri, ci, t) => {
		const g = at.get(`${ri},${ci}`);
		if (g && ci !== g.m.c) return "";
		const span = g ? g.m.cs : 1, head = ri === 0;
		const vm = g && g.m.rs > 1 ? g.top ? "<w:vMerge w:val=\"restart\"/>" : "<w:vMerge/>" : "";
		const text = g && !g.top ? "" : t;
		const right = !head && NUM.test(text.trim()) && !g;
		const isRed = reds.has(`${ri},${ci}`);
		const r = `<w:r><w:rPr>${head ? "<w:b/>" : ""}${isRed ? "<w:color w:val=\"C00000\"/>" : ""}${sz ? `<w:sz w:val="${sz}"/>` : ""}</w:rPr><w:t xml:space="preserve">${x(text)}</w:t></w:r>`;
		return `<w:tc><w:tcPr><w:tcW w:w="${w * span}" w:type="dxa"/>${span > 1 ? `<w:gridSpan w:val="${span}"/>` : ""}${vm}${head ? "<w:shd w:val=\"clear\" w:fill=\"E8EEF0\"/>" : ""}</w:tcPr><w:p><w:pPr><w:spacing w:after="0"/>${right ? "<w:jc w:val=\"right\"/>" : g ? "<w:jc w:val=\"center\"/>" : ""}</w:pPr>${r}</w:p></w:tc>`;
	};
	return `<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/><w:tblBorders>${bd}</w:tblBorders></w:tblPr><w:tblGrid>${Array(n).fill(`<w:gridCol w:w="${w}"/>`).join("")}</w:tblGrid>${rows.map((r, ri) => `<w:tr>${Array.from({ length: n }, (_, ci) => cell(ri, ci, r[ci] ?? "")).join("")}</w:tr>`).join("")}</w:tbl><w:p/>`;
}
function blocksToDocx(blocks, title = "Ghi Nhanh") {
	const X = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>";
	const W = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"";
	const body = blocks.map((b) => b.kind === "table" ? b.rows.length ? table(b.rows, b.merges, b.red) : "" : b.text.trim() ? para(b) : "").join("") || "<w:p/>";
	const hs = [
		1,
		2,
		3
	].map((l) => `<w:style w:type="paragraph" w:styleId="Heading${l}"><w:name w:val="heading ${l}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="240" w:after="120"/><w:outlineLvl w:val="${l - 1}"/></w:pPr><w:rPr><w:b/><w:sz w:val="${[
		32,
		28,
		26
	][l - 1]}"/></w:rPr></w:style>`).join("");
	const lvl = (fmt, txt) => `<w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="${fmt}"/><w:lvlText w:val="${txt}"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="720" w:hanging="360"/></w:pPr></w:lvl>`;
	return zip([
		["[Content_Types].xml", `${X}<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>`],
		["_rels/.rels", `${X}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>`],
		["docProps/core.xml", `${X}<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>${x(title)}</dc:title><dc:creator>Ghi Nhanh</dc:creator></cp:coreProperties>`],
		["word/_rels/document.xml.rels", `${X}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/></Relationships>`],
		["word/styles.xml", `${X}<w:styles ${W}><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman" w:eastAsia="Times New Roman"/><w:sz w:val="26"/><w:lang w:val="vi-VN"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="300" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style>${hs}<w:style w:type="paragraph" w:styleId="ListParagraph"><w:name w:val="List Paragraph"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:after="60"/></w:pPr></w:style></w:styles>`],
		["word/numbering.xml", `${X}<w:numbering ${W}><w:abstractNum w:abstractNumId="0">${lvl("bullet", "•")}</w:abstractNum><w:abstractNum w:abstractNumId="1">${lvl("decimal", "%1.")}</w:abstractNum><w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num><w:num w:numId="2"><w:abstractNumId w:val="1"/></w:num></w:numbering>`],
		["word/document.xml", `${X}<w:document ${W}><w:body>${body}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1701" w:header="709" w:footer="709" w:gutter="0"/></w:sectPr></w:body></w:document>`]
	], "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
}
/** Fallback when AI is unavailable: guess structure from plain OCR text. */
function textToBlocks(text) {
	const out = [];
	let tbl = [];
	let para = [];
	const flushT = () => {
		if (tbl.length >= 2) out.push(block("table", "", { rows: tbl }));
		else tbl.forEach((r) => para.push(r.join(" ")));
		tbl = [];
	};
	const flushP = () => {
		if (para.length) out.push(block("paragraph", para.join(" "), { align: "justify" }));
		para = [];
	};
	for (const raw of text.split("\n")) {
		const l = raw.trim();
		if (!l) {
			flushT();
			flushP();
			continue;
		}
		const cells = l.split(/\t|\s{3,}|\s\|\s/).map((c) => c.trim()).filter(Boolean);
		if (cells.length >= 2) {
			flushP();
			tbl.push(cells);
			continue;
		}
		flushT();
		const letters = l.replace(/[^\p{L}]/gu, "");
		if (/^[-•*+·]\s+/.test(l)) {
			flushP();
			out.push(block("bullet", l.replace(/^[-•*+·]\s+/, "")));
		} else if (/^\d{1,2}[.)]\s+/.test(l)) {
			flushP();
			out.push(block("number", l.replace(/^\d{1,2}[.)]\s+/, "")));
		} else if (l.length <= 70 && letters.length >= 3 && letters === letters.toUpperCase()) {
			flushP();
			out.push(block("heading", l, {
				level: out.length ? 2 : 1,
				align: out.length ? "left" : "center"
			}));
		} else para.push(l);
	}
	flushT();
	flushP();
	return out;
}
/** Pre-export review: flag cells the reader was unsure about, strip markers, estimate output size. */
var MARK = "⟦?⟧";
/** True when AI marked the value, or it looks like a misread number (O/0, l/1, S/5 mixed with digits) or garbage. */
function isUnsure(s) {
	if (!s) return false;
	if (s.includes("⟦?⟧") || s.includes("�")) return true;
	if (/^\?+$/.test(s.trim())) return true;
	return s.split(/\s+/).some((t) => /\d/.test(t) && /^[\d.,OoIlS|]+$/.test(t) && /[OoIlS|]/.test(t) && t.replace(/[^\d]/g, "").length >= 2);
}
var clean = (s) => s.split(MARK).join("").replace(/\s{2,}/g, " ").trim();
var cleanBlocks = (bs) => bs.map((b) => ({
	...b,
	text: clean(b.text),
	rows: b.rows.map((r) => r.map(clean))
}));
var cleanSheets = (ss) => ss.map((s) => ({
	...s,
	rows: s.rows.map((r) => r.map(clean))
}));
var buildReview = (r) => r.kind === "word" ? blocksToDocx(cleanBlocks(r.blocks), r.title) : sheetsToXlsx(cleanSheets(r.sheets));
function countUnsure(r) {
	return (r.kind === "word" ? r.blocks.flatMap((b) => [b.text, ...b.rows.flat()]) : r.sheets.flatMap((s) => s.rows.flat())).filter(isUnsure).length;
}
var fmtSize = (n) => n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(0)} KB` : `${(n / 1048576).toFixed(1)} MB`;
var STORE = "conversions";
async function run(mode, fn) {
	const db = await openDb();
	return new Promise((resolve, reject) => {
		const t = db.transaction(STORE, mode);
		const req = fn(t.objectStore(STORE));
		t.oncomplete = () => resolve(req ? req.result : void 0);
		t.onerror = () => reject(t.error);
		t.onabort = () => reject(t.error);
	});
}
/** Tệp gốc tạo muộn (vd PDF từ trang tài liệu): chỉ chạy khi người dùng bấm Lưu. */
var lazySources = /* @__PURE__ */ new Map();
function registerSource(make) {
	const id = uid();
	lazySources.set(id, make);
	return id;
}
async function takeSource(id) {
	const make = id ? lazySources.get(id) : void 0;
	if (!make) return void 0;
	lazySources.delete(id);
	try {
		return await make();
	} catch (e) {
		console.error("history source", e);
		return;
	}
}
var pagesOf = (r) => r.kind === "excel" ? r.sheets.map((s) => s.rows) : r.blocks.filter((b) => b.kind === "table").map((b) => b.rows);
/** Ô chưa chắc: còn dấu/nhìn như đọc nhầm ở bản cuối, hoặc ban đầu bị đánh dấu mà người dùng chỉ bỏ dấu, không sửa giá trị. */
function unsureCells(before, after) {
	const a = pagesOf(before);
	return pagesOf(after).map((rows, index) => {
		const unsure = [];
		rows.forEach((r, row) => r.forEach((v, col) => {
			const orig = a[index]?.[row]?.[col] ?? "";
			if (isUnsure(v) || isUnsure(orig) && clean(v) === clean(orig)) unsure.push({
				row,
				col,
				value: clean(v)
			});
		}));
		return {
			index,
			ai: a[index]?.some((r) => r.some((v) => v.includes("⟦?⟧"))) ?? false,
			unsure
		};
	});
}
var conversionSize = (c) => (c.sourceBlob?.size ?? 0) + c.outputBlob.size + JSON.stringify(c.review ?? null).length * 2;
/** Chọn mục cần xoá: giữ mới nhất, tối đa MAX_ITEMS và MAX_BYTES. */
function pickPrune(items, size) {
	const sorted = [...items].sort((x, y) => y.at - x.at);
	let total = 0;
	return sorted.filter((c, i) => {
		total += size(c.id);
		return i >= 30 || i > 0 && total > 209715200;
	}).map((c) => c.id);
}
var listeners = /* @__PURE__ */ new Set();
var notify = () => listeners.forEach((l) => l());
async function listConversions() {
	return (await run("readonly", (s) => s.getAll())).sort((a, b) => b.at - a.at);
}
async function deleteConversions(ids) {
	if (!ids.length) return;
	await run("readwrite", (s) => {
		ids.forEach((id) => s.delete(id));
	});
	notify();
}
async function recordConversion(before, after, outputBlob, outputName) {
	const src = before.source ?? {};
	const prev = src.historyId ? (await listConversions()).find((c) => c.id === src.historyId) : void 0;
	const { source: _s, ...review } = after;
	const item = {
		id: uid(),
		at: Date.now(),
		kind: src.kind ?? prev?.kind ?? (after.kind === "word" ? "Word" : "Excel"),
		sourceName: src.name ?? prev?.sourceName ?? after.title,
		outputBlob,
		outputName,
		pages: unsureCells(before, after),
		warnings: after.note ? [after.note] : [],
		review
	};
	const details = src.details ?? prev?.details;
	if (details?.length) item.details = details;
	const blob = src.blob ?? await takeSource(src.lazy) ?? prev?.sourceBlob;
	if (blob) item.sourceBlob = blob;
	return store(item);
}
/** Tệp xuất thẳng không qua màn Xem lại (PDF, tệp nén hàng loạt): chỉ tải lại được, không sửa. */
async function recordFile(o) {
	const item = {
		id: uid(),
		at: Date.now(),
		kind: o.kind,
		sourceName: o.sourceName,
		outputBlob: o.outputBlob,
		outputName: o.outputName,
		pages: [],
		warnings: o.warnings ?? []
	};
	if (o.sourceBlob) item.sourceBlob = o.sourceBlob;
	if (o.details?.length) item.details = o.details;
	return store(item);
}
async function store(item) {
	await run("readwrite", (s) => {
		s.put(item);
	});
	const all = await listConversions();
	const sizes = new Map(all.map((c) => [c.id, conversionSize(c)]));
	await deleteConversions(pickPrune(all, (id) => sizes.get(id) ?? 0));
	notify();
	return item;
}
/** Sao lưu: không kèm tệp nguồn và tệp kết quả (tạo lại từ dữ liệu khi khôi phục). */
async function historyForBackup() {
	return (await listConversions()).map(({ sourceBlob: _a, outputBlob: _b, ...c }) => c);
}
async function restoreHistory(items) {
	if (!Array.isArray(items)) return;
	await run("readwrite", (s) => {
		for (const c of items) if (c?.id && c.review) s.put({
			...c,
			outputBlob: buildReview(c.review)
		});
	});
	notify();
}
function useConversions() {
	const [items, setItems] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const load = () => {
			listConversions().then(setItems).catch(() => setItems([]));
		};
		load();
		listeners.add(load);
		return () => {
			listeners.delete(load);
		};
	}, []);
	return items;
}
//#endregion
export { countUnsure as a, historyForBackup as c, recordFile as d, registerSource as f, useConversions as h, clean as i, isUnsure as l, textToBlocks as m, blocksToDocx as n, deleteConversions as o, restoreHistory as p, buildReview as r, fmtSize as s, block as t, recordConversion as u };
