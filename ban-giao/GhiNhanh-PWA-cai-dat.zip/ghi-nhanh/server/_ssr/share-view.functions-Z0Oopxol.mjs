import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as createSsrRpc } from "./createSsrRpc-CVjuB6nW.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CwccI41b.mjs";
import { i as stringType, r as objectType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/share-view.functions-Z0Oopxol.js
var openSharedDoc = createServerFn({ method: "POST" }).inputValidator((d) => objectType({
	token: stringType().regex(/^[A-Za-z0-9_-]{22}$/),
	password: stringType().max(64).default("")
}).parse(d)).handler(createSsrRpc("05e9df102c9c56f519deb2e800e7ee4661deb01d239d3f5fe9673f5658712971"));
var revokeShareLink = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ id: stringType().uuid() }).parse(d)).handler(createSsrRpc("9d73e134a8f620a8ab710665a2c56d119dc94d5559f194a2366313730f523e47"));
//#endregion
export { revokeShareLink as n, openSharedDoc as t };
