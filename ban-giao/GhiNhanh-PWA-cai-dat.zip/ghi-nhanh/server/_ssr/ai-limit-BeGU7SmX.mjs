//#region node_modules/.nitro/vite/services/ssr/assets/ai-limit-BeGU7SmX.js
/** HM-03 (Q1=b): giới hạn số lần gọi AI theo khách (IP) mỗi giờ, để khoá AI của chủ app không bị dùng quá mức.
*  Bộ đếm nằm trong bộ nhớ của từng máy chủ chạy app (không bền, không chia sẻ giữa các bản chạy song song) → chỉ là
*  lớp chặn lạm dụng cơ bản, không phải hạn mức chính xác. Thuần, không phụ thuộc máy chủ nên kiểm thử được. */
var AI_LIMIT_DEFAULT = 60;
var AI_LIMIT_WINDOW_MS = 36e5;
function createRateLimiter(o) {
	const now = o.now ?? Date.now, maxKeys = o.maxKeys ?? 5e3;
	const m = /* @__PURE__ */ new Map();
	return {
		hit(key) {
			if (o.limit <= 0) return { ok: true };
			const t = now();
			let e = m.get(key);
			if (!e || e.start + o.windowMs <= t) {
				e = {
					start: t,
					count: 0
				};
				m.delete(key);
				m.set(key, e);
				if (m.size > maxKeys) {
					for (const [k, v] of m) if (v.start + o.windowMs <= t) m.delete(k);
					while (m.size > maxKeys) m.delete(m.keys().next().value);
				}
			}
			if (e.count >= o.limit) return {
				ok: false,
				retryAfterSec: Math.max(1, Math.ceil((e.start + o.windowMs - t) / 1e3))
			};
			e.count++;
			return { ok: true };
		},
		size: () => m.size
	};
}
/** Định danh khách: IP do Cloudflare đặt (không giả được) → x-real-ip → x-forwarded-for. Không xác định được → null (không giới hạn). */
function clientKey(h) {
	if (!h) return null;
	return h.get("cf-connecting-ip") || h.get("x-real-ip") || h.get("x-forwarded-for")?.split(",")[0]?.trim() || null;
}
/** Biến môi trường AI_RATE_LIMIT_PER_HOUR: số lần/giờ; 0 = tắt; thiếu/sai → mặc định. */
function limitFromEnv(v) {
	if (v === void 0 || v.trim() === "") return 60;
	const n = Number(v);
	return Number.isInteger(n) && n >= 0 ? n : 60;
}
/** Cùng dạng {ok:false, code, message} mà giao diện đã xử lý cho mọi lỗi AI. Tiền tố "Hết lượt AI" để classifyAiFailure nhận ra. */
function limitedFail(retryAfterSec) {
	return {
		ok: false,
		code: 429,
		message: `Hết lượt AI trong giờ này. Hãy thử lại sau khoảng ${Math.max(1, Math.ceil(retryAfterSec / 60))} phút. Quét, cắt, xuất PDF vẫn dùng bình thường.`
	};
}
//#endregion
export { AI_LIMIT_DEFAULT, AI_LIMIT_WINDOW_MS, clientKey, createRateLimiter, limitFromEnv, limitedFail };
