import { l as compress } from "./image-DFWRNlNd.mjs";
import { a as recognize } from "./ocr-CLa2avjZ.mjs";
import { m as textToBlocks, n as blocksToDocx } from "./history-ZPjFrOJG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/word-DdGqJXaY.js
/** Page images → real .docx. AI reads layout (first 4 pages per call); falls back to OCR text structure. */
async function imagesToWord(srcs, name, layout, knownText) {
	const blocks = [];
	let title = name;
	let note = "";
	try {
		for (let i = 0; i < srcs.length; i += 4) {
			const r = await layout({ data: { images: await Promise.all(srcs.slice(i, i + 4).map((s) => compress(s, 1600, .8))) } });
			if (!r.ok) throw Object.assign(new Error(r.message), { aiMessage: r.message });
			if (i === 0 && r.data.title) title = r.data.title;
			blocks.push(...r.data.blocks);
		}
		if (!blocks.some((b) => b.text.trim() || b.rows.length)) throw new Error("empty");
	} catch (e) {
		blocks.length = 0;
		note = (e.aiMessage ?? "AI chưa đọc được bố cục.") + " Đã dùng cách đọc chữ thường.";
		let text = knownText?.trim() ?? "";
		if (!text) for (const s of srcs) text += await recognize(s) + "\n\n";
		blocks.push(...textToBlocks(text));
	}
	return {
		blob: blocksToDocx(blocks, title),
		title,
		blocks,
		note
	};
}
//#endregion
export { imagesToWord as t };
