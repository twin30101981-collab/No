import { n as init_performance, r as performance_default } from "../_libs/canvg+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/perf-stats-C5jrVSN8.js
init_performance();
var KEY = "ghi-nhanh:perf";
/** Đo một tác vụ bất đồng bộ và ghi vào perf-stats (kể cả khi lỗi). */
async function timed(k, fn) {
	const t0 = performance_default.now();
	try {
		return await fn();
	} finally {
		recordPerf(k, performance_default.now() - t0);
	}
}
var MAX = 600;
function recordPerf(k, ms) {
	try {
		const list = JSON.parse(localStorage.getItem(KEY) ?? "[]");
		list.unshift({
			k,
			ms: Math.round(ms),
			at: Date.now()
		});
		localStorage.setItem(KEY, JSON.stringify(list.slice(0, MAX)));
	} catch {}
}
function readPerf() {
	try {
		return JSON.parse(localStorage.getItem(KEY) ?? "[]");
	} catch {
		return [];
	}
}
function clearPerf() {
	try {
		localStorage.removeItem(KEY);
	} catch {}
}
function stat(values) {
	if (!values.length) return {
		count: 0,
		median: 0,
		p90: 0
	};
	const s = [...values].sort((a, b) => a - b);
	const at = (p) => s[Math.min(s.length - 1, Math.ceil(p * s.length) - 1)];
	return {
		count: s.length,
		median: at(.5),
		p90: at(.9)
	};
}
var NOT_ERRORS = /* @__PURE__ */ new Set(["AI_OK"]);
function buildReport(perf, log) {
	const of = (k) => stat(perf.filter((p) => p.k === k).map((p) => p.ms));
	const ai = log.filter((e) => e.aiStatus);
	const ok = ai.filter((e) => e.aiStatus === "ok").length, fail = ai.length - ok;
	const counts = /* @__PURE__ */ new Map();
	for (const e of log) if (!NOT_ERRORS.has(e.code)) counts.set(e.code, (counts.get(e.code) ?? 0) + 1);
	return {
		warpGpu: of("warp-gpu"),
		warpCpu: of("warp-cpu"),
		detect: of("detect"),
		ai: {
			...stat(ai.filter((e) => e.aiStatus === "ok" && e.ms).map((e) => e.ms)),
			ok,
			fail,
			errorRate: ai.length ? fail / ai.length : 0
		},
		topErrors: [...counts].map(([code, n]) => ({
			code,
			n
		})).sort((a, b) => b.n - a.n).slice(0, 3)
	};
}
/** B00 — Mốc đo nền V12: p50/p95 các mốc chính, xuất ra perf-baseline.json. */
var BASELINE_KINDS = [
	"grab",
	"release",
	"preview-shown",
	"normalize",
	"render"
];
function pct(values, p) {
	if (!values.length) return 0;
	const s = [...values].sort((a, b) => a - b);
	return s[Math.min(s.length - 1, Math.max(0, Math.ceil(p * s.length) - 1))];
}
function buildBaseline(perf, version = "V12", now = /* @__PURE__ */ new Date(), ua = typeof navigator !== "undefined" ? navigator.userAgent : "") {
	const stages = Object.fromEntries(BASELINE_KINDS.map((k) => {
		const v = perf.filter((p) => p.k === k).map((p) => p.ms);
		return [k, {
			count: v.length,
			p50: pct(v, .5),
			p95: pct(v, .95)
		}];
	}));
	return {
		version,
		createdAt: now.toISOString(),
		userAgent: ua,
		stages
	};
}
function downloadBaseline(perf = readPerf()) {
	const blob = new Blob([JSON.stringify(buildBaseline(perf), null, 2)], { type: "application/json" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = "perf-baseline.json";
	a.click();
	setTimeout(() => URL.revokeObjectURL(url), 1e3);
}
/** Ngưỡng cảnh báo: chậm hơn mốc 20% (p95 hiện tại > 1.2 × p95 mốc). */
var SLOW_RATIO = 1.2;
/**
* So số đo hiện tại với mốc baseline. Trả danh sách mốc chậm hơn 20%,
* sắp xếp theo mức chậm giảm dần. Mốc thiếu dữ liệu (mốc 0 hoặc ít mẫu) bị bỏ qua.
*/
function slowWarnings(perf, baseline, ratio = SLOW_RATIO) {
	const out = [];
	for (const k of BASELINE_KINDS) {
		const base = baseline.stages[k];
		if (!base || !base.p95) continue;
		const v = perf.filter((p) => p.k === k).map((p) => p.ms);
		if (v.length < 5) continue;
		const p95 = pct(v, .95);
		if (p95 > base.p95 * ratio) out.push({
			kind: k,
			p95,
			baseP95: base.p95,
			ratio: p95 / base.p95
		});
	}
	return out.sort((a, b) => b.ratio - a.ratio);
}
var BASELINE_KEY = "ghi-nhanh:perf-baseline";
function readBaseline() {
	try {
		const s = localStorage.getItem(BASELINE_KEY);
		return s ? JSON.parse(s) : null;
	} catch {
		return null;
	}
}
/** Câu cảnh báo tiếng Việt cho một mốc chậm. */
function slowWarningText(w) {
	return `${{
		grab: "lấy khung hình",
		release: "bấm chụp",
		"preview-shown": "hiện xem trước",
		normalize: "nắn trang",
		render: "dựng trang"
	}[w.kind]} chậm hơn mốc ${Math.round((w.ratio - 1) * 100)}% (p95 ${w.p95} ms / mốc ${w.baseP95} ms)`;
}
/** Ngân sách p90 (ms) theo công đoạn: bấm chụp trả nút ≤ 0,5 s; trang hiện trong khay ≤ 300 ms; ảnh xem trước đã cắt ≤ 800 ms;
*  dựng bản đầy đủ ≤ 1,2 s/trang; Xong → màn tài liệu ≤ 1 s. */
var BUDGET_171 = [
	{
		k: "release",
		label: "Bấm chụp → chụp tiếp được",
		ms: 500
	},
	{
		k: "preview-shown",
		label: "Trang hiện trong khay",
		ms: 300
	},
	{
		k: "render",
		label: "Ảnh xem trước đã cắt",
		ms: 800
	},
	{
		k: "finish",
		label: "Dựng bản đầy đủ (mỗi trang)",
		ms: 1200
	},
	{
		k: "done",
		label: "Xong → màn tài liệu",
		ms: 1e3
	}
];
/** Bảng ngân sách: p90 từng công đoạn so ngưỡng; ok = null khi chưa đủ SLOW_MIN_SAMPLES mẫu. */
function budgetReport(perf) {
	return BUDGET_171.map(({ k, label, ms }) => {
		const v = perf.filter((p) => p.k === k).map((p) => p.ms), p90 = pct(v, .9);
		return {
			k,
			label,
			budget: ms,
			count: v.length,
			p90,
			ok: v.length < 5 ? null : p90 <= ms
		};
	});
}
function overBudgetText(r) {
	return `${r.label}: chậm nhất ~${r.p90} ms, vượt ngân sách ${r.budget} ms (${r.count} lần đo)`;
}
//#endregion
export { overBudgetText as a, recordPerf as c, timed as d, downloadBaseline as i, slowWarningText as l, buildReport as n, readBaseline as o, clearPerf as r, readPerf as s, budgetReport as t, slowWarnings as u };
