import { o as __toESM } from "../_runtime.mjs";
import { D as require_react, E as require_jsx_runtime, d as DialogContent, f as DialogDescription, h as DialogTitle, l as Dialog, m as DialogPortal, p as DialogOverlay, u as DialogClose } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { Xt as Check, _t as FolderPlus, gt as Folder, qt as ChevronRight, r as X, z as Plus } from "../_libs/lucide-react.mjs";
import { D as useDocs } from "./db-CclUQaLE.mjs";
import { a as baseName, b as useLibrary, m as parentOf, r as allFolders, s as createFolder, u as ensureTag, y as tagColor } from "./library-BIMZUn1d.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { t as Input } from "./input-T4LKa1EA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/library-ui-BCoN_d8a.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Sheet = Dialog;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
var tagStyle = (c) => ({ "--tag-c": `var(--tag-${c % 6})` });
function TagChip({ name, onRemove, active, onClick }) {
	const lib = useLibrary();
	const cls = `inline-flex h-6 max-w-full shrink-0 items-center gap-1 rounded-md px-1.5 text-[0.625rem] font-bold ${active === false ? "bg-muted text-muted-foreground" : "tag-chip"} ${active ? "ring-1 ring-current" : ""}`;
	const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tag-dot size-1.5 shrink-0 rounded-full" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "truncate",
			children: name
		}),
		onRemove && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
			className: "size-3 shrink-0",
			onClick: (e) => {
				e.stopPropagation();
				onRemove();
			}
		})
	] });
	return onClick ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		style: tagStyle(tagColor(lib, name)),
		className: cls,
		children: inner
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		style: tagStyle(tagColor(lib, name)),
		className: cls,
		children: inner
	});
}
function BottomSheet({ open, onOpenChange, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			side: "bottom",
			className: "mx-auto max-h-[85dvh] max-w-[430px] overflow-y-auto rounded-t-[20px] pb-[max(1.5rem,env(safe-area-inset-bottom))]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
				className: "font-display text-left",
				children: title
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4",
				children
			})]
		})
	});
}
/** Folder tree picker with inline "new subfolder". */
function FolderPicker({ open, onOpenChange, value, onPick, title = "Chọn thư mục" }) {
	const lib = useLibrary();
	const { docs } = useDocs();
	const folders = allFolders(lib, docs);
	const [newIn, setNewIn] = (0, import_react.useState)(void 0);
	const [name, setName] = (0, import_react.useState)("");
	const depth = (f) => f.split("/").length - 1;
	function add() {
		const n = name.trim().replace(/\//g, "-");
		if (!n) return;
		const path = newIn ? `${newIn}/${n}` : n;
		createFolder(path);
		setNewIn(void 0);
		setName("");
		onPick(path);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BottomSheet, {
		open,
		onOpenChange,
		title,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col gap-1",
			children: folders.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1",
				style: { paddingLeft: depth(f) * 16 },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => onPick(f),
					className: `flex h-11 min-w-0 flex-1 items-center gap-2 rounded-[12px] px-3 text-left text-sm ${value === f ? "bg-secondary font-semibold text-primary" : "hover:bg-muted"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Folder, { className: "size-4 shrink-0" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: baseName(f)
						}),
						value === f && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "ml-auto size-4" })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": `Tạo thư mục con trong ${f}`,
					onClick: () => {
						setNewIn(f);
						setName("");
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderPlus, {})
				})]
			}, f))
		}), newIn !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-1 text-[0.6875rem] text-muted-foreground",
				children: ["Thư mục mới ", newIn ? `trong "${newIn}"` : "ở gốc"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					autoFocus: true,
					className: "h-11",
					value: name,
					onChange: (e) => setName(e.target.value),
					onKeyDown: (e) => e.key === "Enter" && add(),
					placeholder: "Tên thư mục"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "h-11",
					onClick: add,
					children: "Tạo"
				})]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "glass",
			className: "mt-3 w-full",
			onClick: () => {
				setNewIn(null);
				setName("");
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Thư mục mới ở gốc"]
		})]
	});
}
/** Toggle tags on/off, with creation of new tags. */
function TagPicker({ open, onOpenChange, value, onChange, title = "Gắn thẻ" }) {
	const lib = useLibrary();
	const [name, setName] = (0, import_react.useState)("");
	const toggle = (t) => onChange(value.includes(t) ? value.filter((x) => x !== t) : [...value, t]);
	function add() {
		const n = name.trim();
		if (!n) return;
		ensureTag(n);
		const real = lib.tags.find((t) => t.name.toLowerCase() === n.toLowerCase())?.name ?? n;
		if (!value.includes(real)) onChange([...value, real]);
		setName("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BottomSheet, {
		open,
		onOpenChange,
		title,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [lib.tags.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagChip, {
					name: t.name,
					active: value.includes(t.name),
					onClick: () => toggle(t.name)
				}, t.name)), !lib.tags.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Chưa có thẻ nào. Tạo thẻ đầu tiên bên dưới."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "h-11",
					value: name,
					onChange: (e) => setName(e.target.value),
					onKeyDown: (e) => e.key === "Enter" && add(),
					placeholder: "Tên thẻ mới"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					className: "h-11",
					onClick: add,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Thêm"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "glass",
				className: "mt-3 w-full",
				onClick: () => onOpenChange(false),
				children: "Xong"
			})
		]
	});
}
/** Combined filter editor: tags, kind, date range, OCR status. */
function FilterSheet({ open, onOpenChange, value, onChange, kinds, onSaveQuick }) {
	const lib = useLibrary();
	const [qname, setQname] = (0, import_react.useState)("");
	const set = (p) => onChange({
		...value,
		...p
	});
	const pill = (on) => `h-9 rounded-full px-3.5 text-xs font-semibold ${on ? "bg-primary text-primary-foreground" : "shortcut-tile"}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BottomSheet, {
		open,
		onOpenChange,
		title: "Bộ lọc",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-semibold",
				children: "Thẻ (phải có tất cả)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [lib.tags.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagChip, {
					name: t.name,
					active: value.tags.includes(t.name),
					onClick: () => set({ tags: value.tags.includes(t.name) ? value.tags.filter((x) => x !== t.name) : [...value.tags, t.name] })
				}, t.name)), !lib.tags.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Chưa có thẻ."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 mt-4 text-xs font-semibold",
				children: "Loại tài liệu"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: pill(!value.kind),
					onClick: () => set({ kind: null }),
					children: "Tất cả"
				}), kinds.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: pill(value.kind === k),
					onClick: () => set({ kind: k }),
					children: k
				}, k))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 mt-4 text-xs font-semibold",
				children: "Ngày tạo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-[0.6875rem] text-muted-foreground",
					children: ["Từ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						className: "mt-1 h-11",
						value: value.from,
						onChange: (e) => set({ from: e.target.value })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-[0.6875rem] text-muted-foreground",
					children: ["Đến", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						className: "mt-1 h-11",
						value: value.to,
						onChange: (e) => set({ to: e.target.value })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 mt-4 text-xs font-semibold",
				children: "Chữ nhận dạng"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: [
					["any", "Tất cả"],
					["yes", "Đã nhận chữ"],
					["no", "Chưa nhận chữ"]
				].map(([k, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: pill(value.ocr === k),
					onClick: () => set({ ocr: k }),
					children: l
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 mt-5 text-xs font-semibold",
				children: "Lưu thành Bộ lọc nhanh (hiện ở Trang chủ)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "h-11",
					value: qname,
					onChange: (e) => setQname(e.target.value),
					placeholder: "Ví dụ: Hoá đơn tháng này"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "h-11",
					disabled: !qname.trim(),
					onClick: () => {
						onSaveQuick(qname.trim());
						setQname("");
					},
					children: "Lưu"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "glass",
					onClick: () => onChange({
						...value,
						tags: [],
						kind: null,
						from: "",
						to: "",
						ocr: "any"
					}),
					children: "Xoá bộ lọc"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => onOpenChange(false),
					children: "Xem kết quả"
				})]
			})
		]
	});
}
function FolderCrumbs({ folder, onGo }) {
	const parts = [];
	let p = folder;
	while (p) {
		parts.unshift(p);
		p = parentOf(p);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 items-center gap-1 overflow-x-auto text-xs [scrollbar-width:none]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => onGo(null),
			className: `min-w-10 shrink-0 py-3 font-semibold ${folder ? "text-primary" : ""}`,
			children: "Tất cả"
		}), parts.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex shrink-0 items-center gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => onGo(f),
				className: `font-semibold ${i < parts.length - 1 ? "text-primary" : ""}`,
				children: baseName(f)
			})]
		}, f))]
	});
}
//#endregion
export { TagPicker as a, TagChip as i, FolderCrumbs as n, FolderPicker as r, FilterSheet as t };
