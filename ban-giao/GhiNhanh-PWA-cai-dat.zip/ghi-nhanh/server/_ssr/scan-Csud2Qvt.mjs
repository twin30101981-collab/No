import { S as createFileRoute, x as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scan-Csud2Qvt.js
var MODES = {
	doc: "Tài liệu",
	id: "Thẻ CCCD",
	book: "Sách",
	whiteboard: "Bảng trắng",
	passport: "Hộ chiếu",
	photo: "Ảnh",
	qr: "Mã QR"
};
var $$splitComponentImporter = () => import("./scan-CzvXPNXH.mjs");
var Route = createFileRoute("/scan")({
	validateSearch: (s) => ({
		mode: typeof s["mode"] === "string" && s["mode"] in MODES ? s["mode"] : void 0,
		doc: typeof s["doc"] === "string" ? s["doc"] : void 0
	}),
	head: () => ({ meta: [
		{ title: "Quét tài liệu — Ghi Nhanh" },
		{
			name: "description",
			content: "Máy quét tự nhận khung giấy, tự chụp, quét thẻ CCCD, sách, bảng trắng và mã QR."
		},
		{
			property: "og:title",
			content: "Quét tài liệu — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Máy quét tự nhận khung giấy, tự chụp, quét thẻ CCCD, sách, bảng trắng và mã QR."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as n, MODES as t };
