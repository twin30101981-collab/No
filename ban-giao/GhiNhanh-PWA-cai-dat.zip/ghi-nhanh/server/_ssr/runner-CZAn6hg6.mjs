import { r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { n as blobFor, t as adoptBlob } from "./disk-pack-ZdDKsocx.mjs";
import { n as getSettings } from "./settings-DDlMLZCe.mjs";
import { c as getDocs, d as mutateDoc, s as ensureDocsLoaded } from "./db-CclUQaLE.mjs";
import { d as timed } from "./perf-stats-C5jrVSN8.mjs";
import { L as renderPageUrl, q as targetLong } from "./image-DFWRNlNd.mjs";
import { t as finishLanes } from "./machine-lanes-xhX0UZ2n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/runner-CZAn6hg6.js
var runner_CZAn6hg6_exports = /* @__PURE__ */ __exportAll({
	a: () => runner_exports,
	i: () => pipelineEnabled,
	n: () => finishedStore,
	o: () => startPipeline,
	r: () => healPending,
	s: () => bgQueue,
	t: () => applyFinished
});
/** requestIdleCallback (hết hạn 1 s), dự phòng setTimeout 16 ms. */
var idleScheduler = (cb) => {
	const ric = globalThis.requestIdleCallback;
	if (typeof ric === "function") ric(cb, { timeout: 1e3 });
	else setTimeout(cb, 16);
};
var dbp = null;
function idb() {
	if (!dbp) dbp = new Promise((res, rej) => {
		const r = indexedDB.open("ghi-nhanh-jobs", 1);
		r.onupgradeneeded = () => {
			if (!r.result.objectStoreNames.contains("j")) r.result.createObjectStore("j", { keyPath: "id" });
		};
		r.onsuccess = () => res(r.result);
		r.onerror = () => rej(r.error);
	});
	return dbp;
}
async function run(mode, f) {
	const db = await idb();
	return new Promise((res, rej) => {
		const t = db.transaction("j", mode);
		const q = f(t.objectStore("j"));
		t.oncomplete = () => res(q.result);
		t.onerror = () => rej(t.error);
		t.onabort = () => rej(t.error);
	});
}
function jobToDisk(j) {
	const b = j.payload.orig.startsWith("blob:") ? blobFor(j.payload.orig) : void 0;
	return b ? {
		...j,
		payload: {
			...j.payload,
			orig: ""
		},
		origB: b
	} : j;
}
function jobFromDisk({ origB, ...j }) {
	return origB ? {
		...j,
		payload: {
			...j.payload,
			orig: adoptBlob(origB)
		}
	} : j;
}
var idbJobStore = {
	all: async () => (await run("readonly", (s) => s.getAll())).map(jobFromDisk),
	put: async (j) => {
		await run("readwrite", (s) => s.put(jobToDisk(j)));
	},
	del: async (id) => {
		await run("readwrite", (s) => s.delete(id));
	},
	clear: async () => {
		await run("readwrite", (s) => s.clear());
	}
};
var MAX_ATTEMPTS = 2;
var BgQueue = class {
	store;
	handlers;
	schedule;
	jobs = /* @__PURE__ */ new Map();
	order = [];
	/** Các lượt đang chạy — flush() phải CHỜ chúng, không gọi step() lặp (step() trả về ngay khi đã đủ làn). */
	active = /* @__PURE__ */ new Set();
	/** CS-09b: số việc chạy song song (mặc định 1). Phần nặng của việc dựng chạy trong bể Worker → 2 làn chồng được phần Worker của việc này lên phần luồng chính của việc kia. */
	lanes = 1;
	loaded = false;
	listeners = /* @__PURE__ */ new Set();
	giveUp = /* @__PURE__ */ new Set();
	/** BL-04: nghe việc bị BỎ sau khi hết lượt thử (vd. đánh dấu trang "loi"). */
	onGiveUp(fn) {
		this.giveUp.add(fn);
		return () => {
			this.giveUp.delete(fn);
		};
	}
	/** R4.2: đăng ký nghe thay đổi hàng đợi (để hiện nhãn tiến độ). */
	subscribe(fn) {
		this.listeners.add(fn);
		return () => {
			this.listeners.delete(fn);
		};
	}
	notify() {
		for (const fn of this.listeners) fn();
	}
	constructor(store = idbJobStore, handlers = {}, schedule = idleScheduler) {
		this.store = store;
		this.handlers = handlers;
		this.schedule = schedule;
	}
	get size() {
		return this.jobs.size;
	}
	has(pageId, kind) {
		for (const j of this.jobs.values()) if (j.pageId === pageId && (!kind || j.kind === kind)) return true;
		return false;
	}
	list() {
		return [...this.jobs.values()].map((j) => ({ ...j }));
	}
	setHandler(kind, h) {
		this.handlers[kind] = h;
	}
	/** CS-09b: đổi số làn (≥ 1); tăng làn thì chạy thêm ngay việc đang chờ. */
	setLanes(n) {
		this.lanes = Math.max(1, Math.floor(n) || 1);
		this.kick();
	}
	get laneCount() {
		return this.lanes;
	}
	/** Xếp việc mới cho trang; việc cùng trang + cùng loại trước đó bị thay. Ghi xuống kho trước khi chạy. */
	async enqueue(pageId, kind, payload) {
		await this.load();
		this.cancelPage(pageId, kind);
		const job = {
			id: Math.random().toString(36).slice(2, 10) + Date.now().toString(36),
			pageId,
			kind,
			state: "queued",
			payload,
			attempts: 0,
			createdAt: Date.now(),
			updatedAt: Date.now()
		};
		this.jobs.set(job.id, job);
		this.order.push(job.id);
		await this.store.put(job).catch(() => {});
		this.notify();
		this.kick();
		return { ...job };
	}
	/** Huỷ mọi việc của một trang (người dùng xoá trang); đang chạy thì bỏ kết quả. */
	cancelPage(pageId, kind) {
		for (const j of [...this.jobs.values()]) {
			if (j.pageId !== pageId || kind && j.kind !== kind) continue;
			this.jobs.delete(j.id);
			this.order = this.order.filter((x) => x !== j.id);
			this.store.del(j.id).catch(() => {});
		}
		this.notify();
	}
	/** CS-02: đưa việc của trang đang xem lên đầu hàng đợi (việc đang chạy giữ nguyên). Trả true nếu có việc được đưa lên. */
	prioritize(pageId, kind) {
		const ids = this.order.filter((id) => {
			const j = this.jobs.get(id);
			return j && j.pageId === pageId && (!kind || j.kind === kind);
		});
		if (!ids.length) return false;
		this.order = [...ids, ...this.order.filter((id) => !ids.includes(id))];
		return true;
	}
	cancelAll() {
		for (const j of [...this.jobs.values()]) this.cancelPage(j.pageId);
	}
	/** Đọc việc còn dở từ kho (sau khi tải lại): running → queued, error còn lượt → queued. */
	async resume() {
		await this.load();
		let n = 0;
		for (const j of this.jobs.values()) if (j.state === "running" || j.state === "error" && j.attempts < MAX_ATTEMPTS) {
			j.state = "queued";
			j.updatedAt = Date.now();
			this.order.push(j.id);
			n++;
			this.store.put(j).catch(() => {});
		} else if (j.state === "queued" && !this.order.includes(j.id)) {
			this.order.push(j.id);
			n++;
		}
		this.kick();
		return n;
	}
	/** Chạy ngay mọi việc còn lại (khi lưu tài liệu) và chờ xong. */
	async flush() {
		await this.load();
		while (this.order.length || this.active.size) if (this.order.length && this.active.size < this.lanes) await this.step();
		else await Promise.race(this.active);
	}
	async load() {
		if (this.loaded) return;
		this.loaded = true;
		const all = await this.store.all().catch(() => []);
		for (const j of all) if (j.state === "queued" || j.state === "running" || j.state === "error") this.jobs.set(j.id, j);
	}
	/** Số lượt đã hẹn (chưa bắt đầu) — không hẹn quá số làn trống. */
	pending = 0;
	kick() {
		while (this.active.size + this.pending < this.lanes && this.order.length > this.pending) {
			this.pending++;
			this.schedule(() => {
				this.pending--;
				this.step();
			});
		}
	}
	/** Bắt đầu MỘT việc nếu còn làn trống; trả lời hứa của việc đó (đủ làn → lời hứa của một việc đang chạy). */
	step() {
		if (this.active.size >= this.lanes) return Promise.race(this.active);
		const p = this.runOne();
		this.active.add(p);
		p.finally(() => {
			this.active.delete(p);
			this.kick();
		});
		return p;
	}
	async runOne() {
		const id = this.order.shift();
		const j = id ? this.jobs.get(id) : void 0;
		if (!j) {
			if (this.order.length) this.kick();
			return;
		}
		j.state = "running";
		j.attempts++;
		j.updatedAt = Date.now();
		this.store.put(j).catch(() => {});
		try {
			const h = this.handlers[j.kind];
			if (!h) throw new Error(`Chưa có bộ xử lý cho việc "${j.kind}"`);
			await h(j);
			if (this.jobs.get(j.id) === j) {
				this.jobs.delete(j.id);
				this.store.del(j.id).catch(() => {});
			}
		} catch (e) {
			if (this.jobs.get(j.id) === j) {
				j.state = "error";
				j.error = String(e?.message ?? e);
				j.updatedAt = Date.now();
				if (j.attempts < MAX_ATTEMPTS) {
					j.state = "queued";
					this.order.push(j.id);
					this.store.put(j).catch(() => {});
				} else {
					this.jobs.delete(j.id);
					this.store.del(j.id).catch(() => {});
					for (const fn of this.giveUp) try {
						fn({ ...j }, e);
					} catch {}
				}
			}
		} finally {
			this.notify();
		}
	}
};
/** Hàng đợi dùng chung toàn app. */
var bgQueue = new BgQueue();
var runner_exports = /* @__PURE__ */ __exportAll$1({
	applyFinished: () => applyFinished,
	finishHandler: () => finishHandler,
	finishedStore: () => finishedStore,
	healPending: () => healPending,
	markFailed: () => markFailed,
	pipelineEnabled: () => pipelineEnabled,
	sameEdit: () => sameEdit,
	startPipeline: () => startPipeline
});
var pipelineEnabled = () => getSettings().globalPipeline !== false;
var finished = /* @__PURE__ */ new Map();
var listeners = /* @__PURE__ */ new Set();
var finishedStore = {
	get: (id) => finished.get(id),
	delete: (id) => {
		finished.delete(id);
	},
	subscribe: (fn) => {
		listeners.add(fn);
		return () => {
			listeners.delete(fn);
		};
	},
	size: () => finished.size
};
var DEFAULT_EDIT = {
	rotation: 0,
	filter: "original",
	brightness: 0,
	contrast: 0
};
var canon = (v) => Array.isArray(v) ? v.map(canon) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).filter((k) => v[k] !== void 0).sort().map((k) => [k, canon(v[k])])) : v;
var sameEdit = (a, b) => JSON.stringify(canon(a ?? null)) === JSON.stringify(canon(b ?? null));
/** Ghi bản đầy đủ vào trang trong tài liệu đã lưu. Trả true nếu đã ghi. BL-05a: ghi qua mutateDoc (bản mới nhất, hàng ghi tuần tự)
*  → không đè thay đổi của nơi khác (xoá, đổi thư mục, OCR…) và hai trang cùng tài liệu không ghi đè nhau. */
async function applyFinished(pageId, src, edit) {
	await ensureDocsLoaded().catch(() => {});
	const doc = getDocs().find((d) => d.pages.some((p) => p.id === pageId));
	if (!doc) return false;
	let wrote = false;
	await mutateDoc(doc.id, (d) => {
		if (d.locked || d.enc || d.deletedAt) return null;
		const pg = d.pages.find((p) => p.id === pageId);
		if (!pg || !sameEdit(pg.edit, edit)) return null;
		wrote = true;
		return {
			...d,
			pages: d.pages.map((p) => p.id === pageId ? {
				...p,
				src,
				status: "xong"
			} : p)
		};
	});
	return wrote;
}
/** Bộ xử lý việc "finish": dựng bản đầy đủ; ghi vào tài liệu nếu trang đã lưu, không thì giữ cho màn Chụp nhận. */
async function finishHandler(j) {
	const full = j.payload.targetLong ?? targetLong(getSettings().quality === "normal" ? "normal" : "high");
	const src = await timed("finish", () => renderPageUrl(j.payload.orig, j.payload.edit ?? DEFAULT_EDIT, full));
	if (await applyFinished(j.pageId, src, j.payload.edit ?? DEFAULT_EDIT)) return;
	finished.set(j.pageId, src);
	listeners.forEach((l) => l(j.pageId, src));
}
/** CS-04 — bất biến "trang dang ⇒ có việc finish trong hàng đợi". Trang dang mà không có việc (kết quả bị một lần ghi tài liệu khác
*  đè mất — nhiều nơi cùng saveDoc, xem BL-05 — hoặc việc đã lỗi hết lượt) được xếp lại để dựng bản đầy đủ. Trả số việc đã xếp. */
async function healPending(docs = getDocs()) {
	const full = targetLong(getSettings().quality === "normal" ? "normal" : "high");
	let n = 0;
	const jobEdit = new Map(bgQueue.list().filter((j) => j.kind === "finish" && (j.state === "queued" || j.state === "running")).map((j) => [j.pageId, j.payload.edit]));
	for (const d of docs) {
		if (d.locked || d.enc || d.deletedAt) continue;
		for (const p of d.pages) {
			if (p.status !== "dang" || !p.orig) continue;
			if (jobEdit.has(p.id) && sameEdit(jobEdit.get(p.id), p.edit)) continue;
			await bgQueue.enqueue(p.id, "finish", {
				orig: p.orig,
				edit: p.edit,
				targetLong: full
			});
			n++;
		}
	}
	return n;
}
/** BL-04: dựng bản đầy đủ hỏng hết lượt → trang "loi" kèm lý do (thay vì "dang" mãi). healPending không tự thử lại trang "loi". */
async function markFailed(pageId, err) {
	const doc = getDocs().find((d) => d.pages.some((p) => p.id === pageId));
	if (!doc) return false;
	const error = `Chưa dựng được ảnh đầy đủ: ${(err instanceof Error ? err.message : err && typeof err === "object" && "type" in err ? "không đọc được ảnh gốc" : String(err)).slice(0, 160)}`;
	let wrote = false;
	await mutateDoc(doc.id, (d) => {
		if (d.locked || d.enc || d.deletedAt || d.pages.find((p) => p.id === pageId)?.status !== "dang") return null;
		wrote = true;
		return {
			...d,
			pages: d.pages.map((p) => p.id === pageId ? {
				...p,
				status: "loi",
				error
			} : p)
		};
	});
	return wrote;
}
var started = false;
/** Gọi một lần ở gốc app: đăng ký bộ xử lý và chạy tiếp việc còn dở sau khi tải lại. Trả true nếu vừa khởi động. */
function startPipeline() {
	if (started || typeof window === "undefined" || !pipelineEnabled()) return false;
	started = true;
	bgQueue.setHandler("finish", finishHandler);
	bgQueue.setLanes(finishLanes());
	bgQueue.onGiveUp((j, err) => {
		if (j.kind === "finish") markFailed(j.pageId, err);
	});
	bgQueue.resume().then(() => ensureDocsLoaded()).then(() => healPending()).catch(() => {});
	return true;
}
//#endregion
export { pipelineEnabled as a, healPending as i, bgQueue as n, runner_CZAn6hg6_exports as o, finishedStore as r, startPipeline as s, applyFinished as t };
