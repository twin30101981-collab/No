import { t as Anthropic } from "../_libs/@anthropic-ai/sdk+[...].mjs";
import { AI_TIMEOUT_MS } from "./ai-chain.server-D7XpPXa2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-claude.server-pfj-bkxq.js
var IMAGE_TYPES = [
	"image/jpeg",
	"image/png",
	"image/gif",
	"image/webp"
];
/** data:image/…;base64,… → khối ảnh base64 của Messages API. */
function imageBlock(dataUrl) {
	const m = /^data:(image\/[a-z+.-]+);base64,(.*)$/s.exec(dataUrl);
	if (!m) throw Object.assign(/* @__PURE__ */ new Error("ảnh không phải data URL base64"), { statusCode: 400 });
	return {
		type: "image",
		source: {
			type: "base64",
			media_type: IMAGE_TYPES.includes(m[1]) ? m[1] : "image/jpeg",
			data: m[2]
		}
	};
}
async function claudeGenerate(req) {
	const client = new Anthropic({
		apiKey: req.apiKey,
		timeout: AI_TIMEOUT_MS,
		maxRetries: 1
	});
	const content = req.parts.map((p) => p.type === "text" ? {
		type: "text",
		text: p.text
	} : imageBlock(p.dataUrl));
	const res = await client.beta.messages.create({
		model: req.model || "claude-opus-5-5",
		max_tokens: 16e3,
		system: req.system,
		betas: ["server-side-fallback-2026-07-01"],
		fallbacks: "default",
		output_config: {
			effort: "medium",
			...req.schema ? { format: {
				type: "json_schema",
				schema: req.schema
			} } : {}
		},
		messages: [{
			role: "user",
			content
		}]
	});
	if (res.stop_reason === "refusal") throw Object.assign(/* @__PURE__ */ new Error("Claude từ chối yêu cầu"), {
		statusCode: 451,
		refusal: true,
		category: res.stop_details?.category ?? null
	});
	if (res.stop_reason === "max_tokens") throw Object.assign(/* @__PURE__ */ new Error("Claude: vượt giới hạn độ dài trả lời"), { statusCode: 502 });
	const text = res.content.map((b) => b.type === "text" ? b.text : "").join("");
	if (!text.trim()) throw Object.assign(/* @__PURE__ */ new Error("Claude: trả lời rỗng"), { statusCode: 502 });
	return text;
}
//#endregion
export { claudeGenerate };
