import { o as __toESM } from "../_runtime.mjs";
import { T as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { D as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { a as userMessage } from "./errors-DKvrPJ4v.mjs";
import { C as saveDoc, c as getDocs, m as newPage, p as newDoc, u as loadDocs } from "./db-CclUQaLE.mjs";
import { j as normalize } from "./image-DFWRNlNd.mjs";
import { h as pdfToImages, r as canvasToPageUrl } from "./files-CTF11Arr.mjs";
import { n as confirmDialog } from "./dialog-IcUxZaUZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/importer-BUHDogNt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* G4-14 — Khử vân moiré khi chụp màn hình.
*
* Vân moiré chủ yếu là sọc màu lặp lại (lưới điểm ảnh màn hình × cảm biến máy ảnh).
* Cách làm: tách YCbCr, làm mờ mạnh kênh màu (Cb/Cr) bằng hộp mờ, làm mờ nhẹ độ sáng
* chỉ ở vùng phẳng (chênh lệch nhỏ) để giữ nét chữ. Pure, kiểm thử được.
*/
var moire_exports = /* @__PURE__ */ __exportAll({
	MOIRE_HINT: () => 4,
	moireScore: () => moireScore,
	moireScoreOfSource: () => moireScoreOfSource,
	removeMoire: () => removeMoire,
	removeMoireDataUrl: () => removeMoireDataUrl
});
function boxBlur(src, w, h, r) {
	const tmp = new Float32Array(w * h), out = new Float32Array(w * h);
	for (let y = 0; y < h; y++) {
		let s = 0;
		const row = y * w;
		for (let x = -r; x <= r; x++) s += src[row + Math.min(w - 1, Math.max(0, x))];
		for (let x = 0; x < w; x++) {
			tmp[row + x] = s / (2 * r + 1);
			s += src[row + Math.min(w - 1, x + r + 1)] - src[row + Math.max(0, x - r)];
		}
	}
	for (let x = 0; x < w; x++) {
		let s = 0;
		for (let y = -r; y <= r; y++) s += tmp[Math.min(h - 1, Math.max(0, y)) * w + x];
		for (let y = 0; y < h; y++) {
			out[y * w + x] = s / (2 * r + 1);
			s += tmp[Math.min(h - 1, y + r + 1) * w + x] - tmp[Math.max(0, y - r) * w + x];
		}
	}
	return out;
}
/** Độ mạnh vân màu: trung bình |Cb−128|+|Cr−128| lệch khỏi bản đã làm mờ (0 = không có). */
function moireScore(img) {
	const { Y, Cb, Cr } = split(img), n = img.width * img.height;
	const b = boxBlur(Cb, img.width, img.height, 4), r = boxBlur(Cr, img.width, img.height, 4);
	let s = 0;
	for (let p = 0; p < n; p++) s += Math.abs(Cb[p] - b[p]) + Math.abs(Cr[p] - r[p]);
	return s / n;
}
function split(img) {
	const n = img.width * img.height, s = img.data, Y = new Float32Array(n), Cb = new Float32Array(n), Cr = new Float32Array(n);
	for (let p = 0; p < n; p++) {
		const R = s[p * 4], G = s[p * 4 + 1], B = s[p * 4 + 2];
		Y[p] = .299 * R + .587 * G + .114 * B;
		Cb[p] = 128 - .168736 * R - .331264 * G + .5 * B;
		Cr[p] = 128 + .5 * R - .418688 * G - .081312 * B;
	}
	return {
		Y,
		Cb,
		Cr
	};
}
function removeMoire(img, o = {}) {
	const { width: w, height: h } = img, n = w * h;
	const cr = o.chromaRadius ?? Math.max(3, Math.round(Math.min(w, h) / 300)), lr = o.lumaRadius ?? 1, edge = o.edge ?? 24;
	const { Y, Cb, Cr } = split(img);
	const cb2 = boxBlur(Cb, w, h, cr), cr2 = boxBlur(Cr, w, h, cr), yb = boxBlur(Y, w, h, lr);
	const d = new Uint8ClampedArray(img.data);
	for (let p = 0; p < n; p++) {
		const diff = Math.abs(Y[p] - yb[p]);
		const t = diff >= edge ? 0 : 1 - diff / edge;
		const y = Y[p] * (1 - t) + yb[p] * t, u = cb2[p] - 128, v = cr2[p] - 128;
		d[p * 4] = y + 1.402 * v;
		d[p * 4 + 1] = y - .344136 * u - .714136 * v;
		d[p * 4 + 2] = y + 1.772 * u;
	}
	return {
		data: d,
		width: w,
		height: h
	};
}
/** Bản cho giao diện: ảnh URL → object URL JPEG đã khử vân (R1.4: không còn data URL). */
async function removeMoireDataUrl(src) {
	const img = await new Promise((res, rej) => {
		const i = new Image();
		i.onload = () => res(i);
		i.onerror = () => rej(/* @__PURE__ */ new Error("Không mở được ảnh"));
		i.src = src;
	});
	const c = document.createElement("canvas");
	c.width = img.naturalWidth;
	c.height = img.naturalHeight;
	const ctx = c.getContext("2d");
	ctx.drawImage(img, 0, 0);
	const id = ctx.getImageData(0, 0, c.width, c.height);
	const before = moireScore(id);
	const out = removeMoire(id);
	ctx.putImageData(new ImageData(out.data, out.width, out.height), 0, 0);
	return {
		src: await canvasToPageUrl(c, "image/jpeg", .92),
		before,
		after: moireScore(out)
	};
}
/** Độ vân của vùng giữa ảnh (không thu nhỏ: thu nhỏ làm mất vân); null khi không đọc được. */
async function moireScoreOfSource(src, size = 512) {
	if (typeof document === "undefined") return null;
	try {
		const bmp = await createImageBitmap(await (await fetch(src)).blob());
		const w = Math.min(size, bmp.width), h = Math.min(size, bmp.height);
		const c = document.createElement("canvas");
		c.width = w;
		c.height = h;
		const ctx = c.getContext("2d", { willReadFrequently: true });
		if (!ctx) {
			bmp.close();
			return null;
		}
		ctx.drawImage(bmp, bmp.width - w >> 1, bmp.height - h >> 1, w, h, 0, 0, w, h);
		bmp.close();
		return moireScore(ctx.getImageData(0, 0, w, h));
	} catch {
		return null;
	}
}
/** TD-37: ảnh chụp nhập từ thư viện không tự dò khung (R4.1) → gợi ý bấm "Tự dò góc" khi chưa cắt. */
function needsCornerHint(p) {
	return p.importKind === "photo" && !p.edit.quad && !p.manual;
}
var SAMPLE = 32;
var BLOCK = 8;
/** Giảm mẫu RGBA về lưới xám size×size (trung bình khối). */
function grayGrid(data, w, h, size) {
	const out = new Float64Array(size * size);
	for (let gy = 0; gy < size; gy++) {
		const y0 = Math.floor(gy * h / size), y1 = Math.max(y0 + 1, Math.floor((gy + 1) * h / size));
		for (let gx = 0; gx < size; gx++) {
			const x0 = Math.floor(gx * w / size), x1 = Math.max(x0 + 1, Math.floor((gx + 1) * w / size));
			let sum = 0, n = 0;
			for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
				const i = (y * w + x) * 4;
				sum += .299 * data[i] + .587 * data[i + 1] + .114 * data[i + 2];
				n++;
			}
			out[gy * size + gx] = sum / n;
		}
	}
	return out;
}
/** DCT-II 2 chiều trên lưới 32×32, trả khối tần số thấp 8×8. */
function dctLow(gray) {
	const out = /* @__PURE__ */ new Float64Array(64);
	for (let u = 0; u < BLOCK; u++) {
		const cu = u === 0 ? Math.SQRT1_2 : 1;
		for (let v = 0; v < BLOCK; v++) {
			const cv = v === 0 ? Math.SQRT1_2 : 1;
			let sum = 0;
			for (let y = 0; y < SAMPLE; y++) {
				const cy = Math.cos((2 * y + 1) * u * Math.PI / 64);
				for (let x = 0; x < SAMPLE; x++) sum += gray[y * SAMPLE + x] * cy * Math.cos((2 * x + 1) * v * Math.PI / 64);
			}
			out[u * BLOCK + v] = .25 * cu * cv * sum;
		}
	}
	return out;
}
/** Dấu vân ảnh 64 bit dưới dạng 16 ký tự hex. Thuần hàm, kiểm thử được. */
function phashFromRgba(data, width, height) {
	const low = dctLow(grayGrid(data, width, height, SAMPLE));
	const rest = Array.from(low.slice(1)).sort((a, b) => a - b);
	const median = rest[Math.floor(rest.length / 2)];
	let hi = 0n, lo = 0n;
	for (let i = 0; i < 64; i++) if (low[i] > median) if (i < 32) hi |= 1n << BigInt(31 - i);
	else lo |= 1n << BigInt(63 - i);
	return hi.toString(16).padStart(8, "0") + lo.toString(16).padStart(8, "0");
}
/** Khoảng cách Hamming giữa hai dấu vân hex 64 bit. */
function hammingHex(a, b) {
	let dist = 0;
	for (let i = 0; i < 16; i += 8) {
		let x = parseInt(a.slice(i, i + 8), 16) ^ parseInt(b.slice(i, i + 8), 16);
		while (x) {
			x &= x - 1;
			dist++;
		}
	}
	return dist;
}
/** Hai dấu vân có coi là trùng không (mặc định ≤ 6/64 bit khác). */
function isDuplicateHash(a, b, maxDist = 8) {
	return a.length === 16 && b.length === 16 && hammingHex(a, b) <= maxDist;
}
/** Tìm dấu vân trùng trong danh sách đã có; trả chỉ số phần tử trùng đầu tiên. */
function findDuplicate(hash, existing, maxDist = 6) {
	for (let i = 0; i < existing.length; i++) {
		const h = existing[i];
		if (h && isDuplicateHash(hash, h, maxDist)) return i;
	}
	return -1;
}
/**
* Phân loại ảnh nhập. Thuần hàm trên dữ liệu RGBA (nên giảm mẫu ≤ 256 px
* trước khi gọi để nhanh).
*/
function classifyImportImage(data, w, h) {
	const px = (x, y) => {
		const i = (y * w + x) * 4;
		return [
			data[i],
			data[i + 1],
			data[i + 2]
		];
	};
	const lum = (x, y) => {
		const [r, g, b] = px(x, y);
		return .299 * r + .587 * g + .114 * b;
	};
	const band = Math.max(2, Math.round(Math.min(w, h) * .03));
	let borderSum = 0, borderN = 0, borderSat = 0, borderDark = 0;
	const sampleBorder = (x, y) => {
		const [r, g, b] = px(x, y);
		const l = .299 * r + .587 * g + .114 * b;
		borderSum += l;
		borderN++;
		if (l < 120) borderDark++;
		const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
		if (mx > 0) borderSat += (mx - mn) / mx;
	};
	for (let y = 0; y < h; y += 2) for (let x = 0; x < w; x += 2) if (x < band || x >= w - band || y < band || y >= h - band) sampleBorder(x, y);
	const borderMean = borderSum / borderN;
	const borderDarkRatio = borderDark / borderN;
	const borderSatMean = borderSat / borderN;
	let satSum = 0, satN = 0;
	const colors = /* @__PURE__ */ new Set();
	let uniformRows = 0;
	for (let y = 0; y < h; y += 4) {
		let rowUniform = true;
		let prev = -1;
		for (let x = 0; x < w; x += 4) {
			const [r, g, b] = px(x, y);
			const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
			if (mx > 0) {
				satSum += (mx - mn) / mx;
				satN++;
			}
			const q = r >> 4 << 8 | g >> 4 << 4 | b >> 4;
			colors.add(q);
			if (prev >= 0 && Math.abs(q - prev) > 17) rowUniform = false;
			prev = q;
		}
		if (rowUniform) uniformRows++;
	}
	satN && satSum / satN;
	const sampled = Math.ceil(h / 4) * Math.ceil(w / 4);
	const colorRichness = colors.size / Math.max(1, sampled);
	const uniformRowRatio = uniformRows / Math.ceil(h / 4);
	let hardEdges = 0, edgeN = 0;
	for (let y = Math.floor(h * .2); y < h * .8; y += 3) for (let x = 1; x < w - 1; x += 3) {
		const d = Math.abs(lum(x + 1, y) - lum(x - 1, y));
		if (d > 4) {
			edgeN++;
			if (d > 90) hardEdges++;
		}
	}
	const hardEdgeRatio = edgeN ? hardEdges / edgeN : 0;
	if (borderMean > 150 && borderDarkRatio < .15 && borderSatMean < .25) return "flat";
	if (uniformRowRatio > .35 || colorRichness < .02 && hardEdgeRatio > .5) return "screenshot";
	return "photo";
}
var ANALYZE_SIZE = 96;
/** Giải mã nguồn ảnh (data URL / blob URL) về RGBA nhỏ để phân tích. SSR trả null. */
async function analyzeImageSource(src) {
	if (typeof document === "undefined") return null;
	try {
		const blob = await (await fetch(src)).blob();
		const bmp = await createImageBitmap(blob);
		const scale = Math.min(1, ANALYZE_SIZE / Math.max(bmp.width, bmp.height));
		const w = Math.max(8, Math.round(bmp.width * scale));
		const h = Math.max(8, Math.round(bmp.height * scale));
		const c = document.createElement("canvas");
		c.width = w;
		c.height = h;
		const ctx = c.getContext("2d", { willReadFrequently: true });
		if (!ctx) {
			bmp.close();
			return null;
		}
		ctx.drawImage(bmp, 0, 0, w, h);
		bmp.close();
		return {
			data: ctx.getImageData(0, 0, w, h).data,
			w,
			h
		};
	} catch {
		return null;
	}
}
/** Dấu vân + loại ảnh cho một nguồn ảnh; null khi không giải mã được. */
async function fingerprintImageSource(src) {
	const a = await analyzeImageSource(src);
	if (!a) return null;
	return {
		phash: phashFromRgba(a.data, a.w, a.h),
		kind: classifyImportImage(a.data, a.w, a.h)
	};
}
/** Shared browser-only image intake for picker, paste, share and scan. */
var IMAGE_ACCEPT = "image/*,.heic,.heif,image/heic,image/heif,.tif,.tiff,image/tiff";
var FILE_ACCEPT = `${IMAGE_ACCEPT},application/pdf`;
var HEIF_TYPES = /* @__PURE__ */ new Set([
	"image/heic",
	"image/heif",
	"image/heic-sequence",
	"image/heif-sequence"
]);
var HEIF_BRANDS = /* @__PURE__ */ new Set([
	"heic",
	"heix",
	"hevc",
	"hevx",
	"heim",
	"heis",
	"hevm",
	"hevs",
	"mif1",
	"msf1"
]);
function readBlob(blob) {
	if (typeof blob.arrayBuffer === "function") return blob.arrayBuffer();
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => reader.result instanceof ArrayBuffer ? resolve(reader.result) : reject(/* @__PURE__ */ new Error("Không đọc được ảnh"));
		reader.onerror = () => reject(reader.error ?? /* @__PURE__ */ new Error("Không đọc được ảnh"));
		reader.onabort = () => reject(/* @__PURE__ */ new Error("Đã huỷ đọc ảnh"));
		reader.readAsArrayBuffer(blob);
	});
}
function isImageFile(file) {
	return file.type.startsWith("image/") || /\.(heic|heif|jpe?g|png|webp|gif|bmp|avif|tiff?)$/i.test(file.name);
}
/** CS-11: TIFF theo kiểu MIME, đuôi tệp hoặc 4 byte đầu (ảnh từ máy quét/fax thường thiếu kiểu MIME). */
async function isTiffFile(file) {
	if (/^image\/tiff?$/i.test(file.type) || file instanceof File && /\.tiff?$/i.test(file.name)) return true;
	const b = new Uint8Array(await readBlob(file.slice(0, 4)));
	return b.length === 4 && (b[0] === 73 && b[1] === 73 && (b[2] === 42 || b[2] === 43) && b[3] === 0 || b[0] === 77 && b[1] === 77 && b[2] === 0 && (b[3] === 42 || b[3] === 43));
}
var tiffWorker = null;
var tiffSeq = 0;
var tiffIdle;
/** Giải TIFF trong Worker riêng (utif2 không vào bể Worker chung để bể nhẹ); Worker tắt sau 30 s rảnh. */
function decodeTiffInWorker(buf) {
	clearTimeout(tiffIdle);
	tiffWorker ??= new Worker(new URL("./tiff.worker.ts", import.meta.url), { type: "module" });
	const w = tiffWorker, id = ++tiffSeq;
	return new Promise((resolve, reject) => {
		const done = () => {
			w.removeEventListener("message", onMsg);
			w.removeEventListener("error", onErr);
			tiffIdle = setTimeout(() => {
				if (tiffWorker === w) {
					w.terminate();
					tiffWorker = null;
				}
			}, 3e4);
		};
		const onMsg = (e) => {
			if (e.data.id !== id) return;
			done();
			resolve(e.data);
		};
		const onErr = (e) => {
			done();
			if (tiffWorker === w) {
				w.terminate();
				tiffWorker = null;
			}
			reject(new Error(e.message || "worker"));
		};
		w.addEventListener("message", onMsg);
		w.addEventListener("error", onErr);
		w.postMessage({
			id,
			buf
		}, [buf]);
	});
}
async function rgbaToJpeg(width, height, rgba) {
	const c = document.createElement("canvas");
	c.width = width;
	c.height = height;
	const ctx = c.getContext("2d");
	if (!ctx) throw new Error("Không tạo được canvas");
	const bytes = rgba instanceof Uint8Array ? rgba : new Uint8Array(rgba);
	ctx.putImageData(new ImageData(new Uint8ClampedArray(bytes.buffer, bytes.byteOffset, bytes.byteLength), width, height), 0, 0);
	const blob = await new Promise((r) => c.toBlob(r, "image/jpeg", .95));
	c.width = c.height = 0;
	if (!blob) throw new Error("Không mã hoá được ảnh");
	return blob;
}
/** CS-11: mọi trang của tệp TIFF thành ảnh JPEG (giải trong Worker; không có Worker → giải ở luồng chính). */
async function tiffBlobs(file) {
	const name = file instanceof File ? ` “${file.name}”` : "";
	const buf = await readBlob(file);
	try {
		let pages;
		if (typeof Worker !== "undefined") {
			const r = await decodeTiffInWorker(buf);
			if (r.error || !r.pages) throw new Error(r.error ?? "TIFF");
			pages = r.pages;
		} else {
			const { decodeTiffPages } = await import("./tiff-decode-BuyiEdCy.mjs");
			pages = decodeTiffPages(buf).pages.map((p) => ({
				width: p.width,
				height: p.height,
				rgba: p.data
			}));
		}
		const out = [];
		for (const p of pages) out.push(p.blob ?? await rgbaToJpeg(p.width, p.height, p.rgba));
		return out;
	} catch {
		throw new Error(`Không đọc được ảnh TIFF${name}. Hãy xuất lại tệp thành PDF/JPG/PNG.`);
	}
}
/** CS-11: tách tệp TIFF nhiều trang thành từng ảnh JPEG; tệp khác giữ nguyên. Lỗi một tệp → onError (bỏ tệp đó) hoặc ném lỗi. */
async function expandImageFiles(files, onError) {
	const out = [];
	for (const f of files) {
		if (!await isTiffFile(f)) {
			out.push(f);
			continue;
		}
		try {
			const blobs = await tiffBlobs(f);
			const base = f.name.replace(/\.[^.]+$/, "") || "anh";
			blobs.forEach((b, i) => out.push(new File([b], blobs.length > 1 ? `${base}-trang-${i + 1}.jpg` : `${base}.jpg`, { type: "image/jpeg" })));
		} catch (error) {
			if (!onError) throw error;
			onError(f, error);
		}
	}
	return out;
}
async function isHeicFile(file) {
	if (HEIF_TYPES.has(file.type.toLowerCase()) || file instanceof File && /\.hei[cf]$/i.test(file.name)) return true;
	const bytes = new Uint8Array(await readBlob(file.slice(0, 256)));
	const text = (at) => String.fromCharCode(...bytes.slice(at, at + 4));
	if (bytes.length < 16 || text(4) !== "ftyp") return false;
	const brands = [text(8)];
	const size = new DataView(bytes.buffer).getUint32(0);
	for (let at = 16; at + 4 <= Math.min(size, bytes.length); at += 4) brands.push(text(at));
	return !brands.some((b) => b === "avif" || b === "avis") && brands.some((b) => HEIF_BRANDS.has(b));
}
var conversion = Promise.resolve();
async function imageBlob(file) {
	if (!await isHeicFile(file)) return file;
	const result = conversion.then(async () => {
		try {
			const { heicTo } = await import("../_libs/heic-to.mjs").then((n) => n.t);
			const blob = await heicTo({
				blob: file,
				type: "image/jpeg",
				quality: .95
			});
			if (!blob.size) throw new Error("Ảnh rỗng");
			return blob;
		} catch {
			throw new Error(`Không chuyển được ảnh HEIC${file instanceof File ? ` “${file.name}”` : ""}. Hãy chọn lại ảnh hoặc xuất ảnh thành JPG/PNG.`);
		}
	});
	conversion = result.then(() => void 0, () => void 0);
	return result;
}
function clipboardImages(data) {
	if (!data) return [];
	const files = Array.from(data.files ?? []).filter(isImageFile);
	if (files.length) return files;
	return Array.from(data.items ?? []).flatMap((item) => {
		if (item.kind !== "file") return [];
		const file = item.getAsFile();
		return file && isImageFile(file) ? [file] : [];
	});
}
function isEditingText(target) {
	return target instanceof Element && !!target.closest("input,textarea,[contenteditable]:not([contenteditable=\"false\"]),[role=\"textbox\"]");
}
async function readClipboardImages() {
	if (!navigator.clipboard?.read) throw new Error("Trình duyệt này không có nút dán ảnh. Hãy dùng lệnh Dán của máy hoặc chọn ảnh từ thư viện.");
	try {
		const files = [];
		for (const item of await navigator.clipboard.read()) {
			const type = item.types.find((t) => t.startsWith("image/"));
			if (!type) continue;
			const blob = await item.getType(type);
			const ext = type.split("/")[1]?.replace("jpeg", "jpg") ?? "png";
			files.push(new File([blob], `anh-dan-${files.length + 1}.${ext}`, { type }));
		}
		if (!files.length) throw new Error("Bộ nhớ tạm chưa có ảnh. Hãy sao chép ảnh trước khi dán.");
		return files;
	} catch (error) {
		if (error instanceof DOMException && (error.name === "NotAllowedError" || error.name === "SecurityError")) throw new Error("Chưa được phép đọc ảnh đã sao chép. Hãy cho phép quyền dán hoặc chọn ảnh từ thư viện.");
		throw error;
	}
}
var INK = 40;
function rows(d, w, h) {
	const out = [], lum = new Uint8Array(w), hist = /* @__PURE__ */ new Uint32Array(256);
	for (let y = 0; y < h; y++) {
		hist.fill(0);
		for (let x = 0; x < w; x++) {
			const p = (y * w + x) * 4;
			const l = d[p] * 77 + d[p + 1] * 150 + d[p + 2] * 29 >> 8;
			lum[x] = l;
			hist[l]++;
		}
		let bg = 0, best = -1;
		for (let l = 0; l < 256; l++) {
			let s = 0;
			for (let k = Math.max(0, l - 3); k <= Math.min(255, l + 3); k++) s += hist[k];
			if (s > best) {
				best = s;
				bg = l;
			}
		}
		const r = {
			ink: 0,
			left: 0,
			right: 0,
			center: 0,
			mid: 0,
			xmin: w,
			xmax: -1,
			lmax: -1,
			rmin: w,
			bg
		};
		for (let x = 0; x < w; x++) {
			if (Math.abs(lum[x] - bg) < INK) continue;
			r.ink++;
			if (x < r.xmin) r.xmin = x;
			r.xmax = x;
			const f = x / w;
			if (f < .4) r.left++;
			else if (f > .6) r.right++;
			if (f < .5) r.lmax = x;
			else if (r.rmin === w) r.rmin = x;
			if (f >= .45 && f <= .55) r.center++;
			if (f >= .4 && f <= .6) r.mid++;
		}
		out.push(r);
	}
	return out;
}
/** Nhóm hàng có nét liên tiếp (cho phép hở ≤ gap hàng) trong [from, to). */
function groups(rs, from, to, gap) {
	const g = [];
	let s = -1, e = -1;
	for (let y = from; y < to; y++) {
		if (!rs[y].ink) continue;
		if (s >= 0 && y - e - 1 <= gap) e = y;
		else {
			if (s >= 0) g.push([s, e]);
			s = e = y;
		}
	}
	if (s >= 0) g.push([s, e]);
	return g;
}
var sameBg = (a, b) => Math.abs(a.bg - b.bg) <= 6;
function topBar(rs, w, h, strict) {
	const lim = Math.round(h * .075), gap = Math.max(1, Math.round(h * .003));
	const gs = groups(rs, 0, lim, gap);
	if (!gs.length) return 0;
	const [s, e] = gs[0];
	const tall = e - s + 1;
	if (tall < h * .006 || tall > h * .035 || e >= lim - 1 || strict && s > h * .03) return 0;
	let left = 0, right = 0, xmin = w, lmax = -1, rmin = w, xmax = -1;
	for (let y = s; y <= e; y++) {
		const r = rs[y];
		if (r.center > 0 || r.mid > w * .04) return 0;
		left += r.left;
		right += r.right;
		if (r.ink) {
			xmin = Math.min(xmin, r.xmin);
			xmax = Math.max(xmax, r.xmax);
			lmax = Math.max(lmax, r.lmax);
			rmin = Math.min(rmin, r.rmin);
		}
	}
	if (!left || !right) return 0;
	if (xmin > w * .2 || lmax > w * .42 || rmin < w * .62 || xmax < w * .8) return 0;
	for (let y = 0; y < s; y++) if (!sameBg(rs[y], rs[s])) return 0;
	const want = Math.min(lim, e + 1 + Math.max(s, gap));
	let cut = e + 1;
	while (cut < want && !rs[cut].ink && sameBg(rs[cut], rs[0])) cut++;
	if (cut - e - 1 < 2) return 0;
	return cut / h;
}
function bottomBar(rs, w, h, strict) {
	const from = h - Math.round(h * .07), gap = Math.max(1, Math.round(h * .003));
	const gs = groups(rs, from, h, gap);
	if (!gs.length) return 0;
	const [s, e] = gs[gs.length - 1];
	const tall = e - s + 1;
	if (tall > h * .03 || s <= from) return 0;
	for (let y = e + 1; y < h; y++) if (rs[y].ink) return 0;
	let xmin = w, xmax = -1, l = 0, m = 0, r = 0, full = 0;
	for (let y = s; y <= e; y++) {
		const row = rs[y];
		if (!row.ink) continue;
		xmin = Math.min(xmin, row.xmin);
		xmax = Math.max(xmax, row.xmax);
		l += row.left;
		m += row.mid;
		r += row.right;
		full = Math.max(full, row.ink);
	}
	const pill = xmin >= w * .25 && xmax <= w * .75 && xmax - xmin >= w * .15 && tall <= h * .01 && m > 0 && full >= (xmax - xmin + 1) * .8;
	const buttons = !strict && xmin >= w * .08 && xmax <= w * .92 && l > 0 && m > 0 && r > 0 && tall >= h * .008;
	if (!pill && !buttons) return 0;
	const need = Math.max(2, Math.round(h * .004));
	let y = s - 1, blank = 0;
	while (y >= from - need && !rs[y].ink && sameBg(rs[y], rs[s - 1])) {
		blank++;
		y--;
	}
	if (blank < need) return 0;
	return (h - Math.max(y + 1, s - Math.max(h - 1 - e, gap))) / h;
}
/** Thanh hệ thống cần bỏ trên ảnh chụp màn hình dọc (rộng w, cao h, RGBA).
*  strict (ảnh loại "flat" — có thể là trang quét): nét trên phải bắt đầu trong 3 % đầu, đáy chỉ nhận vạch home. */
function detectSystemBars(d, w, h, strict = false) {
	if (h < w * 1.3 || w < 100) return {
		top: 0,
		bottom: 0
	};
	const rs = rows(d, w, h);
	return {
		top: topBar(rs, w, h, strict),
		bottom: bottomBar(rs, w, h, strict)
	};
}
/** Khung cắt (toạ độ 0..1) bỏ thanh hệ thống; null khi không có gì để bỏ. */
function barsQuad(b) {
	if (b.top <= 0 && b.bottom <= 0) return null;
	const t = +b.top.toFixed(4), u = +(1 - b.bottom).toFixed(4);
	return [
		[0, t],
		[1, t],
		[1, u],
		[0, u]
	];
}
/** Bản cho trình duyệt: nguồn ảnh → khung cắt bỏ thanh hệ thống (dò trên bản rộng 360) + ảnh trang đã cắt; null khi không có/không đọc được. */
async function cropSystemBars(src, strict = false) {
	if (typeof document === "undefined") return null;
	try {
		const bmp = await createImageBitmap(await (await fetch(src)).blob());
		const w = 360, h = Math.max(1, Math.round(bmp.height * w / bmp.width));
		const c = document.createElement("canvas");
		c.width = w;
		c.height = h;
		const ctx = c.getContext("2d", { willReadFrequently: true });
		if (!ctx) {
			bmp.close();
			return null;
		}
		ctx.drawImage(bmp, 0, 0, w, h);
		const quad = barsQuad(detectSystemBars(ctx.getImageData(0, 0, w, h).data, w, h, strict));
		if (!quad) {
			bmp.close();
			return null;
		}
		const y0 = Math.round(quad[0][1] * bmp.height), y1 = Math.round(quad[2][1] * bmp.height);
		const out = document.createElement("canvas");
		out.width = bmp.width;
		out.height = Math.max(1, y1 - y0);
		out.getContext("2d").drawImage(bmp, 0, y0, bmp.width, out.height, 0, 0, bmp.width, out.height);
		bmp.close();
		const { canvasToPageUrl } = await import("./files-CTF11Arr.mjs").then((n) => n.l).then((n) => n.S);
		return {
			quad,
			src: await canvasToPageUrl(out, "image/jpeg", .92)
		};
	} catch {
		return null;
	}
}
/** Open a native file picker and resolve the chosen files. */
function pickFiles(accept, multiple = true, capture) {
	return new Promise((resolve) => {
		const input = document.createElement("input");
		input.type = "file";
		input.accept = accept.includes("image/*") ? `${accept},.heic,.heif,image/heic,image/heif,.tif,.tiff,image/tiff` : accept;
		input.multiple = multiple;
		if (capture) input.setAttribute("capture", capture);
		input.onchange = () => resolve(Array.from(input.files ?? []));
		input.oncancel = () => resolve([]);
		input.click();
	});
}
/** R4.1: dấu vân của mọi trang đã lưu (để chống nhập trùng). */
async function existingHashes() {
	try {
		await loadDocs();
		return getDocs().flatMap((d) => d.pages.map((p) => p.phash).filter((h) => !!h));
	} catch {
		return [];
	}
}
/** Khung cắt trùng toàn bộ ảnh — dùng cho ảnh nhập đã phẳng, không cắt lại. */
var FULL_QUAD = [
	[0, 0],
	[1, 0],
	[1, 1],
	[0, 1]
];
/** `stats.skipped` đếm ảnh trùng mà người dùng chọn không thêm (để báo đúng, không báo "tệp không hợp lệ"). */
async function filesToPages(files, stats) {
	const pages = [];
	const hashes = await existingHashes();
	let dupes = 0;
	const moire = [];
	for (const f0 of files) {
		const known = hashes.length;
		for (const f of await expandImageFiles([f0])) if (f.type === "application/pdf" || /\.pdf$/i.test(f.name)) for (const src of await pdfToImages(f)) pages.push(newPage(src));
		else if (isImageFile(f)) {
			const src = await normalize(await imageBlob(f));
			const page = newPage(src);
			const fp = await fingerprintImageSource(src);
			if (fp) {
				page.phash = fp.phash;
				page.importKind = fp.kind;
				if (fp.kind !== "photo") page.edit.quad = FULL_QUAD;
				if (fp.kind !== "photo") {
					const bars = await cropSystemBars(src, fp.kind === "flat");
					if (bars) {
						page.src = bars.src;
						page.edit = {
							...page.edit,
							quad: bars.quad,
							paper: "free",
							flatten: false
						};
					}
				} else if (fp.kind === "photo" && (await moireScoreOfSource(src) ?? 0) >= 4) moire.push(f.name);
				if (findDuplicate(fp.phash, f === f0 ? hashes : hashes.slice(0, known)) >= 0) {
					dupes++;
					if (!await confirmDialog(`Ảnh “${f.name}” hình như đã nhập trước đây`, {
						message: "Vẫn thêm lại?",
						okText: "Vẫn thêm"
					})) {
						if (stats) stats.skipped++;
						continue;
					}
				}
				hashes.push(fp.phash);
			}
			pages.push(page);
		}
	}
	if (dupes && !stats?.skipped) toast.info(`Phát hiện ${dupes} ảnh trùng với tài liệu đã có`);
	if (moire.length) toast.info(`Ảnh có vân màn hình: ${moire.length > 1 ? `${moire.length} ảnh` : `“${moire[0]}”`}`, {
		description: "Mở menu Tài liệu → Khử vân màn hình để làm mịn",
		duration: 8e3
	});
	return pages;
}
/** Import images/PDFs as a new document and open it. */
function useImport() {
	const navigate = useNavigate();
	return (0, import_react.useCallback)(async (accept = FILE_ACCEPT, kind = "Nhập", tool) => {
		const files = typeof accept === "string" ? await pickFiles(accept === "image/*" ? IMAGE_ACCEPT : accept) : accept;
		if (!files.length) return;
		const id = toast.loading("Đang nhập…");
		try {
			const stats = { skipped: 0 };
			const raw = await filesToPages(files, stats);
			if (!raw.length) {
				if (stats.skipped) toast.info("Đã bỏ qua ảnh trùng, không nhập gì", { id });
				else toast.error("Không có ảnh hoặc PDF hợp lệ", { id });
				return;
			}
			const { processImported } = await import("./import-pipeline-B6K4tiBD.mjs");
			const pages = await processImported(raw, (d, t) => toast.loading(`Đang dò khung ${d}/${t} ảnh…`, { id }));
			const name = files.length === 1 ? files[0].name.replace(/\.[^.]+$/, "") : void 0;
			const doc = await saveDoc(newDoc(pages, name, kind));
			import("./post-capture-metrics-X7ExzflM.mjs").then((m) => m.postCaptureWithMetrics(doc, /* @__PURE__ */ new Set(), true, { heal: true }));
			toast.success(`Đã nhập ${pages.length} trang`, { id });
			navigate({
				to: "/doc/$id",
				params: { id: doc.id },
				search: tool ? { tool } : {}
			});
		} catch (error) {
			toast.error(userMessage(error, "Không đọc được tập tin này"), { id });
		}
	}, [navigate]);
}
//#endregion
export { IMAGE_ACCEPT as a, imageBlob as c, readClipboardImages as d, needsCornerHint as f, FILE_ACCEPT as i, isEditingText as l, pickFiles as n, clipboardImages as o, moire_exports as p, useImport as r, expandImageFiles as s, filesToPages as t, isImageFile as u };
