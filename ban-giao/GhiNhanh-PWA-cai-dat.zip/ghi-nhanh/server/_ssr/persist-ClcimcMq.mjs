//#region node_modules/.nitro/vite/services/ssr/assets/persist-ClcimcMq.js
var asked = null;
async function ensurePersist(sm = typeof navigator !== "undefined" ? navigator.storage : void 0) {
	if (!sm?.persist) return false;
	try {
		if (sm.persisted && await sm.persisted()) return true;
		return await sm.persist();
	} catch {
		return false;
	}
}
/** Chỉ hỏi một lần mỗi phiên; gọi sau lần lưu tài liệu đầu tiên (có tương tác người dùng). */
function persistOnce(sm) {
	if (!asked) asked = ensurePersist(sm).then((ok) => {
		globalThis.__v11 = ok;
		return ok;
	});
	return asked;
}
//#endregion
export { persistOnce };
