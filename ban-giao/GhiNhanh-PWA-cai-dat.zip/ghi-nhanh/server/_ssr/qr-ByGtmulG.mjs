import { o as __toESM } from "../_runtime.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/qr-ByGtmulG.js
var native;
var canvas = () => document.createElement("canvas");
function getNative() {
	if (native !== void 0) return native;
	const BD = window.BarcodeDetector;
	try {
		native = BD ? new BD({ formats: [
			"qr_code",
			"ean_13",
			"code_128"
		] }) : null;
	} catch {
		native = null;
	}
	return native;
}
var cv = null;
async function viaJsQr(src, w, h) {
	const { default: jsQR } = await import("../_libs/jsqr.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
	const s = Math.min(1, 800 / Math.max(w, h));
	cv ??= canvas();
	cv.width = Math.round(w * s);
	cv.height = Math.round(h * s);
	const ctx = cv.getContext("2d", { willReadFrequently: true });
	ctx.drawImage(src, 0, 0, cv.width, cv.height);
	const d = ctx.getImageData(0, 0, cv.width, cv.height);
	return jsQR(d.data, d.width, d.height, { inversionAttempts: "attemptBoth" })?.data ?? null;
}
async function readCode(src) {
	const w = src instanceof HTMLVideoElement ? src.videoWidth : src.naturalWidth;
	const h = src instanceof HTMLVideoElement ? src.videoHeight : src.naturalHeight;
	if (!w) return null;
	const n = getNative();
	if (n) {
		const [r] = await n.detect(src).catch(() => []);
		if (r?.rawValue) return r.rawValue;
	}
	return viaJsQr(src, w, h);
}
async function readCodeFromDataUrl(url) {
	const img = new Image();
	img.src = url;
	await img.decode();
	return readCode(img);
}
//#endregion
export { readCodeFromDataUrl as n, readCode as t };
