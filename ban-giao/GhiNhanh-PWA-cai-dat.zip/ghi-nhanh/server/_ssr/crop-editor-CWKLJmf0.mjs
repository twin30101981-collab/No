import { o as __toESM } from "../_runtime.mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { o as aiPaperCorners } from "./ai.functions-CpS7iAgj.mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { Jt as ChevronLeft, Kt as ChevronUp, N as RotateCcw, Yt as ChevronDown, d as TriangleAlert, o as WandSparkles, qt as ChevronRight, r as X } from "../_libs/lucide-react.mjs";
import { i as useQueuedServerFn } from "./ai-queue-DZjZmUCT.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { P as refineQuadOnSrc, X as toolsKey, _ as detectQuadInfo, l as compress, n as PAPER_LABEL } from "./image-DFWRNlNd.mjs";
import { o as recognizeWordBoxes } from "./ocr-CLa2avjZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/crop-editor-CWKLJmf0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var shouldAskAi = (local, online) => !(local.quad && local.sure) && online;
function pickQuad(local, ai) {
	if (local.quad && local.sure) return {
		q: local.quad,
		how: "local"
	};
	if (ai) return {
		q: ai,
		how: "ai"
	};
	return {
		q: local.quad,
		how: local.quad ? "local" : "none"
	};
}
var cross$1 = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
function orderQuad$1(pts) {
	const cx = pts.reduce((s, p) => s + p[0], 0) / 4, cy = pts.reduce((s, p) => s + p[1], 0) / 4;
	const sorted = [...pts].sort((a, b) => Math.atan2(a[1] - cy, a[0] - cx) - Math.atan2(b[1] - cy, b[0] - cx));
	let start = 0;
	sorted.forEach((p, i) => {
		if (p[0] + p[1] < sorted[start][0] + sorted[start][1]) start = i;
	});
	return [
		0,
		1,
		2,
		3
	].map((k) => sorted[(start + k) % 4]);
}
function quadArea$1(q) {
	let s = 0;
	for (let i = 0; i < 4; i++) {
		const a = q[i], b = q[(i + 1) % 4];
		s += a[0] * b[1] - b[0] * a[1];
	}
	return Math.abs(s) / 2;
}
function isConvex$1(q) {
	const signs = q.map((_, i) => Math.sign(cross$1(q[i], q[(i + 1) % 4], q[(i + 2) % 4])));
	return signs.every((s) => s !== 0 && s === signs[0]);
}
/** Returns a usable quad or null (not found, unsure, off-image, too small, self-crossing). */
function parseAiQuad(r, minConfidence = .4) {
	if (!r || !r.found || r.confidence < minConfidence || r.corners?.length !== 4) return null;
	const pts = [];
	for (const c of r.corners) {
		if (!Number.isFinite(c.x) || !Number.isFinite(c.y) || c.x < -150 || c.y < -150 || c.x > 1150 || c.y > 1150) return null;
		pts.push([Math.min(1, Math.max(0, c.x / 1e3)), Math.min(1, Math.max(0, c.y / 1e3))]);
	}
	const q = orderQuad$1(pts);
	if (!isConvex$1(q) || quadArea$1(q) < .08) return null;
	for (let i = 0; i < 4; i++) for (let j = i + 1; j < 4; j++) if (Math.hypot(q[i][0] - q[j][0], q[i][1] - q[j][1]) < .05) return null;
	return q;
}
function isLandscapeSpread(W, H) {
	return W > 0 && H > 0 && W / H >= 1.15;
}
var mid = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
/** Lấy nửa trái/phải của khung 4 góc (↖↗↘↙), cắt theo trung điểm cạnh trên và cạnh dưới. */
function halfQuad(q, side) {
	const top = mid(q[0], q[1]), bot = mid(q[3], q[2]);
	return side === "left" ? [
		[q[0][0], q[0][1]],
		top,
		bot,
		[q[3][0], q[3][1]]
	] : [
		top,
		[q[1][0], q[1][1]],
		[q[2][0], q[2][1]],
		bot
	];
}
/** Vị trí góc trên-trái của kính (px trong hộp ảnh). Mặc định đặt phía trên, lệch về phía tâm ảnh. */
function loupePlacement(fx, fy, bw, bh, size = 112, gap = 24) {
	const px = fx * bw, py = fy * bh;
	let left = fx > .5 ? px - size - gap : px + gap;
	let top = py - size - gap;
	if (top < 0) top = py + gap;
	left = Math.max(0, Math.min(Math.max(0, bw - size), left));
	top = Math.max(0, Math.min(Math.max(0, bh - size), top));
	return {
		left,
		top
	};
}
var SNAP_DIST = .02;
var cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
/** Diện tích (shoelace, luôn dương). */
function quadArea(q) {
	let s = 0;
	for (let i = 0; i < 4; i++) s += q[i][0] * q[(i + 1) % 4][1] - q[(i + 1) % 4][0] * q[i][1];
	return Math.abs(s) / 2;
}
/** Sắp lại thứ tự ↖ ↗ ↘ ↙ (theo chiều kim đồng hồ quanh trọng tâm) — sửa khung chéo khi kéo góc vượt qua nhau. */
function orderQuad(q) {
	const cx = q.reduce((s, p) => s + p[0], 0) / 4, cy = q.reduce((s, p) => s + p[1], 0) / 4;
	const pts = [...q].map((p) => [p[0], p[1]]).sort((a, b) => Math.atan2(a[1] - cy, a[0] - cx) - Math.atan2(b[1] - cy, b[0] - cx));
	let k = 0;
	for (let i = 1; i < 4; i++) if (pts[i][0] + pts[i][1] < pts[k][0] + pts[k][1]) k = i;
	return [
		0,
		1,
		2,
		3
	].map((i) => pts[(k + i) % 4]);
}
function isConvex(q) {
	let sign = 0;
	for (let i = 0; i < 4; i++) {
		const c = cross(q[i], q[(i + 1) % 4], q[(i + 2) % 4]);
		if (Math.abs(c) < 1e-9) return false;
		if (sign === 0) sign = Math.sign(c);
		else if (Math.sign(c) !== sign) return false;
	}
	return true;
}
/** Góc trong nhỏ nhất (độ). */
function minInnerAngle(q) {
	let m = 180;
	for (let i = 0; i < 4; i++) {
		const a = q[(i + 3) % 4], o = q[i], b = q[(i + 1) % 4];
		const v1 = [a[0] - o[0], a[1] - o[1]], v2 = [b[0] - o[0], b[1] - o[1]];
		const c = (v1[0] * v2[0] + v1[1] * v2[1]) / (Math.hypot(v1[0], v1[1]) * Math.hypot(v2[0], v2[1]) || 1);
		m = Math.min(m, Math.acos(Math.max(-1, Math.min(1, c))) * 180 / Math.PI);
	}
	return m;
}
/** Kiểm khung trước khi Áp dụng: không lõm/chéo, không quá nhỏ, không méo quá. */
function checkQuad(q) {
	if (!isConvex(q)) return {
		ok: false,
		reason: "cheo",
		message: "Khung bị chéo hoặc lõm — kéo các góc về đúng 4 góc giấy"
	};
	if (quadArea(q) < .05) return {
		ok: false,
		reason: "nho",
		message: "Khung quá nhỏ — hãy kéo rộng ra mép giấy"
	};
	if (minInnerAngle(q) < 30) return {
		ok: false,
		reason: "meo",
		message: "Khung méo quá — chữ sẽ bị kéo giãn khi nắn"
	};
	return { ok: true };
}
/** Hút góc `i` về góc dò được gần nhất nếu trong `dist`. Trả nguyên khung nếu không có gì để hút. */
function snapCorner(q, i, targets, dist = SNAP_DIST) {
	const p = q[i];
	let best = null, bd = dist;
	for (const t of targets) {
		const d = Math.hypot(t[0] - p[0], t[1] - p[1]);
		if (d <= bd) {
			bd = d;
			best = t;
		}
	}
	if (!best) return q;
	return q.map((v, j) => j === i ? [best[0], best[1]] : v);
}
/** Điểm hút: góc khung dò tự động + 4 góc ảnh. */
function snapTargets(detected) {
	const t = [
		[0, 0],
		[1, 0],
		[1, 1],
		[0, 1]
	];
	if (detected) for (const p of detected) t.push([p[0], p[1]]);
	return t;
}
/** Chuẩn hoá khung khi thả tay: sắp lại thứ tự nếu chéo do kéo vượt; kẹp trong 0..1. */
function tidyQuad(q) {
	const c = q.map((p) => [Math.min(1, Math.max(0, p[0])), Math.min(1, Math.max(0, p[1]))]);
	return isConvex(c) ? c : (() => {
		const o = orderQuad(c);
		return isConvex(o) ? o : c;
	})();
}
var TILT_STEP = .5;
function rotateQuad(q, deg, W, H) {
	const a = deg * Math.PI / 180, c = Math.cos(a), s = Math.sin(a);
	const cx = q.reduce((t, p) => t + p[0], 0) / 4 * W, cy = q.reduce((t, p) => t + p[1], 0) / 4 * H;
	return q.map(([x, y]) => {
		const dx = x * W - cx, dy = y * H - cy;
		return [Math.min(1, Math.max(0, (cx + dx * c - dy * s) / W)), Math.min(1, Math.max(0, (cy + dx * s + dy * c) / H))];
	});
}
var clampTilt = (t) => Math.max(-5, Math.min(5, Math.round(t / TILT_STEP) * TILT_STEP));
/** P3.2 – Hút cạnh: nhận khung tinh chỉnh trên ảnh gốc chỉ cho 2 góc của cạnh vừa kéo, và chỉ khi mỗi góc dời ≤ `maxMove`. */
var EDGE_SNAP_MAX = .03;
function acceptEdgeRefine(q, refined, side, maxMove = EDGE_SNAP_MAX) {
	const ids = [side, (side + 1) % 4];
	for (const i of ids) if (Math.hypot(refined[i][0] - q[i][0], refined[i][1] - q[i][1]) > maxMove) return q;
	const out = q.map((p, i) => ids.includes(i) ? [refined[i][0], refined[i][1]] : p);
	return checkQuad(out).ok ? out : q;
}
/** Tỉ lệ vừa khung (CSS px trên 1 điểm ảnh). */
function fitScale(view, img) {
	if (!(view.w > 0 && view.h > 0 && img.w > 0 && img.h > 0)) return 1;
	return Math.min(view.w / img.w, view.h / img.h);
}
/** Tỉ lệ 100%: 1 điểm ảnh = 1 điểm vật lý của màn hình (dpr = devicePixelRatio). */
function actualScale(dpr) {
	return dpr > 0 ? 1 / dpr : 1;
}
/** Giữ ảnh trong khung: nhỏ hơn khung thì căn giữa, lớn hơn thì không hở mép. `pan` = vị trí góc trên trái của ảnh trong khung. */
function clampPan(pan, view, img, scale) {
	const cw = img.w * scale, ch = img.h * scale;
	const ax = (p, v, c) => c <= v ? (v - c) / 2 : Math.min(0, Math.max(v - c, p));
	return {
		x: ax(pan.x, view.w, cw),
		y: ax(pan.y, view.h, ch)
	};
}
/** Đưa điểm ảnh chuẩn hoá (0..1) về giữa khung ở tỉ lệ `scale` (để nhảy tới vùng bị báo cắt). */
function centerOn(point, view, img, scale) {
	return clampPan({
		x: view.w / 2 - point.x * img.w * scale,
		y: view.h / 2 - point.y * img.h * scale
	}, view, img, scale);
}
/** Hộp điểm ảnh (x0,y0,x1,y1; y hướng xuống) → hộp chuẩn hoá, kẹp 0..1, bỏ hộp rỗng/hỏng. */
function boxFromPixels(b, img, kind) {
	if (!(img.w > 0 && img.h > 0)) return null;
	const x0 = Math.max(0, Math.min(1, b.x0 / img.w)), x1 = Math.max(0, Math.min(1, b.x1 / img.w));
	const y0 = Math.max(0, Math.min(1, b.y0 / img.h)), y1 = Math.max(0, Math.min(1, b.y1 / img.h));
	if (![
		x0,
		x1,
		y0,
		y1
	].every(Number.isFinite) || x1 - x0 <= 0 || y1 - y0 <= 0) return null;
	return kind ? {
		x: x0,
		y: y0,
		w: x1 - x0,
		h: y1 - y0,
		kind
	} : {
		x: x0,
		y: y0,
		w: x1 - x0,
		h: y1 - y0
	};
}
/** Từ OCR (điểm ảnh, y hướng xuống, có độ tin cậy 0..100) → hộp nội dung; bỏ từ tin cậy thấp và ký hiệu thuần (gạch bảng, vệt) vì không phải chữ cần giữ. */
function boxFromOcrWord(w, img, minConf = 30) {
	if (!(w.conf >= minConf) || !/[\p{L}\p{N}]/u.test(w.text)) return null;
	return boxFromPixels(w, img, "text");
}
var clone = (e) => ({
	...e,
	tools: e.tools ? { ...e.tools } : void 0,
	quad: e.quad ? e.quad.map((p) => [p[0], p[1]]) : void 0,
	paper: e.paper
});
/** Góc xoay theo vòng 0..359: app cộng dồn +90 (360, 450…) và image.ts chuẩn hoá khi dựng, nên so sánh cũng phải chuẩn hoá. */
var turn = (r) => (r % 360 + 360) % 360;
function editsEqual(a, b) {
	if (turn(a.rotation) !== turn(b.rotation) || a.filter !== b.filter || a.brightness !== b.brightness || a.contrast !== b.contrast) return false;
	if ((a.flatten ?? null) !== (b.flatten ?? null) || toolsKey(a.tools) !== toolsKey(b.tools)) return false;
	if (JSON.stringify(a.quad ?? null) !== JSON.stringify(b.quad ?? null)) return false;
	return JSON.stringify(a.paper ?? null) === JSON.stringify(b.paper ?? null);
}
/** Mở phiên: `saved` không bao giờ bị sửa tại chỗ; mọi thao tác chỉ đổi `draft`. */
function startSession(saved) {
	return {
		saved: clone(saved),
		draft: clone(saved),
		past: [],
		future: []
	};
}
var isDirty = (s) => !editsEqual(s.draft, s.saved);
var canUndo = (s) => s.past.length > 0;
var canRedo = (s) => s.future.length > 0;
/** Áp một thay đổi lên bản nháp. Thay đổi không làm đổi gì thì không thêm bước hoàn tác. */
function applyEdit(s, patch) {
	const next = clone({
		...s.draft,
		...patch
	});
	if (editsEqual(next, s.draft)) return s;
	return {
		...s,
		draft: next,
		past: [...s.past, s.draft].slice(-50),
		future: []
	};
}
function undo(s) {
	const prev = s.past[s.past.length - 1];
	if (!prev) return s;
	return {
		...s,
		draft: prev,
		past: s.past.slice(0, -1),
		future: [s.draft, ...s.future]
	};
}
function redo(s) {
	const nxt = s.future[0];
	if (!nxt) return s;
	return {
		...s,
		draft: nxt,
		past: [...s.past, s.draft].slice(-50),
		future: s.future.slice(1)
	};
}
/** Đặt lại về bản đã lưu; bản thân việc đặt lại cũng hoàn tác được. */
function resetSession(s) {
	return applyEdit(s, s.saved);
}
/** Lưu: chỉ báo `changed` khi bản nháp khác bản đã lưu; nơi gọi chỉ dựng lại/ghi trang khi `changed`. */
function saveSession(s) {
	const edit = clone(s.draft);
	return {
		edit,
		changed: isDirty(s),
		session: startSession(edit)
	};
}
var area2 = (q) => q.reduce((a, p, i) => {
	const n = q[(i + 1) % q.length];
	return a + (p[0] * n[1] - n[0] * p[1]);
}, 0);
function insideQuad(q, x, y, margin) {
	const sign = area2(q) >= 0 ? 1 : -1;
	for (let i = 0; i < q.length; i++) {
		const a = q[i], b = q[(i + 1) % q.length];
		const ex = b[0] - a[0], ey = b[1] - a[1], len = Math.hypot(ex, ey);
		if (len === 0) continue;
		if (sign * (ex * (y - a[1]) - ey * (x - a[0])) / len < -margin) return false;
	}
	return true;
}
/**
* Kiểm vùng sẽ cắt: lấy lưới 5×5 điểm trên mỗi hộp nội dung, hộp nào có điểm nằm ngoài khung (dung sai `margin`) là bị cắt.
* Không có khung (quad rỗng) = giữ cả ảnh = an toàn. Đây là chỉ báo cho người dùng xem trước khi Lưu, không thay việc soi mắt ở 100%.
*/
function cropSafety(quad, boxes, margin = .005) {
	if (!quad || quad.length < 3) return {
		safe: true,
		cut: []
	};
	const cut = [];
	boxes.forEach((b, index) => {
		let inn = 0, tot = 0;
		for (let i = 0; i <= 4; i++) for (let j = 0; j <= 4; j++) {
			tot++;
			if (insideQuad(quad, b.x + b.w * i / 4, b.y + b.h * j / 4, margin)) inn++;
		}
		if (inn < tot) cut.push({
			index,
			kind: b.kind,
			inside: inn / tot
		});
	});
	return {
		safe: cut.length === 0,
		cut
	};
}
/**
* Chỉ giữ hộp bị khung cắt NGANG (một phần trong, một phần ngoài). Hộp nằm hẳn ngoài khung (chữ trang kế, bàn, hình mờ máy ảnh) không phải chữ bị mất nên bỏ qua.
* Đo trên bộ ảnh gốc: từ OCR hẳn ngoài khung 66/307, vắt ngang mép 8/307 (progress/S13/s13c).
*/
function edgeCutCheck(quad, boxes, margin = .005) {
	const cut = cropSafety(quad, boxes, margin).cut.filter((c) => c.inside > 0);
	return {
		safe: cut.length === 0,
		cut
	};
}
var CORNERS = [
	"↖",
	"↗",
	"↘",
	"↙"
];
/** On-device detector first; AI corners (refined on the original) when local is unsure. */
function useFindQuad() {
	const aiFn = useQueuedServerFn(aiPaperCorners, "Dò mép giấy");
	return async (src) => {
		const local = await detectQuadInfo(src);
		const online = typeof navigator === "undefined" || navigator.onLine !== false;
		if (!shouldAskAi(local, online)) return {
			...pickQuad(local, null),
			msg: online ? void 0 : "Đang mất mạng — dùng bộ dò trên máy, hãy kiểm tra lại các góc"
		};
		const res = await aiFn({ data: { image: await compress(src, 1024, .7) } }).catch(() => null);
		const aq = res?.ok ? parseAiQuad(res.data) : null;
		return {
			...pickQuad(local, aq ? await refineQuadOnSrc(src, aq).catch(() => aq) : null),
			msg: res && !res.ok ? res.message : void 0
		};
	};
}
function CropEditor({ src, quad, paper: paper0, onClose, onApply, cancelLabel = "Hủy", applyLabel = "Áp dụng" }) {
	const [q, setQ] = (0, import_react.useState)(quad ?? [
		[.04, .04],
		[.96, .04],
		[.96, .96],
		[.04, .96]
	]);
	const [paper, setPaper] = (0, import_react.useState)(paper0 ?? "auto");
	const [active, setActive] = (0, import_react.useState)(-1);
	const [sel, setSel] = (0, import_react.useState)(0);
	const initial = (0, import_react.useRef)(q);
	const detected = (0, import_react.useRef)(quad ?? null);
	function nudge(dx, dy) {
		const s = .005;
		setQ((cur) => cur.map((p, i) => i === sel ? [Math.min(1, Math.max(0, p[0] + dx * s)), Math.min(1, Math.max(0, p[1] + dy * s))] : p));
	}
	const [busy, setBusy] = (0, import_react.useState)(false);
	const find = useFindQuad();
	const findQuad = () => find(src);
	async function auto() {
		setBusy(true);
		try {
			const r = await findQuad();
			if (r.q) {
				setQ(r.q);
				detected.current = r.q;
			}
			if (r.how === "ai") toast("Đã dò mép giấy bằng AI — kiểm tra lại các góc");
			else if (r.how === "none") toast(r.msg ?? "Không tự nhận được mép giấy, hãy kéo góc bằng tay");
			else if (r.msg) toast(r.msg);
		} catch {
			toast("Không tự nhận được mép giấy, hãy kéo góc bằng tay");
		} finally {
			setBusy(false);
		}
	}
	const box = (0, import_react.useRef)(null);
	const drag = (0, import_react.useRef)(-1);
	(0, import_react.useEffect)(() => {
		if (quad) return;
		let live = true;
		setBusy(true);
		findQuad().then((r) => {
			if (live && r.q) {
				setQ(r.q);
				initial.current = r.q;
				detected.current = r.q;
			}
		}).catch(() => {}).finally(() => live && setBusy(false));
		return () => {
			live = false;
		};
	}, [src, quad]);
	const start = (0, import_react.useRef)(null);
	const clamp = (v) => Math.min(1, Math.max(0, v));
	function down(i, e) {
		drag.current = i;
		setActive(i);
		if (i < 4) setSel(i);
		start.current = {
			x: e.clientX,
			y: e.clientY,
			q
		};
		e.target.setPointerCapture(e.pointerId);
	}
	function up() {
		const k = drag.current;
		if (k >= 0) setQ((cur) => tidyQuad(k < 4 ? snapCorner(cur, k, snapTargets(detected.current)) : cur));
		if (k >= 4) {
			const side = k - 4;
			setQ((cur) => {
				refineQuadOnSrc(src, cur).then((rf) => setQ((now) => now === cur ? acceptEdgeRefine(cur, rf, side) : now)).catch(() => {});
				return cur;
			});
		}
		drag.current = -1;
		setActive(-1);
		start.current = null;
	}
	const check = checkQuad(q);
	const [boxes, setBoxes] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		recognizeWordBoxes(src, 1600).then((r) => {
			if (live) setBoxes(r.words.map((w) => boxFromOcrWord(w, r.size)).filter((b) => !!b));
		}).catch(() => {});
		return () => {
			live = false;
		};
	}, [src]);
	const cutCheck = boxes ? edgeCutCheck(q, boxes) : null;
	const [tilt, setTilt] = (0, import_react.useState)(0);
	const imgRef = (0, import_react.useRef)(null);
	const [spread, setSpread] = (0, import_react.useState)(false);
	function rotate(step) {
		const next = clampTilt(tilt + step);
		if (next === tilt) return;
		const el = imgRef.current;
		const W = el?.naturalWidth || 1, H = el?.naturalHeight || 1;
		setQ((cur) => rotateQuad(cur, next - tilt, W, H));
		setTilt(next);
	}
	function move(e) {
		const st = start.current;
		if (drag.current < 0 || !box.current || !st) return;
		const r = box.current.getBoundingClientRect();
		const dx = (e.clientX - st.x) / r.width, dy = (e.clientY - st.y) / r.height;
		const k = drag.current;
		const ids = k < 4 ? [k] : [k - 4, (k - 3) % 4];
		setQ(st.q.map((p, i) => ids.includes(i) ? [clamp(p[0] + dx), clamp(p[1] + dy)] : p));
	}
	const mids = q.map((p, i) => [(p[0] + q[(i + 1) % 4][0]) / 2, (p[1] + q[(i + 1) % 4][1]) / 2]);
	const area = (0, import_react.useRef)(null);
	const [areaH, setAreaH] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const el = area.current;
		if (!el || typeof ResizeObserver === "undefined") return;
		const ro = new ResizeObserver(() => setAreaH(el.clientHeight));
		ro.observe(el);
		return () => ro.disconnect();
	}, []);
	const focus = active < 0 ? null : active < 4 ? q[active] : mids[active - 4];
	const bw = box.current?.clientWidth ?? 0, bh = box.current?.clientHeight ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "scan-screen fixed inset-0 z-50 mx-auto flex max-w-[430px] flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-3 pt-[max(0.75rem,env(safe-area-inset-top))] pb-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: "scan-icon",
						onClick: onClose,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}),
							" ",
							cancelLabel
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm font-semibold",
						children: "Kéo góc hoặc cạnh vào mép giấy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-16" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: area,
				"data-testid": "crop-area",
				className: "grid min-h-0 flex-1 place-items-center p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: box,
					className: "relative touch-none",
					onPointerMove: move,
					onPointerUp: up,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							ref: imgRef,
							src,
							alt: "Ảnh gốc",
							className: "block max-h-[62dvh] max-w-full select-none",
							draggable: false,
							style: areaH ? { maxHeight: Math.max(120, areaH - 48) } : void 0,
							onLoad: (e) => setSpread(isLandscapeSpread(e.currentTarget.naturalWidth, e.currentTarget.naturalHeight))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							viewBox: "0 0 100 100",
							preserveAspectRatio: "none",
							className: "pointer-events-none absolute inset-0 h-full w-full",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									"data-crop-dim": true,
									fillRule: "evenodd",
									className: "scan-dim",
									d: `M0,0 H100 V100 H0 Z M${q.map(([x, y]) => `${x * 100},${y * 100}`).join(" L")} Z`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
									points: q.map(([x, y]) => `${x * 100},${y * 100}`).join(" "),
									className: "scan-quad"
								}),
								cutCheck && !cutCheck.safe && boxes && cutCheck.cut.map((c) => {
									const bx = boxes[c.index];
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										"data-cut": true,
										x: bx.x * 100,
										y: bx.y * 100,
										width: bx.w * 100,
										height: bx.h * 100,
										className: "fill-destructive/40 stroke-destructive",
										strokeWidth: .5,
										style: { vectorEffect: "non-scaling-stroke" }
									}, c.index);
								})
							]
						}),
						focus && bw > 0 && (() => {
							const L = loupePlacement(focus[0], focus[1], bw, bh);
							const half = 112 / 2;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								"data-testid": "crop-loupe",
								className: "pointer-events-none absolute z-10 overflow-hidden rounded-full border-2 border-primary bg-background shadow-lg",
								style: {
									left: L.left,
									top: L.top,
									width: 112,
									height: 112
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute",
										style: {
											width: bw * 3,
											height: bh * 3,
											left: half - focus[0] * bw * 3,
											top: half - focus[1] * bh * 3
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src,
											alt: "",
											className: "block h-full w-full",
											draggable: false
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
											viewBox: "0 0 100 100",
											preserveAspectRatio: "none",
											className: "absolute inset-0 h-full w-full",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
												points: q.map(([x, y]) => `${x * 100},${y * 100}`).join(" "),
												className: "scan-quad",
												style: { vectorEffect: "non-scaling-stroke" }
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-1/2 top-0 h-full w-px -translate-x-1/2 bg-primary/70" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-0 top-1/2 h-px w-full -translate-y-1/2 bg-primary/70" })
								]
							});
						})(),
						q.map(([x, y], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							onPointerDown: (e) => down(i, e),
							onPointerMove: move,
							onPointerUp: up,
							onPointerCancel: up,
							style: {
								left: `${x * 100}%`,
								top: `${y * 100}%`
							},
							className: `crop-handle absolute size-8 -translate-x-1/2 -translate-y-1/2 rounded-full ${sel === i ? "ring-4 ring-primary/60" : ""}`
						}, i)),
						mids.map(([x, y], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-label": "Kéo cạnh",
							onPointerDown: (e) => down(i + 4, e),
							onPointerMove: move,
							onPointerUp: up,
							onPointerCancel: up,
							style: {
								left: `${x * 100}%`,
								top: `${y * 100}%`
							},
							className: "crop-handle absolute size-6 -translate-x-1/2 -translate-y-1/2 rounded-full opacity-80"
						}, `m${i}`))
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shrink-0 flex items-center justify-between gap-2 px-4 pb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1",
					role: "group",
					"aria-label": "Chọn góc để chỉnh",
					children: CORNERS.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: sel === i ? "default" : "glass",
						className: "h-8 rounded-full px-2.5 text-xs",
						onClick: () => setSel(i),
						children: c
					}, c))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-0.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "glass",
							className: "size-7",
							"aria-label": "Lên",
							onClick: () => nudge(0, -1),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "glass",
							className: "size-7",
							"aria-label": "Trái",
							onClick: () => nudge(-1, 0),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "glass",
							className: "size-7",
							"aria-label": "Đặt lại",
							onClick: () => setQ(initial.current),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "glass",
							className: "size-7",
							"aria-label": "Phải",
							onClick: () => nudge(1, 0),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "glass",
							className: "size-7",
							"aria-label": "Xuống",
							onClick: () => nudge(0, 1),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shrink-0 flex items-center justify-center gap-2 px-4 pb-2",
				role: "group",
				"aria-label": "Xoay mịn",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "glass",
						className: "h-8 rounded-full",
						"aria-label": "Xoay trái 0,5 độ",
						disabled: tilt <= -5,
						onClick: () => rotate(-TILT_STEP),
						children: "↺"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "w-16 text-center text-xs tabular-nums",
						"aria-live": "polite",
						children: [tilt.toLocaleString("vi-VN"), "°"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "glass",
						className: "h-8 rounded-full",
						"aria-label": "Xoay phải 0,5 độ",
						disabled: tilt >= 5,
						onClick: () => rotate(TILT_STEP),
						children: "↻"
					})
				]
			}),
			spread && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-center gap-2 px-4 pb-2",
				role: "group",
				"aria-label": "Ảnh ngang 2 trang",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs opacity-70",
						children: "Ảnh ngang — giữ 1 trang:"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "glass",
						className: "h-8 rounded-full",
						onClick: () => setQ((cur) => tidyQuad(halfQuad(cur, "left"))),
						children: "Trang trái"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "glass",
						className: "h-8 rounded-full",
						onClick: () => setQ((cur) => tidyQuad(halfQuad(cur, "right"))),
						children: "Trang phải"
					})
				]
			}),
			cutCheck && !cutCheck.safe && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				role: "alert",
				className: "scan-warn mx-4 mb-2 flex items-center gap-2 rounded-lg px-3 py-2 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 shrink-0" }),
					" Khung cắt đi qua ",
					cutCheck.cut.length,
					" từ ở mép — nới khung ra để không mất chữ."
				]
			}),
			!check.ok && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "px-4 pb-2 text-center text-xs text-destructive",
				children: check.message
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0 flex gap-1.5 overflow-x-auto px-4 pb-2 [scrollbar-width:none]",
				children: Object.keys(PAPER_LABEL).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: paper === k ? "default" : "glass",
					className: "shrink-0 rounded-full",
					onClick: () => setPaper(k),
					children: PAPER_LABEL[k]
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shrink-0 grid grid-cols-3 gap-2 px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "glass",
						disabled: busy,
						onClick: auto,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WandSparkles, {}),
							" ",
							busy ? "Đang dò…" : "Tự động"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "glass",
						onClick: () => setQ([
							[0, 0],
							[1, 0],
							[1, 1],
							[0, 1]
						]),
						children: "Toàn ảnh"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: !check.ok,
						onClick: () => check.ok && onApply(q, paper),
						children: applyLabel
					})
				]
			})
		]
	});
}
//#endregion
export { useFindQuad as _, canRedo as a, clampPan as c, isDirty as d, redo as f, undo as g, startSession as h, boxFromOcrWord as i, edgeCutCheck as l, saveSession as m, actualScale as n, canUndo as o, resetSession as p, applyEdit as r, centerOn as s, CropEditor as t, fitScale as u };
