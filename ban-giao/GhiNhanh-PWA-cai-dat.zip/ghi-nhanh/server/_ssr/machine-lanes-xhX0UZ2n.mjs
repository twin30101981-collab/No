//#region node_modules/.nitro/vite/services/ssr/assets/machine-lanes-xhX0UZ2n.js
/**
* B06: số làn xử lý song song co theo sức máy.
* Máy RAM 3–4 GB (deviceMemory ≤ 4) chỉ chạy 1–2 làn để không tràn bộ nhớ;
* máy mạnh hơn chạy tối đa min(4, cores/2). Công tắc __v8Lanes vẫn ghi đè để đo so sánh.
*/
function machineLanes(cores = typeof navigator !== "undefined" && navigator.hardwareConcurrency || 2, memGB = typeof navigator !== "undefined" && navigator.deviceMemory || 8) {
	const force = globalThis.__v8Lanes;
	if (force && force > 0) return Math.floor(force);
	if (memGB <= 4) return cores <= 2 ? 1 : 2;
	return Math.min(4, Math.max(2, Math.floor(cores / 2)));
}
/**
* CS-09b: số việc "dựng bản đầy đủ" chạy song song trong hàng đợi nền. Mỗi việc giữ vài bộ đệm ~35 MB (A4 300 dpi),
* nên chỉ chạy nhiều làn (3, CS-17e) khi máy ≥ 4 nhân và RAM > 4 GB; còn lại 1 làn như trước.
*/
function finishLanes(cores = typeof navigator !== "undefined" && navigator.hardwareConcurrency || 2, memGB = typeof navigator !== "undefined" && navigator.deviceMemory || 8) {
	return cores >= 4 && memGB > 4 ? 3 : 1;
}
//#endregion
export { machineLanes as n, finishLanes as t };
