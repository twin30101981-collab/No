import { n as reportAiResult } from "./ai-queue-DZjZmUCT.mjs";
import { r as canvasToPageUrl } from "./files-CTF11Arr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/translate-overlay-Cd_yt33V.js
var top = (w) => -w.y - w.h / 2;
function union(a, b) {
	const x = Math.min(a.x, b.x), y = Math.min(a.y, b.y);
	return {
		x,
		y,
		w: Math.max(a.x + a.w, b.x + b.w) - x,
		h: Math.max(a.y + a.h, b.y + b.h) - y
	};
}
/** Gom từ cùng hàng (tâm dọc lệch < nửa chiều cao) và gần nhau theo chiều ngang thành dòng. */
function wordsToLines(words) {
	const ws = words.filter((w) => w.str.trim() && w.w > 0 && w.h > 0).map((w) => ({
		x: w.x,
		y: top(w),
		w: w.w,
		h: w.h,
		text: w.str.trim()
	})).sort((a, b) => a.y + a.h / 2 - (b.y + b.h / 2) || a.x - b.x);
	const rows = [];
	for (const w of ws) {
		const cy = w.y + w.h / 2;
		const row = rows.find((r) => {
			const l = r[r.length - 1];
			return Math.abs(l.y + l.h / 2 - cy) < Math.max(l.h, w.h) / 2;
		});
		if (row) row.push(w);
		else rows.push([w]);
	}
	const lines = [];
	for (const r of rows) {
		r.sort((a, b) => a.x - b.x);
		let cur = null;
		for (const w of r) if (cur && w.x - (cur.x + cur.w) <= 2.5 * Math.max(cur.h, w.h)) cur = {
			...union(cur, w),
			text: `${cur.text} ${w.text}`
		};
		else {
			if (cur) lines.push(cur);
			cur = { ...w };
		}
		if (cur) lines.push(cur);
	}
	return lines.sort((a, b) => a.y - b.y || a.x - b.x);
}
/** Gom dòng liền nhau (cách dọc < 0.8 chiều cao dòng, chồng ngang, cỡ chữ gần nhau) thành khối đoạn. */
function linesToBlocks(lines) {
	const blocks = [];
	for (const l of lines) {
		const b = blocks.find((k) => {
			const gap = l.y - (k.last.y + k.last.h);
			const overlap = Math.min(k.x + k.w, l.x + l.w) - Math.max(k.x, l.x);
			const ratio = l.h / k.lineH;
			return gap >= -l.h / 2 && gap < .8 * Math.max(l.h, k.lineH) && overlap > .3 * Math.min(k.w, l.w) && ratio > .6 && ratio < 1.6;
		});
		if (b) {
			Object.assign(b, union(b, l));
			b.text += `\n${l.text}`;
			b.lineH = (b.lineH * b.lines + l.h) / (b.lines + 1);
			b.lines += 1;
			b.last = l;
		} else blocks.push({
			x: l.x,
			y: l.y,
			w: l.w,
			h: l.h,
			text: l.text,
			lineH: l.h,
			lines: 1,
			last: l
		});
	}
	return blocks.map(({ last: _l, ...b }) => b).sort((a, b) => a.y - b.y || a.x - b.x);
}
/** Bỏ khối chỉ có số/ký hiệu (không cần dịch) hoặc quá ngắn. */
function needsTranslation(text) {
	return /\p{L}{2,}/u.test(text);
}
function blocksFromWords(words) {
	return linesToBlocks(wordsToLines(words)).filter((b) => needsTranslation(b.text));
}
/** Ghép kết quả AI vào khối; thiếu/thừa phần tử thì giữ nguyên văn bản gốc. */
function attachTranslations(blocks, translations) {
	return blocks.map((b, i) => ({
		...b,
		translated: translations[i]?.trim() || b.text
	}));
}
/** Chạy trọn bước 1: OCR có vị trí → khối → AI dịch theo lô. */
async function translateImage(src, lang) {
	const { recognizeWords } = await import("./ocr-CLa2avjZ.mjs").then((n) => n.r).then((n) => n.r);
	const { words } = await recognizeWords(src);
	const blocks = blocksFromWords(words);
	if (!blocks.length) return {
		blocks: [],
		error: "Không tìm thấy chữ cần dịch trên trang này."
	};
	const { aiTranslateBlocks } = await import("./ai.functions-CpS7iAgj.mjs").then((n) => n.m).then((n) => n.m);
	const res = await aiTranslateBlocks({ data: {
		texts: blocks.map((b) => b.text).slice(0, 200),
		lang
	} });
	reportAiResult(res);
	if (!res.ok) return {
		blocks: attachTranslations(blocks, []),
		error: res.message
	};
	return { blocks: attachTranslations(blocks, res.texts) };
}
/** Ngắt dòng theo từ cho vừa chiều rộng; từ quá dài được cắt theo ký tự. */
function wrapText(text, maxW, measure) {
	const out = [];
	for (const para of text.split("\n")) {
		let cur = "";
		for (const word of para.split(/\s+/).filter(Boolean)) {
			const next = cur ? `${cur} ${word}` : word;
			if (measure(next) <= maxW) {
				cur = next;
				continue;
			}
			if (cur) out.push(cur);
			cur = "";
			let w = word;
			while (measure(w) > maxW && w.length > 1) {
				let n = w.length - 1;
				while (n > 1 && measure(w.slice(0, n)) > maxW) n--;
				out.push(w.slice(0, n));
				w = w.slice(n);
			}
			cur = w;
		}
		out.push(cur);
	}
	return out;
}
/** Tìm cỡ chữ lớn nhất (≤ 1.1× cỡ gốc, ≥ 6px) để bản dịch vừa khung. measure(s, size) đo chiều rộng. */
function fitText(text, box, measure) {
	const maxSize = Math.max(6, Math.round(box.lineH * 1.1));
	for (let size = maxSize; size >= 6; size--) {
		const lines = wrapText(text, box.w, (s) => measure(s, size));
		if (lines.length * size * 1.2 <= box.h + size * .3 && lines.every((l) => measure(l, size) <= box.w)) return {
			size,
			lines
		};
	}
	return {
		size: 6,
		lines: wrapText(text, box.w, (s) => measure(s, 6))
	};
}
/** Màu nền = trung vị viền quanh khung; chữ đen hoặc trắng tuỳ độ sáng nền. */
function pickColors(data, width, height, box) {
	const rs = [], gs = [], bs = [];
	const pad = 3, x0 = Math.max(0, Math.floor(box.x - pad)), y0 = Math.max(0, Math.floor(box.y - pad));
	const x1 = Math.min(width - 1, Math.ceil(box.x + box.w + pad)), y1 = Math.min(height - 1, Math.ceil(box.y + box.h + pad));
	const push = (x, y) => {
		const i = (y * width + x) * 4;
		rs.push(data[i]);
		gs.push(data[i + 1]);
		bs.push(data[i + 2]);
	};
	for (let x = x0; x <= x1; x++) {
		push(x, y0);
		push(x, y1);
	}
	for (let y = y0; y <= y1; y++) {
		push(x0, y);
		push(x1, y);
	}
	const med = (a) => {
		a.sort((p, q) => p - q);
		return a[a.length >> 1] ?? 255;
	};
	const bg = [
		med(rs),
		med(gs),
		med(bs)
	];
	const lum = .299 * bg[0] + .587 * bg[1] + .114 * bg[2];
	return {
		bg: `rgb(${bg[0]},${bg[1]},${bg[2]})`,
		fg: lum > 128 ? "#111" : "#fafafa"
	};
}
/** Vẽ ảnh + các khối dịch, trả object URL JPEG đã đăng ký (R1.4: không còn data URL). */
async function renderOverlay(src, blocks) {
	const img = new Image();
	img.src = src;
	await img.decode();
	const c = document.createElement("canvas");
	c.width = img.naturalWidth;
	c.height = img.naturalHeight;
	const ctx = c.getContext("2d");
	ctx.drawImage(img, 0, 0);
	const { data } = ctx.getImageData(0, 0, c.width, c.height);
	const font = (s) => `${s}px system-ui, "DejaVu Sans", sans-serif`;
	const measure = (s, size) => {
		ctx.font = font(size);
		return ctx.measureText(s).width;
	};
	for (const b of blocks) {
		const { bg, fg } = pickColors(data, c.width, c.height, b);
		ctx.fillStyle = bg;
		ctx.fillRect(b.x - 2, b.y - 2, b.w + 4, b.h + 4);
		const fit = fitText(b.translated, b, measure);
		ctx.font = font(fit.size);
		ctx.fillStyle = fg;
		ctx.textBaseline = "top";
		fit.lines.forEach((l, i) => ctx.fillText(l, b.x, b.y + i * fit.size * 1.2));
	}
	return canvasToPageUrl(c, "image/jpeg", .92);
}
//#endregion
export { renderOverlay, translateImage };
