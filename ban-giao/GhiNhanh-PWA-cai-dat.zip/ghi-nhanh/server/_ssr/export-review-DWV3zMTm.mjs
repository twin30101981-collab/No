import { o as __toESM } from "../_runtime.mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { It as Download, St as FileTypeCorner, d as TriangleAlert, wt as FileSpreadsheet } from "../_libs/lucide-react.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { c as download, x as safeName } from "./files-CTF11Arr.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, t as Dialog } from "./dialog-3HhpKDcy.mjs";
import { a as countUnsure, i as clean, l as isUnsure, r as buildReview, s as fmtSize, u as recordConversion } from "./history-ZPjFrOJG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/export-review-DWV3zMTm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var cellCls = (s) => "w-full min-w-[84px] rounded-md border px-2 py-1 text-xs outline-none focus:ring-2 focus:ring-ring " + (isUnsure(s) ? "border-warning-foreground/40 bg-warning text-warning-foreground" : "border-border bg-background");
function Grid({ rows, onChange }) {
	const n = Math.max(1, ...rows.map((r) => r.length));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-auto rounded-lg border border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
			className: "text-xs",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.slice(0, 200).map((r, ri) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: Array.from({ length: n }, (_, ci) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "p-0.5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					"aria-label": `Hàng ${ri + 1} cột ${ci + 1}`,
					className: cellCls(r[ci] ?? "") + (ri === 0 ? " font-semibold" : ""),
					value: r[ci] ?? "",
					onChange: (e) => onChange(ri, ci, e.target.value)
				})
			}, ci)) }, ri)) })
		})
	});
}
/** Preview + edit before download. Highlights cells the reader was unsure about. */
function ExportReview({ review, onClose }) {
	const [r, setR] = (0, import_react.useState)(review);
	const [tab, setTab] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		setR(review);
		setTab(0);
	}, [review]);
	const blob = (0, import_react.useMemo)(() => r ? buildReview(r) : null, [r]);
	const unsure = r ? countUnsure(r) : 0;
	if (!r) return null;
	const setCell = (bi, ri, ci, v) => setR((p) => {
		if (!p) return p;
		const c = structuredClone(p);
		const rows = c.kind === "word" ? c.blocks[bi].rows : c.sheets[bi].rows;
		while (rows[ri].length <= ci) rows[ri].push("");
		rows[ri][ci] = v;
		return c;
	});
	const setText = (bi, v) => setR((p) => {
		if (!p || p.kind !== "word") return p;
		const c = structuredClone(p);
		c.blocks[bi].text = v;
		return c;
	});
	const acceptAll = () => setR((p) => {
		if (!p) return p;
		const c = structuredClone(p);
		if (c.kind === "word") c.blocks.forEach((b) => {
			b.text = clean(b.text);
			b.rows = b.rows.map((x) => x.map(clean));
		});
		else c.sheets.forEach((s) => {
			s.rows = s.rows.map((x) => x.map(clean));
		});
		return c;
	});
	const save = () => {
		if (!blob || !review) return;
		const name = `${safeName(r.title)}.${r.kind === "word" ? "docx" : "xlsx"}`;
		download(blob, name);
		toast.success(r.kind === "word" ? "Đã lưu Word" : "Đã lưu Excel");
		recordConversion(review, r, blob, name).catch((e) => console.error("history", e));
		onClose();
	};
	const Icon = r.kind === "word" ? FileTypeCorner : FileSpreadsheet;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "flex max-h-[92vh] max-w-[96vw] flex-col gap-3 rounded-[18px] sm:max-w-[720px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
					className: "flex items-center gap-2 font-display",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 text-primary" }), " Xem lại trước khi lưu"]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					"aria-label": "Tên tệp",
					className: "rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium",
					value: r.title,
					onChange: (e) => setR({
						...r,
						title: e.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2 text-xs text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-secondary px-2.5 py-1 text-secondary-foreground",
							children: ["Dung lượng ước tính: ", blob ? fmtSize(blob.size) : "…"]
						}),
						r.kind === "excel" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-secondary px-2.5 py-1 text-secondary-foreground",
							children: [r.sheets.length, " trang tính"]
						}),
						unsure > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1 rounded-full bg-warning px-2.5 py-1 text-warning-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-3.5" }),
								" ",
								unsure,
								" ô đọc chưa chắc — hãy kiểm tra ô tô vàng"
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-secondary px-2.5 py-1 text-secondary-foreground",
							children: "Không có ô nghi ngờ"
						})
					]
				}),
				r.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: r.note
				}),
				r.kind === "excel" && r.sheets.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1 overflow-x-auto",
					children: r.sheets.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: i === tab ? "default" : "glass",
						onClick: () => setTab(i),
						children: [s.name, s.rows.flat().some(isUnsure) ? " •" : ""]
					}, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-0 flex-1 space-y-2 overflow-auto",
					children: r.kind === "excel" ? r.sheets[tab]?.rows.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grid, {
						rows: r.sheets[tab].rows,
						onChange: (ri, ci, v) => setCell(tab, ri, ci, v)
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Trang này không có dữ liệu."
					}) : r.blocks.map((b, bi) => b.kind === "table" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grid, {
						rows: b.rows,
						onChange: (ri, ci, v) => setCell(bi, ri, ci, v)
					}, bi) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						"aria-label": `Đoạn ${bi + 1}`,
						rows: Math.min(6, Math.max(1, Math.ceil(b.text.length / 60))),
						value: b.text,
						onChange: (e) => setText(bi, e.target.value),
						className: cellCls(b.text) + " resize-y text-sm" + (b.kind === "heading" ? " font-display font-semibold" : "")
					}, bi))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-end gap-2",
					children: [
						unsure > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "glass",
							onClick: acceptAll,
							children: "Bỏ đánh dấu tất cả"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "glass",
							onClick: onClose,
							children: "Huỷ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: save,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), " Lưu tệp"]
						})
					]
				})
			]
		})
	});
}
//#endregion
export { ExportReview as t };
