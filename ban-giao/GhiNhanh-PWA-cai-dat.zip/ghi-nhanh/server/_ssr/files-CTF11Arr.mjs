import { r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { t as adoptBlob } from "./disk-pack-ZdDKsocx.mjs";
import { c as getDocs } from "./db-CclUQaLE.mjs";
import { A as loadImg } from "./image-DFWRNlNd.mjs";
import { i as healPending, n as bgQueue } from "./runner-CZAn6hg6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/files-CTF11Arr.js
var files_CTF11Arr_exports = /* @__PURE__ */ __exportAll({
	C: () => revokeTemp,
	S: () => canvas_url_exports,
	_: () => watermarkPdf,
	a: () => download,
	b: () => canvasToPageUrl,
	c: () => parsePages,
	d: () => pdfjs,
	f: () => reorderPdf,
	g: () => splitPdf,
	h: () => shareOrDownload,
	i: () => docToPdf,
	l: () => pdfPageCount,
	m: () => safeName,
	n: () => compressPage,
	o: () => imagesToPdf,
	p: () => rotatePdf,
	r: () => dataUrlToBlob,
	s: () => mergePdfs,
	t: () => PDF_SIZES,
	u: () => pdfToImages,
	v: () => NUMBER_STYLES,
	w: () => readyDocs,
	x: () => canvasToTempUrl,
	y: () => pageNumberText
});
/** Số việc "finish" còn chờ/đang chạy của các trang thuộc `docs` (việc đã lỗi hết lượt không tính: không còn ai chạy nó). */
function pendingFinishCount(docs) {
	const ids = new Set(docs.flatMap((d) => d.pages.map((p) => p.id)));
	return bgQueue.list().filter((j) => j.kind === "finish" && (j.state === "queued" || j.state === "running") && ids.has(j.pageId)).length;
}
/** Chờ các trang của `docs` hoàn thiện (có thông báo tiến độ), trả về bản mới nhất của từng tài liệu. Không có việc chờ → trả nguyên. */
async function readyDocs(docs) {
	const latest = () => {
		const m = new Map(getDocs().map((d) => [d.id, d]));
		return docs.map((d) => m.get(d.id) ?? d);
	};
	let cur = latest();
	let tid;
	try {
		for (let round = 0; round < 3; round++) {
			await healPending(cur);
			const n = pendingFinishCount(cur);
			if (!n) break;
			tid ??= toast.loading(`Đang hoàn thiện ${n} trang trước khi xuất…`, { description: "Ảnh chất lượng đầy đủ đang được dựng." });
			await bgQueue.flush();
			cur = latest();
		}
	} finally {
		if (tid !== void 0) toast.dismiss(tid);
	}
	const left = cur.reduce((n, d) => n + d.pages.filter((p) => p.status === "dang" || p.status === "loi").length, 0);
	if (left) toast.warning(`${left} trang chưa hoàn thiện được ảnh đầy đủ`, { description: "Bản xuất dùng ảnh xem trước cho các trang này — mở tài liệu để thử lại." });
	return cur;
}
/**
* R1.3 (TD-04) – xuất canvas thành Blob/object URL thay vì chuỗi base64 data URL.
* Canvas được giải phóng (width = 0) ngay sau khi mã hoá để iPhone không giữ bộ nhớ ảnh.
*/
var canvas_url_exports = /* @__PURE__ */ __exportAll$1({
	canvasToBlob: () => canvasToBlob,
	canvasToPageUrl: () => canvasToPageUrl,
	canvasToTempUrl: () => canvasToTempUrl,
	revokeTemp: () => revokeTemp
});
function canvasToBlob(c, type = "image/png", quality) {
	return new Promise((ok, bad) => c.toBlob((b) => b ? ok(b) : bad(/* @__PURE__ */ new Error("Ảnh quá lớn để tạo")), type, quality));
}
/** Object URL tạm (xem trước/lớp phủ): người gọi phải gọi URL.revokeObjectURL khi xong. */
async function canvasToTempUrl(c, type = "image/png", quality) {
	const b = await canvasToBlob(c, type, quality);
	c.width = 0;
	return URL.createObjectURL(b);
}
/** Object URL của trang: đã đăng ký với kho tài liệu, nên lưu/thu hồi cùng tài liệu. */
async function canvasToPageUrl(c, type = "image/jpeg", quality) {
	const b = await canvasToBlob(c, type, quality);
	c.width = 0;
	return adoptBlob(b);
}
/** Thu hồi object URL tạm; bỏ qua chuỗi không phải blob:. */
function revokeTemp(u) {
	if (u && u.startsWith("blob:")) URL.revokeObjectURL(u);
}
var NUMBER_STYLES = [
	"Trang n/N",
	"n/N",
	"n"
];
var pad = (n) => String(n).padStart(2, "0");
var viDate = (d) => `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
/** Fill tokens: {trang} page, {tong} total, {ten} doc name, {ngay} dd/mm/yyyy. */
function fillMarkText(tpl, page, total, name, date) {
	return tpl.replace(/\{trang\}/gi, String(page)).replace(/\{tong\}/gi, String(total)).replace(/\{ten\}/gi, name).replace(/\{ngay\}/gi, viDate(date)).trim();
}
function pageNumberText(style, page, total) {
	if (style === "n") return String(page);
	if (style === "n/N") return `${page}/${total}`;
	return `Trang ${page}/${total}`;
}
/** Extra margin (mm) reserved at top / bottom so the image never covers the text. */
function markMargins(m) {
	return {
		top: m.header?.trim() ? 9 : 0,
		bottom: m.footer?.trim() || m.numbers ? 9 : 0
	};
}
var hasMarks = (m) => !!(m.numbers || m.header?.trim() || m.footer?.trim());
/** BL-08 (RS-17): mật khẩu chủ PDF ngẫu nhiên 128 bit (trước: mật khẩu mở + "#owner" → ai biết mật khẩu mở đều gỡ được giới hạn quyền). */
function randomOwnerPassword() {
	return Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(16)), (b) => b.toString(16).padStart(2, "0")).join("");
}
/** B15: nhường luồng giao diện giữa các trang PDF để màn hình không treo (scheduler.yield, dự phòng setTimeout 0). */
function yieldUi() {
	const s = globalThis.scheduler;
	return s?.yield ? s.yield() : new Promise((r) => setTimeout(r, 0));
}
/** B15: ném lỗi hủy khi người dùng bấm Hủy giữa chừng. */
function throwIfAborted(signal) {
	if (signal?.aborted) throw new DOMException("Đã hủy xuất PDF", "AbortError");
}
function download(blob, name) {
	const a = document.createElement("a");
	a.href = URL.createObjectURL(blob);
	a.download = name;
	document.body.appendChild(a);
	a.click();
	a.remove();
	setTimeout(() => URL.revokeObjectURL(a.href), 4e3);
}
async function dataUrlToBlob(src) {
	return (await fetch(src)).blob();
}
var safeName = (s) => s.replace(/[\\/:*?"<>|]+/g, "-").trim() || "ghi-nhanh";
/** Chia sẻ qua bảng chia sẻ của máy (Zalo, Messenger, thư…); không được thì lưu về máy và BÁO RÕ (TF-01). */
async function shareOrDownload(blob, name) {
	const { shareOrSave } = await import("./share-C6NDb_Ds.mjs").then((n) => n.r);
	return shareOrSave(blob, name, download);
}
var PDF_SIZES = {
	small: {
		label: "Nhỏ",
		maxSide: 1754,
		q: .75,
		bwDpi: 200
	},
	balanced: {
		label: "Chuẩn",
		maxSide: 2339,
		q: .82,
		bwDpi: 300
	},
	high: {
		label: "Cao",
		maxSide: 3508,
		q: .9,
		bwDpi: 300
	}
};
/** CS-22: chất lượng JPEG lớp nền MRC theo mức xuất. */
var MRC_Q = {
	small: .45,
	balanced: .55,
	high: .65
};
var pageKindOf = (filter) => filter === "mono" ? "bw" : filter === "gray" ? "gray" : "color";
/** B1: chỉ nén lại khi cần thu nhỏ hoặc đổi định dạng – ảnh JPEG đã đúng cỡ đi thẳng vào PDF (tránh nén chồng). */
function needsReencode(w, h, size, bw, isJpeg) {
	if (bw || !isJpeg) return true;
	return Math.max(w, h) > PDF_SIZES[size].maxSide;
}
/** Downscale + re-encode a page; bw = adaptive black & white (great for text, tiny files). */
async function compressPage(src, size, bw = false, crop = true) {
	const { maxSide, q } = PDF_SIZES[size];
	const { compressInWorker } = await import("./compress-pool-D9_WWDTt.mjs");
	const wp = compressInWorker(src, maxSide, q, bw, src.startsWith("data:image/jpeg"), crop);
	if (wp) try {
		return await wp;
	} catch {}
	if (!crop && !bw) {
		const blob = await (await fetch(src)).blob();
		const { imageSize } = await import("./pdf-page-11Gerqi0.mjs");
		const head = blob.type === "image/jpeg" || src.startsWith("data:image/jpeg") ? imageSize(new Uint8Array(await blob.slice(0, 65536).arrayBuffer())) : null;
		if (head && head.fmt === "JPEG" && !head.exif && Math.max(head.w, head.h) <= maxSide) {
			const { fileToDataUrl } = await import("./image-DFWRNlNd.mjs").then((n) => n.D).then((n) => n.f);
			return {
				src: src.startsWith("data:") ? src : await fileToDataUrl(blob),
				w: head.w,
				h: head.h,
				fmt: "JPEG",
				ox: 0,
				oy: 0,
				scale: 1
			};
		}
	}
	const img = await loadImg(src);
	const s = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
	const W = Math.round(img.naturalWidth * s), H = Math.round(img.naturalHeight * s);
	const c = document.createElement("canvas");
	c.width = W;
	c.height = H;
	const x = c.getContext("2d");
	x.imageSmoothingEnabled = true;
	x.imageSmoothingQuality = "high";
	x.fillStyle = "#fff";
	x.fillRect(0, 0, W, H);
	x.drawImage(img, 0, 0, W, H);
	const p = x.getImageData(0, 0, W, H).data;
	const lum = new Uint8Array(W * H);
	for (let i = 0; i < W * H; i++) lum[i] = (p[i * 4] * 299 + p[i * 4 + 1] * 587 + p[i * 4 + 2] * 114) / 1e3;
	const { contentBox, encodePng1bit, bytesToDataUrl } = await import("./content-crop-PCcOoYJZ.mjs");
	let box = crop ? contentBox(lum, W, H) : {
		x: 0,
		y: 0,
		w: W,
		h: H
	};
	if (box.w * box.h < W * H * .25) box = {
		x: 0,
		y: 0,
		w: W,
		h: H
	};
	const map = {
		ox: box.x,
		oy: box.y,
		scale: s
	};
	if (box.w === W && box.h === H && src.startsWith("data:") && !needsReencode(img.naturalWidth, img.naturalHeight, size, bw, src.startsWith("data:image/jpeg"))) {
		c.width = 0;
		return {
			src,
			w: W,
			h: H,
			fmt: "JPEG",
			...map
		};
	}
	if (bw) {
		const g = new Float64Array((W + 1) * (H + 1));
		for (let y = 0; y < H; y++) {
			let row = 0;
			for (let xx = 0; xx < W; xx++) {
				row += lum[y * W + xx];
				g[(y + 1) * (W + 1) + xx + 1] = g[y * (W + 1) + xx + 1] + row;
			}
		}
		const r = Math.max(8, Math.round(Math.min(W, H) / 40));
		const bin = new Uint8Array(box.w * box.h);
		for (let y = box.y; y < box.y + box.h; y++) for (let xx = box.x; xx < box.x + box.w; xx++) {
			const x0 = Math.max(0, xx - r), x1 = Math.min(W, xx + r + 1), y0 = Math.max(0, y - r), y1 = Math.min(H, y + r + 1);
			const mean = (g[y1 * (W + 1) + x1] - g[y0 * (W + 1) + x1] - g[y1 * (W + 1) + x0] + g[y0 * (W + 1) + x0]) / ((x1 - x0) * (y1 - y0));
			bin[(y - box.y) * box.w + xx - box.x] = lum[y * W + xx] < mean * .88 ? 0 : 255;
		}
		c.width = 0;
		return {
			src: bytesToDataUrl(encodePng1bit(bin, box.w, box.h)),
			w: box.w,
			h: box.h,
			fmt: "PNG",
			...map
		};
	}
	let out;
	if (box.w !== W || box.h !== H) {
		const cc = document.createElement("canvas");
		cc.width = box.w;
		cc.height = box.h;
		cc.getContext("2d").drawImage(c, box.x, box.y, box.w, box.h, 0, 0, box.w, box.h);
		out = cc.toDataURL("image/jpeg", q);
		cc.width = 0;
	} else out = c.toDataURL("image/jpeg", q);
	c.width = 0;
	return {
		src: out,
		w: box.w,
		h: box.h,
		fmt: "JPEG",
		...map
	};
}
/** CS-21: số trang xuất được dựng lại từ ảnh gốc (re), thử lệch cỡ (miss), lỗi (err) — kiểm chứng "nén một lần". */
var exportStats = {
	re: 0,
	miss: 0,
	err: 0
};
if (typeof globalThis !== "undefined") globalThis.__cs21 = exportStats;
var headOf = async (src) => {
	const { imageSize } = await import("./pdf-page-11Gerqi0.mjs");
	return imageSize(new Uint8Array(await (await (await fetch(src)).blob()).slice(0, 65536).arrayBuffer()));
};
/**
* CS-20/21 (QP-04): nén MỘT lần. Ảnh trang đã lưu là JPEG q0,92 → dựng lại từ ảnh gốc + tham số ở ĐÚNG cỡ ảnh trang (cùng chuỗi dựng
* nên cùng điểm ảnh), nén với chất lượng `q` (= mức xuất, hoặc 1 = gần không mất mát cho bước xám / 4:4:4 phía sau).
* KHÔNG dựng thẳng ở cỡ nhỏ hơn ảnh trang (đo P33: mất nét dấu "năm" → "nàm"). Không dựng lại được → ảnh trang.
*/
async function fromOrig(src, so, q) {
	if (!so || !so.orig || so.orig === src || src === "=") return src;
	const head = await headOf(src);
	if (!head || head.fmt !== "JPEG") return src;
	try {
		const { renderExport, TARGET_LONG, targetLong } = await import("./image-DFWRNlNd.mjs").then((n) => n.D).then((n) => n.f);
		const { getSettings } = await import("./settings-DDlMLZCe.mjs").then((n) => n.s).then((n) => n.s);
		for (const max of [.../* @__PURE__ */ new Set([
			targetLong(getSettings().quality),
			TARGET_LONG.high,
			TARGET_LONG.normal,
			Math.max(head.w, head.h)
		])]) {
			const out = await renderExport(so.orig, so.edit, max, q);
			const re = await headOf(out);
			if (re && re.w === head.w && re.h === head.h) {
				exportStats.re++;
				return out;
			}
			exportStats.miss++;
		}
		return src;
	} catch (e) {
		exportStats.err++;
		console.warn("export re-render skipped", e);
		return src;
	}
}
/** CS-20/21: một trang PDF theo loại trang + mức xuất. */
async function exportPage(s, so, kind, size, fit, adaptive, mrc = false) {
	const { maxSide, q, bwDpi } = PDF_SIZES[size];
	const pool = await import("./compress-pool-D9_WWDTt.mjs");
	const head = await headOf(s).catch(() => null);
	const long = head ? Math.max(head.w, head.h) : 0;
	if (kind === "bw" && head) {
		const { fitFormat } = await import("./pdf-page-11Gerqi0.mjs");
		const k = Math.min(2.5, Math.max(.5, bwDpi / fitFormat(head.w, head.h).dpi));
		const wp = pool.pdfPageInWorker(s, "bw", q, maxSide, k, adaptive);
		if (wp) try {
			return await wp;
		} catch {}
		return compressPage(s, size, true, !fit);
	}
	if (mrc && fit && head) {
		const wp = pool.pdfPageInWorker(long <= maxSide ? await fromOrig(s, so, 1) : s, "mrc", MRC_Q[size], maxSide);
		if (wp) try {
			return await wp;
		} catch {}
	}
	if (kind === "gray" && head) {
		const wp = pool.pdfPageInWorker(long <= maxSide ? await fromOrig(s, so, 1) : s, "gray", q, maxSide);
		if (wp) try {
			return await wp;
		} catch {}
	}
	if (kind === "color" && fit && head && q >= .9) {
		if (await (pool.inkShareInWorker(s) ?? Promise.resolve(0)).catch(() => 0) > .002) {
			const wp = pool.pdfPageInWorker(await fromOrig(s, so, 1), "c444", q, maxSide);
			if (wp) try {
				return await wp;
			} catch {}
		}
		return compressPage(s, size, false, false);
	}
	if (fit && head && q < .9) return compressPage(long <= maxSide ? await fromOrig(s, so, q) : s, size, false, false);
	return compressPage(s, size, kind === "bw", !fit);
}
/** CS-21: định dạng ảnh "G4" cho jsPDF — gói packG4 (g4.ts) → luồng CCITTFaxDecode K = −1, DeviceGray 1 bit. */
var g4Ready = false;
function registerG4(api) {
	if (g4Ready) return;
	g4Ready = true;
	api["processG4M"] = function(data, index, alias) {
		const v = new DataView(data.buffer, data.byteOffset, data.byteLength), w = v.getUint32(4), h = v.getUint32(8);
		return {
			data: this.__addimage__.arrayBufferToBinaryString(data.subarray(12)),
			width: w,
			height: h,
			colorSpace: "DeviceGray",
			bitsPerComponent: 1,
			transparency: [1],
			filter: "CCITTFaxDecode",
			decodeParameters: `/K -1 /Columns ${w} /Rows ${h} /BlackIs1 false`,
			index,
			alias
		};
	};
	api["processG4"] = function(data, index, alias) {
		const v = new DataView(data.buffer, data.byteOffset, data.byteLength), w = v.getUint32(4), h = v.getUint32(8);
		return {
			data: this.__addimage__.arrayBufferToBinaryString(data.subarray(12)),
			width: w,
			height: h,
			colorSpace: "DeviceGray",
			bitsPerComponent: 1,
			filter: "CCITTFaxDecode",
			decodeParameters: `/K -1 /Columns ${w} /Rows ${h} /BlackIs1 false`,
			index,
			alias
		};
	};
}
async function imagesToPdf(srcs, opts = {}) {
	const { jsPDF } = await import("../_libs/jspdf.mjs").then((n) => n.t);
	const { fitFormat, pdfProperties } = await import("./pdf-page-11Gerqi0.mjs");
	const paper = opts.paper ?? "fit", fit = paper === "fit", size = opts.size ?? "balanced", bw = !!opts.bw;
	const enc = opts.password ? { encryption: {
		userPassword: opts.password,
		ownerPassword: randomOwnerPassword(),
		userPermissions: ["print", "copy"]
	} } : {};
	let pdf = null;
	const m = fit ? 0 : 6;
	const marks = opts.marks ?? {}, mm = markMargins(marks), date = /* @__PURE__ */ new Date();
	const dpis = [];
	const { orderedPool, pdfLanes } = await import("./ordered-pool-BPbz5dnO.mjs");
	let i = -1;
	registerG4(jsPDF.API);
	const build = (s, k) => {
		const kind = opts.kinds?.[k] ?? "color";
		return exportPage(s, opts.sources?.[k], bw ? "bw" : kind, size, fit, kind !== "bw", !!opts.mrc && !bw);
	};
	for await (const page of orderedPool(srcs, opts.lanes ?? pdfLanes(), build)) {
		throwIfAborted(opts.signal);
		i++;
		let PW, PH, x, y, w, h, r;
		if (fit) {
			const f = fitFormat(page.w, page.h);
			PW = f.wMm;
			PH = f.hMm + mm.top + mm.bottom;
			w = f.wMm;
			h = f.hMm;
			x = 0;
			y = mm.top;
			r = f.wMm / page.w;
			const fmt = [PW, PH], orient = PW > PH ? "l" : "p";
			if (!pdf) pdf = new jsPDF({
				unit: "mm",
				format: fmt,
				orientation: orient,
				compress: true,
				...enc
			});
			else pdf.addPage(fmt, orient);
		} else {
			if (!pdf) pdf = new jsPDF({
				unit: "mm",
				format: paper,
				compress: true,
				...enc
			});
			else pdf.addPage(paper);
			PW = pdf.internal.pageSize.getWidth();
			PH = pdf.internal.pageSize.getHeight();
			const aw = PW - m * 2, ah = PH - m * 2 - mm.top - mm.bottom;
			r = Math.min(aw / page.w, ah / page.h);
			w = page.w * r;
			h = page.h * r;
			x = (PW - w) / 2;
			y = m + mm.top + (ah - h) / 2;
		}
		dpis.push(Math.round(25.4 / r));
		if (i === 0 && hasMarks(marks) && !pdf.getFontList()["DejaVu"]) {
			pdf.addFileToVFS("DejaVuSans.ttf", await loadFont());
			pdf.addFont("DejaVuSans.ttf", "DejaVu", "normal", void 0, "Identity-H");
		}
		if (page.fmt === "G4" && page.data) pdf.addImage(page.data, "G4", x, y, w, h, void 0, "NONE");
		else if (page.fmt === "MRC" && page.data) {
			pdf.addImage(page.src, "JPEG", x, y, w, h, void 0, "FAST");
			pdf.addImage(page.data, "G4M", x, y, w, h, void 0, "NONE");
		} else pdf.addImage(page.src, page.fmt, x, y, w, h, void 0, "FAST");
		if (opts.searchable) await addTextLayer(pdf, srcs[i], x, y, r, {
			ox: page.ox ?? 0,
			oy: page.oy ?? 0,
			scale: page.scale ?? 1,
			w: page.w,
			h: page.h
		});
		if (opts.watermark) {
			pdf.saveGraphicsState();
			pdf.setGState(new pdf.GState({ opacity: .18 }));
			pdf.setTextColor(0, 140, 120);
			pdf.setFontSize(46 * Math.min(1, PW / 180));
			pdf.text(opts.watermark, PW / 2, PH / 2, {
				align: "center",
				angle: 35
			});
			pdf.restoreGraphicsState();
		}
		if (hasMarks(marks)) {
			const mk = Math.max(m, 2);
			pdf.setFont("DejaVu", "normal");
			pdf.setFontSize(9);
			pdf.setTextColor(90, 90, 90);
			const name = opts.name ?? "";
			if (marks.header?.trim()) pdf.text(fillMarkText(marks.header, i + 1, srcs.length, name, date), PW / 2, mk + 4, {
				align: "center",
				maxWidth: PW - mk * 2
			});
			const foot = marks.footer?.trim() ? fillMarkText(marks.footer, i + 1, srcs.length, name, date) : "";
			const num = marks.numbers ? pageNumberText(marks.numberStyle, i + 1, srcs.length) : "";
			if (foot) pdf.text(foot, num ? mk + 2 : PW / 2, PH - mk - 1, {
				align: num ? "left" : "center",
				maxWidth: PW - mk * 2 - (num ? 30 : 0)
			});
			if (num) pdf.text(num, foot ? PW - mk - 2 : PW / 2, PH - mk - 1, { align: foot ? "right" : "center" });
			pdf.setTextColor(0, 0, 0);
		}
		await yieldUi();
	}
	throwIfAborted(opts.signal);
	if (!pdf) pdf = new jsPDF({
		unit: "mm",
		format: fit ? "a4" : paper,
		compress: true,
		...enc
	});
	pdf.setProperties(pdfProperties(opts.name, dpis, paper));
	return pdf.output("blob");
}
/** fromOrig = false khi ảnh trang đã bị đổi so với bản lưu (vd. đóng hình mờ CCCD) → không dựng lại từ ảnh gốc. */
async function docToPdf(doc0, opts = {}) {
	const [doc] = await readyDocs([doc0]);
	const { fromOrig: useOrig = true, ...rest } = opts;
	const sources = useOrig ? doc.pages.map((p) => p.orig ? {
		orig: p.orig,
		edit: p.edit
	} : void 0) : void 0;
	return imagesToPdf(doc.pages.map((p) => p.src), {
		searchable: true,
		name: doc.name,
		sources,
		kinds: doc.pages.map((p) => pageKindOf(p.edit?.filter)),
		...rest
	});
}
var fontB64 = null;
function loadFont() {
	fontB64 ??= fetch("/fonts/DejaVuSans.ttf").then((r) => r.arrayBuffer()).then((b) => {
		const u = new Uint8Array(b);
		let s = "";
		for (let i = 0; i < u.length; i += 32768) s += String.fromCharCode(...u.subarray(i, i + 32768));
		return btoa(s);
	});
	return fontB64;
}
function textLayerOps(lines, x0, y0, r, map = {
	ox: 0,
	oy: 0,
	scale: 1
}) {
	const ops = [];
	const { ox, oy, scale: k } = map;
	for (const ln of lines) {
		const t = ln.text.trim();
		if (!t) continue;
		const lx = ln.bbox.x0 * k - ox, ly = ln.bbox.y0 * k - oy, lx1 = ln.bbox.x1 * k - ox, ly1 = ln.bbox.y1 * k - oy;
		if (lx1 <= 0 || ly1 <= 0 || map.w !== void 0 && lx >= map.w || map.h !== void 0 && ly >= map.h) continue;
		const hMm = (ly1 - ly) * r;
		const size = Math.max(2, hMm / .3528 * .85);
		ops.push({
			text: t,
			x: x0 + lx * r,
			y: y0 + ly1 * r - hMm * .2,
			size,
			charSpace: 0
		});
	}
	return ops;
}
/** Ghi các dòng chữ vô hình vào PDF (phông DejaVu nhúng sẵn → tìm/sao chép được tiếng Việt ở mọi trình đọc). */
async function writeTextLayer(pdf, ops) {
	if (!ops.length) return;
	if (!pdf.getFontList()["DejaVu"]) {
		pdf.addFileToVFS("DejaVuSans.ttf", await loadFont());
		pdf.addFont("DejaVuSans.ttf", "DejaVu", "normal", void 0, "Identity-H");
	}
	pdf.setFont("DejaVu", "normal");
	for (const op of ops) {
		pdf.setFontSize(op.size);
		pdf.text(op.text, op.x, op.y, {
			renderingMode: "invisible",
			charSpace: op.charSpace
		});
	}
}
async function addTextLayer(pdf, src, x0, y0, r, map) {
	try {
		const { sharedOcr, currentLang } = await import("./ocr-worker-DbwCMwXG.mjs").then((n) => n.t).then((n) => n.t);
		const lines = ((await sharedOcr().run(await currentLang(), src, { out: { blocks: true } })).data.blocks ?? []).flatMap((b) => b.paragraphs.flatMap((p) => p.lines));
		if (!lines.length) return;
		await writeTextLayer(pdf, textLayerOps(lines, x0, y0, r, map));
	} catch (e) {
		console.warn("text layer skipped", e);
	}
}
async function pdfjs() {
	const lib = await import("../_libs/pdfjs-dist.mjs").then((n) => n.t);
	const worker = await import("./pdf.worker.min-BFJhmjfM.mjs");
	lib.GlobalWorkerOptions.workerSrc = worker.default;
	return lib;
}
async function pdfToImages(file, scale = 2, q = .88, withAnnotations = true) {
	const task = (await pdfjs()).getDocument({ data: new Uint8Array(await file.arrayBuffer()) });
	try {
		const pdf = await task.promise;
		const out = [];
		for (let i = 1; i <= pdf.numPages; i++) {
			const page = await pdf.getPage(i);
			const vp = page.getViewport({ scale });
			const c = document.createElement("canvas");
			c.width = vp.width;
			c.height = vp.height;
			await page.render({
				canvas: c,
				canvasContext: c.getContext("2d"),
				viewport: vp,
				...withAnnotations ? {} : { annotationMode: 0 }
			}).promise;
			page.cleanup();
			out.push(await canvasToPageUrl(c, "image/jpeg", q));
		}
		return out;
	} finally {
		await task.destroy();
	}
}
/** BL-06 (RS-26): KHÔNG dùng ignoreEncryption — pdf-lib nạp PDF mã hoá mà không giải mã, gộp/tách/xoay ra tệp hỏng hoặc trang trắng, im lặng. */
async function loadPlainPdf(file) {
	const lib = await import("../_libs/pdf-lib+tslib.mjs").then((n) => n.t);
	try {
		return {
			doc: await lib.PDFDocument.load(await file.arrayBuffer()),
			lib
		};
	} catch (e) {
		if (e instanceof lib.EncryptedPDFError || /encrypt/i.test(String(e?.message ?? e))) throw Object.assign(new Error("PDF này có mật khẩu hoặc được mã hoá — chưa sửa trực tiếp được. Hãy mở khoá PDF trước, hoặc dùng công cụ “PDF → ảnh”.", { cause: e }), { name: "EncryptedPdf" });
		throw e;
	}
}
async function mergePdfs(files) {
	const { PDFDocument } = await import("../_libs/pdf-lib+tslib.mjs").then((n) => n.t);
	const out = await PDFDocument.create();
	for (const f of files) {
		const { doc: src } = await loadPlainPdf(f);
		(await out.copyPages(src, src.getPageIndices())).forEach((p) => out.addPage(p));
	}
	return new Blob([await out.save()], { type: "application/pdf" });
}
async function splitPdf(file) {
	const { PDFDocument } = await import("../_libs/pdf-lib+tslib.mjs").then((n) => n.t);
	const { doc: src } = await loadPlainPdf(file);
	const parts = [];
	for (const i of src.getPageIndices()) {
		const d = await PDFDocument.create();
		const [p] = await d.copyPages(src, [i]);
		d.addPage(p);
		parts.push(new Blob([await d.save()], { type: "application/pdf" }));
	}
	return parts;
}
var pdfBlob = (b) => new Blob([b], { type: "application/pdf" });
async function loadPdf(file) {
	const { doc, lib } = await loadPlainPdf(file);
	return {
		doc,
		PDFDocument: lib.PDFDocument,
		degrees: lib.degrees
	};
}
async function pdfPageCount(file) {
	return (await loadPdf(file)).doc.getPageCount();
}
/** Rotate pages (1-based list, empty = all) by a multiple of 90°. */
async function rotatePdf(file, angle, pages = []) {
	const { doc, degrees } = await loadPdf(file);
	doc.getPages().forEach((p, i) => {
		if (!pages.length || pages.includes(i + 1)) p.setRotation(degrees((p.getRotation().angle + angle) % 360));
	});
	return pdfBlob(await doc.save());
}
/** Build a new PDF with the given 1-based page order (omitted pages are removed). */
async function reorderPdf(file, order) {
	const { doc, PDFDocument } = await loadPdf(file);
	const out = await PDFDocument.create();
	for (const p of await out.copyPages(doc, order.map((n) => n - 1))) out.addPage(p);
	return pdfBlob(await out.save());
}
/** Stamp a text watermark (rendered to PNG so Vietnamese accents work) on every page. */
async function watermarkPdf(file, text) {
	const { doc } = await loadPdf(file);
	const c = document.createElement("canvas");
	const ctx = c.getContext("2d");
	ctx.font = "bold 96px sans-serif";
	c.width = Math.ceil(ctx.measureText(text).width) + 40;
	c.height = 130;
	ctx.font = "bold 96px sans-serif";
	ctx.fillStyle = "rgba(0,140,120,0.22)";
	ctx.textBaseline = "middle";
	ctx.fillText(text, 20, 65);
	const png = await doc.embedPng(await (await canvasToBlob(c, "image/png")).arrayBuffer());
	const { degrees } = await import("../_libs/pdf-lib+tslib.mjs").then((n) => n.t);
	for (const p of doc.getPages()) {
		const { width, height } = p.getSize();
		const w = width * .8, h = w * c.height / c.width;
		const a = Math.atan2(height, width);
		p.drawImage(png, {
			x: width / 2 - w / 2 * Math.cos(a) + h / 2 * Math.sin(a),
			y: height / 2 - w / 2 * Math.sin(a) - h / 2 * Math.cos(a),
			width: w,
			height: h,
			rotate: degrees(a * 180 / Math.PI)
		});
	}
	return pdfBlob(await doc.save());
}
/** Parse "1-3, 5, 7" into page numbers within 1..max (keeps order and repeats). */
function parsePages(s, max) {
	const out = [];
	for (const part of s.split(/[,;\s]+/).filter(Boolean)) {
		const m = part.match(/^(\d+)(?:-(\d+))?$/);
		if (!m) continue;
		const a0 = +m[1], b0 = m[2] ? +m[2] : a0;
		if (a0 < 1 && b0 < 1 || a0 > max && b0 > max) continue;
		const clamp = (v) => Math.min(max, Math.max(1, v));
		const a = clamp(a0), b = clamp(b0), step = a <= b ? 1 : -1;
		for (let i = a; step > 0 ? i <= b : i >= b; i += step) out.push(i);
	}
	return out;
}
//#endregion
export { splitPdf as C, shareOrDownload as S, readyDocs as _, compressPage as a, rotatePdf as b, download as c, mergePdfs as d, pageNumberText as f, pdfjs as g, pdfToImages as h, canvasToTempUrl as i, files_CTF11Arr_exports as l, pdfPageCount as m, PDF_SIZES as n, dataUrlToBlob as o, parsePages as p, canvasToPageUrl as r, docToPdf as s, NUMBER_STYLES as t, imagesToPdf as u, reorderPdf as v, watermarkPdf as w, safeName as x, revokeTemp as y };
