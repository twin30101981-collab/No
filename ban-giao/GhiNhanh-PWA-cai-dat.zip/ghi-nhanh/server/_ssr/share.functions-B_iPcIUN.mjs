import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CwccI41b.mjs";
import { t as createServerRpc } from "./createServerRpc-CxD4EZ5P.mjs";
import { i as stringType, n as enumType, r as objectType } from "../_libs/zod.mjs";
import { a as expiresAt, c as newToken, o as hashPassword, r as checkPassword, t as EXPIRY_OPTIONS } from "./share-links-s-_jx_4k.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/share.functions-B_iPcIUN.js
var createShareLink_createServerFn_handler = createServerRpc({
	id: "f631e086e864b55a802d3846676e9c76d6b0d78df3ae21524dfa509bbf1a00b3",
	name: "createShareLink",
	filename: "src/lib/share.functions.ts"
}, (opts) => createShareLink.__executeServer(opts));
var createShareLink = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	localId: stringType().min(1).max(200),
	expiry: enumType(EXPIRY_OPTIONS.map((o) => o.id)),
	password: stringType().max(64).default("")
}).parse(d)).handler(createShareLink_createServerFn_handler, async ({ data, context }) => {
	const bad = checkPassword(data.password);
	if (bad) return {
		ok: false,
		message: bad
	};
	const { data: doc } = await context.supabase.from("documents").select("id").eq("local_id", data.localId).maybeSingle();
	if (!doc) return {
		ok: false,
		message: "Tài liệu chưa có trên mây. Hãy đồng bộ rồi thử lại."
	};
	const row = {
		user_id: context.userId,
		document_id: doc.id,
		token: newToken(),
		expires_at: expiresAt(data.expiry, Date.now()),
		password_hash: data.password ? await hashPassword(data.password) : null
	};
	const { error } = await context.supabase.from("share_links").insert(row);
	if (error) return {
		ok: false,
		message: "Chưa tạo được liên kết, thử lại sau."
	};
	return {
		ok: true,
		token: row.token,
		expiresAt: row.expires_at,
		hasPassword: !!row.password_hash
	};
});
var listShareLinks_createServerFn_handler = createServerRpc({
	id: "041fdf35b19bf4c65096476bcea235fc14bc14efac887da12e7c9bb40c9cd5f8",
	name: "listShareLinks",
	filename: "src/lib/share.functions.ts"
}, (opts) => listShareLinks.__executeServer(opts));
var listShareLinks = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ localId: stringType().min(1).max(200) }).parse(d)).handler(listShareLinks_createServerFn_handler, async ({ data, context }) => {
	const { data: doc } = await context.supabase.from("documents").select("id").eq("local_id", data.localId).maybeSingle();
	if (!doc) return [];
	const { data: rows } = await context.supabase.from("share_links").select("id, token, expires_at, revoked_at, password_hash, created_at").eq("document_id", doc.id).order("created_at", { ascending: false });
	return (rows ?? []).map(({ password_hash, ...r }) => ({
		...r,
		hasPassword: !!password_hash
	}));
});
//#endregion
export { createShareLink_createServerFn_handler, listShareLinks_createServerFn_handler };
