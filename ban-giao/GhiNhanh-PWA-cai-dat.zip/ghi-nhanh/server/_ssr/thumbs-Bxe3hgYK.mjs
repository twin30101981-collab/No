import { o as __toESM } from "../_runtime.mjs";
import { D as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as fpOf } from "./disk-pack-ZdDKsocx.mjs";
import { c as getDocs, d as mutateDoc } from "./db-CclUQaLE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/thumbs-Bxe3hgYK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/** Ảnh thu nhỏ (~200px) cho danh sách & dải trang: giải mã ảnh gốc nhiều MB làm cuộn rất giật.
*  B14: mọi trang đều có ảnh thu nhỏ riêng (không chỉ trang đầu) — mở tài liệu nhiều trang
*  không giải mã ảnh lớn cho dải trang/bảng sắp xếp. */
var key = (p) => fpOf(p.src);
var mem = /* @__PURE__ */ new Map();
var listeners = /* @__PURE__ */ new Set();
var queue = [];
var running = false;
var thumbValid = (p) => !!p.thumb && p.thumbKey === key(p);
/** Khoá hàng đợi cho một trang của một tài liệu. */
var thumbTaskKey = (docId, i) => `${docId}:${i}`;
async function makeThumb(src, max = 200) {
	const blob = await (await fetch(src)).blob();
	const bmp = await createImageBitmap(blob);
	const s = Math.min(1, max / Math.max(bmp.width, bmp.height));
	const c = document.createElement("canvas");
	c.width = Math.round(bmp.width * s);
	c.height = Math.round(bmp.height * s);
	c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
	bmp.close();
	const url = c.toDataURL("image/jpeg", .7);
	c.width = 0;
	return url;
}
var idle = () => new Promise((r) => "requestIdleCallback" in window ? requestIdleCallback(() => r(), { timeout: 500 }) : setTimeout(r, 16));
async function run() {
	if (running) return;
	running = true;
	while (queue.length) {
		const [id, idx] = queue.shift().split(":");
		const i = Number(idx);
		const doc = getDocs().find((d) => d.id === id);
		const p = doc?.pages[i];
		if (!doc || !p || thumbValid(p)) continue;
		await idle();
		try {
			const t = await makeThumb(p.src);
			mem.set(key(p), t);
			listeners.forEach((l) => l());
			await mutateDoc(id, (fresh) => {
				const fp = fresh.pages[i];
				return fp && key(fp) === key(p) ? {
					...fresh,
					pages: fresh.pages.map((x, k) => k === i ? {
						...x,
						thumb: t,
						thumbKey: key(x)
					} : x)
				} : null;
			});
		} catch {}
	}
	running = false;
}
/** Trả ảnh thu nhỏ của trang i; nếu chưa có thì xếp hàng tạo lúc máy rảnh. */
function usePageThumb(doc, i) {
	const p = doc.pages[i];
	const [, tick] = (0, import_react.useState)(0);
	const ready = p ? thumbValid(p) ? p.thumb : mem.get(key(p)) : void 0;
	(0, import_react.useEffect)(() => {
		if (!p || ready) return;
		const l = () => tick((n) => n + 1);
		listeners.add(l);
		const t = thumbTaskKey(doc.id, i);
		if (!queue.includes(t)) queue.push(t);
		run();
		return () => {
			listeners.delete(l);
		};
	}, [
		doc.id,
		i,
		p,
		ready
	]);
	return ready;
}
/** Trả ảnh thu nhỏ của trang đầu; nếu chưa có thì xếp hàng tạo lúc máy rảnh. */
function useThumb(doc) {
	return usePageThumb(doc, 0);
}
//#endregion
export { usePageThumb as n, useThumb as r, makeThumb as t };
