import { o as __toESM } from "../_runtime.mjs";
import { D as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as safeSet } from "./safe-storage-DnXnZPA0.mjs";
import { E as uid, f as mutateDocs, o as docText } from "./db-CclUQaLE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/library-BIMZUn1d.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var ROOT_FOLDER = "Chung";
var emptyFilter = () => ({
	q: "",
	folder: null,
	tags: [],
	kind: null,
	from: "",
	to: "",
	ocr: "any"
});
var KEY = "ghi-nhanh-library";
var EMPTY = {
	folders: [ROOT_FOLDER],
	tags: [],
	quick: []
};
var state = EMPTY;
var loaded = false;
var subs = /* @__PURE__ */ new Set();
function load() {
	if (loaded || typeof window === "undefined") return;
	loaded = true;
	try {
		const raw = localStorage.getItem(KEY);
		if (raw) state = {
			...EMPTY,
			...JSON.parse(raw)
		};
	} catch {}
}
function getLibrary() {
	load();
	return state;
}
function setLibrary(next) {
	state = {
		...next,
		folders: [.../* @__PURE__ */ new Set([ROOT_FOLDER, ...next.folders])].sort((a, b) => a.localeCompare(b, "vi"))
	};
	safeSet(KEY, JSON.stringify(state));
	subs.forEach((f) => f());
}
var update = (fn) => setLibrary({
	...getLibrary(),
	...fn(getLibrary())
});
function useLibrary() {
	return (0, import_react.useSyncExternalStore)((cb) => {
		subs.add(cb);
		return () => subs.delete(cb);
	}, getLibrary, () => EMPTY);
}
var parentOf = (p) => p.includes("/") ? p.slice(0, p.lastIndexOf("/")) : null;
var baseName = (p) => p.slice(p.lastIndexOf("/") + 1);
var inFolder = (docFolder, folder) => docFolder === folder || docFolder.startsWith(folder + "/");
/** All folder paths known from the library and documents, including implied parents. */
function allFolders(lib, docs) {
	const set = /* @__PURE__ */ new Set([
		ROOT_FOLDER,
		...lib.folders,
		...docs.map((d) => d.folder)
	]);
	for (const f of [...set]) {
		let p = parentOf(f);
		while (p) {
			set.add(p);
			p = parentOf(p);
		}
	}
	return [...set].sort((a, b) => a.localeCompare(b, "vi"));
}
var childFolders = (all, parent) => all.filter((f) => parentOf(f) === parent);
function createFolder(path) {
	update((l) => ({ folders: [...l.folders, path] }));
}
/** BL-05a: `_docs` chỉ giữ chữ ký cũ — tài liệu được chọn và sửa trên bản mới nhất (mutateDocs). */
async function renameFolder(from, to, _docs) {
	const swap = (p) => inFolder(p, from) ? to + p.slice(from.length) : p;
	update((l) => ({
		folders: l.folders.map(swap),
		quick: l.quick.map((q) => ({
			...q,
			filter: {
				...q.filter,
				folder: q.filter.folder && swap(q.filter.folder)
			}
		}))
	}));
	await mutateDocs((d) => inFolder(d.folder, from), (d) => ({
		...d,
		folder: swap(d.folder)
	}), true);
}
/** Deletes a folder and its subfolders; their documents move to the parent folder. */
async function deleteFolder(path, _docs) {
	const target = parentOf(path) ?? "Chung";
	update((l) => ({ folders: l.folders.filter((f) => !inFolder(f, path)) }));
	await mutateDocs((d) => inFolder(d.folder, path), (d) => ({
		...d,
		folder: target
	}), true);
}
function ensureTag(name) {
	const n = name.trim();
	if (!n) return;
	if (getLibrary().tags.some((t) => t.name.toLowerCase() === n.toLowerCase())) return;
	update((l) => ({ tags: [...l.tags, {
		name: n,
		color: l.tags.length % 6
	}] }));
}
var tagColor = (lib, name) => lib.tags.find((t) => t.name === name)?.color ?? 0;
function saveQuickFilter(name, filter) {
	update((l) => ({ quick: [...l.quick, {
		id: uid(),
		name,
		filter
	}] }));
}
function removeQuickFilter(id) {
	update((l) => ({ quick: l.quick.filter((q) => q.id !== id) }));
}
var norm = (s) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d");
var hayCache = /* @__PURE__ */ new WeakMap();
function matchesQuery(d, q) {
	const n = norm(q.trim());
	if (!n) return true;
	let hay = hayCache.get(d);
	if (hay === void 0) {
		hay = norm([
			d.name,
			d.folder,
			d.kind,
			...d.tags ?? [],
			d.locked ? "" : docText(d),
			...Object.values(d.fields ?? {})
		].join("\n"));
		hayCache.set(d, hay);
	}
	return hay.includes(n);
}
function applyFilter(docs, f) {
	const from = f.from ? new Date(f.from).getTime() : -Infinity;
	const to = f.to ? new Date(f.to).getTime() + 864e5 : Infinity;
	return docs.filter((d) => (!f.folder || inFolder(d.folder, f.folder)) && (!f.kind || d.kind === f.kind) && f.tags.every((t) => d.tags?.includes(t)) && d.createdAt >= from && d.createdAt < to && (f.ocr === "any" || f.ocr === "yes" === d.pages.some((p) => p.text)) && matchesQuery(d, f.q));
}
var activeFilterCount = (f) => (f.kind ? 1 : 0) + f.tags.length + (f.from ? 1 : 0) + (f.to ? 1 : 0) + (f.ocr !== "any" ? 1 : 0);
//#endregion
export { saveQuickFilter as _, baseName as a, useLibrary as b, deleteFolder as c, getLibrary as d, inFolder as f, renameFolder as g, removeQuickFilter as h, applyFilter as i, emptyFilter as l, parentOf as m, activeFilterCount as n, childFolders as o, matchesQuery as p, allFolders as r, createFolder as s, ROOT_FOLDER as t, ensureTag as u, setLibrary as v, tagColor as y };
