//#region node_modules/.nitro/vite/services/ssr/assets/name-rules-BfNs0V4s.js
/** Tên mặc định do newDoc sinh: "<loại> dd-mm hh:mm". */
var isDefaultName = (d) => d.name.startsWith(d.kind + " ") && /^\d{2}-\d{2} \d{2}:\d{2}$/.test(d.name.slice(d.kind.length + 1));
function cleanTitle(t) {
	const s = t.replace(/[\\/:*?"<>|\n\r\t]+/g, " ").replace(/\s+/g, " ").trim().replace(/^["'“]+|["'”.]+$/g, "");
	return s.length > 60 ? s.slice(0, 59).trimEnd() + "…" : s;
}
function cleanTags(tags) {
	const out = [];
	for (const t of tags) {
		const s = t.replace(/^#/, "").replace(/\s+/g, " ").trim().slice(0, 24);
		if (s && !out.some((o) => o.toLowerCase() === s.toLowerCase())) out.push(s);
	}
	return out.slice(0, 3);
}
/** Trả về tài liệu đã cập nhật, hoặc null nếu không nên đổi (người dùng đã tự đặt tên, AI không chắc…). */
function applyClassification(doc, c) {
	if (doc.locked || doc.deletedAt || !isDefaultName(doc) || !(c.confidence >= .4)) return null;
	const title = cleanTitle(c.title);
	if (!title) return null;
	const tags = [...doc.tags ?? []];
	for (const t of cleanTags(c.tags)) if (!tags.some((o) => o.toLowerCase() === t.toLowerCase())) tags.push(t);
	return {
		...doc,
		name: title,
		tags,
		fields: {
			...doc.fields ?? {},
			"Loại (AI)": c.type
		}
	};
}
var PLACEHOLDERS = [
	["{ten}", "Tên AI đặt"],
	["{loai}", "Loại giấy tờ"],
	["{the}", "Thẻ đầu tiên"],
	["{ngay}", "dd-mm-yyyy"],
	["{thang}", "mm-yyyy"],
	["{nam}", "yyyy"]
];
var FIELD_LABEL = {
	type: "Loại",
	tag: "Thẻ",
	name: "Tên"
};
var pad = (n) => String(n).padStart(2, "0");
/** Bỏ dấu + chữ thường để so khớp "hoa don" với "Hoá đơn". */
var fold = (s) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "d").toLowerCase().trim();
function renderTemplate(tpl, v) {
	const d = new Date(v.date);
	const map = {
		ten: v.title,
		loai: v.type,
		the: v.tags[0] ?? "",
		ngay: `${pad(d.getDate())}-${pad(d.getMonth() + 1)}-${d.getFullYear()}`,
		thang: `${pad(d.getMonth() + 1)}-${d.getFullYear()}`,
		nam: String(d.getFullYear())
	};
	return cleanTitle((tpl.trim() || "{ten}").replace(/\{(\w+)\}/g, (m, k) => k in map ? map[k] : m).replace(/\s*([-–_·|])\s*(?=\1|$)/g, "").replace(/^\s*[-–_·|]\s*/, "").replace(/\s+/g, " ")) || cleanTitle(v.title);
}
var cleanFolder = (f) => f.split("/").map((p) => p.replace(/[\\:*?"<>|]+/g, " ").replace(/\s+/g, " ").trim()).filter(Boolean).join("/");
function validRule(r) {
	return !!fold(r.contains) && !!cleanFolder(r.folder);
}
function ruleMatches(r, d) {
	const q = fold(r.contains);
	if (!q) return false;
	if (r.field === "name") return fold(d.name).includes(q);
	if (r.field === "tag") return (d.tags ?? []).some((t) => fold(t) === q);
	return fold(d.fields?.["Loại (AI)"] ?? "").includes(q);
}
/** Thư mục của quy tắc đầu tiên khớp, hoặc null. */
function pickFolder(rules, d) {
	const r = rules.find((x) => validRule(x) && ruleMatches(x, d));
	return r ? cleanFolder(r.folder) : null;
}
/** Áp mẫu tên + quy tắc thư mục sau khi AI phân loại. Chỉ chuyển tài liệu đang ở thư mục gốc. */
function applyNaming(doc, c, tpl, rules, root = "Chung") {
	const name = renderTemplate(tpl, {
		title: c.title,
		type: c.type,
		tags: doc.tags ?? [],
		date: doc.createdAt
	});
	const next = {
		...doc,
		name
	};
	const folder = doc.folder === root ? pickFolder(rules, next) : null;
	return folder ? {
		...next,
		folder
	} : next;
}
//#endregion
export { renderTemplate as a, applyNaming as i, PLACEHOLDERS as n, applyClassification as r, FIELD_LABEL as t };
