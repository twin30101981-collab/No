import { S as createFileRoute, x as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/s._token-DbbrCp4H.js
var $$splitComponentImporter = () => import("./s._token-BtAuRrV6.mjs");
var Route = createFileRoute("/s/$token")({
	head: () => ({ meta: [
		{ title: "Tài liệu được chia sẻ — Ghi Nhanh" },
		{
			name: "description",
			content: "Xem tài liệu được chia sẻ qua Ghi Nhanh."
		},
		{
			name: "robots",
			content: "noindex"
		},
		{
			property: "og:title",
			content: "Tài liệu được chia sẻ — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Xem tài liệu được chia sẻ qua Ghi Nhanh."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
