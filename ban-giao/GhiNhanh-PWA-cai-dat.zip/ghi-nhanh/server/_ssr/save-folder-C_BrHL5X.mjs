//#region node_modules/.nitro/vite/services/ssr/assets/save-folder-C_BrHL5X.js
var DB = "gn-save-folder";
var STORE = "h";
var KEY = "default";
var picker = () => typeof window === "undefined" ? void 0 : window.showDirectoryPicker;
var folderSupported = () => typeof picker() === "function";
function idb(mode, fn) {
	return new Promise((ok, fail) => {
		const o = indexedDB.open(DB, 1);
		o.onupgradeneeded = () => {
			o.result.createObjectStore(STORE);
		};
		o.onerror = () => fail(o.error);
		o.onsuccess = () => {
			const r = fn(o.result.transaction(STORE, mode).objectStore(STORE));
			r.onsuccess = () => {
				o.result.close();
				ok(r.result);
			};
			r.onerror = () => {
				o.result.close();
				fail(r.error);
			};
		};
	});
}
/** Thư mục mặc định đã nhớ (null nếu chưa chọn / không đọc được). Không xin quyền. */
async function savedFolder() {
	try {
		return await idb("readonly", (s) => s.get(KEY)) ?? null;
	} catch {
		return null;
	}
}
async function forgetFolder() {
	try {
		await idb("readwrite", (s) => s.delete(KEY));
	} catch {}
}
/** Mở hộp chọn thư mục của hệ điều hành (PHẢI gọi từ thao tác chạm) và nhớ làm mặc định. null = người dùng huỷ. */
async function pickFolder() {
	const p = picker();
	if (!p) throw new Error("Trình duyệt này chưa cho lưu thẳng vào thư mục. Hãy dùng Chrome hoặc Edge trên máy tính.");
	try {
		const h = await p({
			mode: "readwrite",
			id: "ghi-nhanh",
			startIn: "documents"
		});
		try {
			await idb("readwrite", (s) => s.put(h, KEY));
		} catch {}
		return h;
	} catch (e) {
		if (e?.name === "AbortError") return null;
		throw e;
	}
}
/** Đảm bảo có quyền ghi (xin lại nếu hết; cần thao tác chạm). false = bị từ chối. */
async function ensureWritable(h) {
	try {
		if (!h.queryPermission) return true;
		if (await h.queryPermission({ mode: "readwrite" }) === "granted") return true;
		return await h.requestPermission?.({ mode: "readwrite" }) === "granted";
	} catch {
		return false;
	}
}
/** Thư mục để lưu: mặc định đã nhớ (có quyền) hoặc hỏi chọn lần đầu. null = huỷ/từ chối quyền. */
async function folderForSave(opts = {}) {
	if (!opts.change) {
		const h = await savedFolder();
		if (h && await ensureWritable(h)) return h;
	}
	const h = await pickFolder();
	return h && await ensureWritable(h) ? h : null;
}
/** Tên chưa dùng trong thư mục: "a.pdf" → "a (2).pdf" → "a (3).pdf" (không ghi đè tệp có sẵn). */
async function freeName(dir, name) {
	const dot = name.lastIndexOf("."), base = dot > 0 ? name.slice(0, dot) : name, ext = dot > 0 ? name.slice(dot) : "";
	for (let k = 1; k < 1e3; k++) {
		const n = k === 1 ? name : `${base} (${k})${ext}`;
		try {
			await dir.getFileHandle(n);
		} catch (e) {
			if (e?.name === "NotFoundError") return n;
			throw e;
		}
	}
	return `${base}-${Date.now()}${ext}`;
}
/** Ghi một tệp; trả tên đã dùng. */
async function writeToFolder(dir, blob, name) {
	const n = await freeName(dir, name);
	const w = await (await dir.getFileHandle(n, { create: true })).createWritable();
	try {
		await w.write(blob);
	} catch (e) {
		await w.abort().catch(() => {});
		throw e;
	}
	await w.close();
	return n;
}
function folderError(e) {
	const n = e?.name;
	if (n === "NotAllowedError" || n === "SecurityError") return "Không có quyền ghi vào thư mục này. Hãy chọn lại thư mục.";
	if (n === "QuotaExceededError") return "Ổ đĩa đầy — chưa lưu được vào thư mục.";
	if (n === "NotFoundError" || n === "InvalidStateError") return "Thư mục đã bị xoá hoặc di chuyển. Hãy chọn lại thư mục.";
	return "Không lưu được vào thư mục. Hãy chọn lại thư mục rồi thử lại.";
}
//#endregion
export { savedFolder as a, forgetFolder as i, folderForSave as n, writeToFolder as o, folderSupported as r, folderError as t };
