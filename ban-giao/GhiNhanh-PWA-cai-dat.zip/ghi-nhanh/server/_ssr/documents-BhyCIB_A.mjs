import { o as __toESM } from "../_runtime.mjs";
import { T as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as aiLayout, f as aiTable } from "./ai.functions-CpS7iAgj.mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { i as showError } from "./errors-DKvrPJ4v.mjs";
import { At as FileArchive, Bt as Combine, C as SlidersHorizontal, Ct as FileText, E as Search, Et as FileOutput, St as FileTypeCorner, V as Pencil, X as LoaderCircle, Z as List, _t as FolderPlus, bt as FolderDown, f as Trash2, gt as Folder, in as ArrowDownUp, m as Tags, r as X, tt as LayoutGrid, w as Share2, wt as FileSpreadsheet, yt as FolderInput } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-CZvf2xHx.mjs";
import { c as srcBytes } from "./disk-pack-ZdDKsocx.mjs";
import { C as saveDoc, D as useDocs, E as uid, S as restoreDocs, f as mutateDocs, i as deleteDocs, o as docText, p as newDoc } from "./db-CclUQaLE.mjs";
import { _ as saveQuickFilter, a as baseName, b as useLibrary, c as deleteFolder, f as inFolder, g as renameFolder, i as applyFilter, l as emptyFilter, m as parentOf, n as activeFilterCount, o as childFolders, r as allFolders, s as createFolder } from "./library-BIMZUn1d.mjs";
import { i as useQueuedServerFn } from "./ai-queue-DZjZmUCT.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { i as healPending } from "./runner-CZAn6hg6.mjs";
import { S as shareOrDownload, _ as readyDocs, c as download, s as docToPdf, u as imagesToPdf, x as safeName } from "./files-CTF11Arr.mjs";
import { i as promptDialog, n as confirmDialog } from "./dialog-IcUxZaUZ.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, t as Dialog } from "./dialog-3HhpKDcy.mjs";
import { d as recordFile, f as registerSource } from "./history-ZPjFrOJG.mjs";
import { a as TagPicker, i as TagChip, n as FolderCrumbs, r as FolderPicker, t as FilterSheet } from "./library-ui-BCoN_d8a.mjs";
import { a as savedFolder, n as folderForSave, o as writeToFolder, r as folderSupported, t as folderError } from "./save-folder-C_BrHL5X.mjs";
import { t as ExportReview } from "./export-review-DWV3zMTm.mjs";
import { t as Route } from "./documents-Cxss4jut.mjs";
import { t as DocRow } from "./doc-row-BD9Y5xLI.mjs";
import { t as Progress } from "./progress-DOIEKRJF.mjs";
import { n as batchMerged, r as batchSeparate } from "./batch-BYOz1Bdb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/documents-BhyCIB_A.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FORMATS = [
	{
		id: "pdf",
		label: "PDF",
		icon: FileText
	},
	{
		id: "word",
		label: "Word",
		icon: FileTypeCorner
	},
	{
		id: "excel",
		label: "Excel",
		icon: FileSpreadsheet
	}
];
/** Pick format + separate/merged, convert all chosen documents in one go. */
function BatchExport({ docs: docsProp, open, onClose, onDone }) {
	const [fmt, setFmt] = (0, import_react.useState)("pdf");
	const [merged, setMerged] = (0, import_react.useState)(false);
	const [bundle, setBundle] = (0, import_react.useState)(false);
	const [toFolder, setToFolder] = (0, import_react.useState)(false);
	const [folderOk, setFolderOk] = (0, import_react.useState)(false);
	const [folderName, setFolderName] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!folderSupported()) return;
		setFolderOk(true);
		savedFolder().then((h) => setFolderName(h?.name ?? null));
	}, [open]);
	const [prog, setProg] = (0, import_react.useState)(null);
	const [review, setReview] = (0, import_react.useState)(null);
	const fns = {
		layout: useQueuedServerFn(aiLayout, "Đọc bố cục"),
		table: useQueuedServerFn(aiTable, "Đọc bảng")
	};
	const ext = fmt === "pdf" ? "pdf" : fmt === "word" ? "docx" : "xlsx";
	const title = `${docsProp.length} tài liệu`;
	async function runBundle() {
		const docs = await readyDocs(docsProp);
		setProg({
			done: 0,
			total: docs.length,
			name: ""
		});
		try {
			const { buildBatchBundle } = await import("./export-bundle-DTDgvJ_l.mjs");
			const r = await buildBatchBundle(docs.map((d) => ({
				name: safeName(d.name),
				pdf: () => docToPdf(d),
				pages: d.pages.map((p) => p.src),
				text: docText(d)
			})), (done, total, name) => setProg({
				done,
				total,
				name
			}));
			if (!r.blob) throw new Error("Không đóng gói được tài liệu nào");
			const out = `ghi-nhanh-${docs.length}-tai-lieu-goi-day-du.zip`;
			download(r.blob, out);
			recordFile({
				kind: "Hàng loạt → Gói đầy đủ",
				sourceName: title,
				outputBlob: r.blob,
				outputName: out,
				details: docs.map((d) => `${d.name} (${d.pages.length} trang)`),
				warnings: r.failed.length ? [`${r.failed.length} tài liệu chưa đóng gói được`] : []
			}).catch((e) => console.error("history", e));
			toast.success(`Đã đóng gói ${r.count}/${docs.length} tài liệu`);
			if (r.failed.length) toast(`Chưa đóng gói được: ${r.failed.join(", ")}`);
			onDone();
		} catch (e) {
			showError(e, "Không đóng gói được");
		} finally {
			setProg(null);
		}
	}
	async function run() {
		const useFolder = toFolder && !merged && !bundle && folderOk;
		let dir = null;
		if (useFolder) {
			try {
				dir = await folderForSave();
			} catch (e) {
				showError(e, "Không mở được thư mục");
				return;
			}
			if (!dir) {
				toast("Chưa xuất: bạn chưa chọn thư mục hoặc chưa cho phép ghi.");
				return;
			}
			setFolderName(dir.name);
		}
		const docs = await readyDocs(docsProp);
		if (bundle) return runBundle();
		setProg({
			done: 0,
			total: docs.length,
			name: ""
		});
		const onP = (done, total, name) => setProg({
			done,
			total,
			name
		});
		const warn = (m) => toast(m);
		const names = docs.map((d) => `${d.name} (${d.pages.length} trang)`);
		const kind = `Hàng loạt → ${fmt === "pdf" ? "PDF" : fmt === "word" ? "Word" : "Excel"}`;
		const allPdf = () => imagesToPdf(docs.flatMap((d) => d.pages.map((p) => p.src)), { searchable: true });
		try {
			if (merged) {
				const r = await batchMerged(docs, fmt, fns, onP, warn);
				if (r.kind === "pdf") {
					const out = `gop-${docs.length}-tai-lieu.pdf`;
					download(r.blob, out);
					toast.success("Đã lưu PDF gộp");
					recordFile({
						kind: `${kind} (gộp)`,
						sourceName: title,
						outputBlob: r.blob,
						outputName: out,
						details: names
					}).catch((e) => console.error("history", e));
					onDone();
				} else {
					const source = {
						kind: `${kind} (gộp)`,
						name: `${title}.pdf`,
						lazy: registerSource(allPdf),
						details: names
					};
					onClose();
					setReview(r.kind === "word" ? {
						kind: "word",
						title: `Gộp ${title}`,
						blocks: r.blocks,
						source
					} : {
						kind: "excel",
						title: `Gộp ${title}`,
						sheets: r.sheets,
						source
					});
				}
			} else {
				const r = await batchSeparate(docs, fmt, fns, onP, warn, dir ? (n, b) => writeToFolder(dir, b, n).catch((e) => {
					throw Object.assign(new Error(folderError(e)), { folder: true });
				}) : void 0);
				if (!r.count) throw new Error("Không chuyển được tài liệu nào");
				if (dir) {
					toast.success(`Đã lưu ${r.count}/${docs.length} tệp vào thư mục “${dir.name}”`);
					if (r.failed.length) toast(`Chưa chuyển được: ${r.failed.join(", ")}`);
					onDone();
					return;
				}
				const out = `ghi-nhanh-${docs.length}-tai-lieu-${ext}.zip`;
				download(r.blob, out);
				const ok = docs.filter((d) => !r.failed.includes(d.name)).map((d) => `${d.name} (${d.pages.length} trang)`);
				const src = await allPdf().catch(() => void 0);
				recordFile({
					kind: `${kind} (mỗi tài liệu một tệp)`,
					sourceName: `${title}.pdf`,
					outputBlob: r.blob,
					outputName: out,
					sourceBlob: src && new File([src], `${title}.pdf`, { type: "application/pdf" }),
					details: [...ok, ...r.failed.map((n) => `Bỏ qua: ${n}`)],
					warnings: r.failed.length ? [`${r.failed.length} tài liệu chưa chuyển được`] : []
				}).catch((e) => console.error("history", e));
				toast.success(`Đã chuyển ${r.count}/${docs.length} tài liệu`);
				if (r.failed.length) toast(`Chưa chuyển được: ${r.failed.join(", ")}`);
				onDone();
			}
		} catch (e) {
			showError(e, "Không chuyển được");
		} finally {
			setProg(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (o) => !o && !prog && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-[92vw] rounded-[18px] sm:max-w-[400px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
					className: "font-display",
					children: ["Xuất ", title]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium text-muted-foreground",
					children: "Định dạng"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: FORMATS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: fmt === f.id ? "default" : "glass",
						className: "h-16 flex-col gap-1",
						disabled: !!prog,
						onClick: () => setFmt(f.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(f.icon, { className: "size-5" }), f.label]
					}, f.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: bundle ? "default" : "glass",
					className: "h-auto justify-start gap-2 whitespace-normal py-2 text-left",
					disabled: !!prog,
					onClick: () => setBundle(!bundle),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileArchive, { className: "size-5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Gói đầy đủ" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[0.6875rem] font-normal opacity-80",
							children: "Mỗi tài liệu một thư mục: PDF + ảnh từng trang + chữ"
						})]
					})]
				}),
				!bundle && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium text-muted-foreground",
					children: "Cách xuất"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: !merged ? "default" : "glass",
						className: "h-auto flex-col items-start whitespace-normal py-2 text-left",
						disabled: !!prog,
						onClick: () => setMerged(false),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Mỗi tài liệu một tệp" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[0.6875rem] font-normal opacity-80",
							children: "Gói trong một tệp nén"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: merged ? "default" : "glass",
						className: "h-auto flex-col items-start whitespace-normal py-2 text-left",
						disabled: !!prog,
						onClick: () => setMerged(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Gộp thành một tệp" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[0.6875rem] font-normal opacity-80",
							children: fmt === "excel" ? "Mỗi tài liệu một trang tính" : "Nối tiếp theo thứ tự"
						})]
					})]
				})] }),
				!bundle && !merged && folderOk && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: toFolder ? "default" : "glass",
					className: "h-auto justify-start gap-2 whitespace-normal py-2 text-left",
					disabled: !!prog,
					"aria-pressed": toFolder,
					onClick: () => setToFolder(!toFolder),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderDown, { className: "size-5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Lưu thẳng vào thư mục" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[0.6875rem] font-normal opacity-80",
							children: folderName ? `Mỗi tài liệu một tệp trong “${folderName}” (không gói nén)` : "Chọn thư mục một lần, lần sau tự nhớ"
						})]
					})]
				}),
				!bundle && fmt !== "pdf" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Word/Excel dùng AI đọc từng trang nên mất vài giây mỗi trang."
				}),
				prog && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: prog.done / Math.max(1, prog.total) * 100 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "truncate text-xs text-muted-foreground",
						children: [
							"Đang xử lý ",
							Math.min(prog.done + 1, prog.total),
							"/",
							prog.total,
							prog.name ? ` · ${prog.name}` : ""
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: run,
					disabled: !!prog,
					children: [
						prog ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : null,
						" Xuất ",
						docsProp.length,
						" tài liệu"
					]
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportReview, {
		review,
		onClose: () => {
			setReview(null);
			onDone();
		}
	})] });
}
var SORT_LABEL = {
	date: "Mới nhất",
	name: "Tên A–Z",
	size: "Dung lượng"
};
function Documents() {
	const { docs } = useDocs();
	const lib = useLibrary();
	const navigate = useNavigate();
	const search = Route.useSearch();
	const [filter, setFilter] = (0, import_react.useState)(() => emptyFilter());
	const [sort, setSort] = (0, import_react.useState)("date");
	const [grid, setGrid] = (0, import_react.useState)(false);
	const [selected, setSelected] = (0, import_react.useState)([]);
	const [sheet, setSheet] = (0, import_react.useState)(null);
	const [bulkTags, setBulkTags] = (0, import_react.useState)([]);
	const [dropOn, setDropOn] = (0, import_react.useState)(null);
	const selectMode = selected.length > 0;
	const [batchOpen, setBatchOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const qf = search.qf && lib.quick.find((q) => q.id === search.qf);
		if (qf) setFilter({
			...emptyFilter(),
			...qf.filter
		});
		else if (search.tag) setFilter({
			...emptyFilter(),
			tags: [search.tag]
		});
	}, [
		search.qf,
		search.tag,
		lib.quick
	]);
	const folders = (0, import_react.useMemo)(() => allFolders(lib, docs), [lib, docs]);
	const subfolders = childFolders(folders, filter.folder);
	const [limit, setLimit] = (0, import_react.useState)(PAGE);
	(0, import_react.useEffect)(() => {
		setLimit(PAGE);
	}, [filter, sort]);
	const kinds = (0, import_react.useMemo)(() => [...new Set(docs.map((d) => d.kind))].sort((a, b) => a.localeCompare(b, "vi")), [docs]);
	const list = (0, import_react.useMemo)(() => {
		const size = (d) => d.pages.reduce((n, p) => n + srcBytes(p.src), 0);
		return applyFilter(docs, filter).sort((a, b) => sort === "name" ? a.name.localeCompare(b.name, "vi") : sort === "size" ? size(b) - size(a) : b.updatedAt - a.updatedAt);
	}, [
		docs,
		filter,
		sort
	]);
	const chosen = docs.filter((d) => selected.includes(d.id));
	const toggle = (id) => setSelected((s) => s.includes(id) ? s.filter((x) => x !== id) : [...s, id]);
	const set = (p) => setFilter((f) => ({
		...f,
		...p
	}));
	const nActive = activeFilterCount(filter);
	async function merge() {
		if (chosen.length < 2) {
			toast("Chọn ít nhất 2 tài liệu để ghép");
			return;
		}
		const doc = await saveDoc(newDoc(chosen.flatMap((d) => d.pages.map((p) => ({
			...p,
			id: uid()
		}))), `Ghép ${chosen.length} tài liệu`, "Ghép"));
		healPending([doc]);
		setSelected([]);
		navigate({
			to: "/doc/$id",
			params: { id: doc.id }
		});
	}
	async function moveTo(folder, ids = selected) {
		await mutateDocs(ids, (d) => ({
			...d,
			folder
		}), true);
		setSelected([]);
		setSheet(null);
		toast.success(`Đã chuyển ${ids.length} tài liệu vào "${baseName(folder)}"`);
	}
	async function applyTags() {
		await mutateDocs(chosen.map((d) => d.id), (d) => ({
			...d,
			tags: [.../* @__PURE__ */ new Set([...d.tags ?? [], ...bulkTags])]
		}), true);
		toast.success(`Đã gắn ${bulkTags.length} thẻ cho ${chosen.length} tài liệu`);
		setBulkTags([]);
		setSelected([]);
		setSheet(null);
	}
	async function share() {
		const ready = await readyDocs(chosen);
		const blob = ready.length === 1 ? await docToPdf(ready[0]) : await imagesToPdf(ready.flatMap((d) => d.pages.map((p) => p.src)), { searchable: true });
		await shareOrDownload(blob, `${safeName(ready.length === 1 ? ready[0].name : "ghi-nhanh")}.pdf`);
	}
	async function remove() {
		if (!await confirmDialog(`Xóa ${chosen.length} tài liệu?`, {
			message: "Không thể hoàn tác.",
			okText: "Xóa",
			danger: true
		})) return;
		const ids = selected;
		await deleteDocs(ids);
		setSelected([]);
		toast(`Đã chuyển ${ids.length} tài liệu vào thùng rác`, { action: {
			label: "Hoàn tác",
			onClick: () => void restoreDocs(ids)
		} });
	}
	async function newFolder() {
		const n = (await promptDialog(filter.folder ? `Thư mục con trong "${baseName(filter.folder)}"` : "Thư mục mới", {
			placeholder: "Tên thư mục",
			okText: "Tạo"
		}))?.replace(/\//g, "-");
		if (!n) return;
		const path = filter.folder ? `${filter.folder}/${n}` : n;
		createFolder(path);
		toast.success(`Đã tạo "${n}"`);
	}
	async function rename() {
		const f = filter.folder;
		if (!f) return;
		const n = (await promptDialog("Đổi tên thư mục", {
			defaultValue: baseName(f),
			okText: "Lưu"
		}))?.replace(/\//g, "-");
		if (!n || n === baseName(f)) return;
		const p = parentOf(f);
		const to = p ? `${p}/${n}` : n;
		await renameFolder(f, to, docs);
		set({ folder: to });
		toast.success("Đã đổi tên");
	}
	async function removeFolder() {
		const f = filter.folder;
		if (!f) return;
		const count = docs.filter((d) => inFolder(d.folder, f)).length;
		if (!await confirmDialog(`Xoá thư mục "${baseName(f)}"?`, {
			message: `Các thư mục con cũng bị xoá. ${count} tài liệu sẽ chuyển lên "${parentOf(f) ?? "Chung"}".`,
			okText: "Xoá",
			danger: true
		})) return;
		await deleteFolder(f, docs);
		set({ folder: parentOf(f) });
		toast("Đã xoá thư mục");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		wide: true,
		title: selectMode ? `Đã chọn ${selected.length}` : "Tài liệu",
		action: selectMode ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "glass",
			size: "icon",
			"aria-label": "Bỏ chọn",
			onClick: () => setSelected([]),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "glass",
				size: "icon",
				"aria-label": "Đổi cách sắp xếp",
				onClick: () => setSort((s) => s === "date" ? "name" : s === "name" ? "size" : "date"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownUp, {})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "glass",
				size: "icon",
				"aria-label": "Đổi kiểu hiển thị",
				onClick: () => setGrid((g) => !g),
				children: grid ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, {})
			})]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise rise-1 flex gap-2 px-5 pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "glass-field flex h-11 min-w-0 flex-1 items-center gap-2 rounded-[12px] px-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 shrink-0 text-muted-foreground" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: filter.q,
							onChange: (e) => set({ q: e.target.value }),
							placeholder: "Tên, chữ trong ảnh, thẻ…",
							className: "min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
						}),
						filter.q && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							"aria-label": "Xoá tìm kiếm",
							onClick: () => set({ q: "" }),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4 text-muted-foreground" })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: nActive ? "default" : "glass",
					className: "h-11 gap-1.5",
					onClick: () => setSheet("filter"),
					"aria-label": "Bộ lọc",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {}), nActive || null]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise rise-1 flex items-center gap-2 px-5 pt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-w-0 flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderCrumbs, {
							folder: filter.folder,
							onGo: (f) => set({ folder: f })
						})
					}),
					filter.folder && filter.folder !== "Chung" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "size-8",
						"aria-label": "Đổi tên thư mục",
						onClick: rename,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "size-8 text-destructive",
						"aria-label": "Xoá thư mục",
						onClick: removeFolder,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "size-10",
						"aria-label": "Tạo thư mục",
						onClick: newFolder,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderPlus, {})
					})
				]
			}),
			subfolders.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto px-5 pt-2 [scrollbar-width:none]",
				children: subfolders.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => set({ folder: f }),
					onDragOver: (e) => {
						e.preventDefault();
						setDropOn(f);
					},
					onDragLeave: () => setDropOn(null),
					onDrop: (e) => {
						e.preventDefault();
						setDropOn(null);
						const id = e.dataTransfer.getData("text/doc-id");
						if (id) moveTo(f, selected.includes(id) ? selected : [id]);
					},
					className: `shortcut-tile flex h-10 shrink-0 items-center gap-1.5 rounded-[12px] px-3 text-xs font-semibold ${dropOn === f ? "ring-2 ring-primary" : ""}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Folder, { className: "size-4 text-primary" }),
						baseName(f),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[0.625rem] font-normal text-muted-foreground",
							children: docs.filter((d) => inFolder(d.folder, f)).length
						})
					]
				}, f))
			}),
			(filter.tags.length > 0 || filter.kind || filter.from || filter.to || filter.ocr !== "any") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-1.5 px-5 pt-2",
				children: [
					filter.tags.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagChip, {
						name: t,
						onRemove: () => set({ tags: filter.tags.filter((x) => x !== t) })
					}, t)),
					filter.kind && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
						onRemove: () => set({ kind: null }),
						children: filter.kind
					}),
					(filter.from || filter.to) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Pill, {
						onRemove: () => set({
							from: "",
							to: ""
						}),
						children: [
							filter.from || "…",
							" → ",
							filter.to || "…"
						]
					}),
					filter.ocr !== "any" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
						onRemove: () => set({ ocr: "any" }),
						children: filter.ocr === "yes" ? "Đã nhận chữ" : "Chưa nhận chữ"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "px-5 pt-2 text-[0.6875rem] text-muted-foreground",
				children: [
					list.length,
					" tài liệu · ",
					SORT_LABEL[sort],
					" · Giữ lâu để chọn nhiều"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `rise rise-2 px-5 pt-3 ${grid ? "grid grid-cols-2 gap-2.5 lg:grid-cols-4" : "flex flex-col gap-2.5 lg:grid lg:grid-cols-2"}`,
				children: [
					list.slice(0, limit).map((doc) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocRow, {
						doc,
						grid,
						selectMode,
						selected: selected.includes(doc.id),
						onLongPress: () => toggle(doc.id),
						onToggle: () => toggle(doc.id),
						onDelete: async () => {
							await deleteDocs([doc.id]);
							toast("Đã chuyển vào thùng rác", { action: {
								label: "Hoàn tác",
								onClick: () => void restoreDocs([doc.id])
							} });
						},
						onShare: async () => {
							await shareOrDownload(await docToPdf(doc), `${safeName(doc.name)}.pdf`);
						}
					}, doc.id)),
					list.length > limit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadMore, { onMore: () => setLimit((n) => n + PAGE) }),
					!list.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "col-span-full py-16 text-center text-sm text-muted-foreground",
						children: "Không có tài liệu phù hợp"
					})
				]
			}),
			selectMode && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bottom-nav fixed inset-x-0 bottom-[calc(76px+env(safe-area-inset-bottom))] z-40 mx-auto grid w-[calc(100%-24px)] max-w-[406px] grid-cols-6 rounded-[16px] p-1.5",
				children: [
					{
						i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, {}),
						l: "Chia sẻ",
						f: share
					},
					{
						i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileOutput, {}),
						l: "Xuất",
						f: () => setBatchOpen(true)
					},
					{
						i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Combine, {}),
						l: "Ghép",
						f: merge
					},
					{
						i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderInput, {}),
						l: "Thư mục",
						f: () => setSheet("move")
					},
					{
						i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tags, {}),
						l: "Gắn thẻ",
						f: () => setSheet("tags")
					},
					{
						i: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}),
						l: "Xóa",
						f: remove
					}
				].map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					className: `h-14 flex-col gap-1 px-0 text-[0.625rem] ${a.l === "Xóa" ? "text-destructive" : ""}`,
					onClick: a.f,
					children: [a.i, a.l]
				}, a.l))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BatchExport, {
				docs: chosen,
				open: batchOpen,
				onClose: () => setBatchOpen(false),
				onDone: () => {
					setBatchOpen(false);
					setSelected([]);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterSheet, {
				open: sheet === "filter",
				onOpenChange: (o) => setSheet(o ? "filter" : null),
				value: filter,
				onChange: setFilter,
				kinds,
				onSaveQuick: (name) => {
					saveQuickFilter(name, filter);
					toast.success(`Đã lưu "${name}" vào Trang chủ`);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderPicker, {
				open: sheet === "move",
				onOpenChange: (o) => setSheet(o ? "move" : null),
				title: `Chuyển ${selected.length} tài liệu vào`,
				value: chosen.length && chosen.every((d) => d.folder === chosen[0].folder) ? chosen[0].folder : void 0,
				onPick: (f) => void moveTo(f)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagPicker, {
				open: sheet === "tags",
				onOpenChange: (o) => {
					if (!o && bulkTags.length) applyTags();
					else setSheet(o ? "tags" : null);
				},
				title: `Gắn thẻ cho ${selected.length} tài liệu`,
				value: bulkTags,
				onChange: setBulkTags
			})
		]
	});
}
function Pill({ children, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex h-6 items-center gap-1 rounded-md bg-secondary px-1.5 text-[0.625rem] font-bold text-primary",
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			"aria-label": "Bỏ",
			onClick: onRemove,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
		})]
	});
}
var PAGE = 40;
/** Hiện dần 40 tài liệu mỗi lần khi cuộn tới cuối — giữ danh sách mượt khi có hàng trăm tài liệu. */
function LoadMore({ onMore }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const io = new IntersectionObserver(([e]) => {
			if (e.isIntersecting) onMore();
		}, { rootMargin: "400px" });
		io.observe(el);
		return () => io.disconnect();
	}, [onMore]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: "col-span-full h-8"
	});
}
//#endregion
export { Documents as component };
