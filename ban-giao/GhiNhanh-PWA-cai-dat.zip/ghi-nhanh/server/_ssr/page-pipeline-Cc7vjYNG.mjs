import { n as runInPool } from "./worker-pool-DW9Ak2AM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/page-pipeline-Cc7vjYNG.js
/** Tắt Worker (đo so sánh / rollback): setPagePipelineWorker(false). */
var enabled = true;
/**
* Xử lý một trang trong worker: cắt theo `quad` (nếu có), thu nhỏ về `max`,
* nén JPEG chất lượng `q`, kèm ảnh thu nhỏ cạnh dài `thumbMax`.
* `bmp` bị chuyển quyền (transfer) — caller không dùng lại được sau khi gọi.
* Trả null nếu không dùng được Worker.
*/
function processPageInWorker(bmp, opts) {
	if (!enabled) return null;
	const p = runInPool("page", {
		bmp,
		...opts
	}, [bmp]);
	if (!p) return null;
	return p.then((r) => {
		if (!r.main || !r.thumb) throw new Error(r.error || "page-pipeline worker");
		return {
			main: r.main,
			thumb: r.thumb,
			w: r.w ?? 0,
			h: r.h ?? 0
		};
	});
}
//#endregion
export { processPageInWorker };
