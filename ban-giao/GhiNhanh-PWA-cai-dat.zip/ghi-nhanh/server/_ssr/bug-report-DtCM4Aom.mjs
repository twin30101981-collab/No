import { n as getSettings } from "./settings-DDlMLZCe.mjs";
import { s as readPerf, t as budgetReport } from "./perf-stats-C5jrVSN8.mjs";
import { a as readScanLog, n as deviceInfo } from "./scan-log-DnWLrMlu.mjs";
import { n as readUses } from "./tool-usage-C3cHF8xW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bug-report-DtCM4Aom.js
/**
* FX-04: gói "Báo lỗi" — nhật ký quét/AI + số đo tốc độ (ngân sách §17.1) + công cụ hay dùng + cài đặt không nhạy cảm.
* KHÔNG kèm ảnh/nội dung tài liệu: mọi chuỗi data:/blob:/base64 dài bị thay bằng "[đã bỏ]"; không có PIN, khoá két, quy tắc thư mục.
*/
/** Cài đặt được phép gửi (cờ chức năng); bỏ pin/pinSalt/vaultWrap/nameTemplate/folderRules. */
var SAFE_SETTINGS = [
	"quality",
	"paper",
	"pdfPage",
	"ocrLang",
	"dark",
	"autoLock",
	"autoCapture",
	"maxQuality",
	"captureSound",
	"captureVibrate",
	"defaultFilter",
	"autoName",
	"autoOcr",
	"autoRecipe",
	"globalPipeline",
	"continuousCapture",
	"largeText",
	"voiceGuide",
	"guideVibrate"
];
var DROPPED = "[đã bỏ]";
/** Bỏ mọi giá trị có thể là ảnh/tệp: data:/blob: URL, chuỗi base64 dài (≥ 200 ký tự liền), chuỗi > 2000 ký tự. */
function scrub(v, depth = 0) {
	if (typeof v === "string") return /^(data|blob):/i.test(v) || /[A-Za-z0-9+/=]{200,}/.test(v) || v.length > 2e3 ? DROPPED : v;
	if (v === null || typeof v !== "object") return v;
	if (depth > 6) return DROPPED;
	if (Array.isArray(v)) return v.map((x) => scrub(x, depth + 1));
	return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, scrub(x, depth + 1)]));
}
function buildBugReport(src) {
	const settings = Object.fromEntries(SAFE_SETTINGS.filter((k) => k in src.settings).map((k) => [k, src.settings[k]]));
	return {
		kind: "ghi-nhanh-bao-loi",
		createdAt: (src.now ?? /* @__PURE__ */ new Date()).toISOString(),
		build: src.build,
		device: src.device,
		note: scrub((src.note ?? "").slice(0, 1e3)),
		settings,
		scanLog: scrub(src.log),
		perf: {
			samples: src.perf.length,
			budget: budgetReport(src.perf)
		},
		toolUses: src.uses
	};
}
/** Gói từ dữ liệu trên máy → Blob JSON + tên tệp. */
function currentBugReport(note = "") {
	const r = buildBugReport({
		log: readScanLog(),
		perf: readPerf(),
		uses: readUses(),
		settings: getSettings(),
		build: "20261015024518",
		device: deviceInfo(),
		note
	});
	return {
		report: r,
		name: `ghi-nhanh-bao-loi-${r.createdAt.slice(0, 19).replace(/[:T]/g, "-")}.json`,
		blob: new Blob([JSON.stringify(r, null, 2)], { type: "application/json" })
	};
}
//#endregion
export { currentBugReport };
