import { S as createFileRoute, x as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pair_._code-BPp1iwsc.js
var $$splitComponentImporter = () => import("./pair_._code-lJWI1NVs.mjs");
var Route = createFileRoute("/pair_/$code")({
	validateSearch: (s) => ({ t: Number(s["t"]) || void 0 }),
	head: () => ({ meta: [
		{ title: "Nối với máy tính — Ghi Nhanh" },
		{
			name: "description",
			content: "Điện thoại đang nối với máy tính để gửi ảnh giấy tờ vừa chụp."
		},
		{
			property: "og:title",
			content: "Nối với máy tính — Ghi Nhanh"
		},
		{
			property: "og:description",
			content: "Điện thoại đang nối với máy tính để gửi ảnh giấy tờ vừa chụp."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
