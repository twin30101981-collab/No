//#region node_modules/.nitro/vite/services/ssr/assets/disk-pack-ZdDKsocx.js
/** Dấu vân tay giống cloud-sync.fingerprint (tính trên data URL) — lưu kèm Blob để object URL vẫn so được. */
function fpOf(s) {
	if (s.startsWith("blob:")) {
		const f = fps.get(s);
		if (f) return f;
	}
	let h = 2166136261;
	const step = Math.max(1, Math.floor(s.length / 4096));
	for (let i = 0; i < s.length; i += step) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return `${s.length}:${(h >>> 0).toString(36)}`;
}
var fps = /* @__PURE__ */ new Map();
function toBlob(u) {
	if (!u.startsWith("data:") || !u.includes(";base64,")) return null;
	const i = u.indexOf(",");
	const raw = atob(u.slice(i + 1));
	const a = new Uint8Array(raw.length);
	for (let k = 0; k < raw.length; k++) a[k] = raw.charCodeAt(k);
	return new Blob([a], { type: u.slice(5, i).replace(";base64", "") || "image/jpeg" });
}
/** S15f3b: ảnh nạp từ kho giữ dạng object URL (không giải base64 vào RAM). Sổ đăng ký URL→Blob để
*  packDoc ghi lại được nhị phân, và để thu hồi URL khi xoá tài liệu. */
var reg = /* @__PURE__ */ new Map();
var blobFor = (u) => reg.get(u);
function objUrl(b, fp) {
	if (typeof URL === "undefined" || typeof URL.createObjectURL !== "function") return "";
	const u = URL.createObjectURL(b);
	reg.set(u, b);
	fps.set(u, fp);
	return u;
}
/** R1.3: nhận Blob mới (vd. từ canvas.toBlob) thành object URL đã đăng ký — packDoc ghi lại được, revokeDoc thu hồi được. */
function adoptBlob(b) {
	return objUrl(b, `${b.size}:${b.type}:${Date.now().toString(36)}`);
}
/** Thu hồi object URL của các trang (gọi khi xoá tài liệu). */
function revokeDoc(d, keep = /* @__PURE__ */ new Set()) {
	for (const p of d?.pages ?? []) for (const u of [p.orig, p.src]) if (u && reg.has(u) && !keep.has(u)) {
		URL.revokeObjectURL(u);
		reg.delete(u);
		fps.delete(u);
	}
}
/** Đổi object URL về data URL (cho niêm phong/khoá, nơi phải giữ ảnh trong chuỗi). */
async function inlineDoc(d) {
	if (!d.pages?.some((p) => reg.has(p.orig) || reg.has(p.src))) return d;
	const f = async (u) => {
		const b = reg.get(u);
		return b ? toUrl(b) : u;
	};
	return {
		...d,
		pages: await Promise.all(d.pages.map(async (p) => ({
			...p,
			orig: await f(p.orig),
			src: await f(p.src)
		})))
	};
}
var asBlob = (u) => u.startsWith("blob:") ? reg.get(u) ?? null : toBlob(u);
function toUrl(b) {
	return new Promise((res, rej) => {
		const r = new FileReader();
		r.onload = () => res(r.result);
		r.onerror = rej;
		r.readAsDataURL(b);
	});
}
function packDoc(d) {
	if (d.enc || !d.pages?.length) return d;
	return {
		...d,
		pages: d.pages.map((p) => {
			const ob = asBlob(p.orig);
			const out = { ...p };
			if (ob) {
				out.origB = ob;
				out.origFp = fpOf(p.orig);
				out.orig = "";
			}
			if (p.src === p.orig && ob) out.src = "=";
			else {
				const sb = asBlob(p.src);
				if (sb) {
					out.srcB = sb;
					out.srcFp = fpOf(p.src);
					out.src = "";
				}
			}
			return out;
		})
	};
}
async function unpackDoc(d) {
	const pages = d.pages;
	if (!pages?.some((p) => p.origB || p.srcB)) return d;
	return {
		...d,
		pages: await Promise.all(pages.map(async ({ origB, srcB, origFp, srcFp, ...p }) => {
			const conv = async (b, fp) => {
				return objUrl(b, fp ?? fpOf(await toUrl(b))) || toUrl(b);
			};
			const orig = origB ? await conv(origB, origFp) : p.orig;
			const src = p.src === "=" ? orig : srcB ? await conv(srcB, srcFp) : p.src;
			return {
				...p,
				orig,
				src
			};
		}))
	};
}
/** Số byte thật của ảnh trang: blob: lấy từ Blob đã đăng ký, data: tính từ base64. */
function srcBytes(u) {
	if (!u) return 0;
	if (u.startsWith("blob:")) return reg.get(u)?.size ?? 0;
	const i = u.indexOf(",");
	if (u.startsWith("data:") && i > 0) {
		const b = u.slice(i + 1);
		return u.slice(0, i).includes(";base64") ? Math.floor(b.length * 3 / 4) - (b.endsWith("==") ? 2 : b.endsWith("=") ? 1 : 0) : b.length;
	}
	return u.length;
}
/** B05: sau khi lưu, đổi data URL của trang thành object URL để bộ nhớ không giữ chuỗi base64 ảnh.
*  Dấu vân tay tính trên data URL gốc nên đồng bộ đám mây không thấy khác. Tài liệu mã hoá giữ nguyên. */
function blobifyDoc(d) {
	if (d.enc || !d.pages?.some((p) => p.orig?.startsWith("data:") || p.src?.startsWith("data:"))) return d;
	const memo = /* @__PURE__ */ new Map();
	const f = (u) => {
		if (!u?.startsWith("data:")) return u;
		const hit = memo.get(u);
		if (hit) return hit;
		const b = toBlob(u);
		const r = (b ? objUrl(b, fpOf(u)) : "") || u;
		memo.set(u, r);
		return r;
	};
	return {
		...d,
		pages: d.pages.map((p) => ({
			...p,
			orig: f(p.orig),
			src: f(p.src)
		}))
	};
}
//#endregion
export { inlineDoc as a, srcBytes as c, fpOf as i, unpackDoc as l, blobFor as n, packDoc as o, blobifyDoc as r, revokeDoc as s, adoptBlob as t };
