import { O as withStatus, _ as pageStatus, t as FILTER_LABEL } from "./db-CclUQaLE.mjs";
import { t as QUALITY_THRESHOLDS } from "./quality-B8m69IKS.mjs";
import { n as suggestFilter } from "./filter-suggest-C3Br7JC3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/batch-review-Be3azLyj.js
var TAB_LABEL = {
	all: "Tất cả",
	review: "Cần xem lại",
	manual: "Đã sửa tay"
};
var needsReview = (score) => score < 70;
/** Câu giải thích ngắn: vấn đề đo được → bộ lọc đang áp dụng, ví dụ “ảnh hơi tối → Làm sáng”. */
function decisionNote(m, filter) {
	const T = QUALITY_THRESHOLDS;
	const problem = suggestFilter(m)?.reason ?? (m.blur < T.BLUR_WARNING ? "ảnh hơi mờ" : (m.skew ?? 0) > T.SKEW_AUTO_FIX ? "ảnh nghiêng" : null);
	const dark = m.brightness < T.DARK_WARNING ? ` (độ sáng ${Math.round(m.brightness / 255 * 100)}%)` : "";
	return problem ? `${problem}${dark} → ${FILTER_LABEL[filter]}` : `ảnh ổn → ${FILTER_LABEL[filter]}`;
}
/** Chỉ số (theo vị trí gốc) của các trang thuộc thẻ lọc. Trang chưa đo điểm không bị coi là cần xem lại. */
function filterPages(pages, reviews, tab) {
	const out = [];
	pages.forEach((p, i) => {
		const r = reviews[p.id];
		if (tab === "all" || tab === "review" && r && needsReview(r.score) || tab === "manual" && p.manual) out.push(i);
	});
	return out;
}
/** Dấu ghi vào page.warnings khi máy chưa chắc mép giấy lúc chụp (trước: chỉ nằm trong state màn Chụp → mất khi bấm Xong). */
var EDGE_WARNING = "Máy chưa chắc mép giấy";
/** Chỉ số các trang cần xem lại: trạng thái "xem-lai", có cảnh báo lúc chụp, hoặc điểm chất lượng thấp (đã đo). */
function reviewTargets(pages, reviews = {}) {
	const out = [];
	pages.forEach((p, i) => {
		const r = reviews[p.id];
		if (pageStatus(p) === "xem-lai" || (p.warnings?.length ?? 0) > 0 || !p.manual && r && needsReview(r.score)) out.push(i);
	});
	return out;
}
function reviewReason(p, r) {
	if (p.warnings?.length) return p.warnings.join("; ");
	if (pageStatus(p) === "xem-lai") return "App chưa chắc khung cắt của trang này";
	if (r && needsReview(r.score)) return `Chất lượng thấp (${r.score}/100) — ${r.note}`;
	return "";
}
/** "Giữ nguyên": bỏ cảnh báo, trang xem-lai → xong. Không đổi ảnh. */
function markChecked(p) {
	const { warnings: _w, ...rest } = p;
	const q = rest;
	return pageStatus(q) === "xem-lai" ? withStatus(q, "xong") : q;
}
/** CS-07: ghi cùng một chỉnh sửa cho nhiều trang, không dựng ảnh (việc nền dựng sau). `ids` rỗng/thiếu = mọi trang. */
function applyEditToPages(pages, edit, ids) {
	return pages.map((p) => !ids || ids.has(p.id) ? applyEditQueued(p, edit) : p);
}
/**
* Sửa khung một trang mà không chờ dựng ảnh: ghi edit mới + trạng thái "dang" — bộ điều phối nền (healPending → việc "finish")
* dựng bản đầy đủ sau, người dùng sang trang kế ngay (tiêu chí "sửa 1 trang không chặn trang khác").
*/
function applyEditQueued(p, edit) {
	const { warnings: _w, ...rest } = p;
	let q = {
		...rest,
		edit: {
			...p.edit,
			...edit
		},
		manual: true
	};
	const s = pageStatus(q);
	if (s === "loi") q = withStatus(q, "cho");
	if (s === "moi") q = withStatus(q, "cho");
	return pageStatus(q) === "dang" ? q : withStatus(q, "dang");
}
//#endregion
export { decisionNote as a, needsReview as c, applyEditToPages as i, reviewReason as l, TAB_LABEL as n, filterPages as o, applyEditQueued as r, markChecked as s, EDGE_WARNING as t, reviewTargets as u };
