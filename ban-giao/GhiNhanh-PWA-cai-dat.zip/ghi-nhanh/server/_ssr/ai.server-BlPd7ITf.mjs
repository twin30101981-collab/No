import { AI_TIMEOUT_MS, aiEnv, errorCode, providerKey, runChain } from "./ai-chain.server-D7XpPXa2.mjs";
import { AI_LIMIT_WINDOW_MS, clientKey, createRateLimiter, limitFromEnv, limitedFail } from "./ai-limit-BeGU7SmX.mjs";
import { rt as jsonSchema } from "../_libs/@ai-sdk/gateway+[...].mjs";
import { t as createOpenAI } from "../_libs/ai-sdk__openai+zod.mjs";
import { n as streamText, t as output_exports } from "../_libs/ai.mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/ai.server-BlPd7ITf.js
var GATEWAY = "https://ai.gateway.lovable.dev/v1";
var MODEL = "openai/gpt-6-astra";
var RUN_ID = "X-Lovable-AIG-Run-ID";
function provider(apiKey) {
	let runId;
	return createOpenAI({
		baseURL: GATEWAY,
		apiKey,
		headers: {
			"Lovable-API-Key": apiKey,
			"X-Lovable-AIG-SDK": "vercel-ai-sdk"
		},
		fetch: async (input, init) => {
			const headers = new Headers(init?.headers);
			if (runId) headers.set(RUN_ID, runId);
			const res = await fetch(input, {
				...init,
				headers
			});
			runId ??= res.headers.get(RUN_ID) ?? void 0;
			return res;
		}
	});
}
var OPTS = { openai: {
	forceReasoning: true,
	reasoningEffort: "low",
	reasoningSummary: "auto",
	store: false,
	include: ["reasoning.encrypted_content"]
} };
/** Chuyển lỗi gateway thành thông báo tiếng Việt; không tự gửi lại. */
function toFail(e) {
	const err = e;
	const inner = err.lastError ?? err;
	const code = errorCode(e);
	let body = "";
	try {
		body = JSON.parse(inner.responseBody ?? "{}")?.message ?? "";
	} catch {}
	if (code === 402) return {
		ok: false,
		code,
		message: body || "Đã hết lượt AI miễn phí của tháng. Chủ ứng dụng cần nạp thêm để tiếp tục."
	};
	if (code === 429) return {
		ok: false,
		code,
		message: "AI đang quá tải. Hãy đợi khoảng một phút rồi thử lại."
	};
	if (code === 403) return {
		ok: false,
		code,
		message: body || "AI đang bị giới hạn cho ứng dụng này."
	};
	if (code === 401) return {
		ok: false,
		code,
		message: "AI chưa được cấu hình trên máy chủ."
	};
	if (code === 451) return {
		ok: false,
		code,
		message: "AI từ chối xử lý nội dung này. Hãy thử trang khác hoặc dùng xử lý trên máy."
	};
	if (code === 408) return {
		ok: false,
		code,
		message: "AI phản hồi quá lâu (quá 60 giây). Hãy thử lại sau."
	};
	if (code === 400) return {
		ok: false,
		code,
		message: "Ảnh quá lớn hoặc không hợp lệ. Hãy thử trang khác."
	};
	return {
		ok: false,
		code,
		message: "AI tạm thời không phản hồi. Hãy thử lại sau ít phút."
	};
}
var limiter = null;
async function aiGate() {
	limiter ??= createRateLimiter({
		limit: limitFromEnv(processModule.env["AI_RATE_LIMIT_PER_HOUR"]),
		windowMs: AI_LIMIT_WINDOW_MS
	});
	const { getRequest } = await import("./server-BYuUwks4.mjs").then((n) => n.i).then((n) => n.t);
	const k = clientKey(getRequest()?.headers);
	if (!k) return null;
	const r = limiter.hit(k);
	if (r.ok) return null;
	console.log("[ai-limit] vượt giới hạn, chặn 1 lượt");
	return limitedFail(r.retryAfterSec);
}
function key() {
	const k = processModule.env["LOVABLE_API_KEY"];
	if (!k) throw Object.assign(/* @__PURE__ */ new Error("no key"), { statusCode: 401 });
	return k;
}
var COMPAT = {
	mistral: {
		baseURL: "https://api.mistral.ai/v1",
		modelEnv: "MISTRAL_MODEL",
		model: "mistral-medium-latest"
	},
	gemini: {
		baseURL: "https://generativelanguage.googleapis.com/v1beta/openai",
		modelEnv: "GEMINI_MODEL",
		model: "gemini-flash-latest"
	}
};
function modelFor(p) {
	if (p === "lovable") return provider(key()).responses(MODEL);
	const c = COMPAT[p];
	const env = aiEnv(), base = env[`${p.toUpperCase()}_BASE_URL`];
	return createOpenAI({
		baseURL: base || c.baseURL,
		apiKey: providerKey(p)
	}).chat(env[c.modelEnv] || c.model);
}
/** Nội dung người dùng (chữ + ảnh data URL) → phần nhập của Claude. */
function claudeParts(messages) {
	const out = [];
	for (const m of messages) {
		if (m.role !== "user") continue;
		if (typeof m.content === "string") {
			out.push({
				type: "text",
				text: m.content
			});
			continue;
		}
		for (const part of m.content) if (part.type === "text") out.push({
			type: "text",
			text: part.text
		});
		else if (part.type === "file" && typeof part.data === "string") out.push({
			type: "image",
			dataUrl: part.data
		});
	}
	return out;
}
async function runOne(p, req, schema) {
	if (p === "claude") {
		const { claudeGenerate } = await import("./ai-claude.server-pfj-bkxq.mjs");
		const js = schema ? await schema.jsonSchema : void 0;
		const txt = await claudeGenerate({
			system: req.instructions,
			parts: claudeParts(req.messages),
			schema: js,
			apiKey: providerKey("claude"),
			model: aiEnv()["ANTHROPIC_MODEL"]
		});
		return schema ? JSON.parse(txt) : txt;
	}
	let failure;
	const base = {
		model: modelFor(p),
		instructions: req.instructions,
		messages: req.messages,
		abortSignal: AbortSignal.timeout(AI_TIMEOUT_MS),
		onError: ({ error }) => {
			failure = error;
		},
		...p === "lovable" ? { providerOptions: OPTS } : {}
	};
	try {
		if (schema) return await streamText({
			...base,
			output: output_exports.object({ schema })
		}).output;
		const t = await streamText(base).text;
		if (failure) throw failure;
		return t;
	} catch (e) {
		throw failure ?? e;
	}
}
/** Đầu ra JSON theo schema qua chuỗi nguồn. */
async function genObject(task, req, schema) {
	return runChain(task, (p) => runOne(p, req, schema), { sensitive: req.sensitive });
}
/** AI-04: nút "Kiểm tra" — gọi đúng MỘT nguồn bằng câu hỏi rất ngắn (vài token). */
async function pingProvider(p) {
	return runChain(`ping:${p}`, (q) => runOne(q, {
		instructions: "Trả lời đúng một từ: OK",
		messages: [{
			role: "user",
			content: [{
				type: "text",
				text: "OK?"
			}]
		}]
	}), { sensitive: false }, {
		...aiEnv(),
		AI_PROVIDERS: p
	});
}
/** Đầu ra chữ qua chuỗi nguồn. */
async function genText(task, req) {
	return runChain(task, (p) => runOne(p, req), { sensitive: req.sensitive });
}
var filePart = (url) => ({
	type: "file",
	data: url,
	mediaType: url.slice(5, url.indexOf(";")) || "image/jpeg"
});
var DOC_TYPES = [
	"Hoá đơn",
	"CCCD/Hộ chiếu",
	"Hợp đồng",
	"Biên lai",
	"Biên bản",
	"Báo cáo",
	"Công văn",
	"Đơn từ",
	"Sao kê/Chứng từ ngân hàng",
	"Danh thiếp",
	"Giấy đăng ký xe",
	"Sổ đỏ",
	"Ghi chú",
	"Khác"
];
var EXTRACT_SCHEMA = jsonSchema({
	type: "object",
	additionalProperties: false,
	required: [
		"type",
		"title",
		"summary",
		"keyPoints",
		"confidence",
		"fields",
		"tags"
	],
	properties: {
		type: {
			type: "string",
			enum: [...DOC_TYPES]
		},
		title: { type: "string" },
		summary: { type: "string" },
		keyPoints: {
			type: "array",
			items: { type: "string" }
		},
		confidence: { type: "number" },
		fields: {
			type: "array",
			items: {
				type: "object",
				additionalProperties: false,
				required: ["label", "value"],
				properties: {
					label: { type: "string" },
					value: { type: "string" }
				}
			}
		},
		tags: {
			type: "array",
			items: { type: "string" }
		}
	}
});
async function extractFromImages(images, template) {
	const { templateById, templatePrompt } = await import("./vn-templates-Br-nZelc.mjs").then((n) => n.s);
	const tpl = templateById(template);
	return genObject("extractFromImages", {
		instructions: `Bạn đọc ảnh tài liệu đã quét và trích thông tin quan trọng bằng tiếng Việt.
- type: một trong ${DOC_TYPES.join(", ")}.
- title: tên ngắn gọn cho tài liệu (tối đa 60 ký tự), ví dụ "Hoá đơn Điện lực 09/2026".
- summary: một câu tóm tắt.
- keyPoints: 3–6 ý chính ngắn gọn của nội dung (ai, việc gì, khi nào, con số, kết luận).
- confidence: độ chắc chắn về loại tài liệu, từ 0 đến 1.
- fields: các trường theo loại. Hoá đơn/Biên lai: Số tiền, Ngày, Bên bán, Bên mua, Số hoá đơn, Mã số thuế. CCCD/Hộ chiếu: Họ tên, Số giấy tờ, Ngày sinh, Giới tính, Quê quán, Ngày hết hạn. Hợp đồng: Các bên, Ngày ký, Thời hạn, Giá trị. Danh thiếp: Họ tên, Chức vụ, Công ty, Điện thoại, Email, Địa chỉ. Chỉ đưa trường thấy rõ trong ảnh, giữ nguyên số và định dạng.
- tags: 1–3 thẻ ngắn gợi ý (ví dụ "Điện", "Công việc").${tpl ? templatePrompt(tpl) : ""}`,
		messages: [{
			role: "user",
			content: [{
				type: "text",
				text: "Trích xuất thông tin từ (các) trang sau."
			}, ...images.map(filePart)]
		}]
	}, EXTRACT_SCHEMA);
}
var TASK_PROMPT = {
	translate: "Dịch nội dung sang {lang}. Giữ định dạng dòng. Chỉ trả về bản dịch.",
	summarize: "Tóm tắt nội dung bằng tiếng Việt: một đoạn ngắn rồi 3–6 gạch đầu dòng ý chính.",
	handwrite: "Ảnh chứa chữ viết tay (tiếng Việt hoặc ngoại ngữ). Chép lại nguyên văn, đủ dấu tiếng Việt, giữ xuống dòng và gạch đầu dòng như trong ảnh. Không sửa lỗi chính tả, không thêm lời bình. Chữ không đọc được ghi ⟦?⟧. Chỉ trả về văn bản đã chép.",
	solve: "Đây là bài tập. Giải từng bước rõ ràng bằng tiếng Việt, ghi đáp số cuối cùng. Dùng văn bản thuần, không dùng LaTeX."
};
async function runTextTask(task, input) {
	const content = [{
		type: "text",
		text: input.text ? `Nội dung:\n${input.text}` : "Nội dung nằm trong ảnh."
	}, ...(input.images ?? []).map(filePart)];
	return genText("runTextTask", {
		instructions: TASK_PROMPT[task].replace("{lang}", input.lang ?? "tiếng Anh"),
		messages: [{
			role: "user",
			content
		}]
	});
}
jsonSchema({
	type: "object",
	additionalProperties: false,
	required: ["title", "rows"],
	properties: {
		title: { type: "string" },
		rows: {
			type: "array",
			items: {
				type: "array",
				items: { type: "string" }
			}
		}
	}
});
var ROWS_SCHEMA = jsonSchema({
	type: "object",
	additionalProperties: false,
	required: ["title", "rows"],
	properties: {
		title: { type: "string" },
		rows: {
			type: "array",
			items: {
				type: "object",
				additionalProperties: false,
				required: ["y", "cells"],
				properties: {
					y: { type: "number" },
					cells: {
						type: "array",
						items: {
							type: "object",
							additionalProperties: false,
							required: [
								"x0",
								"x1",
								"text"
							],
							properties: {
								x0: { type: "number" },
								x1: { type: "number" },
								text: { type: "string" }
							}
						}
					}
				}
			}
		}
	}
});
/** Đọc ảnh gốc (không xoay) theo từng dòng, mỗi ô kèm toạ độ ngang để ghép cột ở phía máy. */
async function rowsFromImages(images) {
	return genObject("rowsFromImages", {
		instructions: `Bạn chép lại bảng (hoặc chữ) trong ảnh theo TỪNG DÒNG, mỗi ô kèm vị trí ngang.
- Đọc theo đúng chiều của chữ, kể cả khi ảnh nằm ngang hay ngược. Toạ độ tính theo chiều đọc đó: x0, x1 là mép trái/phải của ô, y là vị trí dọc của dòng, cùng thang 0–1000.
- Một ô = một vùng giữa hai đường kẻ dọc (hoặc một nhóm chữ tách biệt nếu bảng không kẻ). x0/x1 là mép ô (đường kẻ), không phải mép chữ.
- Ô gộp (ví dụ "DƯ NỢ" phủ nhiều cột) là MỘT ô với x0/x1 trải hết các cột nó phủ.
- Không ghi ô trống. NGOẠI LỆ BẮT BUỘC: ô chỉ có một dấu "-" (hoặc "–") KHÔNG phải ô trống — luôn ghi thành một ô text "-" với x0/x1 của ô đó, kể cả ở cột Đầu năm/đầu kỳ. Giữ nguyên chữ và số (dấu chấm hàng nghìn kiểu Việt Nam, số trong ngoặc "(98.855)").
- Dấu "-" nằm cùng ô với số là dấu âm: ghi chung trong text của ô đó. Không ghép dấu "-" của ô này với số của ô bên cạnh.
- Giữ hàng tổng/nhóm. Chữ/số đọc chưa chắc: ghi giá trị đoán tốt nhất rồi thêm "⟦?⟧" cuối ô.
- title: tên ngắn cho bảng (tối đa 40 ký tự).`,
		messages: [{
			role: "user",
			content: [{
				type: "text",
				text: "Chép bảng trong ảnh theo từng dòng kèm toạ độ ô."
			}, ...images.map(filePart)]
		}]
	}, ROWS_SCHEMA);
}
var LAYOUT_SCHEMA = jsonSchema({
	type: "object",
	additionalProperties: false,
	required: ["title", "blocks"],
	properties: {
		title: { type: "string" },
		blocks: {
			type: "array",
			items: {
				type: "object",
				additionalProperties: false,
				required: [
					"kind",
					"level",
					"text",
					"align",
					"bold",
					"rows"
				],
				properties: {
					kind: {
						type: "string",
						enum: [
							"heading",
							"paragraph",
							"bullet",
							"number",
							"table"
						]
					},
					level: { type: "number" },
					text: { type: "string" },
					align: {
						type: "string",
						enum: [
							"left",
							"center",
							"right",
							"justify"
						]
					},
					bold: { type: "boolean" },
					rows: {
						type: "array",
						items: {
							type: "array",
							items: { type: "string" }
						}
					}
				}
			}
		}
	}
});
/** Đọc bố cục trang (tiêu đề, đoạn, danh sách, bảng) để dựng tệp Word. */
async function layoutFromImages(images) {
	return genObject("layoutFromImages", {
		instructions: `Bạn chép lại toàn bộ nội dung ảnh tài liệu thành các khối theo đúng thứ tự đọc, giữ nguyên chữ, dấu tiếng Việt và số.
- heading: tiêu đề/đề mục, level 1 cho tiêu đề chính, 2–3 cho mục con. Quốc hiệu, tên cơ quan, tên văn bản thường căn giữa (align "center").
- paragraph: một đoạn văn liền (nối các dòng bị ngắt trong cùng đoạn), align "justify" cho thân văn bản, "right" cho ngày tháng/chữ ký nếu nằm bên phải.
- bullet / number: từng mục danh sách, bỏ ký hiệu đầu dòng.
- table: mọi bảng, rows hàng đầu là tiêu đề cột, các hàng cùng số cột, ô trống "".
- Các trường không dùng: level 1, text "", rows [], bold false. Không thêm nội dung không có trong ảnh.
- Chữ/số nào đọc chưa chắc (mờ, che, nhoè): ghi giá trị đoán tốt nhất rồi thêm "⟦?⟧" ngay sau từ/ô đó.
- title: tên ngắn cho tài liệu (tối đa 60 ký tự).`,
		messages: [{
			role: "user",
			content: [{
				type: "text",
				text: "Chuyển (các) trang sau thành văn bản Word giữ bố cục."
			}, ...images.map(filePart)]
		}]
	}, LAYOUT_SCHEMA);
}
/** Trả lời câu hỏi về tài liệu từ các đoạn đã chọn (doc-qa.ts), kèm trích dẫn trang. */
async function answerDocQuestion(question, context) {
	const answer = (await genText("answerDocQuestion", {
		instructions: `Bạn là trợ lý trả lời câu hỏi về một tài liệu đã quét. Ngữ cảnh gồm các đoạn chữ đọc được, mỗi đoạn bắt đầu bằng [Trang N].
- Chỉ trả lời từ ngữ cảnh; không suy đoán ngoài tài liệu.
- Mỗi ý trả lời phải ghi trang nguồn dạng [Trang N] (nhiều trang: [Trang 1, 3]).
- Không tìm thấy trong ngữ cảnh: nói rõ "Tài liệu không ghi phần này" và gợi ý cách hỏi khác nếu hợp lý.
- Trả lời ngắn gọn bằng tiếng Việt, văn bản thuần, giữ nguyên số liệu/dấu câu như tài liệu.`,
		messages: [{
			role: "user",
			content: [{
				type: "text",
				text: `Câu hỏi: ${question}\n\nNgữ cảnh:\n${context}`
			}]
		}]
	})).trim();
	const { citedPages } = await import("./doc-qa-DibGoYZN.mjs");
	return {
		answer,
		pages: citedPages(answer)
	};
}
var CLASSIFY_SCHEMA = jsonSchema({
	type: "object",
	additionalProperties: false,
	required: [
		"title",
		"type",
		"tags",
		"confidence"
	],
	properties: {
		title: { type: "string" },
		type: {
			type: "string",
			enum: [...DOC_TYPES]
		},
		tags: {
			type: "array",
			items: { type: "string" }
		},
		confidence: { type: "number" }
	}
});
/** G3-12: đặt tên ngắn + phân loại tài liệu vừa quét (nhẹ hơn trích xuất đầy đủ). */
async function classifyImages(images) {
	return genObject("classifyImages", {
		instructions: `Bạn xem ảnh tài liệu vừa quét và đặt tên, phân loại bằng tiếng Việt.
- title: tên ngắn gọn, cụ thể (tối đa 60 ký tự), gồm loại + bên liên quan + kỳ/ngày nếu thấy, ví dụ "Hoá đơn Điện lực 09/2026", "Hợp đồng thuê nhà Nguyễn Văn A". Không ghi số giấy tờ tuỳ thân đầy đủ.
- type: một trong ${DOC_TYPES.join(", ")}.
- tags: 0–3 thẻ ngắn (1–2 từ), ví dụ "Điện", "Nhà", "Công việc".
- confidence: độ chắc chắn 0–1.`,
		messages: [{
			role: "user",
			content: [{
				type: "text",
				text: "Đặt tên và phân loại tài liệu này."
			}, ...images.map(filePart)]
		}]
	}, CLASSIFY_SCHEMA);
}
/** G3-14: dịch từng khối chữ, trả mảng cùng thứ tự và độ dài. */
async function translateBlocks(texts, lang) {
	const schema = jsonSchema({
		type: "object",
		additionalProperties: false,
		required: ["items"],
		properties: { items: {
			type: "array",
			items: { type: "string" }
		} }
	});
	return (await genObject("translateBlocks", {
		instructions: `Dịch từng mục trong danh sách sang ${lang}. Trả về items có đúng ${texts.length} phần tử, cùng thứ tự. Giữ xuống dòng, số liệu, tên riêng; mục không cần dịch thì giữ nguyên. Bản dịch ngắn gọn để vừa khung chữ gốc.`,
		messages: [{
			role: "user",
			content: [{
				type: "text",
				text: JSON.stringify(texts)
			}]
		}]
	}, schema)).items;
}
/** G3-16: nhờ mô hình ảnh thay nền bằng màu xanh lục thuần (#00FF00), giữ nguyên người; client tách mặt nạ bằng khoá màu. */
async function greenScreenPerson(image) {
	const res = await fetch(`${GATEWAY}/chat/completions`, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${key()}`
		},
		body: JSON.stringify({
			model: "google/gemini-3.1-flash-image",
			modalities: ["image", "text"],
			messages: [{
				role: "user",
				content: [{
					type: "text",
					text: "Ảnh chân dung để làm ảnh thẻ. Giữ NGUYÊN người (mặt, tóc, quần áo, tư thế, khung hình, kích thước) không chỉnh sửa gì. Chỉ thay toàn bộ nền phía sau bằng một màu xanh lục thuần #00FF00 phẳng, không bóng, không viền. Tóc phải tách gọn khỏi nền."
				}, {
					type: "image_url",
					image_url: { url: image }
				}]
			}]
		})
	});
	if (!res.ok) throw Object.assign(/* @__PURE__ */ new Error("image gateway"), {
		statusCode: res.status,
		responseBody: await res.text()
	});
	const url = (await res.json()).choices?.[0]?.message?.images?.[0]?.image_url?.url;
	if (!url?.startsWith("data:image/")) throw Object.assign(/* @__PURE__ */ new Error("no image"), { statusCode: 500 });
	return url;
}
/** G3-18: đọc hoá đơn/biên lai — tên cửa hàng, tổng tiền phải trả, ngày, nhóm chi tiêu. */
async function receiptFromImage(image) {
	const schema = jsonSchema({
		type: "object",
		additionalProperties: false,
		required: [
			"merchant",
			"total",
			"date",
			"category",
			"confidence"
		],
		properties: {
			merchant: { type: "string" },
			total: { type: "string" },
			date: { type: "string" },
			category: {
				type: "string",
				enum: [
					"Ăn uống",
					"Đi lại",
					"Mua sắm",
					"Điện nước",
					"Y tế",
					"Giáo dục",
					"Khác"
				]
			},
			confidence: { type: "number" }
		}
	});
	return genObject("receiptFromImage", {
		instructions: `Bạn đọc ảnh hoá đơn/biên lai Việt Nam.
- merchant: tên cửa hàng/đơn vị bán (ngắn).
- total: TỔNG SỐ TIỀN PHẢI THANH TOÁN cuối cùng (sau giảm giá, đã gồm VAT), chép đúng chữ số như trên giấy, ví dụ "1.234.500". Không lấy tiền khách đưa hay tiền thối. Không thấy thì để "".
- date: ngày trên hoá đơn dạng dd/mm/yyyy; không thấy thì "".
- category: nhóm chi tiêu phù hợp nhất.
- confidence: độ chắc chắn 0–1 về total và date.`,
		messages: [{
			role: "user",
			content: [{
				type: "text",
				text: "Đọc hoá đơn này."
			}, filePart(image)]
		}]
	}, schema);
}
async function paperCornersFromImage(image) {
	const schema = jsonSchema({
		type: "object",
		additionalProperties: false,
		required: [
			"found",
			"corners",
			"confidence"
		],
		properties: {
			found: { type: "boolean" },
			confidence: { type: "number" },
			corners: {
				type: "array",
				items: {
					type: "object",
					additionalProperties: false,
					required: ["x", "y"],
					properties: {
						x: { type: "number" },
						y: { type: "number" }
					}
				}
			}
		}
	});
	return genObject("paperCornersFromImage", {
		instructions: `Tìm tờ giấy/tài liệu/thẻ chính trong ảnh. Trả 4 góc của tờ giấy (không phải khung chữ) theo toạ độ 0–1000 so với chiều rộng (x) và chiều cao (y) ảnh, gốc ở góc trên trái. Nếu nhiều tờ giấy chồng lên nhau, chọn tờ nằm trên cùng ở giữa ảnh; mép của nó thường là một vạch mờ hoặc bóng nhẹ giữa hai vùng trắng. Bỏ qua dòng chữ, bảng, chữ ký và dấu thời gian của điện thoại in trên ảnh. Góc bị che hoặc lệch khỏi ảnh thì ước lượng theo phần mép còn thấy (được phép hơi ra ngoài 0–1000). Không thấy tờ giấy rõ ràng thì found=false, corners=[]. confidence 0–1.`,
		messages: [{
			role: "user",
			content: [{
				type: "text",
				text: "Tìm 4 góc tờ giấy."
			}, filePart(image)]
		}]
	}, schema);
}
var crit = () => ({
	type: "object",
	additionalProperties: false,
	required: ["score", "note"],
	properties: {
		score: { type: "number" },
		note: { type: "string" }
	}
});
var PHOTO_SCHEMA = jsonSchema({
	type: "object",
	additionalProperties: false,
	required: [
		"overall",
		"verdict",
		"sharpness",
		"lighting",
		"glare",
		"angle",
		"tips"
	],
	properties: {
		overall: { type: "number" },
		verdict: { type: "string" },
		sharpness: crit(),
		lighting: crit(),
		glare: crit(),
		angle: crit(),
		tips: {
			type: "array",
			items: { type: "string" }
		}
	}
});
/** Đánh giá chất lượng ảnh chụp tài liệu và gợi ý cách chụp lại. */
async function checkDocPhoto(image) {
	return genObject("checkDocPhoto", {
		instructions: `Bạn là chuyên gia chụp tài liệu. Chấm ảnh tài liệu theo thang 0–10 (10 là tốt nhất) bằng tiếng Việt:
- sharpness: độ rõ nét của chữ (mờ, rung tay, lệch nét).
- lighting: ánh sáng đủ và đều (quá tối, quá sáng, bóng đổ của tay/điện thoại).
- glare: mức KHÔNG bị chói/loá (10 = không có điểm loá; thấp = có vệt phản chiếu che chữ).
- angle: góc chụp (10 = chụp thẳng từ trên xuống, giấy vuông vức, đủ 4 góc trong khung).
Mỗi mục có note: một câu ngắn nêu vấn đề cụ thể thấy trong ảnh (vị trí nếu có).
- overall: điểm tổng 0–10. verdict: một câu kết luận (dùng được hay nên chụp lại).
- tips: 2–5 hướng dẫn hành động cụ thể để chụp lại tốt hơn, ưu tiên vấn đề nặng nhất trước. Nếu ảnh đã tốt, tips nêu cách giữ chất lượng.`,
		messages: [{
			role: "user",
			content: [{
				type: "text",
				text: "Đánh giá ảnh chụp tài liệu này."
			}, filePart(image)]
		}]
	}, PHOTO_SCHEMA);
}
/** S12 – chẩn đoán 4 nhóm lỗi ảnh quét, có vùng đánh dấu (toạ độ 0–1) và độ tin cậy. */
var DIAG_SCHEMA = jsonSchema({
	type: "object",
	additionalProperties: false,
	required: ["summary", "issues"],
	properties: {
		summary: { type: "string" },
		issues: {
			type: "array",
			items: {
				type: "object",
				additionalProperties: false,
				required: [
					"group",
					"severity",
					"confidence",
					"note",
					"regions"
				],
				properties: {
					group: {
						type: "string",
						enum: [
							"shadow",
							"edge_noise",
							"cut_text",
							"skew"
						]
					},
					severity: { type: "number" },
					confidence: { type: "number" },
					note: { type: "string" },
					regions: {
						type: "array",
						items: {
							type: "object",
							additionalProperties: false,
							required: [
								"x",
								"y",
								"w",
								"h"
							],
							properties: {
								x: { type: "number" },
								y: { type: "number" },
								w: { type: "number" },
								h: { type: "number" }
							}
						}
					}
				}
			}
		}
	}
});
async function diagnoseScan(image) {
	return genObject("diagnoseScan", {
		instructions: `Bạn kiểm tra chất lượng ảnh tài liệu ĐÃ QUÉT (đã cắt, nắn). Chỉ báo 4 nhóm lỗi:
- shadow: bóng xám/vệt tối (thường ở góc).
- edge_noise: rác điểm ảnh, chấm đen, vạch ở mép.
- cut_text: chữ bị cắt mất ở mép.
- skew: dòng chữ còn cong/nghiêng.
Mỗi lỗi: severity 0–1, confidence 0–1, note một câu tiếng Việt KHÔNG chép nội dung tài liệu, regions là hộp x,y,w,h theo tỉ lệ 0–1 của ảnh. Không có lỗi thì issues rỗng. summary một câu.`,
		messages: [{
			role: "user",
			content: [{
				type: "text",
				text: "Chẩn đoán ảnh quét này."
			}, filePart(image)]
		}]
	}, DIAG_SCHEMA);
}
//#endregion
export { aiGate, answerDocQuestion, checkDocPhoto, classifyImages, diagnoseScan, extractFromImages, greenScreenPerson, layoutFromImages, paperCornersFromImage, pingProvider, receiptFromImage, rowsFromImages, runTextTask, toFail, translateBlocks };
