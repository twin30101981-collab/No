import { o as __toESM } from "../_runtime.mjs";
import { T as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { i as showError } from "./errors-DKvrPJ4v.mjs";
import { N as RotateCcw, Zt as Camera, j as Ruler, l as Undo2, ot as ImagePlus, r as X } from "../_libs/lucide-react.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { j as normalize } from "./image-DFWRNlNd.mjs";
import { n as pickFiles } from "./importer-BUHDogNt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/measure-DkZYRLnx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var REFS = [
	{
		id: "card",
		label: "Thẻ CCCD (cạnh dài)",
		mm: 85.6
	},
	{
		id: "a4w",
		label: "A4 (cạnh ngắn)",
		mm: 210
	},
	{
		id: "a4h",
		label: "A4 (cạnh dài)",
		mm: 297
	},
	{
		id: "coin",
		label: "Đồng xu 5.000đ",
		mm: 25.5
	},
	{
		id: "custom",
		label: "Tự nhập",
		mm: 0
	}
];
var dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
var fmt = (mm) => mm >= 1e3 ? `${(mm / 1e3).toFixed(2)} m` : mm >= 100 ? `${(mm / 10).toFixed(1)} cm` : `${mm.toFixed(1)} mm`;
function Measure() {
	const navigate = useNavigate();
	const [img, setImg] = (0, import_react.useState)(null);
	const [refId, setRefId] = (0, import_react.useState)("card");
	const [customMm, setCustomMm] = (0, import_react.useState)("100");
	const [pts, setPts] = (0, import_react.useState)([]);
	const canvas = (0, import_react.useRef)(null);
	const image = (0, import_react.useRef)(null);
	const refMm = refId === "custom" ? Number(customMm.replace(",", ".")) || 0 : REFS.find((r) => r.id === refId).mm;
	const scale = pts.length >= 2 && refMm > 0 ? refMm / dist(pts[0], pts[1]) : 0;
	const results = [];
	for (let i = 2; i + 1 < pts.length; i += 2) results.push(dist(pts[i], pts[i + 1]) * scale);
	const load = async (fromCamera) => {
		try {
			const [f] = await pickFiles("image/*", false, fromCamera ? "environment" : void 0);
			if (!f) return;
			setImg(await normalize(f, 1600));
			setPts([]);
		} catch (e) {
			showError(e, "Không mở được ảnh");
		}
	};
	(0, import_react.useEffect)(() => {
		if (!img) return;
		const el = new Image();
		el.onload = () => {
			image.current = el;
			draw();
		};
		el.src = img;
	}, [img]);
	(0, import_react.useEffect)(() => draw(), [pts, refMm]);
	function draw() {
		const c = canvas.current, el = image.current;
		if (!c || !el) return;
		c.width = el.naturalWidth;
		c.height = el.naturalHeight;
		const ctx = c.getContext("2d");
		ctx.drawImage(el, 0, 0);
		const u = Math.max(c.width, c.height) / 400;
		const css = getComputedStyle(document.documentElement);
		const accent = css.getPropertyValue("--primary").trim() || "currentColor";
		const warn = css.getPropertyValue("--destructive").trim() || "currentColor";
		const segs = [];
		for (let i = 0; i < pts.length; i += 2) {
			const label = i === 0 ? `Mẫu ${fmt(refMm)}` : scale ? fmt(results[i / 2 - 1] ?? 0) : "";
			segs.push([
				pts[i],
				pts[i + 1],
				i === 0 ? warn : accent,
				label
			]);
		}
		for (const [a, b, col, label] of segs) {
			ctx.strokeStyle = col;
			ctx.fillStyle = col;
			ctx.lineWidth = 2.5 * u;
			if (b) {
				ctx.beginPath();
				ctx.moveTo(a.x, a.y);
				ctx.lineTo(b.x, b.y);
				ctx.stroke();
			}
			for (const p of [a, b]) if (p) {
				ctx.beginPath();
				ctx.arc(p.x, p.y, 5 * u, 0, Math.PI * 2);
				ctx.fill();
			}
			if (b && label) {
				ctx.font = `bold ${14 * u}px sans-serif`;
				const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2, w = ctx.measureText(label).width + 12 * u;
				ctx.fillRect(mx - w / 2, my - 22 * u, w, 18 * u);
				ctx.fillStyle = css.getPropertyValue("--primary-foreground").trim() || "white";
				ctx.textAlign = "center";
				ctx.fillText(label, mx, my - 8 * u);
			}
		}
	}
	const tap = (e) => {
		const c = e.currentTarget, r = c.getBoundingClientRect();
		setPts((p) => [...p, {
			x: (e.clientX - r.left) / r.width * c.width,
			y: (e.clientY - r.top) / r.height * c.height
		}]);
		navigator.vibrate?.(10);
	};
	const hint = pts.length < 2 ? `Bước 1: chạm 2 đầu của vật mẫu (${pts.length}/2)` : refMm <= 0 ? "Nhập độ dài vật mẫu để tính" : pts.length % 2 === 0 ? "Bước 2: chạm 2 đầu của vật cần đo" : "Chạm điểm cuối của vật cần đo";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-dvh bg-background text-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh max-w-[430px] flex-col px-4 pb-8 pt-[max(1rem,env(safe-area-inset-top))]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": "Đóng",
					onClick: () => navigate({ to: "/tools" }),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-lg font-semibold",
					children: "Đo độ dài"
				})]
			}), !img ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-[18px] bg-secondary p-4 text-sm leading-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ruler, { className: "size-4 text-primary" }), " Cách đo"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-2 list-decimal space-y-1 pl-5 text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Đặt một vật mẫu (thẻ CCCD, tờ A4…) nằm sát cạnh vật cần đo, cùng mặt phẳng." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Chụp thẳng từ trên xuống, không nghiêng." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Chạm 2 đầu vật mẫu, rồi chạm 2 đầu vật cần đo." })
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "h-14",
						onClick: () => load(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {}), " Chụp ảnh"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						className: "h-14",
						onClick: () => load(false),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {}), " Chọn ảnh"]
					})]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-3 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-xs font-semibold text-muted-foreground",
						children: ["Vật mẫu", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: refId,
							onChange: (e) => setRefId(e.target.value),
							className: "mt-1 h-10 w-full rounded-lg border border-input bg-background px-2 text-sm text-foreground",
							children: REFS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: r.id,
								children: [r.label, r.mm ? ` — ${r.mm} mm` : ""]
							}, r.id))
						})]
					}),
					refId === "custom" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-xs font-semibold text-muted-foreground",
						children: ["Độ dài vật mẫu (mm)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							inputMode: "decimal",
							value: customMm,
							onChange: (e) => setCustomMm(e.target.value),
							className: "mt-1 h-10 w-full rounded-lg border border-input bg-background px-2 text-sm text-foreground"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-lg bg-secondary px-3 py-2 text-sm font-medium",
						children: hint
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
						ref: canvas,
						onPointerDown: tap,
						className: "w-full touch-none rounded-[14px]"
					}),
					results.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1 rounded-[14px] bg-card p-3 text-sm",
						children: results.map((mm, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: ["Số đo ", i + 1]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmt(mm) })]
						}, i))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "secondary",
								disabled: !pts.length,
								onClick: () => setPts((p) => p.slice(0, -1)),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, {}), " Hoàn tác"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "secondary",
								disabled: !pts.length,
								onClick: () => setPts([]),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), " Đo lại"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "secondary",
								onClick: () => load(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {}), " Ảnh mới"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Kết quả ước lượng, sai số khoảng 2–5% tuỳ góc chụp. Ảnh không được lưu."
					}),
					results.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "w-full",
						onClick: () => {
							navigator.clipboard?.writeText(results.map((m, i) => `Số đo ${i + 1}: ${fmt(m)}`).join("\n"));
							toast.success("Đã sao chép số đo");
						},
						children: "Sao chép kết quả"
					})
				]
			})]
		})
	});
}
//#endregion
export { Measure as component };
