import { t as safeSet } from "./safe-storage-DnXnZPA0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/receipt-aj8VqILp.js
var CATEGORIES = [
	"Ăn uống",
	"Đi lại",
	"Mua sắm",
	"Điện nước",
	"Y tế",
	"Giáo dục",
	"Khác"
];
/** "1.234.500đ", "1,234,500 VND", "125.000,50" → số đồng (làm tròn). Không đọc được → null. */
function parseAmount(s) {
	const t = s.replace(/[^\d.,-]/g, "");
	if (!/\d/.test(t)) return null;
	let n;
	const lastDot = t.lastIndexOf("."), lastComma = t.lastIndexOf(",");
	const last = Math.max(lastDot, lastComma);
	const tail = last >= 0 ? t.length - last - 1 : 0;
	if (last >= 0 && tail > 0 && tail <= 2 && lastDot !== -1 && lastComma !== -1) n = t.slice(0, last).replace(/[.,]/g, "") + "." + t.slice(last + 1);
	else if (last >= 0 && tail > 0 && tail <= 2 && t.split(t[last]).length === 2) n = t.slice(0, last).replace(/[.,]/g, "") + "." + t.slice(last + 1);
	else n = t.replace(/[.,]/g, "");
	const v = Number(n);
	return Number.isFinite(v) && v >= 0 ? Math.round(v) : null;
}
/** Ngày dạng dd/mm/yyyy, d-m-yy, yyyy-mm-dd → "yyyy-mm-dd"; sai → "". */
function parseDate(s) {
	const pad = (x) => String(x).padStart(2, "0");
	const ok = (y, m, d) => {
		const dt = new Date(Date.UTC(y, m - 1, d));
		return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d && y >= 2e3 && y <= 2100 ? `${y}-${pad(m)}-${pad(d)}` : "";
	};
	let m = s.match(/(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
	if (m) return ok(+m[1], +m[2], +m[3]);
	m = s.match(/(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})/);
	if (m) {
		let y = +m[3];
		if (y < 100) y += 2e3;
		return ok(y, +m[2], +m[1]);
	}
	return "";
}
function formatVnd(n) {
	return n.toLocaleString("vi-VN") + " ₫";
}
function normalizeReceipt(a) {
	const total = parseAmount(a.total);
	const date = parseDate(a.date);
	const category = CATEGORIES.includes(a.category) ? a.category : "Khác";
	return {
		merchant: a.merchant.trim().slice(0, 80),
		total,
		date,
		category,
		unsure: total === null || !date || a.confidence < .6
	};
}
var KEY = "gn-receipts";
function loadReceipts() {
	try {
		return JSON.parse(localStorage.getItem(KEY) ?? "[]");
	} catch {
		return [];
	}
}
function saveReceipts(list) {
	safeSet(KEY, JSON.stringify(list));
}
/** Tổng theo tháng "yyyy-mm". */
function monthTotals(list) {
	const m = /* @__PURE__ */ new Map();
	for (const r of list) {
		const k = r.date.slice(0, 7) || "Không rõ";
		const v = m.get(k) ?? {
			total: 0,
			count: 0
		};
		v.total += r.total;
		v.count++;
		m.set(k, v);
	}
	return [...m].map(([month, v]) => ({
		month,
		...v
	})).sort((a, b) => b.month.localeCompare(a.month));
}
var dmy = (iso) => iso ? iso.split("-").reverse().join("/") : "";
/** G3-19: sổ chi tiêu → các trang Excel: "Tổng hợp" (tháng × nhóm) + một trang mỗi tháng. `months` rỗng = tất cả. */
function expenseSheets(list, months = []) {
	const pick = list.filter((r) => !months.length || months.includes(r.date.slice(0, 7)));
	const ms = monthTotals(pick).map((m) => m.month).sort();
	const cats = CATEGORIES.filter((c) => pick.some((r) => r.category === c));
	const sum = (rs) => String(rs.reduce((a, r) => a + r.total, 0));
	const summary = [[
		"Tháng",
		"Số hoá đơn",
		...cats,
		"Tổng"
	], ...ms.map((m) => {
		const rs = pick.filter((r) => r.date.slice(0, 7) === m);
		return [
			m.split("-").reverse().join("/"),
			String(rs.length),
			...cats.map((c) => sum(rs.filter((r) => r.category === c))),
			sum(rs)
		];
	})];
	const per = ms.map((m) => ({
		name: `Tháng ${m.slice(5)}-${m.slice(0, 4)}`,
		totals: true,
		rows: [[
			"Ngày",
			"Cửa hàng",
			"Nhóm",
			"Số tiền"
		], ...pick.filter((r) => r.date.slice(0, 7) === m).sort((a, b) => a.date.localeCompare(b.date)).map((r) => [
			dmy(r.date),
			r.merchant,
			r.category,
			String(r.total)
		])]
	}));
	return [{
		name: "Tổng hợp",
		rows: summary,
		totals: true
	}, ...per];
}
//#endregion
export { monthTotals as a, parseDate as c, loadReceipts as i, saveReceipts as l, expenseSheets as n, normalizeReceipt as o, formatVnd as r, parseAmount as s, CATEGORIES as t };
