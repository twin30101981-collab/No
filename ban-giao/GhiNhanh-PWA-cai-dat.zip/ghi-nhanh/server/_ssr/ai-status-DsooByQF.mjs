import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-status-DsooByQF.js
var ai_status_exports = /* @__PURE__ */ __exportAll({
	AI_NAME: () => AI_NAME,
	noteAiResult: () => noteAiResult,
	providerState: () => providerState,
	readAiStatus: () => readAiStatus
});
var AI_NAME = {
	lovable: "Lovable AI",
	claude: "Claude",
	mistral: "Mistral",
	gemini: "Gemini"
};
var KEY = "ghi-nhanh:ai-status";
var NOTE_EVERY = 6e5;
function readAiStatus() {
	try {
		const v = JSON.parse(localStorage.getItem(KEY) ?? "{}");
		return v && typeof v === "object" && !Array.isArray(v) ? {
			providers: {},
			...v
		} : { providers: {} };
	} catch {
		return { providers: {} };
	}
}
/** Ghi một kết quả AI; trả tên nguồn dự phòng nếu cần báo người dùng (đã giãn 10 phút), ngược lại null. */
function noteAiResult(r, now = Date.now()) {
	if (!r || typeof r !== "object") return null;
	const x = r;
	if (!x.source && !x.tried?.length) return null;
	const st = readAiStatus();
	for (const t of x.tried ?? []) st.providers[t.provider] = {
		at: now,
		ok: false,
		code: t.code
	};
	let note = null;
	if (x.ok && x.source) {
		st.providers[x.source] = {
			at: now,
			ok: true
		};
		const fallback = !!x.tried?.length;
		st.last = {
			source: x.source,
			at: now,
			fallback
		};
		if (fallback && (!st.notedAt || now - st.notedAt > NOTE_EVERY)) {
			note = AI_NAME[x.source];
			st.notedAt = now;
		}
	}
	try {
		localStorage.setItem(KEY, JSON.stringify(st));
	} catch {}
	return note;
}
/** Trạng thái hiển thị một nguồn. */
function providerState(keySource, enabled, memo) {
	if (!enabled) return {
		state: "off",
		text: "Đã tắt trong thứ tự"
	};
	if (!keySource) return {
		state: "off",
		text: "Chưa có key"
	};
	if (memo && !memo.ok) {
		if (memo.code === 401 || memo.code === 403) return {
			state: "warn",
			text: "Lỗi key (lần gần nhất)"
		};
		if (memo.code === 402 || memo.code === 429) return {
			state: "warn",
			text: "Hết lượt / quá tải (lần gần nhất)"
		};
		if (memo.code === 451) return {
			state: "warn",
			text: "Từ chối nội dung (lần gần nhất)"
		};
		return {
			state: "warn",
			text: "Lỗi lần gần nhất — có thể tạm thời"
		};
	}
	return {
		state: "ok",
		text: `Sẵn sàng · ${keySource === "user" ? "key của bạn" : "key máy chủ"}`
	};
}
//#endregion
export { readAiStatus as i, ai_status_exports as n, providerState as r, AI_NAME as t };
