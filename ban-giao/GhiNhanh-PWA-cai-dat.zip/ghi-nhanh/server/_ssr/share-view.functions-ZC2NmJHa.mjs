import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CwccI41b.mjs";
import { t as createServerRpc } from "./createServerRpc-CxD4EZ5P.mjs";
import { i as stringType, r as objectType } from "../_libs/zod.mjs";
import { d as tooManyFailsMessage, f as verifyPassword, i as createFailGate, l as shareFailKey, n as SHARE_PW_WINDOW_MS, s as linkStatus } from "./share-links-s-_jx_4k.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/share-view.functions-ZC2NmJHa.js
var pwGate = createFailGate({
	limit: 10,
	windowMs: SHARE_PW_WINDOW_MS
});
var openSharedDoc_createServerFn_handler = createServerRpc({
	id: "05e9df102c9c56f519deb2e800e7ee4661deb01d239d3f5fe9673f5658712971",
	name: "openSharedDoc",
	filename: "src/lib/share-view.functions.ts"
}, (opts) => openSharedDoc.__executeServer(opts));
var openSharedDoc = createServerFn({ method: "POST" }).inputValidator((d) => objectType({
	token: stringType().regex(/^[A-Za-z0-9_-]{22}$/),
	password: stringType().max(64).default("")
}).parse(d)).handler(openSharedDoc_createServerFn_handler, async ({ data }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data: link } = await supabaseAdmin.from("share_links").select("document_id, expires_at, revoked_at, password_hash").eq("token", data.token).maybeSingle();
	if (!link) return {
		ok: false,
		code: "missing",
		message: "Liên kết không tồn tại."
	};
	const st = linkStatus(link, Date.now());
	if (st === "revoked") return {
		ok: false,
		code: "revoked",
		message: "Người chia sẻ đã thu hồi liên kết này."
	};
	if (st === "expired") return {
		ok: false,
		code: "expired",
		message: "Liên kết đã hết hạn."
	};
	if (link.password_hash) {
		if (!data.password) return {
			ok: false,
			code: "password",
			message: "Nhập mật khẩu để xem tài liệu."
		};
		const [{ getRequest }, { clientKey }] = await Promise.all([import("./server-BYuUwks4.mjs").then((n) => n.i).then((n) => n.t), import("./ai-limit-BeGU7SmX.mjs")]);
		const fk = shareFailKey(clientKey(getRequest()?.headers), data.token);
		const gate = pwGate.check(fk);
		if (!gate.ok) return {
			ok: false,
			code: "password",
			message: tooManyFailsMessage(gate.retryAfterSec)
		};
		if (!await verifyPassword(data.password, link.password_hash)) {
			pwGate.fail(fk);
			return {
				ok: false,
				code: "password",
				message: "Sai mật khẩu, thử lại."
			};
		}
		pwGate.reset(fk);
	}
	const { data: doc } = await supabaseAdmin.from("documents").select("name, deleted_at").eq("id", link.document_id).maybeSingle();
	if (!doc || doc.deleted_at) return {
		ok: false,
		code: "missing",
		message: "Tài liệu không còn nữa."
	};
	const { data: pages } = await supabaseAdmin.from("pages").select("src_path, position").eq("document_id", link.document_id).order("position");
	const paths = (pages ?? []).map((p) => p.src_path).filter((p) => !!p);
	const { data: signed } = paths.length ? await supabaseAdmin.storage.from("pages").createSignedUrls(paths, 3600) : { data: [] };
	return {
		ok: true,
		name: doc.name,
		images: (signed ?? []).map((s) => s.signedUrl).filter(Boolean)
	};
});
var revokeShareLink_createServerFn_handler = createServerRpc({
	id: "9d73e134a8f620a8ab710665a2c56d119dc94d5559f194a2366313730f523e47",
	name: "revokeShareLink",
	filename: "src/lib/share-view.functions.ts"
}, (opts) => revokeShareLink.__executeServer(opts));
var revokeShareLink = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ id: stringType().uuid() }).parse(d)).handler(revokeShareLink_createServerFn_handler, async ({ data, context }) => {
	const { error } = await context.supabase.from("share_links").update({ revoked_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", data.id).is("revoked_at", null);
	return error ? {
		ok: false,
		message: "Chưa thu hồi được, thử lại sau."
	} : { ok: true };
});
//#endregion
export { openSharedDoc_createServerFn_handler, revokeShareLink_createServerFn_handler };
