import { o as __toESM } from "../_runtime.mjs";
import { w as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { J as Lock, X as LoaderCircle } from "../_libs/lucide-react.mjs";
import { t as useServerFn } from "./useServerFn-CrZF2pjq.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { t as Input } from "./input-T4LKa1EA.mjs";
import { t as openSharedDoc } from "./share-view.functions-Z0Oopxol.mjs";
import { t as Route } from "./s._token-DbbrCp4H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/s._token-BtAuRrV6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SharedView() {
	const { token } = Route.useParams();
	const open = useServerFn(openSharedDoc);
	const [res, setRes] = (0, import_react.useState)(null);
	const [pw, setPw] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(true);
	const load = async (password = "") => {
		setBusy(true);
		if (!/^[A-Za-z0-9_-]{22}$/.test(token)) {
			setRes({
				ok: false,
				code: "missing",
				message: "Liên kết không tồn tại."
			});
			setBusy(false);
			return;
		}
		try {
			setRes(await open({ data: {
				token,
				password
			} }));
		} catch {
			setRes({
				ok: false,
				code: "missing",
				message: "Không mở được liên kết. Kiểm tra mạng rồi thử lại."
			});
		} finally {
			setBusy(false);
		}
	};
	(0, import_react.useEffect)(() => {
		load();
	}, [token]);
	if (busy && !res) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin text-primary" })
	});
	if (res && !res.ok) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center p-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm",
			children: [
				res.code === "password" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "mx-auto size-8 text-primary" }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-display font-semibold",
					children: res.message
				}),
				res.code === "password" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-4 flex gap-2",
					onSubmit: (e) => {
						e.preventDefault();
						load(pw);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "h-11",
						type: "password",
						autoFocus: true,
						placeholder: "Mật khẩu",
						value: pw,
						onChange: (e) => setPw(e.target.value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: busy || !pw,
						children: busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : "Mở"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "mt-4 inline-block text-sm font-semibold text-primary",
					children: "Về Ghi Nhanh"
				})
			]
		})
	});
	if (!res?.ok) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-lg font-semibold",
				children: res.name || "Tài liệu"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [res.images.length, " trang · chỉ xem"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 space-y-3",
				children: res.images.map((u, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: u,
					alt: `Trang ${i + 1}`,
					loading: "lazy",
					className: "w-full rounded-lg border border-border"
				}, u))
			})
		]
	});
}
//#endregion
export { SharedView as component };
