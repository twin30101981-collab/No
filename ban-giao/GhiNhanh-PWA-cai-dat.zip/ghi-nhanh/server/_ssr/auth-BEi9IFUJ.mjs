import { o as __toESM } from "../_runtime.mjs";
import { D as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as isVietnamese } from "./errors-DKvrPJ4v.mjs";
import { n as supabase } from "./client-D3MSxqCj.mjs";
import { t as createLovableAuth } from "../_libs/lovable.dev__cloud-auth-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-BEi9IFUJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var AUTH_NEXT_KEY = "gn-auth-next";
/** Chỉ nhận kết quả đăng nhập ở các đường này (redirect_uri = gốc app; thư xác nhận email về /me). */
var AUTH_PATHS = [
	"/",
	"/auth",
	"/me"
];
var paramsOf = (l) => {
	const h = new URLSearchParams(l.hash.replace(/^#/, ""));
	const s = new URLSearchParams(l.search);
	const get = (k) => h.get(k) ?? s.get(k);
	return get;
};
/** URL hiện tại có phải là lượt quay về của đăng nhập không — null nếu không. */
function parseAuthCallback(l = window.location) {
	if (!AUTH_PATHS.includes(l.pathname)) return null;
	const get = paramsOf(l);
	const err = get("error_description") ?? get("error") ?? get("error_code");
	const access = get("access_token"), refresh = get("refresh_token");
	if (access && refresh) return {
		kind: "tokens",
		error: null,
		accessToken: access,
		refreshToken: refresh
	};
	if (err) return {
		kind: "error",
		error: err,
		accessToken: null,
		refreshToken: null
	};
	if (get("code") && (l.pathname === "/" || l.pathname === "/auth")) return {
		kind: "code",
		error: null,
		accessToken: null,
		refreshToken: null
	};
	return null;
}
var hasAuthCallback = (l = window.location) => parseAuthCallback(l) !== null;
/** Chỉ cho đường nội bộ ("/me", "/sync"…): chặn "//evil", "http://…", "/\\evil" (chuyển hướng ra ngoài). */
function safeNext(v, fallback = "/me") {
	if (!v || !v.startsWith("/") || v.startsWith("//") || v.startsWith("/\\")) return fallback;
	return v;
}
function rememberAuthNext(path, storage = safeSession()) {
	try {
		storage?.setItem(AUTH_NEXT_KEY, safeNext(path));
	} catch {}
}
function takeAuthNext(storage = safeSession()) {
	try {
		const v = storage?.getItem(AUTH_NEXT_KEY);
		storage?.removeItem(AUTH_NEXT_KEY);
		return safeNext(v);
	} catch {
		return "/me";
	}
}
function safeSession() {
	try {
		return typeof sessionStorage === "undefined" ? void 0 : sessionStorage;
	} catch {
		return;
	}
}
/**
* Hoàn tất đăng nhập: khởi tạo Supabase (tự đọc mã trên URL), xác nhận có phiên, xoá mã khỏi thanh địa chỉ.
* Ghi chú: mã vẫn bị xoá khỏi URL cả khi lỗi — để không nằm lại trong lịch sử/ảnh chụp màn hình.
*/
async function completeAuthCallback(opts = {}) {
	const loc = opts.loc ?? window.location;
	const info = parseAuthCallback(loc);
	const replaceUrl = opts.replaceUrl ?? ((p) => window.history.replaceState(window.history.state, "", p));
	const next = (opts.next ?? takeAuthNext)();
	if (!info) return {
		user: null,
		error: null,
		next
	};
	const clean = () => replaceUrl(loc.pathname);
	if (info.kind === "error") {
		clean();
		return {
			user: null,
			error: info.error,
			next
		};
	}
	try {
		const client = await (opts.getClient ?? (async () => (await import("./client-D3MSxqCj.mjs").then((n) => n.t).then((n) => n.t)).supabase))();
		let { data, error } = await client.auth.getSession();
		if (!data.session && info.accessToken && info.refreshToken) ({data, error} = await client.auth.setSession({
			access_token: info.accessToken,
			refresh_token: info.refreshToken
		}));
		clean();
		const user = data.session?.user ?? null;
		return {
			user,
			error: user ? null : error ? String(error.message ?? error) : "No tokens received",
			next
		};
	} catch (e) {
		clean();
		return {
			user: null,
			error: e instanceof Error ? e.message : String(e),
			next
		};
	}
}
var inflight = null;
/** Gọi từ __root: chạy đúng một lần cho một lượt quay về (StrictMode chạy effect hai lần). */
function runAuthCallbackOnce() {
	if (inflight) return inflight;
	if (!hasAuthCallback()) return null;
	inflight = completeAuthCallback().finally(() => {
		setTimeout(() => {
			inflight = null;
		}, 0);
	});
	return inflight;
}
var lovableAuth = createLovableAuth();
var lovable = { auth: { signInWithOAuth: async (provider, opts) => {
	const result = await lovableAuth.signInWithOAuth(provider, {
		...opts,
		extraParams: { ...opts?.extraParams }
	});
	if (result.redirected) return result;
	if (result.error) return result;
	try {
		await supabase.auth.setSession(result.tokens);
	} catch (e) {
		return { error: e instanceof Error ? e : new Error(String(e)) };
	}
	return result;
} } };
var IN_APP = [
	[/Zalo/i, "Zalo"],
	[/FBAN|FBAV|FB_IAB|FBIOS/i, "Facebook"],
	[/Messenger|MessengerLite/i, "Messenger"],
	[/Instagram/i, "Instagram"],
	[/TikTok|musical_ly|Bytedance/i, "TikTok"],
	[/\bLine\//i, "Line"],
	[/Viber/i, "Viber"],
	[/Snapchat/i, "Snapchat"],
	[/Twitter|TwitterAndroid/i, "X (Twitter)"],
	[/LinkedInApp/i, "LinkedIn"]
];
/** Tên ứng dụng đang nhúng trình duyệt, hoặc null nếu là trình duyệt thường. */
function detectInAppBrowser(ua = typeof navigator === "undefined" ? "" : navigator.userAgent) {
	for (const [re, name] of IN_APP) if (re.test(ua)) return name;
	if (/Android/i.test(ua) && /; wv\)/.test(ua)) return "ứng dụng khác";
	return null;
}
/** PWA đã cài trên iPhone/iPad (chế độ standalone): trang Google có thể mở ở khung Safari riêng, phiên không về app. */
function isIosStandalonePwa() {
	if (typeof navigator === "undefined" || typeof window === "undefined") return false;
	const ios = /iPhone|iPad|iPod/i.test(navigator.userAgent) || /Macintosh/i.test(navigator.userAgent) && navigator.maxTouchPoints > 1;
	const standalone = navigator.standalone === true || (window.matchMedia?.("(display-mode: standalone)").matches ?? false);
	return ios && standalone;
}
/** Liên kết mở thẳng bằng Chrome trên Android (iOS không có cách tương đương → chỉ sao chép liên kết). */
function chromeIntentUrl(href, ua = typeof navigator === "undefined" ? "" : navigator.userAgent) {
	if (!/Android/i.test(ua)) return null;
	try {
		const u = new URL(href);
		return `intent://${u.host}${u.pathname}${u.search}#Intent;scheme=${u.protocol.replace(":", "")};package=com.android.chrome;end`;
	} catch {
		return null;
	}
}
/** Có cấu hình đám mây chưa — thiếu thì mọi tính năng trên máy vẫn chạy, chỉ ẩn phần cần đăng nhập. */
var cloudReady = () => !!({
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/"
}["VITE_SUPABASE_URL"] && {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/"
}["VITE_SUPABASE_PUBLISHABLE_KEY"]);
var NO_CLOUD = "Chưa kết nối máy chủ đám mây — tính năng này cần Lovable Cloud.";
function useUser() {
	const [user, setUser] = (0, import_react.useState)(null);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!cloudReady()) {
			setReady(true);
			return;
		}
		const { data } = supabase.auth.onAuthStateChange((_e, s) => {
			setUser(s?.user ?? null);
			setReady(true);
		});
		supabase.auth.getSession().then(({ data: d }) => {
			setUser(d.session?.user ?? null);
			setReady(true);
		});
		return () => data.subscription.unsubscribe();
	}, []);
	return {
		user,
		ready
	};
}
/** Lỗi đăng nhập -> câu tiếng Việt dễ hiểu. */
function authMessage(msg) {
	const m = msg.toLowerCase();
	if (m.includes("invalid login")) return "Sai email hoặc mật khẩu";
	if (m.includes("email not confirmed")) return "Email chưa xác nhận — mở thư xác nhận trong hộp thư";
	if (m.includes("already registered")) return "Email này đã có tài khoản — hãy đăng nhập";
	if (m.includes("password") && (m.includes("6") || m.includes("short") || m.includes("weak"))) return "Mật khẩu quá yếu (ít nhất 6 ký tự)";
	if (m.includes("rate limit")) return "Thử quá nhiều lần, đợi một lát rồi thử lại";
	if (m.includes("fetch") || m.includes("network")) return "Mất mạng — kiểm tra kết nối rồi thử lại";
	if (m.includes("popup was blocked")) return "Trình duyệt chặn cửa sổ đăng nhập — cho phép cửa sổ bật lên cho trang này rồi thử lại, hoặc mở app ở tab riêng";
	if (m.includes("sign in was cancelled") || m.includes("access_denied") || m.includes("user cancelled")) return "Đăng nhập Google chưa hoàn tất (đã huỷ hoặc không được cho phép) — bấm lại để thử";
	if (m.includes("not supported in preview mode")) return "Không đăng nhập được trong khung xem trước — mở app ở tab trình duyệt mới rồi đăng nhập";
	if (m.includes("state is invalid")) return "Phiên đăng nhập đã hết hạn hoặc bị mở ở tab khác — bấm đăng nhập lại";
	if (m.includes("no tokens received")) return "Google đã xác nhận nhưng app chưa nhận được phiên — thử lại; nếu vẫn lỗi hãy đăng nhập bằng email";
	if (m.includes("timed out")) return "Đăng nhập quá lâu không phản hồi — kiểm tra mạng rồi thử lại";
	if (m.includes("provider is not enabled") || m.includes("unsupported provider")) return "Đăng nhập Google chưa được bật cho ứng dụng này — dùng email, hoặc nhờ chủ ứng dụng bật Google trong phần Xác thực";
	if (m.includes("disallowed_useragent")) return "Google không cho đăng nhập trong trình duyệt của ứng dụng này — mở liên kết bằng Chrome hoặc Safari";
	if (m.includes("redirect") && (m.includes("not allowed") || m.includes("mismatch") || m.includes("invalid"))) return "Địa chỉ quay về chưa được phép — nhờ chủ ứng dụng thêm địa chỉ này vào danh sách chuyển hướng";
	if (m.includes("sign in failed")) return "Đăng nhập Google không thành công — thử lại hoặc dùng email";
	if (isVietnamese(msg)) return msg;
	console.warn("[FX-03] lỗi đăng nhập chưa dịch:", msg);
	return "Chưa đăng nhập được — thử lại sau ít phút; nếu vẫn lỗi hãy dùng cách đăng nhập khác";
}
async function signInEmail(email, password) {
	if (!cloudReady()) throw new Error(NO_CLOUD);
	const { error } = await supabase.auth.signInWithPassword({
		email,
		password
	});
	if (error) throw new Error(authMessage(error.message));
}
async function signUpEmail(email, password) {
	if (!cloudReady()) throw new Error(NO_CLOUD);
	const { data, error } = await supabase.auth.signUp({
		email,
		password,
		options: { emailRedirectTo: window.location.origin + "/me" }
	});
	if (error) throw new Error(authMessage(error.message));
	return { needConfirm: !data.session };
}
/** `next`: màn cần quay lại sau khi đăng nhập (mặc định /me). Bị chặn trong trình duyệt nhúng vì Google trả 403 disallowed_useragent. */
async function signInGoogle(next = "/me") {
	if (!cloudReady()) throw new Error(NO_CLOUD);
	if (detectInAppBrowser()) throw new Error(authMessage("disallowed_useragent"));
	rememberAuthNext(next);
	const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
	if (r.error) throw new Error(authMessage(String(r.error.message ?? r.error)));
	return r;
}
async function signOut() {
	if (!cloudReady()) return;
	await supabase.auth.signOut();
}
//#endregion
export { detectInAppBrowser as a, signInEmail as c, signUpEmail as d, useUser as f, cloudReady as i, signInGoogle as l, authMessage as n, isIosStandalonePwa as o, chromeIntentUrl as r, runAuthCallbackOnce as s, NO_CLOUD as t, signOut as u };
