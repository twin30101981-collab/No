import { o as __toESM } from "../_runtime.mjs";
import { T as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { i as showError } from "./errors-DKvrPJ4v.mjs";
import { P as RefreshCw, S as Smartphone, kt as FileDown, r as X, rt as Laptop } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-CZvf2xHx.mjs";
import { C as saveDoc, m as newPage, p as newDoc } from "./db-CclUQaLE.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { a as newRoomCode, i as joinRoom, o as pairUrl, s as remaining, t as Assembler } from "./pair-DrmeGriq.mjs";
import { t as require_lib } from "../_libs/qrcode.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pair-BjtEtPv4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_lib = /* @__PURE__ */ __toESM(require_lib());
function PairDesktop() {
	const [room, setRoom] = (0, import_react.useState)(null);
	const [qr, setQr] = (0, import_react.useState)("");
	const [peers, setPeers] = (0, import_react.useState)([]);
	const [now, setNow] = (0, import_react.useState)(Date.now());
	const [shots, setShots] = (0, import_react.useState)([]);
	const [incoming, setIncoming] = (0, import_react.useState)(0);
	const asm = (0, import_react.useRef)(new Assembler());
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		setRoom({
			code: newRoomCode(),
			created: Date.now()
		});
	}, []);
	(0, import_react.useEffect)(() => {
		const t = setInterval(() => setNow(Date.now()), 1e3);
		return () => clearInterval(t);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!room) return;
		import_lib.toDataURL(pairUrl(location.origin, room.code, room.created), {
			margin: 1,
			width: 320
		}).then(setQr);
		setPeers([]);
		asm.current = new Assembler();
		const r = joinRoom(room.code, {
			role: "desktop",
			device: "Máy tính"
		}, setPeers, void 0, (ch) => {
			ch.on("broadcast", { event: "part" }, ({ payload }) => {
				const p = payload;
				const done = asm.current.push(p);
				setIncoming(done ? 0 : asm.current.progress(p.id) ?? 0);
				if (!done) return;
				setShots((l) => l.some((x) => x.id === done.id) ? l : [...l, {
					id: done.id,
					src: done.dataUrl
				}]);
				ch.send({
					type: "broadcast",
					event: "ack",
					payload: { id: done.id }
				});
			});
		});
		return () => r.leave();
	}, [room]);
	const left = room ? remaining(room.created, now) : 0;
	const phone = peers.find((p) => p.role === "phone");
	const expired = !!room && left === 0 && !phone && shots.length === 0;
	const fresh = () => setRoom({
		code: newRoomCode(),
		created: Date.now()
	});
	async function saveAll() {
		try {
			const doc = await saveDoc(newDoc(shots.map((x) => newPage(x.src)), void 0, "Từ điện thoại"));
			toast.success(`Đã lưu ${shots.length} trang`);
			navigate({
				to: "/doc/$id",
				params: { id: doc.id }
			});
		} catch (e) {
			showError(e, "Không lưu được ảnh");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Quét bằng điện thoại",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-md space-y-4 p-4 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[0.95rem] text-muted-foreground",
					children: "Mở camera trên điện thoại, quét mã dưới đây để nối với máy tính này."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid aspect-square w-64 place-items-center rounded-xl border bg-card p-3",
					children: expired ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Mã đã hết hạn"
					}) : qr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: qr,
						alt: "Mã QR ghép điện thoại",
						className: "w-full"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Đang tạo mã…"
					})
				}),
				phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "status",
					className: "flex items-center justify-center gap-2 rounded-lg bg-primary/10 p-3 font-medium text-primary",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, {
							className: "h-5 w-5",
							"aria-hidden": true
						}),
						" Đã nối với ",
						phone.device
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "status",
					className: "flex items-center justify-center gap-2 text-sm text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Laptop, {
						className: "h-4 w-4",
						"aria-hidden": true
					}), expired ? "Tạo mã mới để thử lại" : `Đang chờ điện thoại… mã còn ${Math.floor(left / 6e4)}:${String(Math.floor(left / 1e3) % 60).padStart(2, "0")}`]
				}),
				phone && shots.length === 0 && !incoming && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Chụp trên điện thoại, ảnh sẽ hiện ở đây ngay."
				}),
				incoming > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					role: "status",
					className: "text-sm",
					children: [
						"Đang nhận ảnh… ",
						Math.round(incoming * 100),
						"%"
					]
				}),
				shots.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2",
						children: shots.map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: x.src,
								alt: `Trang ${i + 1} từ điện thoại`,
								className: "aspect-[3/4] w-full rounded-md border object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								"aria-label": `Bỏ trang ${i + 1}`,
								onClick: () => setShots((l) => l.filter((y) => y.id !== x.id)),
								className: "absolute right-1 top-1 rounded-full bg-background/90 p-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
									className: "h-3.5 w-3.5",
									"aria-hidden": true
								})
							})]
						}, x.id))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "w-full",
						onClick: saveAll,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, {
								className: "mr-2 h-4 w-4",
								"aria-hidden": true
							}),
							"Lưu thành tài liệu (",
							shots.length,
							" trang)"
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: fresh,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
						className: "mr-2 h-4 w-4",
						"aria-hidden": true
					}), "Tạo mã mới"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Không cần đăng nhập. Phòng chỉ tồn tại khi trang này đang mở; ảnh không lưu trên máy chủ."
				})
			]
		})
	});
}
//#endregion
export { PairDesktop as component };
