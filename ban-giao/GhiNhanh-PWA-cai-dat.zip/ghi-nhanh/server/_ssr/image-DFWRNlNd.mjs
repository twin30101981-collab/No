import { r as __exportAll } from "../_runtime.mjs";
import { n as init_performance, r as performance_default } from "../_libs/canvg+[...].mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { t as adoptBlob } from "./disk-pack-ZdDKsocx.mjs";
import { c as recordPerf } from "./perf-stats-C5jrVSN8.mjs";
import { n as runInPool, t as poolCanvasSupported } from "./worker-pool-DW9Ak2AM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/image-DFWRNlNd.js
var image_DFWRNlNd_exports = /* @__PURE__ */ __exportAll({
	A: () => lapVarGray,
	B: () => LEVEL_LABEL,
	C: () => splitBook,
	D: () => toJpeg,
	E: () => tilt,
	F: () => curveAt,
	G: () => detectFrameAsync,
	H: () => TOOL_LABEL,
	I: () => edgeCurves,
	J: () => lastSampleMs,
	K: () => detectPaperAsync,
	L: () => detectTextLines,
	M: () => skewFromGray,
	N: () => skewSize,
	O: () => yieldTask,
	P: () => normalizeFilter,
	R: () => buildPageCurve,
	S: () => sharpness,
	T: () => targetLong,
	U: () => clampLevel,
	V: () => TOOL_KEYS,
	W: () => toolsKey,
	X: () => detectPaper,
	Y: () => PAPER_LABEL,
	Z: () => detectPaperGray,
	_: () => releaseRenderCache,
	a: () => detectQuadInfo,
	b: () => renderPreview,
	c: () => estimateSkew,
	d: () => grayscale,
	f: () => image_exports,
	g: () => refineQuadOnSrc,
	h: () => normalizeUrl,
	i: () => detectQuadFromSrc,
	j: () => sharpSize,
	k: () => PREVIEW_LONG,
	l: () => fileToDataUrl,
	m: () => normalize,
	n: () => compress,
	o: () => detectQuadScoredAsync,
	p: () => loadImg,
	q: () => detectVideoFrameAsync,
	r: () => countObjects,
	s: () => enhanceForOcr,
	t: () => composeIdCard,
	u: () => glare,
	v: () => renderPage,
	w: () => stamp,
	x: () => renderQuickUrl,
	y: () => renderPageUrl,
	z: () => smallGray
});
init_performance();
function workerNormalizeSupported() {
	return poolCanvasSupported();
}
/** Trả Blob JPEG đã thu nhỏ, hoặc null nếu không dùng được Worker. */
function normalizeInWorker(blob, max, q) {
	if (!workerNormalizeSupported()) return null;
	const p = runInPool("normalize", {
		blob,
		max,
		q
	});
	if (!p) return null;
	return p.then((r) => {
		if (!r.blob) throw new Error(r.error || "normalize worker");
		return r.blob;
	});
}
/** V7: lấy mẫu RGBA thu nhỏ (luồng chính, rẻ) — phần dò nặng chạy trong Worker. */
function sampleRgba(src, w, h) {
	const c = document.createElement("canvas");
	c.width = w;
	c.height = h;
	const ctx = c.getContext("2d", { willReadFrequently: true });
	ctx.drawImage(src, 0, 0, w, h);
	const d = ctx.getImageData(0, 0, w, h).data;
	c.width = 0;
	return d;
}
function rgbaToGray(d, n) {
	const g = new Float32Array(n);
	for (let i = 0; i < n; i++) g[i] = d[i * 4] * .3 + d[i * 4 + 1] * .59 + d[i * 4 + 2] * .11;
	return g;
}
/** V7: kích thước bản dò theo cạnh dài size. */
function detectSize(sw, sh, size) {
	const s = size / Math.max(sw, sh);
	return {
		w: Math.max(8, Math.round(sw * s)),
		h: Math.max(8, Math.round(sh * s))
	};
}
/** V7: dò từ RGBA (dùng chung cho Worker và luồng chính → kết quả giống hệt). */
function detectFromRgba(d, w, h, robust) {
	return detectPaperGray(rgbaToGray(d, w * h), w, h, robust);
}
function boxBlur$1(g, w, h, r) {
	const t = new Float32Array(g.length), o = new Float32Array(g.length);
	for (let y = 0; y < h; y++) {
		let s = 0;
		const row = y * w;
		for (let x = -r; x <= r; x++) s += g[row + Math.min(w - 1, Math.max(0, x))];
		for (let x = 0; x < w; x++) {
			t[row + x] = s / (2 * r + 1);
			s += g[row + Math.min(w - 1, x + r + 1)] - g[row + Math.max(0, x - r)];
		}
	}
	for (let x = 0; x < w; x++) {
		let s = 0;
		for (let y = -r; y <= r; y++) s += t[Math.min(h - 1, Math.max(0, y)) * w + x];
		for (let y = 0; y < h; y++) {
			o[y * w + x] = s / (2 * r + 1);
			s += t[Math.min(h - 1, y + r + 1) * w + x] - t[Math.max(0, y - r) * w + x];
		}
	}
	return o;
}
var NT = 120;
var COS = Array.from({ length: NT }, (_, i) => Math.cos(i * Math.PI / NT));
var SIN = Array.from({ length: NT }, (_, i) => Math.sin(i * Math.PI / NT));
function detectPaper(src, sw, sh, size = 360) {
	if (!sw || !sh) return null;
	const { w, h } = detectSize(sw, sh, size);
	return detectFromRgba(sampleRgba(src, w, h), w, h, size >= 500);
}
/** Kéo giãn tương phản theo phân vị 1–99 % (ảnh tối, thiếu sáng, chụp qua kính). */
function stretchGray(g) {
	const hist = /* @__PURE__ */ new Uint32Array(256);
	for (let i = 0; i < g.length; i++) hist[Math.max(0, Math.min(255, g[i] | 0))]++;
	let acc = 0, lo = 0, hi = 255;
	for (let v = 0; v < 256; v++) {
		acc += hist[v];
		if (acc >= g.length * .01) {
			lo = v;
			break;
		}
	}
	acc = 0;
	for (let v = 255; v >= 0; v--) {
		acc += hist[v];
		if (acc >= g.length * .01) {
			hi = v;
			break;
		}
	}
	const r = Math.max(20, hi - lo), o = new Float32Array(g.length);
	for (let i = 0; i < g.length; i++) o[i] = Math.max(0, Math.min(255, (g[i] - lo) / r * 255));
	return o;
}
/** Bù sáng không đều (bóng tay/đèn): chia cho nền mờ rộng, giữ biên giấy–nền rõ ở mọi vùng. */
function evenLight(g, w, h) {
	const r = Math.max(4, Math.round(Math.max(w, h) / 12));
	const bg = boxBlur$1(boxBlur$1(g, w, h, r), w, h, r);
	let mean = 0;
	for (let i = 0; i < g.length; i++) mean += g[i];
	mean /= g.length || 1;
	const o = new Float32Array(g.length);
	for (let i = 0; i < g.length; i++) o[i] = Math.max(0, Math.min(255, g[i] / Math.max(8, bg[i]) * mean));
	return stretchGray(o);
}
/** Core detector on a grayscale buffer (w×h, 0..255); pure, so it runs in tests and the crop benchmark. */
function detectPaperGray(raw, w, h, robust = false) {
	const base = detectCore(raw, w, h);
	if (!robust || base && base.score >= .85) return base;
	let best = base;
	for (const g of [stretchGray(raw), evenLight(raw, w, h)]) {
		const d = detectCore(g, w, h);
		if (d && (!best || d.score > best.score + .02)) best = d;
	}
	return best;
}
function detectCore(raw, w, h) {
	const g = boxBlur$1(boxBlur$1(raw, w, h, 1), w, h, 1);
	const mag = new Float32Array(w * h), ang = new Float32Array(w * h);
	const hist = /* @__PURE__ */ new Uint32Array(256);
	for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
		const i = y * w + x;
		const gx = g[i - w + 1] + 2 * g[i + 1] + g[i + w + 1] - g[i - w - 1] - 2 * g[i - 1] - g[i + w - 1];
		const gy = g[i + w - 1] + 2 * g[i + w] + g[i + w + 1] - g[i - w - 1] - 2 * g[i - w] - g[i - w + 1];
		const m = Math.hypot(gx, gy);
		mag[i] = m;
		ang[i] = Math.atan2(gy, gx);
		hist[Math.min(255, m / 4) | 0]++;
	}
	let acc = 0, thrBin = 255;
	const target = w * h * .07;
	for (let b = 255; b >= 0; b--) {
		acc += hist[b];
		if (acc >= target) {
			thrBin = b;
			break;
		}
	}
	const thr = Math.max(40, thrBin * 4);
	const diag = Math.ceil(Math.hypot(w, h));
	const NR = diag * 2 + 1;
	const H = new Float32Array(NT * NR);
	for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
		const i = y * w + x;
		if (mag[i] < thr) continue;
		let a = ang[i];
		if (a < 0) a += Math.PI;
		const tc = Math.round(a / Math.PI * NT);
		for (let k = -6; k <= 6; k++) {
			const t = (tc + k + NT) % NT;
			const rho = Math.round(x * COS[t] + y * SIN[t]) + diag;
			H[t * NR + rho] += 1;
		}
	}
	const lines = [];
	const cand = [];
	const minVotes = Math.min(w, h) * .18;
	for (let i = 0; i < H.length; i++) if (H[i] >= minVotes) cand.push(i);
	cand.sort((a, b) => H[b] - H[a]);
	for (const i of cand) {
		const t = Math.floor(i / NR), r = i % NR - diag;
		const th = t * Math.PI / NT;
		if (lines.some((l) => {
			let dt = Math.abs(l.theta - th);
			dt = Math.min(dt, Math.PI - dt);
			const rr = Math.abs(dt) > Math.PI / 2 - .2 ? Math.abs(l.rho + r) : Math.abs(l.rho - r);
			return dt < .14 && rr < Math.min(w, h) * .06;
		})) continue;
		lines.push({
			rho: r,
			theta: th,
			votes: H[i]
		});
		if (lines.length >= 18) break;
	}
	const hor = [
		...lines.filter((l) => Math.abs(l.theta - Math.PI / 2) < Math.PI / 4).slice(0, 8),
		{
			rho: 1,
			theta: Math.PI / 2,
			votes: 0
		},
		{
			rho: h - 2,
			theta: Math.PI / 2,
			votes: 0
		}
	];
	const ver = [
		...lines.filter((l) => Math.abs(l.theta - Math.PI / 2) >= Math.PI / 4).slice(0, 8),
		{
			rho: 1,
			theta: 0,
			votes: 0
		},
		{
			rho: w - 2,
			theta: 0,
			votes: 0
		}
	];
	const inter = (a, b) => {
		const c1 = Math.cos(a.theta), s1 = Math.sin(a.theta), c2 = Math.cos(b.theta), s2 = Math.sin(b.theta);
		const det = c1 * s2 - s1 * c2;
		if (Math.abs(det) < 1e-6) return null;
		return [(a.rho * s2 - b.rho * s1) / det, (c1 * b.rho - c2 * a.rho) / det];
	};
	const onBorder = (p, q) => p[0] < 3 && q[0] < 3 || p[1] < 3 && q[1] < 3 || p[0] > w - 4 && q[0] > w - 4 || p[1] > h - 4 && q[1] > h - 4;
	const edgeSupport = (p, q) => {
		if (onBorder(p, q)) return .35;
		const len = Math.hypot(q[0] - p[0], q[1] - p[1]);
		const n = Math.max(8, Math.round(len / 2));
		let hit = 0, cnt = 0;
		for (let k = 1; k < n; k++) {
			const x = p[0] + (q[0] - p[0]) * k / n, y = p[1] + (q[1] - p[1]) * k / n;
			const xi = Math.round(x), yi = Math.round(y);
			if (xi < 1 || yi < 1 || xi >= w - 1 || yi >= h - 1) continue;
			cnt++;
			let best = 0;
			for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) best = Math.max(best, mag[(yi + dy) * w + xi + dx]);
			if (best >= thr * .6) hit++;
		}
		return cnt ? hit / n : 0;
	};
	const brightness = (pts, inside) => {
		const cx = (pts[0][0] + pts[1][0] + pts[2][0] + pts[3][0]) / 4, cy = (pts[0][1] + pts[1][1] + pts[2][1] + pts[3][1]) / 4;
		let s = 0, n = 0;
		for (let i = 0; i < 4; i++) {
			const a = pts[i], b = pts[(i + 1) % 4];
			for (let k = 1; k < 8; k++) {
				const x = a[0] + (b[0] - a[0]) * k / 8, y = a[1] + (b[1] - a[1]) * k / 8;
				const dx = cx - x, dy = cy - y, dl = Math.hypot(dx, dy) || 1;
				const off = (inside ? 1 : -1) * Math.min(w, h) * .04;
				const xi = Math.round(x + dx / dl * off), yi = Math.round(y + dy / dl * off);
				if (xi < 0 || yi < 0 || xi >= w || yi >= h) continue;
				s += g[yi * w + xi];
				n++;
			}
		}
		return n ? s / n : -1;
	};
	const innerDark = (pts) => {
		const at = (u, v) => {
			const x = (1 - v) * ((1 - u) * pts[0][0] + u * pts[1][0]) + v * ((1 - u) * pts[3][0] + u * pts[2][0]);
			const y = (1 - v) * ((1 - u) * pts[0][1] + u * pts[1][1]) + v * ((1 - u) * pts[3][1] + u * pts[2][1]);
			const xi = Math.round(x), yi = Math.round(y);
			return xi < 0 || yi < 0 || xi >= w || yi >= h ? -1 : g[yi * w + xi];
		};
		const band = (fixed, t) => {
			let s = 0, n = 0;
			for (let k = 2; k < 30; k++) {
				const o = k / 31;
				const val = fixed === "v" ? at(o, t) : at(t, o);
				if (val >= 0) {
					s += val;
					n++;
				}
			}
			return n ? s / n : 255;
		};
		let centre = 0;
		for (const t of [
			.4,
			.5,
			.6
		]) centre += band("v", t) / 3;
		let worst = 0;
		for (let t = .03; t <= .25; t += .02) for (const [f, tt] of [
			["v", t],
			["v", 1 - t],
			["u", t],
			["u", 1 - t]
		]) {
			const r = band(f, tt) / Math.max(1, centre);
			if (r < .55) worst = Math.max(worst, .55 - r);
		}
		return worst;
	};
	const clutter = (pts) => {
		const cx = (pts[0][0] + pts[1][0] + pts[2][0] + pts[3][0]) / 4, cy = (pts[0][1] + pts[1][1] + pts[2][1] + pts[3][1]) / 4;
		let worst = 0;
		for (let i = 0; i < 4; i++) {
			const a = pts[i], b = pts[(i + 1) % 4];
			let hit = 0, n = 0;
			for (let k = 1; k < 16; k++) {
				const x = a[0] + (b[0] - a[0]) * k / 16, y = a[1] + (b[1] - a[1]) * k / 16;
				const dx = cx - x, dy = cy - y, dl = Math.hypot(dx, dy) || 1;
				for (const f of [
					.03,
					.05,
					.07
				]) {
					const off = Math.min(w, h) * f;
					const xi = Math.round(x + dx / dl * off), yi = Math.round(y + dy / dl * off);
					if (xi < 0 || yi < 0 || xi >= w || yi >= h) continue;
					n++;
					if (mag[yi * w + xi] >= thr * .6) hit++;
				}
			}
			worst = Math.max(worst, n ? hit / n : 0);
		}
		return worst;
	};
	const sideContrast = (pts) => {
		const cx = (pts[0][0] + pts[1][0] + pts[2][0] + pts[3][0]) / 4, cy = (pts[0][1] + pts[1][1] + pts[2][1] + pts[3][1]) / 4;
		let worst = 1;
		for (let i = 0; i < 4; i++) {
			const a = pts[i], b = pts[(i + 1) % 4];
			if (onBorder(a, b)) continue;
			const vin = [], vout = [];
			for (let k = 1; k < 12; k++) {
				const x = a[0] + (b[0] - a[0]) * k / 12, y = a[1] + (b[1] - a[1]) * k / 12;
				const dx = cx - x, dy = cy - y, dl = Math.hypot(dx, dy) || 1;
				const off = Math.min(w, h) * .025;
				const xi = Math.round(x + dx / dl * off), yi = Math.round(y + dy / dl * off);
				const xo = Math.round(x - dx / dl * off), yo = Math.round(y - dy / dl * off);
				if (xi < 0 || yi < 0 || xi >= w || yi >= h || xo < 0 || yo < 0 || xo >= w || yo >= h) continue;
				vin.push(g[yi * w + xi]);
				vout.push(g[yo * w + xo]);
			}
			if (vin.length < 4) continue;
			const raw = vin.map((v, k) => v - vout[k]), diff = [...raw].sort((p, q) => p - q);
			let c = diff[Math.floor(diff.length * .7)] / 255;
			if (c < .08 && neighbourEdge(raw)) c = .08;
			worst = Math.min(worst, c);
		}
		return worst;
	};
	const neighbourEdge = (raw) => {
		const n = raw.length, end = Math.max(raw[0], raw[n - 1]), mid = raw.slice(1, n - 1);
		const brighter = mid.filter((v) => v <= -3 && v >= -45).length, flat = mid.filter((v) => Math.abs(v) < 40).length;
		return end >= 60 && flat >= mid.length * .85 && brighter >= mid.length * .5;
	};
	const isNeighbour = (a, b, cx, cy) => {
		const d = [];
		for (let k = 1; k < 12; k++) {
			const x = a[0] + (b[0] - a[0]) * k / 12, y = a[1] + (b[1] - a[1]) * k / 12;
			const dx = cx - x, dy = cy - y, dl = Math.hypot(dx, dy) || 1;
			const off = Math.min(w, h) * .025;
			const xi = Math.round(x + dx / dl * off), yi = Math.round(y + dy / dl * off), xo = Math.round(x - dx / dl * off), yo = Math.round(y - dy / dl * off);
			if (xi < 0 || yi < 0 || xi >= w || yi >= h || xo < 0 || yo < 0 || xo >= w || yo >= h) continue;
			d.push(g[yi * w + xi] - g[yo * w + xo]);
		}
		return d.length >= 4 && neighbourEdge(d);
	};
	const spill = (pts) => {
		const cx = (pts[0][0] + pts[1][0] + pts[2][0] + pts[3][0]) / 4, cy = (pts[0][1] + pts[1][1] + pts[2][1] + pts[3][1]) / 4;
		const centre = g[Math.round(cy) * w + Math.round(cx)] ?? 0;
		let worst = 0;
		for (let i = 0; i < 4; i++) {
			const a = pts[i], b = pts[(i + 1) % 4];
			if (onBorder(a, b)) continue;
			let hit = 0, n = 0;
			for (let k = 1; k < 12; k++) {
				const x = a[0] + (b[0] - a[0]) * k / 12, y = a[1] + (b[1] - a[1]) * k / 12;
				const dx = cx - x, dy = cy - y, dl = Math.hypot(dx, dy) || 1;
				const xi = Math.round(x + dx / dl * Math.min(w, h) * .04), yi = Math.round(y + dy / dl * Math.min(w, h) * .04);
				if (xi < 0 || yi < 0 || xi >= w || yi >= h) continue;
				const vin = g[yi * w + xi];
				if (vin < centre * .75) continue;
				for (const f of [.04, .08]) {
					const off = Math.min(w, h) * f;
					const xo = Math.round(x - dx / dl * off), yo = Math.round(y - dy / dl * off);
					if (xo < 0 || yo < 0 || xo >= w || yo >= h) continue;
					n++;
					if (g[yo * w + xo] >= vin - 15) hit++;
				}
			}
			if (n >= 6 && !isNeighbour(a, b, cx, cy)) worst = Math.max(worst, hit / n);
		}
		return worst;
	};
	let best = null;
	const m = Math.max(w, h) * .04;
	for (let a = 0; a < hor.length; a++) for (let b = a + 1; b < hor.length; b++) for (let c = 0; c < ver.length; c++) for (let d = c + 1; d < ver.length; d++) {
		let top = hor[a], bot = hor[b];
		let left = ver[c], right = ver[d];
		const midY = (l) => {
			const p = inter(l, {
				rho: w / 2,
				theta: 0,
				votes: 0
			});
			return p ? p[1] : 0;
		};
		const midX = (l) => {
			const p = inter(l, {
				rho: h / 2,
				theta: Math.PI / 2,
				votes: 0
			});
			return p ? p[0] : 0;
		};
		if (midY(top) > midY(bot)) [top, bot] = [bot, top];
		if (midX(left) > midX(right)) [left, right] = [right, left];
		const tl = inter(top, left), tr = inter(top, right), br = inter(bot, right), bl = inter(bot, left);
		if (!tl || !tr || !br || !bl) continue;
		const pts = [
			tl,
			tr,
			br,
			bl
		];
		if (pts.some(([x, y]) => x < -m || y < -m || x > w + m || y > h + m)) continue;
		let sign = 0, convex = true;
		for (let i = 0; i < 4; i++) {
			const p = pts[i], q = pts[(i + 1) % 4], r = pts[(i + 2) % 4];
			const cr = (q[0] - p[0]) * (r[1] - q[1]) - (q[1] - p[1]) * (r[0] - q[0]);
			if (!sign) sign = Math.sign(cr);
			else if (Math.sign(cr) !== sign) {
				convex = false;
				break;
			}
		}
		if (!convex) continue;
		const inside = (x, y) => {
			for (let i = 0; i < 4; i++) {
				const p = pts[i], q = pts[(i + 1) % 4];
				if (Math.sign((q[0] - p[0]) * (y - p[1]) - (q[1] - p[1]) * (x - p[0])) === -sign) return false;
			}
			return true;
		};
		if (![
			[.3, .3],
			[.7, .3],
			[.7, .7],
			[.3, .7]
		].every(([u, v]) => inside(u * w, v * h))) continue;
		let area = 0;
		for (let i = 0; i < 4; i++) {
			const p = pts[i], q = pts[(i + 1) % 4];
			area += p[0] * q[1] - q[0] * p[1];
		}
		area = Math.abs(area) / 2 / (w * h);
		if (area < .05 || area > .99) continue;
		let angPen = 0;
		for (let i = 0; i < 4; i++) {
			const p = pts[(i + 3) % 4], q = pts[i], r = pts[(i + 1) % 4];
			const v1 = [p[0] - q[0], p[1] - q[1]], v2 = [r[0] - q[0], r[1] - q[1]];
			const cos = (v1[0] * v2[0] + v1[1] * v2[1]) / (Math.hypot(v1[0], v1[1]) * Math.hypot(v2[0], v2[1]) || 1);
			angPen += Math.abs(cos);
		}
		angPen /= 4;
		if (angPen > .55) continue;
		const sup = [
			0,
			1,
			2,
			3
		].map((i) => edgeSupport(pts[i], pts[(i + 1) % 4]));
		const minSup = Math.min(...sup), meanSup = sup.reduce((x, y) => x + y, 0) / 4;
		const borders = [
			0,
			1,
			2,
			3
		].filter((i) => onBorder(pts[i], pts[(i + 1) % 4])).length;
		if (minSup < .2 || borders > 3 || borders === 3 && Math.max(...sup.filter((v) => v !== .35)) < .6) continue;
		const sideLen = [
			0,
			1,
			2,
			3
		].map((i) => Math.hypot(pts[(i + 1) % 4][0] - pts[i][0], pts[(i + 1) % 4][1] - pts[i][1]));
		if ((sideLen[0] + sideLen[2]) / (sideLen[1] + sideLen[3] || 1) > 3.5 || (sideLen[1] + sideLen[3]) / (sideLen[0] + sideLen[2] || 1) > 3.5) continue;
		const bin = brightness(pts, true), bout = brightness(pts, false);
		const contrast = bout < 0 ? .15 : Math.max(-.2, Math.min(.4, (bin - bout) / 255));
		const score = meanSup * .55 + minSup * .25 + contrast * .5 + Math.sqrt(area) * .25 - angPen * .35 - borders * .06 - (borders === 3 ? .05 : 0) - clutter(pts) * .9 - innerDark(pts) * 1.6 + Math.min(.08, sideContrast(pts)) * 1.5 - (sideContrast(pts) < .04 ? .35 : 0) - Math.max(0, spill(pts) - .35) * .6;
		if (!best || score > best.score) {
			const clamp = (v) => Math.min(1, Math.max(0, v));
			best = {
				quad: pts.map(([x, y]) => [clamp(x / w), clamp(y / h)]),
				score,
				area
			};
		}
	}
	return best;
}
/** Projective aspect ratio (width / height) of a rectangle seen as quad, Zhang & He method. */
function quadAspect(quad, W, H) {
	const p = quad.map(([x, y]) => [
		x * W - W / 2,
		y * H - H / 2,
		1
	]);
	const m1 = p[0], m2 = p[1], m3 = p[3], m4 = p[2];
	const cross = (a, b) => [
		a[1] * b[2] - a[2] * b[1],
		a[2] * b[0] - a[0] * b[2],
		a[0] * b[1] - a[1] * b[0]
	];
	const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
	const d = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
	const naive = (d(m1, m2) + d(m3, m4)) / 2 / ((d(m1, m3) + d(m2, m4)) / 2);
	const k2 = dot(cross(m1, m4), m3) / dot(cross(m2, m4), m3);
	const k3 = dot(cross(m1, m4), m2) / dot(cross(m3, m4), m2);
	const n2 = m2.map((v, i) => k2 * v - m1[i]), n3 = m3.map((v, i) => k3 * v - m1[i]);
	if (Math.abs(n2[2]) < 1e-9 || Math.abs(n3[2]) < 1e-9) return naive;
	const f2 = -(n2[0] * n3[0] + n2[1] * n3[1]) / (n2[2] * n3[2]);
	if (!(f2 > 0) || !isFinite(f2)) return naive;
	const f = Math.sqrt(f2);
	if (f < Math.max(W, H) * .4 || f > Math.max(W, H) * 5) return naive;
	const r = Math.sqrt((n2[0] ** 2 + n2[1] ** 2) / f2 + n2[2] ** 2) / Math.sqrt((n3[0] ** 2 + n3[1] ** 2) / f2 + n3[2] ** 2);
	return isFinite(r) && r > .1 && r < 10 ? r : naive;
}
var PAPER_LABEL = {
	auto: "Tự nhận",
	free: "Tự do",
	a4: "A4 / A5",
	letter: "Letter",
	legal: "Legal",
	id: "Thẻ"
};
var PAPER_RATIO = {
	a4: 297 / 210,
	letter: 11 / 8.5,
	legal: 14 / 8.5,
	id: 85.6 / 54
};
/** Snap a width/height ratio to a standard paper ratio (keeps orientation). */
function snapAspect(r, paper = "auto") {
	if (paper === "free") return r;
	const portrait = r < 1;
	const long = portrait ? 1 / r : r;
	let target = long;
	if (paper !== "auto") target = PAPER_RATIO[paper];
	else {
		let bestD = .06;
		for (const v of Object.values(PAPER_RATIO)) {
			const dd = Math.abs(long - v) / v;
			if (dd < bestD) {
				bestD = dd;
				target = v;
			}
		}
	}
	return portrait ? 1 / target : target;
}
/** B09: phương sai Laplacian (độ nét) tính thẳng trên RGBA — chạy được trong Worker, không cần canvas. */
function sharpnessRgba(d, w, h, quad) {
	const g = rgbaToGray(d, w * h);
	let x0 = 1, y0 = 1, x1 = w - 1, y1 = h - 1;
	if (quad) {
		const xs = quad.map((p) => p[0] * w), ys = quad.map((p) => p[1] * h);
		x0 = Math.max(1, Math.round(Math.min(...xs) + w * .03));
		x1 = Math.min(w - 1, Math.round(Math.max(...xs) - w * .03));
		y0 = Math.max(1, Math.round(Math.min(...ys) + h * .03));
		y1 = Math.min(h - 1, Math.round(Math.max(...ys) - h * .03));
	}
	let sum = 0, sq = 0, n = 0;
	for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
		const i = y * w + x;
		const l = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w];
		sum += l;
		sq += l * l;
		n++;
	}
	return n ? sq / n - (sum / n) ** 2 : 0;
}
/** B09: tỉ lệ điểm cháy sáng (lóa) trong vùng giấy, 0..1 — trên RGBA, chạy được trong Worker. */
function glareRgba(d, w, h, quad) {
	let x0 = 0, y0 = 0, x1 = w, y1 = h;
	if (quad) {
		const xs = quad.map((p) => p[0] * w), ys = quad.map((p) => p[1] * h);
		x0 = Math.max(0, Math.round(Math.min(...xs)));
		x1 = Math.min(w, Math.round(Math.max(...xs)));
		y0 = Math.max(0, Math.round(Math.min(...ys)));
		y1 = Math.min(h, Math.round(Math.max(...ys)));
	}
	let hot = 0, n = 0;
	for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
		const i = (y * w + x) * 4;
		n++;
		if (d[i] > 250 && d[i + 1] > 250 && d[i + 2] > 250) hot++;
	}
	return n ? hot / n : 0;
}
/**
* V7: dò khung trong một Worker riêng (không xếp hàng sau việc dựng trang nặng).
* Luồng chính chỉ lấy mẫu RGBA ~320 px rồi chuyển quyền bộ đệm. Không có Worker / lỗi → dò trên luồng chính.
*/
/** CS-03b: thời gian luồng chính (ms) của lần lấy mẫu khung gần nhất trong detectFrameAsync. */
var lastSampleMs = 0;
var v7Stats = {
	worker: 0,
	main: 0,
	mainMs: 0,
	workerMs: 0,
	dropped: 0
};
if (typeof globalThis !== "undefined") globalThis.__v7 = v7Stats;
/** R2.1: gọi bể chung ưu tiên cao nhất (nhịp ngắm trực tiếp); null khi không có Worker. */
function detectViaPool(d, w, h, robust) {
	return runInPool("detect", {
		d,
		w,
		h,
		robust
	}, [d.buffer]);
}
/** Dò khung bất đồng bộ; kết quả giống hệt detectPaper(src, sw, sh, size). */
async function detectPaperAsync(src, sw, sh, size = 360) {
	if (!sw || !sh) return null;
	const { w, h } = detectSize(sw, sh, size);
	const robust = size >= 500;
	const d = sampleRgba(src, w, h);
	const viaPool = detectViaPool(d, w, h, robust);
	if (viaPool) {
		const t0 = performance_default.now();
		const r = await viaPool.catch(() => ({ error: "worker" }));
		if (!r.error) {
			v7Stats.worker++;
			v7Stats.workerMs += performance_default.now() - t0;
			return r.det ?? null;
		}
		return detectPaperAsync(src, sw, sh, size);
	}
	const t0 = performance_default.now();
	const det = detectFromRgba(d, w, h, robust);
	v7Stats.main++;
	v7Stats.mainMs += performance_default.now() - t0;
	return det;
}
/** B09: một nhịp ngắm trọn gói — dò khung + độ nét + lóa đều tính trong Worker trên cùng bản mẫu RGBA.
*  Không có Worker / lỗi → tính trên luồng chính nhưng vẫn trên bản mẫu nhỏ (không vẽ lại canvas). */
async function detectFrameAsync(src, sw, sh, size = 320) {
	if (!sw || !sh) return {
		det: null,
		sharp: 0,
		glare: 0,
		fromWorker: false
	};
	const { w, h } = detectSize(sw, sh, size);
	const robust = size >= 500;
	const ts = performance_default.now();
	const d = sampleRgba(src, w, h);
	lastSampleMs = performance_default.now() - ts;
	const viaPool = detectViaPool(d, w, h, robust);
	if (viaPool) {
		const t0 = performance_default.now();
		const r = await viaPool.catch(() => ({ error: "worker" }));
		if (!r.error) {
			v7Stats.worker++;
			v7Stats.workerMs += performance_default.now() - t0;
			return {
				det: r.det ?? null,
				sharp: r.sharp ?? 0,
				glare: r.glare ?? 0,
				fromWorker: true
			};
		}
		return detectFrameAsync(src, sw, sh, size);
	}
	const t0 = performance_default.now();
	const det = detectFromRgba(d, w, h, robust);
	const sharp = sharpnessRgba(d, w, h, det?.quad ?? null);
	const gl = glareRgba(d, w, h, det?.quad ?? null);
	v7Stats.main++;
	v7Stats.mainMs += performance_default.now() - t0;
	return {
		det,
		sharp,
		glare: gl,
		fromWorker: false
	};
}
var vfOff = false;
/**
* CS-03b: một nhịp ngắm gần như không tốn luồng chính. new VideoFrame(video) chỉ tham chiếu khung camera (không chép);
* Worker vẽ nó thành bản mẫu dò (cùng detectSize/robust như detectFrameAsync), khung nhỏ tw×th và — khi `ring` —
* ImageBitmap cỡ đầy đủ cho vòng đệm (trước đây createImageBitmap(video) + 2 lần drawImage(video) trên luồng chính,
* ~250 ms/nhịp ở CPU 6×). Trả null khi trình duyệt không có VideoFrame/Worker, khung có xoay (cỡ lệch video) hoặc
* Worker lỗi (tắt hẳn đường này) → gọi nơi dùng đường cũ.
*/
async function detectVideoFrameAsync(v, size, tw, th, ring, detect = true) {
	const VF = globalThis.VideoFrame;
	if (vfOff || !VF || !poolCanvasSupported() || !v.videoWidth || !v.videoHeight) return null;
	const ts = performance_default.now();
	let vf;
	try {
		vf = new VF(v);
	} catch {
		vfOff = true;
		return null;
	}
	if (vf.displayWidth !== v.videoWidth || vf.displayHeight !== v.videoHeight) {
		vf.close();
		vfOff = true;
		return null;
	}
	const { w, h } = detectSize(v.videoWidth, v.videoHeight, size);
	const job = runInPool("frame", {
		vf,
		w,
		h,
		robust: size >= 500,
		detect,
		tw,
		th,
		ring
	}, [vf]);
	lastSampleMs = performance_default.now() - ts;
	if (!job) {
		vf.close();
		vfOff = true;
		return null;
	}
	const r = await job.catch(() => ({ error: "worker" }));
	if (r.error || !("px" in r) || !r.px) {
		vfOff = true;
		return null;
	}
	v7Stats.worker++;
	return {
		det: r.det ?? null,
		sharp: r.sharp ?? 0,
		glare: r.glare ?? 0,
		fromWorker: true,
		px: r.px,
		bmp: r.bmp ?? null
	};
}
var luma$1 = (d, i) => d[i] * .299 + d[i + 1] * .587 + d[i + 2] * .114;
function morph(g, w, h, r, isMax) {
	const tmp = new Float32Array(g.length), out = new Float32Array(g.length);
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		let m = isMax ? -1 : 1e9;
		for (let k = Math.max(0, x - r); k <= Math.min(w - 1, x + r); k++) {
			const v = g[y * w + k];
			m = isMax ? Math.max(m, v) : Math.min(m, v);
		}
		tmp[y * w + x] = m;
	}
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		let m = isMax ? -1 : 1e9;
		for (let k = Math.max(0, y - r); k <= Math.min(h - 1, y + r); k++) {
			const v = tmp[k * w + x];
			m = isMax ? Math.max(m, v) : Math.min(m, v);
		}
		out[y * w + x] = m;
	}
	return out;
}
function boxBlur(g, w, h, r) {
	const tmp = new Float32Array(g.length), out = new Float32Array(g.length);
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		let s = 0, n = 0;
		for (let k = Math.max(0, x - r); k <= Math.min(w - 1, x + r); k++) {
			s += g[y * w + k];
			n++;
		}
		tmp[y * w + x] = s / n;
	}
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		let s = 0, n = 0;
		for (let k = Math.max(0, y - r); k <= Math.min(h - 1, y + r); k++) {
			s += tmp[k * w + x];
			n++;
		}
		out[y * w + x] = s / n;
	}
	return out;
}
/** Ước lượng lớp chiếu sáng. `cell` = cỡ khối (px ảnh gốc) — đủ lớn để chứa vài nét chữ. */
function estimateIllumination(d, W, H, cell = Math.max(8, Math.round(Math.max(W, H) / 48))) {
	const gw = Math.max(2, Math.ceil(W / cell)), gh = Math.max(2, Math.ceil(H / cell));
	const grid = new Float32Array(gw * gh);
	const hist = /* @__PURE__ */ new Uint32Array(256);
	for (let gy = 0; gy < gh; gy++) for (let gx = 0; gx < gw; gx++) {
		hist.fill(0);
		const x0 = Math.floor(gx * W / gw), x1 = Math.max(x0 + 1, Math.floor((gx + 1) * W / gw));
		const y0 = Math.floor(gy * H / gh), y1 = Math.max(y0 + 1, Math.floor((gy + 1) * H / gh));
		let n = 0;
		for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
			hist[luma$1(d, (y * W + x) * 4) | 0]++;
			n++;
		}
		let acc = 0, v = 255;
		const target = n * .9;
		for (let i = 0; i < 256; i++) {
			acc += hist[i];
			if (acc >= target) {
				v = i;
				break;
			}
		}
		grid[gy * gw + gx] = v;
	}
	let g = morph(grid, gw, gh, 1, true);
	g = morph(g, gw, gh, 1, false);
	g = boxBlur(g, gw, gh, 1);
	return {
		grid: g,
		gw,
		gh,
		W,
		H
	};
}
/** Giá trị chiếu sáng tại điểm (x, y), nội suy song tuyến. */
function illumAt(m, x, y) {
	const u = Math.min(m.gw - 1.001, Math.max(0, (x + .5) * m.gw / m.W - .5));
	const v = Math.min(m.gh - 1.001, Math.max(0, (y + .5) * m.gh / m.H - .5));
	const u0 = u | 0, v0 = v | 0, fu = u - u0, fv = v - v0, g = m.grid, w = m.gw;
	const a = g[v0 * w + u0], b = g[v0 * w + u0 + 1], c = g[(v0 + 1) * w + u0], e = g[(v0 + 1) * w + u0 + 1];
	return (a * (1 - fu) + b * fu) * (1 - fv) + (c * (1 - fu) + e * fu) * fv;
}
/**
* Khử bóng: chia độ sáng cho lớp chiếu sáng, đưa giấy về `paper` (mặc định 245).
* `strength` 0..1 trộn giữa ảnh gốc và ảnh đã khử. Giữ tỉ lệ màu RGB.
*/
function removeShadow(d, W, H, strength = 1, paper = 245, map = estimateIllumination(d, W, H)) {
	const s = Math.min(1, Math.max(0, strength));
	for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
		const i = (y * W + x) * 4;
		const L = illumAt(map, x, y);
		const gain = 1 + (paper / Math.max(30, L) - 1) * s;
		for (let k = 0; k < 3; k++) d[i + k] = Math.min(255, d[i + k] * gain);
	}
	return d;
}
/**
* G2-02 — Khử bóng đậm/bóng tay: hai lượt (khối thô rồi khối mịn để bám mép bóng tay),
* sau đó kéo giãn để mực trong vùng bóng đậm không bị xám.
*/
function deshadowPixels$1(d, W, H) {
	const L = Math.max(W, H);
	removeShadow(d, W, H, 1, 245, estimateIllumination(d, W, H, Math.max(8, Math.round(L / 40))));
	removeShadow(d, W, H, .8, 245, estimateIllumination(d, W, H, Math.max(6, Math.round(L / 90))));
	for (let i = 0; i < d.length; i += 4) for (let k = 0; k < 3; k++) {
		const v = d[i + k];
		d[i + k] = v >= 235 ? 255 : Math.max(0, (v - 10) * (255 / 225));
	}
	return d;
}
/**
* G4-15 — Khử nhiễu độ sáng + màu (ảnh chụp thiếu sáng).
* Độ sáng: lọc song phương 5×5 (giữ cạnh chữ). Màu: làm mờ hộp Cb/Cr bán kính 2.
* Pure, chạy trên mảng RGBA.
*/
function denoise(s, w, h, strength = 1) {
	const n = w * h, Y = new Float32Array(n), U = new Float32Array(n), V = new Float32Array(n);
	for (let p = 0; p < n; p++) {
		const r = s[p * 4], g = s[p * 4 + 1], b = s[p * 4 + 2];
		Y[p] = .299 * r + .587 * g + .114 * b;
		U[p] = b - Y[p];
		V[p] = r - Y[p];
	}
	const sig = 18 * strength, inv = -1 / (2 * sig * sig), R = 2;
	const Yo = new Float32Array(n), Uo = new Float32Array(n), Vo = new Float32Array(n);
	const sp = [];
	for (let dy = -2; dy <= R; dy++) for (let dx = -2; dx <= R; dx++) sp.push(Math.exp(-(dx * dx + dy * dy) / 4.5));
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		const p = y * w + x, c = Y[p];
		let sw = 0, sy = 0, su = 0, sv = 0, k = 0, cnt = 0;
		for (let dy = -2; dy <= R; dy++) {
			const yy = Math.min(h - 1, Math.max(0, y + dy));
			for (let dx = -2; dx <= R; dx++, k++) {
				const q = yy * w + Math.min(w - 1, Math.max(0, x + dx)), d = Y[q] - c;
				const wt = sp[k] * Math.exp(d * d * inv);
				sw += wt;
				sy += wt * Y[q];
				su += U[q];
				sv += V[q];
				cnt++;
			}
		}
		Yo[p] = sy / sw;
		Uo[p] = su / cnt;
		Vo[p] = sv / cnt;
	}
	const d = new Uint8ClampedArray(s);
	for (let p = 0; p < n; p++) {
		const y = Yo[p], r = Vo[p] + y, b = Uo[p] + y;
		d[p * 4] = r;
		d[p * 4 + 2] = b;
		d[p * 4 + 1] = (y - .299 * r - .114 * b) / .587;
	}
	return d;
}
/** P4.3–P4.6 – Công cụ chỉnh 3 mức (thuần điểm ảnh): Làm rõ chữ, Sáng nền, Xoá góc ố đen.
*  Mức 0 = tắt, 1 = nhẹ, 2 = vừa, 3 = mạnh. Chạy sau bộ lọc, trước độ sáng/tương phản. */
var TOOL_LABEL = {
	clarify: "Làm rõ chữ",
	whiten: "Sáng nền",
	corners: "Xoá góc ố đen",
	deshadow: "Khử bóng",
	denoise: "Khử nhiễu"
};
var LEVEL_LABEL = [
	"Tắt",
	"Nhẹ",
	"Vừa",
	"Mạnh"
];
var TOOL_KEYS = [
	"clarify",
	"whiten",
	"corners",
	"deshadow",
	"denoise"
];
/** Tham số theo mức — tăng dần đơn điệu. */
var CLARIFY_AMOUNT = [
	0,
	.6,
	1.1,
	1.8
];
var CLARIFY_INK = [
	0,
	.08,
	.16,
	.26
];
var WHITEN_TARGET = [
	0,
	.94,
	.88,
	.8
];
var CORNER_STRENGTH = [
	0,
	.5,
	.8,
	1
];
/** R6.1 – Khử bóng: phần bù nền cục bộ (chia cho nền ước lượng theo ô). */
var DESHADOW_STRENGTH = [
	0,
	.55,
	.8,
	1
];
/** R6.1 – Khử nhiễu: độ mạnh lọc song phương (denoise.ts). */
var DENOISE_STRENGTH = [
	0,
	.6,
	1,
	1.6
];
function clampLevel(v) {
	const n = Math.round(Number(v));
	return n >= 3 ? 3 : n <= 0 || !Number.isFinite(n) ? 0 : n;
}
function hasTools(t) {
	return !!t && TOOL_KEYS.some((k) => clampLevel(t[k]) > 0);
}
/** Chuỗi khoá ổn định cho bộ đệm/so sánh. */
function toolsKey(t) {
	return TOOL_KEYS.map((k) => clampLevel(t?.[k])).join("");
}
var luma = (d, i) => d[i] * .299 + d[i + 1] * .587 + d[i + 2] * .114;
/** Phân vị độ chói (lấy mẫu thưa). */
function lumaPercentile(d, p) {
	const hist = /* @__PURE__ */ new Uint32Array(256);
	let n = 0;
	const step = d.length > 4e6 ? 32 : 4;
	for (let i = 0; i < d.length; i += step) {
		hist[luma(d, i) | 0]++;
		n++;
	}
	const want = n * p;
	let acc = 0;
	for (let v = 0; v < 256; v++) {
		acc += hist[v];
		if (acc >= want) return v;
	}
	return 255;
}
/** Sáng nền: kéo điểm nền (phân vị cao) về trắng, giữ chữ tối. */
function whitenPixels(d, level) {
	if (!level) return d;
	const gain = 255 / Math.max(120, lumaPercentile(d, WHITEN_TARGET[level]));
	for (let i = 0; i < d.length; i += 4) for (let k = 0; k < 3; k++) d[i + k] = Math.min(255, d[i + k] * gain);
	return d;
}
/** Làm rõ chữ: làm nét độ chói bằng mờ hộp 3×3 + đậm thêm nét tối. */
function clarifyPixels(d, W, H, level) {
	if (!level || W < 3 || H < 3) return d;
	const amt = CLARIFY_AMOUNT[level], ink = CLARIFY_INK[level];
	const Y = new Float32Array(W * H);
	for (let p = 0, i = 0; p < Y.length; p++, i += 4) Y[p] = luma(d, i);
	for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
		let s = 0, c = 0;
		for (let dy = -1; dy <= 1; dy++) {
			const yy = y + dy;
			if (yy < 0 || yy >= H) continue;
			for (let dx = -1; dx <= 1; dx++) {
				const xx = x + dx;
				if (xx < 0 || xx >= W) continue;
				s += Y[yy * W + xx];
				c++;
			}
		}
		const p = y * W + x, i = p * 4, y0 = Y[p];
		let ny = y0 + (y0 - s / c) * amt;
		if (ny < 160) ny -= (160 - ny) * ink;
		const delta = ny - y0;
		for (let k = 0; k < 3; k++) d[i + k] = Math.min(255, Math.max(0, d[i + k] + delta));
	}
	return d;
}
/** Xoá góc ố đen: đo nền theo vòng khoảng cách tới tâm, nâng các vòng ngoài tối hơn tâm. */
function cornersPixels(d, W, H, level) {
	if (!level || W < 4 || H < 4) return d;
	const RINGS = 16, cx = (W - 1) / 2, cy = (H - 1) / 2, rmax = Math.hypot(cx, cy) || 1;
	const ringOf = (x, y) => Math.min(15, Math.floor(Math.hypot(x - cx, y - cy) / rmax * RINGS));
	const hists = Array.from({ length: RINGS }, () => /* @__PURE__ */ new Uint32Array(256));
	const step = Math.max(1, Math.round(Math.sqrt(W * H / 25e4)));
	for (let y = 0; y < H; y += step) for (let x = 0; x < W; x += step) hists[ringOf(x, y)][luma(d, (y * W + x) * 4) | 0]++;
	const bg = hists.map((h) => {
		let n = 0;
		for (const v of h) n += v;
		if (!n) return -1;
		let acc = 0;
		for (let v = 0; v < 256; v++) {
			acc += h[v];
			if (acc >= n * .8) return v;
		}
		return 255;
	});
	const center = Math.max(1, ...bg.slice(0, 4).filter((v) => v > 0));
	const s = CORNER_STRENGTH[level];
	const gain = bg.map((v) => v <= 0 ? 1 : 1 + Math.max(0, center / Math.max(20, v) - 1) * s);
	for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
		const t = Math.hypot(x - cx, y - cy) / rmax * RINGS - .5;
		const a = Math.max(0, Math.min(15, Math.floor(t))), b = Math.min(15, a + 1), f = Math.max(0, Math.min(1, t - a));
		const g = gain[a] * (1 - f) + gain[b] * f;
		if (g <= 1.001) continue;
		const i = (y * W + x) * 4;
		for (let k = 0; k < 3; k++) d[i + k] = Math.min(255, d[i + k] * g);
	}
	return d;
}
/** R6.1 – Khử bóng: ước lượng nền theo lưới ô (phân vị 90%), nội suy song tuyến, chia nền về trắng.
*  Bóng tay/điện thoại đổ lên giấy là biến thiên nền tần số thấp → san phẳng mà giữ nét chữ. */
function deshadowPixels(d, W, H, level) {
	if (!level || W < 8 || H < 8) return d;
	const G = 16, cw = W / G, ch = H / G, s = DESHADOW_STRENGTH[level];
	const bg = /* @__PURE__ */ new Float32Array(256);
	const step = Math.max(1, Math.round(Math.sqrt(W * H / 4e5)));
	for (let gy = 0; gy < G; gy++) for (let gx = 0; gx < G; gx++) {
		const h = /* @__PURE__ */ new Uint32Array(256);
		let n = 0;
		const x0 = Math.floor(gx * cw), x1 = Math.max(x0 + 1, Math.floor((gx + 1) * cw));
		const y0 = Math.floor(gy * ch), y1 = Math.max(y0 + 1, Math.floor((gy + 1) * ch));
		for (let y = y0; y < y1; y += step) for (let x = x0; x < x1; x += step) {
			h[luma(d, (y * W + x) * 4) | 0]++;
			n++;
		}
		let acc = 0, v = 255;
		for (let k = 0; k < 256; k++) {
			acc += h[k];
			if (acc >= n * .9) {
				v = k;
				break;
			}
		}
		bg[gy * G + gx] = Math.max(24, v);
	}
	let ref = 0;
	for (const v of bg) ref = Math.max(ref, v);
	for (let y = 0; y < H; y++) {
		const fy = Math.max(0, Math.min(15, y / ch - .5)), ay = Math.floor(fy), by = Math.min(15, ay + 1), ty = fy - ay;
		for (let x = 0; x < W; x++) {
			const fx = Math.max(0, Math.min(15, x / cw - .5)), ax = Math.floor(fx), bx = Math.min(15, ax + 1), tx = fx - ax;
			const b = (bg[ay * G + ax] * (1 - tx) + bg[ay * G + bx] * tx) * (1 - ty) + (bg[by * G + ax] * (1 - tx) + bg[by * G + bx] * tx) * ty;
			const g = 1 + (ref / b - 1) * s;
			if (g <= 1.001) continue;
			const i = (y * W + x) * 4;
			for (let k = 0; k < 3; k++) d[i + k] = Math.min(255, d[i + k] * g);
		}
	}
	return d;
}
/** R6.1 – Khử nhiễu 3 cấp (song phương giữ cạnh chữ). */
function denoisePixels(d, W, H, level) {
	if (!level || W < 3 || H < 3) return d;
	d.set(denoise(d, W, H, DENOISE_STRENGTH[level]));
	return d;
}
/** Chạy công cụ theo thứ tự cố định: nhiễu → bóng → góc → nền → chữ. */
function applyTools(d, W, H, t) {
	if (!hasTools(t)) return d;
	denoisePixels(d, W, H, clampLevel(t.denoise));
	deshadowPixels(d, W, H, clampLevel(t.deshadow));
	cornersPixels(d, W, H, clampLevel(t.corners));
	whitenPixels(d, clampLevel(t.whiten));
	clarifyPixels(d, W, H, clampLevel(t.clarify));
	return d;
}
function levelParams(d, n = d.length) {
	const hist = /* @__PURE__ */ new Uint32Array(256);
	for (let i = 0; i < n; i += 16) hist[d[i] * .3 + d[i + 1] * .59 + d[i + 2] * .11 | 0]++;
	const total = Math.ceil(n / 16);
	let acc = 0, lo = 0;
	for (let i = 0; i < 256; i++) {
		acc += hist[i];
		if (acc > total * .01) {
			lo = i;
			break;
		}
	}
	acc = 0;
	let top = 255;
	for (let i = 255; i >= 0; i--) {
		acc += hist[i];
		if (acc > total * .01) {
			top = i;
			break;
		}
	}
	const mid = lo + top >> 1;
	let cnt = 0;
	for (let i = mid; i < 256; i++) cnt += hist[i];
	acc = 0;
	let paper = top;
	for (let i = mid; i < 256; i++) {
		acc += hist[i];
		if (acc >= cnt / 2) {
			paper = i;
			break;
		}
	}
	paper = Math.max(lo + 30, paper);
	return {
		lo,
		paper
	};
}
/** Áp mức tại chỗ trên RGBA. boost > 1 tăng tương phản nét (chế độ Sắc nét). */
function autoLevel(d, boost = 1) {
	const n = d.length;
	const { lo, paper } = levelParams(d, n);
	const lut = /* @__PURE__ */ new Uint8ClampedArray(256);
	for (let v = 0; v < 256; v++) {
		let y;
		if (v <= paper) {
			const t = Math.max(0, (v - lo) / (paper - lo));
			y = 248 * Math.pow(t, boost);
		} else y = 248 + 7 * Math.min(1, (v - paper) / Math.max(1, 255 - paper));
		lut[v] = Math.round(y);
	}
	for (let i = 0; i < n; i += 4) {
		d[i] = lut[d[i]];
		d[i + 1] = lut[d[i + 1]];
		d[i + 2] = lut[d[i + 2]];
	}
	showThroughLift(d);
	return {
		lo,
		paper
	};
}
function showThroughLift(d, lo = 200, hi = 248) {
	for (let i = 0; i < d.length; i += 4) {
		const r = d[i], g = d[i + 1], b = d[i + 2];
		if (Math.max(r, g, b) - Math.min(r, g, b) >= 22) continue;
		const y = r * .3 + g * .59 + b * .11;
		if (y < lo || y >= hi) continue;
		const t = (y - lo) / (hi - lo);
		const k = t * t * (3 - 2 * t);
		const add = (hi - y) * k;
		d[i] = r + add;
		d[i + 1] = g + add;
		d[i + 2] = b + add;
	}
}
function whitenPaper(d) {
	const lut = /* @__PURE__ */ new Uint8ClampedArray(256);
	for (let v = 0; v < 256; v++) if (v <= 232) lut[v] = v;
	else if (v >= 244) lut[v] = 255;
	else {
		const t = (v - 232) / 12;
		const k = t * t * (3 - 2 * t);
		lut[v] = Math.round(v + (255 - v) * k);
	}
	for (let i = 0; i < d.length; i += 4) {
		d[i] = lut[d[i]];
		d[i + 1] = lut[d[i + 1]];
		d[i + 2] = lut[d[i + 2]];
	}
}
function inkCurve(v, knee = 200, gamma = 3) {
	return v >= knee ? v : knee * Math.pow(Math.max(0, v) / knee, gamma);
}
/**
* HM-11 (R6.1e, Q3=a): điểm màu bão hoà-tối Ở MÉP TRANG (số trang đỏ, logo) chỉ được tối đi tối đa còn SAT_FLOOR lần mỗi lượt.
* Hai lượt đậm hoá (200/3,0 rồi 170/2,2) trước đây ép khối đỏ (độ sáng ≈ 75) xuống ≈ 3 → đen; cổng R6.1 đếm điểm rất tối ở 4 góc
* (ảnh NB: góc dưới-trái 0,7% → 42,6%). Chỉ bảo vệ dải mép: bảo vệ toàn trang làm ΔL (chữ/nền) tụt 83 → 54 vì trang màu nhiều.
* Chữ/mực trung tính và mọi điểm thân trang không đổi.
*/
var SAT_FLOOR = .6;
var EDGE_BAND = .08;
var saturated = (r, g, b) => {
	const mx = Math.max(r, g, b), c = mx - Math.min(r, g, b);
	return c >= 30 && c >= .3 * mx;
};
/** Mặt nạ 1 byte/điểm ảnh: điểm màu bão hoà-tối (độ sáng < 170) nằm trong dải mép. Tính TRƯỚC khi bộ lọc làm mất màu. */
function edgeSaturatedMask(d, W, H) {
	const m = new Uint8Array(W * H), bx = Math.ceil(W * EDGE_BAND), by = Math.ceil(H * EDGE_BAND);
	for (let y = 0; y < H; y++) {
		const full = y < by || y >= H - by;
		for (let x = 0; x < W; x++) {
			if (!full && x >= bx && x < W - bx) {
				x = W - bx - 1;
				continue;
			}
			const i = (y * W + x) * 4;
			if (d[i + 3] !== 0 && saturated(d[i], d[i + 1], d[i + 2]) && d[i] * .3 + d[i + 1] * .59 + d[i + 2] * .11 < 170) m[y * W + x] = 1;
		}
	}
	return m;
}
/** `protect` (tuỳ chọn): mặt nạ từ edgeSaturatedMask; điểm được bảo vệ chỉ giảm tối thiểu đến SAT_FLOOR mỗi lượt. */
function inkDeepen(d, knee = 200, gamma = 3, protect) {
	const lut = /* @__PURE__ */ new Float32Array(256);
	for (let v = 0; v < 256; v++) lut[v] = v ? inkCurve(v, knee, gamma) / v : 0;
	for (let i = 0; i < d.length; i += 4) {
		const y = d[i] * .3 + d[i + 1] * .59 + d[i + 2] * .11 | 0;
		if (y >= knee) continue;
		let k = lut[y];
		if (protect && k < .6 && protect[i >> 2]) k = SAT_FLOOR;
		d[i] *= k;
		d[i + 1] *= k;
		d[i + 2] *= k;
	}
	return d;
}
function regionAngle(g, W, x0, x1, y0, y1, maxDeg = 3, step = .25, thr = 140) {
	const H = y1 - y0, cx = (x0 + x1) / 2;
	let best = 0, bestScore = -1, ink = 0;
	const xs = Math.max(1, (x1 - x0) / 200 | 0);
	for (let y = y0; y < y1; y += 2) for (let x = x0; x < x1; x += xs) if (g[y * W + x] < thr) ink++;
	const nx = Math.max(0, Math.ceil((x1 - x0) / xs)), Hs = Math.max(0, H);
	const P = new Int32Array((nx + 1) * Hs);
	for (let j = 0; j < nx; j++) {
		const x = x0 + j * xs, a0 = j * H, a1 = a0 + H;
		for (let py = 0; py < H; py++) P[a1 + py] = P[a0 + py] + (g[(y0 + py) * W + x] < thr ? 1 : 0);
	}
	const prof = new Float64Array(H + 1);
	const nearTie = (q) => Math.abs(q - Math.floor(q) - .5) < 1e-9;
	for (let a = -maxDeg; a <= maxDeg + 1e-9; a += step) {
		const t = Math.tan(a * Math.PI / 180);
		prof.fill(0);
		for (let j = 0; j < nx;) {
			const x = x0 + j * xs, o = (x - cx) * t;
			if (nearTie(-o)) {
				for (let py = 0; py < H; py++) {
					if (g[(y0 + py) * W + x] >= thr) continue;
					const r = Math.round(py - o);
					if (r >= 0 && r <= H) prof[r]++;
				}
				j++;
				continue;
			}
			const c = Math.round(-o);
			let j2 = j + 1;
			for (; j2 < nx; j2++) {
				const q = -((x0 + j2 * xs - cx) * t);
				if (nearTie(q) || Math.round(q) !== c) break;
			}
			const lo = Math.max(0, c), hi = Math.min(H, H - 1 + c), A = j2 * H - c, B = j * H - c;
			for (let r = lo; r <= hi; r++) prof[r] += P[A + r] - P[B + r];
			j = j2;
		}
		let s = 0;
		for (let r = 1; r <= H; r++) {
			const d = prof[r] - prof[r - 1];
			s += d * d;
		}
		if (s > bestScore) {
			bestScore = s;
			best = a;
		}
	}
	return {
		angle: best,
		ink
	};
}
/** Bảng làm tròn của v + 0,5 khi gán vào Uint8ClampedArray (làm tròn nửa về số chẵn: lẻ → +1). */
var HALF_UP = Uint8Array.from({ length: 256 }, (_, v) => v & 1 ? Math.min(255, v + 1) : v);
function roundHalfRow(d, out, o, n) {
	for (let i = o, e = o + n; i < e; i++) out[i] = HALF_UP[d[i]];
}
/** Lấy mẫu dọc song tuyến tại (x, sy) ghi vào (x, y) — chung cho các bước nắn dòng (CS-17a: tách ra, cùng phép tính). */
function sampleV(d, out, W, H, x, y, sy) {
	sy = Math.min(H - 1.001, Math.max(0, sy));
	const y0 = sy | 0, f = sy - y0, g = 1 - f, i0 = (y0 * W + x) * 4, i1 = i0 + W * 4, o = (y * W + x) * 4;
	out[o] = d[i0] * g + d[i1] * f + .5;
	out[o + 1] = d[i0 + 1] * g + d[i1 + 1] * f + .5;
	out[o + 2] = d[i0 + 2] * g + d[i1 + 2] * f + .5;
	out[o + 3] = d[i0 + 3] * g + d[i1 + 3] * f + .5;
}
function lineSkewMap(g, W, H, bands = 6) {
	const mx = W * .06 | 0, my = H * .04 | 0;
	const bh = (H - 2 * my) / bands | 0, half = (W - 2 * mx) / 2 | 0;
	const cells = [];
	for (let b = 0; b < bands; b++) {
		const y0 = my + b * bh;
		for (const side of [0, 1]) {
			const x0 = mx + side * half;
			const r = regionAngle(g, W, x0, x0 + half, y0, y0 + bh);
			cells.push({
				band: b,
				side,
				...r
			});
		}
	}
	const curve = (from, to) => {
		let m = 0;
		for (let b = from; b < to; b++) {
			const l = cells[b * 2], r = cells[b * 2 + 1];
			if (l.ink > 50 && r.ink > 50) m = Math.max(m, Math.abs(l.angle - r.angle));
		}
		return m;
	};
	const tilt = (from, to) => {
		let s = 0, n = 0;
		for (const c of cells) if (c.band >= from && c.band < to && c.ink > 50) {
			s += c.angle;
			n++;
		}
		return n ? s / n : 0;
	};
	const h = bands >> 1;
	return {
		cells,
		top: {
			curve: curve(0, h),
			tilt: tilt(0, h)
		},
		bottom: {
			curve: curve(h, bands),
			tilt: tilt(h, bands)
		}
	};
}
/**
* S11g – Nắn bù góc dòng nửa dưới theo số đo từng ô (lineSkewMap).
* Độ dốc dòng tan(góc) được nội suy song tuyến giữa tâm các ô; nửa trên = 0
* (chuyển mượt qua tâm dải giữa). Dịch dọc tại (x, y) = tích phân độ dốc từ
* tâm trang tới x, nên tâm trang đứng yên. Ô ít mực hoặc |góc| < minDeg bỏ qua.
* Lấy mẫu song tuyến; trả ảnh RGBA mới cùng cỡ.
*/
function lineSkewCorrect(d, W, H, cells, bands = 6, opts = {}) {
	const from = opts.fromBand ?? bands >> 1, to = opts.toBand ?? bands, minDeg = opts.minDeg ?? .25, minInk = opts.minInk ?? 50;
	const mx = W * .06 | 0, my = H * .04 | 0;
	const bh = (H - 2 * my) / bands | 0, half = (W - 2 * mx) / 2 | 0;
	const slope = (b, s) => {
		if (b < from || b >= to) return 0;
		const c = cells[b * 2 + s];
		if (!c || c.ink <= minInk || Math.abs(c.angle) < minDeg) return 0;
		return Math.tan(c.angle * Math.PI / 180);
	};
	if (cells.every((_, i) => slope(i >> 1, i & 1) === 0)) return new Uint8ClampedArray(d);
	const xl = mx + half / 2, xr = mx + half * 1.5, cx = W / 2;
	const out = new Uint8ClampedArray(d.length);
	const row = new Float64Array(W);
	for (let y = 0; y < H; y++) {
		const fb = Math.min(bands - 1, Math.max(0, (y - my) / bh - .5));
		const b0 = Math.floor(fb), b1 = Math.min(bands - 1, b0 + 1), tb = fb - b0;
		const sl = slope(b0, 0) * (1 - tb) + slope(b1, 0) * tb;
		const sr = slope(b0, 1) * (1 - tb) + slope(b1, 1) * tb;
		if (sl === 0 && sr === 0 && y < H - 1) {
			roundHalfRow(d, out, y * W * 4, W * 4);
			continue;
		}
		const k = (x) => {
			const t = Math.min(1, Math.max(0, (x - xl) / (xr - xl)));
			return sl * (1 - t) + sr * t;
		};
		const c0 = Math.round(cx);
		row[c0] = 0;
		for (let x = c0 + 1; x < W; x++) row[x] = row[x - 1] + k(x - .5);
		for (let x = c0 - 1; x >= 0; x--) row[x] = row[x + 1] - k(x + .5);
		for (let x = 0; x < W; x++) sampleV(d, out, W, H, x, y, y + row[x]);
	}
	return out;
}
/**
* S11i – Nắn nhiều lượt: sau lượt 1, đo lại và nắn tiếp các ô còn lệch.
* Mỗi lượt chỉ được giữ nếu điểm nửa dưới (max |góc| + cong) giảm; dừng khi
* đạt chỉ tiêu (mọi ô ≤ 0,5°, cong ≤ 0,5°) hoặc hết số lượt.
*/
function lineSkewRefine(d, W, H, passes = 2, bands = 6) {
	const gray = (p) => {
		const g = new Uint8Array(W * H);
		for (let i = 0, j = 0; j < g.length; i += 4, j++) g[j] = p[i] * 77 + p[i + 1] * 150 + p[i + 2] * 29 >> 8;
		return g;
	};
	const from = bands >> 1;
	const score = (m) => {
		let a = 0;
		for (const c of m.cells) if (c.band >= from && c.ink > 50) a = Math.max(a, Math.abs(c.angle));
		return {
			a,
			curve: m.bottom.curve,
			s: a + m.bottom.curve
		};
	};
	let cur = d, m = lineSkewMap(gray(cur), W, H, bands), sc = score(m), used = 0;
	for (let p = 0; p < passes; p++) {
		if (sc.a <= .5 && sc.curve <= .5 && p > 0) break;
		const next = lineSkewCorrect(cur, W, H, m.cells, bands);
		const m2 = lineSkewMap(gray(next), W, H, bands), sc2 = score(m2);
		if (p > 0 && sc2.s >= sc.s) break;
		cur = next;
		m = m2;
		sc = sc2;
		used++;
	}
	return {
		data: cur === d ? new Uint8ClampedArray(d) : cur,
		passes: used,
		score: sc.s
	};
}
/**
* S11k – Nắn nửa trên (tiêu đề/bảng gây nhiễu đo). Chỉ tin ô có mực ≥ minInk
* và góc nhất quán với ô cùng bên ở dải kề (chênh ≤ 0,75°) hoặc với ô đối
* diện cùng dải; ô lẻ loi bị bỏ. Giữ kết quả chỉ khi điểm nửa trên giảm và
* nửa dưới không xấu đi. Nửa dưới không bị dịch (toBand = bands/2).
*/
function lineSkewRefineTop(d, W, H, passes = 2, bands = 6, minInk = 150) {
	const gray = (p) => {
		const g = new Uint8Array(W * H);
		for (let i = 0, j = 0; j < g.length; i += 4, j++) g[j] = p[i] * 77 + p[i + 1] * 150 + p[i + 2] * 29 >> 8;
		return g;
	};
	const h = bands >> 1;
	const trusted = (cells) => cells.map((c) => {
		if (c.band >= h || c.ink < minInk) return {
			...c,
			ink: 0
		};
		return [
			cells[(c.band - 1) * 2 + c.side],
			cells[(c.band + 1) * 2 + c.side],
			cells[c.band * 2 + (1 - c.side)]
		].filter((n) => n && n.ink >= minInk).some((n) => Math.abs(n.angle - c.angle) <= .75) ? c : {
			...c,
			ink: 0
		};
	});
	const score = (m) => {
		let a = 0, b = 0;
		for (const c of m.cells) if (c.ink > 50) if (c.band < h) a = Math.max(a, Math.abs(c.angle));
		else b = Math.max(b, Math.abs(c.angle));
		return {
			top: a + m.top.curve,
			bot: b + m.bottom.curve
		};
	};
	let cur = d, m = lineSkewMap(gray(cur), W, H, bands), sc = score(m), used = 0;
	for (let p = 0; p < passes; p++) {
		if (sc.top <= .5) break;
		const cells = trusted(m.cells);
		const next = lineSkewCorrect(cur, W, H, cells, bands, {
			fromBand: 0,
			toBand: h,
			minInk: 50
		});
		const m2 = lineSkewMap(gray(next), W, H, bands), sc2 = score(m2);
		if (sc2.top >= sc.top || sc2.bot > sc.bot) break;
		cur = next;
		m = m2;
		sc = sc2;
		used++;
	}
	return {
		data: cur === d ? new Uint8ClampedArray(d) : cur,
		passes: used,
		score: sc.top
	};
}
/**
* S11m – Nắn riêng một nửa (trái/phải) của dải trên khi lượt nắn cả hai nửa
* bị chặn. Chọn bên lệch nhất ở dải 0–2, đo lại bên đó bằng bước 0,125°,
* chỉ dịch theo góc bên đó (bên kia độ dốc 0). Giữ lượt khi |góc| tối đa bên
* đó giảm, bên kia không xấu thêm > 0,25° và nửa dưới không xấu đi.
*/
/**
* S11p – Ô dải trên có mực ít (lowInk ≤ ink < minInk) vẫn được tin khi góc
* khớp (≤ 0,75°) một ô cùng bên ở dải kề có đủ mực. Ô không được tin → ink 0.
*/
function trustTopCells(cells, h, minInk = 150, lowInk = 60, tol = .75) {
	return cells.map((c) => {
		if (c.band >= h) return c;
		if (c.ink >= minInk) return c;
		if (c.ink < lowInk) return {
			...c,
			ink: 0
		};
		return cells.some((n) => n.side === c.side && n.band < h && Math.abs(n.band - c.band) === 1 && n.ink >= minInk && Math.abs(n.angle - c.angle) <= tol) ? {
			...c,
			ink: minInk
		} : {
			...c,
			ink: 0
		};
	});
}
function lineSkewRefineTopSide(d, W, H, passes = 2, bands = 6, minInk = 150, lowInk = 60) {
	const log = [];
	const gray = (p) => {
		const g = new Uint8Array(W * H);
		for (let i = 0, j = 0; j < g.length; i += 4, j++) g[j] = p[i] * 77 + p[i + 1] * 150 + p[i + 2] * 29 >> 8;
		return g;
	};
	const h = bands >> 1;
	const mx = W * .06 | 0, my = H * .04 | 0;
	const bh = (H - 2 * my) / bands | 0, half = (W - 2 * mx) / 2 | 0;
	const fine = (g) => {
		const cells = [];
		for (let b = 0; b < bands; b++) for (const s of [0, 1]) {
			const x0 = mx + s * half, y0 = my + b * bh;
			const r = b < h ? regionAngle(g, W, x0, x0 + half, y0, y0 + bh, 3, .125) : {
				angle: 0,
				ink: 0
			};
			cells.push({
				band: b,
				side: s,
				...r
			});
		}
		return cells;
	};
	const sideMax = (cells, s) => {
		let a = 0;
		for (const c of trustTopCells(cells, h, minInk, lowInk)) if (c.band < h && c.side === s && c.ink >= minInk) a = Math.max(a, Math.abs(c.angle));
		return a;
	};
	const botMax = (p) => {
		const m = lineSkewMap(gray(p), W, H, bands);
		let b = 0;
		for (const c of m.cells) if (c.band >= h && c.ink > 50) b = Math.max(b, Math.abs(c.angle));
		return b + m.bottom.curve;
	};
	let cur = d, cells = fine(gray(cur));
	const l0 = sideMax(cells, 0), r0 = sideMax(cells, 1);
	const side = r0 >= l0 ? 1 : 0;
	if (Math.max(l0, r0) <= .5) return {
		data: new Uint8ClampedArray(d),
		passes: 0,
		side: -1,
		worst: Math.max(l0, r0),
		log: [`ok l=${l0} r=${r0} cells=${cells.filter((c) => c.band < h).map((c) => `${c.angle}/${c.ink}`).join(",")}`]
	};
	let worst = sideMax(cells, side), other = sideMax(cells, 1 - side), bot = botMax(cur), used = 0;
	for (let p = 0; p < passes && worst > .5; p++) {
		let kept = false;
		for (const k of [1, .5]) {
			const only = trustTopCells(cells, h, minInk, lowInk).map((c) => c.side === side && c.band < h && c.ink >= minInk ? {
				...c,
				angle: c.angle * k
			} : {
				...c,
				ink: 0
			});
			const next = lineSkewCorrect(cur, W, H, only, bands, {
				fromBand: 0,
				toBand: h,
				minInk: 50,
				minDeg: .0625
			});
			const c2 = fine(gray(next));
			const w2 = sideMax(c2, side), o2 = sideMax(c2, 1 - side), b2 = botMax(next);
			log.push(`p${p} k=${k} side=${side} worst ${worst}->${w2} other ${other}->${o2} bot ${bot}->${b2} cells=${cells.filter((c) => c.band < h).map((c) => `${c.angle}/${c.ink}`).join(",")} after=${c2.filter((c) => c.band < h).map((c) => `${c.angle}/${c.ink}`).join(",")}`);
			if (w2 >= worst || o2 > other + .25 || b2 > bot) continue;
			cur = next;
			cells = c2;
			worst = w2;
			other = o2;
			bot = b2;
			used++;
			kept = true;
			break;
		}
		if (!kept) break;
	}
	return {
		data: cur === d ? new Uint8ClampedArray(d) : cur,
		passes: used,
		side,
		worst,
		log
	};
}
/**
* S11r – Nắn riêng ô dải 0 (trên cùng) lệch nhất, lặp tối đa `passes` lượt.
* Chỉ dịch theo góc ô đó (các ô khác độ dốc 0) nên ô dải 1 ít mực không kéo
* dải 0 ngược chiều. Giữ lượt khi |góc| ô đó giảm, ô bên kia và dải 1–2 không
* xấu thêm > 0,25°, nửa dưới không xấu đi.
*/
function lineSkewRefineBand0(d, W, H, passes = 3, bands = 6, minInk = 150) {
	const gray = (p) => {
		const g = new Uint8Array(W * H);
		for (let i = 0, j = 0; j < g.length; i += 4, j++) g[j] = p[i] * 77 + p[i + 1] * 150 + p[i + 2] * 29 >> 8;
		return g;
	};
	const h = bands >> 1;
	let m = lineSkewMap(gray(d), W, H, bands);
	const cand = [m.cells[0], m.cells[1]].filter((c) => c.ink >= minInk && Math.abs(c.angle) > .5);
	if (!cand.length) return {
		data: new Uint8ClampedArray(d),
		passes: 0,
		side: -1,
		angle: 0
	};
	const side = cand.sort((a, b) => Math.abs(b.angle) - Math.abs(a.angle))[0].side;
	const others = (mm) => mm.cells.filter((c) => c.ink >= minInk && !(c.band === 0 && c.side === side) && c.band < h).map((c) => Math.abs(c.angle));
	const bot = (mm) => Math.max(0, ...mm.cells.filter((c) => c.band >= h && c.ink > 50).map((c) => Math.abs(c.angle))) + mm.bottom.curve;
	let cur = d, used = 0;
	for (let p = 0; p < passes; p++) {
		const a = m.cells[side].angle;
		if (Math.abs(a) <= .5) break;
		const cells = m.cells.map((c, i) => i === side ? {
			...c,
			ink: minInk
		} : {
			...c,
			ink: 0
		});
		const next = lineSkewCorrect(cur, W, H, cells, bands, {
			fromBand: 0,
			toBand: h,
			minInk: 50
		});
		const m2 = lineSkewMap(gray(next), W, H, bands);
		const o1 = others(m);
		const worse = others(m2).some((v, i) => v > (o1[i] ?? v) + .25) || bot(m2) > bot(m) || m2.cells[side].ink < 50;
		if (Math.abs(m2.cells[side].angle) >= Math.abs(a) || worse) break;
		cur = next;
		m = m2;
		used++;
	}
	return {
		data: cur === d ? new Uint8ClampedArray(d) : cur,
		passes: used,
		side,
		angle: m.cells[side].angle
	};
}
/**
* S11s – Nắn ô dải 1 (ít mực được, ≥ lowInk) còn lệch, bù dải 0 cùng bên
* trong cùng lượt. Nắn riêng dải 1 kéo dải 0 lệch theo (nội suy giữa tâm
* dải) nên trước đây lượt luôn bị bỏ. Thử các mức bù dải 0 = a0 + t·a1
* (t = 0, −0,25, −0,5, −0,75), chọn lượt làm |góc dải 1| nhỏ nhất mà dải 0
* không vượt max(0,5°, |a0|), ô khác không xấu thêm > 0,25°, nửa dưới không xấu đi.
*/
function lineSkewRefineBand1(d, W, H, passes = 2, bands = 6, minInk = 150, lowInk = 60) {
	const gray = (p) => {
		const g = new Uint8Array(W * H);
		for (let i = 0, j = 0; j < g.length; i += 4, j++) g[j] = p[i] * 77 + p[i + 1] * 150 + p[i + 2] * 29 >> 8;
		return g;
	};
	const h = bands >> 1, log = [];
	let m = lineSkewMap(gray(d), W, H, bands);
	const cand = [m.cells[2], m.cells[3]].filter((c) => c.ink >= lowInk && Math.abs(c.angle) > .5);
	if (!cand.length) return {
		data: new Uint8ClampedArray(d),
		passes: 0,
		side: -1,
		angle: 0,
		log: ["ok"]
	};
	const side = cand.sort((a, b) => Math.abs(b.angle) - Math.abs(a.angle))[0].side;
	const i0 = side, i1 = 2 + side;
	const others = (mm) => mm.cells.map((c, i) => i !== i0 && i !== i1 && c.band < h && c.ink >= minInk ? Math.abs(c.angle) : 0);
	const bot = (mm) => Math.max(0, ...mm.cells.filter((c) => c.band >= h && c.ink > 50).map((c) => Math.abs(c.angle))) + mm.bottom.curve;
	let cur = d, used = 0;
	for (let p = 0; p < passes; p++) {
		const a1 = m.cells[i1].angle, a0 = m.cells[i0].angle;
		if (Math.abs(a1) <= .5) break;
		const lim0 = Math.max(.5, Math.abs(a0)), o1 = others(m), b1 = bot(m);
		let best = null;
		for (const t of [
			0,
			-.25,
			-.5,
			-.75
		]) {
			const cells = m.cells.map((c, i) => i === i1 ? {
				...c,
				ink: minInk
			} : i === i0 ? {
				...c,
				angle: a0 + t * a1,
				ink: minInk
			} : {
				...c,
				ink: 0
			});
			const next = lineSkewCorrect(cur, W, H, cells, bands, {
				fromBand: 0,
				toBand: h,
				minInk: 50,
				minDeg: .0625
			});
			const m2 = lineSkewMap(gray(next), W, H, bands), o2 = others(m2);
			const n1 = Math.abs(m2.cells[i1].angle), n0 = Math.abs(m2.cells[i0].angle);
			const ok = n1 < Math.abs(a1) && n0 <= lim0 && !o2.some((v, i) => v > o1[i] + .25) && bot(m2) <= b1 && m2.cells[i1].ink >= 50;
			log.push(`p${p} t=${t} side=${side} d1 ${a1}->${m2.cells[i1].angle} d0 ${a0}->${m2.cells[i0].angle} ${ok ? "giữ" : "bỏ"}`);
			if (ok && (!best || n1 < Math.abs(best.a))) best = {
				data: next,
				m: m2,
				a: m2.cells[i1].angle
			};
		}
		if (!best) break;
		cur = best.data;
		m = best.m;
		used++;
	}
	return {
		data: cur === d ? new Uint8ClampedArray(d) : cur,
		passes: used,
		side,
		angle: m.cells[i1].angle,
		log
	};
}
/**
* S15i – Trường cong mượt toàn trang.
* Thay vì nắn từng ô/dải (S11g–S11s, dễ "vá chằng vá đụp"), khớp một mặt
* độ dốc dòng mượt cho cả trang từ số đo lineSkewMap:
*   tan(góc)(u, v) = a + b·u + c·v + d·u·v + e·v²   (u, v ∈ [−½, ½])
* Khớp bình phương tối thiểu có trọng số mực, một lượt loại ô lệch > 0,75°
* so với mặt vừa khớp. Dịch dọc = tích phân giải tích theo x từ tâm trang,
* nên tâm trang đứng yên và không có bậc thang giữa các ô.
* Hàm thuần, chạy được trong Worker/kiểm thử. Chưa nối vào chuỗi lọc.
*/
var DEG = Math.PI / 180;
var basis = (u, v) => [
	1,
	u,
	v,
	u * v,
	v * v
];
function solve$1(A, b) {
	const n = b.length, M = A.map((r, i) => [...r, b[i]]);
	for (let c = 0; c < n; c++) {
		let p = c;
		for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
		if (Math.abs(M[p][c]) < 1e-12) return null;
		[M[c], M[p]] = [M[p], M[c]];
		for (let r = 0; r < n; r++) {
			if (r === c) continue;
			const f = M[r][c] / M[c][c];
			for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
		}
	}
	return M.map((r, i) => r[n] / r[i]);
}
/** Toạ độ chuẩn hoá tâm ô, khớp với bố cục lineSkewMap. */
function cellCenter(c, W, H, bands) {
	const mx = W * .06 | 0, my = H * .04 | 0;
	const bh = (H - 2 * my) / bands | 0;
	const x = mx + ((W - 2 * mx) / 2 | 0) * (c.side + .5), y = my + bh * (c.band + .5);
	return {
		u: x / W - .5,
		v: y / H - .5
	};
}
function fitSkewField(cells, W, H, bands = 6, opts = {}) {
	const minInk = opts.minInk ?? 60, tol = Math.tan((opts.outlierDeg ?? .75) * DEG);
	const pts = cells.filter((c) => c.ink > minInk).map((c) => ({
		...cellCenter(c, W, H, bands),
		s: Math.tan(c.angle * DEG),
		w: Math.sqrt(c.ink)
	}));
	const fit = (P) => {
		const k = P.length >= 8 ? 5 : P.length >= 3 ? 3 : P.length >= 1 ? 1 : 0;
		if (!k) return null;
		const A = Array.from({ length: k }, () => new Array(k).fill(0)), b = new Array(k).fill(0);
		for (const p of P) {
			const f = basis(p.u, p.v).slice(0, k);
			for (let i = 0; i < k; i++) {
				b[i] += p.w * f[i] * p.s;
				for (let j = 0; j < k; j++) A[i][j] += p.w * f[i] * f[j];
			}
		}
		for (let i = 1; i < k; i++) A[i][i] += 1e-6;
		const x = solve$1(A, b);
		if (!x) return null;
		while (x.length < 5) x.push(0);
		return x;
	};
	const at = (c, u, v) => basis(u, v).reduce((s, f, i) => s + f * c[i], 0);
	let coef = fit(pts);
	if (!coef) return null;
	let keep = pts;
	for (let it = 0; it < pts.length && keep.length > 3; it++) {
		let wi = -1, we = tol;
		keep.forEach((p, i) => {
			const c = fit(keep.filter((_, j) => j !== i));
			const e = c ? Math.abs(at(c, p.u, p.v) - p.s) : 0;
			if (e > we) {
				we = e;
				wi = i;
			}
		});
		if (wi < 0) break;
		keep = keep.filter((_, i) => i !== wi);
		coef = fit(keep) ?? coef;
	}
	const dropped = pts.length - keep.length;
	return {
		coef,
		used: keep.length || pts.length,
		dropped
	};
}
/** Nắn theo trường: lấy mẫu dọc song tuyến tại y + ∫ độ dốc dx (từ tâm). */
function skewFieldApply(d, W, H, f) {
	const [a, b, c, dd, e] = f.coef;
	const out = new Uint8ClampedArray(d.length);
	for (let y = 0; y < H; y++) {
		const v = y / H - .5, k0 = a + c * v + e * v * v, k1 = b + dd * v;
		for (let x = 0; x < W; x++) {
			const u = (x - W / 2) / W;
			sampleV(d, out, W, H, x, y, y + W * (k0 * u + k1 * u * u / 2));
		}
	}
	return out;
}
var gray = (p, W, H) => {
	const g = new Uint8Array(W * H);
	for (let i = 0, j = 0; j < g.length; i += 4, j++) g[j] = p[i] * 77 + p[i + 1] * 150 + p[i + 2] * 29 >> 8;
	return g;
};
/** Điểm toàn trang: max |góc| ô đủ mực + cong lớn nhất (trên/dưới). */
function pageSkewScore(m, minInk = 60) {
	let a = 0;
	for (const c of m.cells) if (c.ink > minInk) a = Math.max(a, Math.abs(c.angle));
	return a + Math.max(m.top.curve, m.bottom.curve);
}
/**
* Nắn một lượt bằng trường mượt, có kiểm điểm: chỉ giữ khi điểm toàn trang
* giảm. Trang đã thẳng (mọi |góc| ≤ minDeg) trả bản sao y nguyên.
*/
function smoothSkewCorrect(d, W, H, bands = 6, minDeg = .25) {
	const m = lineSkewMap(gray(d, W, H), W, H, bands), before = pageSkewScore(m);
	const same = {
		data: new Uint8ClampedArray(d),
		applied: false,
		before,
		after: before
	};
	if (m.cells.every((c) => c.ink <= 60 || Math.abs(c.angle) < minDeg)) return same;
	const f = fitSkewField(m.cells, W, H, bands);
	if (!f) return same;
	const next = skewFieldApply(d, W, H, f);
	const after = pageSkewScore(lineSkewMap(gray(next, W, H), W, H, bands));
	return after < before ? {
		data: next,
		applied: true,
		before,
		after
	} : same;
}
/** Bình phương tối thiểu bậc 2, x quanh 0,5 cho ổn định. */
function fitLine(l) {
	const n = l.pts.length;
	if (n < 3) return null;
	let s0 = 0, s1 = 0, s2 = 0, s3 = 0, s4 = 0, t0 = 0, t1 = 0, t2 = 0;
	for (const [px, y] of l.pts) {
		const x = px - .5, x2 = x * x;
		s0++;
		s1 += x;
		s2 += x2;
		s3 += x2 * x;
		s4 += x2 * x2;
		t0 += y;
		t1 += x * y;
		t2 += x2 * y;
	}
	const det = (m) => m[0] * (m[4] * m[8] - m[5] * m[7]) - m[1] * (m[3] * m[8] - m[5] * m[6]) + m[2] * (m[3] * m[7] - m[4] * m[6]);
	const D = det([
		s0,
		s1,
		s2,
		s1,
		s2,
		s3,
		s2,
		s3,
		s4
	]);
	if (Math.abs(D) < 1e-12) return null;
	const a = det([
		t0,
		s1,
		s2,
		t1,
		s2,
		s3,
		t2,
		s3,
		s4
	]) / D;
	const b = det([
		s0,
		t0,
		s2,
		s1,
		t1,
		s3,
		s2,
		t2,
		s4
	]) / D;
	const c = det([
		s0,
		s1,
		t0,
		s1,
		s2,
		t1,
		s2,
		s3,
		t2
	]) / D;
	let e = 0;
	for (const [px, y] of l.pts) {
		const x = px - .5;
		e += (y - (a + b * x + c * x * x)) ** 2;
	}
	return {
		a,
		b,
		c,
		rms: Math.sqrt(e / n)
	};
}
/** Bỏ dòng khớp kém hoặc cong lệch hẳn số đông (hình minh họa, chú thích lẫn vào). */
function buildPageCurve(lines) {
	let fits = lines.map(fitLine).filter((f) => !!f && f.rms < .01);
	if (fits.length < 3) return null;
	const cs = fits.map((f) => f.c).sort((x, y) => x - y);
	const med = cs[cs.length >> 1];
	const dev = cs.map((c) => Math.abs(c - med)).sort((x, y) => x - y)[cs.length >> 1];
	fits = fits.filter((f) => Math.abs(f.c - med) <= Math.max(3 * dev, .02)).sort((p, q) => p.a - q.a);
	if (fits.length < 3) return null;
	const lin = (k) => {
		const n = fits.length;
		let sa = 0, sv = 0, saa = 0, sav = 0;
		for (const f of fits) {
			sa += f.a;
			sv += f[k];
			saa += f.a * f.a;
			sav += f.a * f[k];
		}
		const d = n * saa - sa * sa;
		const m = Math.abs(d) < 1e-12 ? 0 : (n * sav - sa * sv) / d;
		return [m, (sv - m * sa) / n];
	};
	const [mc, kc] = lin("c"), [mb, kb] = lin("b");
	const fitC = fits.map((f) => mc * f.a + kc);
	if (Math.sqrt(fits.reduce((e, f, i) => e + (f.c - fitC[i]) ** 2, 0) / fits.length) > .35 * (fitC.reduce((e, v) => e + Math.abs(v), 0) / fits.length) + .004) return null;
	fits = fits.map((f, i) => ({
		...f,
		c: fitC[i],
		b: mb * f.a + kb
	}));
	return {
		lines: fits,
		bend: Math.max(...fits.map((f) => Math.abs(f.c) / 4))
	};
}
/** Nội suy (b, c) tại hàng chuẩn hóa y của ảnh phẳng. */
function coefAt(pc, y) {
	const L = pc.lines;
	if (y <= L[0].a) return [L[0].b, L[0].c];
	for (let i = 1; i < L.length; i++) if (y <= L[i].a) {
		const t = (y - L[i - 1].a) / (L[i].a - L[i - 1].a || 1);
		return [L[i - 1].b + t * (L[i].b - L[i - 1].b), L[i - 1].c + t * (L[i].c - L[i - 1].c)];
	}
	const z = L[L.length - 1];
	return [z.b, z.c];
}
/** Điểm (x, y) của ảnh phẳng nằm ở đâu trên ảnh cong (dịch dọc, giữ nguyên x). */
function sourceY(pc, x, y) {
	const [b, c] = coefAt(pc, y);
	const u = x - .5;
	return y + b * u + c * u * u;
}
/** Ảnh RGBA → xám thu nhỏ (cạnh dài ≤ max) để dò dòng nhanh; tọa độ chuẩn hóa nên dùng lại được cho ảnh gốc. */
function smallGray(d, W, H, max = 800) {
	const s = Math.min(1, max / Math.max(W, H));
	const w = Math.max(8, Math.round(W * s)), h = Math.max(8, Math.round(H * s));
	const g = new Uint8Array(w * h);
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		const i = (Math.floor(y * H / h) * W + Math.floor(x * W / w)) * 4;
		g[y * w + x] = d[i] * .3 + d[i + 1] * .59 + d[i + 2] * .11;
	}
	return {
		g,
		w,
		h
	};
}
/** G4-06: nắn ảnh màu theo dòng chữ. Trang không đủ dòng hoặc gần phẳng (võng < minBend) → trả nguyên ảnh. */
function textFlattenRGBA(d, W, H, detect, minBend = .004) {
	const { g, w, h } = smallGray(d, W, H);
	const pc = buildPageCurve(detect(g, w, h));
	if (!pc || pc.bend < minBend) return d;
	const out = new Uint8ClampedArray(d.length);
	for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
		const sy = Math.min(H - 1.001, Math.max(0, sourceY(pc, (x + .5) / W, (y + .5) / H) * H - .5));
		const y0 = sy | 0, f = sy - y0, a = (y0 * W + x) * 4, b = a + W * 4, o = (y * W + x) * 4;
		for (let k = 0; k < 3; k++) out[o + k] = d[a + k] + (d[b + k] - d[a + k]) * f;
		out[o + 3] = 255;
	}
	return out;
}
function inkMask(g, W, H) {
	let sum = 0;
	for (let i = 0; i < W * H; i++) sum += g[i];
	const thr = sum / (W * H) * .72;
	const m = new Uint8Array(W * H);
	for (let i = 0; i < W * H; i++) m[i] = g[i] < thr ? 1 : 0;
	return m;
}
function peaks(p, r, min) {
	const out = [];
	for (let y = 0; y < p.length; y++) {
		if (p[y] < min) continue;
		let top = true;
		for (let k = 1; k <= r && top; k++) if (y - k >= 0 && p[y - k] > p[y] || y + k < p.length && p[y + k] >= p[y]) top = false;
		if (top) out.push(y);
	}
	return out;
}
var median$1 = (a) => {
	if (!a.length) return 0;
	const s = [...a].sort((x, y) => x - y);
	return s[s.length >> 1];
};
function detectTextLines(gray, W, H, o = {}) {
	const S = o.strips ?? 24;
	const minCover = o.minCover ?? .4;
	const m = inkMask(gray, W, H);
	const sw = W / S;
	const r = Math.max(1, Math.round(H / 160));
	const strips = [];
	for (let s = 0; s < S; s++) {
		const x0 = Math.floor(s * sw), x1 = Math.floor((s + 1) * sw);
		const raw = new Float32Array(H);
		for (let y = 0; y < H; y++) {
			let c = 0;
			for (let x = x0; x < x1; x++) c += m[y * W + x];
			raw[y] = c;
		}
		const p = new Float32Array(H);
		for (let y = 0; y < H; y++) {
			let c = 0, n = 0;
			for (let k = -r; k <= r; k++) {
				const yy = y + k;
				if (yy >= 0 && yy < H) {
					c += raw[yy];
					n++;
				}
			}
			p[y] = c / n;
		}
		strips.push(peaks(p, r * 2, (x1 - x0) * .08));
	}
	const gaps = [];
	for (const pk of strips) for (let i = 1; i < pk.length; i++) gaps.push(pk[i] - pk[i - 1]);
	const tol = (median$1(gaps) || H / 20) * .45;
	const used = strips.map((pk) => new Array(pk.length).fill(false));
	const lines = [];
	const order = Array.from({ length: S }, (_, i) => i).sort((a, b) => Math.abs(a - S / 2) - Math.abs(b - S / 2));
	for (const s0 of order) strips[s0].forEach((y0, j0) => {
		if (used[s0][j0]) return;
		used[s0][j0] = true;
		const pts = /* @__PURE__ */ new Map([[s0, y0]]);
		for (const dir of [-1, 1]) {
			let y = y0, dy = 0, miss = 0;
			for (let s = s0 + dir; s >= 0 && s < S && miss < 2; s += dir) {
				const want = y + dy;
				let best = -1, bd = tol;
				strips[s].forEach((yy, j) => {
					const d = Math.abs(yy - want);
					if (!used[s][j] && d <= bd) {
						bd = d;
						best = j;
					}
				});
				if (best < 0) {
					miss++;
					continue;
				}
				used[s][best] = true;
				const ny = strips[s][best];
				dy = (ny - y) / (miss + 1) * .5 + dy * .5;
				y = ny;
				miss = 0;
				pts.set(s, ny);
			}
		}
		const cover = pts.size / S;
		if (cover >= minCover) lines.push({
			cover,
			pts: [...pts.entries()].sort((a, b) => a[0] - b[0]).map(([s, yy]) => [(s + .5) * sw / W, yy / H])
		});
	});
	return lines.sort((a, b) => a.pts[0][1] - b.pts[0][1]);
}
/**
* Nắn phẳng giấy cong + làm sạch mép + làm nét chữ. Thuần điểm ảnh (chạy được trong Worker và test).
* - edgeCurves: đo độ cong từng cạnh trên ảnh gốc, khớp o(t) = t(1−t)(c0 + c1(t−½)) (góc giữ cố định).
* - warpCurved: homography + trường dịch chuyển Coons từ 4 cạnh cong, nội suy bicubic (nét hơn song tuyến).
* - trimBox / cleanBorder: cắt dải nền tối còn sót ở mép và xoá nêm nền dính mép.
* - sharpenLuma: unsharp trên độ sáng với nhân Gauss 5×5, không viền màu.
*/
var clampI = (v, lo, hi) => v < lo ? lo : v > hi ? hi : v;
var lumAt = (d, W, H, x, y) => {
	const i = (clampI(Math.round(y), 0, H - 1) * W + clampI(Math.round(x), 0, W - 1)) * 4;
	return d[i] * .3 + d[i + 1] * .59 + d[i + 2] * .11;
};
var curveAt = (c, t) => c ? t * (1 - t) * (c[0] + c[1] * (t - .5)) : 0;
function solveN(A, b) {
	const n = b.length;
	for (let i = 0; i < n; i++) {
		let p = i;
		for (let r = i + 1; r < n; r++) if (Math.abs(A[r][i]) > Math.abs(A[p][i])) p = r;
		[A[i], A[p]] = [A[p], A[i]];
		[b[i], b[p]] = [b[p], b[i]];
		if (Math.abs(A[i][i]) < 1e-12) return null;
		for (let r = i + 1; r < n; r++) {
			const f = A[r][i] / A[i][i];
			for (let c = i; c < n; c++) A[r][c] -= f * A[i][c];
			b[r] -= f * b[i];
		}
	}
	const x = new Array(n).fill(0);
	for (let i = n - 1; i >= 0; i--) {
		let s = b[i];
		for (let c = i + 1; c < n; c++) s -= A[i][c] * x[c];
		x[i] = s / A[i][i];
	}
	return x;
}
/**
* Khớp o(t) = a + b·t + t(1−t)(c0 + c1(t−½)) có loại ngoại lai (MAD). Phần a + b·t là lệch thẳng
* (góc hơi sai) — bỏ đi; chỉ trả phần cong c = [c0, c1].
*/
function fitCurve(ts, os) {
	let idx = ts.map((_, i) => i);
	let c = [0, 0], rms = Infinity;
	const basis = (t) => [
		1,
		t,
		t * (1 - t),
		t * (1 - t) * (t - .5)
	];
	for (let iter = 0; iter < 3; iter++) {
		if (idx.length < 6) return null;
		const A = [
			0,
			1,
			2,
			3
		].map(() => [
			0,
			0,
			0,
			0
		]), bv = [
			0,
			0,
			0,
			0
		];
		for (const i of idx) {
			const f = basis(ts[i]);
			for (let r = 0; r < 4; r++) {
				bv[r] += f[r] * os[i];
				for (let k = 0; k < 4; k++) A[r][k] += f[r] * f[k];
			}
		}
		const x = solveN(A, bv);
		if (!x) return null;
		c = [x[2], x[3]];
		const res = idx.map((i) => {
			const f = basis(ts[i]);
			return Math.abs(os[i] - (x[0] * f[0] + x[1] * f[1] + x[2] * f[2] + x[3] * f[3]));
		});
		rms = Math.sqrt(res.reduce((s, r) => s + r * r, 0) / res.length);
		const sorted = [...res].sort((p, q) => p - q);
		const mad = sorted[Math.floor(sorted.length / 2)] || .5;
		const keep = idx.filter((_, k) => res[k] <= Math.max(1.5, mad * 3));
		if (keep.length === idx.length) break;
		idx = keep;
	}
	return {
		c,
		rms,
		inliers: idx.length
	};
}
/** Đo độ cong 4 cạnh của quad (pixel ảnh gốc). Cạnh thẳng hoặc không đo được → null. */
function edgeCurves(d, W, H, q) {
	const cx = (q[0][0] + q[1][0] + q[2][0] + q[3][0]) / 4, cy = (q[0][1] + q[1][1] + q[2][1] + q[3][1]) / 4;
	return [
		0,
		1,
		2,
		3
	].map((s) => {
		const a = q[s], b = q[(s + 1) % 4];
		const dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy);
		if (len < 60) return null;
		const tx = dx / len, ty = dy / len;
		let nx = -ty, ny = tx;
		if ((cx - (a[0] + b[0]) / 2) * nx + (cy - (a[1] + b[1]) / 2) * ny < 0) {
			nx = -nx;
			ny = -ny;
		}
		const win = Math.max(10, Math.round(len * .07)), gap = Math.max(2, Math.round(len / 600));
		const N = 31, ts = [], os = [], signs = [];
		const strengths = [];
		for (let k = 1; k < N; k++) {
			const t = k / N;
			const px = a[0] + dx * t, py = a[1] + dy * t;
			let best = 0, bestOff = 0, bestSign = 0;
			for (let off = -win; off <= win; off++) {
				let inn = 0, out = 0;
				for (let j = -2; j <= 2; j++) {
					inn += lumAt(d, W, H, px + nx * (off + gap) + tx * j, py + ny * (off + gap) + ty * j);
					out += lumAt(d, W, H, px + nx * (off - gap) + tx * j, py + ny * (off - gap) + ty * j);
				}
				const g = (inn - out) / 5;
				if (Math.abs(g) > best) {
					best = Math.abs(g);
					bestOff = off;
					bestSign = Math.sign(g);
				}
			}
			strengths.push(best);
			if (best >= 14) {
				ts.push(t);
				os.push(bestOff);
				signs.push(bestSign);
			}
		}
		if (ts.length < N * .6) return null;
		const major = signs.reduce((s, v) => s + v, 0) >= 0 ? 1 : -1;
		const fit = fitCurve(ts.filter((_, i) => signs[i] === major), os.filter((_, i) => signs[i] === major));
		if (!fit || fit.inliers < N * .5 || fit.rms > Math.max(2, len * .004)) return null;
		const peak = Math.max(...[
			.25,
			.5,
			.75
		].map((t) => Math.abs(curveAt(fit.c, t))));
		if (peak < Math.max(2, len * .004) || peak > len * .1) return null;
		return fit.c;
	});
}
/** Nội suy bicubic Catmull-Rom một kênh tại (u, v). */
function cubic(p0, p1, p2, p3, t) {
	return p1 + .5 * t * (p2 - p0 + t * (2 * p0 - 5 * p1 + 4 * p2 - p3 + t * (3 * (p1 - p2) + p3 - p0)));
}
/**
* Nắn quad (pixel) ra ow×oh: homography + dịch chuyển cong Coons. curves rỗng = nắn phẳng thường.
* Luôn nội suy bicubic để giữ nét chữ.
*/
/**
* B7: ánh xạ toạ độ điểm ảnh đích (x, y – chỉ số, tâm tại +0,5) → toạ độ ảnh nguồn (chưa kẹp).
* Dùng chung cho CPU (warpCurved) và lưới ánh xạ GPU (warp-mesh.ts) để hai nhánh khớp nhau.
*/
function makeSrcMap(q, ow, oh, curves = []) {
	const h = homography([
		[0, 0],
		[ow, 0],
		[ow, oh],
		[0, oh]
	], q);
	const cx = (q[0][0] + q[1][0] + q[2][0] + q[3][0]) / 4, cy = (q[0][1] + q[1][1] + q[2][1] + q[3][1]) / 4;
	const normals = [
		0,
		1,
		2,
		3
	].map((s) => {
		const a = q[s], b = q[(s + 1) % 4];
		const L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
		let nx = -(b[1] - a[1]) / L, ny = (b[0] - a[0]) / L;
		if ((cx - (a[0] + b[0]) / 2) * nx + (cy - (a[1] + b[1]) / 2) * ny < 0) {
			nx = -nx;
			ny = -ny;
		}
		return [nx, ny];
	});
	const curved = curves.some(Boolean);
	return (x, y) => {
		const dd = h[6] * (x + .5) + h[7] * (y + .5) + 1;
		let sx = (h[0] * (x + .5) + h[1] * (y + .5) + h[2]) / dd - .5;
		let sy = (h[3] * (x + .5) + h[4] * (y + .5) + h[5]) / dd - .5;
		if (curved) {
			const u = (x + .5) / ow, v = (y + .5) / oh;
			const wT = (1 - v) * curveAt(curves[0], u), wR = u * curveAt(curves[1], v);
			const wB = v * curveAt(curves[2], 1 - u), wL = (1 - u) * curveAt(curves[3], 1 - v);
			sx += normals[0][0] * wT + normals[1][0] * wR + normals[2][0] * wB + normals[3][0] * wL;
			sy += normals[0][1] * wT + normals[1][1] * wR + normals[2][1] * wB + normals[3][1] * wL;
		}
		return [sx, sy];
	};
}
/**
* Nắn quad (pixel) ra ow×oh: homography + dịch chuyển cong Coons. curves rỗng = nắn phẳng thường.
* Luôn nội suy bicubic để giữ nét chữ. (Nhánh CPU dự phòng của B7.)
*/
function warpCurved(sd, W, H, q, ow, oh, curves = []) {
	const od = new Uint8ClampedArray(ow * oh * 4);
	const map = makeSrcMap(q, ow, oh, curves);
	const row = W * 4;
	for (let y = 0; y < oh; y++) for (let x = 0; x < ow; x++) {
		let [sx, sy] = map(x, y);
		sx = clampI(sx, 0, W - 1.001);
		sy = clampI(sy, 0, H - 1.001);
		const x0 = sx | 0, y0 = sy | 0, fx = sx - x0, fy = sy - y0, oi = (y * ow + x) * 4;
		const xs = [
			clampI(x0 - 1, 0, W - 1),
			x0,
			clampI(x0 + 1, 0, W - 1),
			clampI(x0 + 2, 0, W - 1)
		];
		const ys = [
			clampI(y0 - 1, 0, H - 1),
			y0,
			clampI(y0 + 1, 0, H - 1),
			clampI(y0 + 2, 0, H - 1)
		];
		for (let k = 0; k < 3; k++) {
			const r0 = ys[0] * row + k, r1 = ys[1] * row + k, r2 = ys[2] * row + k, r3 = ys[3] * row + k;
			const c0 = cubic(sd[r0 + xs[0] * 4], sd[r0 + xs[1] * 4], sd[r0 + xs[2] * 4], sd[r0 + xs[3] * 4], fx);
			const c1 = cubic(sd[r1 + xs[0] * 4], sd[r1 + xs[1] * 4], sd[r1 + xs[2] * 4], sd[r1 + xs[3] * 4], fx);
			const c2 = cubic(sd[r2 + xs[0] * 4], sd[r2 + xs[1] * 4], sd[r2 + xs[2] * 4], sd[r2 + xs[3] * 4], fx);
			const c3 = cubic(sd[r3 + xs[0] * 4], sd[r3 + xs[1] * 4], sd[r3 + xs[2] * 4], sd[r3 + xs[3] * 4], fx);
			od[oi + k] = cubic(c0, c1, c2, c3, fy);
		}
		od[oi + 3] = 255;
	}
	return od;
}
/** Mức sáng giấy: phân vị 80 vùng giữa ảnh. */
function paperLevel(d, W, H) {
	const hist = /* @__PURE__ */ new Uint32Array(256);
	let n = 0;
	for (let y = Math.floor(H * .2); y < H * .8; y += 3) for (let x = Math.floor(W * .2); x < W * .8; x += 3) {
		const i = (y * W + x) * 4;
		hist[d[i] * .3 + d[i + 1] * .59 + d[i + 2] * .11 | 0]++;
		n++;
	}
	let acc = 0;
	for (let v = 0; v < 256; v++) {
		acc += hist[v];
		if (acc >= n * .8) return v;
	}
	return 255;
}
/** Hộp cắt bỏ các dải nền (tối hơn giấy) dính sát mép sau khi nắn; tối đa 5 % mỗi cạnh. */
function trimBox(d, W, H) {
	const P = paperLevel(d, W, H);
	const dark = P * .62;
	const isBg = (count, darkCount, sum) => darkCount > count * .35 || sum / count < P * .7;
	const lineRow = (y) => {
		let dc = 0, s = 0, c = 0;
		for (let x = Math.floor(W * .05); x < W * .95; x += 2) {
			const l = lumAt(d, W, H, x, y);
			s += l;
			c++;
			if (l < dark) dc++;
		}
		return isBg(c, dc, s);
	};
	const lineCol = (x) => {
		let dc = 0, s = 0, c = 0;
		for (let y = Math.floor(H * .05); y < H * .95; y += 2) {
			const l = lumAt(d, W, H, x, y);
			s += l;
			c++;
			if (l < dark) dc++;
		}
		return isBg(c, dc, s);
	};
	if (P < 90) return {
		x0: 0,
		y0: 0,
		x1: W,
		y1: H
	};
	const lim = (n) => Math.max(2, Math.round(n * .05));
	let y0 = 0;
	while (y0 < lim(H) && lineRow(y0)) y0++;
	let y1 = H;
	while (H - y1 < lim(H) && lineRow(y1 - 1)) y1--;
	let x0 = 0;
	while (x0 < lim(W) && lineCol(x0)) x0++;
	let x1 = W;
	while (W - x1 < lim(W) && lineCol(x1 - 1)) x1--;
	const meanRow = (y) => {
		let s2 = 0, c = 0;
		for (let x = Math.floor(W * .05); x < W * .95; x += 2) {
			s2 += lumAt(d, W, H, x, y);
			c++;
		}
		return s2 / c;
	};
	const meanCol = (x) => {
		let s2 = 0, c = 0;
		for (let y = Math.floor(H * .05); y < H * .95; y += 2) {
			s2 += lumAt(d, W, H, x, y);
			c++;
		}
		return s2 / c;
	};
	const thin = (n) => Math.max(1, Math.round(n * .008)), soft = P * .9;
	while (y0 < lim(H) && meanRow(y0) < soft && y0 < thin(H) + 8) y0++;
	while (H - y1 < lim(H) && meanRow(y1 - 1) < soft && H - y1 < thin(H) + 8) y1--;
	while (x0 < lim(W) && meanCol(x0) < soft && x0 < thin(W) + 8) x0++;
	while (W - x1 < lim(W) && meanCol(x1 - 1) < soft && W - x1 < thin(W) + 8) x1--;
	if (y0) y0 = Math.min(y0 + 1, lim(H));
	if (y1 < H) y1 = Math.max(y1 - 1, H - lim(H));
	if (x0) x0 = Math.min(x0 + 1, lim(W));
	if (x1 < W) x1 = Math.max(x1 - 1, W - lim(W));
	return {
		x0,
		y0,
		x1,
		y1
	};
}
/** Xoá nêm nền tối dính mép (góc lệch vài px) trong dải 3 % quanh viền: tô bằng màu giấy. */
function cleanBorder(d, W, H) {
	const P = paperLevel(d, W, H);
	if (P < 90) return d;
	const dark = P * .6, bw = Math.max(3, Math.round(Math.min(W, H) * .03));
	const inBand = (x, y) => x < bw || y < bw || x >= W - bw || y >= H - bw;
	const seen = new Uint8Array(W * H);
	const stack = [];
	const lum = (i) => d[i * 4] * .3 + d[i * 4 + 1] * .59 + d[i * 4 + 2] * .11;
	const push = (x, y) => {
		const i = y * W + x;
		if (!seen[i] && lum(i) < dark) {
			seen[i] = 1;
			stack.push(i);
		}
	};
	for (let x = 0; x < W; x++) {
		push(x, 0);
		push(x, H - 1);
	}
	for (let y = 0; y < H; y++) {
		push(0, y);
		push(W - 1, y);
	}
	let r = 0, g = 0, b = 0, n = 0;
	for (let y = bw; y < bw * 2 && y < H; y++) for (let x = bw; x < W - bw; x += 4) {
		const i = (y * W + x) * 4;
		if (lum(y * W + x) >= P * .85) {
			r += d[i];
			g += d[i + 1];
			b += d[i + 2];
			n++;
		}
	}
	const fill = n ? [
		r / n,
		g / n,
		b / n
	] : [
		P,
		P,
		P
	];
	while (stack.length) {
		const i = stack.pop();
		const x = i % W, y = i / W | 0;
		d[i * 4] = fill[0];
		d[i * 4 + 1] = fill[1];
		d[i * 4 + 2] = fill[2];
		if (x + 1 < W && inBand(x + 1, y)) push(x + 1, y);
		if (x > 0 && inBand(x - 1, y)) push(x - 1, y);
		if (y + 1 < H && inBand(x, y + 1)) push(x, y + 1);
		if (y > 0 && inBand(x, y - 1)) push(x, y - 1);
	}
	return d;
}
var ci = (v, a, b) => v < a ? a : v > b ? b : v;
function adaptiveGain(diff, amount, knee = 40) {
	return amount / (1 + Math.abs(diff) / knee);
}
function sharpenAdaptive(d, W, H, amount, threshold = 4) {
	const n = W * H, L = new Float32Array(n), t = new Float32Array(n), B = new Float32Array(n);
	for (let i = 0; i < n; i++) L[i] = d[i * 4] * .3 + d[i * 4 + 1] * .59 + d[i * 4 + 2] * .11;
	for (let y = 0; y < H; y++) {
		const r = y * W;
		for (let x = 0; x < W; x++) {
			const a = r + (x < 2 ? ci(x - 2, 0, W - 1) : x - 2), b = r + (x < 1 ? 0 : x - 1), c = r + (x > W - 2 ? W - 1 : x + 1), e = r + (x > W - 3 ? ci(x + 2, 0, W - 1) : x + 2);
			t[r + x] = (0 + L[a] + 4 * L[b] + 6 * L[r + x] + 4 * L[c] + L[e]) / 16;
		}
	}
	for (let y = 0; y < H; y++) {
		const a = ci(y - 2, 0, H - 1) * W, b = ci(y - 1, 0, H - 1) * W, m = y * W, c = ci(y + 1, 0, H - 1) * W, e = ci(y + 2, 0, H - 1) * W;
		for (let x = 0; x < W; x++) B[m + x] = (0 + t[a + x] + 4 * t[b + x] + 6 * t[m + x] + 4 * t[c + x] + t[e + x]) / 16;
	}
	for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
		const i = y * W + x, diff = L[i] - B[i];
		if (Math.abs(diff) <= threshold) continue;
		let lo = 255, hi = 0;
		const ra = (y > 0 ? y - 1 : 0) * W, rc = (y < H - 1 ? y + 1 : H - 1) * W, xa = x > 0 ? x - 1 : 0, xc = x < W - 1 ? x + 1 : W - 1;
		for (const r of [
			ra,
			y * W,
			rc
		]) for (const xx of [
			xa,
			x,
			xc
		]) {
			const v = L[r + xx];
			if (v < lo) lo = v;
			if (v > hi) hi = v;
		}
		const add = ci(L[i] + adaptiveGain(diff, amount) * diff, lo, hi) - L[i];
		d[i * 4] = d[i * 4] + add;
		d[i * 4 + 1] = d[i * 4 + 1] + add;
		d[i * 4 + 2] = d[i * 4 + 2] + add;
	}
	return d;
}
var lumOf = (d, i) => d[i * 4] * .3 + d[i * 4 + 1] * .59 + d[i * 4 + 2] * .11;
/** CS-17e: gọi f(o, a, b) cho từng đoạn hàng [o+a, o+b) của dải mép rộng B (cả ảnh khi 2B ≥ W hoặc H). */
function forBand(W, H, B, f) {
	const full = !(B * 2 < W && B * 2 < H);
	for (let y = 0; y < H; y++) {
		const o = y * W;
		if (full || y < B || y >= H - B) f(o, 0, W);
		else {
			f(o, 0, B);
			f(o, W - B, W);
		}
	}
}
/** CS-17e: độ sáng Float32 (như mảng L cũ) chỉ trong dải mép B; ngoài dải để 0 — nơi gọi không đọc ngoài dải. */
function lumBand(d, W, H, B) {
	const L = new Float32Array(W * H);
	forBand(W, H, B, (o, a, b) => {
		for (let i = o + a; i < o + b; i++) L[i] = lumOf(d, i);
	});
	return L;
}
/** Màu giấy (RGB + độ sáng) từ vành trong, bỏ điểm tối (chữ, bóng). */
function paperColor(d, W, H) {
	const hist = /* @__PURE__ */ new Uint32Array(256);
	const pts = [];
	const x0 = Math.floor(W * .04), x1 = Math.ceil(W * .12), y0 = Math.floor(H * .04), y1 = Math.ceil(H * .12);
	const step = Math.max(1, Math.round(Math.min(W, H) / 400));
	const take = (x, y) => {
		const i = y * W + x;
		hist[Math.round(lumOf(d, i))]++;
		pts.push(i);
	};
	for (let y = y0; y < y1; y += step) for (let x = x0; x < W - x0; x += step) {
		take(x, y);
		take(x, H - 1 - y);
	}
	for (let x = x0; x < x1; x += step) for (let y = y1; y < H - y1; y += step) {
		take(x, y);
		take(W - 1 - x, y);
	}
	const n = pts.length;
	if (!n) return {
		r: 255,
		g: 255,
		b: 255,
		L: 255
	};
	let acc = 0, P = 255;
	for (let v = 0; v < 256; v++) {
		acc += hist[v];
		if (acc >= n * .75) {
			P = v;
			break;
		}
	}
	let r = 0, g = 0, b = 0, c = 0;
	for (const i of pts) {
		const l = lumOf(d, i);
		if (l >= P - 12 && l <= P + 20) {
			r += d[i * 4];
			g += d[i * 4 + 1];
			b += d[i * 4 + 2];
			c++;
		}
	}
	return c ? {
		r: r / c,
		g: g / c,
		b: b / c,
		L: P
	} : {
		r: P,
		g: P,
		b: P,
		L: P
	};
}
/** Ngưỡng "tối hơn giấy rõ rệt": chịu được giấy tương phản thấp (nền 160 / giấy 215). */
var darkThreshold = (P) => Math.min(P * .85, P - 22);
/** Mặt nạ vùng ngoài giấy (1 = nền) — chỉ trong dải mép, nối với viền ảnh. */
function paperMask(d, W, H, band = .06) {
	const { L: P } = paperColor(d, W, H);
	const mask = new Uint8Array(W * H);
	if (P < 90) return {
		mask,
		count: 0,
		P,
		bw: 0
	};
	const dark = darkThreshold(P), bw = Math.max(4, Math.round(Math.min(W, H) * band));
	const inBand = (x, y) => x < bw || y < bw || x >= W - bw || y >= H - bw;
	const stack = [];
	let count = 0;
	const push = (x, y) => {
		const i = y * W + x;
		if (!mask[i] && lumOf(d, i) < dark) {
			mask[i] = 1;
			count++;
			stack.push(i);
		}
	};
	for (let x = 0; x < W; x++) {
		push(x, 0);
		push(x, H - 1);
	}
	for (let y = 0; y < H; y++) {
		push(0, y);
		push(W - 1, y);
	}
	while (stack.length) {
		const i = stack.pop();
		const x = i % W, y = i / W | 0;
		if (x + 1 < W && inBand(x + 1, y)) push(x + 1, y);
		if (x > 0 && inBand(x - 1, y)) push(x - 1, y);
		if (y + 1 < H && inBand(x, y + 1)) push(x, y + 1);
		if (y > 0 && inBand(x, y - 1)) push(x, y - 1);
	}
	return {
		mask,
		count,
		P,
		bw
	};
}
/** Nở mặt nạ r px (hình vuông, tách 2 lượt). V5b: chỉ quét dải viền B px khi biết mặt nạ = 0 ngoài dải bw (B ≥ bw + r). */
function dilate(m, W, H, r, B = Infinity) {
	const t = new Uint8Array(W * H), o = new Uint8Array(W * H);
	const row = (y, a, b) => {
		let last = -1e9;
		for (let x = a; x < b; x++) {
			if (m[y * W + x]) last = x;
			if (x - last <= r) t[y * W + x] = 1;
		}
		last = 1e9;
		for (let x = b - 1; x >= a; x--) {
			if (m[y * W + x]) last = x;
			if (last - x <= r) t[y * W + x] = 1;
		}
	};
	const full = !(B * 2 < W && B * 2 < H);
	for (let y = 0; y < H; y++) if (full || y < B || y >= H - B) row(y, 0, W);
	else {
		row(y, 0, B);
		row(y, W - B, W);
	}
	if (full) {
		const last = new Float64Array(W);
		last.fill(-1e9);
		for (let y = 0; y < H; y++) {
			const o0 = y * W;
			for (let x = 0; x < W; x++) {
				if (t[o0 + x]) last[x] = y;
				if (y - last[x] <= r) o[o0 + x] = 1;
			}
		}
		last.fill(1e9);
		for (let y = H - 1; y >= 0; y--) {
			const o0 = y * W;
			for (let x = 0; x < W; x++) {
				if (t[o0 + x]) last[x] = y;
				if (last[x] - y <= r) o[o0 + x] = 1;
			}
		}
		return o;
	}
	const last = new Float64Array(W);
	last.fill(-1e9);
	for (let y = 0; y < H; y++) {
		if (y === H - B) last.fill(-1e9, B, W - B);
		const o0 = y * W, mid = y >= B && y < H - B;
		for (let x = 0; x < W; x++) {
			if (mid && x === B) x = W - B;
			if (t[o0 + x]) last[x] = y;
			if (y - last[x] <= r) o[o0 + x] = 1;
		}
	}
	last.fill(1e9);
	for (let y = H - 1; y >= 0; y--) {
		if (y === B - 1) last.fill(1e9, B, W - B);
		const o0 = y * W, mid = y >= B && y < H - B;
		for (let x = 0; x < W; x++) {
			if (mid && x === B) x = W - B;
			if (t[o0 + x]) last[x] = y;
			if (last[x] - y <= r) o[o0 + x] = 1;
		}
	}
	return o;
}
/** Tô vùng ngoài giấy bằng màu giấy ước lượng; viền nở thêm `grow` px pha mềm để không lộ mép. */
function paperMaskFill(d, W, H, grow = 3) {
	const { mask, count, bw } = paperMask(d, W, H);
	if (!count) return d;
	const col = paperColor(d, W, H);
	const g1 = Math.max(1, grow - 1), B = bw + g1 + 2;
	const core = dilate(mask, W, H, g1, B), soft = dilate(core, W, H, 1, B);
	const px = (i) => {
		if (!soft[i]) return;
		const a = core[i] ? 1 : .5, j = i * 4;
		if (lumOf(d, i) >= col.L && !core[i]) return;
		d[j] = d[j] * (1 - a) + col.r * a;
		d[j + 1] = d[j + 1] * (1 - a) + col.g * a;
		d[j + 2] = d[j + 2] * (1 - a) + col.b * a;
	};
	const full = !(B * 2 < W && B * 2 < H);
	for (let y = 0; y < H; y++) {
		const o = y * W;
		if (full || y < B || y >= H - B) for (let x = 0; x < W; x++) px(o + x);
		else {
			for (let x = 0; x < B; x++) px(o + x);
			for (let x = W - B; x < W; x++) px(o + x);
		}
	}
	return d;
}
/**
* S10 – Q1: bóng xám mềm dính mép/góc (tối hơn giấy nhẹ, không đủ "tối rõ rệt" cho paperMask).
* Loang từ viền ảnh qua điểm "phẳng" (không có nét chữ) tối hơn giấy ≥ 8, trong dải `band` (15 %).
* Chữ có độ tương phản cục bộ cao nên chặn loang → không xoá chữ. Tô dần về màu giấy theo độ tối.
*/
function edgeShadowLift(d, W, H, band = .15) {
	const col = paperColor(d, W, H);
	const P = col.L;
	if (P < 90) return d;
	const mild = P - 8, bw = Math.max(4, Math.round(Math.min(W, H) * band)), s = 2;
	const B = bw + s + 4, L = lumBand(d, W, H, B);
	const inBand = (x, y) => x < bw || y < bw || x >= W - bw || y >= H - bw;
	const smooth = (x, y) => {
		const v = L[y * W + x];
		return (x < s || Math.abs(L[y * W + x - s] - v) < 14) && (x >= W - s || Math.abs(L[y * W + x + s] - v) < 14) && (y < s || Math.abs(L[(y - s) * W + x] - v) < 14) && (y >= H - s || Math.abs(L[(y + s) * W + x] - v) < 14);
	};
	const m = new Uint8Array(W * H);
	const st = [];
	const push = (x, y) => {
		const i = y * W + x;
		if (!m[i] && L[i] < mild && smooth(x, y)) {
			m[i] = 1;
			st.push(i);
		}
	};
	for (let x = 0; x < W; x++) {
		push(x, 0);
		push(x, H - 1);
	}
	for (let y = 0; y < H; y++) {
		push(0, y);
		push(W - 1, y);
	}
	while (st.length) {
		const i = st.pop();
		const x = i % W, y = i / W | 0;
		if (x + 1 < W && inBand(x + 1, y)) push(x + 1, y);
		if (x > 0 && inBand(x - 1, y)) push(x - 1, y);
		if (y + 1 < H && inBand(x, y + 1)) push(x, y + 1);
		if (y > 0 && inBand(x, y - 1)) push(x, y - 1);
	}
	const g = dilate(m, W, H, 2, B);
	forBand(W, H, B, (o, a, b) => {
		for (let i = o + a; i < o + b; i++) {
			if (!g[i]) continue;
			const j = i * 4;
			if (!m[i] && L[i] < P * .6) continue;
			d[j] = col.r;
			d[j + 1] = col.g;
			d[j + 2] = col.b;
		}
	});
	return d;
}
/**
* S10 – Q2: rác điểm ảnh ở mép (chấm đen, vệt nhỏ) – thành phần tối nhỏ nằm trọn trong dải mép `band` (2 %).
* Chữ thật hiếm khi nằm trọn trong 2 % sát mép; thành phần lớn hơn `maxFrac` cạnh ngắn được giữ.
*/
function edgeSpeckClean(d, W, H, band = .02, maxFrac = .03) {
	const col = paperColor(d, W, H);
	const dark = darkThreshold(col.L);
	const bw = Math.max(3, Math.round(Math.min(W, H) * band)), maxPx = Math.max(4, Math.round(Math.min(W, H) * maxFrac));
	const inBand = (x, y) => x < bw || y < bw || x >= W - bw || y >= H - bw;
	const seen = new Uint8Array(W * H);
	const scan = (sx, sy) => {
		const s = sy * W + sx;
		if (seen[s] || lumOf(d, s) >= dark) return;
		const comp = [s];
		const st = [s];
		seen[s] = 1;
		let inside = true, x0 = sx, x1 = sx, y0 = sy, y1 = sy;
		while (st.length) {
			const i = st.pop();
			const x = i % W, y = i / W | 0;
			if (!inBand(x, y)) inside = false;
			if (x < x0) x0 = x;
			if (x > x1) x1 = x;
			if (y < y0) y0 = y;
			if (y > y1) y1 = y;
			if (x + 1 < W) {
				const k = i + 1;
				if (!seen[k] && lumOf(d, k) < dark) {
					seen[k] = 1;
					st.push(k);
					comp.push(k);
				}
			}
			if (x > 0) {
				const k = i - 1;
				if (!seen[k] && lumOf(d, k) < dark) {
					seen[k] = 1;
					st.push(k);
					comp.push(k);
				}
			}
			if (y + 1 < H) {
				const k = i + W;
				if (!seen[k] && lumOf(d, k) < dark) {
					seen[k] = 1;
					st.push(k);
					comp.push(k);
				}
			}
			if (y > 0) {
				const k = i - W;
				if (!seen[k] && lumOf(d, k) < dark) {
					seen[k] = 1;
					st.push(k);
					comp.push(k);
				}
			}
		}
		if (inside && Math.max(x1 - x0, y1 - y0) + 1 <= maxPx) for (const i of comp) {
			d[i * 4] = col.r;
			d[i * 4 + 1] = col.g;
			d[i * 4 + 2] = col.b;
		}
	};
	for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (inBand(x, y)) scan(x, y);
	return d;
}
/**
* S10f – Q2 sót: vệt mảnh dài song song mép (mép tờ giấy bên dưới) nằm trong dải `band` (8 %).
* Thành phần tối có bề ngang ≤ 1,2 % cạnh ngắn, dài ≥ 6 % cạnh ngắn và ≥ 8× bề ngang → tô màu giấy.
* Nét chữ ngắn (l, I) không đủ dài nên giữ nguyên.
*/
function edgeLineClean(d, W, H, band = .08) {
	const col = paperColor(d, W, H);
	const dark = darkThreshold(col.L) + 25;
	const S = Math.min(W, H);
	const bw = Math.round(S * band), maxW = Math.max(3, Math.round(S * .012)), minL = Math.round(S * .06);
	const seen = new Uint8Array(W * H);
	const isDark = (k) => {
		if (lumOf(d, k) < dark) return true;
		seen[k] = 2;
		return false;
	};
	const comp = /* @__PURE__ */ new Int32Array(200004), st = /* @__PURE__ */ new Int32Array(200004);
	for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
		if (!(x < bw || y < bw || x >= W - bw || y >= H - bw)) {
			x = W - bw - 1;
			continue;
		}
		const s = y * W + x;
		if (seen[s] || !isDark(s)) continue;
		let n = 1, sp = 1;
		comp[0] = s;
		st[0] = s;
		seen[s] = 1;
		let x0 = x, x1 = x, y0 = y, y1 = y;
		while (sp && n < 2e5) {
			const i = st[--sp];
			const py = i / W | 0, px = i - py * W;
			if (px < x0) x0 = px;
			if (px > x1) x1 = px;
			if (py < y0) y0 = py;
			if (py > y1) y1 = py;
			if (px + 1 < W && !seen[i + 1] && isDark(i + 1)) {
				seen[i + 1] = 1;
				st[sp++] = i + 1;
				comp[n++] = i + 1;
			}
			if (px > 0 && !seen[i - 1] && isDark(i - 1)) {
				seen[i - 1] = 1;
				st[sp++] = i - 1;
				comp[n++] = i - 1;
			}
			if (py + 1 < H && !seen[i + W] && isDark(i + W)) {
				seen[i + W] = 1;
				st[sp++] = i + W;
				comp[n++] = i + W;
			}
			if (py > 0 && !seen[i - W] && isDark(i - W)) {
				seen[i - W] = 1;
				st[sp++] = i - W;
				comp[n++] = i - W;
			}
		}
		const bwX = x1 - x0 + 1, bhY = y1 - y0 + 1;
		const vert = bwX <= maxW * 2 && bhY >= minL && bhY >= 8 * bwX && (x1 < bw || x0 >= W - bw);
		const horz = bhY <= maxW * 2 && bwX >= minL && bwX >= 8 * bhY && (y1 < bw || y0 >= H - bw);
		const thin = vert ? n / bhY <= maxW : horz ? n / bwX <= maxW : false;
		if ((vert || horz) && thin) for (let q = 0; q < n; q++) {
			const i = comp[q];
			d[i * 4] = col.r;
			d[i * 4 + 1] = col.g;
			d[i * 4 + 2] = col.b;
		}
	}
	return d;
}
/**
* S10b – Q1 (bản dùng): bóng xám mềm trong dải mép, không cần chạm viền ảnh.
* Điểm "phẳng" (lệch < 14 so với láng giềng cách 2 px) có độ sáng trong (0,55·P; P−6) → tô màu giấy.
* Nét chữ có cạnh gắt nên không phẳng; lõi nét đậm < 0,55·P nên được giữ.
*/
function edgeShadowSmooth(d, W, H, band = .25) {
	const col = paperColor(d, W, H);
	const P = col.L;
	if (P < 90) return d;
	const lo = P * .55, hi = P - 6, bw = Math.min(W, H) * band, s = 2;
	const B = Math.floor(bw) + 1 + s + 4, L = lumBand(d, W, H, B);
	const m = new Uint8Array(W * H);
	forBand(W, H, B, (o, a, b) => {
		const y = o / W;
		if (y < s || y >= H - s) return;
		for (let x = a < s ? s : a, xe = b > W - s ? W - s : b; x < xe; x++) {
			if (Math.min(x, y, W - 1 - x, H - 1 - y) > bw) continue;
			const i = o + x, v = L[i];
			if (v <= lo || v >= hi) continue;
			if (Math.abs(L[i - s] - v) < 14 && Math.abs(L[i + s] - v) < 14 && Math.abs(L[i - s * W] - v) < 14 && Math.abs(L[i + s * W] - v) < 14) m[i] = 1;
		}
	});
	const g = dilate(m, W, H, 2, B);
	forBand(W, H, B, (o, a, b) => {
		for (let i = o + a; i < o + b; i++) {
			if (!g[i] || L[i] < lo) continue;
			const j = i * 4;
			d[j] = col.r;
			d[j + 1] = col.g;
			d[j + 2] = col.b;
		}
	});
	return d;
}
/**
* S10g/S10h – vệt đứt nét sát mép (mép tờ bên dưới): nhiều mảnh mảnh, dài theo một hướng, nối thành đường gần thẳng
* (cho phép xiên ≤ 0,2 px/px) trong dải mép `band` (12 %). Điểm "tối" theo tương phản cục bộ: tối hơn nền ô ≥ 14
* (bắt cả vệt xám nhạt). Mảnh phải cô lập (không có điểm tối bên cạnh như chữ cùng dòng). Tổng dài ≥ 6 % cạnh ngắn → xoá.
*/
/**
* V5d: điểm tối theo tương phản cục bộ (nền = độ sáng lớn nhất trong ô S/40, kẹp ≤ màu giấy; tối hơn nền ≥ 14).
* Dùng chung cho edgeDashClean/edgeStrokeClean; chỉ số ô tính theo hàng + bảng cột, không chia cho từng điểm.
*/
/**
* CS-17e: tính lười — chỉ ô nền / điểm được hỏi tới (dải mép + nơi loang tới), kết quả y hệt bản tính cả ảnh cũ
* (L Float32 = Math.fround(lumOf), nền ô = max L khởi 0). Điều kiện: d không đổi giữa lần hỏi đầu và lần cuối.
*/
function lazyLocalDark(d, W, H, S, paperL, band) {
	const cell = Math.max(8, Math.round(S / 40)), cw = Math.ceil(W / cell), bg = new Float32Array(cw * Math.ceil(H / cell)).fill(-1);
	const dk = new Uint8Array(W * H);
	{
		const xa = Math.ceil(band / cell) * cell, xb = Math.floor((W - band) / cell) * cell, ya = Math.ceil(band / cell) * cell, yb = Math.floor((H - band) / cell) * cell;
		const full = xa >= xb || ya >= yb, cx = new Int32Array(W);
		for (let x = 0; x < W; x++) cx[x] = x / cell | 0;
		const seg = (f) => {
			for (let y = 0; y < H; y++) {
				const o = y * W, r = (y / cell | 0) * cw;
				if (full || y < ya || y >= yb) f(o, r, 0, W);
				else {
					f(o, r, 0, xa);
					f(o, r, xb, W);
				}
			}
		};
		seg((o, r, a, b) => {
			for (let x = a; x < b; x++) {
				const k = r + cx[x], v = Math.fround(lumOf(d, o + x));
				if (bg[k] < 0 || v > bg[k]) bg[k] = bg[k] < 0 ? v > 0 ? v : 0 : v;
			}
		});
		seg((o, r, a, b) => {
			for (let x = a; x < b; x++) dk[o + x] = Math.min(paperL, bg[r + cx[x]]) - Math.fround(lumOf(d, o + x)) >= 14 ? 1 : 2;
		});
	}
	const cellBg = (k) => {
		const cy = k / cw | 0, x0 = (k - cy * cw) * cell, y0 = cy * cell, x1 = Math.min(W, x0 + cell), y1 = Math.min(H, y0 + cell);
		let v = 0;
		for (let y = y0; y < y1; y++) for (let i = y * W + x0, e = y * W + x1; i < e; i++) {
			const l = Math.fround(lumOf(d, i));
			if (l > v) v = l;
		}
		return bg[k] = v;
	};
	const get = (i) => {
		let v = dk[i];
		if (!v) {
			const y = i / W | 0, k = (y / cell | 0) * cw + ((i - y * W) / cell | 0);
			let b = bg[k];
			if (b < 0) b = cellBg(k);
			v = dk[i] = Math.min(paperL, b) - Math.fround(lumOf(d, i)) >= 14 ? 1 : 2;
		}
		return v === 1;
	};
	return {
		get,
		raw: dk
	};
}
function edgeDashClean(d, W, H, band = .12) {
	const col = paperColor(d, W, H);
	const S = Math.min(W, H);
	if (col.L < 90) return d;
	const bw = Math.round(S * band), maxW = Math.max(3, Math.round(S * .008)), minL = Math.round(S * .06), maxGap = Math.round(S * .05);
	const { get: dk, raw } = lazyLocalDark(d, W, H, S, col.L, bw + maxW * 3 + 2);
	const seen = new Uint8Array(W * H), cB = /* @__PURE__ */ new Int32Array(5004), sB = /* @__PURE__ */ new Int32Array(5004);
	const cs = [];
	const darkIn = (xa, xb, ya, yb) => {
		let n = 0;
		for (let y = Math.max(0, ya); y <= Math.min(H - 1, yb); y++) for (let x = Math.max(0, xa), xe = Math.min(W - 1, xb), o = y * W; x <= xe; x++) {
			const v = raw[o + x];
			n += v === 1 ? 1 : v === 0 && dk(o + x) ? 1 : 0;
		}
		return n;
	};
	forBand(W, H, bw, (o, a, b) => {
		for (let s = o + a; s < o + b; s++) {
			if (seen[s] || !dk(s)) continue;
			const x = s - o, y = o / W;
			let n = 1, sp = 1;
			cB[0] = s;
			sB[0] = s;
			seen[s] = 1;
			let x0 = x, x1 = x, y0 = y, y1 = y;
			while (sp && n < 5e3) {
				const i = sB[--sp];
				const px = i % W, py = i / W | 0;
				if (px < x0) x0 = px;
				if (px > x1) x1 = px;
				if (py < y0) y0 = py;
				if (py > y1) y1 = py;
				if (px + 1 < W) {
					const k = i + 1;
					if (!seen[k] && dk(k)) {
						seen[k] = 1;
						sB[sp++] = k;
						cB[n++] = k;
					}
				}
				if (px > 0) {
					const k = i - 1;
					if (!seen[k] && dk(k)) {
						seen[k] = 1;
						sB[sp++] = k;
						cB[n++] = k;
					}
				}
				if (py + 1 < H) {
					const k = i + W;
					if (!seen[k] && dk(k)) {
						seen[k] = 1;
						sB[sp++] = k;
						cB[n++] = k;
					}
				}
				if (py > 0) {
					const k = i - W;
					if (!seen[k] && dk(k)) {
						seen[k] = 1;
						sB[sp++] = k;
						cB[n++] = k;
					}
				}
			}
			const w = x1 - x0 + 1, h = y1 - y0 + 1, r = maxW * 3;
			if (h >= 4 * w && h >= 6 && n / h <= maxW && (x1 < bw || x0 >= W - bw)) {
				if (darkIn(x0 - r, x0 - 2, y0, y1) + darkIn(x1 + 2, x1 + r, y0, y1) <= h * .3) cs.push({
					px: cB.slice(0, n),
					c: (x0 + x1) / 2,
					a0: y0,
					a1: y1,
					v: true
				});
			} else if (w >= 4 * h && w >= 6 && n / w <= maxW && (y1 < bw || y0 >= H - bw)) {
				if (darkIn(x0, x1, y0 - r, y0 - 2) + darkIn(x0, x1, y1 + 2, y1 + r) <= w * .3) cs.push({
					px: cB.slice(0, n),
					c: (y0 + y1) / 2,
					a0: x0,
					a1: x1,
					v: false
				});
			}
		}
	});
	for (const v of [true, false]) {
		const g = cs.filter((c) => c.v === v).sort((a, b) => a.a0 - b.a0);
		const used = new Uint8Array(g.length);
		for (let i = 0; i < g.length; i++) {
			if (used[i]) continue;
			const chain = [i];
			used[i] = 1;
			let last = g[i], tot = last.a1 - last.a0 + 1;
			for (let j = i + 1; j < g.length; j++) {
				if (used[j]) continue;
				const gap = g[j].a0 - last.a1;
				if (gap > maxGap) break;
				if (Math.abs(g[j].c - last.c) <= maxW * 1.5 + Math.max(0, gap + (g[j].a1 - g[j].a0)) * .2) {
					chain.push(j);
					used[j] = 1;
					tot += g[j].a1 - g[j].a0 + 1;
					last = g[j];
				}
			}
			if (tot >= minL && chain.length > 1) for (const k of chain) for (const p of g[k].px) {
				d[p * 4] = col.r;
				d[p * 4 + 1] = col.g;
				d[p * 4 + 2] = col.b;
			}
		}
	}
	return d;
}
/**
* S10i – vệt đứt nét/xiên bất kỳ góc (mép tờ dưới, vết bút) trong dải mép `band` (15 %).
* Điểm tối theo tương phản cục bộ (≥ 14). Mảnh nhỏ (≤ 4× bề dày tối đa) nằm thưa (ít điểm tối lạ quanh mảnh) được
* coi là ứng viên; tìm đường thẳng đi qua ≥ 5 mảnh (≥ 6 mảnh gạch thuôn, phủ ≥ 40 %, lệch ≤ bề dày tối đa, khe ≤ 5 %, dài ≥ 8 % cạnh ngắn; hai bên trống ≥ 98 %),
* không gần nằm ngang (≥ 35°, tránh dòng chữ nghiêng). Mỗi mảnh trên đường phải trống hai bên (không có chữ) → tô màu giấy.
*/
function edgeStrokeClean(d, W, H, band = .15) {
	const col = paperColor(d, W, H);
	const S = Math.min(W, H);
	if (col.L < 90) return d;
	const bw = Math.round(S * band), maxW = Math.max(3, Math.round(S * .008)), minL = S * .08, maxGap = S * .05;
	const dk = lazyLocalDark(d, W, H, S, col.L, bw + maxW * 4).get;
	const lab = new Int32Array(W * H);
	const cB = /* @__PURE__ */ new Int32Array(4008), sB = /* @__PURE__ */ new Int32Array(4008);
	const fs = [];
	let nid = 0;
	const maxS = maxW * 4;
	forBand(W, H, bw, (o, a, b) => {
		for (let s = o + a; s < o + b; s++) {
			if (lab[s] !== 0 || !dk(s)) continue;
			const x = s - o, y = o / W;
			const id = ++nid;
			let n = 1, sp = 1;
			cB[0] = s;
			sB[0] = s;
			lab[s] = id;
			let x0 = x, x1 = x, y0 = y, y1 = y;
			while (sp && n < 4e3) {
				const i = sB[--sp];
				const py = i / W | 0, px = i - py * W;
				if (px < x0) x0 = px;
				if (px > x1) x1 = px;
				if (py < y0) y0 = py;
				if (py > y1) y1 = py;
				if (px > 0 && py > 0 && px < W - 1 && py < H - 1) {
					let k = i - W - 1;
					if (lab[k] === 0 && dk(k)) {
						lab[k] = id;
						sB[sp++] = k;
						cB[n++] = k;
					}
					k = i - W;
					if (lab[k] === 0 && dk(k)) {
						lab[k] = id;
						sB[sp++] = k;
						cB[n++] = k;
					}
					k = i - W + 1;
					if (lab[k] === 0 && dk(k)) {
						lab[k] = id;
						sB[sp++] = k;
						cB[n++] = k;
					}
					k = i - 1;
					if (lab[k] === 0 && dk(k)) {
						lab[k] = id;
						sB[sp++] = k;
						cB[n++] = k;
					}
					k = i + 1;
					if (lab[k] === 0 && dk(k)) {
						lab[k] = id;
						sB[sp++] = k;
						cB[n++] = k;
					}
					k = i + W - 1;
					if (lab[k] === 0 && dk(k)) {
						lab[k] = id;
						sB[sp++] = k;
						cB[n++] = k;
					}
					k = i + W;
					if (lab[k] === 0 && dk(k)) {
						lab[k] = id;
						sB[sp++] = k;
						cB[n++] = k;
					}
					k = i + W + 1;
					if (lab[k] === 0 && dk(k)) {
						lab[k] = id;
						sB[sp++] = k;
						cB[n++] = k;
					}
				} else for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
					const nx = px + dx, ny = py + dy;
					if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
					const k = ny * W + nx;
					if (lab[k] === 0 && dk(k)) {
						lab[k] = id;
						sB[sp++] = k;
						cB[n++] = k;
					}
				}
			}
			if (n < 3 || x1 - x0 + 1 > maxS || y1 - y0 + 1 > maxS) continue;
			const r = maxW * 2;
			let foreign = 0;
			for (let yy = Math.max(0, y0 - r); yy <= Math.min(H - 1, y1 + r); yy += 2) for (let xx = Math.max(0, x0 - r); xx <= Math.min(W - 1, x1 + r); xx += 2) {
				const k = yy * W + xx;
				if (dk(k) && lab[k] !== id) foreign++;
			}
			if (foreign > Math.max(40, n * 1.5)) continue;
			const comp = cB.slice(0, n);
			let mx = 0, my = 0;
			for (const p of comp) {
				mx += p % W;
				my += p / W | 0;
			}
			fs.push({
				px: comp,
				id,
				x: mx / n,
				y: my / n,
				x0,
				x1,
				y0,
				y1
			});
		}
	});
	const paintF = [];
	const alive = new Uint8Array(fs.length).fill(1);
	const sinH = Math.sin(35 * Math.PI / 180);
	for (let i = 0; i < fs.length; i++) for (let j = i + 1; j < fs.length; j++) {
		if (!alive[i] || !alive[j]) continue;
		const a = fs[i], b = fs[j];
		const dx = b.x - a.x, dy = b.y - a.y, dist = Math.hypot(dx, dy);
		if (dist < maxW * 2 || dist > maxGap) continue;
		const ux = dx / dist, uy = dy / dist;
		if (Math.abs(uy) < sinH) continue;
		const inl = [];
		for (let k = 0; k < fs.length; k++) {
			if (!alive[k]) continue;
			const ex = fs[k].x - a.x, ey = fs[k].y - a.y;
			if (Math.abs(-ex * uy + ey * ux) <= maxW) inl.push({
				k,
				t: ex * ux + ey * uy
			});
		}
		if (inl.length < 5) continue;
		inl.sort((p, q) => p.t - q.t);
		let s0 = inl.findIndex((p) => p.k === i), e0 = s0;
		while (s0 > 0 && inl[s0].t - inl[s0 - 1].t <= maxGap) s0--;
		while (e0 < inl.length - 1 && inl[e0 + 1].t - inl[e0].t <= maxGap) e0++;
		const run = inl.slice(s0, e0 + 1);
		if (run.length < 6 || run[run.length - 1].t - run[0].t < minL) continue;
		let cover = 0, along = 0;
		for (const { k } of run) {
			let t0 = Infinity, t1 = -Infinity, v0 = Infinity, v1 = -Infinity;
			for (const p of fs[k].px) {
				const ex = p % W - a.x, ey = (p / W | 0) - a.y;
				const t = ex * ux + ey * uy, v = -ex * uy + ey * ux;
				if (t < t0) t0 = t;
				if (t > t1) t1 = t;
				if (v < v0) v0 = v;
				if (v > v1) v1 = v;
			}
			cover += t1 - t0 + 1;
			if (t1 - t0 >= 1.5 * (v1 - v0)) along++;
		}
		const span = run[run.length - 1].t - run[0].t;
		if (cover < span * .4 || along < run.length * .6) continue;
		let side = 0, tot = 0;
		const R = maxW * 3;
		for (const { k } of run) {
			const f = fs[k];
			for (const sg of [-1, 1]) for (let v = maxW; v <= R; v++) {
				const X = Math.round(f.x - sg * v * uy), Y = Math.round(f.y + sg * v * ux);
				tot++;
				if (X >= 0 && Y >= 0 && X < W && Y < H && dk(Y * W + X) && lab[Y * W + X] !== f.id) side++;
			}
		}
		if (side > tot * .02) continue;
		for (const { k } of run) {
			alive[k] = 0;
			paintF.push(k);
		}
	}
	for (const k of paintF) for (const p of fs[k].px) {
		d[p * 4] = col.r;
		d[p * 4 + 1] = col.g;
		d[p * 4 + 2] = col.b;
	}
	return d;
}
/**
* S10j – (1) khung xám mảnh: hàng/cột gần thẳng trục trong dải mép `band` có ≥ 25 % chiều dài là điểm hơi tối
* (tương phản ≥ 6), dày ≤ bề dày tối đa, hai bên là giấy → tô màu giấy.
* (2) vạch liền dài: thành phần tối liền khối, thuôn (dài ≥ 6 % cạnh ngắn, ≥ 8× bề ngang trung bình), góc ≥ 35°,
* nằm trong dải mép, ít điểm tối lạ quanh → tô màu giấy.
*/
function edgeFrameClean(d, W, H, band = .15) {
	const col = paperColor(d, W, H);
	const S = Math.min(W, H);
	if (col.L < 90) return d;
	const bw = Math.round(S * band), maxW = Math.max(3, Math.round(S * .008));
	const B = bw + 8, L = lumBand(d, W, H, B);
	const inB = (i) => {
		const y = i / W | 0, x = i - y * W;
		return x < B || y < B || x >= W - B || y >= H - B || !(B * 2 < W && B * 2 < H);
	};
	const paint = (i) => {
		d[i * 4] = col.r;
		d[i * 4 + 1] = col.g;
		d[i * 4 + 2] = col.b;
	};
	const faint = (i) => col.L - L[i] >= 6 && col.L - L[i] < 120;
	const isPaper = (i) => col.L - L[i] < 5;
	const minRun = S * .2;
	const fM = new Uint8Array(W * H), pM = new Uint8Array(W * H);
	forBand(W, H, B, (o, a, b) => {
		for (let i = o + a; i < o + b; i++) {
			if (faint(i)) fM[i] = 1;
			if (isPaper(i)) pM[i] = 1;
		}
	});
	const scan = (horiz) => {
		const N = horiz ? H : W, M = horiz ? W : H;
		const at = (a, b) => horiz ? a * W + b : b * W + a;
		const qRows = /* @__PURE__ */ new Map();
		if (!horiz) {
			const QT = new Uint8Array(W * H), z = new Uint8Array(H), c1 = Math.min(W, bw + 1), c2 = Math.max(c1, W - bw - 1);
			for (let y = 0; y < H; y++) {
				const o = y * W;
				for (let aa = 0; aa < W; aa++) {
					if (aa === c1) aa = c2;
					if (aa >= W) break;
					const up = aa > 4 ? aa - 4 : 0, dn = aa + 4 < W - 1 ? aa + 4 : W - 1;
					if (fM[o + aa] && pM[o + up] && pM[o + dn]) QT[aa * H + y] = 1;
				}
			}
			for (let aa = -1; aa <= W; aa++) {
				if (aa === c1) aa = c2;
				qRows.set(aa, aa >= 0 && aa < W ? QT.subarray(aa * H, aa * H + H) : z);
			}
		}
		const q = (aa) => {
			let r = qRows.get(aa);
			if (r) return r;
			r = new Uint8Array(M);
			if (aa >= 0 && aa < N) {
				const up = aa > 4 ? aa - 4 : 0, dn = aa + 4 < N - 1 ? aa + 4 : N - 1;
				for (let b = 0; b < M; b++) if (fM[at(aa, b)] && pM[at(up, b)] && pM[at(dn, b)]) r[b] = 1;
			}
			qRows.set(aa, r);
			if (horiz) qRows.delete(aa - 3);
			return r;
		};
		for (let a = 0; a < N; a++) {
			if (a >= bw && a < N - bw) continue;
			let s = -1, gap = 0, hit = 0;
			const q0 = q(a), qm = q(a - 1), qp = q(a + 1);
			for (let b = 0; b <= M; b++) {
				if (b < M && (q0[b] | qm[b] | qp[b]) === 1) {
					if (s < 0) s = b;
					hit++;
					gap = 0;
					continue;
				}
				if (s >= 0 && b < M && ++gap <= maxW * 2) continue;
				const e = b - gap;
				if (s >= 0 && e - s >= minRun && hit >= (e - s) * .6) for (let k = s; k <= e && k < M; k++) for (let t = -3; t <= 3; t++) {
					const aa = a + t;
					if (aa < 0 || aa >= N) continue;
					const i = at(aa, k);
					if (faint(i)) paint(i);
				}
				s = -1;
				gap = 0;
				hit = 0;
			}
		}
	};
	scan(true);
	scan(false);
	const dkc = new Uint8Array(W * H);
	const dk = (i) => {
		let v = dkc[i];
		if (!v) v = dkc[i] = col.L - lumOf(d, i) >= 30 ? 1 : 2;
		return v === 1;
	};
	forBand(W, H, bw, (o, a, b) => {
		for (let i = o + a; i < o + b; i++) dkc[i] = col.L - lumOf(d, i) >= 30 ? 1 : 2;
	});
	const Lat = (k) => inB(k) ? L[k] : Math.fround(lumOf(d, k));
	const seen = new Uint8Array(W * H);
	const sinH = Math.sin(35 * Math.PI / 180);
	const paintK = [];
	const cB = /* @__PURE__ */ new Int32Array(20008), sB = /* @__PURE__ */ new Int32Array(20008);
	forBand(W, H, bw, (o, a, b) => {
		for (let s = o + a; s < o + b; s++) {
			if (seen[s] || dkc[s] !== 1) continue;
			let n = 1, sp = 1;
			cB[0] = s;
			sB[0] = s;
			seen[s] = 1;
			while (sp && n < 2e4) {
				const i = sB[--sp];
				const py = i / W | 0, px = i - py * W;
				if (px > 0 && py > 0 && px < W - 1 && py < H - 1) {
					let k = i - W - 1;
					if (!seen[k] && dk(k)) {
						seen[k] = 1;
						sB[sp++] = k;
						cB[n++] = k;
					}
					k = i - W;
					if (!seen[k] && dk(k)) {
						seen[k] = 1;
						sB[sp++] = k;
						cB[n++] = k;
					}
					k = i - W + 1;
					if (!seen[k] && dk(k)) {
						seen[k] = 1;
						sB[sp++] = k;
						cB[n++] = k;
					}
					k = i - 1;
					if (!seen[k] && dk(k)) {
						seen[k] = 1;
						sB[sp++] = k;
						cB[n++] = k;
					}
					k = i + 1;
					if (!seen[k] && dk(k)) {
						seen[k] = 1;
						sB[sp++] = k;
						cB[n++] = k;
					}
					k = i + W - 1;
					if (!seen[k] && dk(k)) {
						seen[k] = 1;
						sB[sp++] = k;
						cB[n++] = k;
					}
					k = i + W;
					if (!seen[k] && dk(k)) {
						seen[k] = 1;
						sB[sp++] = k;
						cB[n++] = k;
					}
					k = i + W + 1;
					if (!seen[k] && dk(k)) {
						seen[k] = 1;
						sB[sp++] = k;
						cB[n++] = k;
					}
				} else for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
					const nx = px + dx, ny = py + dy;
					if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
					const k = ny * W + nx;
					if (!seen[k] && dk(k)) {
						seen[k] = 1;
						sB[sp++] = k;
						cB[n++] = k;
					}
				}
			}
			if (n < 20) continue;
			const comp = cB.subarray(0, n);
			let mx = 0, my = 0;
			for (const p of comp) {
				mx += p % W;
				my += p / W | 0;
			}
			mx /= n;
			my /= n;
			let sxx = 0, syy = 0, sxy = 0;
			for (const p of comp) {
				const ex = p % W - mx, ey = (p / W | 0) - my;
				sxx += ex * ex;
				syy += ey * ey;
				sxy += ex * ey;
			}
			const th = .5 * Math.atan2(2 * sxy, sxx - syy), ux = Math.cos(th), uy = Math.sin(th);
			let t0 = Infinity, t1 = -Infinity;
			for (const p of comp) {
				const t = (p % W - mx) * ux + ((p / W | 0) - my) * uy;
				if (t < t0) t0 = t;
				if (t > t1) t1 = t;
			}
			const len = t1 - t0 + 1, wAvg = n / len;
			let rr = 0;
			for (const p of comp) {
				const v = -(p % W - mx) * uy + ((p / W | 0) - my) * ux;
				rr += v * v;
			}
			if (Math.sqrt(rr / n) > Math.max(1.5, wAvg * .6)) continue;
			if (len < S * .04 || wAvg > maxW * 1.5 || len < wAvg * 8 || Math.abs(uy) < sinH) continue;
			let side = 0, tot = 0;
			const R = maxW * 4;
			for (let q = 0; q < n; q += 3) {
				const p = comp[q];
				const px = p % W, py = p / W | 0;
				for (const sg of [-1, 1]) for (let v = maxW * 2; v <= R; v += 2) {
					const X = Math.round(px - sg * v * uy), Y = Math.round(py + sg * v * ux);
					tot++;
					if (X >= 0 && Y >= 0 && X < W && Y < H && dk(Y * W + X) && !seen[Y * W + X]) side++;
				}
			}
			if (side > tot * .02) continue;
			for (const p of comp) {
				paintK.push(p);
				const px = p % W, py = p / W | 0;
				for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
					const k = (py + dy) * W + px + dx;
					if (k >= 0 && k < W * H) {
						const l = Lat(k);
						if (col.L - l >= 6 && col.L - l < 80) paintK.push(k);
					}
				}
			}
		}
	});
	for (const k of paintK) paint(k);
	return d;
}
/**
* S10j – mảng xám phẳng (bóng tờ khác, cạnh sắc) bất kỳ vị trí: nền cục bộ (đóng hình thái max→min trên ảnh ½)
* thấp hơn giấy 6–70 → chia nền (flat-field) cho điểm đó; chữ vẫn tối, nền về màu giấy.
*/
function greyBlockLift(d, W, H) {
	const col = paperColor(d, W, H);
	if (col.L < 120) return d;
	const w = Math.ceil(W / 2), h = Math.ceil(H / 2), g = new Float32Array(w * h);
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) g[y * w + x] = lumOf(d, Math.min(H - 1, y * 2) * W + Math.min(W - 1, x * 2));
	const r = Math.max(4, Math.round(Math.min(w, h) / 180));
	const k = 2 * r + 1, NEG = -Infinity;
	const mR = Math.ceil((w + 2 * r) / k) * k, pad = new Float32Array(mR), gF = new Float32Array(mR), hF = new Float32Array(mR);
	const CW = 128, mm = Math.ceil((h + 2 * r) / k) * k;
	const G = new Float32Array(mm * CW), Hb = new Float32Array(mm * CW);
	const maxFilt = (src) => {
		const a = new Float32Array(w * h), out = new Float32Array(w * h);
		for (let y = 0; y < h; y++) {
			const off = y * w;
			for (let i = 0; i < mR; i++) {
				const q = i - r;
				pad[i] = q >= 0 && q < w ? src[off + q] : NEG;
			}
			for (let b = 0; b < mR; b += k) {
				let v = NEG;
				for (let i = b; i < b + k; i++) {
					const x = pad[i];
					if (x > v) v = x;
					gF[i] = v;
				}
				v = NEG;
				for (let i = b + k - 1; i >= b; i--) {
					const x = pad[i];
					if (x > v) v = x;
					hF[i] = v;
				}
			}
			for (let q = 0; q < w; q++) {
				const x = hF[q], c = gF[q + 2 * r];
				a[off + q] = x > c ? x : c;
			}
		}
		for (let c0 = 0; c0 < w; c0 += CW) {
			const cn = Math.min(CW, w - c0);
			for (let b = 0; b < mm; b += k) {
				for (let i = b; i < b + k; i++) {
					const q = i - r, so = q * w + c0, go = i * CW, gp = go - CW;
					if (q < 0 || q >= h) if (i === b) G.fill(NEG, go, go + cn);
					else G.copyWithin(go, gp, gp + cn);
					else if (i === b) for (let x = 0; x < cn; x++) G[go + x] = a[so + x];
					else for (let x = 0; x < cn; x++) {
						const v = a[so + x], u = G[gp + x];
						G[go + x] = v > u ? v : u;
					}
				}
				for (let i = b + k - 1; i >= b; i--) {
					const q = i - r, so = q * w + c0, go = i * CW, gp = go + CW;
					if (q < 0 || q >= h) if (i === b + k - 1) Hb.fill(NEG, go, go + cn);
					else Hb.copyWithin(go, gp, gp + cn);
					else if (i === b + k - 1) for (let x = 0; x < cn; x++) Hb[go + x] = a[so + x];
					else for (let x = 0; x < cn; x++) {
						const v = a[so + x], u = Hb[gp + x];
						Hb[go + x] = v > u ? v : u;
					}
				}
			}
			for (let q = 0; q < h; q++) {
				const ho = q * CW, go = (q + 2 * r) * CW, o = q * w + c0;
				for (let x = 0; x < cn; x++) {
					const u = Hb[ho + x], c = G[go + x];
					out[o + x] = u > c ? u : c;
				}
			}
		}
		return out;
	};
	const neg = (a) => {
		for (let i = 0; i < a.length; i++) a[i] = -a[i];
		return a;
	};
	const bg0 = neg(maxFilt(neg(maxFilt(g))));
	const rm = new Float32Array(w * h), bg = new Float32Array(w * h);
	for (let y = 0; y < h; y++) {
		const o = y * w;
		rm[o] = w > 1 ? Math.min(bg0[o], bg0[o + 1]) : bg0[o];
		for (let x = 1; x < w - 1; x++) {
			const i = o + x;
			rm[i] = Math.min(bg0[i - 1], bg0[i], bg0[i + 1]);
		}
		if (w > 1) rm[o + w - 1] = Math.min(bg0[o + w - 2], bg0[o + w - 1]);
	}
	for (let y = 0; y < h; y++) {
		const o = y * w, up = y > 0 ? o - w : o, dn = y < h - 1 ? o + w : o;
		for (let x = 0; x < w; x++) bg[o + x] = Math.min(rm[up + x], rm[o + x], rm[dn + x]);
	}
	const lifted = new Uint8Array(W * H), rowL = new Uint8Array(H), L = new Float32Array(W * H);
	for (let y = 0; y < H; y++) {
		const br = (y >> 1) * w, o = y * W;
		for (let xh = 0; xh < w; xh++) {
			const b = bg[br + xh], def = col.L - b;
			if (def >= 6 && def <= 70) {
				const s = col.L / b;
				rowL[y] = 1;
				for (let x = xh * 2, xe = Math.min(W, x + 2); x < xe; x++) {
					const i = o + x;
					lifted[i] = 1;
					for (let c = 0; c < 3; c++) d[i * 4 + c] = Math.min(255, d[i * 4 + c] * s);
				}
			}
		}
	}
	const lum = (k) => {
		if (L[k] === 0) L[k] = lumOf(d, k);
		return L[k];
	};
	const pap = (k) => lum(k) >= col.L - 12;
	for (let y = 3; y < H - 3; y++) {
		if (!rowL[y] && !rowL[y - 3] && !rowL[y + 3]) continue;
		for (let x = 3; x < W - 3; x++) {
			const i = y * W + x;
			if (!lifted[i] && !lifted[i - 3] && !lifted[i + 3] && !lifted[i - 3 * W] && !lifted[i + 3 * W]) continue;
			const def = col.L - lum(i);
			if (def < 6 || def > 45) continue;
			if (pap(i - 3) && pap(i + 3) || pap(i - 3 * W) && pap(i + 3 * W)) for (let c = 0; c < 3; c++) d[i * 4 + c] = d[(pap(i - 3) ? i - 3 : i - 3 * W) * 4 + c];
		}
	}
	return d;
}
/**
* S10m – Q2 sót ở góc: vệt mảnh cô lập (dấu tick, đoạn mép tờ dưới) nằm trong vùng góc 12 %.
* Thành phần tối: dài 2–10 % cạnh ngắn, bề dày TB ≤ 1,2 % cạnh ngắn, quanh nó (lề 2 %) gần như không có
* điểm tối khác → tô màu giấy. Chữ ký/chữ ở góc lớn hơn hoặc không cô lập nên được giữ.
*/
function edgeCornerClean(d, W, H, zone = .12) {
	const col = paperColor(d, W, H);
	const dark = darkThreshold(col.L) + 25;
	const S = Math.min(W, H);
	const cz = Math.round(S * zone), minL = Math.round(S * .02), maxL = Math.round(S * .1), maxW = Math.max(3, Math.round(S * .012)), mg = Math.round(S * .02);
	const inCorner = (x, y) => (x < cz || x >= W - cz) && (y < cz || y >= H - cz);
	const dc = new Uint8Array(W * H);
	const isDark = (k) => {
		let v = dc[k];
		if (!v) {
			v = lumOf(d, k) < dark ? 1 : 2;
			dc[k] = v;
		}
		return v === 1;
	};
	const seen = new Uint8Array(W * H), mine = new Uint8Array(W * H);
	const comp = /* @__PURE__ */ new Int32Array(100008), st = /* @__PURE__ */ new Int32Array(100008);
	for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
		if (!inCorner(x, y)) {
			x = x < W - cz ? W - cz - 1 : W;
			continue;
		}
		const s = y * W + x;
		if (seen[s] || !isDark(s)) continue;
		let n = 1, sp = 1;
		comp[0] = s;
		st[0] = s;
		seen[s] = 1;
		let x0 = x, x1 = x, y0 = y, y1 = y;
		while (sp && n < 1e5) {
			const i = st[--sp];
			const py = i / W | 0, px = i - py * W;
			if (px < x0) x0 = px;
			if (px > x1) x1 = px;
			if (py < y0) y0 = py;
			if (py > y1) y1 = py;
			if (px > 0 && py > 0 && px < W - 1 && py < H - 1) {
				let k = i - W - 1;
				if (!seen[k] && isDark(k)) {
					seen[k] = 1;
					st[sp++] = k;
					comp[n++] = k;
				}
				k = i - W;
				if (!seen[k] && isDark(k)) {
					seen[k] = 1;
					st[sp++] = k;
					comp[n++] = k;
				}
				k = i - W + 1;
				if (!seen[k] && isDark(k)) {
					seen[k] = 1;
					st[sp++] = k;
					comp[n++] = k;
				}
				k = i - 1;
				if (!seen[k] && isDark(k)) {
					seen[k] = 1;
					st[sp++] = k;
					comp[n++] = k;
				}
				k = i + 1;
				if (!seen[k] && isDark(k)) {
					seen[k] = 1;
					st[sp++] = k;
					comp[n++] = k;
				}
				k = i + W - 1;
				if (!seen[k] && isDark(k)) {
					seen[k] = 1;
					st[sp++] = k;
					comp[n++] = k;
				}
				k = i + W;
				if (!seen[k] && isDark(k)) {
					seen[k] = 1;
					st[sp++] = k;
					comp[n++] = k;
				}
				k = i + W + 1;
				if (!seen[k] && isDark(k)) {
					seen[k] = 1;
					st[sp++] = k;
					comp[n++] = k;
				}
			} else for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
				const nx = px + dx, ny = py + dy;
				if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
				const k = ny * W + nx;
				if (!seen[k] && isDark(k)) {
					seen[k] = 1;
					st[sp++] = k;
					comp[n++] = k;
				}
			}
		}
		const len = Math.max(x1 - x0, y1 - y0) + 1;
		if (len < minL || len > maxL || n / len > maxW) continue;
		if (!(inCorner(x0, y0) && inCorner(x1, y1) && inCorner(x0, y1) && inCorner(x1, y0))) continue;
		for (let q = 0; q < n; q++) mine[comp[q]] = 1;
		let other = 0;
		for (let yy = Math.max(0, y0 - mg); yy <= Math.min(H - 1, y1 + mg); yy++) for (let xx = Math.max(0, x0 - mg); xx <= Math.min(W - 1, x1 + mg); xx++) {
			const k = yy * W + xx;
			if (!mine[k] && isDark(k)) other++;
		}
		for (let q = 0; q < n; q++) mine[comp[q]] = 0;
		if (other > n * .15) continue;
		for (let yy = Math.max(0, y0 - 3); yy <= Math.min(H - 1, y1 + 3); yy++) for (let xx = Math.max(0, x0 - 3); xx <= Math.min(W - 1, x1 + 3); xx++) {
			const k = yy * W + xx;
			if (lumOf(d, k) < col.L - 3) {
				d[k * 4] = col.r;
				d[k * 4 + 1] = col.g;
				d[k * 4 + 2] = col.b;
				dc[k] = 0;
			}
		}
	}
	const grey = (k) => lumOf(d, k) < col.L - 15, pap = (k) => lumOf(d, k) >= col.L - 8;
	const wipe = (ks) => {
		for (const k of ks) {
			d[k * 4] = col.r;
			d[k * 4 + 1] = col.g;
			d[k * 4 + 2] = col.b;
		}
	};
	for (let x = 4; x < W - 4; x++) {
		if (!(x < cz || x >= W - cz)) continue;
		for (const [ya, yb] of [[0, cz], [H - cz, H]]) {
			let run = [];
			for (let y = ya; y <= yb; y++) {
				const k = y * W + x;
				if (y < yb && grey(k) && pap(k - 4) && pap(k + 4)) {
					run.push(k);
					continue;
				}
				if (run.length >= minL) wipe(run);
				run = [];
			}
		}
	}
	for (let y = 4; y < H - 4; y++) {
		if (!(y < cz || y >= H - cz)) continue;
		for (const [xa, xb] of [[0, cz], [W - cz, W]]) {
			let run = [];
			for (let x = xa; x <= xb; x++) {
				const k = y * W + x;
				if (x < xb && grey(k) && pap(k - 4 * W) && pap(k + 4 * W)) {
					run.push(k);
					continue;
				}
				if (run.length >= minL) wipe(run);
				run = [];
			}
		}
	}
	return d;
}
/**
* R6.1b-3 – Nâng bóng nền tràn vào 4 góc sau khi nắn khung (cổng 17.4: góc tối ≤ 0,2 %).
* Thành phần tối (luma < 60) trong vùng góc 6 % mà chạm mép ảnh là nền ngoài tờ giấy
* (nội dung thật hầu như không dính mép) → tô màu giấy cả quầng xám 2 px quanh nó.
* Vệt tối ở góc nhưng KHÔNG chạm mép (chữ ký, dấu) được giữ nguyên.
*/
function cornerShadowLift(d, W, H, zone = .06) {
	const col = paperColor(d, W, H);
	const S = Math.min(W, H);
	const cz = Math.round(S * zone);
	const inCorner = (x, y) => (x < cz || x >= W - cz) && (y < cz || y >= H - cz);
	const isDark = (k) => lumOf(d, k) < 60;
	const seen = new Uint8Array(W * H);
	for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
		if (!inCorner(x, y)) {
			x = x < W - cz ? W - cz - 1 : W;
			continue;
		}
		const s = y * W + x;
		if (seen[s] || !isDark(s)) continue;
		const st = [s];
		seen[s] = 1;
		let touch = false;
		let x0 = x, x1 = x, y0 = y, y1 = y;
		let n = 0;
		while (st.length && n < 2e5) {
			const i = st.pop();
			n++;
			const px = i % W, py = i / W | 0;
			if (px < x0) x0 = px;
			if (px > x1) x1 = px;
			if (py < y0) y0 = py;
			if (py > y1) y1 = py;
			if (px === 0 || py === 0 || px === W - 1 || py === H - 1) touch = true;
			for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
				const nx = px + dx, ny = py + dy;
				if (nx < 0 || ny < 0 || nx >= W || ny >= H || !inCorner(nx, ny)) continue;
				const k = ny * W + nx;
				if (!seen[k] && isDark(k)) {
					seen[k] = 1;
					st.push(k);
				}
			}
		}
		if (!touch) {
			const bw = x1 - x0 + 1, bh = y1 - y0 + 1;
			if (!(n / (bw * bh) > .7 && bw >= S * .005 && bh >= S * .005 && bw <= S * .08 && bh <= S * .08)) continue;
		}
		for (let yy = Math.max(0, y0 - 2); yy <= Math.min(H - 1, y1 + 2); yy++) for (let xx = Math.max(0, x0 - 2); xx <= Math.min(W - 1, x1 + 2); xx++) {
			const k = yy * W + xx;
			if (lumOf(d, k) < col.L - 3) {
				d[k * 4] = col.r;
				d[k * 4 + 1] = col.g;
				d[k * 4 + 2] = col.b;
			}
		}
	}
	return d;
}
function solve(A, b) {
	const n = b.length;
	for (let i = 0; i < n; i++) {
		let p = i;
		for (let r = i + 1; r < n; r++) if (Math.abs(A[r][i]) > Math.abs(A[p][i])) p = r;
		[A[i], A[p]] = [A[p], A[i]];
		[b[i], b[p]] = [b[p], b[i]];
		for (let r = i + 1; r < n; r++) {
			const f = A[r][i] / A[i][i];
			for (let c = i; c < n; c++) A[r][c] -= f * A[i][c];
			b[r] -= f * b[i];
		}
	}
	const x = new Array(n).fill(0);
	for (let i = n - 1; i >= 0; i--) {
		let s = b[i];
		for (let c = i + 1; c < n; c++) s -= A[i][c] * x[c];
		x[i] = s / A[i][i];
	}
	return x;
}
function homography(from, to) {
	const A = [];
	const b = [];
	for (let i = 0; i < 4; i++) {
		const [x, y] = from[i];
		const [u, v] = to[i];
		A.push([
			x,
			y,
			1,
			0,
			0,
			0,
			-u * x,
			-u * y
		]);
		b.push(u);
		A.push([
			0,
			0,
			0,
			x,
			y,
			1,
			-v * x,
			-v * y
		]);
		b.push(v);
	}
	return solve(A, b);
}
/** Unsharp mask: out = px + amount·(px − blur3x3). */
function unsharp(d, W, H, amount, threshold = 3) {
	const src = new Uint8ClampedArray(d);
	const row = W * 4;
	for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
		const i = y * row + x * 4;
		for (let k = 0; k < 3; k++) {
			const j = i + k;
			const b = (src[j - row - 4] + src[j - row] + src[j - row + 4] + src[j - 4] + src[j] + src[j + 4] + src[j + row - 4] + src[j + row] + src[j + row + 4]) / 9;
			const diff = src[j] - b;
			if (Math.abs(diff) > threshold) d[j] = src[j] + amount * diff;
		}
	}
	return d;
}
function grayPixels(d) {
	for (let i = 0; i < d.length; i += 4) {
		const g = d[i] * .3 + d[i + 1] * .59 + d[i + 2] * .11;
		d[i] = d[i + 1] = d[i + 2] = g;
	}
	return d;
}
/**
* Ngưỡng Sauvola (G1-06): T = m · (1 + k · (s/R − 1)), m/s là trung bình/độ lệch chuẩn cục bộ
* tính bằng 2 ảnh tích phân. Giữ nét chữ mảnh, không sinh nhiễu ở vùng nền phẳng. ink = chữ xám đậm.
*/
function thresholdPixels(d, W, H, ink, k = .34, R = 128) {
	const g = new Float32Array(W * H);
	const W1 = W + 1;
	const I = new Float64Array(W1 * (H + 1)), I2 = new Float64Array(W1 * (H + 1));
	for (let i = 0, p = 0; i < d.length; i += 4, p++) g[p] = d[i] * .3 + d[i + 1] * .59 + d[i + 2] * .11;
	for (let y = 1; y <= H; y++) {
		let row = 0, row2 = 0;
		for (let x = 1; x <= W; x++) {
			const v = g[(y - 1) * W + x - 1];
			row += v;
			row2 += v * v;
			I[y * W1 + x] = I[(y - 1) * W1 + x] + row;
			I2[y * W1 + x] = I2[(y - 1) * W1 + x] + row2;
		}
	}
	const r = Math.max(8, Math.round(Math.min(W, H) / 24));
	for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
		const x0 = Math.max(0, x - r), x1 = Math.min(W, x + r), y0 = Math.max(0, y - r), y1 = Math.min(H, y + r);
		const n = (x1 - x0) * (y1 - y0);
		const a = y1 * W1 + x1, b = y0 * W1 + x1, c = y1 * W1 + x0, e = y0 * W1 + x0;
		const m = (I[a] - I[b] - I[c] + I[e]) / n;
		const s = Math.sqrt(Math.max(0, (I2[a] - I2[b] - I2[c] + I2[e]) / n - m * m));
		const p = y * W + x;
		const v = g[p] < m * (1 + k * (s / R - 1)) ? ink ? 24 : 0 : 255;
		d[p * 4] = d[p * 4 + 1] = d[p * 4 + 2] = v;
	}
	return d;
}
function tonePixels(d, brightness, contrast) {
	const cf = 259 * (contrast + 255) / (255 * (259 - contrast));
	for (let i = 0; i < d.length; i += 4) for (let k = 0; k < 3; k++) d[i + k] = Math.min(255, Math.max(0, cf * (d[i + k] - 128) + 128 + brightness));
	return d;
}
/** Chia nền sáng không đều: ước lượng nền giấy (thu nhỏ + lọc max + làm mờ + phóng lại) rồi chuẩn hoá về trắng. Thuần điểm ảnh. */
/** Ảnh nền giấy ở một tỉ lệ: trung bình khối → max 3×3 hai lần (xoá chữ) → mờ hộp 3×3 hai lần. */
function bgMap(d, W, H, div) {
	const sw = Math.max(8, Math.round(W / div)), sh = Math.max(8, Math.round(H / div));
	let small = new Float32Array(sw * sh * 3);
	const bw = W / sw, bh = H / sh;
	for (let y = 0; y < sh; y++) for (let x = 0; x < sw; x++) {
		const x0 = Math.floor(x * bw), x1 = Math.max(x0 + 1, Math.floor((x + 1) * bw));
		const y0 = Math.floor(y * bh), y1 = Math.max(y0 + 1, Math.floor((y + 1) * bh));
		let r = 0, g = 0, b = 0, n = 0;
		for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) {
			const i = (yy * W + xx) * 4;
			r += d[i];
			g += d[i + 1];
			b += d[i + 2];
			n++;
		}
		const o = (y * sw + x) * 3;
		small[o] = r / n;
		small[o + 1] = g / n;
		small[o + 2] = b / n;
	}
	const pass = (fn) => {
		const src = small;
		const out = new Float32Array(src.length);
		for (let y = 0; y < sh; y++) for (let x = 0; x < sw; x++) for (let k = 0; k < 3; k++) out[(y * sw + x) * 3 + k] = fn(src, x, y, k);
		small = out;
	};
	const maxF = (src, x, y, k) => {
		let m = 0;
		for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
			const xx = Math.min(sw - 1, Math.max(0, x + dx)), yy = Math.min(sh - 1, Math.max(0, y + dy));
			m = Math.max(m, src[(yy * sw + xx) * 3 + k]);
		}
		return m;
	};
	const boxF = (src, x, y, k) => {
		let s = 0, n = 0;
		for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
			const xx = x + dx, yy = y + dy;
			if (xx >= 0 && xx < sw && yy >= 0 && yy < sh) {
				s += src[(yy * sw + xx) * 3 + k];
				n++;
			}
		}
		return s / n;
	};
	const minF = (src, x, y, k) => {
		let m = 255;
		for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
			const xx = Math.min(sw - 1, Math.max(0, x + dx)), yy = Math.min(sh - 1, Math.max(0, y + dy));
			m = Math.min(m, src[(yy * sw + xx) * 3 + k]);
		}
		return m;
	};
	pass(maxF);
	pass(maxF);
	pass(minF);
	pass(minF);
	pass(boxF);
	if (div < 48) pass(boxF);
	return {
		small,
		sw,
		sh,
		bw,
		bh
	};
}
/**
* B6: chuẩn hoá nền đa tỉ lệ. Nền thô (khối W/24) chịu mảng chữ đậm; nền mịn (W/64) bám mép bóng tay.
* Dùng nền mịn, trừ chỗ tối sâu hơn 40 % so với nền thô (khối ảnh/chữ lớn) thì giữ nền thô; chia ra rồi đẩy giấy về 250–255.
*/
/** Đo bản đồ nền (thô + mịn) từ ảnh ở bất kỳ độ phân giải nào — S15d: gọi trên bản ≤1000 px. */
function flattenMap(d, W, H) {
	return {
		coarse: bgMap(d, W, H, 24),
		fine: Math.min(W, H) >= 256 ? bgMap(d, W, H, 64) : null
	};
}
/** Bảng nội suy theo một trục: chỉ số ô và phần lẻ cho từng toạ độ (giống hệt sampleBg). */
function axisLut(n, cells) {
	const b = n / cells, i0 = new Int32Array(n), f = new Float32Array(n);
	for (let p = 0; p < n; p++) {
		const u = Math.min(cells - 1.001, Math.max(0, (p + .5) / b - .5));
		i0[p] = u | 0;
		f[p] = u - (u | 0);
	}
	return {
		i0,
		f
	};
}
/**
* Áp bản đồ nền lên ảnh ở bất kỳ độ phân giải nào (nội suy song tuyến theo toạ độ chuẩn hoá).
* V6: tách song tuyến thành 2 trục — nội suy dọc 1 lần/hàng trên lưới nhỏ, mỗi điểm chỉ còn 1 phép nội suy ngang;
* bảng chỉ số dựng sẵn. Cùng công thức với sampleBg nên kết quả giống (sai lệch làm tròn float ≤ 1 mức).
*/
function flattenApply(d, W, H, maps) {
	const { coarse, fine } = maps;
	const cx = axisLut(W, coarse.sw), cy = axisLut(H, coarse.sh);
	const fx = fine ? axisLut(W, fine.sw) : null, fy = fine ? axisLut(H, fine.sh) : null;
	const rowC = new Float32Array(coarse.sw * 3), rowF = new Float32Array(fine ? fine.sw * 3 : 0);
	const vRow = (m, v0, fv, out) => {
		const s = m.small, a = v0 * m.sw * 3, b = a + m.sw * 3;
		for (let i = 0; i < m.sw * 3; i++) out[i] = s[a + i] * (1 - fv) + s[b + i] * fv;
	};
	for (let y = 0; y < H; y++) {
		vRow(coarse, cy.i0[y], cy.f[y], rowC);
		if (fine) vRow(fine, fy.i0[y], fy.f[y], rowF);
		let o = y * W * 4;
		for (let x = 0; x < W; x++, o += 4) {
			const ci = cx.i0[x] * 3, cf = cx.f[x];
			const fi = fine ? fx.i0[x] * 3 : 0, ff = fine ? fx.f[x] : 0;
			for (let k = 0; k < 3; k++) {
				let bg = rowC[ci + k] * (1 - cf) + rowC[ci + 3 + k] * cf;
				if (fine) {
					const f = rowF[fi + k] * (1 - ff) + rowF[fi + 3 + k] * ff;
					if (f >= bg * .6) bg = f;
				}
				const v = d[o + k] * 253 / Math.max(40, bg);
				d[o + k] = v >= 235 ? Math.min(255, 250 + (v - 235) * .3) : Math.min(255, v + Math.max(0, (v - 200) / 35) * 15);
			}
		}
	}
	return d;
}
function flattenPixels(d, W, H) {
	return flattenApply(d, W, H, flattenMap(d, W, H));
}
function otsuPx(g) {
	const hist = new Array(256).fill(0);
	for (const v of g) hist[v | 0]++;
	const total = g.length;
	let sum = 0;
	for (let i = 0; i < 256; i++) sum += i * hist[i];
	let sumB = 0, wB = 0, best = 0, t = 127;
	for (let i = 0; i < 256; i++) {
		wB += hist[i];
		if (!wB) continue;
		const wF = total - wB;
		if (!wF) break;
		sumB += i * hist[i];
		const mB = sumB / wB, mF = (sum - sumB) / wF;
		const between = wB * wF * (mB - mF) ** 2;
		if (between > best) {
			best = between;
			t = i;
		}
	}
	return t;
}
/** Ước lượng độ nghiêng nhỏ (±5°) từ dữ liệu điểm ảnh thô. */
function estimateSkewPx(d, W, H) {
	const s = Math.min(1, 600 / Math.max(W, H));
	const w = Math.max(8, Math.round(W * s)), h = Math.max(8, Math.round(H * s));
	const g = new Uint8ClampedArray(w * h);
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		const sx = Math.min(W - 1, Math.round((x + .5) * (W / w)));
		const i = (Math.min(H - 1, Math.round((y + .5) * (H / h))) * W + sx) * 4;
		g[y * w + x] = d[i] * .3 + d[i + 1] * .59 + d[i + 2] * .11;
	}
	const t = otsuPx(g);
	const ink = [];
	const mx = Math.round(w * .05), my = Math.round(h * .05);
	for (let y = my; y < h - my; y++) for (let x = mx; x < w - mx; x++) if (g[y * w + x] < t - 10) ink.push(x, y);
	if (ink.length < 400 || ink.length / 2 > w * h * .35) return 0;
	const score = (deg) => {
		const a = deg * Math.PI / 180, tn = Math.tan(a);
		const rows = new Float64Array(h * 2);
		for (let i = 0; i < ink.length; i += 2) {
			const r = Math.round(ink[i + 1] - (ink[i] - w / 2) * tn) + h / 2;
			if (r >= 0 && r < rows.length) rows[r]++;
		}
		let v = 0;
		for (let i = 1; i < rows.length; i++) v += (rows[i] - rows[i - 1]) ** 2;
		return v;
	};
	let best = 0, bs = score(0);
	for (let dg = -5; dg <= 5; dg += .5) {
		const v = score(dg);
		if (v > bs) {
			bs = v;
			best = dg;
		}
	}
	const c0 = best;
	for (let dg = c0 - .4; dg <= c0 + .4; dg += .1) {
		const v = score(dg);
		if (v > bs) {
			bs = v;
			best = dg;
		}
	}
	return Math.abs(best) < .25 || bs < score(0) * 1.05 ? 0 : best;
}
/** Xoay thẳng ảnh theo độ nghiêng ước lượng; zoom nhẹ để góc trống khớp màu giấy. Thuần điểm ảnh, kích thước giữ nguyên. */
function deskewPixels(d, W, H) {
	const deg = estimateSkewPx(d, W, H);
	if (!deg) return d;
	const a = deg * Math.PI / 180;
	const zoom = 1 + Math.abs(Math.sin(a)) * Math.max(W / H, H / W);
	const cos = Math.cos(a) / zoom, sin = Math.sin(a) / zoom;
	const out = new Uint8ClampedArray(d.length);
	const cx = W / 2, cy = H / 2;
	for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
		const dx = x - cx, dy = y - cy;
		const u = Math.min(W - 1.001, Math.max(0, dx * cos - dy * sin + cx));
		const v = Math.min(H - 1.001, Math.max(0, dx * sin + dy * cos + cy));
		const u0 = u | 0, v0 = v | 0, fu = u - u0, fv = v - v0;
		const i00 = (v0 * W + u0) * 4, i10 = i00 + 4, i01 = i00 + W * 4, i11 = i01 + 4, oi = (y * W + x) * 4;
		for (let k = 0; k < 3; k++) out[oi + k] = (d[i00 + k] * (1 - fu) + d[i10 + k] * fu) * (1 - fv) + (d[i01 + k] * (1 - fu) + d[i11 + k] * fu) * fv;
		out[oi + 3] = 255;
	}
	return out;
}
/**
* Bộ lọc G1-07. eco: xám, giấy về trắng, mực đen nhạt về ~xám đậm (tốn ít mực hơn khi in);
* vivid: tăng độ bão hòa ×1.5 quanh độ sáng + tương phản nhẹ; bright: nâng vùng tối (gamma 0.7), giữ màu.
*/
function stylePixels(d, mode) {
	for (let i = 0; i < d.length; i += 4) {
		const r = d[i], g = d[i + 1], b = d[i + 2];
		const y = r * .3 + g * .59 + b * .11;
		if (mode === "eco") {
			const t = Math.min(1, Math.max(0, (y - 30) / 175));
			const v = 255 * Math.pow(t, 2.2);
			d[i] = d[i + 1] = d[i + 2] = inkCurve(v);
		} else if (mode === "vivid") for (let k = 0; k < 3; k++) {
			const c = y + (d[i + k] - y) * 1.5;
			d[i + k] = Math.min(255, Math.max(0, (c - 128) * 1.1 + 128));
		}
		else for (let k = 0; k < 3; k++) d[i + k] = 255 * Math.pow(d[i + k] / 255, .7);
	}
	return d;
}
/** Chạy một việc điểm ảnh, trả về bộ đệm kết quả. */
function runJob(j) {
	switch (j.op) {
		case "warp": return warpCurved(j.src, j.W, j.H, j.q, j.ow, j.oh, j.curves ?? []);
		case "textflat": return textFlattenRGBA(j.d, j.W, j.H, detectTextLines);
		case "sharpen": return sharpenAdaptive(j.d, j.W, j.H, j.amount);
		case "clean": return cleanEdges(j.d, j.W, j.H);
		case "gray": return grayPixels(j.d);
		case "threshold": return thresholdPixels(flattenPixels(j.d, j.W, j.H), j.W, j.H, j.ink);
		case "unsharp": return unsharp(j.d, j.W, j.H, j.amount);
		case "style": return stylePixels(j.d, j.mode);
		case "tone": return tonePixels(j.d, j.brightness, j.contrast);
		case "flatten": return flattenPixels(j.d, j.W, j.H);
		case "flatten-apply": return flattenApply(j.d, j.W, j.H, j.maps);
		case "deshadow": return deshadowPixels$1(j.d, j.W, j.H);
		case "deskew": return deskewPixels(j.d, j.W, j.H);
		case "docchain": {
			const o = docChain(j.d, j.W, j.H, j.sharp);
			if (j.deep) inkDeepen(o, 170, 2.2, edgeSaturatedMask(o, j.W, j.H));
			return o;
		}
		case "flatten-small": return flattenApply(j.d, j.W, j.H, flattenMap(j.s, j.sw, j.sh));
		case "tools": return applyTools(j.d, j.W, j.H, j.tools);
	}
}
/** S15e: chuỗi Tài liệu sáng/Sắc nét (kéo mức → nắn dòng → làm nét → nắn nửa trên) trong một việc Worker. */
function docChain(d, W, H, sharp) {
	autoLevel(d, sharp ? 1.85 : 1.55);
	d.set(lineSkewRefine(d, W, H, 2).data);
	d.set(lineSkewRefineTop(d, W, H, 2).data);
	d.set(sharpenAdaptive(d, W, H, sharp ? 1.4 : .9));
	d.set(lineSkewRefineTopSide(d, W, H, 2).data);
	d.set(smoothSkewCorrect(d, W, H).data);
	inkDeepen(d, void 0, void 0, edgeSaturatedMask(d, W, H));
	return d;
}
/** S15j: thứ tự làm sạch mép (giữ đúng thứ tự cũ: xoá nêm → mặt nạ giấy → bóng → chấm/vạch/khung → góc → nâng bóng góc R6.1b-3). */
var EDGE_CLEAN_STEPS = [
	cleanBorder,
	paperMaskFill,
	edgeShadowLift,
	edgeShadowSmooth,
	edgeSpeckClean,
	edgeLineClean,
	edgeDashClean,
	edgeStrokeClean,
	greyBlockLift,
	edgeFrameClean,
	edgeCornerClean,
	cornerShadowLift
];
function cleanEdges(d, W, H) {
	return EDGE_CLEAN_STEPS.reduce((a, f) => f(a, W, H), d);
}
/** Ma trận chiếu biến hình vuông đơn vị (0,0)(1,0)(1,1)(0,1) → tứ giác q (thứ tự TL, TR, BR, BL). */
function squareToQuad(q) {
	const [[x0, y0], [x1, y1], [x2, y2], [x3, y3]] = q;
	const sx = x0 - x1 + x2 - x3, sy = y0 - y1 + y2 - y3;
	let g = 0, h = 0;
	if (Math.abs(sx) > 1e-12 || Math.abs(sy) > 1e-12) {
		const dx1 = x1 - x2, dx2 = x3 - x2, dy1 = y1 - y2, dy2 = y3 - y2;
		const den = dx1 * dy2 - dx2 * dy1;
		g = (sx * dy2 - dx2 * sy) / den;
		h = (dx1 * sy - sx * dy1) / den;
	}
	const a = x1 - x0 + g * x1, b = x3 - x0 + h * x3, c = x0;
	const d = y1 - y0 + g * y1, e = y3 - y0 + h * y3, f = y0;
	return (u, v) => {
		const w = g * u + h * v + 1;
		return [(a * u + b * v + c) / w, (d * u + e * v + f) / w];
	};
}
/**
* Xoay khung nguồn q (toạ độ điểm ảnh) theo góc deg đo trên ảnh đã nắn kích thước ow×oh.
* Kết quả nắn theo khung mới = deskewPixels(nắn theo q), nhưng không có góc trống.
*/
function deskewQuad(q, ow, oh, deg) {
	if (!deg) return q.map((p) => [p[0], p[1]]);
	const H = squareToQuad(q);
	const a = deg * Math.PI / 180;
	const zoom = 1 + Math.abs(Math.sin(a)) * Math.max(ow / oh, oh / ow);
	const cos = Math.cos(a) / zoom, sin = Math.sin(a) / zoom, cx = ow / 2, cy = oh / 2;
	return [
		[0, 0],
		[ow, 0],
		[ow, oh],
		[0, oh]
	].map(([x, y]) => {
		const dx = x - cx, dy = y - cy;
		return H((dx * cos - dy * sin + cx) / ow, (dx * sin + dy * cos + cy) / oh);
	});
}
var FILTER_ALIAS = {
	bw: "mono",
	blackwhite: "mono",
	"black-white": "mono",
	grey: "gray",
	grayscale: "gray",
	document: "auto",
	light: "auto",
	color: "original"
};
var FILTERS = [
	"original",
	"magic",
	"auto",
	"sharp",
	"mono",
	"gray",
	"ink",
	"eco",
	"vivid",
	"bright",
	"shadow",
	"denoise"
];
/** S15b: tên bộ lọc cũ/ngoài → tên nội bộ; tên lạ rơi về "original" có cảnh báo. */
function normalizeFilter(f) {
	const k = String(f ?? "original").trim().toLowerCase();
	if (FILTERS.includes(k)) return k;
	if (FILTER_ALIAS[k]) return FILTER_ALIAS[k];
	console.warn(`[filter] tên bộ lọc không hợp lệ: ${f} → original`);
	return "original";
}
var im = (d, w, h) => new ImageData(d, w, h);
/** Bộ đệm → canvas (putImageData, không sao chép). */
function toCanvas(env, d, w, h) {
	const [c, ctx] = env.canvas(w, h);
	ctx.putImageData(im(d, w, h), 0, 0);
	return [c, ctx];
}
async function timed(env, step, fn) {
	const t0 = performance_default.now();
	try {
		return await fn();
	} finally {
		env.mark?.(step, Math.round(performance_default.now() - t0));
	}
}
/** Nắn một lần (bản dò khi max nhỏ). Trả bộ đệm ow×oh + cờ giấy cong. */
/** CS-16: cạnh dài thật (px ảnh gốc) của tờ giấy = cạnh dài nhất của khung (làm tròn lên, tối thiểu 1). */
function paperLongPx(q) {
	let m = 0;
	for (let i = 0; i < 4; i++) {
		const [ax, ay] = q[i], [bx, by] = q[(i + 1) % 4];
		m = Math.max(m, Math.hypot(bx - ax, by - ay));
	}
	return Math.max(1, Math.ceil(m));
}
/** Khung nguồn (px) + cỡ đích ow×oh của một lần nắn — dùng chung cho dựng chính và xem trước GPU (CS-18). */
function warpSize(quad, W, H, max, paper, keep) {
	const q = quad.map(([x, y]) => [x * W, y * H]);
	const ratio = snapAspect(quadAspect(quad, W, H), paper);
	const long = keep ? max : Math.min(max, paperLongPx(q));
	const ow = ratio >= 1 ? long : long * ratio, oh = ratio >= 1 ? long / ratio : long;
	return {
		q,
		ow: Math.round(ow),
		oh: Math.round(oh)
	};
}
async function warpPx(env, sd, W, H, quad, max, paper, keep, flatten, perf) {
	const { q, ow, oh } = warpSize(quad, W, H, max, paper, keep);
	const t0 = performance_default.now();
	const tc = performance_default.now();
	const curves = flatten === false ? [] : edgeCurves(sd, W, H, q);
	env.mark?.(keep ? "geo:curves0" : "geo:curves", Math.round(performance_default.now() - tc));
	const curved = curves.some(Boolean);
	const w = await timed(env, keep ? "geo:warp0" : "geo:warp", () => env.warp(sd, W, H, q, ow, oh, curves, keep));
	const engine = w.engine;
	let od = w.od;
	if (flatten !== false) od = await timed(env, keep ? "geo:textflat0" : "geo:textflat", () => env.run({
		op: "textflat",
		d: od,
		W: ow,
		H: oh
	}));
	perf.push({
		engine,
		ms: Math.round(performance_default.now() - t0)
	});
	return {
		d: od,
		w: ow,
		h: oh,
		curved
	};
}
/**
* B5: xoay thẳng → nắn/cắt. Đo độ nghiêng trên bản nắn thô nhỏ, rồi xoay khung nguồn và nắn một lần.
* Giấy cong: nắn rồi xoay thẳng điểm ảnh (deskew).
*/
async function straightWarpPx(env, sd, W, H, quad, max, paper = "auto", flatten, perf) {
	const probe = await warpPx(env, sd, W, H, quad, Math.min(max, 720), paper, true, flatten, perf);
	if (probe.curved) {
		const w = await warpPx(env, sd, W, H, quad, max, paper, false, flatten, perf);
		return {
			d: await env.run({
				op: "deskew",
				d: w.d,
				W: w.w,
				H: w.h
			}),
			w: w.w,
			h: w.h
		};
	}
	const deg = estimateSkewPx(probe.d, probe.w, probe.h);
	if (!deg) return warpPx(env, sd, W, H, quad, max, paper, false, flatten, perf);
	return warpPx(env, sd, W, H, deskewQuad(quad.map(([x, y]) => [x * W, y * H]), probe.w, probe.h, deg).map(([x, y]) => [x / W, y / H]), max, paper, false, flatten, perf);
}
/** Bỏ mép nền thừa sau khi nắn: cắt dải tối sát cạnh (trimBox), rồi xoá nêm nền dính viền (op "clean"). */
async function cleanEdgesPx(env, g) {
	const { d: src, w: W, h: H } = g;
	const b = trimBox(src, W, H);
	const w = b.x1 - b.x0, h = b.y1 - b.y0;
	let d;
	if (w === W && h === H) d = src;
	else if (w === W) d = src.slice(b.y0 * W * 4, b.y1 * W * 4);
	else {
		d = new Uint8ClampedArray(w * h * 4);
		for (let y = 0; y < h; y++) {
			const s = ((y + b.y0) * W + b.x0) * 4;
			d.set(src.subarray(s, s + w * 4), y * w * 4);
		}
	}
	const res = await env.run({
		op: "clean",
		d,
		W: w,
		H: h
	});
	return {
		d: res.byteLength === w * h * 4 && res.byteOffset === 0 ? res : new Uint8ClampedArray(res.buffer, res.byteOffset, w * h * 4),
		w,
		h
	};
}
/** Xoay 90/180/270° bằng canvas như bản cũ. */
function rotatePx(env, g, rotation) {
	const r = (rotation % 360 + 360) % 360;
	if (!r) return g;
	const [c] = toCanvas(env, g.d, g.w, g.h);
	const [rc, rctx] = env.canvas(r % 180 ? g.h : g.w, r % 180 ? g.w : g.h);
	rctx.translate(rc.width / 2, rc.height / 2);
	rctx.rotate(r * Math.PI / 180);
	rctx.drawImage(c, -c.width / 2, -c.height / 2);
	c.width = 0;
	return {
		d: rctx.getImageData(0, 0, rc.width, rc.height).data,
		w: rc.width,
		h: rc.height
	};
}
/** Chuẩn hoá ánh sáng: đo nền trên bản ≤ 1000 px (thu nhỏ làm mịn "high"), áp lên bản lớn. */
async function flattenLightPx(env, d, W, H) {
	if (Math.max(W, H) > 1e3) {
		const s = 1e3 / Math.max(W, H);
		const sw = Math.max(1, Math.round(W * s)), sh = Math.max(1, Math.round(H * s));
		const [c] = toCanvas(env, d, W, H);
		const [sm, smx] = env.canvas(sw, sh);
		smx.imageSmoothingQuality = "high";
		smx.drawImage(c, 0, 0, sw, sh);
		const sd = smx.getImageData(0, 0, sw, sh).data;
		sm.width = 0;
		c.width = 0;
		return env.run({
			op: "flatten-small",
			d,
			W,
			H,
			s: sd,
			sw,
			sh
		});
	}
	return env.run({
		op: "flatten",
		d,
		W,
		H
	});
}
/** Áp bộ lọc trên bộ đệm (giữ nguyên từng phép tính của applyFilter cũ). */
async function applyFilterPx(env, d0, W, H, o) {
	const filter = normalizeFilter(o.filter);
	const preFlat = !!o.preFlat, level = o.level ?? 100;
	let d = d0;
	const n = d.length;
	const keep = level < 100 ? new Uint8ClampedArray(d) : null;
	if (filter === "auto" || filter === "sharp") {
		if (!preFlat) d = await flattenLightPx(env, d, W, H);
		d = await env.run({
			op: "docchain",
			d,
			W,
			H,
			sharp: filter === "sharp",
			deep: true
		});
	} else if (filter === "magic") {
		if (!preFlat) d = await flattenLightPx(env, d, W, H);
		const hist = /* @__PURE__ */ new Uint32Array(256);
		for (let i = 0; i < n; i += 16) hist[d[i] * .3 + d[i + 1] * .59 + d[i + 2] * .11 | 0]++;
		let acc = 0, lo = 0;
		const total = n / 16;
		for (let i = 0; i < 256; i++) {
			acc += hist[i];
			if (acc > total * .005) {
				lo = i;
				break;
			}
		}
		const white = 205;
		const keepSat = edgeSaturatedMask(d, W, H);
		for (let i = 0; i < n; i += 4) {
			const r = d[i], g = d[i + 1], b = d[i + 2];
			const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
			const sat = mx ? (mx - mn) / mx : 0;
			const y = r * .3 + g * .59 + b * .11;
			const t = Math.min(1, Math.max(0, (y - lo) / Math.max(30, white - lo)));
			const ny = 255 * Math.pow(t, 2.3);
			if (sat > .22 && mx - mn > 35 && y < 235) {
				const k = Math.max(ny / Math.max(1, y), keepSat[i >> 2] ? .6 : 0);
				const boost = 1.35;
				for (let ch = 0; ch < 3; ch++) {
					const v = d[i + ch];
					d[i + ch] = Math.min(255, Math.max(0, (y + (v - y) * boost) * k));
				}
			} else d[i] = d[i + 1] = d[i + 2] = ny;
		}
		d = await env.run({
			op: "sharpen",
			d,
			W,
			H,
			amount: 1
		});
	} else if (filter === "shadow") d = await env.run({
		op: "deshadow",
		d,
		W,
		H
	});
	else if (filter === "denoise") d = denoise(d, W, H);
	else if (filter === "gray") {
		if (!preFlat) d = await flattenLightPx(env, d, W, H);
		const keepSat = edgeSaturatedMask(d, W, H);
		d = await env.run({
			op: "gray",
			d,
			W,
			H
		});
		autoLevel(d, 1.7);
		inkDeepen(d, void 0, void 0, keepSat);
		inkDeepen(d, 160, 2.2, keepSat);
		whitenPaper(d);
	} else if (filter === "mono" || filter === "ink") {
		const keepSat = filter === "mono" ? edgeSaturatedMask(d, W, H) : null;
		d = await env.run({
			op: "threshold",
			d,
			W,
			H,
			ink: filter === "ink"
		});
		if (keepSat) {
			for (let i = 0; i < keepSat.length; i++) if (keepSat[i] && d[i * 4] < 110) d[i * 4] = d[i * 4 + 1] = d[i * 4 + 2] = 110;
		}
	} else if (filter === "eco" || filter === "vivid" || filter === "bright") {
		if (filter === "eco" && !preFlat) d = await flattenLightPx(env, d, W, H);
		d = await env.run({
			op: "style",
			d,
			W,
			H,
			mode: filter
		});
	}
	if (hasTools(o.tools)) d = await env.run({
		op: "tools",
		d,
		W,
		H,
		tools: o.tools
	});
	if (o.brightness || o.contrast) d = await env.run({
		op: "tone",
		d,
		W,
		H,
		brightness: o.brightness,
		contrast: o.contrast
	});
	if (keep) {
		const m = Math.max(0, Math.min(100, level)) / 100;
		for (let i = 0; i < d.length; i += 4) {
			d[i] = keep[i] + (d[i] - keep[i]) * m;
			d[i + 1] = keep[i + 1] + (d[i + 1] - keep[i + 1]) * m;
			d[i + 2] = keep[i + 2] + (d[i + 2] - keep[i + 2]) * m;
		}
	}
	return d;
}
/**
* S11r: nắn riêng ô dải 0 lệch nhất. Đo trên ảnh đã nén JPEG (giống ảnh lưu). S15c: đo trước trên bản ≤ 1000 px;
* đa số trang không cần nắn → bỏ vòng nén/giải nén. Sửa thẳng trên canvas `c` (đang chứa ảnh sau bộ lọc).
*/
async function band0FixCanvas(env, c, ctx, log) {
	try {
		const s = Math.min(1, 1e3 / Math.max(c.width, c.height));
		const sw = Math.max(1, Math.round(c.width * s)), sh = Math.max(1, Math.round(c.height * s));
		const [sm, smx] = env.canvas(sw, sh);
		smx.imageSmoothingQuality = "high";
		smx.drawImage(c, 0, 0, sw, sh);
		const sd = smx.getImageData(0, 0, sw, sh).data;
		sm.width = 0;
		const p0 = lineSkewRefineBand0(sd, sw, sh, 3);
		const p1 = lineSkewRefineBand1(p0.data, sw, sh, 2);
		if (p0.passes === 0 && p1.passes === 0) return;
		const blob = await env.jpeg(c, .92);
		if (!blob) return;
		const bmp = await env.bitmap(blob);
		const [t, tctx] = env.canvas(c.width, c.height);
		tctx.drawImage(bmp, 0, 0);
		bmp.close();
		const id = tctx.getImageData(0, 0, c.width, c.height);
		t.width = 0;
		const r = lineSkewRefineBand0(id.data, c.width, c.height, 3);
		const r1 = lineSkewRefineBand1(r.data, c.width, c.height, 2);
		log.push(...r1.log);
		if (r.passes > 0 || r1.passes > 0) {
			id.data.set(r1.data);
			ctx.putImageData(id, 0, 0);
		}
	} catch {}
}
/** Bộ lọc → (nắn dải 0 với Tự động/Nét) → JPEG. `d` thuộc quyền hàm này. */
async function finishPx(env, g, o, log) {
	const [c, ctx] = toCanvas(env, await timed(env, "filter", () => applyFilterPx(env, g.d, g.w, g.h, o)), g.w, g.h);
	if (o.filter === "auto" || o.filter === "sharp") await timed(env, "band0", () => band0FixCanvas(env, c, ctx, log));
	const out = await timed(env, "jpeg", () => env.jpeg(c, o.q));
	c.width = 0;
	return out;
}
var clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
/** Bộ đọc trên một vùng RGBA (ox,oy = vị trí vùng trong ảnh gốc). */
function rgbaSampler(d, w, h, ox = 0, oy = 0) {
	const at = (xx, yy) => {
		const i = (yy * w + xx) * 4;
		return d[i] * .3 + d[i + 1] * .59 + d[i + 2] * .11;
	};
	return (X, Y) => {
		const x = clamp(X - ox, 0, w - 1), y = clamp(Y - oy, 0, h - 1);
		const x0 = Math.floor(x), y0 = Math.floor(y), x1 = Math.min(w - 1, x0 + 1), y1 = Math.min(h - 1, y0 + 1);
		const fx = x - x0, fy = y - y0;
		return (at(x0, y0) * (1 - fx) + at(x1, y0) * fx) * (1 - fy) + (at(x0, y1) * (1 - fx) + at(x1, y1) * fx) * fy;
	};
}
function median(values) {
	if (!values.length) return 0;
	const sorted = [...values].sort((a, b) => a - b);
	const mid = Math.floor(sorted.length / 2);
	return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}
var pointLineDistance = (p, a, b) => {
	const dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy);
	return len ? Math.abs(dy * p[0] - dx * p[1] + b[0] * a[1] - b[1] * a[0]) / len : Infinity;
};
/** Khớp đường thẳng bền vững, thử mọi cặp điểm để kết quả luôn xác định. */
function fitLineRansac(points, threshold = 1.5, minInliers = Math.ceil(points.length * .55)) {
	if (points.length < 3) return null;
	let best = [], bestError = Infinity;
	for (let i = 0; i < points.length - 1; i++) for (let j = i + 1; j < points.length; j++) {
		if (Math.hypot(points[j][0] - points[i][0], points[j][1] - points[i][1]) < 4) continue;
		const inliers = [];
		let error = 0;
		for (let k = 0; k < points.length; k++) {
			const distance = pointLineDistance(points[k], points[i], points[j]);
			if (distance <= threshold) {
				inliers.push(k);
				error += distance * distance;
			}
		}
		if (inliers.length > best.length || inliers.length === best.length && error < bestError) {
			best = inliers;
			bestError = error;
		}
	}
	if (best.length < Math.max(3, minInliers)) return null;
	const selected = best.map((i) => points[i]);
	const cx = selected.reduce((s, p) => s + p[0], 0) / selected.length;
	const cy = selected.reduce((s, p) => s + p[1], 0) / selected.length;
	let xx = 0, xy = 0, yy = 0;
	for (const p of selected) {
		const x = p[0] - cx, y = p[1] - cy;
		xx += x * x;
		xy += x * y;
		yy += y * y;
	}
	const angle = .5 * Math.atan2(2 * xy, xx - yy);
	const normal = [-Math.sin(angle), Math.cos(angle)];
	const offset = normal[0] * cx + normal[1] * cy;
	const rms = Math.sqrt(selected.reduce((s, p) => s + (normal[0] * p[0] + normal[1] * p[1] - offset) ** 2, 0) / selected.length);
	if (!Number.isFinite(rms) || rms > threshold) return null;
	return {
		normal,
		offset,
		inliers: selected.length,
		rms
	};
}
function refineEdge(L, a, b, centre, window) {
	const dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy);
	if (len < 24) return {
		line: null,
		reliable: false,
		start: null,
		end: null
	};
	let nx = -dy / len, ny = dx / len;
	const tx = dx / len, ty = dy / len;
	const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
	if ((centre[0] - mx) * nx + (centre[1] - my) * ny < 0) {
		nx = -nx;
		ny = -ny;
	}
	const lum3 = (x, y) => (L(x - tx, y - ty) + L(x, y) + L(x + tx, y + ty)) / 3;
	const half = Math.max(2, Math.floor(window / 2));
	const points = [], strengths = [], ts = [];
	const samples = Math.max(11, Math.min(41, Math.round(len / 25)));
	for (let s = 0; s < samples; s++) {
		const t = .06 + s / Math.max(1, samples - 1) * .88;
		const px = a[0] + dx * t, py = a[1] + dy * t;
		let best = 0;
		const scores = [];
		for (let off = -half; off <= half; off++) {
			const inside = lum3(px + nx * (off + 2), py + ny * (off + 2));
			const outside = lum3(px + nx * (off - 2), py + ny * (off - 2));
			const strength = Math.abs(inside - outside);
			scores.push({
				offset: off,
				strength
			});
			best = Math.max(best, strength);
		}
		let k = 0;
		for (let j = 1; j < scores.length; j++) if (scores[j].strength > scores[k].strength) k = j;
		for (let j = 0; j < k; j++) {
			const v = scores[j].strength;
			if (v >= Math.max(12, best * .35) && (j === 0 || v >= scores[j - 1].strength) && v >= scores[j + 1].strength) {
				k = j;
				break;
			}
		}
		const peak = scores[k].strength;
		const plateau = scores.filter((p, j) => Math.abs(j - k) <= 2 && p.strength >= peak * .97);
		let bestOffset = plateau.reduce((sum, p) => sum + p.offset, 0) / Math.max(1, plateau.length);
		if (plateau.length === 1 && k > 0 && k < scores.length - 1) {
			const l = scores[k - 1].strength, c = scores[k].strength, r = scores[k + 1].strength, den = l - 2 * c + r;
			if (den < 0) bestOffset = scores[k].offset + clamp(.5 * (l - r) / den, -.5, .5);
		}
		strengths.push(best);
		if (best >= 12) {
			points.push([px + nx * bestOffset, py + ny * bestOffset]);
			ts.push(t);
		}
	}
	const strong = strengths.filter((v) => v >= 12);
	if (strong.length < Math.ceil(samples * .5) || median(strong) < 16) return {
		line: null,
		reliable: false,
		start: null,
		end: null
	};
	const line = fitLineRansac(points, Math.max(1.5, len * .003), Math.ceil(samples * .5));
	const part = (lo, hi) => {
		const sub = points.filter((_, k) => ts[k] >= lo && ts[k] <= hi);
		return sub.length >= 4 ? fitLineRansac(sub, 1.5, Math.ceil(sub.length * .6)) : null;
	};
	return {
		line,
		reliable: Boolean(line),
		start: part(0, .4),
		end: part(.6, 1)
	};
}
function solveCorner(n1, o1, n2, o2) {
	const det = n1[0] * n2[1] - n1[1] * n2[0];
	if (Math.abs(det) < .2) return null;
	return [(o1 * n2[1] - n1[1] * o2) / det, (n1[0] * o2 - o1 * n2[0]) / det];
}
/** Như refineQuadGradient nhưng đọc ảnh qua Sampler (vd chỉ các dải quanh cạnh của ảnh gốc 4096 px). */
function refineQuadSampler(L, W, H, quad, window = 32) {
	if (W < 32 || H < 32) return quad;
	const pts = quad.map(([x, y]) => [x * W, y * H]);
	const centre = [pts.reduce((s, p) => s + p[0], 0) / 4, pts.reduce((s, p) => s + p[1], 0) / 4];
	const edges = [];
	for (let i = 0; i < 4; i++) edges.push(refineEdge(L, pts[i], pts[(i + 1) % 4], centre, window));
	if (edges.filter((e) => e.reliable).length < 3) return quad;
	return pts.map((p, i) => {
		const prev = edges[(i + 3) % 4], next = edges[i];
		const pairs = [[prev.end, next.start], [prev.line, next.line]];
		for (const [a, b] of pairs) {
			if (!a || !b || !prev.reliable || !next.reliable) continue;
			const corner = solveCorner(a.normal, a.offset, b.normal, b.offset);
			if (!corner || Math.hypot(corner[0] - p[0], corner[1] - p[1]) > window) continue;
			return [clamp(corner[0] / W, 0, 1), clamp(corner[1] / H, 0, 1)];
		}
		return [p[0] / W, p[1] / H];
	});
}
/** Hộp bao (px gốc) của dải quanh cạnh i–(i+1), rộng thêm `pad` mỗi phía. */
function edgeStripBox(quad, W, H, i, pad) {
	const a = quad[i], b = quad[(i + 1) % 4];
	const x0 = Math.max(0, Math.floor(Math.min(a[0], b[0]) * W - pad)), y0 = Math.max(0, Math.floor(Math.min(a[1], b[1]) * H - pad));
	const x1 = Math.min(W, Math.ceil(Math.max(a[0], b[0]) * W + pad)), y1 = Math.min(H, Math.ceil(Math.max(a[1], b[1]) * H + pad));
	return {
		x: x0,
		y: y0,
		w: Math.max(1, x1 - x0),
		h: Math.max(1, y1 - y0)
	};
}
/** Ghép bốn dải cạnh thành một Sampler; điểm nằm ngoài mọi dải lấy dải gần nhất (kẹp mép). */
function stripSampler(strips) {
	const s = strips.map((b) => ({
		b,
		f: rgbaSampler(b.data, b.w, b.h, b.x, b.y)
	}));
	let last = s[0];
	return (x, y) => {
		const inside = (b) => x >= b.x && y >= b.y && x <= b.x + b.w - 1 && y <= b.y + b.h - 1;
		if (!inside(last.b)) last = s.find((e) => inside(e.b)) ?? last;
		return last.f(x, y);
	};
}
/**
* Lớp gọi chung: gửi việc điểm ảnh sang pool Web Worker (B7: 2–4 Worker theo navigator.hardwareConcurrency),
* chuyển bộ đệm không sao chép, giao việc cho Worker đang rảnh nhất. Không có Worker hoặc Worker lỗi → chạy luồng chính.
*/
/** Lỗi Worker kèm bộ đệm vào được trả lại (V3: không giữ bản sao dự phòng). */
var WorkerJobError = class extends Error {
	back;
	constructor(msg, back) {
		super(msg);
		this.back = back;
	}
};
/** V3: số đo truyền – số byte sao chép dự phòng (luôn 0) và thời gian postMessage. */
var v3Stats = {
	copiedBytes: 0,
	postMs: 0,
	posts: 0
};
if (typeof globalThis !== "undefined") globalThis.__v3 = v3Stats;
var bufOf = (j) => j.op === "warp" ? j.src : j.d;
/**
* CS-17b: nắn lưới GPU trong Worker (OffscreenCanvas WebGL2) — luồng chính không còn chờ tải kết cấu + readPixels.
* Nguồn = điểm ảnh RGBA đã đọc (bản sao, chuyển quyền). Ảnh gốc trong app là JPEG đã chuẩn hoá (không hồ sơ màu)
* nên trùng byte với tải thẳng từ ảnh (kiểm V3 kiem-cs17b-gpu-trung.mjs).
* Trả null khi không làm được (không Worker/OffscreenCanvas/WebGL2 trong Worker, lỗi) → tầng trên tự chạy luồng chính.
*/
var gpuOff = true;
async function gpuWarpOff(src, W, H, q, ow, oh, curves) {
	if (!gpuOff || typeof OffscreenCanvas === "undefined") return null;
	const copy = new Uint8ClampedArray(src);
	const p = runInPool("gpuwarp", {
		src: copy,
		W,
		H,
		q,
		ow,
		oh,
		curves
	}, [copy.buffer]);
	if (!p) return null;
	try {
		const r = await p;
		if (r.out) return r.out;
		if (r.reason === "no-webgl2" || r.reason === "no-dom") gpuOff = false;
		return null;
	} catch {
		return null;
	}
}
async function runPixels(job) {
	const t0 = performance_default.now();
	const p = runInPool("pixels", { job }, [bufOf(job).buffer]);
	if (!p) return runJob(job);
	v3Stats.postMs += performance_default.now() - t0;
	v3Stats.posts++;
	try {
		const r = await p;
		if (r.out) return r.out;
		throw new WorkerJobError(r.error ?? "worker", r.back);
	} catch (err) {
		const back = err instanceof WorkerJobError ? err.back : void 0;
		if (back) return runJob(job.op === "warp" ? {
			...job,
			src: back
		} : {
			...job,
			d: back
		});
		throw err;
	}
}
/**
* G2-03 — Nắn phối cảnh bằng WebGL (GPU).
* - webglWarpSupport(): kiểm tra máy có WebGL và đủ cỡ texture cho ảnh.
* - webglWarp(): nắn ảnh nguồn theo 4 góc (pixel) ra canvas ow×oh; trả null khi không làm được
*   để nơi gọi rơi về bản CPU (warpPixels). Phép tính homography dùng chung với pixels.ts nên
*   kết quả GPU và CPU trùng khung.
*/
var VS$1 = `attribute vec2 p; void main(){ gl_Position = vec4(p, 0.0, 1.0); }`;
var FS$1 = `precision highp float;
uniform sampler2D t; uniform vec2 src; uniform float oh;
uniform vec3 r0; uniform vec3 r1; uniform vec2 r2;
void main(){
  float x = gl_FragCoord.x - 0.5; float y = oh - gl_FragCoord.y - 0.5;
  float d = r2.x * x + r2.y * y + 1.0;
  float u = (r0.x * x + r0.y * y + r0.z) / d;
  float v = (r1.x * x + r1.y * y + r1.z) / d;
  vec2 uv = clamp((vec2(u, v) + 0.5) / src, vec2(0.0), vec2(1.0));
  gl_FragColor = vec4(texture2D(t, uv).rgb, 1.0);
}`;
var cached = null;
function makeCanvas(w, h) {
	const c = document.createElement("canvas");
	c.width = w;
	c.height = h;
	return c;
}
function getGL(c) {
	const opts = {
		preserveDrawingBuffer: true,
		premultipliedAlpha: false,
		antialias: false
	};
	return c.getContext("webgl", opts) || c.getContext("experimental-webgl", opts);
}
/** Kiểm tra máy hỗ trợ (lưu kết quả). Truyền W,H để biết ảnh có vừa giới hạn texture không. */
function webglWarpSupport(W = 0, H = 0) {
	if (!cached) try {
		if (typeof document === "undefined") cached = {
			ok: false,
			maxTex: 0,
			reason: "no-dom"
		};
		else {
			const gl = getGL(makeCanvas(1, 1));
			if (!gl) cached = {
				ok: false,
				maxTex: 0,
				reason: "no-webgl"
			};
			else {
				const maxTex = gl.getParameter(gl.MAX_TEXTURE_SIZE);
				cached = maxTex >= 2048 ? {
					ok: true,
					maxTex
				} : {
					ok: false,
					maxTex,
					reason: "small-texture"
				};
				gl.getExtension("WEBGL_lose_context")?.loseContext();
			}
		}
	} catch {
		cached = {
			ok: false,
			maxTex: 0,
			reason: "error"
		};
	}
	const s = cached;
	if (s.ok && Math.max(W, H) > s.maxTex) return {
		maxTex: s.maxTex,
		ok: false,
		reason: "too-large"
	};
	return s;
}
function compile(gl, type, src) {
	const s = gl.createShader(type);
	gl.shaderSource(s, src);
	gl.compileShader(s);
	if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) || "shader");
	return s;
}
/** Nắn phối cảnh trên GPU. Trả canvas 2D ow×oh hoặc null nếu không hỗ trợ / lỗi. */
function webglWarp(img, W, H, q, ow, oh) {
	const sup = webglWarpSupport(W, H);
	if (!sup.ok || ow > sup.maxTex || oh > sup.maxTex) return null;
	const glc = makeCanvas(ow, oh);
	const gl = getGL(glc);
	if (!gl) return null;
	try {
		const prog = gl.createProgram();
		gl.attachShader(prog, compile(gl, gl.VERTEX_SHADER, VS$1));
		gl.attachShader(prog, compile(gl, gl.FRAGMENT_SHADER, FS$1));
		gl.linkProgram(prog);
		if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return null;
		gl.useProgram(prog);
		const buf = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, buf);
		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
			-1,
			-1,
			1,
			-1,
			-1,
			1,
			1,
			1
		]), gl.STATIC_DRAW);
		const loc = gl.getAttribLocation(prog, "p");
		gl.enableVertexAttribArray(loc);
		gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
		const tex = gl.createTexture();
		gl.bindTexture(gl.TEXTURE_2D, tex);
		gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
		gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);
		const h = homography([
			[0, 0],
			[ow, 0],
			[ow, oh],
			[0, oh]
		], q);
		const u = (n) => gl.getUniformLocation(prog, n);
		gl.uniform1i(u("t"), 0);
		gl.uniform2f(u("src"), W, H);
		gl.uniform1f(u("oh"), oh);
		gl.uniform3f(u("r0"), h[0], h[1], h[2]);
		gl.uniform3f(u("r1"), h[3], h[4], h[5]);
		gl.uniform2f(u("r2"), h[6], h[7]);
		gl.viewport(0, 0, ow, oh);
		gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
		if (gl.getError() !== gl.NO_ERROR) return null;
		const out = makeCanvas(ow, oh);
		out.getContext("2d").drawImage(glc, 0, 0);
		return out;
	} catch {
		return null;
	} finally {
		gl.getExtension("WEBGL_lose_context")?.loseContext();
		glc.width = glc.height = 0;
	}
}
/**
* B7 – Nắn giấy (phẳng lẫn cong) trên GPU bằng lưới ánh xạ.
* - buildWarpMesh: lấy mẫu makeSrcMap mỗi `step` px đích → lưới toạ độ nguồn (Float32, RG). Thuần, có kiểm thử.
* - gpuWarpMesh: WebGL2; lưới lưu thành texture RG32F, shader nội suy song tuyến trong lưới rồi lấy mẫu
*   bicubic Catmull-Rom (16 texelFetch) trên ảnh nguồn – cùng công thức với warpCurved (CPU dự phòng).
*   Trả null khi máy không có WebGL2 / texture quá lớn / lỗi → gọi nơi khác chạy CPU.
*/
function buildWarpMesh(q, ow, oh, curves = [], step = 8) {
	const map = makeSrcMap(q, ow, oh, curves);
	const nx = Math.ceil((ow - 1) / step) + 2, ny = Math.ceil((oh - 1) / step) + 2;
	const data = new Float32Array(nx * ny * 2);
	for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
		const [sx, sy] = map(i * step, j * step);
		const k = (j * nx + i) * 2;
		data[k] = sx;
		data[k + 1] = sy;
	}
	return {
		nx,
		ny,
		step,
		data
	};
}
var VS = `#version 300 es
in vec2 p; void main(){ gl_Position = vec4(p, 0.0, 1.0); }`;
var FS = `#version 300 es
precision highp float; precision highp int;
uniform sampler2D img; uniform highp sampler2D mesh;
uniform vec2 src; uniform float step;
out vec4 o;
vec4 cr(vec4 p0, vec4 p1, vec4 p2, vec4 p3, float t){
  return p1 + 0.5*t*(p2 - p0 + t*(2.0*p0 - 5.0*p1 + 4.0*p2 - p3 + t*(3.0*(p1 - p2) + p3 - p0)));
}
vec4 px(int x, int y){ ivec2 m = ivec2(src) - 1; return texelFetch(img, clamp(ivec2(x, y), ivec2(0), m), 0); }
void main(){
  vec2 xy = floor(gl_FragCoord.xy);            // hàng 0 của khung = hàng 0 ảnh đích (readPixels đọc từ dưới)
  vec2 g = xy / step; ivec2 i = ivec2(floor(g)); vec2 f = g - vec2(i);
  vec2 a = texelFetch(mesh, i, 0).xy, b = texelFetch(mesh, i + ivec2(1,0), 0).xy;
  vec2 c = texelFetch(mesh, i + ivec2(0,1), 0).xy, d = texelFetch(mesh, i + ivec2(1,1), 0).xy;
  vec2 s = mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
  s = clamp(s, vec2(0.0), src - 1.001);
  ivec2 s0 = ivec2(floor(s)); vec2 t = s - vec2(s0);
  vec4 r[4];
  for (int k = 0; k < 4; k++) {
    int yy = s0.y - 1 + k;
    r[k] = cr(px(s0.x-1,yy), px(s0.x,yy), px(s0.x+1,yy), px(s0.x+2,yy), t.x);
  }
  vec4 v = cr(r[0], r[1], r[2], r[3], t.y);
  o = vec4(clamp(v.rgb, 0.0, 1.0), 1.0);
}`;
var gpuWarpStats = { ok: false };
function sh(gl, type, s) {
	const o = gl.createShader(type);
	gl.shaderSource(o, s);
	gl.compileShader(o);
	if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o) || "shader");
	return o;
}
/** Nắn bằng lưới ánh xạ trên GPU. Trả RGBA ow×oh (hàng trên cùng trước) hoặc null. */
function gpuWarpMesh(img, W, H, q, ow, oh, curves = []) {
	if (typeof document === "undefined" && typeof OffscreenCanvas === "undefined") {
		gpuWarpStats.ok = false;
		gpuWarpStats.reason = "no-dom";
		return null;
	}
	const t0 = performance_default.now();
	const cv = typeof document !== "undefined" ? document.createElement("canvas") : new OffscreenCanvas(ow, oh);
	cv.width = ow;
	cv.height = oh;
	let gl = null;
	try {
		gl = cv.getContext("webgl2", {
			preserveDrawingBuffer: true,
			antialias: false,
			premultipliedAlpha: false
		});
	} catch {
		gl = null;
	}
	if (!gl) {
		gpuWarpStats.ok = false;
		gpuWarpStats.reason = "no-webgl2";
		return null;
	}
	try {
		const max = gl.getParameter(gl.MAX_TEXTURE_SIZE);
		if (Math.max(W, H, ow, oh) > max) {
			gpuWarpStats.ok = false;
			gpuWarpStats.reason = "too-large";
			return null;
		}
		const prog = gl.createProgram();
		gl.attachShader(prog, sh(gl, gl.VERTEX_SHADER, VS));
		gl.attachShader(prog, sh(gl, gl.FRAGMENT_SHADER, FS));
		gl.linkProgram(prog);
		if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error("link");
		gl.useProgram(prog);
		const buf = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, buf);
		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
			-1,
			-1,
			1,
			-1,
			-1,
			1,
			1,
			1
		]), gl.STATIC_DRAW);
		const loc = gl.getAttribLocation(prog, "p");
		gl.enableVertexAttribArray(loc);
		gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
		const tex = (unit) => {
			const t = gl.createTexture();
			gl.activeTexture(gl.TEXTURE0 + unit);
			gl.bindTexture(gl.TEXTURE_2D, t);
			for (const [k, v] of [
				[gl.TEXTURE_MIN_FILTER, gl.NEAREST],
				[gl.TEXTURE_MAG_FILTER, gl.NEAREST],
				[gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE],
				[gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE]
			]) gl.texParameteri(gl.TEXTURE_2D, k, v);
		};
		tex(0);
		gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
		gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
		gl.pixelStorei(gl.UNPACK_COLORSPACE_CONVERSION_WEBGL, gl.NONE);
		if (img instanceof Uint8ClampedArray) gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, W, H, 0, gl.RGBA, gl.UNSIGNED_BYTE, img);
		else gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, gl.RGBA, gl.UNSIGNED_BYTE, img);
		const m = buildWarpMesh(q, ow, oh, curves);
		tex(1);
		gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
		gl.texImage2D(gl.TEXTURE_2D, 0, gl.RG32F, m.nx, m.ny, 0, gl.RG, gl.FLOAT, m.data);
		const u = (n) => gl.getUniformLocation(prog, n);
		gl.uniform1i(u("img"), 0);
		gl.uniform1i(u("mesh"), 1);
		gl.uniform2f(u("src"), W, H);
		gl.uniform1f(u("step"), m.step);
		gl.viewport(0, 0, ow, oh);
		gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
		const out = new Uint8ClampedArray(ow * oh * 4);
		gl.readPixels(0, 0, ow, oh, gl.RGBA, gl.UNSIGNED_BYTE, out);
		if (gl.getError() !== gl.NO_ERROR) throw new Error("gl");
		gpuWarpStats.ok = true;
		gpuWarpStats.reason = void 0;
		gpuWarpStats.ms = Math.round(performance_default.now() - t0);
		return out;
	} catch (e) {
		gpuWarpStats.ok = false;
		gpuWarpStats.reason = String(e?.message ?? e).slice(0, 80);
		return null;
	} finally {
		gl.getExtension("WEBGL_lose_context")?.loseContext();
		cv.width = cv.height = 0;
	}
}
/** Cỡ ảnh xám của estimateSkew: cạnh dài ≤ 600. */
function skewSize(cw, ch) {
	const s = Math.min(1, 600 / Math.max(cw, ch));
	return {
		w: Math.max(8, Math.round(cw * s)),
		h: Math.max(8, Math.round(ch * s))
	};
}
/** Cỡ ảnh xám của sharpness: cạnh dài 480. */
function sharpSize(sw, sh) {
	const s = 480 / Math.max(sw, sh);
	return {
		w: Math.max(8, Math.round(sw * s)),
		h: Math.max(8, Math.round(sh * s))
	};
}
function otsu(g) {
	const hist = new Array(256).fill(0);
	for (const v of g) hist[v | 0]++;
	const total = g.length;
	let sum = 0;
	for (let i = 0; i < 256; i++) sum += i * hist[i];
	let sumB = 0, wB = 0, best = 0, t = 127;
	for (let i = 0; i < 256; i++) {
		wB += hist[i];
		if (!wB) continue;
		const wF = total - wB;
		if (!wF) break;
		sumB += i * hist[i];
		const mB = sumB / wB, mF = (sum - sumB) / wF;
		const between = wB * wF * (mB - mF) ** 2;
		if (between > best) {
			best = between;
			t = i;
		}
	}
	return t;
}
/** Độ nghiêng chữ nhỏ (±5°) theo độ nét hình chiếu hàng — thân estimateSkew sau bước xám. */
function skewFromGray(g, w, h) {
	const t = otsu(g);
	const ink = [];
	const mx = Math.round(w * .05), my = Math.round(h * .05);
	for (let y = my; y < h - my; y++) for (let x = mx; x < w - mx; x++) if (g[y * w + x] < t - 10) ink.push(x, y);
	if (ink.length < 400 || ink.length / 2 > w * h * .35) return 0;
	const score = (deg) => {
		const a = deg * Math.PI / 180, tn = Math.tan(a);
		const rows = new Float64Array(h * 2);
		for (let i = 0; i < ink.length; i += 2) {
			const r = Math.round(ink[i + 1] - (ink[i] - w / 2) * tn) + h / 2;
			if (r >= 0 && r < rows.length) rows[r]++;
		}
		let v = 0;
		for (let i = 1; i < rows.length; i++) v += (rows[i] - rows[i - 1]) ** 2;
		return v;
	};
	let best = 0, bs = score(0);
	for (let d = -5; d <= 5; d += .5) {
		const v = score(d);
		if (v > bs) {
			bs = v;
			best = d;
		}
	}
	const c0 = best;
	for (let d = c0 - .4; d <= c0 + .4; d += .1) {
		const v = score(d);
		if (v > bs) {
			bs = v;
			best = d;
		}
	}
	return Math.abs(best) < .25 || bs < score(0) * 1.05 ? 0 : best;
}
/** Phương sai Laplace (độ nét) — thân sharpness sau bước xám. */
function lapVarGray(g, w, h, quad) {
	let x0 = 1, y0 = 1, x1 = w - 1, y1 = h - 1;
	if (quad) {
		const xs = quad.map((p) => p[0] * w), ys = quad.map((p) => p[1] * h);
		x0 = Math.max(1, Math.round(Math.min(...xs) + w * .03));
		x1 = Math.min(w - 1, Math.round(Math.max(...xs) - w * .03));
		y0 = Math.max(1, Math.round(Math.min(...ys) + h * .03));
		y1 = Math.min(h - 1, Math.round(Math.max(...ys) - h * .03));
	}
	let sum = 0, sq = 0, n = 0;
	for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
		const i = y * w + x;
		const l = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w];
		sum += l;
		sq += l * l;
		n++;
	}
	return n ? sq / n - (sum / n) ** 2 : 0;
}
/** LRU nhỏ: giữ tối đa `max` mục, gọi `onEvict` khi đẩy ra (để giải phóng canvas / object URL).
* S15f: tuỳ chọn `sizeOf` + `maxBytes` – đẩy mục cũ nhất ra khi tổng dung lượng vượt trần (luôn giữ mục mới nhất). */
var Lru = class {
	max;
	onEvict;
	sizeOf;
	maxBytes;
	m = /* @__PURE__ */ new Map();
	sz = /* @__PURE__ */ new Map();
	total = 0;
	constructor(max, onEvict, sizeOf, maxBytes = Infinity) {
		this.max = max;
		this.onEvict = onEvict;
		this.sizeOf = sizeOf;
		this.maxBytes = maxBytes;
	}
	get size() {
		return this.m.size;
	}
	get bytes() {
		return this.total;
	}
	get(k) {
		const v = this.m.get(k);
		if (v !== void 0) {
			this.m.delete(k);
			this.m.set(k, v);
		}
		return v;
	}
	drop(k) {
		this.total -= this.sz.get(k) ?? 0;
		this.sz.delete(k);
		this.m.delete(k);
	}
	set(k, v) {
		const old = this.m.get(k);
		if (old !== void 0) {
			this.drop(k);
			if (old !== v) this.onEvict?.(old, k);
		}
		this.m.set(k, v);
		const b = this.sizeOf ? Math.max(0, this.sizeOf(v)) : 0;
		this.sz.set(k, b);
		this.total += b;
		while (this.m.size > this.max || this.total > this.maxBytes && this.m.size > 1) {
			const [fk, fv] = this.m.entries().next().value;
			this.drop(fk);
			this.onEvict?.(fv, fk);
		}
	}
	/** CS-17d: bỏ một mục (không gọi onEvict — dùng khi giá trị đã mất, vd bộ đệm cho Worker mượn bị mất). */
	delete(k) {
		if (this.m.has(k)) this.drop(k);
	}
	clear() {
		for (const [k, v] of this.m) this.onEvict?.(v, k);
		this.m.clear();
		this.sz.clear();
		this.total = 0;
	}
};
var MB = 1048576;
/** Hàng đợi giới hạn số việc chạy cùng lúc (vd tối đa 2 ảnh 4096 px giải mã đồng thời). */
function limiter(n) {
	let active = 0;
	let peak = 0;
	const waiting = [];
	const run = async (fn) => {
		if (active >= n) await new Promise((r) => waiting.push(r));
		active++;
		peak = Math.max(peak, active);
		try {
			return await fn();
		} finally {
			active--;
			waiting.shift()?.();
		}
	};
	return Object.assign(run, {
		stats: () => ({
			active,
			peak,
			waiting: waiting.length
		}),
		resetPeak: () => {
			peak = active;
		}
	});
}
/** Khoá nhanh cho chuỗi ảnh rất dài (data URL nhiều MB): độ dài + FNV-1a trên ~4096 ký tự lấy mẫu đều. */
function srcKey(s) {
	let h = 2166136261;
	const step = Math.max(1, Math.floor(s.length / 4096));
	for (let i = 0; i < s.length; i += step) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	for (let i = Math.max(0, s.length - 64); i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return `${s.length.toString(36)}-${(h >>> 0).toString(36)}`;
}
/** Khoá phần hình học (nắn/cắt/xoay) — đổi bộ lọc không làm đổi khoá này. */
function geoKey(src, e, max) {
	const q = e.quad ? e.quad.map((p) => p.map((v) => v.toFixed(5)).join(",")).join(";") : "-";
	return `${srcKey(src)}|${q}|${e.paper ?? "auto"}|${(e.rotation % 360 + 360) % 360}|${e.flatten ?? "auto"}|${max}`;
}
/** Khoá kết quả cuối = hình học + bộ lọc + độ sáng + tương phản. */
function resultKey(src, e, max) {
	return `${geoKey(src, e, max)}|${e.filter}|${e.brightness}|${e.contrast}|${[
		"clarify",
		"whiten",
		"corners"
	].map((k) => e.tools?.[k] ?? 0).join("")}|${e.level ?? 100}`;
}
/** Tầng xem trước (cạnh dài) — chỉ dựng 3508 px khi lưu/xuất. */
var PREVIEW_LONG = 1200;
var image_exports = /* @__PURE__ */ __exportAll$1({
	TARGET_LONG: () => TARGET_LONG,
	composeIdCard: () => composeIdCard,
	compress: () => compress,
	countObjects: () => countObjects,
	dataUrlToBlob: () => dataUrlToBlob,
	detectQuadFromSrc: () => detectQuadFromSrc,
	detectQuadInfo: () => detectQuadInfo,
	detectQuadScoredAsync: () => detectQuadScoredAsync,
	enhanceForOcr: () => enhanceForOcr,
	estimateSkew: () => estimateSkew,
	fileToDataUrl: () => fileToDataUrl,
	glare: () => glare,
	grayscale: () => grayscale,
	lastThumbs: () => lastThumbs,
	loadImg: () => loadImg,
	normalize: () => normalize,
	normalizeBlob: () => normalizeBlob,
	normalizeUrl: () => normalizeUrl,
	quickStats: () => quickStats,
	refineQuadOnSrc: () => refineQuadOnSrc,
	releaseRenderCache: () => releaseRenderCache,
	renderExport: () => renderExport,
	renderPage: () => renderPage,
	renderPageUrl: () => renderPageUrl,
	renderPreview: () => renderPreview,
	renderQuickUrl: () => renderQuickUrl,
	sharpness: () => sharpness,
	splitBook: () => splitBook,
	stamp: () => stamp,
	targetLong: () => targetLong,
	tilt: () => tilt,
	toJpeg: () => toJpeg,
	toJpegAsync: () => toJpegAsync,
	toJpegBlob: () => toJpegBlob,
	v4Stats: () => v4Stats,
	warpStats: () => warpStats,
	yieldTask: () => yieldTask
});
/** Đo tốc độ nắn gần nhất (G2-04): "gpu" | "cpu" và số ms. */
var warpStats = {
	engine: "",
	ms: 0
};
function loadImg(src) {
	const url = typeof src === "string" ? src : URL.createObjectURL(src);
	return new Promise((resolve, reject) => {
		const img = new Image();
		const done = () => {
			if (typeof src !== "string") URL.revokeObjectURL(url);
		};
		img.onload = () => {
			const ok = () => {
				done();
				resolve(img);
			};
			if (typeof img.decode === "function") img.decode().then(ok, ok);
			else ok();
		};
		img.onerror = (e) => {
			done();
			reject(e);
		};
		img.src = url;
	});
}
/** CS-17d: nhường luồng chính một nhịp (tác vụ mới) — tách các bước vẽ/đo nối tiếp để mỗi tác vụ < 50 ms. */
var yieldTask = () => new Promise((r) => setTimeout(r, 0));
function fileToDataUrl(file) {
	return new Promise((resolve, reject) => {
		const r = new FileReader();
		r.onload = () => resolve(r.result);
		r.onerror = reject;
		r.readAsDataURL(file);
	});
}
function canvas(w, h) {
	const c = document.createElement("canvas");
	c.width = Math.max(1, Math.round(w));
	c.height = Math.max(1, Math.round(h));
	return [c, c.getContext("2d", { willReadFrequently: true })];
}
function toJpeg(c, q = .92) {
	return c.toDataURL("image/jpeg", q);
}
/** S4: nén JPEG thành Blob ngoài luồng chính; rơi về chuyển từ toDataURL khi thiếu toBlob. */
function toJpegBlob(c, q = .92) {
	if (typeof c.toBlob !== "function") return Promise.resolve(dataUrlToBlob(toJpeg(c, q)));
	return new Promise((res) => c.toBlob((b) => res(b ?? dataUrlToBlob(toJpeg(c, q))), "image/jpeg", q));
}
/** S3: nén JPEG không chặn luồng chính – toBlob mã hoá ngoài luồng chính, rơi về toDataURL khi thiếu. */
function toJpegAsync(c, q = .92) {
	if (typeof c.toBlob !== "function") return Promise.resolve(toJpeg(c, q));
	return new Promise((res) => c.toBlob((b) => b ? fileToDataUrl(b).then(res, () => res(toJpeg(c, q))) : res(toJpeg(c, q)), "image/jpeg", q));
}
async function drawNormalized(src, max) {
	const img = typeof src === "string" ? await loadImg(src.startsWith("data:") ? dataUrlToBlob(src) : src) : src instanceof Blob ? await loadImg(src) : src;
	const w = img.naturalWidth || img.videoWidth || img.width;
	const h = img.naturalHeight || img.videoHeight || img.height;
	const s = Math.min(1, max / Math.max(w, h));
	const [c, ctx] = canvas(w * s, h * s);
	ctx.drawImage(img, 0, 0, c.width, c.height);
	return c;
}
/** B07: ảnh thu nhỏ mới nhất từ page-pipeline (khoá = Blob nguồn), để lưới trang dùng ngay. */
var lastThumbs = /* @__PURE__ */ new WeakMap();
/** S5d/B07: Blob → Worker (giải mã/thu nhỏ/nén ngoài luồng chính); lỗi hoặc không hỗ trợ → null.
*  B07: ưu tiên page-pipeline — một lượt nền duy nhất cho cả ảnh chính lẫn ảnh thu nhỏ. */
async function viaWorker(src, max, q) {
	if (!(src instanceof Blob)) return null;
	try {
		const { processPageInWorker } = await import("./page-pipeline-Cc7vjYNG.mjs");
		const pp = processPageInWorker(await createImageBitmap(src), {
			max,
			q,
			thumbMax: 512
		});
		if (pp) try {
			const r = await pp;
			lastThumbs.set(src, r.thumb);
			return r.main;
		} catch {}
	} catch {}
	const p = normalizeInWorker(src, max, q);
	if (!p) return null;
	try {
		return await p;
	} catch {
		return null;
	}
}
/** Downscale any image source to a max dimension and return a jpeg data URL. */
async function normalize(src, max = 2e3, q = .9) {
	const wb = await viaWorker(src, max, q);
	if (wb) return fileToDataUrl(wb);
	const c = await drawNormalized(src, max);
	const out = await toJpegAsync(c, q);
	c.width = 0;
	return out;
}
/** S4: như normalize nhưng trả Blob – không tạo chuỗi base64 (giảm RAM, nhanh hơn). */
async function normalizeBlob(src, max = 2e3, q = .9) {
	const wb = await viaWorker(src, max, q);
	if (wb) return wb;
	const c = await drawNormalized(src, max);
	const out = await toJpegBlob(c, q);
	c.width = 0;
	return out;
}
/** Đo tốc độ nắn gần nhất — ghi từ số đo Worker hoặc luồng chính. */
function recordWarps(perf) {
	for (const p of perf) {
		warpStats.engine = p.engine;
		warpStats.ms = p.ms;
		recordPerf(p.engine === "gpu" ? "warp-gpu" : "warp-cpu", p.ms);
	}
}
/** V4: số lần đọc toàn ảnh gốc (getImageData W×H) — đích 1 lần/trang. */
var v4Stats = { fullReads: 0 };
if (typeof globalThis !== "undefined") globalThis.__v4 = v4Stats;
/** V4: đọc điểm ảnh gốc một lần; straightWarpPx dùng lại cho cả bản dò lẫn bản chính. */
function readSrc(img) {
	const W = img.naturalWidth, H = img.naturalHeight;
	const [sc, sctx] = canvas(W, H);
	sctx.drawImage(img, 0, 0);
	const d = sctx.getImageData(0, 0, W, H).data;
	sc.width = 0;
	v4Stats.fullReads++;
	return d;
}
/**
* CS-17d: môi trường luồng chính cho render-core — chỉ dùng khi Worker không dựng được (thiếu Worker/OffscreenCanvas,
* Worker không có WebGL2, lỗi). Thứ tự nắn giữ như CS-17b: GPU trong Worker → GPU luồng chính → GPU cũ (phẳng) → CPU trong Worker.
*/
function mainEnv(img) {
	return {
		canvas,
		run: runPixels,
		async warp(sd, W, H, q, ow, oh, curves, keep) {
			if (!img) throw new Error("warp: thiếu ảnh gốc");
			const curved = curves.some(Boolean);
			let od = await gpuWarpOff(sd, W, H, q, ow, oh, curves) ?? gpuWarpMesh(img, W, H, q, ow, oh, curves);
			let engine = od ? "gpu" : "cpu";
			if (!od && !curved) {
				const gpu = webglWarp(img, W, H, q, ow, oh);
				if (gpu) {
					od = new Uint8ClampedArray(gpu.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, ow, oh).data);
					gpu.width = 0;
					engine = "gpu";
				}
			}
			if (!od) od = await runPixels({
				op: "warp",
				src: keep ? new Uint8ClampedArray(sd) : sd,
				W,
				H,
				q,
				ow,
				oh,
				curves
			});
			return {
				od,
				engine
			};
		},
		jpeg: (c, q) => new Promise((res) => c.toBlob(res, "image/jpeg", q)),
		bitmap: (b) => createImageBitmap(b),
		mark: pushV0
	};
}
/**
* CS-17d: việc dựng trong Worker của bể ("render": geo / flat / fin) — luồng chính chỉ gửi bộ đệm (chuyển quyền) và nhận kết quả.
* null = không làm được → tầng trên chạy render-core ở luồng chính (cùng phép tính, trùng byte).
*/
var offOk = true;
var offGeo = true;
async function offRun(payload, transfer = [], onBack) {
	if (!offOk || !poolCanvasSupported()) return null;
	const p = runInPool("render", payload, transfer);
	if (!p) return null;
	const r = await p.catch((e) => ({
		...e,
		failed: true
	}));
	if (r.back) onBack?.(r.back);
	for (const [step, ms] of r.t ?? []) pushV0(step, ms);
	if (r.fallback === "no-canvas") offOk = false;
	if (r.fallback === "no-webgl2" || r.fallback === "no-dom") offGeo = false;
	return r.fallback || r.failed ? null : r;
}
/** Bản sao để chuyển quyền sang Worker (bản trong bộ đệm giữ nguyên) — chỉ dùng cho ảnh nhỏ và đường dự phòng luồng chính. */
var copyImg = (g) => ({
	d: g.d.slice(),
	w: g.w,
	h: g.h
});
var LEND_MIN = 8 * MB;
/**
* CS-17d: gửi ảnh trong bộ đệm cho Worker. Ảnh lớn: CHO MƯỢN (chuyển quyền, Worker tự sao chép rồi trả lại) — luồng chính
* không sao chép 35 MB (đo: copyImg ~60 ms/lần là long task). Mỗi ảnh một lượt mượn tại một thời điểm. Ảnh nhỏ: sao chép.
*/
function sendImg(g, payload) {
	if (g.d.byteLength < LEND_MIN && !g.lock) {
		const c = copyImg(g);
		return offRun({
			...payload,
			d: c.d,
			w: c.w,
			h: c.h
		}, [c.d.buffer]);
	}
	const run = (g.lock ?? Promise.resolve()).catch(() => {}).then(async () => {
		if (g.lost) return null;
		const d = g.d;
		const r = await offRun({
			...payload,
			d,
			w: g.w,
			h: g.h,
			lend: true
		}, [d.buffer], (b) => {
			g.d = b;
		});
		if (!g.d.byteLength) g.lost = true;
		return r;
	});
	g.lock = run;
	return run;
}
/** Estimate small text tilt (±5°) via row projection-profile sharpness. */
function estimateSkew(c) {
	const { w, h } = skewSize(c.width, c.height);
	return skewFromGray(grayscale(c, w, h), w, h);
}
/** Rotate away small tilt; fills exposed corners with edge-matching paper colour by slight zoom. Chạy trong Worker. */
async function deskew(c) {
	const ctx = c.getContext("2d", { willReadFrequently: true });
	const im = ctx.getImageData(0, 0, c.width, c.height);
	const out = await runPixels({
		op: "deskew",
		d: new Uint8ClampedArray(im.data),
		W: c.width,
		H: c.height
	});
	im.data.set(out);
	ctx.putImageData(im, 0, 0);
	return c;
}
/** B1: cạnh dài đích (px) theo chất lượng: Nét nhất = A4 300 dpi, Cân bằng = A4 200 dpi. */
var TARGET_LONG = {
	high: 3508,
	normal: 2339
};
function targetLong(quality = "high") {
	return TARGET_LONG[quality] ?? TARGET_LONG.high;
}
var decodeGate = limiter(2);
var inUse = /* @__PURE__ */ new Map();
var freeLater = /* @__PURE__ */ new Map();
var decoded = new Lru(2, (v) => {
	const free = () => {
		if (v.url) URL.revokeObjectURL(v.url);
		v.img.src = "";
	};
	if (inUse.has(v.img)) freeLater.set(v.img, free);
	else free();
}, (v) => v.img.naturalWidth * v.img.naturalHeight * 4, 128 * MB);
/** Phần hình học đã dựng (nắn → thẳng → làm sạch mép → xoay), dùng lại khi chỉ đổi bộ lọc. */
var geoCache = new Lru(8, () => {}, (g) => g.d.byteLength, 160 * MB);
/** Kết quả cuối theo (ảnh, hình học, bộ lọc, sáng, tương phản). */
var resultCache = new Lru(24, (u) => {
	if (u.startsWith("blob:")) URL.revokeObjectURL(u);
});
var inflight = /* @__PURE__ */ new Map();
function once(k, fn) {
	const p = inflight.get(k);
	if (p) return p;
	const q = fn().finally(() => inflight.delete(k));
	inflight.set(k, q);
	return q;
}
function dataUrlToBlob(u) {
	const i = u.indexOf(",");
	const meta = u.slice(5, i);
	const raw = meta.endsWith(";base64") ? atob(u.slice(i + 1)) : decodeURIComponent(u.slice(i + 1));
	const a = new Uint8Array(raw.length);
	for (let k = 0; k < raw.length; k++) a[k] = raw.charCodeAt(k);
	return new Blob([a], { type: meta.replace(";base64", "") || "image/jpeg" });
}
async function decodeOrig(orig) {
	const k = srcKey(orig);
	const hit = decoded.get(k);
	if (hit) return hit.img;
	return once("d:" + k, () => decodeGate(async () => {
		const url = orig.startsWith("data:") ? URL.createObjectURL(dataUrlToBlob(orig)) : null;
		const img = await loadImg(url ?? orig);
		try {
			await img.decode?.();
		} catch {}
		decoded.set(k, {
			img,
			url
		});
		return img;
	}));
}
/** Dùng ảnh gốc đã giải mã trong suốt `fn` (kể cả qua các await) — không bị giải phóng giữa chừng khi bộ đệm đẩy ra. */
async function withDecoded(orig, fn, step) {
	let img = await (step ? v0(step, () => decodeOrig(orig)) : decodeOrig(orig));
	for (let i = 0; i < 3 && !img.naturalWidth; i++) img = await decodeOrig(orig);
	inUse.set(img, (inUse.get(img) ?? 0) + 1);
	try {
		return await fn(img);
	} finally {
		const n = (inUse.get(img) ?? 1) - 1;
		if (n > 0) inUse.set(img, n);
		else {
			inUse.delete(img);
			const free = freeLater.get(img);
			if (free) {
				freeLater.delete(img);
				free();
			}
		}
	}
}
/** Giải phóng toàn bộ ảnh giải mã + bộ đệm (gọi khi rời màn hình chỉnh/chụp). */
function releaseRenderCache() {
	decoded.clear();
	geoCache.clear();
	resultCache.clear();
}
/** V0: ghi thời gian từng bước dựng trang vào globalThis.__v0 (chỉ số đo, không ảnh hưởng ảnh ra). */
function pushV0(step, ms) {
	const g = globalThis;
	(g.__v0 ??= []).push({
		step,
		ms
	});
}
async function v0(step, fn) {
	const t0 = performance_default.now();
	try {
		return await fn();
	} finally {
		pushV0(step, Math.round(performance_default.now() - t0));
	}
}
/** Hình học ở luồng chính (dự phòng CS-17d): nắn → thẳng → làm sạch mép, hoặc thu nhỏ khi không có khung. */
async function geoMain(img, edit, max) {
	const env = mainEnv(img), perf = [];
	let g;
	if (edit.quad) {
		const sd = readSrc(img);
		g = await v0("warp", () => straightWarpPx(env, sd, img.naturalWidth, img.naturalHeight, edit.quad, max, edit.paper, edit.flatten, perf));
		g = await v0("edge-clean", () => cleanEdgesPx(env, g));
	} else {
		const s = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
		const [cc, ctx] = canvas(img.naturalWidth * s, img.naturalHeight * s);
		ctx.drawImage(img, 0, 0, cc.width, cc.height);
		g = {
			d: ctx.getImageData(0, 0, cc.width, cc.height).data,
			w: cc.width,
			h: cc.height
		};
		cc.width = 0;
	}
	recordWarps(perf);
	return rotatePx(env, g, edit.rotation);
}
/** CS-17d: hình học trong Worker — Worker tự tải ảnh gốc (fetch + createImageBitmap), luồng chính không giải mã/đọc điểm ảnh. */
async function geoOff(orig, edit, max) {
	if (!offGeo || !edit.quad) return null;
	const r = await offRun({
		op: "geo",
		src: orig,
		quad: edit.quad ?? null,
		max,
		paper: edit.paper ?? "auto",
		flatten: edit.flatten,
		rotation: edit.rotation
	});
	if (!r) return null;
	v4Stats.fullReads += r.reads;
	recordWarps(r.perf);
	return {
		d: r.out,
		w: r.w,
		h: r.h
	};
}
async function renderGeometry(orig, edit, max) {
	const k = geoKey(orig, edit, max);
	const hit = geoCache.get(k);
	if (hit && !hit.lost) return hit;
	return once("g:" + k, async () => {
		const g = await v0("geo", () => geoOff(orig, edit, max)) ?? await withDecoded(orig, (img) => geoMain(img, edit, max), "decode");
		geoCache.set(k, g);
		return g;
	});
}
/** Lớp đã chuẩn hoá ánh sáng (dùng chung cho Tự động/Nét/Màu kỳ diệu/Tiết kiệm mực). */
var FLAT_FILTERS = /* @__PURE__ */ new Set([
	"auto",
	"sharp",
	"magic",
	"eco"
]);
async function renderFlat(orig, edit, max) {
	const k = geoKey(orig, edit, max) + "|flat";
	const hit = geoCache.get(k);
	if (hit && !hit.lost) return hit;
	return once("f:" + k, async () => {
		const g = await renderGeometry(orig, edit, max);
		const f = {
			d: await v0("flatten", async () => {
				const r = await sendImg(g, { op: "flat" });
				if (r) return r.out;
				if (g.lost) {
					geoCache.delete(geoKey(orig, edit, max));
					throw new Error("worker: mất bộ đệm hình học");
				}
				return flattenLightPx(mainEnv(), g.d.slice(), g.w, g.h);
			}),
			w: g.w,
			h: g.h
		};
		geoCache.set(k, f);
		return f;
	});
}
/** Bộ lọc → nắn dải 0 → JPEG: Worker trước, luồng chính dự phòng. */
async function finish(g, o, key) {
	const log = [];
	const r = await sendImg(g, {
		op: "fin",
		o
	});
	let blob;
	if (r) {
		blob = r.blob;
		log.push(...r.log);
	} else {
		if (g.lost) {
			geoCache.delete(key);
			throw new Error("worker: mất bộ đệm hình học");
		}
		blob = await finishPx(mainEnv(), copyImg(g), o, log);
	}
	if (log.length) globalThis.__s11 = [...globalThis.__s11 ?? [], ...log];
	if (!blob) throw new Error("toBlob");
	return blob;
}
async function renderTo(orig, edit, max, as, qOut) {
	const k = resultKey(orig, edit, max) + "|" + as + (qOut ? "|q" + qOut : "");
	const hit = as === "page" ? void 0 : resultCache.get(k);
	if (hit) return hit;
	return once("r:" + k, async () => {
		const flat = FLAT_FILTERS.has(edit.filter);
		const g = flat ? await renderFlat(orig, edit, max) : await renderGeometry(orig, edit, max);
		const gk = geoKey(orig, edit, max) + (flat ? "|flat" : "");
		const blob = await finish(g, {
			filter: edit.filter,
			brightness: edit.brightness,
			contrast: edit.contrast,
			preFlat: flat,
			tools: edit.tools,
			level: edit.level ?? 100,
			q: qOut ?? (as === "blob" ? .9 : .92)
		}, gk);
		if (max > 1200) {
			geoCache.delete(geoKey(orig, edit, max));
			geoCache.delete(geoKey(orig, edit, max) + "|flat");
		}
		const out = as === "data" ? await fileToDataUrl(blob) : as === "page" ? adoptBlob(blob) : URL.createObjectURL(blob);
		if (as !== "page") resultCache.set(k, out);
		return out;
	});
}
/** Dựng đầy đủ (A4 300 dpi mặc định) – dùng khi lưu/xuất. Trả data URL. */
function renderPage(orig, edit, max = TARGET_LONG.high) {
	return renderTo(orig, edit, max, "data");
}
/** CS-20: dựng trang từ ảnh gốc + tham số đúng cạnh dài mức xuất, nén JPEG MỘT lần với chất lượng mức xuất (data URL cho jsPDF).
*  Không giữ trong bộ đệm kết quả (xuất một lần, ảnh lớn). */
async function renderExport(orig, edit, max, q) {
	const out = await renderTo(orig, edit, max, "data", q);
	resultCache.delete(resultKey(orig, edit, max) + "|data|q" + q);
	return out;
}
/** CS-12: như renderPage nhưng trả object URL ĐÃ ĐĂNG KÝ (disk-pack) — lưu tài liệu/nhật ký không phải giải base64. */
function renderPageUrl(orig, edit, max = TARGET_LONG.high) {
	return renderTo(orig, edit, max, "page");
}
/** CS-18: số lần xem trước GPU / rơi về CPU (kiểm chứng "−1 lần dựng CPU mỗi trang"). */
var quickStats = {
	gpu: 0,
	cpu: 0,
	reason: ""
};
if (typeof globalThis !== "undefined") globalThis.__cs18 = quickStats;
var quickOk = true;
/**
* CS-18: ảnh xem trước NHÁP của trang vừa chụp/nhập khi bản đầy đủ còn dựng sau — nắn phối cảnh + bộ lọc một pass trên GPU
* trong Worker, không chạy chuỗi CPU (nắn thử/nắn cong/làm sạch mép/chuẩn sáng/lọc). Chuỗi CPU chỉ chạy MỘT lần cho bản đầy đủ
* (trước: chạy cả cho bản xem trước 1200 px rồi chạy lại cho bản đầy đủ). Không khung / không GPU trong Worker → null (nơi gọi
* dựng bằng renderPageUrl như cũ). Trả object URL đã đăng ký như renderPageUrl.
*/
async function renderQuickUrl(orig, edit, max) {
	if (!quickOk || !edit.quad || !poolCanvasSupported()) {
		quickStats.cpu++;
		return null;
	}
	const p = runInPool("quick", {
		op: "quick",
		src: orig,
		quad: edit.quad,
		max,
		paper: edit.paper ?? "auto",
		rotation: edit.rotation,
		filter: edit.filter,
		level: edit.level ?? 100,
		brightness: edit.brightness,
		contrast: edit.contrast,
		q: .85
	});
	const r = p ? await p.catch((e) => e) : null;
	for (const [step, ms] of r?.t ?? []) pushV0(step, ms);
	const blob = r && "blob" in r ? r.blob : void 0;
	if (!(blob instanceof Blob)) {
		quickStats.cpu++;
		quickStats.reason = r?.fallback ?? "error";
		if (r?.fallback) quickOk = false;
		return null;
	}
	quickStats.gpu++;
	return adoptBlob(blob);
}
/** CS-12: ảnh gốc từ khung chụp → Blob JPEG → object URL đã đăng ký (không qua data URL). */
async function normalizeUrl(src, max = 2e3, q = .9) {
	return adoptBlob(await normalizeBlob(src, max, q));
}
/** Tầng xem trước ~1200 px, trả object URL (bộ đệm sở hữu – không tự revoke). */
function renderPreview(orig, edit) {
	return renderTo(orig, edit, PREVIEW_LONG, "blob");
}
/** CS-04b: xuất cho gradeOf (vẽ ở luồng chính, tính ở Worker). */
function grayscale(src, w, h) {
	const [c, ctx] = canvas(w, h);
	ctx.drawImage(src, 0, 0, w, h);
	const d = ctx.getImageData(0, 0, w, h).data;
	const g = new Uint8ClampedArray(w * h);
	for (let i = 0; i < g.length; i++) g[i] = d[i * 4] * .3 + d[i * 4 + 1] * .59 + d[i * 4 + 2] * .11;
	return g;
}
/** CS-03b: như detectQuadScored nhưng phần dò chạy trong Worker (luồng chính chỉ lấy mẫu RGBA) — kết quả giống hệt. */
async function detectQuadScoredAsync(src, sw, sh, size = 720) {
	const d = await detectPaperAsync(src, sw, sh, size);
	return d && d.score > .35 ? {
		quad: d.quad,
		score: d.score
	} : null;
}
async function detectQuadFromSrc(src) {
	const quad = await withDecoded(src, async (img) => {
		const d = await detectPaperAsync(img, img.naturalWidth, img.naturalHeight, 640);
		return d && d.score > .35 ? d.quad : null;
	});
	if (!quad) return null;
	return refineQuadOnSrc(src, quad);
}
/**
* Local detection plus a trust flag. Not sure = weak score or a side lying on the image border
* (sheet edge not actually seen, e.g. white paper on white paper) — callers should then ask the AI.
*/
async function detectQuadInfo(src) {
	return withDecoded(src, async (img) => {
		const d = await detectPaperAsync(img, img.naturalWidth, img.naturalHeight, 640);
		if (!d || d.score <= .35) return {
			quad: null,
			sure: false
		};
		const e = .012, q = d.quad;
		const onEdge = [
			0,
			1,
			2,
			3
		].some((i) => {
			const a = q[i], b = q[(i + 1) % 4];
			return a[0] < e && b[0] < e || a[1] < e && b[1] < e || a[0] > .988 && b[0] > .988 || a[1] > .988 && b[1] > .988;
		});
		let sure = d.score >= .7 && !onEdge;
		const refined = await refineQuadOnSrc(src, q);
		if (sure) {
			await yieldTask();
			sure = !await looksStacked(img, refined);
		}
		return {
			quad: refined,
			sure
		};
	});
}
async function looksStacked(img, q) {
	try {
		const { stackedSides } = await import("./paper-stack-C8J47jK0.mjs");
		const s = 640 / Math.max(img.naturalWidth, img.naturalHeight);
		const w = Math.max(1, Math.round(img.naturalWidth * s)), h = Math.max(1, Math.round(img.naturalHeight * s));
		const c = document.createElement("canvas");
		c.width = w;
		c.height = h;
		const x = c.getContext("2d", { willReadFrequently: true });
		if (!x) return false;
		x.drawImage(img, 0, 0, w, h);
		const rgba = x.getImageData(0, 0, w, h).data, g = new Uint8Array(w * h);
		for (let i = 0; i < g.length; i++) g[i] = rgba[i * 4] * 77 + rgba[i * 4 + 1] * 150 + rgba[i * 4 + 2] * 29 >> 8;
		return stackedSides({
			data: g,
			w,
			h
		}, q).length > 0;
	} catch {
		return false;
	}
}
/** Snap a rough quad (e.g. from the AI model) onto real paper edges of the original. */
async function refineQuadOnSrc(src, quad) {
	return withDecoded(src, (img) => {
		const W = img.naturalWidth, H = img.naturalHeight, pad = 24;
		return refineQuadSampler(stripSampler([
			0,
			1,
			2,
			3
		].map((i) => {
			const b = edgeStripBox(quad, W, H, i, pad);
			const [c, ctx] = canvas(b.w, b.h);
			ctx.drawImage(img, b.x, b.y, b.w, b.h, 0, 0, b.w, b.h);
			const data = ctx.getImageData(0, 0, b.w, b.h).data;
			c.width = 0;
			return {
				...b,
				data
			};
		})), W, H, quad);
	});
}
async function splitBook(src) {
	const img = await loadImg(src);
	const W = img.naturalWidth, H = img.naturalHeight;
	return [0, 1].map((i) => {
		const [c, ctx] = canvas(W / 2, H);
		ctx.drawImage(img, -i * (W / 2), 0);
		return toJpeg(c);
	});
}
/** Place both sides of an ID card at real size (85.6 × 54 mm) on an A4 sheet. */
async function composeIdCard(front, back) {
	const px = 150 / 25.4;
	const [c, ctx] = canvas(210 * px, 297 * px);
	ctx.fillStyle = "#ffffff";
	ctx.fillRect(0, 0, c.width, c.height);
	const cw = 85.6 * px, ch = 54 * px, x = (c.width - cw) / 2;
	for (const [i, s] of [front, back].entries()) {
		const img = await loadImg(s);
		ctx.drawImage(img, x, 50 * px + i * 496.0629921259843, cw, ch);
	}
	return toJpeg(c, .92);
}
async function compress(src, max = 1400, q = .6) {
	return normalize(src, max, q);
}
/** Count distinct objects on a contrasting background. Returns count + annotated image. */
async function countObjects(src) {
	const img = await loadImg(src);
	const s = 360 / Math.max(img.naturalWidth, img.naturalHeight);
	const w = Math.round(img.naturalWidth * s), h = Math.round(img.naturalHeight * s);
	const g = grayscale(img, w, h);
	const t = otsu(g);
	let dark = 0;
	for (const v of g) if (v <= t) dark++;
	const fgDark = dark < g.length / 2;
	const mask = new Uint8Array(w * h);
	for (let i = 0; i < g.length; i++) mask[i] = (fgDark ? g[i] <= t : g[i] > t) ? 1 : 0;
	const label = new Int32Array(w * h);
	const boxes = [];
	const minArea = w * h * 8e-4;
	for (let i = 0; i < mask.length; i++) {
		if (!mask[i] || label[i]) continue;
		const stack = [i];
		label[i] = 1;
		let area = 0, x0 = w, y0 = h, x1 = 0, y1 = 0;
		while (stack.length) {
			const p = stack.pop();
			area++;
			const x = p % w, y = p / w | 0;
			x0 = Math.min(x0, x);
			x1 = Math.max(x1, x);
			y0 = Math.min(y0, y);
			y1 = Math.max(y1, y);
			for (const q of [
				p - 1,
				p + 1,
				p - w,
				p + w
			]) if (q >= 0 && q < mask.length && mask[q] && !label[q] && Math.abs(q % w - x) <= 1) {
				label[q] = 1;
				stack.push(q);
			}
		}
		if (area >= minArea && area < w * h * .5) boxes.push([
			x0,
			y0,
			x1,
			y1
		]);
	}
	const [c, ctx] = canvas(img.naturalWidth, img.naturalHeight);
	ctx.drawImage(img, 0, 0);
	ctx.strokeStyle = "#00BFA5";
	ctx.lineWidth = Math.max(3, c.width / 250);
	ctx.fillStyle = "#00BFA5";
	ctx.font = `bold ${Math.max(16, c.width / 40)}px sans-serif`;
	boxes.forEach(([a, b, cc, d], i) => {
		ctx.strokeRect(a / s, b / s, (cc - a) / s, (d - b) / s);
		ctx.fillText(String(i + 1), a / s, b / s - 4);
	});
	return {
		count: boxes.length,
		image: toJpeg(c)
	};
}
/** Overlay a transparent drawing (signature / annotation) onto a page image. */
async function stamp(base, overlay) {
	const [a, b] = await Promise.all([loadImg(base), loadImg(overlay)]);
	const [c, ctx] = canvas(a.naturalWidth, a.naturalHeight);
	ctx.drawImage(a, 0, 0);
	ctx.drawImage(b, 0, 0, c.width, c.height);
	return toJpeg(c, .92);
}
/** Focus/shake score: variance of the Laplacian on a ~480px grey copy (optionally only inside the paper quad).
*  Higher = sharper. Scale-normalised so video frames and full-res stills are comparable. */
function sharpness(src, sw, sh, quad) {
	const { w, h } = sharpSize(sw, sh);
	return lapVarGray(grayscale(src, w, h), w, h, quad);
}
/** Share of blown-out (glare) pixels inside the paper area, 0..1. */
function glare(src, sw, sh, quad) {
	const s = 240 / Math.max(sw, sh);
	const w = Math.max(8, Math.round(sw * s)), h = Math.max(8, Math.round(sh * s));
	const [c, ctx] = canvas(w, h);
	ctx.drawImage(src, 0, 0, w, h);
	const d = ctx.getImageData(0, 0, w, h).data;
	let x0 = 0, y0 = 0, x1 = w, y1 = h;
	if (quad) {
		const xs = quad.map((p) => p[0] * w), ys = quad.map((p) => p[1] * h);
		x0 = Math.max(0, Math.round(Math.min(...xs)));
		x1 = Math.min(w, Math.round(Math.max(...xs)));
		y0 = Math.max(0, Math.round(Math.min(...ys)));
		y1 = Math.min(h, Math.round(Math.max(...ys)));
	}
	let hot = 0, n = 0;
	for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
		const i = (y * w + x) * 4;
		n++;
		if (d[i] > 250 && d[i + 1] > 250 && d[i + 2] > 250) hot++;
	}
	c.width = 0;
	return n ? hot / n : 0;
}
/** How strongly the phone is tilted: 0 = flat above the page, ~0.3+ = strong angle. */
function tilt(q) {
	const L = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
	const top = L(q[0], q[1]), bot = L(q[3], q[2]), lef = L(q[0], q[3]), rig = L(q[1], q[2]);
	return Math.max(Math.abs(top - bot) / Math.max(top, bot), Math.abs(lef - rig) / Math.max(lef, rig));
}
/** Bản ảnh tăng cường cho lần đọc AI thứ 2: thẳng hoá, xám, kéo giãn tương phản, khử nhiễu nhẹ, làm nét, cỡ tối ưu OCR. */
async function enhanceForOcr(src, max = 1600) {
	const img = await loadImg(src);
	const s = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
	let [c, ctx] = canvas(Math.round(img.naturalWidth * s), Math.round(img.naturalHeight * s));
	ctx.imageSmoothingQuality = "high";
	ctx.drawImage(img, 0, 0, c.width, c.height);
	c = await deskew(c);
	ctx = c.getContext("2d");
	const W = c.width, H = c.height, im = ctx.getImageData(0, 0, W, H), d = im.data, n = W * H;
	const g = new Float32Array(n);
	const hist = /* @__PURE__ */ new Uint32Array(256);
	for (let p = 0; p < n; p++) {
		const v = .299 * d[p * 4] + .587 * d[p * 4 + 1] + .114 * d[p * 4 + 2];
		g[p] = v;
		hist[v | 0]++;
	}
	let lo = 0, hi = 255, acc = 0;
	for (; lo < 255 && (acc += hist[lo]) < n * .01; lo++);
	acc = 0;
	for (; hi > 0 && (acc += hist[hi]) < n * .01; hi--);
	const range = Math.max(30, hi - lo);
	const out = new Uint8ClampedArray(n * 4);
	for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
		const p = y * W + x;
		let v = g[p];
		if (x > 0 && y > 0 && x < W - 1 && y < H - 1) v = (4 * g[p] + g[p - 1] + g[p + 1] + g[p - W] + g[p + W]) / 8;
		v = (v - lo) / range * 255;
		out[p * 4] = out[p * 4 + 1] = out[p * 4 + 2] = v;
		out[p * 4 + 3] = 255;
	}
	unsharp(out, W, H, .8);
	d.set(out);
	ctx.putImageData(im, 0, 0);
	return toJpeg(c, .85);
}
//#endregion
export { loadImg as A, sharpSize as B, estimateSkew as C, image_DFWRNlNd_exports as D, grayscale as E, releaseRenderCache as F, splitBook as G, skewFromGray as H, renderPage as I, tilt as J, stamp as K, renderPageUrl as L, normalizeFilter as M, normalizeUrl as N, lapVarGray as O, refineQuadOnSrc as P, renderPreview as R, enhanceForOcr as S, glare as T, skewSize as U, sharpness as V, smallGray as W, toolsKey as X, toJpeg as Y, yieldTask as Z, detectQuadInfo as _, TOOL_LABEL as a, detectVideoFrameAsync as b, composeIdCard as c, curveAt as d, detectFrameAsync as f, detectQuadFromSrc as g, detectPaperGray as h, TOOL_KEYS as i, normalize as j, lastSampleMs as k, compress as l, detectPaperAsync as m, PAPER_LABEL as n, buildPageCurve as o, detectPaper as p, targetLong as q, PREVIEW_LONG as r, clampLevel as s, LEVEL_LABEL as t, countObjects as u, detectQuadScoredAsync as v, fileToDataUrl as w, edgeCurves as x, detectTextLines as y, renderQuickUrl as z };
