import { t as QUALITY_THRESHOLDS } from "./quality-B8m69IKS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/filter-suggest-C3Br7JC3.js
var clamp01 = (v) => Math.max(0, Math.min(1, v));
/**
* P5: gợi ý bộ lọc từ chỉ số chất lượng trang.
* Ưu tiên theo mức ảnh hưởng tới khả năng đọc: chói > tối > tương phản thấp > mờ.
* Trả null khi ảnh ổn (không cần đổi bộ lọc).
*/
function suggestFilter(m) {
	const T = QUALITY_THRESHOLDS;
	if (m.glare >= T.GLARE_WARNING) return {
		filter: "shadow",
		reason: "ảnh có vùng chói/bóng đổ",
		confidence: clamp01(.55 + m.glare / (T.GLARE_REJECT * 2))
	};
	if (m.brightness < T.DARK_REJECT) return {
		filter: "magic",
		reason: "ảnh chụp thiếu sáng",
		confidence: clamp01(.6 + (T.DARK_REJECT - m.brightness) / T.DARK_REJECT)
	};
	if (m.brightness < T.DARK_WARNING) return {
		filter: "bright",
		reason: "ảnh hơi tối",
		confidence: clamp01(.5 + (T.DARK_WARNING - m.brightness) / (T.DARK_WARNING - T.DARK_REJECT) / 2)
	};
	if (m.contrast < T.CONTRAST_WARNING) return {
		filter: "auto",
		reason: "chữ nhạt, nền xám",
		confidence: clamp01(.5 + (T.CONTRAST_WARNING - m.contrast) / T.CONTRAST_WARNING / 2)
	};
	if (m.blur < T.BLUR_WARNING) return {
		filter: "sharp",
		reason: "ảnh hơi mờ",
		confidence: clamp01(.45 + (T.BLUR_WARNING - m.blur) / T.BLUR_WARNING / 2)
	};
	return null;
}
/** Gợi ý chỉ nên hiện khi khác bộ lọc đang chọn và đủ tin cậy. */
function shouldSuggest(s, current, minConfidence = .4) {
	return !!s && s.filter !== current && s.confidence >= minConfidence;
}
//#endregion
export { suggestFilter as n, shouldSuggest as t };
