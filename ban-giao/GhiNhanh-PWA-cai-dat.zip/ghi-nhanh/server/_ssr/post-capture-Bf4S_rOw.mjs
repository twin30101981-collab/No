//#region node_modules/.nitro/vite/services/ssr/assets/post-capture-Bf4S_rOw.js
/** Thuần: chọn trang cần nhận chữ (mới thêm, chưa có chữ) và có đặt tên tự động không. */
function planPostCapture(doc, before, isNewDoc, s, online) {
	if (doc.locked) return {
		ocrPageIds: [],
		autoName: false
	};
	return {
		ocrPageIds: s.autoOcr ? doc.pages.filter((p) => !before.has(p.id) && !(p.text ?? "").trim()).map((p) => p.id) : [],
		autoName: isNewDoc && s.autoName && online
	};
}
/** Chạy kế hoạch: OCR qua hàng đợi nền dùng chung; đặt tên sau khi OCR xong (không chặn giao diện). */
async function runPostCapture(doc, before, isNewDoc, metrics, opts = {}) {
	const { getSettings } = await import("./settings-DDlMLZCe.mjs").then((n) => n.s).then((n) => n.s);
	const st = getSettings();
	const plan = planPostCapture(doc, before, isNewDoc, {
		autoOcr: st.autoOcr ?? true,
		autoName: st.autoName
	}, navigator.onLine);
	const recipes = metrics?.size && st.autoRecipe !== false ? applyAutoRecipes(doc, before, metrics, st.defaultFilter) : Promise.resolve();
	if (opts.heal) recipes.finally(() => import("./runner-CZAn6hg6.mjs").then((n) => n.o).then((n) => n.a).then(async (r) => {
		const { getDocs } = await import("./db-CclUQaLE.mjs").then((n) => n.r).then((n) => n.n);
		const d = getDocs().find((x) => x.id === doc.id);
		if (d) await r.healPending([d]);
	})).catch(() => {});
	if (plan.autoName) import("./auto-name-run-15gud4Ih.mjs").then((m) => m.autoNameDoc(doc.id));
	if (!plan.ocrPageIds.length) return plan;
	const { ocrQueue } = await import("./ocr-queue-Dg31Dfup.mjs").then((n) => n.r);
	const idx = new Map(doc.pages.map((p, i) => [p.id, i]));
	const tasks = ocrQueue().add(plan.ocrPageIds.map((id) => ({
		docId: doc.id,
		pageId: id,
		label: `${doc.name} · trang ${(idx.get(id) ?? 0) + 1}`,
		src: doc.pages[idx.get(id)].src,
		latest: () => finishedSrc(doc.id, id)
	})));
	Promise.allSettled(tasks).then(async (rs) => {
		const f = await bgOcrFailure(rs);
		if (!f) return;
		const [{ logScan }, { showError }] = await Promise.all([import("./scan-log-DnWLrMlu.mjs").then((n) => n.o), import("./errors-DKvrPJ4v.mjs").then((n) => n.t).then((n) => n.t)]);
		logScan({
			code: "OCR_BG_FAIL",
			message: `${f.count}/${rs.length} trang: ${f.error instanceof Error ? f.error.message : String(f.error)}`
		});
		showError(f.error, `Nhận chữ tự động lỗi ${f.count} trang (mở tài liệu → Nhận diện chữ để thử lại)`);
	});
	return plan;
}
/**
* CS-18 "OCR sau cùng": ảnh trang lúc chụp có thể là bản xem trước NHÁP (GPU, chưa nắn cong/làm sạch mép) — nhận chữ đọc ảnh
* trang mới nhất sau khi bản đầy đủ dựng xong (trạng thái khác "dang"), chờ tối đa `maxMs`; quá hạn đọc ảnh hiện có.
*/
async function finishedSrc(docId, pageId, maxMs = 12e4, stepMs = 500) {
	const { getDocs } = await import("./db-CclUQaLE.mjs").then((n) => n.r).then((n) => n.n);
	const page = () => getDocs().find((d) => d.id === docId)?.pages.find((p) => p.id === pageId);
	for (let t = 0; t < maxMs && page()?.status === "dang"; t += stepMs) await new Promise((r) => setTimeout(r, stepMs));
	const p = page();
	if (!p) throw new Error("trang đã bị xoá");
	return p.src;
}
/** TD-32: lỗi thật (bỏ qua hủy) của một đợt nhận chữ nền; null nếu không có. */
async function bgOcrFailure(rs) {
	const { CancelledError } = await import("./ocr-queue-Dg31Dfup.mjs").then((n) => n.r);
	const bad = rs.filter((r) => r.status === "rejected" && !(r.reason instanceof CancelledError));
	return bad.length ? {
		count: bad.length,
		error: bad[0].reason
	} : null;
}
/** P8.4: áp công thức xử lý cho trang mới (đọc lại bản mới nhất để không đè thay đổi của người dùng). */
async function applyAutoRecipes(doc, before, metrics, defaultFilter) {
	try {
		const [{ planRecipes, applyRecipes }, { detectDocType }, { combineDocType, docImageSignals, guessDocTypeFromImage }, { loadChoices }, db] = await Promise.all([
			import("./recipe-apply-CyLpFKW0.mjs"),
			import("./doc-type-DMOk6KXG.mjs"),
			import("./doc-type-image-om3SvWwU.mjs"),
			import("./user-recipe-DhO7F1JT.mjs"),
			import("./db-CclUQaLE.mjs").then((n) => n.r).then((n) => n.n)
		]);
		const text = doc.pages.map((p) => p.text ?? "").join("\n");
		const newPage = doc.pages.find((p) => before.size === 0 || !before.has(p.id)) ?? doc.pages[0];
		const signals = newPage?.src ? await docImageSignals(newPage.src) : null;
		const changes = planRecipes(doc, before, metrics, defaultFilter, combineDocType(detectDocType(text), signals ? guessDocTypeFromImage(signals) : null)?.id ?? null, loadChoices());
		if (!changes.length) return;
		const { healPending, pipelineEnabled } = await import("./runner-CZAn6hg6.mjs").then((n) => n.o).then((n) => n.a);
		const bg = pipelineEnabled();
		const changed = new Set(changes.map((c) => c.pageId));
		const saved = await db.mutateDoc(doc.id, (fresh) => fresh.locked ? null : {
			...fresh,
			pages: applyRecipes(fresh.pages, changes).map((p) => !bg && changed.has(p.id) ? {
				...p,
				status: fresh.pages.find((x) => x.id === p.id)?.status ?? "xong"
			} : p)
		}, true);
		if (bg && saved && !saved.locked) await healPending([saved]);
	} catch {}
}
//#endregion
export { runPostCapture };
