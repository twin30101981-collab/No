import { n as supabase } from "./client-D3MSxqCj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pair-DrmeGriq.js
var CHUNK = 48e3;
function split(id, dataUrl, size = CHUNK) {
	const n = Math.max(1, Math.ceil(dataUrl.length / size));
	return Array.from({ length: n }, (_, i) => ({
		id,
		i,
		n,
		data: dataUrl.slice(i * size, (i + 1) * size)
	}));
}
/** Ghép mẩu theo id; trả ảnh đầy đủ khi đủ mẩu. Bỏ mẩu lạ/sai/quá lớn; xóa ảnh dở sau `staleMs`. */
var Assembler = class {
	staleMs;
	bufs = /* @__PURE__ */ new Map();
	constructor(staleMs = 6e4) {
		this.staleMs = staleMs;
	}
	push(p, now = Date.now()) {
		for (const [k, b] of this.bufs) if (now - b.at > this.staleMs) this.bufs.delete(k);
		if (!p || typeof p.id !== "string" || !Number.isInteger(p.i) || !Number.isInteger(p.n) || p.n < 1 || p.i < 0 || p.i >= p.n || typeof p.data !== "string") return null;
		if (p.n * 48e3 > 6048e3) return null;
		let b = this.bufs.get(p.id);
		if (!b) {
			b = {
				n: p.n,
				got: new Array(p.n),
				count: 0,
				at: now
			};
			this.bufs.set(p.id, b);
		}
		if (b.n !== p.n) return null;
		b.at = now;
		if (b.got[p.i] === void 0) {
			b.got[p.i] = p.data;
			b.count++;
		}
		if (b.count < b.n) return null;
		this.bufs.delete(p.id);
		const dataUrl = b.got.join("");
		return dataUrl.startsWith("data:image/") ? {
			id: p.id,
			dataUrl
		} : null;
	}
	progress(id) {
		const b = this.bufs.get(id);
		return b ? b.count / b.n : null;
	}
};
var ROOM_TTL_MS = 6e5;
var CODE_RE = /^[A-Za-z0-9_-]{22}$/;
function newRoomCode() {
	const b = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(16));
	return btoa(String.fromCharCode(...b)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
var isRoomCode = (c) => CODE_RE.test(c);
var pairUrl = (origin, code, created) => `${origin}/pair/${code}?t=${created}`;
var roomExpired = (created, now) => created !== null && (now - created > 6e5 || created - now > 6e4);
var remaining = (created, now) => Math.max(0, created + ROOM_TTL_MS - now);
function deviceLabel(ua) {
	if (/iPhone/.test(ua)) return "iPhone";
	if (/iPad/.test(ua)) return "iPad";
	if (/Android/.test(ua)) return "Điện thoại Android";
	return "Điện thoại";
}
/** Vào phòng; báo lại danh sách bên đã vào mỗi khi thay đổi. Trả hàm rời phòng. */
function joinRoom(code, me, onPeers, onStatus, setup) {
	const ch = supabase.channel(`pair:${code}`, { config: {
		presence: { key: `${me.role}-${crypto.randomUUID().slice(0, 8)}` },
		broadcast: { self: false }
	} });
	ch.on("presence", { event: "sync" }, () => {
		const st = ch.presenceState();
		onPeers(Object.values(st).flat().map((p) => ({
			role: p.role,
			device: p.device
		})));
	});
	setup?.(ch);
	ch.subscribe(async (s) => {
		onStatus?.(s);
		if (s === "SUBSCRIBED") await ch.track(me);
	});
	return {
		channel: ch,
		leave: () => {
			ch.untrack();
			supabase.removeChannel(ch);
		}
	};
}
//#endregion
export { newRoomCode as a, roomExpired as c, joinRoom as i, split as l, deviceLabel as n, pairUrl as o, isRoomCode as r, remaining as s, Assembler as t };
