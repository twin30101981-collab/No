import { o as __toESM } from "../_runtime.mjs";
import { T as useNavigate, w as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { a as userMessage } from "./errors-DKvrPJ4v.mjs";
import { a as detectInAppBrowser, c as signInEmail, d as signUpEmail, f as useUser, l as signInGoogle, o as isIosStandalonePwa, r as chromeIntentUrl } from "./auth-BEi9IFUJ.mjs";
import { t as AppShell } from "./app-shell-CZvf2xHx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-DjrNf2r5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuthPage() {
	const { user } = useUser();
	const nav = useNavigate();
	const [mode, setMode] = (0, import_react.useState)("in");
	const [email, setEmail] = (0, import_react.useState)("");
	const [pw, setPw] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (user) nav({ to: "/me" });
	}, [user, nav]);
	async function submit(e) {
		e.preventDefault();
		setErr("");
		setBusy(true);
		try {
			if (mode === "in") {
				await signInEmail(email.trim(), pw);
				toast.success("Đã đăng nhập");
			} else {
				const r = await signUpEmail(email.trim(), pw);
				toast.success(r.needConfirm ? "Đã gửi thư xác nhận — mở email để kích hoạt" : "Đã tạo tài khoản");
			}
		} catch (x) {
			setErr(userMessage(x, "Chưa đăng nhập được — thử lại"));
		} finally {
			setBusy(false);
		}
	}
	const [inApp, setInApp] = (0, import_react.useState)(null);
	const [iosPwa, setIosPwa] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setInApp(detectInAppBrowser());
		setIosPwa(isIosStandalonePwa());
	}, []);
	async function copyLink() {
		try {
			await navigator.clipboard.writeText(window.location.href);
			toast.success("Đã sao chép liên kết — dán vào Chrome hoặc Safari");
		} catch {
			toast.error("Không sao chép được — nhấn giữ thanh địa chỉ để chép liên kết");
		}
	}
	async function google() {
		setErr("");
		setBusy(true);
		try {
			await signInGoogle();
		} catch (x) {
			setErr(userMessage(x, "Chưa đăng nhập được — thử lại"));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: mode === "in" ? "Đăng nhập" : "Tạo tài khoản",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rise rise-1 mx-auto max-w-sm space-y-4 px-5 pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Không bắt buộc. App vẫn dùng đầy đủ khi chưa đăng nhập; tài khoản dùng để đồng bộ tài liệu giữa các máy (sắp có)."
				}),
				inApp && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "note",
					className: "space-y-2 rounded-[14px] border border-amber-500/40 bg-amber-500/10 p-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-semibold",
							children: ["Đang mở trong ", inApp]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-muted-foreground",
							children: [
								"Google không cho đăng nhập trong trình duyệt của ",
								inApp,
								". Hãy mở trang này bằng Chrome hoặc Safari, hoặc đăng nhập bằng email bên dưới."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: copyLink,
								className: "inline-flex min-h-10 items-center rounded-[10px] bg-primary px-3 text-xs font-semibold text-primary-foreground",
								children: "Sao chép liên kết"
							}), chromeIntentUrl(window.location.href) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: chromeIntentUrl(window.location.href) ?? "#",
								className: "inline-flex min-h-10 items-center rounded-[10px] border border-input px-3 text-xs font-semibold",
								children: "Mở bằng Chrome"
							})]
						})
					]
				}),
				iosPwa && !inApp && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "note",
					className: "rounded-[14px] border border-input p-3 text-xs text-muted-foreground",
					children: "Trên iPhone, app đã thêm vào Màn hình chính có thể không nhận được đăng nhập Google. Nếu đăng nhập xong vẫn chưa thấy tên tài khoản, hãy dùng email, hoặc đăng nhập trong Safari rồi mở lại app."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy || !!inApp,
					onClick: google,
					className: "document-row flex w-full items-center justify-center gap-2 rounded-[14px] p-3 text-sm font-semibold disabled:opacity-50",
					children: "Tiếp tục với Google"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 text-xs text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-border" }),
						"hoặc email",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-border" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "email",
							required: true,
							autoComplete: "email",
							placeholder: "Email",
							value: email,
							onChange: (e) => setEmail(e.target.value),
							className: "w-full rounded-[12px] border border-input bg-background px-3 py-2.5 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "password",
							required: true,
							minLength: 6,
							autoComplete: mode === "in" ? "current-password" : "new-password",
							placeholder: "Mật khẩu (ít nhất 6 ký tự)",
							value: pw,
							onChange: (e) => setPw(e.target.value),
							className: "w-full rounded-[12px] border border-input bg-background px-3 py-2.5 text-sm"
						}),
						err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "alert",
							className: "text-sm text-destructive",
							children: err
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: busy,
							className: "w-full rounded-[14px] bg-primary p-3 text-sm font-semibold text-primary-foreground disabled:opacity-50",
							children: busy ? "Đang xử lý…" : mode === "in" ? "Đăng nhập" : "Tạo tài khoản"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setMode(mode === "in" ? "up" : "in");
						setErr("");
					},
					className: "w-full py-3 text-center text-sm font-semibold text-primary",
					children: mode === "in" ? "Chưa có tài khoản? Tạo mới" : "Đã có tài khoản? Đăng nhập"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/me",
					className: "block py-3 text-center text-xs text-muted-foreground",
					children: "Để sau"
				})
			]
		})
	});
}
//#endregion
export { AuthPage as component };
