import { t as aiClassify } from "./ai.functions-CpS7iAgj.mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { n as getSettings } from "./settings-DDlMLZCe.mjs";
import { c as getDocs, d as mutateDoc } from "./db-CclUQaLE.mjs";
import { i as applyNaming, r as applyClassification } from "./name-rules-BfNs0V4s.mjs";
import { d as getLibrary, s as createFolder, t as ROOT_FOLDER, u as ensureTag } from "./library-BIMZUn1d.mjs";
import { i as whenScanIdle, t as isScanActive } from "./priority-gate-CeFvd7IG.mjs";
import { n as reportAiResult } from "./ai-queue-DZjZmUCT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auto-name-run-15gud4Ih.js
async function shrink(src, max = 1024) {
	const img = new Image();
	img.src = src;
	await img.decode();
	const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
	const c = document.createElement("canvas");
	c.width = Math.round(img.naturalWidth * k);
	c.height = Math.round(img.naturalHeight * k);
	c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
	return c.toDataURL("image/jpeg", .8);
}
async function autoNameDoc(id) {
	if (!getSettings().autoName || !navigator.onLine) return;
	if (isScanActive()) await whenScanIdle();
	const start = getDocs().find((d) => d.id === id);
	if (!start || start.locked || !start.pages.length) return;
	try {
		const images = await Promise.all(start.pages.slice(0, 2).map((p) => shrink(p.src)));
		const r = await aiClassify({ data: { images } });
		reportAiResult(r);
		if (!r.ok) return;
		const cur = getDocs().find((d) => d.id === id);
		if (!cur) return;
		const classified = applyClassification(cur, r.data);
		if (!classified) return;
		const st = getSettings();
		const next = applyNaming(classified, {
			title: classified.name,
			type: r.data.type
		}, st.nameTemplate, st.folderRules ?? [], ROOT_FOLDER);
		if (next.folder !== cur.folder && !getLibrary().folders.includes(next.folder)) {
			const parts = next.folder.split("/");
			parts.forEach((_, i) => {
				const f = parts.slice(0, i + 1).join("/");
				if (!getLibrary().folders.includes(f)) createFolder(f);
			});
		}
		for (const t of next.tags ?? []) if (!(cur.tags ?? []).includes(t)) ensureTag(t);
		await mutateDoc(id, (d) => ({
			...d,
			name: next.name,
			kind: next.kind,
			folder: next.folder,
			tags: next.tags ?? [],
			fields: next.fields ?? {}
		}));
		const before = cur;
		toast(`AI đặt tên: ${next.name}`, {
			description: [next.tags?.length ? `Thẻ: ${next.tags.join(", ")}` : "", next.folder !== cur.folder ? `Chuyển vào: ${next.folder}` : ""].filter(Boolean).join(" · ") || void 0,
			action: {
				label: "Hoàn tác",
				onClick: () => void mutateDoc(id, (now) => ({
					...now,
					name: before.name,
					kind: before.kind,
					folder: before.folder,
					tags: before.tags ?? [],
					fields: before.fields ?? {}
				}))
			}
		});
	} catch (e) {
		console.warn("auto-name", e);
	}
}
//#endregion
export { autoNameDoc };
