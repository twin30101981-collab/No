//#region node_modules/.nitro/vite/services/ssr/assets/share-links-s-_jx_4k.js
var EXPIRY_OPTIONS = [
	{
		id: "1h",
		label: "1 giờ",
		ms: 36e5
	},
	{
		id: "1d",
		label: "1 ngày",
		ms: 864e5
	},
	{
		id: "7d",
		label: "7 ngày",
		ms: 6048e5
	},
	{
		id: "30d",
		label: "30 ngày",
		ms: 2592e6
	},
	{
		id: "never",
		label: "Không hết hạn",
		ms: 0
	}
];
/** Thời điểm hết hạn (ISO) hoặc null nếu không hết hạn. */
function expiresAt(id, now) {
	const o = EXPIRY_OPTIONS.find((x) => x.id === id);
	if (!o) throw new Error("Hạn dùng không hợp lệ");
	return o.ms ? new Date(now + o.ms).toISOString() : null;
}
var B64URL = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
/** Mã liên kết 22 ký tự (~132 bit ngẫu nhiên). */
function newToken() {
	const b = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(22));
	return Array.from(b, (x) => B64URL[x & 63]).join("");
}
var hex = (b) => Array.from(new Uint8Array(b), (x) => x.toString(16).padStart(2, "0")).join("");
var unhex = (s) => new Uint8Array((s.match(/../g) ?? []).map((h) => parseInt(h, 16)));
var ITER = 1e5;
async function derive(pw, salt, iter) {
	const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(pw), "PBKDF2", false, ["deriveBits"]);
	return hex(await crypto.subtle.deriveBits({
		name: "PBKDF2",
		hash: "SHA-256",
		salt,
		iterations: iter
	}, key, 256));
}
/** Băm mật khẩu: "pbkdf2$<lặp>$<muối>$<băm>". */
async function hashPassword(pw) {
	const salt = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(16));
	return `pbkdf2$${ITER}$${hex(salt)}$${await derive(pw, salt, ITER)}`;
}
async function verifyPassword(pw, stored) {
	const [alg, it, salt, h] = stored.split("$");
	if (alg !== "pbkdf2" || !it || !salt || !h) return false;
	const got = await derive(pw, unhex(salt), Number(it));
	let diff = got.length ^ h.length;
	for (let i = 0; i < Math.min(got.length, h.length); i++) diff |= got.charCodeAt(i) ^ h.charCodeAt(i);
	return diff === 0;
}
function checkPassword(pw) {
	if (!pw) return null;
	if (pw.length < 4) return "Mật khẩu cần ít nhất 4 ký tự";
	if (pw.length > 64) return "Mật khẩu tối đa 64 ký tự";
	return null;
}
function linkStatus(l, now) {
	if (l.revoked_at) return "revoked";
	if (l.expires_at && Date.parse(l.expires_at) <= now) return "expired";
	return "active";
}
var shareUrl = (origin, token) => `${origin.replace(/\/$/, "")}/s/${token}`;
var SHARE_PW_WINDOW_MS = 9e5;
function createFailGate(o) {
	const now = o.now ?? Date.now, maxKeys = o.maxKeys ?? 5e3;
	const m = /* @__PURE__ */ new Map();
	const live = (k, t) => {
		const e = m.get(k);
		if (e && e.start + o.windowMs <= t) {
			m.delete(k);
			return;
		}
		return e;
	};
	return {
		/** Còn được thử không; nếu bị chặn trả số giây phải chờ. */
		check(key) {
			const t = now(), e = live(key, t);
			if (!e || e.fails < o.limit) return { ok: true };
			return {
				ok: false,
				retryAfterSec: Math.max(1, Math.ceil((e.start + o.windowMs - t) / 1e3))
			};
		},
		fail(key) {
			const t = now();
			const e = live(key, t);
			if (e) {
				e.fails++;
				return;
			}
			m.set(key, {
				start: t,
				fails: 1
			});
			if (m.size > maxKeys) {
				for (const [k, v] of m) if (v.start + o.windowMs <= t) m.delete(k);
				while (m.size > maxKeys) m.delete(m.keys().next().value);
			}
		},
		/** Nhập đúng thì xoá đếm. */
		reset(key) {
			m.delete(key);
		},
		size: () => m.size
	};
}
var shareFailKey = (ip, token) => `${ip ?? "?"}|${token}`;
function tooManyFailsMessage(retryAfterSec) {
	return `Thử sai quá nhiều lần. Hãy đợi khoảng ${Math.max(1, Math.ceil(retryAfterSec / 60))} phút rồi thử lại.`;
}
//#endregion
export { expiresAt as a, newToken as c, tooManyFailsMessage as d, verifyPassword as f, createFailGate as i, shareFailKey as l, SHARE_PW_WINDOW_MS as n, hashPassword as o, checkPassword as r, linkStatus as s, EXPIRY_OPTIONS as t, shareUrl as u };
