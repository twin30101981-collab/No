//#region node_modules/.nitro/vite/services/ssr/assets/safe-storage-DnXnZPA0.js
/**
* BL-08 (safeSet localStorage): ghi localStorage an toàn.
* Gốc lỗi: localStorage đầy (≈5 MB, nhật ký đo/quét tích luỹ) hoặc bị chặn (Safari riêng tư) → setItem ném DOMException
* thô giữa thao tác (đổi cài đặt, lưu hoá đơn, thư mục…). Cách xử lý: khi đầy, xoá nhật ký KHÔNG thiết yếu rồi ghi lại;
* vẫn không được → ném lỗi tiếng Việt rõ ràng (dữ liệu người dùng không bị mất âm thầm).
*/
/** Khoá chỉ là nhật ký/thống kê — xoá được để nhường chỗ cho dữ liệu người dùng. */
var EXPENDABLE_KEYS = [
	"ghi-nhanh:perf",
	"ghi-nhanh:scan-log",
	"ghi-nhanh:tool-uses",
	"ghi-nhanh:perf-baseline"
];
var StorageFullError = class extends Error {
	constructor() {
		super("Bộ nhớ trình duyệt đã đầy hoặc bị chặn — chưa lưu được thay đổi. Hãy xoá bớt dữ liệu (Tôi → Bộ nhớ) rồi thử lại.");
		this.name = "StorageFullError";
	}
};
function safeSet(key, value, store = localStorage) {
	try {
		store.setItem(key, value);
		return;
	} catch {}
	let freed = false;
	for (const k of EXPENDABLE_KEYS) if (k !== key) try {
		if (store.getItem(k) !== null) {
			store.removeItem(k);
			freed = true;
		}
	} catch {}
	if (freed) try {
		store.setItem(key, value);
		return;
	} catch {}
	throw new StorageFullError();
}
//#endregion
export { safeSet as t };
