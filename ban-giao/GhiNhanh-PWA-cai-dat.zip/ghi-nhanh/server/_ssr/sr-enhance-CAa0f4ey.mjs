import { r as canvasToPageUrl } from "./files-CTF11Arr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sr-enhance-CAa0f4ey.js
/** Chia ảnh thành ô (đã gồm viền chồng), phủ kín ảnh. */
function planTiles(w, h, tile = 192, overlap = 16) {
	const step = Math.max(1, tile - 2 * overlap), out = [];
	for (let y0 = 0; y0 < h; y0 += step) for (let x0 = 0; x0 < w; x0 += step) {
		const x = Math.max(0, x0 - overlap), y = Math.max(0, y0 - overlap);
		out.push({
			x,
			y,
			w: Math.min(w, x0 + step + overlap) - x,
			h: Math.min(h, y0 + step + overlap) - y
		});
		if (x0 + step >= w) break;
	}
	return out;
}
/** Hệ số thu nhỏ đầu vào để ảnh ra ≤ maxOutPixels (1 = giữ nguyên). */
function planScale(w, h, scale, maxOutPixels) {
	const out = w * h * scale * scale;
	return out <= maxOutPixels ? 1 : Math.sqrt(maxOutPixels / out);
}
function crop(img, r) {
	const d = new Uint8ClampedArray(r.w * r.h * 4);
	for (let y = 0; y < r.h; y++) d.set(img.data.subarray(((r.y + y) * img.width + r.x) * 4, ((r.y + y) * img.width + r.x + r.w) * 4), y * r.w * 4);
	return {
		data: d,
		width: r.w,
		height: r.h
	};
}
/** Thu nhỏ song tuyến (dùng khi vượt giới hạn bộ nhớ). */
function resize(img, w, h) {
	const d = new Uint8ClampedArray(w * h * 4), sx = img.width / w, sy = img.height / h;
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		const fx = Math.min(img.width - 1, (x + .5) * sx - .5), fy = Math.min(img.height - 1, (y + .5) * sy - .5);
		const x0 = Math.max(0, Math.floor(fx)), y0 = Math.max(0, Math.floor(fy));
		const x1 = Math.min(img.width - 1, x0 + 1), y1 = Math.min(img.height - 1, y0 + 1), ax = Math.max(0, fx - x0), ay = Math.max(0, fy - y0);
		for (let k = 0; k < 4; k++) {
			const g = (xx, yy) => img.data[(yy * img.width + xx) * 4 + k];
			d[(y * w + x) * 4 + k] = (g(x0, y0) * (1 - ax) + g(x1, y0) * ax) * (1 - ay) + (g(x0, y1) * (1 - ax) + g(x1, y1) * ax) * ay;
		}
	}
	return {
		data: d,
		width: w,
		height: h
	};
}
/** Trọng số theo khoảng cách tới mép ô (mép ảnh thật không bị giảm). */
function weight(i, n, ramp, atStart, atEnd) {
	let w = 1;
	if (!atStart && ramp > 0) w = Math.min(w, (i + .5) / ramp);
	if (!atEnd && ramp > 0) w = Math.min(w, (n - i - .5) / ramp);
	return Math.max(.001, Math.min(1, w));
}
async function upscaleTiled(img, upscale, o = {}) {
	const { scale = 2, tile = 192, overlap = 16, maxOutPixels = 24e6 } = o;
	const k = planScale(img.width, img.height, scale, maxOutPixels);
	const src = k < 1 ? resize(img, Math.max(1, Math.floor(img.width * k)), Math.max(1, Math.floor(img.height * k))) : img;
	const W = src.width * scale, H = src.height * scale;
	const acc = new Float32Array(W * H * 4), wsum = new Float32Array(W * H);
	const tiles = planTiles(src.width, src.height, tile, overlap), ramp = overlap * 2 * scale;
	let done = 0;
	for (const r of tiles) {
		if (o.signal?.aborted) throw new DOMException("Đã hủy làm nét", "AbortError");
		const up = await upscale(crop(src, r), scale);
		if (up.width !== r.w * scale || up.height !== r.h * scale) throw new Error("Mô hình trả kích thước ô sai");
		const ox = r.x * scale, oy = r.y * scale;
		for (let y = 0; y < up.height; y++) {
			const wy = weight(y, up.height, ramp, r.y === 0, r.y + r.h >= src.height);
			for (let x = 0; x < up.width; x++) {
				const w = wy * weight(x, up.width, ramp, r.x === 0, r.x + r.w >= src.width);
				const p = (oy + y) * W + ox + x, q = (y * up.width + x) * 4;
				wsum[p] += w;
				for (let c = 0; c < 4; c++) acc[p * 4 + c] += up.data[q + c] * w;
			}
		}
		o.onProgress?.(++done, tiles.length);
		await new Promise((res) => setTimeout(res, 0));
	}
	const out = new Uint8ClampedArray(W * H * 4);
	for (let p = 0; p < W * H; p++) for (let c = 0; c < 4; c++) out[p * 4 + c] = acc[p * 4 + c] / (wsum[p] || 1);
	return {
		data: out,
		width: W,
		height: H,
		inputScale: k
	};
}
/**
* G4-13 — Làm nét HD: dự phòng làm nét cổ điển + hàm chạy cho giao diện.
*
* `classicUpscaler`: phóng song tuyến rồi làm nét không mờ (unsharp mask) trên độ sáng,
* dùng khi chưa có mô hình siêu phân giải (hoặc tải/chạy mô hình lỗi). Cùng kiểu `Upscaler`
* nên chạy được qua `upscaleTiled` (ô ảnh + giới hạn bộ nhớ).
*/
function unsharpLuma(img, amount = .8, threshold = 3) {
	const { width: w, height: h, data: s } = img, n = w * h, L = new Float32Array(n), B = new Float32Array(n), T = new Float32Array(n);
	for (let p = 0; p < n; p++) L[p] = .299 * s[p * 4] + .587 * s[p * 4 + 1] + .114 * s[p * 4 + 2];
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) T[y * w + x] = (L[y * w + Math.max(0, x - 1)] + 2 * L[y * w + x] + L[y * w + Math.min(w - 1, x + 1)]) / 4;
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) B[y * w + x] = (T[Math.max(0, y - 1) * w + x] + 2 * T[y * w + x] + T[Math.min(h - 1, y + 1) * w + x]) / 4;
	const d = new Uint8ClampedArray(s);
	for (let p = 0; p < n; p++) {
		const diff = L[p] - B[p];
		if (Math.abs(diff) < threshold) continue;
		const add = diff * amount;
		d[p * 4] += add;
		d[p * 4 + 1] += add;
		d[p * 4 + 2] += add;
	}
	return {
		data: d,
		width: w,
		height: h
	};
}
var classicUpscaler = async (tile, scale) => unsharpLuma(resize(tile, tile.width * scale, tile.height * scale));
/** Làm nét ảnh: thử mô hình nếu có, lỗi thì tự quay về cách cổ điển. */
async function enhanceImage(img, o = {}) {
	const common = {
		scale: 2,
		maxOutPixels: o.maxOutPixels ?? 16e6,
		signal: o.signal,
		onProgress: (d, t) => o.onProgress?.(Math.round(d / t * 100))
	};
	if (o.model) try {
		return {
			...await upscaleTiled(img, o.model, common),
			method: "model"
		};
	} catch (e) {
		if (e?.name === "AbortError") throw e;
	}
	return {
		...await upscaleTiled(img, classicUpscaler, {
			...common,
			tile: 256,
			overlap: 4
		}),
		method: "classic"
	};
}
/** Bản dùng cho giao diện: ảnh URL → object URL JPEG đã làm nét ×2 (R1.4: không còn data URL). */
async function enhanceDataUrl(src, o = {}) {
	const img = await new Promise((res, rej) => {
		const i = new Image();
		i.onload = () => res(i);
		i.onerror = () => rej(/* @__PURE__ */ new Error("Không mở được ảnh"));
		i.src = src;
	});
	const c = document.createElement("canvas");
	c.width = img.naturalWidth;
	c.height = img.naturalHeight;
	const ctx = c.getContext("2d", { willReadFrequently: true });
	ctx.drawImage(img, 0, 0);
	const r = await enhanceImage(ctx.getImageData(0, 0, c.width, c.height), o);
	c.width = 0;
	const out = document.createElement("canvas");
	out.width = r.width;
	out.height = r.height;
	out.getContext("2d").putImageData(new ImageData(r.data, r.width, r.height), 0, 0);
	return {
		src: await canvasToPageUrl(out, "image/jpeg", .9),
		width: r.width,
		height: r.height,
		method: r.method
	};
}
//#endregion
export { enhanceDataUrl };
