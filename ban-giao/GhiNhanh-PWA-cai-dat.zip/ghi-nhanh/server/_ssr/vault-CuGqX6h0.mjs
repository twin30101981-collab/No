import { r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vault-CuGqX6h0.js
var vault_CuGqX6h0_exports = /* @__PURE__ */ __exportAll({
	a: () => newDataKey,
	c: () => normRecovery,
	d: () => sealVerified,
	f: () => setVaultKey,
	h: () => wrapDataKey,
	i: () => getVaultKey,
	l: () => openDoc,
	m: () => vault_exports,
	n: () => deriveKey,
	o: () => newRecoveryCode,
	p: () => unwrapDataKey,
	r: () => encryptJson,
	s: () => newSalt,
	t: () => decryptJson,
	u: () => sealDoc
});
var vault_exports = /* @__PURE__ */ __exportAll$1({
	PBKDF2_ITER: () => PBKDF2_ITER,
	decryptJson: () => decryptJson,
	deriveKey: () => deriveKey,
	encryptJson: () => encryptJson,
	getVaultKey: () => getVaultKey,
	newDataKey: () => newDataKey,
	newRecoveryCode: () => newRecoveryCode,
	newSalt: () => newSalt,
	normRecovery: () => normRecovery,
	openDoc: () => openDoc,
	sealDoc: () => sealDoc,
	sealVerified: () => sealVerified,
	setVaultKey: () => setVaultKey,
	unwrapDataKey: () => unwrapDataKey,
	wrapDataKey: () => wrapDataKey
});
var PBKDF2_ITER = 15e4;
var b64 = (u) => {
	let s = "";
	for (let i = 0; i < u.length; i += 32768) s += String.fromCharCode(...u.subarray(i, i + 32768));
	return btoa(s);
};
var unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
function newSalt() {
	return b64(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(16)));
}
async function deriveKey(pin, salt, iterations = PBKDF2_ITER) {
	const base = await crypto.subtle.importKey("raw", new TextEncoder().encode(pin), "PBKDF2", false, ["deriveKey"]);
	return crypto.subtle.deriveKey({
		name: "PBKDF2",
		salt: unb64(salt),
		iterations,
		hash: "SHA-256"
	}, base, {
		name: "AES-GCM",
		length: 256
	}, false, ["encrypt", "decrypt"]);
}
async function encryptJson(key, value) {
	const iv = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(12));
	const ct = await crypto.subtle.encrypt({
		name: "AES-GCM",
		iv
	}, key, new TextEncoder().encode(JSON.stringify(value)));
	return {
		v: 1,
		iv: b64(iv),
		data: b64(new Uint8Array(ct))
	};
}
/** Ném lỗi khi sai khoá hoặc dữ liệu bị sửa (AES-GCM có xác thực). */
async function decryptJson(key, blob) {
	const pt = await crypto.subtle.decrypt({
		name: "AES-GCM",
		iv: unb64(blob.iv)
	}, key, unb64(blob.data));
	return JSON.parse(new TextDecoder().decode(pt));
}
/** Bản lưu xuống ổ: bỏ nội dung, thay bằng khối mã hoá. */
async function sealDoc(doc, key) {
	const { pages, fields, tags, enc: _old, ...meta } = doc;
	const secret = {
		pages,
		...fields ? { fields } : {},
		...tags ? { tags } : {}
	};
	return {
		...meta,
		pages: [],
		enc: await encryptJson(key, secret)
	};
}
async function openDoc(doc, key) {
	if (!doc.enc) return doc;
	const { enc, ...meta } = doc;
	const s = await decryptJson(key, enc);
	return {
		...meta,
		...s
	};
}
var current = null;
var getVaultKey = () => current;
var setVaultKey = (k) => {
	current = k;
};
async function newDataKey() {
	return crypto.subtle.generateKey({
		name: "AES-GCM",
		length: 256
	}, true, ["encrypt", "decrypt"]);
}
async function wrapDataKey(dek, kek) {
	return encryptJson(kek, b64(new Uint8Array(await crypto.subtle.exportKey("raw", dek))));
}
/** Ném lỗi khi sai PIN/mã khôi phục. */
async function unwrapDataKey(blob, kek) {
	const raw = await decryptJson(kek, blob);
	return crypto.subtle.importKey("raw", unb64(raw), "AES-GCM", true, ["encrypt", "decrypt"]);
}
var RC = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
/** Mã khôi phục 24 ký tự (≈120 bit), dạng XXXX-XXXX-…; chỉ hiện một lần. */
function newRecoveryCode() {
	const r = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(24));
	return Array.from(r, (b) => RC[b % 32]).join("").replace(/(.{4})(?=.)/g, "$1-");
}
var normRecovery = (c) => c.toUpperCase().replace(/[^A-Z0-9]/g, "");
/** Niêm phong rồi mở thử lại trước khi ghi: không bao giờ thay bản rõ bằng bản mã hỏng. */
async function sealVerified(doc, key) {
	const sealed = await sealDoc(doc, key);
	const back = await openDoc(sealed, key);
	if (JSON.stringify(back.pages) !== JSON.stringify(doc.pages)) throw new Error("Kiểm tra mã hoá không khớp");
	return sealed;
}
//#endregion
export { newDataKey as a, normRecovery as c, sealVerified as d, setVaultKey as f, wrapDataKey as h, getVaultKey as i, openDoc as l, vault_CuGqX6h0_exports as m, deriveKey as n, newRecoveryCode as o, unwrapDataKey as p, encryptJson as r, newSalt as s, decryptJson as t, sealDoc as u };
