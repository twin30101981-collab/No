import { w as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { N as RotateCcw, f as Trash2, nn as ArrowLeft } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./app-shell-CZvf2xHx.mjs";
import { D as useDocs, S as restoreDocs, l as leftLabel, y as purgeDocs } from "./db-CclUQaLE.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { n as confirmDialog } from "./dialog-IcUxZaUZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/trash-C6O_iLO-.js
var import_jsx_runtime = require_jsx_runtime();
function TrashPage() {
	const { trash, ready } = useDocs();
	const items = [...trash].sort((a, b) => (b.deletedAt ?? 0) - (a.deletedAt ?? 0));
	async function purge(ids, label) {
		if (!await confirmDialog(label, {
			message: "Không thể khôi phục sau khi xóa hẳn.",
			okText: "Xóa hẳn",
			danger: true
		})) return;
		await purgeDocs(ids);
		toast(`Đã xóa hẳn ${ids.length} tài liệu`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Thùng rác",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/me",
			"aria-label": "Về trang Tôi",
			className: "grid size-10 place-items-center rounded-full",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "space-y-3 px-5 pb-28 pt-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						"Tài liệu đã xóa được giữ ",
						30,
						" ngày rồi tự xóa hẳn."
					]
				}),
				items.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: async () => {
							const ids = items.map((d) => d.id);
							await restoreDocs(ids);
							toast(`Đã khôi phục ${ids.length} tài liệu`);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), " Khôi phục tất cả"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						className: "text-destructive",
						onClick: () => purge(items.map((d) => d.id), `Dọn sạch ${items.length} tài liệu?`),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Dọn sạch"]
					})]
				}),
				ready && !items.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "document-row rounded-[16px] p-6 text-center text-sm text-muted-foreground",
					children: "Thùng rác trống"
				}),
				items.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "document-row flex items-center gap-3 rounded-[16px] p-3",
					children: [
						d.pages[0] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: d.pages[0].thumb ?? d.pages[0].src,
							alt: "",
							className: "size-12 shrink-0 rounded-[10px] object-cover opacity-70"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-semibold",
								children: d.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									d.pages.length,
									" trang · ",
									leftLabel(d.deletedAt)
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Khôi phục",
							onClick: async () => {
								await restoreDocs([d.id]);
								toast("Đã khôi phục", { description: d.name });
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Xóa hẳn",
							className: "text-destructive",
							onClick: () => purge([d.id], `Xóa hẳn “${d.name}”?`),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
						})
					]
				}, d.id))
			]
		})
	});
}
//#endregion
export { TrashPage as component };
