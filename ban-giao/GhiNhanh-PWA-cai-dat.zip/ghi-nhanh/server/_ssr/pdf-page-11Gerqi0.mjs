//#region node_modules/.nitro/vite/services/ssr/assets/pdf-page-11Gerqi0.js
var PDF_PAPER_LABEL = {
	fit: "Khớp ảnh",
	a4: "A4 có lề",
	letter: "Letter có lề"
};
/** Giấy chuẩn (mm, cạnh ngắn × cạnh dài). A5 cùng tỉ lệ A4 → không phân biệt được theo tỉ lệ, chọn A4. */
var STD = [
	{
		name: "A4",
		s: 210,
		l: 297
	},
	{
		name: "Letter",
		s: 215.9,
		l: 279.4
	},
	{
		name: "Legal",
		s: 215.9,
		l: 355.6
	},
	{
		name: "Thẻ",
		s: 54,
		l: 85.6
	}
];
/** Sai lệch tỉ lệ tối đa để nhận là giấy chuẩn (snapAspect dùng 6 % khi nắn; ảnh đã nắn rơi đúng tỉ lệ). */
var TOL = .03;
/** Khổ trang khớp ảnh cho ảnh w×h px. */
function fitFormat(w, h) {
	const long = Math.max(w, h), r = long / Math.max(1, Math.min(w, h));
	let best = null, bestD = TOL;
	for (const p of STD) {
		const d = Math.abs(r - p.l / p.s) / (p.l / p.s);
		if (d < bestD) {
			bestD = d;
			best = p;
		}
	}
	const dpi = long / (best ? best.l : 297) * 25.4;
	const k = 25.4 / dpi;
	return {
		wMm: w * k,
		hMm: h * k,
		dpi: Math.round(dpi),
		paper: best ? best.name : "Tự do"
	};
}
/** Kích thước ảnh JPEG/PNG từ phần đầu tệp (không giải mã). null = không đọc được. exif = JPEG có khối EXIF (có thể xoay
*  theo Orientation → cỡ hiển thị khác cỡ lưu; nơi gọi không đưa nguyên byte vào PDF). */
function imageSize(b) {
	if (b.length > 24 && b[0] === 137 && b[1] === 80 && b[2] === 78 && b[3] === 71) {
		const v = new DataView(b.buffer, b.byteOffset, b.byteLength);
		return {
			w: v.getUint32(16),
			h: v.getUint32(20),
			fmt: "PNG"
		};
	}
	if (b[0] !== 255 || b[1] !== 216) return null;
	let i = 2, exif = false;
	while (i + 9 < b.length) {
		if (b[i] !== 255) {
			i++;
			continue;
		}
		const m = b[i + 1];
		if (m === 255) {
			i++;
			continue;
		}
		if (m === 216 || m === 1 || m >= 208 && m <= 215) {
			i += 2;
			continue;
		}
		const len = b[i + 2] << 8 | b[i + 3];
		if (m === 225 && b[i + 4] === 69 && b[i + 5] === 120 && b[i + 6] === 105 && b[i + 7] === 102) exif = true;
		if (m >= 192 && m <= 207 && m !== 196 && m !== 200 && m !== 204) return {
			h: b[i + 5] << 8 | b[i + 6],
			w: b[i + 7] << 8 | b[i + 8],
			fmt: "JPEG",
			exif
		};
		i += 2 + len;
	}
	return null;
}
/** Chuỗi DPI cho siêu dữ liệu: "200 dpi" hoặc "150–200 dpi". */
function dpiSummary(dpis) {
	if (!dpis.length) return "";
	const lo = Math.min(...dpis), hi = Math.max(...dpis);
	return lo === hi ? `${lo} dpi` : `${lo}–${hi} dpi`;
}
/** Siêu dữ liệu PDF (QP-08): tiêu đề, chủ đề (số trang + DPI thật), ứng dụng, từ khoá máy đọc được. */
function pdfProperties(name, dpis, paper) {
	const n = dpis.length, dpi = dpiSummary(dpis);
	return {
		title: name?.trim() || "Ghi Nhanh",
		subject: `${n} trang · ${dpi}${paper === "fit" ? " · khổ khớp ảnh" : ` · ${PDF_PAPER_LABEL[paper]}`}`,
		creator: "Ghi Nhanh",
		keywords: `dpi=${dpis.join(",")}`
	};
}
//#endregion
export { PDF_PAPER_LABEL, fitFormat, imageSize, pdfProperties };
