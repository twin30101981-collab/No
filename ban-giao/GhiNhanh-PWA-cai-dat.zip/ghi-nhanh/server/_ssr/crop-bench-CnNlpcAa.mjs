import { n as init_performance, r as performance_default } from "../_libs/canvg+[...].mjs";
import { h as detectPaperGray } from "./image-DFWRNlNd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/crop-bench-CnNlpcAa.js
init_performance();
/** Bộ sinh số giả ngẫu nhiên cố định để bộ mẫu lần nào cũng giống nhau. */
function rng(seed) {
	let s = seed >>> 0 || 1;
	return () => {
		s ^= s << 13;
		s ^= s >>> 17;
		s ^= s << 5;
		return (s >>> 0) % 1e5 / 1e5;
	};
}
var inside = (q, x, y) => {
	let c = false;
	for (let i = 0, j = 3; i < 4; j = i++) {
		const [xi, yi] = q[i], [xj, yj] = q[j];
		if (yi > y !== yj > y && x < (xj - xi) * (y - yi) / (yj - yi) + xi) c = !c;
	}
	return c;
};
function makeSample(name, o, seed, w = 300, h = 400) {
	const r = rng(seed);
	const cx = w / 2 + o.dx * w, cy = h / 2 + o.dy * h;
	const pw = w * o.scale * .5, ph = pw * 1.414;
	const c = Math.cos(o.rot), s = Math.sin(o.rot);
	const q = [
		[-pw / 2, -ph / 2],
		[pw / 2, -ph / 2],
		[pw / 2, ph / 2],
		[-pw / 2, ph / 2]
	].map(([x, y], i) => {
		const xx = x * (i < 2 ? 1 - o.persp : 1);
		return [cx + xx * c - y * s, cy + xx * s + y * c];
	});
	const g = new Float32Array(w * h);
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		let v = o.bg;
		if (o.clutter && ((x >> 4) + (y >> 4)) % 2 === 0) v += 18;
		if (inside(q, x + .5, y + .5)) {
			v = o.paper;
			if (o.text && y % 14 < 3 && Math.abs(x - cx) < pw * .3 && Math.abs(y - cy) < ph * .35) v -= 120;
		}
		if (o.shadow) v *= 1 - o.shadow * Math.max(0, (x - w * .55) / (w * .45));
		v += (r() - .5) * 2 * o.noise;
		g[y * w + x] = Math.max(0, Math.min(255, v));
	}
	return {
		name,
		gray: g,
		w,
		h,
		truth: q.map(([x, y]) => [x / w, y / h])
	};
}
/** 24 mẫu: nền tối/sáng/rối, giấy xoay, phối cảnh, nhiễu, bóng, chữ. */
function sampleSet() {
	const d = {
		bg: 50,
		paper: 225,
		noise: 6,
		rot: 0,
		persp: 0,
		scale: 1.3,
		shadow: 0,
		text: true,
		clutter: false,
		dx: 0,
		dy: 0
	};
	return [
		["thẳng, nền tối", {}],
		["không chữ", { text: false }],
		["nhỏ", { scale: 1 }],
		["lớn", { scale: 1.5 }],
		["xoay 5°", { rot: .087 }],
		["xoay -8°", { rot: -.14 }],
		["xoay 12°", { rot: .21 }],
		["xoay -15°", { rot: -.26 }],
		["phối cảnh nhẹ", { persp: .08 }],
		["phối cảnh mạnh", { persp: .18 }],
		["phối cảnh + xoay", {
			persp: .12,
			rot: .1
		}],
		["lệch trái", { dx: -.06 }],
		["nhiễu nhiều", { noise: 22 }],
		["nhiễu + xoay", {
			noise: 16,
			rot: -.1
		}],
		["nền xám", { bg: 110 }],
		["tương phản thấp", {
			bg: 140,
			paper: 215
		}],
		["bóng nhẹ", { shadow: .25 }],
		["bóng đậm", { shadow: .45 }],
		["nền rối", { clutter: true }],
		["nền rối + xoay", {
			clutter: true,
			rot: .12
		}],
		["giấy ngả màu", { paper: 190 }],
		["lệch lên", { dy: -.05 }],
		["nền sáng", {
			bg: 160,
			paper: 245
		}],
		["tổng hợp khó", {
			noise: 14,
			rot: .15,
			persp: .1,
			shadow: .3
		}]
	].map(([n, p], i) => makeSample(n, {
		...d,
		...p
	}, 1e3 + i));
}
/** Lệch góc lớn nhất (theo tỉ lệ đường chéo ảnh) giữa hai khung. */
function cornerError(a, b, w, h) {
	const diag = Math.hypot(w, h);
	let worst = 0;
	for (let i = 0; i < 4; i++) worst = Math.max(worst, Math.hypot((a[i][0] - b[i][0]) * w, (a[i][1] - b[i][1]) * h) / diag);
	return worst;
}
function runBench(samples = sampleSet(), tol = .03, detect = detectPaperGray) {
	const t0 = performance_default.now();
	const results = samples.map((s) => {
		const d = detect(s.gray, s.w, s.h);
		if (!d) return {
			name: s.name,
			ok: false,
			error: 1,
			found: false
		};
		const error = cornerError(d.quad, s.truth, s.w, s.h);
		return {
			name: s.name,
			ok: error <= tol,
			error,
			found: true
		};
	});
	const correct = results.filter((r) => r.ok).length;
	return {
		total: results.length,
		correct,
		rate: results.length ? correct / results.length : 0,
		meanError: results.reduce((x, r) => x + r.error, 0) / (results.length || 1),
		ms: performance_default.now() - t0,
		results
	};
}
/** G3-22 — So bộ dò cơ bản (cũ, một lượt) với bộ dò bền (mới: thêm bản kéo giãn + bù sáng) trên cùng bộ mẫu G2. */
function compareBench(samples = sampleSet(), tol = .03) {
	const old = runBench(samples, tol, (g, w, h) => detectPaperGray(g, w, h, false));
	const cur = runBench(samples, tol, (g, w, h) => detectPaperGray(g, w, h, true));
	const better = [], worse = [];
	cur.results.forEach((r, i) => {
		const o = old.results[i];
		if (r.ok && !o.ok) better.push(r.name);
		if (!r.ok && o.ok) worse.push(r.name);
	});
	return {
		old,
		cur,
		better,
		worse
	};
}
//#endregion
export { cornerError as n, compareBench as t };
