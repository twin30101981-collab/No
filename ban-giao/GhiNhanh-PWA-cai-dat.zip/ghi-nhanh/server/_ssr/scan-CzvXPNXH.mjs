import { o as __toESM } from "../_runtime.mjs";
import { n as init_performance, r as performance_default } from "../_libs/canvg+[...].mjs";
import { T as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as require_react, E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as toast } from "../_libs/sonner.mjs";
import { a as userMessage, i as showError } from "./errors-DKvrPJ4v.mjs";
import { N as RotateCcw, Nt as ExternalLink, Rt as Crop, Ut as ClipboardPaste, X as LoaderCircle, Xt as Check, b as Sparkles, mt as Grid3x3, n as ZapOff, nt as Layers, ot as ImagePlus, p as Timer, r as X, t as Zap, zt as Copy } from "../_libs/lucide-react.mjs";
import { i as fpOf, l as unpackDoc, n as blobFor, o as packDoc } from "./disk-pack-ZdDKsocx.mjs";
import { n as getSettings, o as setSettings } from "./settings-DDlMLZCe.mjs";
import { C as saveDoc, D as useDocs, E as uid, d as mutateDoc, m as newPage, p as newDoc } from "./db-CclUQaLE.mjs";
import { r as setScanActive } from "./priority-gate-CeFvd7IG.mjs";
import { c as recordPerf, d as timed } from "./perf-stats-C5jrVSN8.mjs";
import { r as logScan } from "./scan-log-DnWLrMlu.mjs";
import { t as Button } from "./button-BbbVcZ3W.mjs";
import { n as runInPool, t as poolCanvasSupported } from "./worker-pool-DW9Ak2AM.mjs";
import { A as loadImg, F as releaseRenderCache, G as splitBook, I as renderPage, J as tilt, L as renderPageUrl, N as normalizeUrl, P as refineQuadOnSrc, T as glare, V as sharpness, _ as detectQuadInfo, b as detectVideoFrameAsync, c as composeIdCard, f as detectFrameAsync, k as lastSampleMs, q as targetLong, r as PREVIEW_LONG, v as detectQuadScoredAsync, z as renderQuickUrl } from "./image-DFWRNlNd.mjs";
import { n as machineLanes } from "./machine-lanes-xhX0UZ2n.mjs";
import { a as pipelineEnabled, n as bgQueue, r as finishedStore, s as startPipeline, t as applyFinished } from "./runner-CZAn6hg6.mjs";
import { n as confirmDialog } from "./dialog-IcUxZaUZ.mjs";
import { a as IMAGE_ACCEPT, c as imageBlob, d as readClipboardImages, n as pickFiles, s as expandImageFiles } from "./importer-BUHDogNt.mjs";
import { i as meanLumaRGBA, r as lightLevel, t as QUALITY_THRESHOLDS } from "./quality-B8m69IKS.mjs";
import { t as EDGE_WARNING } from "./batch-review-Be3azLyj.mjs";
import { gradeCache, gradeOf, postCaptureWithMetrics } from "./post-capture-metrics-X7ExzflM.mjs";
import { t as pmapOrdered } from "./pmap-BY7K0bZd.mjs";
import { n as previewSize } from "./preview-src-DrbqV_z6.mjs";
import { t as makeThumb } from "./thumbs-Bxe3hgYK.mjs";
import { t as CropEditor } from "./crop-editor-CWKLJmf0.mjs";
import { t as useImagePaste } from "./use-image-paste-FdMZgoID.mjs";
import { n as Route, t as MODES } from "./scan-Csud2Qvt.mjs";
import { t as readCode } from "./qr-ByGtmulG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scan-CzvXPNXH.js
init_performance();
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PHOTO_TIMEOUT_MS = 1200;
var cache = /* @__PURE__ */ new WeakMap();
/** Một ImageCapture cho mỗi track; null nếu thiết bị không hỗ trợ (vd iOS Safari) hoặc đã lỗi. */
function getImageCapture(track, Ctor = globalThis.ImageCapture) {
	if (cache.has(track)) return cache.get(track);
	let ic = null;
	try {
		ic = Ctor ? new Ctor(track) : null;
	} catch {
		ic = null;
	}
	cache.set(track, ic);
	return ic;
}
/** Đánh dấu track không dùng được takePhoto → các lần sau đi thẳng khung hình video. */
function disableImageCapture(track) {
	cache.set(track, null);
}
function withTimeout(p, ms) {
	return new Promise((res, rej) => {
		const t = setTimeout(() => rej(/* @__PURE__ */ new Error("timeout")), ms);
		p.then((v) => {
			clearTimeout(t);
			res(v);
		}, (e) => {
			clearTimeout(t);
			rej(e);
		});
	});
}
var FrameRing = class {
	size;
	maxAgeMs;
	items = [];
	constructor(size = 3, maxAgeMs = 1500) {
		this.size = size;
		this.maxAgeMs = maxAgeMs;
	}
	get length() {
		return this.items.length;
	}
	push(frame, score, at = performance_default.now()) {
		this.items.push({
			frame,
			score,
			at
		});
		while (this.items.length > this.size) this.items.shift().frame.close?.();
	}
	/** Lấy ra (chuyển quyền sở hữu) khung nét nhất còn mới; khung khác vẫn trong vòng. */
	takeBest(now = performance_default.now()) {
		let bi = -1;
		this.items.forEach((it, i) => {
			if (now - it.at <= this.maxAgeMs && (bi < 0 || it.score > this.items[bi].score)) bi = i;
		});
		return bi < 0 ? null : this.items.splice(bi, 1)[0].frame;
	}
	clear() {
		for (const it of this.items) it.frame.close?.();
		this.items = [];
	}
};
/** Số ảnh burst: 1 khi FocusGate đã "sharp" hoặc đã có vòng đệm, 3 khi chưa đủ nét (ảnh thường/QR luôn 1). */
function burstCount(mode, focus, ringReady = false) {
	if (ringReady || mode === "photo" || mode === "qr") return 1;
	return focus === "sharp" ? 1 : 3;
}
var VF_INITIAL = {
	quad: null,
	tip: "none",
	focus: 0,
	focusScore: 0
};
/** Lượng tử hoá quad (≈0,3% khung) để rung nhỏ không gây vẽ lại. */
var Q = .003;
function sameQuad(a, b) {
	if (a === b) return true;
	if (!a || !b) return false;
	for (let i = 0; i < 4; i++) if (Math.abs(a[i][0] - b[i][0]) > Q || Math.abs(a[i][1] - b[i][1]) > Q) return false;
	return true;
}
/** Điểm nét hiển thị làm tròn theo bậc 10 — số nhảy liên tục không cần vẽ lại từng khung. */
var bucket = (n) => Math.round(n / 10) * 10;
/** Trả về đúng `prev` khi không có gì đổi đáng kể → React bỏ qua lần vẽ lại. */
function mergeViewfinder(prev, patch) {
	const quad = patch.quad !== void 0 ? patch.quad : prev.quad;
	const tip = patch.tip ?? prev.tip;
	const focus = patch.focus !== void 0 ? Math.round(patch.focus * 20) / 20 : prev.focus;
	const focusScore = patch.focusScore !== void 0 ? bucket(patch.focusScore) : prev.focusScore;
	if (sameQuad(prev.quad, quad) && tip === prev.tip && focus === prev.focus && focusScore === prev.focusScore) return prev;
	return {
		quad: sameQuad(prev.quad, quad) ? prev.quad : quad,
		tip,
		focus,
		focusScore
	};
}
function useViewfinder() {
	const [vf, setVf] = (0, import_react.useState)(VF_INITIAL);
	const ref = (0, import_react.useRef)(vf);
	ref.current = vf;
	return {
		vf,
		vfRef: ref,
		update: (0, import_react.useCallback)((patch) => setVf((p) => mergeViewfinder(p, patch)), [])
	};
}
var defaultEnv = () => ({
	raf: (cb) => requestAnimationFrame(cb),
	caf: (h) => cancelAnimationFrame(h),
	now: () => performance_default.now()
});
/**
* Gọi `tick` theo khung hình thật của camera (requestVideoFrameCallback), dự phòng rAF.
* `minGap` giữ nhịp tối thiểu giữa hai lần xử lý (số, hoặc hàm đọc lại mỗi khung — CS-03b); tick tự bỏ khung khi Worker còn bận.
*/
function onCameraFrames(video, tick, minGap = 66, env = defaultEnv()) {
	let alive = true, handle = 0, last = -Infinity;
	const useVfc = typeof video.requestVideoFrameCallback === "function";
	const loop = () => {
		if (!alive) return;
		const t = env.now();
		if (t - last >= (typeof minGap === "function" ? minGap() : minGap)) {
			last = t;
			try {
				tick();
			} catch {}
		}
		handle = useVfc ? video.requestVideoFrameCallback(loop) : env.raf(loop);
	};
	handle = useVfc ? video.requestVideoFrameCallback(loop) : env.raf(loop);
	return () => {
		alive = false;
		if (useVfc) video.cancelVideoFrameCallback?.(handle);
		else env.caf(handle);
	};
}
/**
* CS-03b: nhịp ngắm theo sức máy. Mỗi nhịp tốn thời gian luồng chính (lấy mẫu khung, ảnh vòng đệm, khung nhỏ); máy yếu
* (CPU 6×) tốn ~100 ms/nhịp → nhịp 120 ms chiếm gần hết luồng chính, cú bấm Chụp phải chờ. Giữ phần luồng chính của vòng
* ngắm ≤ 1/5: khoảng cách = max(base, 5 × chi phí trung bình trượt), trần 600 ms. Máy nhanh (≤ 24 ms/nhịp) giữ nguyên base.
*/
var FramePacer = class {
	base;
	factor;
	cap;
	ema = 0;
	constructor(base = 120, factor = 5, cap = 600) {
		this.base = base;
		this.factor = factor;
		this.cap = cap;
	}
	/** Ghi thời gian luồng chính (ms) của một nhịp. */
	cost(ms) {
		if (Number.isFinite(ms) && ms >= 0) this.ema = this.ema ? this.ema * .7 + ms * .3 : ms;
	}
	gap() {
		return Math.min(this.cap, Math.max(this.base, this.ema * this.factor));
	}
};
/**
* V8: hàng đợi song song có thứ tự — tối đa `lanes` việc nặng chạy cùng lúc,
* nhưng bước ghi kết quả (commit) luôn theo đúng thứ tự gửi vào. Lỗi một việc không chặn việc sau.
* B06: áp lực ngược — khi số việc đang chờ vượt `maxWaiting`, push() từ chối ngay
* để không chất đống ảnh lớn trong bộ nhớ trên máy yếu.
*/
var OrderedLanes = class {
	lanes;
	maxWaiting;
	running = 0;
	waiting = [];
	tail = Promise.resolve();
	peak = 0;
	/** lanes có thể là hàm (đổi theo lúc): chờ làn trống, kiểm lại mỗi 150 ms. */
	constructor(lanes, maxWaiting = 0) {
		this.lanes = lanes;
		this.maxWaiting = maxWaiting;
	}
	cap() {
		return Math.max(1, typeof this.lanes === "function" ? this.lanes() : this.lanes);
	}
	async slot() {
		while (this.running >= this.cap()) await new Promise((r) => {
			this.waiting.push(r);
			setTimeout(r, 150);
		});
		this.running++;
		this.peak = Math.max(this.peak, this.running);
	}
	free() {
		this.running--;
		this.waiting.shift()?.();
	}
	/** Trả về promise xong khi commit của việc này chạy xong. Từ chối (reject) khi hàng chờ đầy (B06). */
	push(work, commit, onError) {
		if (this.maxWaiting > 0 && this.waiting.length >= this.maxWaiting) {
			const err = /* @__PURE__ */ new Error("OrderedLanes: hàng chờ đầy (backpressure)");
			onError?.(err);
			return Promise.reject(err);
		}
		const res = (async () => {
			await this.slot();
			try {
				return await work();
			} finally {
				this.free();
			}
		})();
		res.catch(() => {});
		const done = this.tail.then(async () => {
			try {
				await commit(await res);
			} catch (e) {
				onError?.(e);
			}
		});
		this.tail = done;
		return done;
	}
	/** Promise xong khi mọi việc đã gửi đều commit xong. */
	idle() {
		return this.tail;
	}
};
/** B06: số làn co theo sức máy — RAM ≤ 4 GB chỉ 1–2 làn, máy mạnh tối đa min(4, cores/2). */
function renderLanes(cores) {
	return machineLanes(cores);
}
/** B2 – Chụp độ phân giải cao, giữ ảnh gốc. */
var CAPTURE_MAX = 2560;
var CAPTURE_Q = .88;
/** Ràng buộc camera thử lần lượt: V13-B02: 2560×1920 trước (≈ 219 dpi A4, ít hơn ~60% điểm ảnh so với 4K), hạ dần khi máy không hỗ trợ. */
function cameraTries() {
	return [
		{
			facingMode: { ideal: "environment" },
			width: { ideal: 2560 },
			height: { ideal: 1920 }
		},
		{
			facingMode: { ideal: "environment" },
			width: { ideal: 1920 },
			height: { ideal: 1440 }
		},
		{
			facingMode: { ideal: "environment" },
			width: { ideal: 1280 },
			height: { ideal: 960 }
		},
		{ facingMode: "environment" },
		{}
	];
}
/** Thu khung RGBA về lưới xám SIG×SIG (trung bình khối), đã chuẩn hoá độ sáng trung bình. */
function frameSignature(data, w, h, size = 24) {
	const sum = new Float64Array(size * size);
	const cnt = new Uint32Array(size * size);
	const step = Math.max(1, Math.floor(Math.min(w, h) / (size * 4)));
	for (let y = 0; y < h; y += step) {
		const gy = Math.min(size - 1, Math.floor(y * size / h));
		for (let x = 0; x < w; x += step) {
			const gx = Math.min(size - 1, Math.floor(x * size / w));
			const i = (y * w + x) * 4;
			sum[gy * size + gx] += .299 * data[i] + .587 * data[i + 1] + .114 * data[i + 2];
			cnt[gy * size + gx]++;
		}
	}
	const out = new Float32Array(size * size);
	let mean = 0;
	for (let k = 0; k < out.length; k++) {
		out[k] = cnt[k] ? sum[k] / cnt[k] : 0;
		mean += out[k];
	}
	mean /= out.length;
	for (let k = 0; k < out.length; k++) out[k] = out[k] - mean + 128;
	return out;
}
/** Khác biệt trung bình tuyệt đối giữa hai chữ ký (0..255). */
function signatureDiff(a, b) {
	const n = Math.min(a.length, b.length);
	if (!n) return 255;
	let s = 0;
	for (let k = 0; k < n; k++) s += Math.abs(a[k] - b[k]);
	return s / n;
}
var DEFAULT_DETECT = {
	motion: 12,
	still: 4,
	stableFrames: 6,
	newPage: 10
};
/**
* Máy trạng thái: mỗi khung gọi push(sig).
* Trả "capture" đúng một lần khi khung đã đứng yên đủ lâu và khác trang chụp gần nhất.
*/
var PageDetector = class {
	opt;
	prev = null;
	last = null;
	still = 0;
	armed = true;
	constructor(opt = DEFAULT_DETECT) {
		this.opt = opt;
	}
	/** ready=false: khung chưa đạt điều kiện khác (mờ, lóa, chưa khớp mép) — không chụp, giữ lượt chờ. */
	push(sig, ready = true) {
		const prev = this.prev;
		this.prev = sig;
		if (!prev) return "idle";
		const d = signatureDiff(prev, sig);
		if (d > this.opt.motion) {
			this.still = 0;
			this.armed = true;
			return "moving";
		}
		if (d >= this.opt.still) {
			this.still = 0;
			return this.armed ? "settling" : "idle";
		}
		this.still++;
		if (!this.armed) return "idle";
		if (this.still < this.opt.stableFrames || !ready) return "settling";
		if (this.last && signatureDiff(this.last, sig) <= this.opt.newPage) {
			this.armed = false;
			return "idle";
		}
		this.last = sig;
		this.armed = false;
		this.still = 0;
		return "capture";
	}
	/** Gọi khi người dùng chụp tay, để không chụp trùng trang đó. */
	markCaptured(sig) {
		this.last = sig;
		this.armed = false;
		this.still = 0;
	}
	reset() {
		this.prev = this.last = null;
		this.still = 0;
		this.armed = true;
	}
};
var DEFAULT_FOCUS = {
	floor: 20,
	relative: .8,
	window: 16,
	stable: 3,
	warmup: 5
};
/** Cổng độ nét: mỗi khung gọi push(score). ok=true khi đủ nét ổn định. */
var FocusGate = class {
	opt;
	hist = [];
	run = 0;
	constructor(opt = DEFAULT_FOCUS) {
		this.opt = opt;
	}
	push(score) {
		const h = this.hist;
		h.push(score);
		if (h.length > this.opt.window) h.shift();
		const peak = Math.max(...h);
		const warm = h.length >= this.opt.warmup;
		const level = score < this.opt.floor ? .3 * score / this.opt.floor : peak > 0 ? Math.min(1, score / peak) * (warm ? 1 : .5) : 0;
		const sharp = score >= this.opt.floor && score >= peak * this.opt.relative;
		this.run = sharp ? this.run + 1 : 0;
		const ok = this.run >= this.opt.stable && h.length >= this.opt.warmup;
		return {
			state: !sharp ? score < this.opt.floor ? "blur" : "focusing" : ok ? "sharp" : "focusing",
			ok,
			level
		};
	}
	/** Ảnh đã chụp có đạt so với đỉnh khung sống không (dùng sau chụp). */
	accept(score, ratio = .6) {
		const peak = Math.max(0, ...this.hist);
		return score >= this.opt.floor && (peak === 0 || score >= peak * ratio);
	}
	/** Sau mỗi lần chụp: bắt đầu đếm lại nhưng giữ đỉnh nét đã biết (tránh coi khung mờ là đỉnh). */
	restart() {
		this.run = 0;
	}
	reset() {
		this.hist = [];
		this.run = 0;
	}
};
/**
* Kích thước bản dò cho nhịp kế tiếp.
* - Đã khoá khung (steady) → về 320 cho nhẹ.
* - Mất khung ≥ LIVE_DETECT_ESCALATE_MISS nhịp → tăng LIVE_DETECT_STEP, trần 480.
* - Còn lại giữ nguyên.
*/
function nextDetectSize(cur, miss, locked) {
	if (locked) return 320;
	if (miss >= 6) return Math.min(480, cur + 80);
	return Math.min(480, Math.max(320, cur));
}
/**
* Cảnh báo quan trọng nhất cho khung hiện tại; null khi chất lượng ổn.
* Thứ tự ưu tiên: lỗi nặng (reject) trước — tối quá, lóa mất chữ, mờ quá;
* rồi lỗi nhẹ (warn) — nghiêng, xa, hơi tối, hơi mờ, hơi lóa.
*/
function captureWarning(m) {
	const T = QUALITY_THRESHOLDS;
	const light = lightLevel(m.luma);
	if (light === "dark") return {
		kind: "dark",
		level: "reject",
		message: "Thiếu sáng nặng — bật đèn hoặc ra chỗ sáng hơn rồi chụp lại"
	};
	if (m.glare > T.GLARE_REJECT) return {
		kind: "glare",
		level: "reject",
		message: "Lóa mạnh — chữ vùng lóa sẽ mất, nghiêng nhẹ máy hoặc đổi góc đèn"
	};
	if (m.sharp < T.BLUR_REJECT) return {
		kind: "blur",
		level: "reject",
		message: "Hình quá mờ — giữ yên máy, chờ lấy nét rồi chụp"
	};
	if (m.tilt > .28) return {
		kind: "tilt",
		level: "warn",
		message: "Máy đang nghiêng — đưa máy song song với tờ giấy"
	};
	if (m.area !== null && m.area < .22) return {
		kind: "closer",
		level: "warn",
		message: "Đưa máy lại gần hơn để chữ đủ lớn"
	};
	if (light === "dim") return {
		kind: "dark",
		level: "warn",
		message: "Hơi thiếu sáng — thêm đèn để chữ rõ hơn"
	};
	if (m.sharp < T.BLUR_WARNING) return {
		kind: "blur",
		level: "warn",
		message: "Hình hơi mờ — giữ chắc tay"
	};
	if (m.glare > T.GLARE_WARNING) return {
		kind: "glare",
		level: "warn",
		message: "Có vùng lóa nhẹ — nghiêng nhẹ máy nếu chữ mờ đi"
	};
	return null;
}
var ctx = null;
function captureCue(opt) {
	if (opt.captureVibrate) navigator.vibrate?.(25);
	if (!opt.captureSound) return;
	try {
		const AC = window.AudioContext ?? window.webkitAudioContext;
		if (!AC) return;
		ctx ??= new AC();
		if (ctx.state === "suspended") ctx.resume();
		const t = ctx.currentTime;
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = "triangle";
		osc.frequency.setValueAtTime(1400, t);
		osc.frequency.exponentialRampToValueAtTime(500, t + .07);
		gain.gain.setValueAtTime(.25, t);
		gain.gain.exponentialRampToValueAtTime(.001, t + .09);
		osc.connect(gain).connect(ctx.destination);
		osc.start(t);
		osc.stop(t + .1);
	} catch {}
}
var VOICE_LINES = {
	none: "Đưa cả tờ giấy vào khung",
	closer: "Đưa máy lại gần hơn",
	found: "Đã thấy giấy, giữ thẳng máy",
	hold: "Giữ yên máy",
	blur: "Hình mờ, giữ yên chờ lấy nét",
	glare: "Bị lóa, nghiêng nhẹ máy",
	tilt: "Máy đang nghiêng, đưa song song với giấy",
	dark: "Thiếu sáng, bật đèn hoặc ra chỗ sáng hơn"
};
/** Rung theo lời nhắc: lỗi = 2 nhịp ngắn, đã khớp = 1 nhịp, không có = không rung. */
var VIBRATE = {
	found: [15],
	hold: [15],
	blur: [
		30,
		60,
		30
	],
	glare: [
		30,
		60,
		30
	],
	tilt: [
		30,
		60,
		30
	],
	dark: [
		30,
		60,
		30
	]
};
var DEF = {
	stableMs: 700,
	gapMs: 2500,
	repeatMs: 8e3
};
/** Chỉ nói khi lời nhắc đứng yên đủ lâu, cách lần nói trước đủ xa, không lặp lại cùng câu quá sớm. */
var ScanGuide = class {
	o;
	cur = null;
	since = 0;
	lastAt = -Infinity;
	lastTip = null;
	lastSaid = /* @__PURE__ */ new Map();
	constructor(o = DEF) {
		this.o = o;
	}
	push(tip, now) {
		if (tip !== this.cur) {
			this.cur = tip;
			this.since = now;
			return null;
		}
		if (now - this.since < this.o.stableMs || now - this.lastAt < this.o.gapMs) return null;
		if (tip === this.lastTip) return null;
		if (now - (this.lastSaid.get(tip) ?? -Infinity) < this.o.repeatMs) return null;
		this.lastAt = now;
		this.lastTip = tip;
		this.lastSaid.set(tip, now);
		return tip;
	}
	/** Sau khi chụp: quên câu cuối để trang tiếp theo được nhắc lại. */
	reset() {
		this.cur = null;
		this.lastTip = null;
		this.lastSaid.clear();
	}
};
function speakTip(tip, opt) {
	if (opt.vibrate) {
		const p = VIBRATE[tip];
		if (p) navigator.vibrate?.(p);
	}
	if (!opt.voice || typeof speechSynthesis === "undefined") return;
	try {
		speechSynthesis.cancel();
		const u = new SpeechSynthesisUtterance(VOICE_LINES[tip]);
		u.lang = "vi-VN";
		u.rate = 1.05;
		const v = speechSynthesis.getVoices().find((x) => x.lang?.toLowerCase().startsWith("vi"));
		if (v) u.voice = v;
		speechSynthesis.speak(u);
	} catch {}
}
function stopSpeaking() {
	try {
		if (typeof speechSynthesis !== "undefined") speechSynthesis.cancel();
	} catch {}
}
/** V13-B04: cỡ ảnh xem trước tức thì (cạnh dài). */
var INSTANT_MAX = 1024;
/** V13-B04: khung chữ nhật bao quad (toạ độ 0..1) + lề nhỏ, kẹp trong ảnh; null nếu quad không hợp lệ/quá nhỏ. */
function quadCrop(quad, w, h, margin = .01) {
	if (!quad || quad.length !== 4 || quad.some((p) => !Number.isFinite(p[0]) || !Number.isFinite(p[1]))) return null;
	const xs = quad.map((p) => p[0]), ys = quad.map((p) => p[1]);
	const x0 = Math.max(0, Math.min(...xs) - margin), x1 = Math.min(1, Math.max(...xs) + margin);
	const y0 = Math.max(0, Math.min(...ys) - margin), y1 = Math.min(1, Math.max(...ys) + margin);
	if (x1 - x0 < .1 || y1 - y0 < .1) return null;
	const sx = Math.round(x0 * w), sy = Math.round(y0 * h);
	return {
		sx,
		sy,
		sw: Math.max(1, Math.round(x1 * w) - sx),
		sh: Math.max(1, Math.round(y1 * h) - sy)
	};
}
/** Đếm đường đã dùng để kiểm chứng (globalThis.__previewStats). */
var previewStats = {
	worker: 0,
	main: 0,
	fallback: 0
};
if (typeof globalThis !== "undefined") globalThis.__previewStats = previewStats;
/** R2.1: thu nhỏ + mã hoá JPEG qua bể Worker chung; trả null khi không chạy được (để rơi về luồng chính). */
async function previewViaWorker(frame, w, h, crop) {
	if (!poolCanvasSupported()) return null;
	try {
		const bmp = await createImageBitmap(frame, crop.sx, crop.sy, crop.sw, crop.sh);
		const p = runInPool("preview", {
			bmp,
			w,
			h
		}, [bmp]);
		if (!p) {
			bmp.close();
			return null;
		}
		const r = await p;
		if (r.blob) {
			previewStats.worker++;
			return r.blob;
		}
	} catch {}
	previewStats.fallback++;
	return null;
}
/** V2: ảnh xem trước tức thì từ khung vừa chụp (≤1200 px), hiện ngay trên dải trang
*  trong lúc bản đầy đủ dựng nền. Không đụng tới đường dựng ảnh cuối.
*  V8b: ưu tiên chạy trong Worker; không có Worker/OffscreenCanvas thì dùng canvas như cũ. */
async function instantPreview(frame, max = INSTANT_MAX, quad) {
	const crop = quadCrop(quad, frame.width, frame.height) ?? {
		sx: 0,
		sy: 0,
		sw: frame.width,
		sh: frame.height
	};
	const sz = previewSize(crop.sw, crop.sh, max);
	const wb = await previewViaWorker(frame, sz.w, sz.h, crop);
	if (wb) return URL.createObjectURL(wb);
	try {
		previewStats.main++;
		const c = document.createElement("canvas");
		c.width = sz.w;
		c.height = sz.h;
		const g = c.getContext("2d");
		if (!g) return void 0;
		g.drawImage(frame, crop.sx, crop.sy, crop.sw, crop.sh, 0, 0, sz.w, sz.h);
		const b = await new Promise((r) => c.toBlob(r, "image/jpeg", .8));
		c.width = 0;
		return b ? URL.createObjectURL(b) : void 0;
	} catch {
		return;
	}
}
var KEY = "current";
var dbp$1 = null;
function idb() {
	if (!dbp$1) dbp$1 = new Promise((res, rej) => {
		const r = indexedDB.open("ghi-nhanh-journal", 1);
		r.onupgradeneeded = () => {
			if (!r.result.objectStoreNames.contains("j")) r.result.createObjectStore("j");
		};
		r.onsuccess = () => res(r.result);
		r.onerror = () => rej(r.error);
	});
	return dbp$1;
}
async function run$1(mode, f) {
	const db = await idb();
	return new Promise((res, rej) => {
		const t = db.transaction("j", mode);
		const q = f(t.objectStore("j"));
		t.oncomplete = () => res(q.result);
		t.onerror = () => rej(t.error);
		t.onabort = () => rej(t.error);
	});
}
/** CS-12: trang trong nhật ký ghi ảnh dạng Blob nhị phân như kho tài liệu (packDoc) — blob: chết sau khi tải lại, data: thì phải giải base64. */
var idbKV = {
	get: async (k) => {
		const j = await run$1("readonly", (s) => s.get(k));
		return j?.pages?.length ? {
			...j,
			pages: (await unpackDoc({ pages: j.pages })).pages
		} : j;
	},
	set: async (k, v) => {
		const disk = v.pages.length ? {
			...v,
			pages: packDoc({ pages: v.pages }).pages
		} : v;
		await run$1("readwrite", (s) => s.put(disk, k));
	},
	del: async (k) => {
		await run$1("readwrite", (s) => s.delete(k));
	}
};
function newJournal(mode, docId) {
	return {
		id: Math.random().toString(36).slice(2, 10) + Date.now().toString(36),
		mode,
		docId,
		pages: [],
		states: {},
		pending: 0,
		updatedAt: Date.now()
	};
}
/** Ghi tuần tự (không ghi chồng lệnh cũ lên lệnh mới) — bản cuối luôn thắng. */
var JournalWriter = class {
	kv;
	chain = Promise.resolve();
	constructor(kv = idbKV) {
		this.kv = kv;
	}
	/** Bản ghi chờ ghi gần nhất. Mỗi bản mang CẢ ảnh mọi trang → 20 lần chụp xếp 20 bản ghi lớn (bình phương) gây nghẽn khi bấm Xong.
	*  CS-04: các lần save dồn lại chỉ ghi bản MỚI NHẤT (bản cuối vẫn luôn thắng). */
	latest = null;
	scheduled = false;
	save(j) {
		this.latest = {
			...j,
			pages: [...j.pages],
			states: { ...j.states },
			updatedAt: Date.now()
		};
		if (!this.scheduled) {
			this.scheduled = true;
			this.chain = this.chain.then(() => {
				this.scheduled = false;
				const snap = this.latest;
				this.latest = null;
				if (!snap) return;
				return snap.pages.length || snap.pending ? this.kv.set(KEY, snap) : this.kv.del(KEY);
			}).catch(() => {});
		}
		return this.chain;
	}
	flush() {
		return this.chain;
	}
	async load() {
		const j = await this.kv.get(KEY).catch(() => void 0);
		return j && !j.committedDocId && j.pages.length ? j : void 0;
	}
	/** Commit nguyên tử: đánh dấu đã commit trước khi xoá; save(docId) cùng id → ghi đè, không trùng. */
	async commit(j, save) {
		const docId = await save(j.id);
		this.latest = null;
		const marker = {
			...j,
			pages: [],
			states: {},
			pending: 0,
			committedDocId: docId,
			updatedAt: Date.now()
		};
		this.chain = this.chain.then(() => this.kv.set(KEY, marker)).then(() => this.kv.del(KEY)).catch(() => {});
		return docId;
	}
	clear() {
		this.chain = this.chain.then(() => this.kv.del(KEY)).catch(() => {});
		return this.chain;
	}
};
var dbp = null;
function open() {
	if (!dbp) {
		dbp = new Promise((resolve, reject) => {
			const r = indexedDB.open("ghi-nhanh-blobs", 1);
			r.onupgradeneeded = () => {
				if (!r.result.objectStoreNames.contains("blobs")) r.result.createObjectStore("blobs", { keyPath: "key" });
			};
			r.onsuccess = () => {
				r.result.onversionchange = () => {
					r.result.close();
					dbp = null;
				};
				resolve(r.result);
			};
			r.onerror = () => reject(r.error);
		});
		dbp.catch(() => {
			dbp = null;
		});
	}
	return dbp;
}
async function run(mode, fn) {
	const db = await open();
	return new Promise((resolve, reject) => {
		const t = db.transaction("blobs", mode);
		const req = fn(t.objectStore("blobs"));
		t.oncomplete = () => resolve(req ? req.result : void 0);
		t.onerror = () => reject(t.error);
		t.onabort = () => reject(t.error);
	});
}
/** Khoá mới cho ảnh gốc của một trang. */
var newBlobKey = (pageId) => `orig:${pageId}:${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
async function putBlob(key, blob) {
	await run("readwrite", (s) => s.put({
		key,
		blob,
		size: blob.size,
		at: Date.now()
	}));
}
/** Prefer a full-sensor still (ImageCapture.takePhoto) over a video frame — 2–4× more pixels and sharper.
*  S6: tái dùng ImageCapture, timeout 1,2 s; lỗi/hết giờ → tắt takePhoto cho track này, dùng khung video. */
async function grabFrame(v, s, ring, maxQuality = false) {
	if (!maxQuality && ring) {
		const b = ring.takeBest();
		if (b) return b;
	}
	const track = s?.getVideoTracks()[0];
	const ic = maxQuality && track ? getImageCapture(track) : null;
	if (track && ic) try {
		const blob = await withTimeout(ic.takePhoto(), PHOTO_TIMEOUT_MS);
		const bmp = await createImageBitmap(blob);
		if (bmp.width * bmp.height > v.videoWidth * v.videoHeight) return bmp;
		bmp.close();
		disableImageCapture(track);
	} catch {
		disableImageCapture(track);
	}
	const c = document.createElement("canvas");
	c.width = v.videoWidth;
	c.height = v.videoHeight;
	c.getContext("2d").drawImage(v, 0, 0);
	return c;
}
/** CS-03: ghi ảnh gốc (data URL) vào kho blob riêng; trả khoá ngay, việc ghi chạy nền (lỗi → bỏ qua, ảnh gốc vẫn nằm trong trang). */
function saveOrigBlob(orig) {
	const key = newBlobKey("p");
	const own = blobFor(orig);
	(own ? Promise.resolve(own) : fetch(orig).then((r) => r.blob())).then((b) => putBlob(key, b)).catch(() => {});
	return key;
}
/** CS-03: khoảng lặng sau lần bấm cuối trước khi chạy việc nặng (chuẩn hoá/dò/dựng) trên luồng chính. */
var QUIET_BEFORE_HEAVY_MS = 450;
function Scan() {
	const search = Route.useSearch();
	const navigate = useNavigate();
	const { docs } = useDocs();
	const video = (0, import_react.useRef)(null);
	const stream = (0, import_react.useRef)(null);
	const [mode, setMode] = (0, import_react.useState)(search.mode ?? "doc");
	const [camError, setCamError] = (0, import_react.useState)(false);
	const { vf, update: updateVf } = useViewfinder();
	const { quad, tip, focus, focusScore } = vf;
	const [pages, setPages] = (0, import_react.useState)([]);
	const [idFront, setIdFront] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [torch, setTorch] = (0, import_react.useState)(false);
	const [grid, setGrid] = (0, import_react.useState)(true);
	const [auto, setAuto] = (0, import_react.useState)(true);
	const [qr, setQr] = (0, import_react.useState)("");
	const [flash, setFlash] = (0, import_react.useState)(false);
	const busyRef = (0, import_react.useRef)(false);
	const detectorRef = (0, import_react.useRef)(null);
	const lastSigRef = (0, import_react.useRef)(null);
	const lastQuad = (0, import_react.useRef)(null);
	const view = (0, import_react.useRef)(null);
	const [review, setReview] = (0, import_react.useState)(null);
	const [unsure, setUnsure] = (0, import_react.useState)(() => /* @__PURE__ */ new Set());
	const unsureRef = (0, import_react.useRef)(unsure);
	unsureRef.current = unsure;
	const reviewRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		reviewRef.current = !!review;
	}, [review]);
	const setTip = (0, import_react.useCallback)((t) => updateVf({ tip: t }), [updateVf]);
	const tipRef = (0, import_react.useRef)(tip);
	tipRef.current = tip;
	const ringRef = (0, import_react.useRef)(new FrameRing(3));
	const sharpRef = (0, import_react.useRef)([]);
	const focusRef = (0, import_react.useRef)(new FocusGate({
		floor: 6,
		relative: .8,
		window: 16,
		stable: 3,
		warmup: 5
	}));
	const focusLevelRef = (0, import_react.useRef)("blur");
	const liveWarnRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setAuto(getSettings().autoCapture);
	}, []);
	(0, import_react.useEffect)(() => {
		setScanActive(true);
		return () => setScanActive(false);
	}, []);
	(0, import_react.useEffect)(() => () => releaseRenderCache(), []);
	const [camTry, setCamTry] = (0, import_react.useState)(0);
	const [camSlow, setCamSlow] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		const t0 = performance_default.now();
		setCamError(false);
		setCamSlow(false);
		if (!navigator.mediaDevices) {
			setCamError(true);
			logScan({
				code: "CAM_UNSUPPORTED",
				message: "Trình duyệt không hỗ trợ camera"
			});
			return;
		}
		const slow = setTimeout(() => {
			if (!video.current?.videoWidth) {
				setCamSlow(true);
				logScan({
					code: "CAM_SLOW",
					message: "Camera chưa sẵn sàng sau 6 giây"
				});
			}
		}, 6e3);
		const tries = cameraTries();
		const attach = (s) => {
			if (cancelled) {
				s.getTracks().forEach((t) => t.stop());
				return;
			}
			stream.current = s;
			const tr = s.getVideoTracks()[0];
			tr?.applyConstraints({ advanced: [{ focusMode: "continuous" }] }).catch(() => {});
			if (tr) tr.onended = () => {
				if (!cancelled) {
					logScan({
						code: "CAM_ENDED",
						message: "Camera bị ngắt, đang mở lại"
					});
					setCamTry((n) => n + 1);
				}
			};
			const v = video.current;
			if (v) {
				v.srcObject = s;
				v.onloadedmetadata = () => logScan({
					code: "CAM_READY",
					message: `${v.videoWidth}x${v.videoHeight}`,
					ms: Math.round(performance_default.now() - t0)
				});
				v.play().catch(() => {});
			}
		};
		(async () => {
			let last;
			for (const c of tries) try {
				attach(await navigator.mediaDevices.getUserMedia({
					video: c,
					audio: false
				}));
				return;
			} catch (e) {
				last = e;
				const n = e.name;
				if (n === "NotAllowedError" || n === "SecurityError") break;
			}
			if (cancelled) return;
			setCamError(true);
			logScan({
				code: "CAM_FAILED",
				message: String(last?.name ?? last)
			});
			showError(last, "Không mở được camera");
		})();
		const onVis = () => {
			if (document.visibilityState !== "visible" || cancelled) return;
			const tr = stream.current?.getVideoTracks()[0];
			if (!tr || tr.readyState === "ended") setCamTry((n) => n + 1);
			else video.current?.play().catch(() => {});
		};
		document.addEventListener("visibilitychange", onVis);
		return () => {
			cancelled = true;
			clearTimeout(slow);
			document.removeEventListener("visibilitychange", onVis);
			stream.current?.getTracks().forEach((t) => {
				t.onended = null;
				t.stop();
			});
		};
	}, [camTry]);
	const process = (0, import_react.useCallback)(async (orig, quadHint, paper) => {
		const pages = await processRaw(orig, quadHint, paper);
		const im = await loadImg(orig).catch(() => null);
		return im ? pages.map((p) => p.orig === orig ? {
			...p,
			origW: im.naturalWidth,
			origH: im.naturalHeight
		} : p) : pages;
	}, [mode]);
	const processRaw = async (orig, quadHint, paper) => {
		const def = getSettings().defaultFilter;
		if (mode === "photo") return [newPage(orig)];
		if (mode === "book") return Promise.all((await splitBook(orig)).map(async (o) => {
			const edit = {
				filter: def,
				rotation: 0,
				brightness: 0,
				contrast: 0
			};
			return newPage(o, await renderPage(o, edit, targetLong(getSettings().quality)), edit);
		}));
		const edit = {
			quad: quadHint ?? void 0,
			paper,
			filter: mode === "whiteboard" ? "auto" : def,
			rotation: 0,
			brightness: 0,
			contrast: 0
		};
		const full = targetLong(getSettings().quality);
		const pre = Math.min(PREVIEW_LONG, full);
		const pg = newPage(orig, await timed("render", async () => (full > 1200 ? await renderQuickUrl(orig, edit, pre) : null) ?? renderPageUrl(orig, edit, pre)), edit);
		if (full > 1200) queueFinish(pg, orig, edit, full);
		return [pg];
	};
	const finishedRef = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const queueFinish = (0, import_react.useCallback)((pg, orig, edit, full) => {
		if (pipelineEnabled()) {
			startPipeline();
			bgQueue.enqueue(pg.id, "finish", {
				orig,
				edit,
				targetLong: full
			});
			return;
		}
		bgQueue.setHandler("finish", async (j) => {
			const src = await timed("finish", () => renderPage(j.payload.orig, j.payload.edit ?? {
				rotation: 0,
				filter: "original",
				brightness: 0,
				contrast: 0
			}, j.payload.targetLong ?? full));
			finishedRef.current.set(j.pageId, src);
			setPages((ps) => ps.map((x) => x.id === j.pageId ? {
				...x,
				src
			} : x));
		});
		bgQueue.enqueue(pg.id, "finish", {
			orig,
			edit,
			targetLong: full
		});
	}, []);
	(0, import_react.useEffect)(() => {
		if (!pipelineEnabled()) return;
		return finishedStore.subscribe((id, src) => {
			finishedRef.current.set(id, src);
			setPages((ps) => ps.map((x) => x.id === id ? {
				...x,
				src
			} : x));
		});
	}, []);
	(0, import_react.useEffect)(() => () => {
		if (!pipelineEnabled()) bgQueue.cancelAll();
	}, []);
	const queueRef = (0, import_react.useRef)(Promise.resolve());
	const lastShotRef = (0, import_react.useRef)(0);
	const lanesRef = (0, import_react.useRef)(new OrderedLanes(() => performance_default.now() - lastShotRef.current < 1500 ? 1 : renderLanes()));
	const [pending, setPending] = (0, import_react.useState)(0);
	const pagesRef = (0, import_react.useRef)(pages);
	pagesRef.current = pages;
	const journalW = (0, import_react.useRef)(new JournalWriter());
	const journalRef = (0, import_react.useRef)(newJournal(mode, search.doc));
	const restoredRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		journalW.current.load().then((j) => {
			restoredRef.current = true;
			if (!j || pagesRef.current.length) return;
			toast(`Còn ${j.pages.length} trang chưa lưu từ lần quét trước`, {
				duration: 15e3,
				action: {
					label: "Khôi phục",
					onClick: () => {
						journalRef.current = j;
						setPages((p) => [...j.pages, ...p]);
						const full = targetLong(getSettings().quality);
						bgQueue.resume().then(() => {
							if (full <= 1200) return;
							for (const pg of j.pages) if (!bgQueue.has(pg.id, "finish") && pg.orig && pg.edit) queueFinish(pg, pg.orig, pg.edit, full);
						});
					}
				},
				cancel: {
					label: "Bỏ",
					onClick: () => {
						journalW.current.clear();
						for (const pg of j.pages) {
							bgQueue.cancelPage(pg.id, "finish");
							finishedStore.delete(pg.id);
						}
					}
				}
			});
		});
	}, [queueFinish]);
	(0, import_react.useEffect)(() => {
		if (!restoredRef.current) return;
		journalRef.current = {
			...journalRef.current,
			pages,
			pending
		};
		journalW.current.save(journalRef.current);
	}, [pages, pending]);
	const [continuous, setContinuousRaw] = (0, import_react.useState)(() => getSettings().continuousCapture !== false);
	const setContinuous = (v) => {
		setContinuousRaw(v);
		setSettings({ continuousCapture: v });
	};
	const [retake, setRetake] = (0, import_react.useState)(null);
	const retakeRef = (0, import_react.useRef)(retake);
	retakeRef.current = retake;
	const putPages = (0, import_react.useCallback)((next) => {
		const at = retakeRef.current;
		if (at === null) {
			setPages((p) => [...p, ...next]);
			return;
		}
		setRetake(null);
		const gone = pagesRef.current[at];
		if (gone) {
			bgQueue.cancelPage(gone.id, "finish");
			finishedRef.current.delete(gone.id);
			finishedStore.delete(gone.id);
		}
		setPages((p) => at < p.length ? [
			...p.slice(0, at),
			...next,
			...p.slice(at + 1)
		] : [...p, ...next]);
		toast.success(`Đã thay trang ${at + 1}`);
	}, []);
	const removePage = (i) => {
		const gone = pagesRef.current[i];
		if (gone) {
			bgQueue.cancelPage(gone.id, "finish");
			finishedRef.current.delete(gone.id);
			finishedStore.delete(gone.id);
		}
		setPages((p) => p.filter((_, k) => k !== i));
		setRetake((r) => r === i ? null : r !== null && r > i ? r - 1 : r);
	};
	const [jobs, setJobs] = (0, import_react.useState)([]);
	const setJob = (id, v) => setJobs((js) => {
		if (!v) {
			for (const j of js) if (j.id === id && j.thumb) URL.revokeObjectURL(j.thumb);
		}
		return v ? js.map((j) => j.id === id ? {
			...j,
			...v
		} : j) : js.filter((j) => j.id !== id);
	});
	/** askReview: "modal" = mở màn cắt ngay (chỉ khi người dùng đang chờ, vd. nhập 1 ảnh); "flag" = thêm trang + đánh dấu "Kiểm mép".
	*  Ảnh chụp xử lý xong ở nền (vài giây sau khi bấm) KHÔNG được bật màn cắt toàn màn hình: nó hiện đúng lúc người dùng
	*  đang bấm nút khác (Đóng/Chụp) nên cú chạm rơi vào "Chụp lại" của màn cắt → mất ảnh, tưởng app treo. */
	const thumbsFor = (0, import_react.useCallback)((next) => {
		for (const pg of next) {
			if (pg.thumb) continue;
			makeThumb(pg.src).then((t) => setPages((ps) => ps.map((x) => x.id === pg.id && !x.thumb ? {
				...x,
				thumb: t,
				thumbKey: fpOf(x.src)
			} : x))).catch(() => {});
		}
	}, []);
	const addOrig = (0, import_react.useCallback)(async (orig, quadHint, askReview = false) => {
		if (mode === "id") {
			if (!idFront) {
				setIdFront(orig);
				toast("Đã chụp mặt trước — lật thẻ để chụp mặt sau");
				return;
			}
			const composed = await composeIdCard(idFront, orig);
			setIdFront(null);
			putPages([newPage(composed)]);
			toast.success("Đã ghép 2 mặt thẻ trên 1 trang A4");
			return;
		}
		const reviewable = !continuous && [
			"doc",
			"whiteboard",
			"passport"
		].includes(mode);
		if (askReview === "modal" && reviewable) {
			setReview({
				orig,
				quad: quadHint ?? null
			});
			return;
		}
		const next = await process(orig, quadHint);
		putPages(next);
		if (askReview === "flag" && [
			"doc",
			"whiteboard",
			"passport"
		].includes(mode)) setUnsure((u) => /* @__PURE__ */ new Set([...u, ...next.map((pg) => pg.id)]));
		thumbsFor(next);
	}, [
		idFront,
		mode,
		process,
		continuous,
		putPages,
		thumbsFor
	]);
	const capture = (0, import_react.useCallback)(async (fromAuto = false) => {
		const v = video.current;
		if (!v || busyRef.current || !v.videoWidth) return;
		if (!fromAuto && lastSigRef.current) detectorRef.current?.markCaptured(lastSigRef.current);
		const tRel = performance_default.now();
		let shot = false;
		busyRef.current = true;
		setBusy(true);
		setFlash(true);
		setTimeout(() => setFlash(false), 140);
		captureCue(getSettings());
		const lw = liveWarnRef.current;
		if (lw && !fromAuto && mode !== "photo" && mode !== "qr") toast.warning(lw.message, lw.level === "reject" ? {
			description: "Ảnh chụp lúc này có thể kém chất lượng — cân nhắc chụp lại.",
			duration: 4e3
		} : { duration: 2500 });
		const jid = uid();
		setJobs((j) => [...j, {
			id: jid,
			state: "queued"
		}]);
		try {
			const maxQ = getSettings().maxQuality;
			const burst = burstCount(mode, focusLevelRef.current, !maxQ && ringRef.current.length > 0);
			let c = null;
			let bestS = -1;
			const t0 = performance_default.now();
			for (let k = 0; k < burst; k++) {
				if (k && performance_default.now() - t0 > 150) break;
				const f = await timed("grab", () => grabFrame(v, stream.current, ringRef.current, maxQ));
				const s = burst > 1 ? sharpness(f, f.width, f.height, lastQuad.current) : 0;
				if (s > bestS) {
					if (c && "close" in c) c.close();
					c = f;
					bestS = s;
				} else if ("close" in f) f.close();
				if (k < burst - 1) await new Promise((r) => setTimeout(r, 40));
			}
			if (!c) {
				setJob(jid, null);
				return;
			}
			shot = true;
			const frame = c;
			const max = CAPTURE_MAX;
			const ref = Math.max(0, ...sharpRef.current);
			const pre = async () => {
				const d1 = mode === "id" || mode === "photo" || mode === "book" ? null : await timed("detect1", () => detectQuadScoredAsync(frame, frame.width, frame.height, 720));
				const q = mode === "id" || mode === "photo" || mode === "book" ? null : d1?.quad ?? lastQuad.current;
				const sure1 = !!d1 && d1.score >= .7;
				if (mode !== "photo" && mode !== "qr" && ref > 0) {
					const got = sharpness(frame, frame.width, frame.height, q);
					if (got < ref * .5 || !focusRef.current.accept(got, .5)) {
						if (fromAuto) {
							setTip("blur");
							toast("Ảnh bị mờ — đã bỏ, giữ chắc tay để chụp lại", { duration: 1800 });
							return null;
						}
						toast.warning("Ảnh có vẻ bị mờ hoặc rung", {
							description: "Giữ chắc tay rồi chụp lại để chữ rõ hơn.",
							duration: 4e3
						});
					}
				}
				if (mode !== "photo" && mode !== "qr" && glare(frame, frame.width, frame.height, q) > .04) toast.warning("Ảnh có vùng bị lóa", {
					description: "Chữ ở vùng lóa có thể mất — nghiêng nhẹ máy rồi chụp lại.",
					duration: 4e3
				});
				return {
					q,
					sure1
				};
			};
			setPending((n) => n + 1);
			lastShotRef.current = performance_default.now();
			const tShow = performance_default.now();
			const shown = instantPreview(frame, void 0, lastQuad.current).then((u) => {
				if (!u) return;
				recordPerf("preview-shown", performance_default.now() - tShow);
				setJobs((js) => js.some((j) => j.id === jid) ? js.map((j) => j.id === jid ? {
					...j,
					thumb: u
				} : j) : (URL.revokeObjectURL(u), js));
			});
			let o;
			const canPre = continuous && !["id", "book"].includes(mode);
			queueRef.current = lanesRef.current.push(async () => {
				await Promise.race([shown.catch(() => {}), new Promise((r) => setTimeout(r, 600))]);
				for (let w = 0; w < 4e3 && performance_default.now() - lastShotRef.current < QUIET_BEFORE_HEAVY_MS; w += 100) await new Promise((r) => setTimeout(r, 100));
				setJob(jid, { state: "running" });
				const p0 = await pre();
				if (!p0) return null;
				const { q, sure1 } = p0;
				o = await timed("normalize", () => normalizeUrl(frame, max, CAPTURE_Q));
				const blobKey = saveOrigBlob(o);
				let quad = q, ask = true;
				if (q && sure1) {
					quad = await timed("detect2", () => refineQuadOnSrc(o, q));
					ask = false;
				} else {
					const info = await timed("detect2", () => detectQuadInfo(o));
					quad = info.quad ?? q;
					ask = !info.sure;
				}
				const pages = canPre ? await process(o, quad) : null;
				return {
					o,
					quad,
					ask,
					pages,
					blobKey
				};
			}, async (r) => {
				try {
					if (!r) {
						setJob(jid, null);
						return;
					}
					if (r.pages) {
						putPages(r.pages);
						thumbsFor(r.pages);
						if (r.ask && [
							"doc",
							"whiteboard",
							"passport"
						].includes(mode)) {
							const ids = r.pages.map((pg) => pg.id);
							setUnsure((u) => /* @__PURE__ */ new Set([...u, ...ids]));
						}
					} else await addOrig(r.o, r.quad, r.ask ? "flag" : false);
					if (r.blobKey) {
						const k = r.blobKey;
						setPages((ps) => ps.map((x) => x.orig === r.o && !x.origBlobKey ? {
							...x,
							origBlobKey: k
						} : x));
					}
					setJob(jid, null);
				} finally {
					if ("close" in frame) frame.close();
					setPending((n) => n - 1);
				}
			}, () => {
				setJob(jid, {
					state: "error",
					orig: o
				});
				toast.error("Không xử lý được một tấm ảnh — bấm Thử lại hoặc chụp lại");
				if ("close" in frame) frame.close();
				setPending((n) => n - 1);
			});
		} finally {
			busyRef.current = false;
			setBusy(false);
			if (shot) recordPerf("release", performance_default.now() - tRel);
		}
	}, [
		addOrig,
		mode,
		continuous,
		process,
		putPages,
		setTip,
		thumbsFor
	]);
	const guideRef = (0, import_react.useRef)(new ScanGuide());
	(0, import_react.useEffect)(() => {
		const st = getSettings();
		if (!st.voiceGuide && !st.guideVibrate || camError || ![
			"doc",
			"whiteboard",
			"passport"
		].includes(mode)) return;
		const g = guideRef.current;
		g.reset();
		const t = setInterval(() => {
			if (busyRef.current || reviewRef.current) {
				g.reset();
				return;
			}
			const said = g.push(tipRef.current, Date.now());
			if (said) {
				const s2 = getSettings();
				speakTip(said, {
					voice: s2.voiceGuide,
					vibrate: s2.guideVibrate
				});
			}
		}, 200);
		return () => {
			clearInterval(t);
			stopSpeaking();
		};
	}, [camError, mode]);
	(0, import_react.useEffect)(() => {
		if (camError || mode === "qr") return;
		let steady = 0;
		let smooth = null;
		let miss = 0;
		let dSize = 320;
		const detector = new PageDetector();
		detectorRef.current = detector;
		const sc = document.createElement("canvas");
		sc.width = 96;
		sc.height = 128;
		const sctx = sc.getContext("2d", { willReadFrequently: true });
		let inflight = false, alive = true;
		const pacer = new FramePacer(120);
		const ring = ringRef.current;
		const v0 = video.current;
		if (!v0) return;
		const stopFrames = onCameraFrames(v0, async () => {
			const v = video.current;
			if (!v?.videoWidth || busyRef.current || reviewRef.current) return;
			if (inflight) return;
			inflight = true;
			let fr = {
				det: null,
				sharp: 0,
				glare: 0,
				fromWorker: false
			};
			const wantRing = typeof createImageBitmap === "function";
			let vr = null;
			try {
				vr = await detectVideoFrameAsync(v, dSize, sc.width, sc.height, wantRing, mode !== "photo");
				if (vr) fr = vr;
				else if (mode !== "photo") fr = await detectFrameAsync(v, v.videoWidth, v.videoHeight, dSize);
			} finally {
				inflight = false;
			}
			let ringBmp = vr?.bmp ?? null;
			const t1 = performance_default.now(), sampled = mode === "photo" ? 0 : lastSampleMs;
			try {
				const det = fr.det;
				if (!alive || busyRef.current || reviewRef.current) return;
				const ok = det && det.score > .4 ? det : null;
				if (ok) {
					miss = 0;
					const moved = smooth ? Math.max(...ok.quad.map((p, i) => Math.hypot(p[0] - smooth[i][0], p[1] - smooth[i][1]))) : 1;
					smooth = smooth && moved < .08 ? smooth.map((p, i) => [p[0] * .5 + ok.quad[i][0] * .5, p[1] * .5 + ok.quad[i][1] * .5]) : ok.quad;
					steady = moved < .02 && ok.score > .55 ? steady + 1 : 0;
				} else if (++miss > 2) {
					smooth = null;
					steady = 0;
				}
				dSize = nextDetectSize(dSize, miss, steady >= 2);
				lastQuad.current = smooth;
				let nextTip = !smooth ? "none" : ok && ok.area < .22 ? "closer" : steady > 0 ? "hold" : "found";
				const sh = fr.sharp;
				const hist = sharpRef.current;
				hist.push(sh);
				if (hist.length > 12) hist.shift();
				if (ringBmp) {
					ringRef.current.push(ringBmp, sh);
					ringBmp = null;
				} else if (!vr && wantRing) createImageBitmap(v).then((b) => {
					if (alive) ringRef.current.push(b, sh);
					else b.close();
				}, () => {});
				const fg = focusRef.current.push(sh);
				const sharpNow = fg.ok;
				focusLevelRef.current = fg.ok ? "sharp" : "focusing";
				if (smooth && steady > 0 && !sharpNow) nextTip = "blur";
				const glareNow = smooth ? fr.glare > .04 : false;
				const tiltNow = smooth ? tilt(smooth) > .28 : false;
				if (sctx && !vr) sctx.drawImage(v, 0, 0, sc.width, sc.height);
				const px = vr ? vr.px : sctx ? sctx.getImageData(0, 0, sc.width, sc.height).data : null;
				const luma = px ? meanLumaRGBA(px) : 255;
				const darkNow = lightLevel(luma) !== "ok";
				liveWarnRef.current = px ? captureWarning({
					sharp: sh,
					glare: fr.glare,
					luma,
					tilt: smooth ? tilt(smooth) : 0,
					area: ok ? ok.area : null
				}) : null;
				if (glareNow) nextTip = "glare";
				else if (darkNow) nextTip = "dark";
				else if (tiltNow) nextTip = "tilt";
				updateVf({
					quad: smooth,
					tip: nextTip,
					focus: fg.level,
					focusScore: Math.round(sh)
				});
				if (!sctx || !px) return;
				const sig = frameSignature(px, sc.width, sc.height);
				const ready = !!(auto && smooth && steady >= 4 && sharpNow && !glareNow && !tiltNow && lightLevel(luma) !== "dark" && ok && ok.area >= .22 && [
					"doc",
					"whiteboard",
					"passport"
				].includes(mode));
				const ev = detector.push(sig, ready);
				lastSigRef.current = sig;
				if (ev === "capture") {
					steady = 0;
					focusRef.current.restart();
					capture(true);
				}
			} finally {
				ringBmp?.close();
				pacer.cost(sampled + performance_default.now() - t1);
			}
		}, () => pacer.gap());
		return () => {
			alive = false;
			stopFrames();
			ring.clear();
		};
	}, [
		auto,
		camError,
		capture,
		mode,
		updateVf
	]);
	(0, import_react.useEffect)(() => {
		if (mode !== "qr") return;
		let running = false;
		const t = setInterval(async () => {
			const v = video.current;
			if (!v?.videoWidth || running) return;
			running = true;
			try {
				const r = await readCode(v);
				if (r) {
					setQr(r);
					navigator.vibrate?.(30);
				}
			} finally {
				running = false;
			}
		}, 400);
		return () => clearInterval(t);
	}, [mode]);
	async function toggleTorch() {
		const track = stream.current?.getVideoTracks()[0];
		const caps = track?.getCapabilities?.();
		if (!track || !caps?.torch) {
			toast("Máy này không hỗ trợ bật đèn từ trình duyệt");
			return;
		}
		await track.applyConstraints({ advanced: [{ torch: !torch }] });
		setTorch(!torch);
	}
	async function importImages(picked) {
		if (!picked.length || busyRef.current || reviewRef.current) return;
		busyRef.current = true;
		setBusy(true);
		const noQuad = mode === "photo" || mode === "id" || mode === "book";
		const lim = Math.min(3, Math.max(1, (navigator.hardwareConcurrency || 2) - 1));
		try {
			const files = await expandImageFiles(picked, (f, error) => toast.error(userMessage(error, `Không đọc được ảnh “${f.name}”`)));
			const one = files.length === 1;
			await pmapOrdered(files, lim, async (f) => {
				try {
					const orig = await normalizeUrl(await imageBlob(f), CAPTURE_MAX, CAPTURE_Q);
					return {
						orig,
						quad: noQuad ? null : (await detectQuadInfo(orig)).quad
					};
				} catch (error) {
					toast.error(userMessage(error, `Không đọc được ảnh “${f.name}”`));
					return null;
				}
			}, async (result) => {
				if (result) await addOrig(result.orig, result.quad, one ? "modal" : false);
			});
		} catch (error) {
			showError(error, "Không nhập được ảnh");
		} finally {
			busyRef.current = false;
			setBusy(false);
		}
	}
	async function fromGallery() {
		await importImages(await pickFiles(IMAGE_ACCEPT));
	}
	async function fromClipboard() {
		try {
			await importImages(await readClipboardImages());
		} catch (error) {
			toast.error(userMessage(error, "Không dán được ảnh"));
		}
	}
	useImagePaste(importImages, !busy && !review && mode !== "qr");
	const beforeRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const newDocRef = (0, import_react.useRef)(true);
	async function saveAll() {
		if (pending) {
			toast("Đang xử lý ảnh vừa chụp…");
			await queueRef.current;
			await new Promise((r) => setTimeout(r, 50));
		}
		const bg = pipelineEnabled();
		if (bgQueue.size && !bg) await bgQueue.flush();
		const pages = pagesRef.current.map((p0) => {
			const p = unsureRef.current.has(p0.id) ? {
				...p0,
				warnings: [.../* @__PURE__ */ new Set([...p0.warnings ?? [], EDGE_WARNING])]
			} : p0;
			const src = finishedRef.current.get(p.id) ?? finishedStore.get(p.id);
			if (src) return {
				...p,
				src,
				status: "xong"
			};
			return bg && bgQueue.has(p.id, "finish") ? {
				...p,
				status: "dang"
			} : p;
		});
		if (!pages.length) return null;
		let saved = null;
		await journalW.current.commit({
			...journalRef.current,
			pages
		}, async (cid) => {
			const target = search.doc ? docs.find((d) => d.id === search.doc) : docs.find((d) => d.id === cid);
			if (target) {
				saved = await mutateDoc(target.id, (d) => {
					const have = new Set(d.pages.map((p) => p.id));
					beforeRef.current = have;
					return {
						...d,
						pages: [...d.pages, ...pages.filter((p) => !have.has(p.id))]
					};
				}, true);
				if (saved) {
					newDocRef.current = false;
					return target.id;
				}
			}
			beforeRef.current = /* @__PURE__ */ new Set();
			newDocRef.current = true;
			saved = await saveDoc({
				...newDoc(pages, void 0, MODES[mode]),
				id: target?.id ?? cid
			});
			return saved.id;
		});
		for (const p of pages) {
			if (p.status === "xong") {
				finishedStore.delete(p.id);
				continue;
			}
			const src = p.status === "dang" ? finishedStore.get(p.id) : void 0;
			if (src) applyFinished(p.id, src, p.edit).then((ok) => {
				if (ok) finishedStore.delete(p.id);
			});
		}
		return saved;
	}
	const [saving, setSaving] = (0, import_react.useState)(false);
	const savingRef = (0, import_react.useRef)(false);
	async function saveWithProgress() {
		if (savingRef.current) return void 0;
		savingRef.current = true;
		setSaving(true);
		const n = pagesRef.current.length + pending;
		const tid = n ? toast.loading(`Đang lưu ${n} trang…`, pipelineEnabled() ? void 0 : { description: "Đang hoàn thiện ảnh chất lượng đầy đủ, vui lòng chờ." }) : void 0;
		try {
			return await saveAll();
		} catch (e) {
			showError(e, "Chưa lưu được tài liệu");
			return;
		} finally {
			if (tid !== void 0) toast.dismiss(tid);
			savingRef.current = false;
			setSaving(false);
		}
	}
	async function finish() {
		const t0 = performance_default.now();
		const saved = await saveWithProgress();
		if (saved === void 0) return;
		if (!saved) {
			navigate({ to: "/" });
			return;
		}
		postCaptureWithMetrics(saved, beforeRef.current, newDocRef.current);
		const before = beforeRef.current;
		const needReview = saved.pages.some((p) => !before.has(p.id) && (p.warnings?.length || p.status === "xem-lai"));
		recordPerf("done", performance_default.now() - t0);
		navigate({
			to: "/doc/$id",
			params: { id: saved.id },
			search: needReview ? { review: "1" } : {},
			replace: true
		});
	}
	async function close() {
		const n = pagesRef.current.length + pending;
		if (n && !await confirmDialog(`Thoát và bỏ ${n} trang chưa lưu?`, {
			message: "Bấm “Xong” nếu muốn lưu thành tài liệu.",
			okText: "Bỏ trang",
			danger: true
		})) return;
		for (const pg of pagesRef.current) {
			bgQueue.cancelPage(pg.id, "finish");
			finishedStore.delete(pg.id);
		}
		navigate({ to: "/" });
	}
	async function finishExtract() {
		const saved = await saveWithProgress();
		if (saved === void 0) return;
		if (!saved) {
			navigate({ to: "/" });
			return;
		}
		navigate({
			to: "/doc/$id",
			params: { id: saved.id },
			search: {
				tool: "ai-extract",
				run: "1"
			},
			replace: true
		});
	}
	const vw = video.current?.videoWidth || 1, vh = video.current?.videoHeight || 1;
	const bw = view.current?.clientWidth || 1, bh = view.current?.clientHeight || 1;
	const cs = Math.max(bw / vw, bh / vh), ox = (bw - vw * cs) / 2, oy = (bh - vh * cs) / 2;
	const cornerPts = quad?.map(([x, y]) => [x * vw * cs + ox, y * vh * cs + oy]);
	const pts = cornerPts?.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
	const hint = mode === "id" ? idFront ? "Mặt sau của thẻ" : "Mặt trước của thẻ" : mode === "book" ? "Đặt sách mở 2 trang vào khung" : mode === "qr" ? "Hướng camera vào mã QR" : tip === "glare" ? "Bị lóa đèn — nghiêng nhẹ máy hoặc tắt đèn flash" : tip === "dark" ? "Thiếu sáng — bật đèn hoặc ra chỗ sáng hơn" : tip === "tilt" ? "Máy đang nghiêng — đưa máy song song với tờ giấy" : tip === "blur" ? "Hình đang mờ — giữ yên máy, chờ lấy nét" : tip === "closer" ? "Đưa máy lại gần hơn" : tip === "hold" ? auto ? "Giữ yên máy — đang tự chụp" : "Đã khớp mép giấy" : tip === "found" ? "Giữ thẳng máy trên tờ giấy" : "Đưa cả tờ giấy vào khung, nền tối càng tốt";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "scan-screen fixed inset-0 z-50 mx-auto flex max-w-[430px] flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-3 pt-[max(0.75rem,env(safe-area-inset-top))] pb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": "Đóng",
					className: "scan-icon",
					onClick: () => void close(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Dán ảnh",
							title: "Dán ảnh",
							disabled: busy || !!review || mode === "qr",
							className: "scan-icon",
							onClick: () => void fromClipboard(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Đèn flash",
							className: "scan-icon",
							onClick: toggleTorch,
							children: torch ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZapOff, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Lưới căn",
							className: `scan-icon ${grid ? "text-primary" : ""}`,
							onClick: () => setGrid(!grid),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grid3x3, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Chụp liên tục",
							"aria-pressed": continuous,
							className: `scan-icon ${continuous ? "text-primary" : ""}`,
							onClick: () => {
								setContinuous(!continuous);
								toast(!continuous ? "Chụp liên tục: lật trang là tự chụp, không dừng để cắt" : "Đã tắt chụp liên tục");
								if (!continuous) setAuto(true);
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Tự chụp",
							className: `scan-icon ${auto ? "text-primary" : ""}`,
							onClick: () => setAuto(!auto),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, {})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: view,
				className: "relative mx-3 flex-1 overflow-hidden rounded-[20px] bg-editor",
				children: [
					!camError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						ref: video,
						playsInline: true,
						muted: true,
						className: "absolute inset-0 h-full w-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 grid place-items-center p-8 text-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display font-semibold",
								children: "Không mở được máy ảnh"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: "Hãy cho phép quyền máy ảnh, hoặc chọn ảnh có sẵn."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex justify-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									onClick: () => setCamTry((n) => n + 1),
									children: "Thử lại"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: fromGallery,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {}), " Chọn ảnh"]
								})]
							})
						] })
					}),
					camSlow && !camError && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-x-3 top-3 z-10 flex items-center gap-2 rounded-[12px] bg-background/90 p-2.5 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1",
							children: "Máy ảnh mở chậm hơn bình thường."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							onClick: () => setCamTry((n) => n + 1),
							children: "Mở lại"
						})]
					}),
					grid && !camError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scan-grid pointer-events-none absolute inset-0" }),
					pts && !camError && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: `0 0 ${bw} ${bh}`,
						className: "pointer-events-none absolute inset-0 h-full w-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
							points: pts,
							className: "scan-quad"
						}), cornerPts?.map(([cx, cy], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx,
							cy,
							r: 7,
							"data-corner": i,
							className: `scan-corner${tip === "hold" ? " scan-corner-lock" : ""}`
						}, i))]
					}),
					mode === "id" && !camError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute left-1/2 top-1/2 aspect-[85.6/54] w-[82%] -translate-x-1/2 -translate-y-1/2 rounded-[12px] border-2 border-dashed border-primary" }),
					flash && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-background/80" }),
					!camError && mode !== "qr" && mode !== "photo" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute bottom-3 left-1/2 z-10 flex -translate-x-1/2 items-center gap-2 rounded-full bg-background/90 px-3 py-1.5 text-[11px] font-semibold text-foreground",
						"data-score": focusScore,
						role: "meter",
						"aria-label": "Độ nét",
						"aria-valuemin": 0,
						"aria-valuemax": 100,
						"aria-valuenow": Math.round(focus * 100),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Độ nét" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "h-1.5 w-20 overflow-hidden rounded-full bg-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `block h-full rounded-full transition-all ${focus >= .8 ? "bg-primary" : "bg-destructive"}`,
								style: { width: `${Math.round(focus * 100)}%` }
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "scan-hint absolute inset-x-0 top-3 mx-auto w-max max-w-[90%] rounded-full px-3 py-1.5 text-xs font-semibold",
						children: hint
					}),
					qr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "document-row absolute inset-x-3 bottom-3 rounded-[14px] p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "break-all text-sm font-semibold",
							children: qr
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "glass",
								onClick: () => {
									navigator.clipboard.writeText(qr);
									toast("Đã sao chép");
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), " Sao chép"]
							}), /^https?:\/\//.test(qr) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: qr,
									target: "_blank",
									rel: "noreferrer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {}), " Mở liên kết"]
								})
							})]
						})]
					})
				]
			}),
			(pages.length > 0 || jobs.length > 0) && mode !== "qr" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 overflow-x-auto px-3 pt-3 [scrollbar-width:none]",
				"aria-label": "Các trang đã chụp",
				children: [pages.map((pg, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `relative size-14 shrink-0 overflow-hidden rounded-[10px] border-2 ${retake === i ? "border-destructive" : "border-primary/40"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							"aria-label": `Chụp lại trang ${i + 1}`,
							className: "h-full w-full",
							onClick: () => {
								const on = retake !== i;
								setRetake(on ? i : null);
								toast(on ? `Chụp lại trang ${i + 1}: lần chụp tới sẽ thay trang này` : "Đã huỷ chụp lại");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: pg.thumb || pg.src,
								alt: "",
								className: "h-full w-full object-cover"
							}), retake === i && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute inset-0 grid place-items-center bg-background/60",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-5" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GradeBadge, { src: pg.orig || pg.src }),
						unsure.has(pg.id) && pg.orig && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							"aria-label": `Kiểm mép trang ${i + 1}`,
							title: "Máy chưa chắc mép giấy — chạm để chỉnh khung",
							onClick: () => setReview({
								orig: pg.orig,
								quad: pg.edit.quad ?? null,
								pageId: pg.id
							}),
							className: "absolute bottom-0.5 right-0.5 grid size-5 place-items-center rounded-full bg-warning text-warning-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crop, { className: "size-3" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute bottom-0.5 left-0.5 rounded bg-background/80 px-1 text-[0.625rem] font-bold",
							children: i + 1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							"aria-label": `Xoá trang ${i + 1}`,
							onClick: () => removePage(i),
							className: "absolute right-0.5 top-0.5 grid size-5 place-items-center rounded-full bg-destructive text-destructive-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
						})
					]
				}, pg.id)), jobs.map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					"data-job-state": j.state,
					className: `relative grid size-14 shrink-0 place-items-center rounded-[10px] border-2 bg-muted text-center text-[0.625rem] font-semibold ${j.state === "error" ? "border-destructive text-destructive" : "border-dashed border-primary/40 text-muted-foreground"}`,
					children: [j.state === "error" ? j.orig ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						"aria-label": "Thử lại ảnh lỗi",
						className: "grid h-full w-full place-items-center",
						onClick: () => {
							const o = j.orig;
							setJob(j.id, { state: "running" });
							queueRef.current = queueRef.current.then(() => addOrig(o, null, false)).then(() => setJob(j.id, null), () => setJob(j.id, {
								state: "error",
								orig: o
							}));
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Thử lại"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Lỗi" }) : j.thumb ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: j.thumb,
							alt: "",
							"data-instant-preview": true,
							className: "absolute inset-0 h-full w-full rounded-[8px] object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute inset-0 grid place-items-center rounded-[8px] bg-background/40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"data-finishing": true,
							className: "absolute inset-x-0 bottom-0 truncate rounded-b-[8px] bg-background/80 px-0.5 text-center text-[9px] leading-tight",
							children: "Đang hoàn thiện"
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "grid place-items-center gap-0.5",
						children: [j.state === "running" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : null, j.state === "running" ? "Đang xử lý" : "Đang chờ"]
					}), j.state === "error" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						"aria-label": "Bỏ ảnh lỗi",
						onClick: () => setJob(j.id, null),
						className: "absolute right-0.5 top-0.5 grid size-5 place-items-center rounded-full bg-destructive text-destructive-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
					})]
				}, j.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1.5 overflow-x-auto px-3 py-3 [scrollbar-width:none]",
				children: Object.keys(MODES).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						setMode(m);
						setIdFront(null);
						setQr("");
					},
					className: `h-8 shrink-0 rounded-full px-3.5 text-xs font-semibold ${mode === m ? "bg-primary text-primary-foreground" : "scan-chip"}`,
					children: MODES[m]
				}, m))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 items-center px-6 pb-[max(1.25rem,env(safe-area-inset-bottom))]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center",
						children: pages.length || pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative size-14 overflow-hidden rounded-[10px] border-2 border-primary",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: pages[pages.length - 1]?.src,
									alt: "Trang vừa chụp",
									className: "h-full w-full object-cover"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute right-0.5 top-0.5 grid size-5 place-items-center rounded-full bg-primary text-[0.625rem] font-bold text-primary-foreground",
									children: pages.length + pending
								}),
								pending > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute inset-0 grid place-items-center bg-background/60",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" })
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Chọn từ thư viện",
							className: "scan-icon size-12",
							onClick: fromGallery,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-6" })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						"aria-label": "Chụp",
						disabled: busy || saving || camError || mode === "qr",
						onClick: () => void capture(),
						className: "shutter mx-auto grid size-[76px] place-items-center rounded-full disabled:opacity-50",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-[60px] place-items-center rounded-full bg-primary text-primary-foreground",
							children: busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-end gap-2",
						children: [pages.length > 0 && mode !== "qr" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "glass",
							onClick: finishExtract,
							disabled: busy || saving,
							className: "h-9 rounded-full px-3 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5" }), " Trích xuất"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: finish,
							disabled: busy || saving,
							className: "h-11 rounded-full px-4",
							children: [
								saving ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}),
								" ",
								saving ? "Đang lưu…" : pages.length ? `Xong` : "Thoát"
							]
						})]
					})
				]
			}),
			review && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CropEditor, {
				src: review.orig,
				quad: review.quad ?? void 0,
				cancelLabel: review.pageId ? "Huỷ" : "Chụp lại",
				applyLabel: review.pageId ? "Áp dụng" : "Giữ trang",
				onClose: () => setReview(null),
				onApply: async (q, paper) => {
					const r = review;
					setReview(null);
					setBusy(true);
					try {
						const next = await process(r.orig, q, paper);
						if (!r.pageId) {
							putPages(next);
							return;
						}
						bgQueue.cancelPage(r.pageId, "finish");
						finishedRef.current.delete(r.pageId);
						finishedStore.delete(r.pageId);
						setPages((ps) => ps.flatMap((x) => x.id === r.pageId ? next : [x]));
						setUnsure((u) => {
							const n = new Set(u);
							n.delete(r.pageId);
							return n;
						});
					} catch (e) {
						showError(e, "Không cắt được trang");
					} finally {
						setBusy(false);
					}
				}
			})
		]
	});
}
function GradeBadge({ src }) {
	const [g, setG] = (0, import_react.useState)(() => gradeCache.get(src) ?? null);
	(0, import_react.useEffect)(() => {
		let on = true;
		gradeOf(src).then((r) => on && setG(r)).catch(() => {});
		return () => {
			on = false;
		};
	}, [src]);
	if (!g) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `grade-badge grade-${g.level}`,
		"data-grade": g.level,
		"data-parts": JSON.stringify(g.parts),
		title: g.tip,
		"aria-label": `Điểm trang ${g.score}: ${g.tip}`,
		children: g.score
	});
}
//#endregion
export { Scan as component };
