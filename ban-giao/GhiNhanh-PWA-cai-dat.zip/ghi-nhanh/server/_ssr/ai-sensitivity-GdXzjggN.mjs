//#region node_modules/.nitro/vite/services/ssr/assets/ai-sensitivity-GdXzjggN.js
var SENSITIVE_LABEL = {
	cccd: "số CCCD/CMND",
	phone: "số điện thoại",
	account: "số tài khoản/thẻ"
};
/** Classify a digit string read from a page; null when it is not personal data. `raw` keeps separators to spot money amounts. */
function classifyNumber(digits, raw = digits) {
	if (/^\d{1,3}([.,]\d{3}){2,}$/.test(raw.replace(/\s/g, ""))) return null;
	const n = digits.length;
	if (/^0[35789]\d{8}$/.test(digits) || /^84[35789]\d{8}$/.test(digits)) return "phone";
	if (n === 12 && /^0\d{11}$/.test(digits)) return "cccd";
	if (n === 9 && !/^0/.test(digits)) return "cccd";
	if (n >= 8 && n <= 19) return "account";
	return null;
}
var NUMERIC = /^\+?[\d.\-–]+$/;
/** Find personal numbers in OCR words (pixel coords, y = -centre as produced by ocr.ts). Numbers split by spaces are joined per line. */
function findSensitive(words, W, H) {
	const ws = words.filter((w) => w.str.trim()).map((w) => ({
		...w,
		top: -w.y - w.h / 2
	}));
	ws.sort((a, b) => a.top - b.top || a.x - b.x);
	const lines = [];
	for (const w of ws) {
		const l = lines.find((ln) => Math.abs(ln[0].top + ln[0].h / 2 - (w.top + w.h / 2)) < Math.max(ln[0].h, w.h) * .5);
		if (l) l.push(w);
		else lines.push([w]);
	}
	const out = [];
	for (const ln of lines) {
		ln.sort((a, b) => a.x - b.x);
		let run = [];
		const flush = () => {
			if (!run.length) return;
			const raw = run.map((w) => w.str).join(" ");
			const digits = raw.replace(/\D/g, "");
			const kind = classifyNumber(digits, raw);
			if (kind) {
				const x0 = Math.min(...run.map((w) => w.x)), x1 = Math.max(...run.map((w) => w.x + w.w));
				const y0 = Math.min(...run.map((w) => w.top)), y1 = Math.max(...run.map((w) => w.top + w.h));
				const px = (y1 - y0) * .25;
				out.push({
					kind,
					digits,
					region: {
						x: Math.max(0, (x0 - px) / W),
						y: Math.max(0, (y0 - px) / H),
						w: Math.min(1, (x1 - x0 + 2 * px) / W),
						h: Math.min(1, (y1 - y0 + 2 * px) / H)
					}
				});
			}
			run = [];
		};
		for (const w of ln) {
			const s = w.str.replace(/[:;,]$/, "");
			const prev = run[run.length - 1];
			const near = !prev || w.x - (prev.x + prev.w) < Math.max(prev.h, w.h) * 1.2;
			if (NUMERIC.test(s) && /\d/.test(s) && near) run.push({
				...w,
				str: s
			});
			else {
				flush();
				if (NUMERIC.test(s) && /\d/.test(s)) run.push({
					...w,
					str: s
				});
			}
		}
		flush();
	}
	return out;
}
function summarize(found) {
	const c = {};
	for (const f of found) c[f.kind] = (c[f.kind] ?? 0) + 1;
	return Object.keys(c).map((k) => `${c[k]} ${SENSITIVE_LABEL[k]}`).join(", ");
}
/**
* AI-05 (QD-13, đề án 12.6): định tuyến theo độ nhạy cảm — giấy tờ nhạy cảm (CCCD/hộ chiếu, sổ đỏ, sao kê, hợp đồng, đăng ký xe,
* tài liệu khoá PIN, nội dung có số CCCD/điện thoại/tài khoản) KHÔNG gửi tới nguồn miễn phí (Mistral/Gemini có thể dùng dữ liệu để huấn
* luyện): chỉ Lovable → Claude → xử lý trên máy. Không biết loại tài liệu → coi là nhạy cảm (an toàn trước). Bài tập (Giải bài tập) là
* tài liệu thường trừ khi có số cá nhân. Màn tài liệu báo gợi ý cho máy chủ qua tiêu đề x-ai-sensitive (1/0).
*/
var SENSITIVE_DOC_TYPES = [
	"CCCD/Hộ chiếu",
	"Hợp đồng",
	"Sao kê/Chứng từ ngân hàng",
	"Sổ đỏ",
	"Giấy đăng ký xe"
];
var SENSITIVE_WORDS = /cccd|cmnd|căn cước|hộ chiếu|passport|sổ đỏ|sổ hồng|sao kê|chứng từ ngân hàng|hợp đồng|đăng ký xe/i;
var AI_SENSITIVE_HEADER = "x-ai-sensitive";
/** Tài liệu nhạy cảm: đang khoá PIN, hoặc loại/loại AI đặt thuộc nhóm nhạy cảm. */
function isSensitiveDoc(d) {
	if (d.enc || d.locked) return true;
	return [d.kind, d.fields?.["docType"]].filter((x) => !!x).some((t) => SENSITIVE_DOC_TYPES.includes(t) || SENSITIVE_WORDS.test(t));
}
/** Chữ có số CCCD/CMND, điện thoại hoặc tài khoản/thẻ (cùng luật với che số cá nhân — sensitive.ts). */
function textHasSensitiveNumbers(text) {
	for (const m of text.matchAll(/\+?\d[\d .\-–]{6,}\d/g)) {
		const raw = m[0];
		if (classifyNumber(raw.replace(/\D/g, ""), raw)) return true;
	}
	return false;
}
/** Chuỗi chữ trong dữ liệu gửi AI (bỏ ảnh data URL). */
function texts(v, out = [], depth = 0) {
	if (typeof v === "string") {
		if (!v.startsWith("data:")) out.push(v);
	} else if (v && typeof v === "object" && depth < 5) for (const x of Object.values(v)) texts(x, out, depth + 1);
	return out;
}
/** Quyết định cho một lệnh AI (máy chủ): số cá nhân trong chữ → nhạy cảm; gợi ý của màn tài liệu; bài tập → thường; còn lại → nhạy cảm. */
function sensitiveFor(task, data, hint) {
	if (texts(data).some(textHasSensitiveNumbers)) return true;
	if (hint === "1") return true;
	if (hint === "0") return false;
	if (task === "aiText" && data?.task === "solve") return false;
	return true;
}
var hint = null;
var setAiSensitivity = (v) => {
	hint = v;
};
var aiSensitivityHint = () => hint;
//#endregion
export { AI_SENSITIVE_HEADER, aiSensitivityHint, isSensitiveDoc, summarize as n, sensitiveFor, setAiSensitivity, findSensitive as t };
