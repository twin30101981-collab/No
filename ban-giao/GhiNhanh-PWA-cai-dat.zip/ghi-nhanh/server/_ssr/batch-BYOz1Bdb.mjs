import { o as docText } from "./db-CclUQaLE.mjs";
import { l as compress } from "./image-DFWRNlNd.mjs";
import { s as docToPdf, u as imagesToPdf, x as safeName } from "./files-CTF11Arr.mjs";
import { a as recognize, i as pool } from "./ocr-CLa2avjZ.mjs";
import { i as zip, n as sheetsToXlsx, r as textToRows } from "./xlsx-CvpeQh6I.mjs";
import { n as blocksToDocx, t as block } from "./history-ZPjFrOJG.mjs";
import { t as imagesToWord } from "./word-DdGqJXaY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/batch-BYOz1Bdb.js
/** Long side sent to AI table reading: small digits in dense tables need ~2000px to stay exact. */
var TABLE_PX = 2e3;
/** Page images → rows per page via AI table reading (3 pages at a time), OCR fallback. */
async function imagesToSheets(srcs, table, warn, onPage) {
	return (await imagesToTables(srcs, table, warn, onPage)).map((t) => t.rows);
}
async function imagesToTables(srcs, table, warn, onPage) {
	let warned = false, stopAi = false, done = 0;
	return pool(srcs, 3, async (s) => {
		let res = null;
		if (!stopAi) {
			const r = await table({ data: { images: [await compress(s, TABLE_PX, .85)] } });
			if (r.ok && r.data.rows.length) res = r.data;
			else if (!r.ok) {
				if (r.code === 402 || r.code === 429) stopAi = true;
				if (!warned) {
					warn?.(r.message + " Đang dùng cách đọc chữ thường.");
					warned = true;
				}
			}
		}
		res ??= {
			title: "",
			rows: textToRows(await recognize(s))
		};
		onPage?.(++done, srcs.length);
		return res;
	});
}
/** Unique, safe file names inside a zip. */
function uniqueNames(names, ext) {
	const seen = /* @__PURE__ */ new Map();
	return names.map((n) => {
		const b = safeName(n) || "tai-lieu";
		const k = (seen.get(b) ?? 0) + 1;
		seen.set(b, k);
		return `${k > 1 ? `${b}-${k}` : b}.${ext}`;
	});
}
var bytes = async (b) => new Uint8Array(await b.arrayBuffer());
/** One file per document → zip. Returns blob + any notes. */
/** TF-03: `sink` có thì từng tệp ghi thẳng ra (vd. thư mục trên máy) thay vì gói zip; `savedAs` = tên đã dùng. */
async function batchSeparate(docs, fmt, fns, progress, warn, sink) {
	const ext = fmt === "pdf" ? "pdf" : fmt === "word" ? "docx" : "xlsx";
	const names = uniqueNames(docs.map((d) => d.name), ext);
	const files = [];
	const failed = [];
	const saved = [];
	let count = 0;
	for (const [i, d] of docs.entries()) {
		progress?.(i, docs.length, d.name);
		try {
			const srcs = d.pages.map((p) => p.src);
			const blob = fmt === "pdf" ? await docToPdf(d) : fmt === "word" ? (await imagesToWord(srcs, d.name, fns.layout, docText(d))).blob : sheetsToXlsx((await imagesToSheets(srcs, fns.table, warn)).map((rows, k) => ({
				name: srcs.length > 1 ? `Trang ${k + 1}` : "Bang",
				rows
			})));
			if (sink) {
				saved.push(await sink(names[i], blob));
				count++;
			} else files.push([names[i], await bytes(blob)]);
		} catch (e) {
			console.error(e);
			failed.push(d.name);
		}
	}
	progress?.(docs.length, docs.length, "");
	return {
		blob: sink ? new Blob([]) : zip(files, "application/zip"),
		count: sink ? count : files.length,
		failed,
		saved
	};
}
/** Everything merged into one file. Word/Excel return editable data for the review step. */
async function batchMerged(docs, fmt, fns, progress, warn) {
	if (fmt === "pdf") {
		progress?.(0, 1, "PDF");
		return {
			kind: "pdf",
			blob: await imagesToPdf(docs.flatMap((d) => d.pages.map((p) => p.src)), { searchable: true })
		};
	}
	if (fmt === "word") {
		const blocks = [];
		for (const [i, d] of docs.entries()) {
			progress?.(i, docs.length, d.name);
			const r = await imagesToWord(d.pages.map((p) => p.src), d.name, fns.layout, docText(d));
			blocks.push(block("heading", d.name, { level: 1 }), ...r.blocks);
		}
		return {
			kind: "word",
			blocks,
			blob: blocksToDocx(blocks)
		};
	}
	const sheets = [];
	for (const [i, d] of docs.entries()) {
		progress?.(i, docs.length, d.name);
		const pages = await imagesToSheets(d.pages.map((p) => p.src), fns.table, warn);
		const base = d.name.slice(0, 28) || "Trang";
		let name = base;
		for (let n = 2; sheets.some((x) => x.name.toLowerCase() === name.toLowerCase()); n++) name = `${base} ${n}`;
		sheets.push({
			name,
			rows: pages.flatMap((rows, k) => k ? [[""], ...rows] : rows)
		});
	}
	return {
		kind: "excel",
		sheets,
		blob: sheetsToXlsx(sheets)
	};
}
//#endregion
export { imagesToTables as i, batchMerged as n, batchSeparate as r, TABLE_PX as t };
