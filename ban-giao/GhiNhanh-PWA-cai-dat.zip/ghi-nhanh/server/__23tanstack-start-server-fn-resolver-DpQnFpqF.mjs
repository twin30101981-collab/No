//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-DpQnFpqF.js
var manifest = {
	"041fdf35b19bf4c65096476bcea235fc14bc14efac887da12e7c9bb40c9cd5f8": {
		functionName: "listShareLinks_createServerFn_handler",
		importer: () => import("./_ssr/share.functions-B_iPcIUN.mjs")
	},
	"05e9df102c9c56f519deb2e800e7ee4661deb01d239d3f5fe9673f5658712971": {
		functionName: "openSharedDoc_createServerFn_handler",
		importer: () => import("./_ssr/share-view.functions-ZC2NmJHa.mjs")
	},
	"0ca6e7554fc3f33aecb540529f35ca3c25c7cc60e65d242a45ec1ee9d3492afb": {
		functionName: "aiReceipt_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-YcTY3dK8.mjs")
	},
	"1453a21a4491fc7bec8ad067eb310e9b22376f2bd30a0340c16bfdf1dee2689b": {
		functionName: "aiExtract_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-YcTY3dK8.mjs")
	},
	"27301031363e284184ead21ac910c33ebfbe9159435c975f26319c6a65fade88": {
		functionName: "deleteMyAccount_createServerFn_handler",
		importer: () => import("./_ssr/account.functions-ETXjJPJH.mjs")
	},
	"280c0f12ccaa87a6526d913e064908c02360938c46115eaad9cbad77b3fe7a2b": {
		functionName: "aiDocAsk_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-YcTY3dK8.mjs")
	},
	"3cc5d315fc0705890be69eb9a4146e5e25a5b69a7f7976a6be3c4e4b75a7d087": {
		functionName: "aiKeyCheck_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-YcTY3dK8.mjs")
	},
	"40eea221df3652422361115215091d174916a19c57ecb22f77d6664f33c524c6": {
		functionName: "aiLayout_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-YcTY3dK8.mjs")
	},
	"50d37df7685c56c9fbdeb09183eab242f1002b2926c86996bd696b307e77d0fe": {
		functionName: "aiPaperCorners_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-YcTY3dK8.mjs")
	},
	"53a4f104cd1c70577f4c82bb90053dfe68e795719b2f232b2bf3cfbbe723f46a": {
		functionName: "aiClassify_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-YcTY3dK8.mjs")
	},
	"56db84a888ffaeaaab3462275df7b64e74b44521d4436490ac79509b4b855c40": {
		functionName: "aiText_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-YcTY3dK8.mjs")
	},
	"6db13cc0879a96b11a9842037feb4ee8580102b2c161116c256fdec3b86b4a87": {
		functionName: "aiPersonGreen_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-YcTY3dK8.mjs")
	},
	"8409476496bea21a8699cd409cbee795dd07ebd0d8433c5decd4a798620bf15b": {
		functionName: "aiRows_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-YcTY3dK8.mjs")
	},
	"92c12948b77e36ae0d6df5dfcfbf3ce549377e5dcd880612d491f718bdea9bb7": {
		functionName: "aiTranslateBlocks_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-YcTY3dK8.mjs")
	},
	"9d73e134a8f620a8ab710665a2c56d119dc94d5559f194a2366313730f523e47": {
		functionName: "revokeShareLink_createServerFn_handler",
		importer: () => import("./_ssr/share-view.functions-ZC2NmJHa.mjs")
	},
	"a7c4e12c7d4bceefff8bdb2102e80eefafe878a9712152d19cf39bf8d137fcbe": {
		functionName: "aiScanDiagnose_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-YcTY3dK8.mjs")
	},
	"b7955cf62ddfdb3b49e42ebc7c3a1fbfc7e7891d9b33db3970e46e6401cad67e": {
		functionName: "aiProviders_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-YcTY3dK8.mjs")
	},
	"d862f1b45ce22fc1327a146114ddb240c9906758a402c31bd89063f3e24b2191": {
		functionName: "aiPhotoCheck_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-YcTY3dK8.mjs")
	},
	"f631e086e864b55a802d3846676e9c76d6b0d78df3ae21524dfa509bbf1a00b3": {
		functionName: "createShareLink_createServerFn_handler",
		importer: () => import("./_ssr/share.functions-B_iPcIUN.mjs")
	},
	"fee9b6c827c57709b7fa5d29bb1e9186399d74aefeb66a06a34263447dde1f67": {
		functionName: "aiTable_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-YcTY3dK8.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ??= await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
