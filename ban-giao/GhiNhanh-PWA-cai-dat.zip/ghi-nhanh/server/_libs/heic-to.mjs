const t = new Proxy({}, { get(_, k) { if (k === "then") return undefined; throw new Error("Chỉ dùng trên trình duyệt"); } }); export { t };
