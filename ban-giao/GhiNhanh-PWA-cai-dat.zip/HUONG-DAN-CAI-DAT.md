# Ghi Nhanh — cài lên màn hình chính điện thoại (Chrome)

Ứng dụng web cài được (PWA) chỉ cài được khi mở từ một địa chỉ **https://**. Vì vậy cần đưa thư mục `ghi-nhanh` lên mạng **một lần**
(miễn phí, Cloudflare Workers), rồi mở địa chỉ đó trên điện thoại và bấm "Cài đặt ứng dụng".

## Bước 1 — Đưa lên mạng (làm 1 lần, trên máy tính, ~5 phút)
1. Cài **Node.js bản LTS** (https://nodejs.org) nếu máy chưa có.
2. Tạo tài khoản miễn phí tại https://dash.cloudflare.com/sign-up (chỉ cần email).
3. Giải nén tệp ZIP này, rồi:
   - **Windows**: bấm đúp `trien-khai.bat`.
   - **macOS / Linux**: mở Terminal trong thư mục giải nén, gõ `bash trien-khai.sh`.
4. Lần đầu trình duyệt sẽ mở trang Cloudflare hỏi cấp quyền → bấm **Allow**.
5. Chờ chạy xong, màn hình in ra địa chỉ dạng **`https://ghi-nhanh.<tên-bạn>.workers.dev`** → ghi lại.

## Bước 2 — Cài lên điện thoại
**Android (Chrome):**
1. Mở Chrome, vào địa chỉ ở Bước 1.
2. Bấm biểu tượng **⋮** (góc trên phải) → **Cài đặt ứng dụng** (hoặc **Thêm vào màn hình chính** → **Cài đặt**).
3. Biểu tượng **Ghi Nhanh** xuất hiện trên màn hình chính; mở ra chạy toàn màn hình như ứng dụng thường, dùng được cả khi không có mạng.

**iPhone (Safari):** mở địa chỉ → nút **Chia sẻ** → **Thêm vào MH chính**.

## Dùng được ngay (không cần cấu hình gì thêm)
Chụp/quét giấy tờ, tự cắt mép, bộ lọc, nhập ảnh/PDF/HEIC/TIFF, xuất PDF (Nhỏ/Chuẩn/Cao, "HD nhẹ"), nhận dạng chữ (OCR) trên máy, két mật khẩu, làm việc khi mất mạng.
Dữ liệu lưu **trên điện thoại** (không gửi đi đâu).

## Cần cấu hình thêm (tuỳ chọn)
Các tính năng dùng máy chủ đám mây: trợ lý AI, đăng nhập/đồng bộ, chia sẻ bằng đường link, "Chụp bằng điện thoại" sang máy tính.
- AI: trong thư mục `ghi-nhanh` chạy `npx wrangler@4 secret put LOVABLE_API_KEY -c server/wrangler.json` (hoặc `ANTHROPIC_API_KEY`) rồi dán khoá.
- Đăng nhập/đồng bộ/chia sẻ/ghép điện thoại cần dự án Supabase (VITE_SUPABASE_URL, VITE_SUPABASE_PUBLISHABLE_KEY) và phải **build lại** từ mã nguồn:
  `VITE_SUPABASE_URL=… VITE_SUPABASE_PUBLISHABLE_KEY=… bash scripts/dong-goi-pwa.sh <thư mục ra>` trong `app/`.
Nếu dự án đang ở Lovable: bấm **Publish** trong Lovable cũng cho địa chỉ https:// có sẵn các cấu hình này — mở địa chỉ đó trên Chrome rồi làm Bước 2.

## Cập nhật bản mới
Giải nén ZIP mới, chạy lại `trien-khai` (cùng tài khoản) → địa chỉ giữ nguyên; ứng dụng trên điện thoại tự báo "Có bản mới".

## Gỡ lỗi nhanh
- Không thấy "Cài đặt ứng dụng": phải mở bằng **https** (không phải http hay tệp trên máy), dùng Chrome thường (không ẩn danh), tải lại trang 1 lần.
- `trien-khai` báo lỗi đăng nhập: chạy `npx wrangler@4 login` rồi chạy lại.
