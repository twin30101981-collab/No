// CS-06: lớp phủ "Xem lại theo lô" trong màn tài liệu (?review=1). Đi lần lượt các trang cần xem; sửa khung dùng lại CropEditor;
// sửa xong KHÔNG chờ dựng ảnh (việc nền) → sang trang kế ngay.
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { CropEditor } from "@/components/crop-editor";
import { Button } from "@/components/ui/button";
import { applyEditQueued, markChecked, reviewReason, reviewTargets } from "@/lib/batch-review";
import type { Doc, Page } from "@/lib/db";
import type { PageReview } from "@/lib/page-review";

type Props = { doc: Doc; reviews: Record<string, PageReview | undefined>; onSavePage: (p: Page, rebuild: boolean) => Promise<void>; onClose: () => void; onOpenPage: (i: number) => void };

export function BatchReview({ doc, reviews, onSavePage, onClose, onOpenPage }: Props) {
  // danh sách chốt lúc mở (không co lại khi trang được sửa → bộ đếm "x/n" ổn định)
  const [ids] = useState(() => reviewTargets(doc.pages, reviews).map((i) => doc.pages[i]!.id));
  const [pos, setPos] = useState(0);
  const [done, setDone] = useState<Record<string, "giu" | "sua">>({});
  const [crop, setCrop] = useState(false);
  const page = useMemo(() => doc.pages.find((p) => p.id === ids[pos]), [doc.pages, ids, pos]);
  const index = page ? doc.pages.indexOf(page) : -1;
  const left = ids.filter((id) => !done[id]).length;
  const next = () => {
    const after = ids.findIndex((id, k) => k > pos && !done[id]);
    const any = after >= 0 ? after : ids.findIndex((id, k) => k !== pos && !done[id]);
    if (any < 0) { toast.success("Đã xem lại xong các trang"); onClose(); return; }
    setPos(any);
  };
  if (!ids.length || !page) return null;
  const keep = async () => { setDone((d) => ({ ...d, [page.id]: "giu" })); await onSavePage(markChecked(page), false); next(); };
  return (
    <div role="dialog" aria-modal="true" aria-label="Xem lại theo lô" className="fixed inset-0 z-50 flex flex-col bg-background">
      <header className="flex items-center gap-2 border-b border-border px-4 py-3">
        <div className="min-w-0 flex-1">
          <p className="font-display text-sm font-semibold">Xem lại {pos + 1}/{ids.length} · trang {index + 1}</p>
          <p className="text-xs text-muted-foreground" data-testid="review-left">{left ? `Còn ${left} trang cần xem` : "Đã xem hết"}</p>
        </div>
        <Button variant="glass" size="sm" onClick={onClose}>Đóng</Button>
      </header>
      <div className="flex min-h-0 flex-1 flex-col items-center gap-3 overflow-auto p-4">
        <img src={page.src} alt={`Trang ${index + 1}`} className="max-h-[56dvh] max-w-full rounded-lg object-contain shadow" />
        <p className="max-w-md text-center text-sm" data-testid="review-reason">{done[page.id] === "sua" ? "Đã sửa khung — ảnh đầy đủ đang được dựng ở nền." : reviewReason(page, reviews[page.id]) || "Trang này ổn."}</p>
      </div>
      <footer className="grid grid-cols-3 gap-2 border-t border-border p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
        <Button variant="glass" onClick={() => setCrop(true)}>Sửa khung</Button>
        <Button variant="glass" onClick={() => void keep()}>Giữ nguyên</Button>
        <Button onClick={next}>Trang kế</Button>
        <button className="col-span-3 py-1 text-xs text-muted-foreground underline" onClick={() => { onClose(); onOpenPage(index); }}>Mở trang này để chỉnh đầy đủ (lọc, xoay…)</button>
      </footer>
      {crop && <CropEditor src={page.orig} quad={page.edit.quad} paper={page.edit.paper} onClose={() => setCrop(false)}
        onApply={(quad, paper) => {
          setCrop(false); setDone((d) => ({ ...d, [page.id]: "sua" }));
          void onSavePage(applyEditQueued(page, { quad, paper }), true); // không await: dựng nền, sang trang kế ngay
          next();
        }} />}
    </div>
  );
}
