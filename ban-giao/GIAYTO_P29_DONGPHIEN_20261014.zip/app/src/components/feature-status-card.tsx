// FX-01: thẻ "Tình trạng tính năng" ở mục Tôi.
import { useEffect, useState } from "react";
import { cloudReady, useUser } from "@/lib/auth";
import { DAILY_LIMIT, getQuota } from "@/lib/doc-chat";
import { driveReady } from "@/lib/drive";
import { featureStatuses, gatherFeatureEnv, useOnline, type FeatureRow, type FeatureState } from "@/lib/feature-status";
import { offlineOcrReady } from "@/lib/offline";
import { buildReport, readPerf } from "@/lib/perf-stats";
import { readScanLog } from "@/lib/scan-log";
import { useSettings } from "@/lib/settings";

const DOT: Record<FeatureState, string> = { ok: "bg-emerald-500", warn: "bg-amber-500", off: "bg-muted-foreground/50" };
const WORD: Record<FeatureState, string> = { ok: "Dùng được", warn: "Lưu ý", off: "Chưa dùng được" };

function summary(rows: FeatureRow[]) {
  const n = (k: FeatureState) => rows.filter((r) => r.state === k).length;
  return [`${n("ok")} dùng được`, n("warn") && `${n("warn")} lưu ý`, n("off") && `${n("off")} chưa dùng được`].filter(Boolean).join(" · ");
}

export function FeatureStatusCard() {
  const online = useOnline();
  const { user } = useUser();
  const s = useSettings();
  const [rows, setRows] = useState<FeatureRow[] | null>(null);
  useEffect(() => {
    let live = true;
    const r = buildReport(readPerf(), readScanLog()); const q = getQuota();
    void gatherFeatureEnv({
      online, cloud: cloudReady(), signedIn: !!user, drive: driveReady(), ocrOffline: offlineOcrReady(s.ocrLang),
      askLeft: q.left, askLimit: DAILY_LIMIT, aiErrorRate: r.ai.ok + r.ai.fail >= 3 ? r.ai.errorRate : null,
    }).then((env) => { if (live) setRows(featureStatuses(env)); });
    return () => { live = false; };
  }, [online, user, s.ocrLang]);
  return (
    <section className="rise rise-2 px-5 pt-5" aria-labelledby="fx01-title">
      <h2 id="fx01-title" className="mb-2 font-display text-[0.8125rem] font-semibold text-muted-foreground">Tình trạng tính năng</h2>
      <details className="document-row group overflow-hidden rounded-[16px]">
        <summary className="flex min-h-[52px] cursor-pointer list-none items-center gap-3 px-4 py-2 text-sm [&::-webkit-details-marker]:hidden">
          <span className="min-w-0 flex-1">{rows ? summary(rows) : "Đang kiểm tra…"}</span>
          <span className="shrink-0 text-xs font-semibold text-primary group-open:hidden">Xem</span><span className="hidden shrink-0 text-xs font-semibold text-primary group-open:inline">Thu gọn</span>
        </summary>
        <ul className="divide-y divide-border border-t border-border" data-testid="feature-status">
          {(rows ?? []).map((r) => (
            <li key={r.id} data-feature={r.id} data-state={r.state} className="flex min-h-[52px] items-start gap-3 px-4 py-2.5">
              <span aria-hidden className={`mt-1.5 size-2.5 shrink-0 rounded-full ${DOT[r.state]}`} />
              <span className="min-w-0 flex-1">
                <span className="flex items-baseline justify-between gap-2 text-sm"><span className="font-medium">{r.label}</span><span className="shrink-0 text-[0.6875rem] text-muted-foreground">{WORD[r.state]}</span></span>
                <span className="block text-xs leading-5 text-muted-foreground">{r.detail}</span>
              </span>
            </li>
          ))}
        </ul>
      </details>
    </section>
  );
}
