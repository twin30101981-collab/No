// Supabase GIẢ trong bộ nhớ cho kiểm V2 đồng bộ mây (BL-05b): đủ các lời gọi cloud-sync dùng.
type Row = { id?: string; local_id?: string; document_id?: unknown; revoked_at?: string | null; deleted_at?: string | null; client_updated_at?: number; [k: string]: unknown };
type Tables = { documents: Row[]; pages: Row[]; folders: Row[]; share_links: Row[] };
export function makeFakeSupabase(uid = "u1") {
  const db: Tables = { documents: [], pages: [], folders: [], share_links: [] };
  const tbl = db as unknown as Record<string, Row[]>;
  const files = new Map<string, Blob>();
  const log: string[] = [];
  let seq = 0;
  function q(table: string) {
    const filters: ((r: Row) => boolean)[] = [];
    let op: "select" | "delete" | "update" | "upsert" = "select"; let patch: Row = {}; let rows: Row[] = []; let conflict: string[] = []; let single = false; let ignoreDup = false;
    const api = {
      select() { return api; },
      eq(k: string, v: unknown) { filters.push((r) => r[k] === v); return api; },
      is(k: string, v: unknown) { filters.push((r) => (r[k] ?? null) === v); return api; },
      not(k: string, _op: string, list: string) { const s = new Set(list.slice(1, -1).split(",").map((x) => x.replace(/^"|"$/g, ""))); filters.push((r) => !s.has(String(r[k]))); return api; },
      in(k: string, list: unknown[]) { filters.push((r) => list.includes(r[k])); return api; },
      single() { single = true; return api; },
      maybeSingle() { single = true; return api; },
      delete() { op = "delete"; return api; },
      update(p: Row) { op = "update"; patch = p; return api; },
      upsert(r: Row | Row[], o?: { onConflict?: string; ignoreDuplicates?: boolean }) { op = "upsert"; rows = Array.isArray(r) ? r : [r]; conflict = (o?.onConflict ?? "id").split(","); ignoreDup = !!o?.ignoreDuplicates; return api; },
      then(res: (v: { data: unknown; error: null }) => unknown, rej?: (e: unknown) => unknown) {
        try {
          const t = tbl[table]!; let data: unknown = null;
          if (op === "upsert") {
            const out: Row[] = [];
            for (const r of rows) {
              const hit = t.find((x) => conflict.every((k) => x[k] === r[k]));
              if (hit) { if (!ignoreDup) Object.assign(hit, r); out.push(hit); } else { const n = { id: `id${++seq}`, ...r }; t.push(n); out.push(n); }
            }
            log.push(`upsert ${table} ${rows.length}`); data = single ? out[0] : out;
          } else {
            const hit = t.filter((r) => filters.every((f) => f(r)));
            if (op === "delete") { tbl[table] = t.filter((r) => !hit.includes(r)); log.push(`delete ${table} ${hit.length}`); if (table === "documents") { const ids = new Set<unknown>(hit.map((r) => r.id)); db.pages = db.pages.filter((p) => !ids.has(p.document_id)); db.share_links = db.share_links.filter((p) => !ids.has(p.document_id)); } }
            else if (op === "update") { hit.forEach((r) => Object.assign(r, patch)); log.push(`update ${table} ${hit.length}`); }
            data = single ? hit[0] ?? null : hit;
          }
          return Promise.resolve({ data, error: null }).then(res, rej);
        } catch (e) { return Promise.reject(e).then(res, rej); }
      },
    };
    return api;
  }
  const client = {
    auth: { getUser: async () => ({ data: { user: { id: uid } } }) },
    from: (t: string) => q(t),
    storage: { from: () => ({
      upload: async (p: string, b: Blob) => { files.set(p, b); return { error: null }; },
      remove: async (ps: string[]) => { ps.forEach((p) => files.delete(p)); log.push(`remove ${ps.length}`); return { error: null }; },
      download: async (p: string) => (files.has(p) ? { data: files.get(p)!, error: null } : { data: null, error: new Error("404") }),
    }) },
  };
  return { client, db, files, log };
}
export const fake = makeFakeSupabase();
