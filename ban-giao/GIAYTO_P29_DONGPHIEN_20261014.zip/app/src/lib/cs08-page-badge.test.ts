import { describe, expect, it } from "vitest";
import { pageBadge, pendingPageCount } from "./page-state";

describe("CS-08 pageBadge — nhãn theo trạng thái bền", () => {
  it("mỗi trạng thái có nhãn đúng; trang xong bình thường không nhãn", () => {
    expect(pageBadge({ status: "cho" })?.text).toBe("Chờ xử lý");
    expect(pageBadge({ status: "dang", progress: 42.4 })?.text).toBe("42%");
    expect(pageBadge({ status: "dang" })?.text).toBe("Đang xử lý…");
    expect(pageBadge({ status: "loi", error: "không đọc được ảnh gốc" })).toMatchObject({ kind: "loi", text: "Lỗi", reason: "không đọc được ảnh gốc" });
    expect(pageBadge({ status: "xem-lai", warnings: ["mờ"] })).toMatchObject({ kind: "xem-lai", reason: "mờ" });
    expect(pageBadge({ status: "xong" })).toBeNull();
    expect(pageBadge({})).toBeNull(); // tài liệu cũ không có status = xong
  });
  it("trang tự đổi bộ lọc (CS-05) có nhãn kèm lý do", () => {
    expect(pageBadge({ status: "xong", autoFilter: { from: "auto", to: "magic", reason: "ảnh tối → Tăng nét" } })).toMatchObject({ kind: "tu-loc", reason: expect.stringContaining("ảnh tối → Tăng nét") });
  });
  it("lỗi không có lý do vẫn có câu giải thích; tiến độ kẹp 0–100", () => {
    expect(pageBadge({ status: "loi" })?.reason).toBeTruthy();
    expect(pageBadge({ status: "dang", progress: 140 })?.text).toBe("100%");
  });
  it("pendingPageCount đếm moi/cho/dang", () => {
    expect(pendingPageCount([{ status: "moi" }, { status: "cho" }, { status: "dang" }, { status: "xong" }, { status: "loi" }, {}])).toBe(3);
  });
});
