/** S15h: làm nét thích nghi, bảo vệ nét mảnh.
 *  - Gain giảm dần khi chênh lệch lớn (cạnh đã đậm không bị quầng sáng).
 *  - Kết quả bị kẹp trong [min,max] độ sáng 3×3 quanh điểm → không vọt lố, nét 1 px không bị
 *    "ăn" thành trắng hay loang đen; vùng phẳng (|diff| ≤ threshold) giữ nguyên để không nổi nhiễu. */
type Px = Uint8ClampedArray;
const ci = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);

export function adaptiveGain(diff: number, amount: number, knee = 40) {
  const a = Math.abs(diff);
  return amount / (1 + a / knee);
}

export function sharpenAdaptive(d: Px, W: number, H: number, amount: number, threshold = 4) {
  const n = W * H, L = new Float32Array(n), t = new Float32Array(n), B = new Float32Array(n);
  for (let i = 0; i < n; i++) L[i] = d[i * 4] * 0.3 + d[i * 4 + 1] * 0.59 + d[i * 4 + 2] * 0.11;
  // CS-17a: nhân 1-4-6-4-1 viết thẳng (cùng thứ tự cộng), mép ảnh vẫn kẹp chỉ số như cũ → kết quả giữ nguyên.
  for (let y = 0; y < H; y++) {
    const r = y * W;
    for (let x = 0; x < W; x++) {
      const a = r + (x < 2 ? ci(x - 2, 0, W - 1) : x - 2), b = r + (x < 1 ? 0 : x - 1), c = r + (x > W - 2 ? W - 1 : x + 1), e = r + (x > W - 3 ? ci(x + 2, 0, W - 1) : x + 2);
      t[r + x] = (0 + L[a] + 4 * L[b] + 6 * L[r + x] + 4 * L[c] + L[e]) / 16;
    }
  }
  for (let y = 0; y < H; y++) {
    const a = ci(y - 2, 0, H - 1) * W, b = ci(y - 1, 0, H - 1) * W, m = y * W, c = ci(y + 1, 0, H - 1) * W, e = ci(y + 2, 0, H - 1) * W;
    for (let x = 0; x < W; x++) B[m + x] = (0 + t[a + x] + 4 * t[b + x] + 6 * t[m + x] + 4 * t[c + x] + t[e + x]) / 16;
  }
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = y * W + x, diff = L[i] - B[i];
    if (Math.abs(diff) <= threshold) continue;
    let lo = 255, hi = 0;
    const ra = (y > 0 ? y - 1 : 0) * W, rc = (y < H - 1 ? y + 1 : H - 1) * W, xa = x > 0 ? x - 1 : 0, xc = x < W - 1 ? x + 1 : W - 1;
    for (const r of [ra, y * W, rc]) for (const xx of [xa, x, xc]) {
      const v = L[r + xx]; if (v < lo) lo = v; if (v > hi) hi = v;
    }
    const target = ci(L[i] + adaptiveGain(diff, amount) * diff, lo, hi);
    const add = target - L[i];
    d[i * 4] = d[i * 4] + add; d[i * 4 + 1] = d[i * 4 + 1] + add; d[i * 4 + 2] = d[i * 4 + 2] + add;
  }
  return d;
}
