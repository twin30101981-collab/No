import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { authMessage } from "./auth";
import { friendlyError, isVietnamese, userMessage } from "./errors";
import { SCAN_ERRORS } from "./scan-errors";

// FX-03: mọi câu lỗi hiện lên giao diện phải là tiếng Việt.
const ENGLISH = [
  new TypeError("Failed to fetch"), new Error("toBlob"), new Error("upsert"), new Error("timeout"),
  new TypeError("Cannot read properties of undefined (reading 'x')"), new Error("The operation is insecure."),
  Object.assign(new Error("The requested file could not be read"), { name: "NotReadableError" }), "boom", null, undefined, {},
];

describe("FX-03 userMessage — một cửa câu lỗi", () => {
  it("lỗi kỹ thuật tiếng Anh không bao giờ hiện nguyên văn", () => {
    for (const e of ENGLISH) { const m = userMessage(e, "Không dán được ảnh"); expect(isVietnamese(m), `${String(e)} → ${m}`).toBe(true); }
  });
  it("thông điệp tiếng Việt của app được giữ nguyên", () => {
    expect(userMessage(new Error("Chứng thư đã hết hạn hoặc chưa có hiệu lực."), "x")).toBe("Chứng thư đã hết hạn hoặc chưa có hiệu lực.");
  });
  it("lỗi đã biết → câu dễ hiểu, lạ → câu dự phòng của nơi gọi", () => {
    expect(userMessage(new TypeError("Failed to fetch"), "fb")).toBe("Mất kết nối mạng");
    expect(userMessage(new Error("toBlob"), "Không lưu được nét vẽ")).toBe("Không lưu được nét vẽ");
  });
  it("friendlyError không nuốt thông điệp tiếng Việt thành 'Đã có lỗi xảy ra' (trước: nuốt)", () => {
    expect(friendlyError(new Error("Chứng thư đã hết hạn hoặc chưa có hiệu lực.")).title).toBe("Chứng thư đã hết hạn hoặc chưa có hiệu lực");
    for (const e of ENGLISH) { const f = friendlyError(e); expect(isVietnamese(f.title) && isVietnamese(f.hint)).toBe(true); }
  });
  it("authMessage: câu lạ của máy chủ đăng nhập không hiện tiếng Anh (trước: trả nguyên văn)", () => {
    for (const m of ["Database error saving new user", "Signups not allowed for this instance", "Invalid login credentials"]) expect(isVietnamese(authMessage(m)), m).toBe(true);
  });
  it("danh mục SCAN_ERRORS toàn tiếng Việt", () => {
    for (const [k, v] of Object.entries(SCAN_ERRORS)) expect(isVietnamese(v.message) && isVietnamese(v.hint), k).toBe(true);
  });
});

// Kiểm tĩnh: chặn tái diễn mẫu `e instanceof Error ? e.message : …` / `(x as Error).message` đưa thẳng lên giao diện.
function files(dir: string): string[] {
  return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(tsx?|jsx?)$/.test(f) && !/\.test\./.test(f) ? [p] : []; });
}
describe("FX-03 kiểm tĩnh mã nguồn", () => {
  const src = join(__dirname, "..");
  const all = files(src).map((p) => ({ p, s: readFileSync(p, "utf8") }));
  it("không toast/setErr/aiError nào in thẳng error.message", () => {
    const bad = /(toast(\.\w+)?\(|setErr\(|aiError:)[^;\n]*\b(e|err|error|x)\)?(\s+as\s+Error\))?\.message\b/;
    const hits = all.flatMap(({ p, s }) => s.split("\n").map((l, i) => (bad.test(l) ? `${p.slice(src.length)}:${i + 1}` : "")).filter(Boolean));
    expect(hits).toEqual([]);
  });
  it("mọi chuỗi toast viết cứng là tiếng Việt", () => {
    const lit = /toast(?:\.(?:error|warning|success|info|message|loading))?\(\s*(["'`])((?:(?!\1).)*)\1/g;
    const hits = all.flatMap(({ p, s }) => [...s.matchAll(lit)].filter((m) => !isVietnamese(m[2]!)).map((m) => `${p.slice(src.length)}: ${m[2]}`));
    expect(hits).toEqual([]);
  });
});
