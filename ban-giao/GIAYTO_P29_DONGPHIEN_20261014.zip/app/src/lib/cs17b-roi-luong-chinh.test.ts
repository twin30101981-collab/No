import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { docChain, flattenApply, flattenMap, runJob } from "./pixels";
import { edgeSaturatedMask, inkDeepen } from "./ink-deepen";

/** CS-17b: phần việc trước chạy ở luồng chính nay gộp vào việc Worker — kết quả phải y hệt cách cũ. */
const img = (W: number, H: number, seed: number) => {
  const d = new Uint8ClampedArray(W * H * 4); let s = seed;
  const rnd = () => ((s = (s * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const ink = y % 19 < 5 && x > 20 && x < W - 20 && rnd() > 0.3, v = ink ? 40 : 210 - ((40 * x) / W) | 0, i = (y * W + x) * 4;
    d[i] = v; d[i + 1] = v - 2; d[i + 2] = ink ? 120 : v - 6; d[i + 3] = 255;
  }
  return d;
};

describe("CS-17b việc Worker gộp", () => {
  it("docchain deep = docChain rồi đậm hoá dịu R6.1d (trước ở luồng chính)", () => {
    for (const sharp of [false, true]) {
      const a = img(240, 330, 3), W = 240, H = 330;
      const want = docChain(a.slice(), W, H, sharp); inkDeepen(want, 170, 2.2, edgeSaturatedMask(want, W, H));
      expect(Array.from(runJob({ op: "docchain", d: a.slice(), W, H, sharp, deep: true }))).toEqual(Array.from(want));
    }
  });
  it("docchain không deep giữ nguyên docChain", () => {
    const a = img(120, 160, 5);
    expect(Array.from(runJob({ op: "docchain", d: a.slice(), W: 120, H: 160, sharp: false }))).toEqual(Array.from(docChain(a.slice(), 120, 160, false)));
  });
  it("flatten-small = flattenMap trên bản nhỏ + flattenApply (trước flattenMap ở luồng chính)", () => {
    const big = img(400, 560, 7), small = img(100, 140, 7);
    const want = flattenApply(big.slice(), 400, 560, flattenMap(small, 100, 140));
    expect(Array.from(runJob({ op: "flatten-small", d: big.slice(), W: 400, H: 560, s: small, sw: 100, sh: 140 }))).toEqual(Array.from(want));
  });
  it("kiểm tĩnh: image.ts không còn đậm hoá/đo nền ở luồng chính; nắn GPU thử Worker trước", () => {
    const src = readFileSync("src/lib/image.ts", "utf8");
    expect(src).not.toMatch(/ik\.inkDeepen\(d, 170, 2\.2/);
    expect(src).not.toMatch(/flattenMap\(sd/);
    expect(src).toMatch(/await gpuWarpOff\(sd,/);
  });
});
