import { useEffect, useState } from "react";
import { toast } from "sonner";
import { addTombstones } from "./tombstones";
import { expiredIds } from "./trash";
import { getVaultKey, openDoc, sealDoc, setVaultKey, deriveKey, newDataKey, wrapDataKey, unwrapDataKey, sealVerified, newRecoveryCode, normRecovery, newSalt, type EncBlob } from "./vault";
import { getSettings, hashPin, setSettings } from "./settings";
import { blobifyDoc, inlineDoc, packDoc, revokeDoc, unpackDoc, srcBytes } from "./disk-pack";
import { normalizeDoc } from "./page-state";

export type Filter = "original" | "magic" | "auto" | "sharp" | "mono" | "gray" | "ink" | "eco" | "vivid" | "bright" | "shadow" | "denoise";
export type Quad = [number, number][]; // 4 normalized points: TL, TR, BR, BL
export type PageEdit = { quad?: Quad | undefined; paper?: import("./detect").Paper | undefined; rotation: number; filter: Filter; brightness: number; contrast: number; /** P4/TD-09: nắn phẳng trang cong. undefined = tự động (đo độ cong), false = người dùng tắt, true = người dùng bật. */ flatten?: boolean | undefined; /** P4.3–P4.6: công cụ 3 mức. */ tools?: import("./tool-levels").Tools | undefined; /** R2.4: cấp độ bộ lọc 0–100 (thiếu = 100). */ level?: number | undefined };
export type Page = { id: string; orig: string; src: string; edit: PageEdit; text?: string; thumb?: string; thumbKey?: string; origW?: number; origH?: number; /** R3.1: người dùng đã sửa tay trang này. */ manual?: boolean; /** R4.1: dấu vân ảnh pHash (16 ký tự hex) để chống trùng. */ phash?: string; /** R4.1: loại ảnh nhập — flat/screenshot không cắt lại. */ importKind?: import("./dedupe-phash").ImportKind;
  /** CS-01: trạng thái bền (thiếu = "xong", xem page-state.ts). */ status?: import("./page-state").PageStatus; /** Tiến độ 0–100 khi status = "dang". */ progress?: number;
  /** Độ tin cậy của khung đề xuất, 0–1. */ quadConfidence?: number; /** Cảnh báo chất lượng (mờ, lóa, chữ vắt mép…). */ warnings?: string[]; /** Lý do khi status = "loi". */ error?: string;
  /** Khoá ảnh gốc trong kho blob-store (CS-03 dùng); thiếu = ảnh gốc nằm trong `orig`. */ origBlobKey?: string;
  /** CS-05: vì sao app tự chọn bộ lọc cho trang này (vd. "ảnh tối, chữ mờ → Tăng nét"). */ autoFilter?: { from: Filter; to: Filter; reason: string } };
export type Doc = {
  id: string; name: string; folder: string; kind: string;
  createdAt: number; updatedAt: number; pages: Page[]; locked?: boolean;
  tags?: string[]; fields?: Record<string, string>;
  /** Soft-delete time; set = in trash. */ deletedAt?: number;
  /** Nội dung mã hoá theo PIN (pages rỗng khi còn khoá). */ enc?: EncBlob;
};

export const FILTER_LABEL: Record<Filter, string> = {
  original: "Màu gốc", magic: "Thần kỳ", auto: "Tài liệu sáng", sharp: "Sắc nét", mono: "Đen trắng", gray: "Xám", ink: "Mực", eco: "Tiết kiệm mực", vivid: "Tăng màu", bright: "Làm sáng", shadow: "Khử bóng", denoise: "Khử nhiễu",
};

export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);

let dbPromise: Promise<IDBDatabase> | null = null;
export function openDb() { return open(); }
function open() {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open("ghi-nhanh", 2);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains("docs")) db.createObjectStore("docs", { keyPath: "id" });
        if (!db.objectStoreNames.contains("conversions")) db.createObjectStore("conversions", { keyPath: "id" });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    // HM-15: không giữ lại lời hứa đã bị từ chối, để lần mở sau còn thử lại được.
    dbPromise.catch(() => { dbPromise = null; });
  }
  return dbPromise;
}
/** BL-02 (RS-23/28/32): lỗi giao dịch → Error tiếng Việt rõ ràng (giữ lỗi gốc ở `cause`). Bộ nhớ đầy thường chỉ lộ ra lúc COMMIT. */
export function idbError(e: unknown): Error {
  const name = (e as { name?: string } | null)?.name;
  const msg = name === "QuotaExceededError"
    ? "Bộ nhớ trên máy đã đầy — chưa lưu được. Hãy xoá bớt tài liệu hoặc dọn thùng rác rồi thử lại."
    : `Chưa lưu được vào bộ nhớ máy${name ? ` (${name})` : ""} — dữ liệu cũ vẫn giữ nguyên, hãy thử lại.`;
  return Object.assign(new Error(msg, { cause: e }), { name: name === "QuotaExceededError" ? "QuotaExceededError" : "IdbWriteError" });
}
/** Một lệnh trong một giao dịch. BL-02: chỉ resolve khi giao dịch COMMIT xong (oncomplete) — trước đây resolve ở req.onsuccess,
 *  nên giao dịch bị huỷ lúc commit (bộ nhớ đầy…) vẫn bị báo "đã lưu" và bộ nhớ đệm bị đổi trong khi đĩa giữ bản cũ. */
async function tx<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest): Promise<T> {
  const db = await open();
  return new Promise((resolve, reject) => {
    const t = db.transaction("docs", mode); const req = fn(t.objectStore("docs"));
    t.oncomplete = () => resolve(req.result as T);
    const fail = () => reject(idbError(t.error ?? req.error ?? new DOMException("Giao dịch bị huỷ", "AbortError")));
    t.onerror = fail; t.onabort = fail;
  });
}

/** Nhiều thao tác trong một giao dịch — nhanh hơn hẳn so với từng lệnh riêng. */
async function batch(fn: (s: IDBObjectStore) => void) {
  const db = await open();
  await new Promise<void>((resolve, reject) => {
    const t = db.transaction("docs", "readwrite"); fn(t.objectStore("docs"));
    const fail = () => reject(idbError(t.error ?? new DOMException("Giao dịch bị huỷ", "AbortError")));
    t.oncomplete = () => resolve(); t.onerror = fail; t.onabort = fail;
  });
}
/** Dạng ghi xuống ổ: tài liệu khoá được mã hoá khi đang có khoá PIN trong bộ nhớ. */
async function toDisk(d: Doc): Promise<Doc> {
  const key = getVaultKey();
  if (d.locked && key && !d.enc) return sealDoc(await inlineDoc(d), key);
  if (!d.locked && d.enc) throw new Error("Tài liệu còn mã hoá — mở khoá bằng PIN trước.");
  return packDoc(d);
}
async function writeDocs(docs: Doc[]) {
  const disk = await Promise.all(docs.map(toDisk));
  await batch((s) => disk.forEach((d) => s.put(d)));
  const m = new Map(docs.map((d) => [d.id, normalizeDoc(d.locked ? d : blobifyDoc(d))])); cache = cache.map((d) => m.get(d.id) ?? d); emit();
}
/** BL-05a: MỌI lần ghi kho đi qua một hàng tuần tự. Trước đây mỗi nơi "đọc bản đang có → await → ghi nguyên tài liệu"
 *  chạy chồng nhau (việc nền dựng trang, OCR, xoá, đổi thư mục/thẻ…) → lần ghi sau đè mất thay đổi của lần trước
 *  (đã tái hiện: xoá xong tài liệu "hồi sinh"). Sửa tài liệu đã có thì dùng mutateDoc/mutateDocs — hàm `fn` nhận bản MỚI NHẤT
 *  ngay trong lượt ghi. Không gọi saveDoc/mutateDoc… từ bên trong `fn` (cùng hàng → treo). */
let writeChain: Promise<unknown> = Promise.resolve();
function serial<T>(run: () => Promise<T>): Promise<T> {
  const p = writeChain.then(run, run);
  writeChain = p.catch(() => {});
  return p;
}
/** Ghi nguyên các tài liệu (dùng cho dữ liệu từ ngoài vào: khôi phục, kéo từ mây, khoá két). Sửa tài liệu đã có → mutateDocs. */
export function saveDocs(docs: Doc[]) { return serial(() => writeDocs(docs)); }
/** BL-05a: sửa MỘT tài liệu trên bản mới nhất. `fn` thuần, đồng bộ; trả null/undefined (hoặc chính bản cũ) = không ghi.
 *  Trả bản đã ghi, hoặc bản hiện có nếu không đổi, hoặc null nếu tài liệu không còn (đã xoá hẳn). */
export function mutateDoc(id: string, fn: (d: Doc) => Doc | null | undefined, touch = false): Promise<Doc | null> {
  return serial(async () => {
    const cur = cache.find((d) => d.id === id); if (!cur) return null;
    const next = fn(cur); if (!next || next === cur) return cur;
    return writeDoc({ ...next, id }, touch);
  });
}
/** BL-05a: sửa nhiều tài liệu trên bản mới nhất trong MỘT giao dịch. `pick` = danh sách id hoặc điều kiện trên bản mới nhất.
 *  BL-05b: `touch` = thay đổi của người dùng (xoá, khôi phục, thư mục, thẻ) → tăng updatedAt để lần đồng bộ sau gửi lên mây (không đổi thứ tự). */
export function mutateDocs(pick: Iterable<string> | ((d: Doc) => boolean), fn: (d: Doc) => Doc | null | undefined, touch = false): Promise<Doc[]> {
  return serial(async () => {
    const want = typeof pick === "function" ? pick : ((ids) => (d: Doc) => ids.has(d.id))(new Set(pick));
    const next: Doc[] = []; const now = Date.now();
    for (const d of cache) { if (!want(d)) continue; const n = fn(d); if (n && n !== d) next.push({ ...n, id: d.id, ...(touch ? { updatedAt: Math.max(now, d.updatedAt + 1) } : {}) }); }
    if (next.length) await writeDocs(next);
    return next;
  });
}

let cache: Doc[] = [];
export const getDocs = () => cache;
let ready = false;
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());

export async function loadDocs() {
  await serial(async () => { // BL-05a: không đọc đĩa xen giữa một lượt ghi (đọc xong mới gán → mất bản vừa ghi khỏi bộ đệm)
    const raw = await Promise.all((await tx<Doc[]>("readonly", (s) => s.getAll())).map(unpackDoc));
    const key = getVaultKey();
    cache = (await Promise.all(raw.map((d) => (key && d.enc ? openDoc(d, key).catch(() => d) : d)))).map(normalizeDoc).sort((a, b) => b.updatedAt - a.updatedAt); // CS-01: trang cũ chưa có status → "xong"
  });
  ready = true; emit();
  // Tự dọn: xóa hẳn tài liệu đã ở thùng rác quá 30 ngày.
  const old = expiredIds(cache);
  if (old.length) await purgeDocs(old).catch(() => {});
}
/** CS-02: bộ điều phối nền chạy ở mọi màn — đảm bảo danh sách tài liệu đã nạp trước khi tra cứu trang. */
export async function ensureDocsLoaded() { if (!ready) await loadDocs(); }
/** Ghi NGUYÊN một tài liệu — chỉ dùng cho tài liệu MỚI tạo (newDoc) hoặc dữ liệu từ ngoài vào. Sửa tài liệu đã có → mutateDoc. */
export function saveDoc(doc: Doc, touch = true) { return serial(() => writeDoc(doc, touch)); }
async function writeDoc(doc: Doc, touch: boolean) {
  let next = touch ? { ...doc, updatedAt: Date.now() } : doc;
  const disk = await toDisk(next);
  await tx("readwrite", (s) => s.put(disk));
  next = normalizeDoc(next.locked ? next : blobifyDoc(next));
  void import("./persist").then((m) => m.persistOnce());
  cache = touch ? [next, ...cache.filter((d) => d.id !== doc.id)] : cache.map((d) => (d.id === doc.id ? next : d));
  emit();
  return next;
}
/** Move to trash (soft delete); restore with restoreDocs. */
export async function deleteDocs(ids: string[]) {
  const now = Date.now();
  await mutateDocs(ids, (d) => ({ ...d, deletedAt: now }), true);
}
export async function restoreDocs(ids: string[]) {
  await mutateDocs(ids, ({ deletedAt: _, ...d }) => d, true);
}
/** Permanently remove. */
export function purgeDocs(ids: string[]) { return serial(() => purgeNow(ids)); }
async function purgeNow(ids: string[]) {
  await batch((s) => ids.forEach((id) => s.delete(id)));
  addTombstones(ids); // BL-05b: lần đồng bộ sau xoá bản trên mây, không kéo lại về
  const gone = new Set(ids); const dead = cache.filter((d) => gone.has(d.id));
  cache = cache.filter((d) => !gone.has(d.id)); emit();
  const keep = new Set(cache.flatMap((d) => d.pages.flatMap((p) => [p.orig, p.src])));
  dead.forEach((d) => revokeDoc(d, keep));
}
/** Thay toàn bộ kho bằng `docs` trong MỘT giao dịch (lỗi giữa chừng → giữ nguyên kho cũ). Ảnh ghi dạng nhị phân như saveDocs. */
export async function replaceAll(docs: Doc[]) {
  const disk = docs.map((d) => (d.enc ? d : packDoc(d)));
  await serial(() => batch((s) => { s.clear(); disk.forEach((d) => s.put(d)); }));
  await loadDocs();
}

let warned = false;
/** HM-15: không đọc được kho tài liệu (IndexedDB bị chặn/không có) → vẫn mở app với danh sách rỗng và báo rõ một lần. */
function onLoadFailed(e: unknown) {
  console.error(e);
  cache = []; ready = true; emit();
  if (warned) return; warned = true;
  toast.error("Máy này không cho Ghi Nhanh lưu tài liệu", { description: "Có thể đang ở chế độ riêng tư hoặc đã chặn lưu dữ liệu. Mở bằng cửa sổ thường và cho phép lưu; tài liệu mới có thể không được giữ." });
}

export function useDocs() {
  const [, force] = useState(0);
  useEffect(() => {
    const l = () => force((n) => n + 1);
    listeners.add(l);
    if (!ready) void loadDocs().catch(onLoadFailed); else l();
    return () => { listeners.delete(l); };
  }, []);
  return { docs: cache.filter((d) => !d.deletedAt), trash: cache.filter((d) => d.deletedAt), all: cache, ready };
}

export function newPage(orig: string, src = orig, edit?: Partial<PageEdit>): Page {
  return { id: uid(), orig, src, edit: { rotation: 0, filter: "original", brightness: 0, contrast: 0, ...edit }, status: "xong" };
}

export function newDoc(pages: Page[], name?: string, kind = "Tài liệu"): Doc {
  const d = new Date();
  const stamp = `${String(d.getDate()).padStart(2, "0")}-${String(d.getMonth() + 1).padStart(2, "0")} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
  return { id: uid(), name: name ?? `${kind} ${stamp}`, folder: "Chung", kind, createdAt: Date.now(), updatedAt: Date.now(), pages };
}

export function docSize(doc: Doc) {
  const bytes = doc.pages.reduce((n, p) => n + srcBytes(p.src), 0);
  if (bytes > 0 && bytes < 1e3) return "1 KB";
  return bytes > 1e6 ? `${(bytes / 1e6).toFixed(1)} MB` : `${Math.round(bytes / 1e3)} KB`;
}
export function docText(doc: Doc) { return doc.pages.map((p) => p.text ?? "").join("\n"); }
export function timeAgo(t: number) {
  const m = Math.round((Date.now() - t) / 60000);
  if (m < 1) return "Vừa xong"; if (m < 60) return `${m} phút trước`;
  const h = Math.round(m / 60); if (h < 24) return `${h} giờ trước`;
  const days = Math.round(h / 24); return days === 1 ? "Hôm qua" : `${days} ngày trước`;
}

// ——— Mã hoá theo PIN (G3-08/G3-09) ———
// Khoá dữ liệu (DEK) ngẫu nhiên; lưu trong cài đặt ở dạng bọc bằng khoá từ PIN và (tuỳ chọn) mã khôi phục.
/** BL-03 (RS-18/24): mở từng tài liệu riêng (allSettled) — trước đây Promise.all: MỘT tài liệu hỏng làm cả két "sai PIN", không mở được gì.
 *  Tài liệu không mở được giữ NGUYÊN bản mã (không bị ghi đè). Trả số mở được / tổng / tên tài liệu lỗi. */
async function openAll(key: CryptoKey, fallback?: CryptoKey) {
  const sealed = cache.filter((d) => d.enc);
  const rs = await Promise.allSettled(sealed.map((d) => openDoc(d, key).catch((e) => { if (fallback) return openDoc(d, fallback); throw e; })));
  const m = new Map<string, Doc>(); const failed: string[] = [];
  rs.forEach((r, i) => { if (r.status === "fulfilled") m.set(r.value.id, r.value); else failed.push(sealed[i]!.name); });
  cache = cache.map((d) => m.get(d.id) ?? d);
  return { opened: m.size, total: sealed.length, failed };
}
function warnUnopened(failed: string[]) {
  if (failed.length) toast.warning(`${failed.length} tài liệu khoá không mở được`, { description: `Dữ liệu có thể bị hỏng (${failed.slice(0, 3).join(", ")}${failed.length > 3 ? "…" : ""}). Bản mã vẫn được giữ nguyên, chưa xoá gì.`, duration: 10000 });
}
/** Chuyển tài liệu khoá còn dạng rõ (dữ liệu cũ) hoặc mã theo khoá cũ sang khoá hiện tại, có kiểm tra từng tài liệu. */
export async function migrateLocked(key: CryptoKey, all = false) {
  // BL-03: KHÔNG BAO GIỜ đụng tài liệu còn bản mã (chưa mở được) — trước đây all=true gỡ `enc` rồi niêm phong lại → ghi đè bản mã gốc bằng rác.
  void all; const todo = cache.filter((d) => d.locked && !d.enc);
  const disk: Doc[] = []; const failed: string[] = [];
  for (const d of todo) { try { disk.push(await sealVerified((({ enc: _e, ...r }) => r as Doc)(d), key)); } catch { failed.push(d.name); } }
  if (disk.length) await batch((s) => disk.forEach((d) => s.put(d)));
  return { done: disk.length, failed };
}
export const plainLockedCount = () => cache.filter((d) => d.locked && !d.enc).length;

/** Mở khoá bằng PIN. Trả false nếu sai. Tự chuyển dữ liệu cũ sang dạng mã hoá. */
export async function unlockVault(pin: string, salt: string) {
  const kek = await deriveKey(pin, salt);
  const wrap = getSettings().vaultWrap;
  let dek: CryptoKey;
  try {
    // Có khoá bọc: PIN đúng/sai được xác minh khi gỡ bọc (AES-GCM) → tài liệu hỏng KHÔNG làm "sai PIN".
    if (wrap) { dek = await unwrapDataKey(wrap.pin, kek); warnUnopened((await openAll(dek)).failed); }
    else {
      // Bản G3-08 mã thẳng bằng khoá từ PIN → mở bằng khoá đó, tạo DEK mới rồi mã lại tất cả.
      // Không có khoá bọc để xác minh PIN: chỉ coi là SAI khi KHÔNG tài liệu nào mở được.
      const r = await openAll(kek); if (r.total && !r.opened) throw new Error("sai PIN"); warnUnopened(r.failed);
      dek = await newDataKey();
      setSettings({ vaultWrap: { v: 1, pin: await wrapDataKey(dek, kek) } });
      setVaultKey(dek); await migrateLocked(dek, true); emit(); return true;
    }
  } catch { return false; }
  setVaultKey(dek);
  if (plainLockedCount()) await migrateLocked(dek);
  emit();
  return true;
}
/** Quên PIN: mở bằng mã khôi phục rồi đặt PIN mới (khoá dữ liệu giữ nguyên, không mã lại). */
export async function recoverVault(code: string, newPin: string) {
  const wrap = getSettings().vaultWrap;
  if (!wrap?.rec || !wrap.recSalt) return false;
  try {
    const dek = await unwrapDataKey(wrap.rec, await deriveKey(normRecovery(code), wrap.recSalt));
    warnUnopened((await openAll(dek)).failed); setVaultKey(dek);
  } catch { return false; }
  const salt = newSalt(); const dek = getVaultKey()!;
  setSettings({ pin: await hashPin(newPin), pinSalt: salt, vaultWrap: { ...wrap, pin: await wrapDataKey(dek, await deriveKey(newPin, salt)) } });
  emit(); return true;
}
/** Tạo mã khôi phục mới (cần đang mở khoá). Mã cũ hết hiệu lực. */
export async function createRecovery() {
  const dek = getVaultKey(); const wrap = getSettings().vaultWrap;
  if (!dek || !wrap) throw new Error("Hãy mở khoá bằng PIN trước");
  const code = newRecoveryCode(); const recSalt = newSalt();
  setSettings({ vaultWrap: { ...wrap, rec: await wrapDataKey(dek, await deriveKey(normRecovery(code), recSalt)), recSalt } });
  return code;
}
/** Khoá lại: quên khoá trong bộ nhớ, đọc lại bản mã hoá từ ổ. */
export async function lockVault() { setVaultKey(null); if (ready) await loadDocs(); }
/** Đặt PIN mới (bọc lại khoá dữ liệu) hoặc tắt PIN (giải mã trả về dạng thường). Cần đang mở khoá. */
export async function rekeyVault(next: { pin: string; salt: string } | null) {
  const locked = cache.filter((d) => d.locked);
  if (locked.some((d) => d.enc)) throw new Error("Cần mở khoá trước khi đổi PIN");
  if (next) {
    const dek = getVaultKey() ?? (await newDataKey());
    const wrap = getSettings().vaultWrap;
    setSettings({ vaultWrap: { ...(wrap ?? {}), v: 1, pin: await wrapDataKey(dek, await deriveKey(next.pin, next.salt)) } });
    setVaultKey(dek); await saveDocs(locked);
  } else {
    // BL-03 (RS-02): GHI MỚI → KIỂM → MỚI XOÁ. Trước đây xoá khoá bọc + khoá dữ liệu TRƯỚC khi ghi bản giải mã → ghi lỗi
    // (bộ nhớ đầy…) thì tài liệu trên đĩa còn mã hoá mà khoá đã mất → mất dữ liệu vĩnh viễn.
    await saveDocs(locked.map(({ locked: _, ...d }) => d)); // lỗi ở đây → ném ra, PIN + khoá vẫn nguyên
    const disk = await Promise.all(locked.map((d) => tx<Doc | undefined>("readonly", (st) => st.get(d.id))));
    if (disk.some((d) => !d || d.enc || d.locked)) throw new Error("Kiểm tra sau khi giải mã không khớp — PIN vẫn được giữ, chưa xoá khoá. Hãy thử lại.");
    setVaultKey(null); { const { vaultWrap: _w, ...rest } = getSettings(); localStorage.setItem("ghi-nhanh-settings", JSON.stringify(rest)); setSettings({}); }
  }
}
