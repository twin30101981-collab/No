// BL-05a: màn tài liệu tính danh sách trang mới từ bản nó đang hiển thị (`base`). Trong lúc đó nơi khác (việc nền dựng trang,
// OCR, ảnh thu nhỏ, thêm trang) có thể đã ghi bản mới hơn (`latest`). Ghi thẳng `mine` sẽ đè mất các thay đổi đó.
// rebasePages áp ĐÚNG phần màn hình đã đổi lên bản mới nhất:
//  - thứ tự/xoá/nhân bản theo `mine`;
//  - trang màn hình không đụng (cùng đối tượng với base) → lấy bản mới nhất;
//  - trang màn hình đã sửa → các trường đã đổi đè lên bản mới nhất, trường khác giữ bản mới nhất;
//  - trang nơi khác đã xoá hẳn (có ở base, không còn ở latest) → bỏ; trang nơi khác vừa thêm → giữ, nối cuối.
import type { Page } from "./db";

function changedFields(b: Page, m: Page): Partial<Page> {
  const out: Record<string, unknown> = {};
  const keys = new Set([...Object.keys(b), ...Object.keys(m)]) as Set<keyof Page>;
  for (const k of keys) if (b[k] !== m[k]) out[k] = m[k];
  return out as Partial<Page>;
}

export function rebasePages(base: Page[], mine: Page[], latest: Page[]): Page[] {
  if (base === latest) return mine;
  const baseById = new Map(base.map((p) => [p.id, p]));
  const latestById = new Map(latest.map((p) => [p.id, p]));
  const out: Page[] = [];
  for (const m of mine) {
    const b = baseById.get(m.id); const l = latestById.get(m.id);
    if (!b) { out.push(m); continue; } // trang màn hình vừa thêm (nhân bản, chèn)
    if (!l) continue; // nơi khác đã xoá trang này
    if (b === m) { out.push(l); continue; }
    if (l === b) { out.push(m); continue; }
    const diff = changedFields(b, m);
    const merged = { ...l, ...diff };
    for (const k of Object.keys(diff) as (keyof Page)[]) if (diff[k] === undefined) delete merged[k];
    out.push(merged);
  }
  const seen = new Set(out.map((p) => p.id));
  for (const l of latest) if (!baseById.has(l.id) && !seen.has(l.id)) out.push(l);
  return out;
}
