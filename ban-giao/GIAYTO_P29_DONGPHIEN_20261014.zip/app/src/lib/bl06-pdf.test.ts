import { describe, expect, it } from "vitest";
import { mergePdfs, parsePages, splitPdf, textLayerOps, type OcrLine } from "./files";
import { friendlyError } from "./errors";

// BL-06 (RS-22/26/29)
describe("BL-06 RS-29 parsePages kẹp dải trang", () => {
  it("dải khổng lồ không lặp tới hàng tỉ lần: kẹp về [1, max] (chạy tức thì)", () => {
    const t = performance.now();
    expect(parsePages("1-999999999", 3)).toEqual([1, 2, 3]);
    expect(parsePages("999999999-1", 3)).toEqual([3, 2, 1]);
    expect(performance.now() - t).toBeLessThan(200);
  });
  it("giữ hành vi cũ cho dải bình thường; dải hoàn toàn ngoài phạm vi → rỗng", () => {
    expect(parsePages("1-2, 4", 5)).toEqual([1, 2, 4]);
    expect(parsePages("7-9", 5)).toEqual([]);
  });
});

describe("BL-06 RS-22 lớp chữ theo ảnh đã thu nhỏ + cắt lề", () => {
  const L: OcrLine[] = [{ text: "Xin chào", bbox: { x0: 400, y0: 600, x1: 1400, y1: 700 } }];
  it("ảnh nén còn 1/2 (scale 0.5) và cắt lề trái/trên 100 px: toạ độ chữ = ((gốc × scale) − lề) × r", () => {
    const [op] = textLayerOps(L, 10, 20, 0.1, { ox: 100, oy: 100, scale: 0.5 });
    // x: 10 + (400×0.5 − 100)×0.1 = 20 ; chiều cao dòng 100×0.5×0.1 = 5 mm
    expect(op!.x).toBeCloseTo(20, 5);
    expect(op!.y).toBeCloseTo(20 + (700 * 0.5 - 100) * 0.1 - 5 * 0.2, 5);
  });
  it("không truyền ánh xạ → như cũ (tương thích)", () => {
    const [a] = textLayerOps(L, 10, 20, 0.1); const [b] = textLayerOps(L, 10, 20, 0.1, { ox: 0, oy: 0, scale: 1 });
    expect(a).toEqual(b);
  });
  it("dòng nằm hẳn trong phần lề đã cắt bỏ → bỏ (không đặt chữ ra ngoài ảnh)", () => {
    const out = textLayerOps([{ text: "lề", bbox: { x0: 0, y0: 0, x1: 150, y1: 150 } }], 0, 0, 0.1, { ox: 100, oy: 100, scale: 0.5, w: 500, h: 700 });
    expect(out).toEqual([]);
  });
});

describe("BL-06 RS-26 PDF có mã hoá", () => {
  const encryptedPdf = async () => {
    const { jsPDF } = await import("jspdf");
    const pdf = new jsPDF({ encryption: { userPassword: "abc", ownerPassword: "abc#", userPermissions: ["print"] } });
    pdf.text("bi mat", 10, 10); const buf = pdf.output("arraybuffer");
    return { arrayBuffer: async () => buf } as unknown as Blob; // jsdom: Blob chưa có arrayBuffer()
  };
  it("gộp/tách PDF mã hoá → báo rõ bằng tiếng Việt (không tạo tệp hỏng im lặng)", async () => {
    const f = await encryptedPdf();
    await expect(mergePdfs([f])).rejects.toThrow(/mật khẩu|mã hoá/);
    await expect(splitPdf(f)).rejects.toThrow(/mật khẩu|mã hoá/);
  });
});

describe("BL-06/BL-02 thông điệp lỗi riêng không bị nuốt thành 'Đã có lỗi xảy ra'", () => {
  it("EncryptedPdf và IdbWriteError có tiêu đề + hướng dẫn riêng", () => {
    expect(friendlyError(Object.assign(new Error("x"), { name: "EncryptedPdf" })).title).toMatch(/mật khẩu hoặc được mã hoá/);
    expect(friendlyError(Object.assign(new Error("x"), { name: "IdbWriteError" })).hint).toMatch(/Dữ liệu cũ vẫn giữ nguyên/);
  });
});
