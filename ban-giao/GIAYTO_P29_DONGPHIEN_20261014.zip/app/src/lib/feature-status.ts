// FX-01: tình trạng từng tính năng — người dùng biết trước cái gì dùng được, thay vì bấm rồi mới gặp lỗi.
import { useSyncExternalStore } from "react";

export type FeatureState = "ok" | "warn" | "off";
export type FeatureRow = { id: string; label: string; state: FeatureState; detail: string };
export type FeatureEnv = {
  online: boolean;
  cloud: boolean; // máy chủ đám mây (đăng nhập/đồng bộ) đã cấu hình cho bản này
  signedIn: boolean;
  drive: boolean; // Google Drive đã cấu hình
  ocrOffline: boolean; // gói nhận chữ + vỏ app đã tải sẵn
  camera: boolean;
  share: boolean; // có bảng chia sẻ của hệ điều hành
  storage: { usage: number; quota: number } | null;
  askLeft: number; askLimit: number; // lượt "Hỏi tài liệu" còn hôm nay
  aiErrorRate: number | null; // tỉ lệ lỗi AI gần đây trên máy (null = chưa dùng)
};

const mb = (n: number) => (n >= 1e9 ? `${(n / 1e9).toFixed(1)} GB` : `${Math.round(n / 1e6)} MB`);

/** Hàm thuần: môi trường → bảng tình trạng (thứ tự cố định). */
export function featureStatuses(e: FeatureEnv): FeatureRow[] {
  const rows: FeatureRow[] = [];
  rows.push(e.online
    ? { id: "mang", label: "Mạng", state: "ok", detail: "Đang có mạng" }
    : { id: "mang", label: "Mạng", state: "off", detail: "Đang mất mạng — quét, cắt, xuất PDF vẫn dùng được; AI, đồng bộ, đăng nhập chờ có mạng" });
  rows.push(e.camera
    ? { id: "quet", label: "Quét & xuất PDF", state: "ok", detail: "Chạy trên máy, không cần mạng" }
    : { id: "quet", label: "Quét & xuất PDF", state: "warn", detail: "Không thấy camera — dùng Nhập ảnh; xuất PDF vẫn dùng được" });
  rows.push(e.ocrOffline
    ? { id: "ocr", label: "Nhận chữ (OCR)", state: "ok", detail: "Đã tải sẵn — dùng được cả khi mất mạng" }
    : e.online
      ? { id: "ocr", label: "Nhận chữ (OCR)", state: "warn", detail: "Lần đầu cần mạng để tải gói nhận chữ — bấm “Tải sẵn” ở mục Xuất & nhận chữ" }
      : { id: "ocr", label: "Nhận chữ (OCR)", state: "off", detail: "Chưa tải gói nhận chữ và đang mất mạng" });
  const ask = `Hỏi tài liệu còn ${e.askLeft}/${e.askLimit} lượt hôm nay`;
  rows.push(!e.online
    ? { id: "ai", label: "AI (trích xuất, dịch, tóm tắt…)", state: "off", detail: "Cần mạng — việc AI sẽ chờ tới khi có mạng" }
    : e.aiErrorRate != null && e.aiErrorRate > 0.5
      ? { id: "ai", label: "AI (trích xuất, dịch, tóm tắt…)", state: "warn", detail: `Gần đây lỗi nhiều (${Math.round(e.aiErrorRate * 100)}%) — máy chủ AI có thể đang quá tải hoặc hết lượt · ${ask}` }
      : { id: "ai", label: "AI (trích xuất, dịch, tóm tắt…)", state: e.askLeft > 0 ? "ok" : "warn", detail: `Tối đa 60 lượt/giờ · ${ask}` });
  rows.push(!e.cloud
    ? { id: "dongbo", label: "Đăng nhập & đồng bộ", state: "off", detail: "Bản này chưa cấu hình máy chủ đám mây — tài liệu chỉ lưu trên máy" }
    : !e.signedIn
      ? { id: "dongbo", label: "Đăng nhập & đồng bộ", state: "warn", detail: "Chưa đăng nhập (không bắt buộc) — đăng nhập để đồng bộ và chia sẻ liên kết" }
      : { id: "dongbo", label: "Đăng nhập & đồng bộ", state: e.online ? "ok" : "warn", detail: e.online ? "Đã đăng nhập" : "Đã đăng nhập — đồng bộ chờ có mạng" });
  rows.push(e.drive
    ? { id: "drive", label: "Google Drive", state: e.online ? "ok" : "warn", detail: e.online ? "Đã cấu hình" : "Cần mạng" }
    : { id: "drive", label: "Google Drive", state: "off", detail: "Chưa cấu hình cho ứng dụng — nút Lưu vào Drive được ẩn" });
  rows.push(e.share
    ? { id: "chiase", label: "Chia sẻ sang ứng dụng khác", state: "ok", detail: "Có bảng chia sẻ của máy" }
    : { id: "chiase", label: "Chia sẻ sang ứng dụng khác", state: "warn", detail: "Trình duyệt không có bảng chia sẻ — tệp sẽ được lưu về máy" });
  if (!e.storage || !e.storage.quota) rows.push({ id: "bonho", label: "Bộ nhớ máy", state: "warn", detail: "Trình duyệt không cho biết dung lượng" });
  else {
    const r = e.storage.usage / e.storage.quota;
    const d = `Đã dùng ${mb(e.storage.usage)} / ${mb(e.storage.quota)} (${Math.round(r * 100)}%)`;
    rows.push({ id: "bonho", label: "Bộ nhớ máy", state: r >= 0.9 ? "off" : r >= 0.75 ? "warn" : "ok", detail: r >= 0.75 ? `${d} — xoá bớt hoặc sao lưu ra tệp` : d });
  }
  return rows;
}

// Trạng thái mạng dùng chung (huy hiệu trên nút + trang tình trạng)
const onlineNow = () => typeof navigator === "undefined" || navigator.onLine !== false;
function subscribeOnline(cb: () => void) {
  window.addEventListener("online", cb); window.addEventListener("offline", cb);
  return () => { window.removeEventListener("online", cb); window.removeEventListener("offline", cb); };
}
export const useOnline = () => useSyncExternalStore(subscribeOnline, onlineNow, () => true);

/** Thu thập môi trường thật trên trình duyệt (phần không đồng bộ: dung lượng). */
export async function gatherFeatureEnv(base: Pick<FeatureEnv, "online" | "cloud" | "signedIn" | "drive" | "ocrOffline" | "askLeft" | "askLimit" | "aiErrorRate">): Promise<FeatureEnv> {
  let storage: FeatureEnv["storage"] = null;
  try { const s = await navigator.storage?.estimate?.(); if (s?.quota) storage = { usage: s.usage ?? 0, quota: s.quota }; } catch { /* không hỗ trợ: để null, hiện "không cho biết" */ }
  return {
    ...base,
    camera: !!navigator.mediaDevices?.getUserMedia,
    share: typeof navigator.share === "function",
    storage,
  };
}
