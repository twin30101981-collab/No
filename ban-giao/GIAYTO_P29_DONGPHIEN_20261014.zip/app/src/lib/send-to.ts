/** G4-21: send a document to other services (email, Zalo, system share). Pure helpers + thin browser glue. */
import { toast } from "sonner";
import { download } from "./files";
import { canShareThisFile, offerTapToShare, tryShare } from "./share";

export type SendTarget = "system" | "email" | "zalo";

/** mailto: link with subject/body; body trimmed so the URL stays under common client limits (~1800 chars). */
export function mailtoUrl(opts: { to?: string | undefined; subject: string; body?: string | undefined }) {
  const to = (opts.to ?? "").split(/[,;\s]+/).filter((e) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)).join(",");
  let body = opts.body ?? "";
  const base = `mailto:${encodeURIComponent(to).replace(/%2C/g, ",")}?subject=${encodeURIComponent(opts.subject)}`;
  const max = 1800 - base.length - 6;
  while (body && encodeURIComponent(body).length > max) body = body.slice(0, Math.floor(body.length * 0.9));
  if (body !== (opts.body ?? "")) body = body.trimEnd() + "…";
  return body ? `${base}&body=${encodeURIComponent(body)}` : base;
}

/** Zalo share page for a public link (Zalo has no web API for files; files go through the system share sheet). */
export function zaloShareUrl(link: string) {
  return `https://zalo.me/share?url=${encodeURIComponent(link)}`;
}
/** Zalo trên máy tính chạy ở web: kéo tệp đã tải vào khung chat (Zalo không có API gửi tệp từ web khác). */
export const ZALO_WEB_URL = "https://chat.zalo.me/";

/** Default message body for a document. */
export function sendMessage(name: string, pages: number, link?: string) {
  return [`Gửi bạn tài liệu "${name}" (${pages} trang).`, link ? `Xem tại: ${link}` : "Tệp PDF đính kèm.", "", "— Gửi từ Ghi Nhanh"].join("\n");
}

export function canShareFiles(file?: File) {
  if (typeof navigator === "undefined" || !navigator.canShare) return false;
  return navigator.canShare({ files: [file ?? new File([""], "a.pdf", { type: "application/pdf" })] });
}

/**
 * Send a file. With a share sheet (phones), files are attached directly — the user picks Mail, Zalo, Messenger…
 * Without it (desktop), the file is saved and the mail app opens so the user attaches it.
 */
export async function sendFile(target: SendTarget, blob: Blob, name: string, meta: { title: string; pages: number; to?: string | undefined; link?: string | undefined }): Promise<"shared" | "cancelled" | "fallback" | "pending"> {
  const file = new File([blob], name, { type: blob.type || "application/pdf" });
  const text = sendMessage(meta.title, meta.pages, meta.link);
  if (target === "zalo" && meta.link) { window.open(zaloShareUrl(meta.link), "_blank", "noopener"); return "shared"; }
  if (canShareThisFile(file)) {
    // TF-02: điện thoại LUÔN dùng bảng chia sẻ để đính kèm thật (trước đây có người nhận thì tải về rồi mở thư rỗng).
    // Bảng chia sẻ không điền sẵn người nhận → chép địa chỉ vào bộ nhớ tạm và nhắc dán.
    if (target === "email" && meta.to) {
      void navigator.clipboard?.writeText(meta.to).then(() => { toast.info(`Đã chép ${meta.to} — dán vào ô Người nhận`); }, () => { toast.info(`Người nhận: ${meta.to} — nhập vào ô Người nhận`); });
    }
    const r = await tryShare(file, { title: meta.title, text });
    if (r === "shared") return "shared";
    if (r === "cancelled") return "cancelled";
    // TF-01: hết quyền chia sẻ của lần chạm (dựng PDF lâu) → thẻ "Tệp đã sẵn sàng — Chia sẻ" để chạm lần 2, không im lặng
    if (r === "needs-tap") { offerTapToShare(file, { title: meta.title, text }, download); return "pending"; }
  }
  download(blob, name);
  if (target === "email") {
    window.location.href = mailtoUrl({ to: meta.to, subject: meta.title, body: sendMessage(meta.title, meta.pages, meta.link) + `\n\n(Đính kèm tệp ${name} vừa tải về.)` });
    toast.info("Đã tải PDF — đính kèm vào thư vừa mở");
  } else if (target === "zalo") {
    toast(`Đã tải “${name}”`, { description: "Mở Zalo trên máy tính rồi kéo tệp vừa tải vào khung chat.", duration: 20000,
      action: { label: "Mở Zalo", onClick: () => { window.open(ZALO_WEB_URL, "_blank", "noopener"); } },
      actionButtonStyle: { minHeight: 40, padding: "0 14px", fontSize: 14, fontWeight: 600 } });
  } else toast.info("Máy này không có bảng chia sẻ — đã tải PDF về");
  return "fallback";
}
