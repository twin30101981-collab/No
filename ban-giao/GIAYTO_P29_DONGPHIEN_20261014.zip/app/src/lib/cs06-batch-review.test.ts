import { describe, expect, it } from "vitest";
import { applyEditQueued, EDGE_WARNING, markChecked, reviewReason, reviewTargets } from "./batch-review";
import type { Page } from "./db";

const pg = (id: string, extra: Partial<Page> = {}): Page => ({ id, orig: "o", src: "s", edit: { rotation: 0, filter: "auto", brightness: 0, contrast: 0 }, ...extra });

describe("CS-06 xem lại theo lô", () => {
  it("chọn đúng trang cần xem: cảnh báo lúc chụp, xem-lai, điểm thấp (bỏ trang đã sửa tay)", () => {
    const pages = [pg("a"), pg("b", { warnings: [EDGE_WARNING] }), pg("c", { status: "xem-lai" }), pg("d"), pg("e", { manual: true })];
    expect(reviewTargets(pages, { d: { score: 30, note: "ảnh hơi mờ" }, e: { score: 10, note: "x" }, a: { score: 90, note: "ổn" } })).toEqual([1, 2, 3]);
    expect(reviewReason(pages[1]!)).toBe(EDGE_WARNING);
    expect(reviewReason(pages[3]!, { score: 30, note: "ảnh hơi mờ" })).toMatch(/30\/100/);
  });
  it("Giữ nguyên: bỏ cảnh báo, xem-lai → xong", () => {
    const r = markChecked(pg("c", { status: "xem-lai", warnings: ["w"] }));
    expect(r.warnings).toBeUndefined(); expect(r.status).toBe("xong");
  });
  it("Sửa khung: ghi edit + manual + 'dang' (dựng nền), bỏ cảnh báo — từ xong, xem-lai, loi, dang", () => {
    for (const status of ["xong", "xem-lai", "loi", "dang", undefined] as const) {
      const r = applyEditQueued(pg("x", { ...(status ? { status } : {}), warnings: [EDGE_WARNING], error: "e" }), { quad: [[0, 0], [1, 0], [1, 1], [0, 1]] });
      expect(r.status).toBe("dang"); expect(r.manual).toBe(true); expect(r.warnings).toBeUndefined();
      expect(r.edit.quad).toHaveLength(4); expect(r.edit.filter).toBe("auto");
    }
  });
});

describe("CS-07 applyEditToPages — áp bộ lọc cho nhiều trang, dựng nền", async () => {
  const { applyEditToPages } = await import("./batch-review");
  it("mọi trang (ids thiếu) hoặc chỉ trang chọn; giữ khung riêng của từng trang", () => {
    const q: [number, number][] = [[0, 0], [1, 0], [1, 1], [0, 1]];
    const pages = [pg("a", { status: "xong", edit: { rotation: 0, filter: "auto", brightness: 0, contrast: 0, quad: q } }), pg("b", { status: "xong" })];
    const all = applyEditToPages(pages, { filter: "magic" });
    expect(all.map((p) => [p.edit.filter, p.status])).toEqual([["magic", "dang"], ["magic", "dang"]]);
    expect(all[0]!.edit.quad).toBe(q);
    const one = applyEditToPages(pages, { filter: "mono" }, new Set(["b"]));
    expect(one[0]).toBe(pages[0]); expect(one[1]!.edit.filter).toBe("mono");
  });
});
