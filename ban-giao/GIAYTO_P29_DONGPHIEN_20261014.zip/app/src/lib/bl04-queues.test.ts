import { describe, expect, it, vi } from "vitest";
import { createAiQueue, isNetworkError } from "./ai-queue";
import { BgQueue, memoryJobStore } from "./bg-queue";

// BL-04 (RS-05/08/31)
const env = (online = true) => ({ online: () => online, onOnline: () => {} });

describe("BL-04 ai-queue: phân loại lỗi mạng", () => {
  it("TypeError do LỖI LẬP TRÌNH không phải lỗi mạng (trước: mọi TypeError = mất mạng → việc bị giữ mãi)", () => {
    expect(isNetworkError(new TypeError("Cannot read properties of undefined (reading 'x')"))).toBe(false);
    expect(isNetworkError(new TypeError("Failed to fetch"))).toBe(true);
    expect(isNetworkError(new TypeError("NetworkError when attempting to fetch resource."))).toBe(true);
    expect(isNetworkError(new TypeError("Load failed"))).toBe(true);
  });
  it("lỗi lập trình → báo ngay cho người gọi, không xếp hàng (t1b)", async () => {
    const q = createAiQueue(env(true));
    await expect(q.run("x", async () => { throw new TypeError("Cannot read properties of undefined"); })).rejects.toThrow(/Cannot read/);
    expect(q.jobs()).toHaveLength(0);
  });
  it("máy báo có mạng nhưng máy chủ không tới được mãi → sau vài lần thử thì báo lỗi, gỡ khỏi hàng (t2)", async () => {
    const q = createAiQueue(env(true)); let calls = 0;
    const p = q.run("x", async () => { calls++; throw new TypeError("Failed to fetch"); });
    // gắn kỳ vọng TRƯỚC vòng lặp: p bị từ chối giữa chừng, gắn muộn → vitest báo "Unhandled Rejection" và thoát mã 1
    const rejected = expect(p).rejects.toThrow(/mạng|máy chủ|Failed to fetch/);
    // mỗi lần flush (sự kiện mạng / gọi việc mới) thử lại một lần
    for (let i = 0; i < 6; i++) { await q.flush(); await new Promise((r) => setTimeout(r, 0)); }
    await rejected;
    expect(calls).toBeLessThanOrEqual(4);
  });
});

describe("BL-04 bg-queue: việc lỗi hết lượt không nằm lại mãi", () => {
  it("hết lượt thử → gỡ khỏi hàng + kho; báo cho người nghe onGiveUp", async () => {
    const store = memoryJobStore();
    const q = new BgQueue(store, { finish: async () => { throw new Error("hỏng"); } }, (f) => { void f(); });
    const gave: string[] = []; q.onGiveUp((j, e) => gave.push(`${j.pageId}:${String((e as Error).message)}`));
    await q.enqueue("p1", "finish", { orig: "o" });
    await q.flush();
    expect(q.size).toBe(0); expect(q.has("p1")).toBe(false);
    expect(await store.all()).toHaveLength(0);
    expect(gave).toEqual(["p1:hỏng"]);
  });
  it("việc thành công lần 2 vẫn xong bình thường (không bị gỡ sớm)", async () => {
    let n = 0; const fn = vi.fn(async () => { if (++n < 2) throw new Error("tạm"); });
    const q = new BgQueue(memoryJobStore(), { finish: fn }, (f) => { void f(); });
    await q.enqueue("p1", "finish", { orig: "o" }); await q.flush();
    expect(fn).toHaveBeenCalledTimes(2); expect(q.size).toBe(0);
  });
});
