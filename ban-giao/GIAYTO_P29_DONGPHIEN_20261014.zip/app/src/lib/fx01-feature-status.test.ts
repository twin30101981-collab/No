import { describe, expect, it } from "vitest";
import { featureStatuses, type FeatureEnv } from "./feature-status";
import { isVietnamese } from "./errors";

const base: FeatureEnv = { online: true, cloud: true, signedIn: true, drive: true, ocrOffline: true, camera: true, share: true, storage: { usage: 1e8, quota: 1e9 }, askLeft: 30, askLimit: 30, aiErrorRate: null };
type Id = "mang" | "quet" | "ocr" | "ai" | "dongbo" | "drive" | "chiase" | "bonho";
const st = (e: Partial<FeatureEnv>) => Object.fromEntries(featureStatuses({ ...base, ...e }).map((r) => [r.id, r.state])) as Record<Id, string>;

describe("FX-01 featureStatuses", () => {
  it("đủ điều kiện → mọi tính năng dùng được, thứ tự cố định, câu tiếng Việt", () => {
    const rows = featureStatuses(base);
    expect(rows.map((r) => r.id)).toEqual(["mang", "quet", "ocr", "ai", "dongbo", "drive", "chiase", "bonho"]);
    expect(rows.every((r) => r.state === "ok" && isVietnamese(r.detail))).toBe(true);
  });
  it("mất mạng: AI tắt, quét vẫn dùng được, OCR tuỳ đã tải sẵn", () => {
    expect(st({ online: false })).toMatchObject({ mang: "off", quet: "ok", ocr: "ok", ai: "off", dongbo: "warn", drive: "warn" });
    expect(st({ online: false, ocrOffline: false }).ocr).toBe("off");
    expect(st({ ocrOffline: false }).ocr).toBe("warn");
  });
  it("chưa cấu hình đám mây / Drive → 'Chưa dùng được' kèm lý do", () => {
    const r = featureStatuses({ ...base, cloud: false, drive: false });
    expect(r.find((x) => x.id === "dongbo")).toMatchObject({ state: "off", detail: expect.stringMatching(/chưa cấu hình/) });
    expect(r.find((x) => x.id === "drive")).toMatchObject({ state: "off", detail: expect.stringMatching(/ẩn/) });
    expect(st({ signedIn: false }).dongbo).toBe("warn");
  });
  it("AI: hết lượt hỏi tài liệu hoặc lỗi nhiều → lưu ý", () => {
    expect(st({ askLeft: 0 }).ai).toBe("warn");
    expect(st({ aiErrorRate: 0.8 }).ai).toBe("warn");
    expect(st({ aiErrorRate: 0.1 }).ai).toBe("ok");
  });
  it("bộ nhớ: ≥75% lưu ý, ≥90% chưa dùng được, không đo được → lưu ý", () => {
    expect(st({ storage: { usage: 8e8, quota: 1e9 } }).bonho).toBe("warn");
    expect(st({ storage: { usage: 9.5e8, quota: 1e9 } }).bonho).toBe("off");
    expect(st({ storage: null }).bonho).toBe("warn");
    expect(st({ camera: false, share: false })).toMatchObject({ quet: "warn", chiase: "warn" });
  });
});
