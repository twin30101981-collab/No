// BL-05b: dấu "đã xoá hẳn trên máy" (id → thời điểm) để lần đồng bộ sau xoá bản trên mây và KHÔNG kéo lại về.
// Trước đây xoá hẳn chỉ xoá trên máy → lần đồng bộ sau thấy tài liệu "chỉ có trên mây" và tải về lại (hồi sinh), liên kết chia sẻ vẫn mở.
// Dấu bị bỏ qua khi máy lại có tài liệu cùng id (vd. khôi phục từ tệp sao lưu).
const KEY = "gn-sync-tomb";
const MAX = 2000;
export function readTombstones(): Record<string, number> {
  try { const v = JSON.parse(localStorage.getItem(KEY) ?? "{}") as unknown; return v && typeof v === "object" ? (v as Record<string, number>) : {}; } catch { return {}; }
}
function write(t: Record<string, number>) {
  const keep = Object.entries(t).sort((a, b) => b[1] - a[1]).slice(0, MAX);
  try { localStorage.setItem(KEY, JSON.stringify(Object.fromEntries(keep))); } catch { /* bộ nhớ trình duyệt đầy: lần đồng bộ sau có thể kéo lại tài liệu — không chặn việc xoá */ }
}
export function addTombstones(ids: string[], now = Date.now()) {
  if (!ids.length) return; const t = readTombstones(); for (const id of ids) t[id] = now; write(t);
}
export function clearTombstones(ids: string[]) {
  if (!ids.length) return; const t = readTombstones(); for (const id of ids) delete t[id]; write(t);
}
