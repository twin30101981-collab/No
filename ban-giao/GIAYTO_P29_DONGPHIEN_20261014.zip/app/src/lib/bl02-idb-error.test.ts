import { describe, expect, it } from "vitest";
import { idbError } from "./db";

// BL-02: lỗi ghi IndexedDB phải ra thông điệp tiếng Việt rõ ràng, giữ lỗi gốc; bộ nhớ đầy có thông điệp riêng.
describe("BL-02 idbError", () => {
  it("QuotaExceededError → báo bộ nhớ đầy, giữ tên + lỗi gốc", () => {
    const raw = new DOMException("quota", "QuotaExceededError"); const e = idbError(raw);
    expect(e.name).toBe("QuotaExceededError"); expect(e.message).toMatch(/Bộ nhớ trên máy đã đầy/); expect(e.cause).toBe(raw);
  });
  it("lỗi khác / null → 'Chưa lưu được…', nói rõ dữ liệu cũ vẫn giữ", () => {
    expect(idbError(new DOMException("x", "AbortError")).message).toMatch(/Chưa lưu được.*AbortError.*dữ liệu cũ vẫn giữ nguyên/);
    expect(idbError(null).message).toMatch(/^Chưa lưu được vào bộ nhớ máy — /);
  });
});
