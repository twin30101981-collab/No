import { createHash } from "node:crypto";
import { describe, expect, it } from "vitest";
import { EDGE_CLEAN_STEPS } from "./pixels";
import { finishLanes } from "./machine-lanes";

/**
 * CS-17e: làm sạch mép tối ưu (dải mép, tối cục bộ tính lười, hoãn tô, loang mở vòng) phải cho ảnh ra GIỐNG HỆT từng byte
 * mã P26. Băm vàng lấy từ mã P26 trên ảnh tổng hợp kích hoạt mọi bước (vạch đứt xiên, chấm mép, khung nhạt, vạch liền xiên,
 * mảng xám, dấu góc, nêm góc, dải nền tối) — bổ sung cho cs17a-trung-byte (ảnh nhỏ).
 */
// prettier-ignore
// Ảnh thử tổng hợp kích hoạt từng bước làm sạch mép (vạch đứt xiên, chấm mép, khung nhạt, vạch liền xiên, mảng xám, góc).
function makeImg(kind: number, W = 1240, H = 1754): Uint8ClampedArray {
  const d = new Uint8ClampedArray(W * H * 4); let seed = 101 + kind * 7919;
  const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
  const v = new Float32Array(W * H);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) v[y * W + x] = 224 - (10 * y) / H + rnd() * 5;
  const dot = (x: number, y: number, val: number, r = 1) => { for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) { const X = Math.round(x + dx), Y = Math.round(y + dy); if (X >= 0 && Y >= 0 && X < W && Y < H) v[Y * W + X] = Math.min(v[Y * W + X], val); } };
  // chữ giữa trang
  for (let y = 300; y < H - 300; y++) if (y % 34 < 9) for (let x = 260; x < W - 260; x++) if ((x >> 2) % 6 !== 0 && rnd() > 0.3) v[y * W + x] = 40 + rnd() * 30;
  const a = (kind % 3) * 0.35 + 1.05; // góc vạch xiên (rad)
  // vạch đứt xiên ở dải mép trái (edgeStrokeClean)
  for (let t = 0; t < 520; t++) { if (t % 34 > 20) continue; const x = 70 + (kind * 13) + t * Math.cos(a) * 0.35, y = 400 + t * Math.sin(a); dot(x, y, 90 + kind * 10, 1); }
  // vạch đứt dọc sát mép phải (edgeDashClean)
  for (let y = 300; y < 1400; y++) if (y % 40 < 22) { dot(W - 30 - kind, y, 110, 1); }
  // chấm mép (edgeSpeckClean)
  for (let k = 0; k < 30; k++) dot(5 + rnd() * 15, 100 + rnd() * (H - 200), 50, 1 + (k % 2));
  // khung nhạt ngang ở dải trên (edgeFrameClean 1)
  for (let x = 150; x < W - 150; x++) if (rnd() > 0.2) { v[(120 + kind) * W + x] = 212 - kind * 3; }
  // vạch liền xiên dài (edgeFrameClean 2) ở dải dưới-phải
  for (let t = 0; t < 140; t++) dot(W - 160 + t * Math.cos(a + 0.3) * 0.5, H - 230 + t * Math.sin(a + 0.3) * 0.9, 120, kind % 2);
  // mảng xám (greyBlockLift) + dấu tick góc (edgeCornerClean) + khối đen góc (cornerShadowLift)
  for (let y = 900; y < 1200; y++) for (let x = 40; x < 240; x++) v[y * W + x] -= 30 + kind * 8;
  for (let t = 0; t < 60; t++) dot(W - 120 + t, 60 + t * 0.4, 70, 1);
  for (let y = H - 90; y < H - 60; y++) for (let x = 50; x < 75; x++) v[y * W + x] = 20;
  for (let y = 0; y < 25 + kind * 10; y++) for (let x = 0; x < 40 - y; x++) v[y * W + x] = 30; // nêm góc tối
  for (let y = 0; y < H; y++) for (let x = W - 6 - kind; x < W; x++) v[y * W + x] = 70; // dải nền tối mép phải
  for (let i = 0; i < W * H; i++) { const q = Math.round(v[i]); d[i * 4] = q; d[i * 4 + 1] = q - (kind & 1); d[i * 4 + 2] = q - 3; d[i * 4 + 3] = 255; }
  return d;
}

// prettier-ignore
const VANG: string[][] = [["a8440ce0b2ad4544", "a8440ce0b2ad4544", "e953ffb21f436987", "9638416b7dc895b9", "24fe43ba46337a3f", "24fe43ba46337a3f", "29e4dcab2274d862", "5775ed62daf8c5a2", "5775ed62daf8c5a2", "c201e34fc9946a40", "15346f01b9bdff0b", "092c36c33730dd53"], ["06e5131c9708c88e", "06e5131c9708c88e", "2650c0f817200a43", "2356b6b8b741d938", "5bfa98603b6e70f3", "5bfa98603b6e70f3", "7fc14ac47cab04ea", "7fc14ac47cab04ea", "7fc14ac47cab04ea", "dc11bbe5318850eb", "096925c8f8bd24ac", "d9e9259f339cdb16"], ["9007409f20235f9f", "9007409f20235f9f", "a65588c303c196fa", "45ee5df677911717", "f42ab62030d36895", "f42ab62030d36895", "e7c0b668af5e0f96", "e7c0b668af5e0f96", "e7c0b668af5e0f96", "f4080b83395d0ccf", "c0d4d7b1f3b6399f", "d596c16a881316ee"], ["f023c81cb04da966", "f023c81cb04da966", "5679ae62c8d742e9", "371e482cda324217", "31a51c29a40c537f", "31a51c29a40c537f", "3f3d2aa77008c7f0", "8d7e8ac7b12dc786", "8d7e8ac7b12dc786", "f16c542ba527e5b2", "4acfb79f1913421d", "4eb303dc91c17d9e"]];

describe("CS-17e trùng byte làm sạch mép", () => {
  it("từng bước trên 4 ảnh tổng hợp 1240×1754 khớp băm vàng mã P26", () => {
    for (let k = 0; k < 4; k++) {
      let a = makeImg(k, 1240, 1754);
      const got = EDGE_CLEAN_STEPS.map((f) => { a = f(a, 1240, 1754); return createHash("sha1").update(a).digest("hex").slice(0, 16); });
      expect(got).toEqual(VANG[k]);
    }
  }, 60000);
  it("ảnh vàng làm đổi ít nhất 7 bước mỗi ảnh (độ phủ)", () => {
    for (const r of VANG) expect(r.filter((h, i) => i > 0 && h !== r[i - 1]).length).toBeGreaterThanOrEqual(7);
  });
  it("finishLanes: máy ≥ 4 nhân, RAM > 4 GB dựng 3 làn; máy yếu giữ 1 làn", () => {
    expect(finishLanes(4, 8)).toBe(3); expect(finishLanes(16, 16)).toBe(3);
    expect(finishLanes(4, 4)).toBe(1); expect(finishLanes(2, 8)).toBe(1);
  });
});
