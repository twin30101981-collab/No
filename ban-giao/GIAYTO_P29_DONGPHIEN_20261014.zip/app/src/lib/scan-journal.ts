/**
 * S8: nhật ký phiên quét (session journal). Mỗi lần danh sách trang thay đổi,
 * ghi toàn bộ phiên xuống IndexedDB riêng ("ghi-nhanh-journal") để tải lại giữa chừng
 * không mất trang. Commit sang tài liệu dùng commitId cố định theo phiên → không trùng.
 */
import type { Doc, Page } from "./db";
import { packDoc, unpackDoc } from "./disk-pack";

export type PageState = "queued" | "running" | "done" | "error";
export type Journal = {
  id: string; mode: string; docId?: string | undefined;
  pages: Page[]; states: Record<string, PageState>;
  pending: number; committedDocId?: string | undefined; updatedAt: number;
};
export interface KV { get(k: string): Promise<Journal | undefined>; set(k: string, v: Journal): Promise<void>; del(k: string): Promise<void> }

const KEY = "current";

export function memoryKV(): KV {
  const m = new Map<string, Journal>();
  return { get: async (k) => (m.has(k) ? structuredClone(m.get(k)!) : undefined), set: async (k, v) => { m.set(k, structuredClone(v)); }, del: async (k) => { m.delete(k); } };
}

let dbp: Promise<IDBDatabase> | null = null;
function idb(): Promise<IDBDatabase> {
  if (!dbp) dbp = new Promise((res, rej) => {
    const r = indexedDB.open("ghi-nhanh-journal", 1);
    r.onupgradeneeded = () => { if (!r.result.objectStoreNames.contains("j")) r.result.createObjectStore("j"); };
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
  return dbp;
}
async function run<T>(mode: IDBTransactionMode, f: (s: IDBObjectStore) => IDBRequest): Promise<T> {
  const db = await idb();
  return new Promise((res, rej) => { const t = db.transaction("j", mode); const q = f(t.objectStore("j")); t.oncomplete = () => res(q.result as T); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error); });
}
/** CS-12: trang trong nhật ký ghi ảnh dạng Blob nhị phân như kho tài liệu (packDoc) — blob: chết sau khi tải lại, data: thì phải giải base64. */
export const idbKV: KV = {
  get: async (k) => { const j = await run<Journal | undefined>("readonly", (s) => s.get(k)); return j?.pages?.length ? { ...j, pages: (await unpackDoc({ pages: j.pages } as Doc)).pages } : j; },
  set: async (k, v) => { const disk = v.pages.length ? { ...v, pages: packDoc({ pages: v.pages } as Doc).pages } : v; await run("readwrite", (s) => s.put(disk, k)); },
  del: async (k) => { await run("readwrite", (s) => s.delete(k)); },
};

export function newJournal(mode: string, docId?: string): Journal {
  return { id: Math.random().toString(36).slice(2, 10) + Date.now().toString(36), mode, docId, pages: [], states: {}, pending: 0, updatedAt: Date.now() };
}

/** Ghi tuần tự (không ghi chồng lệnh cũ lên lệnh mới) — bản cuối luôn thắng. */
export class JournalWriter {
  private chain: Promise<void> = Promise.resolve();
  constructor(private kv: KV = idbKV) {}
  /** Bản ghi chờ ghi gần nhất. Mỗi bản mang CẢ ảnh mọi trang → 20 lần chụp xếp 20 bản ghi lớn (bình phương) gây nghẽn khi bấm Xong.
   *  CS-04: các lần save dồn lại chỉ ghi bản MỚI NHẤT (bản cuối vẫn luôn thắng). */
  private latest: Journal | null = null; private scheduled = false;
  save(j: Journal) {
    this.latest = { ...j, pages: [...j.pages], states: { ...j.states }, updatedAt: Date.now() };
    if (!this.scheduled) {
      this.scheduled = true;
      this.chain = this.chain.then(() => {
        this.scheduled = false; const snap = this.latest; this.latest = null;
        if (!snap) return;
        return snap.pages.length || snap.pending ? this.kv.set(KEY, snap) : this.kv.del(KEY);
      }).catch(() => {});
    }
    return this.chain;
  }
  flush() { return this.chain; }
  async load(): Promise<Journal | undefined> {
    const j = await this.kv.get(KEY).catch(() => undefined);
    return j && !j.committedDocId && j.pages.length ? j : undefined;
  }
  /** Commit nguyên tử: đánh dấu đã commit trước khi xoá; save(docId) cùng id → ghi đè, không trùng. */
  async commit(j: Journal, save: (commitId: string) => Promise<string>) {
    // CS-04: không chờ các lần ghi nhật ký cũ (mỗi lần mang CẢ ảnh các trang — hàng giây trên máy yếu). Lưu tài liệu trước;
    // dấu "đã commit" chỉ cần đứng sau mọi lần ghi cũ trong hàng đợi, và KHÔNG mang ảnh (load() bỏ qua mọi nhật ký đã commit).
    const docId = await save(j.id);
    this.latest = null; // bản ghi chờ (mang ảnh) không còn cần: tài liệu đã lưu
    const marker: Journal = { ...j, pages: [], states: {}, pending: 0, committedDocId: docId, updatedAt: Date.now() };
    this.chain = this.chain.then(() => this.kv.set(KEY, marker)).then(() => this.kv.del(KEY)).catch(() => {});
    return docId; // không chờ hàng đợi: người dùng thấy tài liệu ngay; dọn nhật ký chạy nền (flush() nếu cần chờ)
  }
  clear() { this.chain = this.chain.then(() => this.kv.del(KEY)).catch(() => {}); return this.chain; }
}

export function stateCounts(j: Pick<Journal, "pages" | "states" | "pending">) {
  const c: Record<PageState, number> = { queued: j.pending, running: 0, done: 0, error: 0 };
  for (const p of j.pages) c[j.states[p.id] ?? "done"]++;
  return c;
}
