// CS-04b: phần TÍNH của các phép đo chất lượng trang (độ nghiêng, độ nét) trên ảnh xám đã vẽ sẵn — thuần, dùng chung luồng chính
// và Worker (pool.worker "grade"); mã chuyển nguyên từ image.ts (estimateSkew/sharpness/otsu), không đổi phép tính.
import type { Quad } from "./db";

/** Cỡ ảnh xám của estimateSkew: cạnh dài ≤ 600. */
export function skewSize(cw: number, ch: number) {
  const s = Math.min(1, 600 / Math.max(cw, ch)); return { w: Math.max(8, Math.round(cw * s)), h: Math.max(8, Math.round(ch * s)) };
}
/** Cỡ ảnh xám của sharpness: cạnh dài 480. */
export function sharpSize(sw: number, sh: number) {
  const s = 480 / Math.max(sw, sh); return { w: Math.max(8, Math.round(sw * s)), h: Math.max(8, Math.round(sh * s)) };
}
export function otsu(g: Uint8ClampedArray | number[]) {
  const hist = new Array(256).fill(0); for (const v of g) hist[v | 0]++;
  const total = g.length; let sum = 0; for (let i = 0; i < 256; i++) sum += i * hist[i];
  let sumB = 0, wB = 0, best = 0, t = 127;
  for (let i = 0; i < 256; i++) {
    wB += hist[i]; if (!wB) continue; const wF = total - wB; if (!wF) break;
    sumB += i * hist[i]; const mB = sumB / wB, mF = (sum - sumB) / wF; const between = wB * wF * (mB - mF) ** 2;
    if (between > best) { best = between; t = i; }
  }
  return t;
}

/** Độ nghiêng chữ nhỏ (±5°) theo độ nét hình chiếu hàng — thân estimateSkew sau bước xám. */
export function skewFromGray(g: Uint8ClampedArray, w: number, h: number) {
  const t = otsu(g);
  const ink: number[] = []; const mx = Math.round(w * 0.05), my = Math.round(h * 0.05);
  for (let y = my; y < h - my; y++) for (let x = mx; x < w - mx; x++) if (g[y * w + x] < t - 10) ink.push(x, y);
  if (ink.length < 400 || ink.length / 2 > w * h * 0.35) return 0;
  const score = (deg: number) => {
    const a = (deg * Math.PI) / 180, tn = Math.tan(a); const rows = new Float64Array(h * 2);
    for (let i = 0; i < ink.length; i += 2) { const r = Math.round(ink[i + 1] - (ink[i] - w / 2) * tn) + h / 2; if (r >= 0 && r < rows.length) rows[r]++; }
    let v = 0; for (let i = 1; i < rows.length; i++) v += (rows[i] - rows[i - 1]) ** 2; return v;
  };
  let best = 0, bs = score(0);
  for (let d = -5; d <= 5; d += 0.5) { const v = score(d); if (v > bs) { bs = v; best = d; } }
  const c0 = best; for (let d = c0 - 0.4; d <= c0 + 0.4; d += 0.1) { const v = score(d); if (v > bs) { bs = v; best = d; } }
  return Math.abs(best) < 0.25 || bs < score(0) * 1.05 ? 0 : best;
}

/** Phương sai Laplace (độ nét) — thân sharpness sau bước xám. */
export function lapVarGray(g: Uint8ClampedArray, w: number, h: number, quad?: Quad | null) {
  let x0 = 1, y0 = 1, x1 = w - 1, y1 = h - 1;
  if (quad) { const xs = quad.map((p) => p[0] * w), ys = quad.map((p) => p[1] * h);
    x0 = Math.max(1, Math.round(Math.min(...xs) + w * 0.03)); x1 = Math.min(w - 1, Math.round(Math.max(...xs) - w * 0.03));
    y0 = Math.max(1, Math.round(Math.min(...ys) + h * 0.03)); y1 = Math.min(h - 1, Math.round(Math.max(...ys) - h * 0.03)); }
  let sum = 0, sq = 0, n = 0;
  for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
    const i = y * w + x; const l = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w];
    sum += l; sq += l * l; n++; }
  return n ? sq / n - (sum / n) ** 2 : 0;
}
