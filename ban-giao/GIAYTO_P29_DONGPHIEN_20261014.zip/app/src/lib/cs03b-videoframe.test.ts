// CS-03b: nhịp ngắm qua VideoFrame — luồng chính không chép khung; mọi tình huống không chắc chắn đều rơi về đường cũ (null).
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

type Msg = { id: number; kind: string; w?: number; h?: number; robust?: boolean; ring?: boolean; detect?: boolean };
let posted: { m: Msg; t: unknown[] }[] = [];
let reply: (m: Msg) => Record<string, unknown> | null = () => null;
let throwOnPost = false;
class FakeWorker {
  onmessage: ((e: { data: unknown }) => void) | null = null; onerror: (() => void) | null = null;
  postMessage(m: Msg, t: unknown[] = []) {
    if (throwOnPost) throw new DOMException("không chuyển được", "DataCloneError");
    posted.push({ m, t }); const r = reply(m); if (r) queueMicrotask(() => this.onmessage?.({ data: { id: m.id, ...r } }));
  }
}
class FakeFrame { closed = false; constructor(public displayWidth: number, public displayHeight: number) {} close() { this.closed = true; } }
let made: FakeFrame[] = []; let frameSize: [number, number] | null = null;
function FakeVideoFrame(this: unknown, v: { videoWidth: number; videoHeight: number }) { const f = new FakeFrame(...(frameSize ?? [v.videoWidth, v.videoHeight])); made.push(f); return f; }

async function load() { vi.resetModules(); return import("./detect-worker"); }
const video = { videoWidth: 1920, videoHeight: 1080 };

beforeEach(() => {
  posted = []; made = []; frameSize = null; throwOnPost = false;
  reply = (m) => (m.kind === "frame" ? { det: null, sharp: 12, glare: 0, px: new Uint8ClampedArray(96 * 128 * 4), bmp: null } : null);
  vi.stubGlobal("Worker", FakeWorker); vi.stubGlobal("OffscreenCanvas", class {}); vi.stubGlobal("createImageBitmap", () => Promise.resolve({}));
  vi.stubGlobal("VideoFrame", FakeVideoFrame);
});
afterEach(() => vi.unstubAllGlobals());

describe("CS-03b detectVideoFrameAsync", () => {
  it("gửi VideoFrame sang Worker bằng chuyển quyền, cùng cỡ bản dò/robust như detectFrameAsync; trả khung nhỏ", async () => {
    const { detectVideoFrameAsync } = await load();
    const r = await detectVideoFrameAsync(video, 320, 96, 128, true);
    expect(r).not.toBeNull(); expect(r!.sharp).toBe(12); expect(r!.px.length).toBe(96 * 128 * 4); expect(r!.fromWorker).toBe(true);
    const { m, t } = posted[0];
    expect(m.kind).toBe("frame"); expect([m.w, m.h]).toEqual([320, 180]); expect(m.robust).toBe(false);
    expect(m.ring).toBe(true); expect(m.detect).toBe(true); expect(t).toEqual([made[0]]); // VideoFrame nằm trong danh sách chuyển quyền
    await detectVideoFrameAsync(video, 520, 96, 128, false, false);
    expect(posted[1].m.robust).toBe(true); expect(posted[1].m.ring).toBe(false); expect(posted[1].m.detect).toBe(false);
  });

  it("không có VideoFrame → null (dùng đường cũ), không gửi gì", async () => {
    vi.stubGlobal("VideoFrame", undefined);
    const { detectVideoFrameAsync } = await load();
    expect(await detectVideoFrameAsync(video, 320, 96, 128, true)).toBeNull(); expect(posted.length).toBe(0);
  });

  it("khung camera lệch cỡ video (xoay/cắt) → đóng khung, null, tắt hẳn đường VideoFrame", async () => {
    frameSize = [1080, 1920];
    const { detectVideoFrameAsync } = await load();
    expect(await detectVideoFrameAsync(video, 320, 96, 128, true)).toBeNull();
    expect(made[0].closed).toBe(true); expect(posted.length).toBe(0);
    frameSize = null; expect(await detectVideoFrameAsync(video, 320, 96, 128, true)).toBeNull(); // đã tắt
  });

  it("Worker báo lỗi → null và tắt đường VideoFrame (nhịp sau đi đường cũ)", async () => {
    reply = (m) => ({ error: "x" + m.kind });
    const { detectVideoFrameAsync } = await load();
    expect(await detectVideoFrameAsync(video, 320, 96, 128, true)).toBeNull();
    expect(await detectVideoFrameAsync(video, 320, 96, 128, true)).toBeNull(); expect(posted.length).toBe(1);
  });

  it("postMessage không chuyển được VideoFrame → việc bị từ chối, Worker không kẹt bận", async () => {
    throwOnPost = true;
    const { detectVideoFrameAsync } = await load();
    expect(await detectVideoFrameAsync(video, 320, 96, 128, true)).toBeNull();
    const { sharedPoolInfo } = await import("./worker-pool");
    expect(sharedPoolInfo().busy).toBe(0); expect(sharedPoolInfo().queued).toBe(0);
  });

  it("scan.tsx: nhịp ngắm dùng VideoFrame trước, chỉ createImageBitmap(video) khi không có đường VideoFrame", async () => {
    const fs = await import("node:fs");
    const src = fs.readFileSync("src/routes/scan.tsx", "utf8");
    expect(src).toMatch(/detectVideoFrameAsync\(v, dSize, sc\.width, sc\.height/);
    expect(src).toMatch(/else if \(!vr && wantRing\) void createImageBitmap\(v\)/);
    expect(src).toMatch(/ringBmp\?\.close\(\)/); // khung vòng đệm không dùng phải được giải phóng
  });
});
