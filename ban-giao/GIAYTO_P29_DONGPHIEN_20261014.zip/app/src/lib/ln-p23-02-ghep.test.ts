// LN-P23-02: trang tạo từ trang có sẵn (Ghép tài liệu, Nhân bản trang) phải có id MỚI và được xếp việc dựng nếu còn "dang".
// Trước: Ghép giữ id nguồn → applyFinished/markFailed/OCR tìm tài liệu ĐẦU TIÊN có pageId → ghi nhầm, trang "dang" ở bên kia kẹt mãi.
import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { join } from "node:path";
const src = (p: string) => readFileSync(join(__dirname, "..", p), "utf8");

describe("LN-P23-02 kiểm tĩnh", () => {
  it("Ghép: trang ghép mang id mới + xếp việc dựng cho tài liệu ghép", () => {
    const s = src("routes/documents.tsx"); const m = s.slice(s.indexOf("async function merge"), s.indexOf("async function moveTo"));
    expect(m).toMatch(/d\.pages\.map\(\(p\) => \(\{ \.\.\.p, id: uid\(\) \}\)\)/);
    expect(m).not.toMatch(/flatMap\(\(d\) => d\.pages\)/);
    expect(m).toMatch(/healPending\(\[doc\]\)/);
  });
  it("Nhân bản trang: sau khi lưu xếp việc dựng (bản sao trang 'dang')", () => {
    const s = src("routes/doc.$id.tsx");
    expect((s.match(/duplicatePages?\([^\n]*void save\(\{ pages: r\.pages \}\)\.then\(\(d\) => d && healPending\(\[d\]\)\)/g) ?? []).length).toBe(2);
  });
});
