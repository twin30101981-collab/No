import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import type { Page } from "./db";
import { rebasePages } from "./doc-merge";

const E = { rotation: 0, filter: "auto" as const, brightness: 0, contrast: 0 };
const pg = (id: string, extra: Partial<Page> = {}): Page => ({ id, orig: "o-" + id, src: "s-" + id, edit: E, ...extra });

describe("BL-05a rebasePages — áp thay đổi của màn hình lên bản mới nhất", () => {
  it("màn hình sửa trang 1, việc nền vừa dựng xong trang 2 → giữ cả hai", () => {
    const base = [pg("a", { status: "dang" }), pg("b", { status: "dang" })];
    const mine = [{ ...base[0]!, edit: { ...E, filter: "mono" as const }, manual: true }, base[1]!];
    const latest = [{ ...base[0]! }, { ...base[1]!, src: "FULL-b", status: "xong" as const }];
    const r = rebasePages(base, mine, latest);
    expect(r[0]!.edit.filter).toBe("mono"); expect(r[0]!.manual).toBe(true);
    expect(r[1]!.src).toBe("FULL-b"); expect(r[1]!.status).toBe("xong");
  });
  it("cùng một trang: trường màn hình đổi đè lên, trường nơi khác đổi (chữ OCR) giữ", () => {
    const base = [pg("a")];
    const mine = [{ ...base[0]!, edit: { ...E, rotation: 90 }, src: "rot" }];
    const latest = [{ ...base[0]!, text: "CHU-OCR" }];
    const r = rebasePages(base, mine, latest);
    expect(r[0]).toMatchObject({ src: "rot", text: "CHU-OCR" }); expect(r[0]!.edit.rotation).toBe(90);
  });
  it("đổi thứ tự/xoá theo màn hình; trang nơi khác vừa thêm được giữ (nối cuối); trang nơi khác xoá thì bỏ", () => {
    const base = [pg("a"), pg("b"), pg("c")];
    const mine = [base[2]!, base[0]!]; // xoá b, đảo c lên đầu
    const latest = [base[0]!, base[1]!, pg("d")].map((p) => ({ ...p })); // nơi khác: xoá c, thêm d
    expect(rebasePages(base, mine, latest).map((p) => p.id)).toEqual(["a", "d"]);
  });
  it("nhân bản (id mới) được giữ; trường bị màn hình bỏ (undefined) thì bỏ hẳn", () => {
    const base = [pg("a", { warnings: ["w"] })];
    const mine = [{ ...base[0]!, warnings: undefined } as unknown as Page, pg("a2")];
    const r = rebasePages(base, mine, [{ ...base[0]!, text: "t" }]);
    expect(r.map((p) => p.id)).toEqual(["a", "a2"]); expect("warnings" in r[0]!).toBe(false); expect(r[0]!.text).toBe("t");
  });
  it("không ai khác ghi (latest === base) → đúng bản của màn hình", () => {
    const base = [pg("a")]; const mine = [pg("x")];
    expect(rebasePages(base, mine, base)).toBe(mine);
  });
});

// Kiểm tĩnh: ghi NGUYÊN tài liệu (saveDoc/saveDocs) chỉ cho tài liệu mới tạo hoặc dữ liệu từ ngoài vào.
// Sửa tài liệu đã có phải qua mutateDoc/mutateDocs (đọc bản mới nhất trong lượt ghi) — chặn tái diễn lỗi ghi đè.
describe("BL-05a kiểm tĩnh: không ghi nguyên tài liệu đã có ngoài danh sách cho phép", () => {
  const root = join(__dirname, "..");
  const files: string[] = [];
  const walk = (d: string) => { for (const f of readdirSync(d)) { const p = join(d, f); if (statSync(p).isDirectory()) walk(p); else if (/\.tsx?$/.test(f) && !/\.test\.tsx?$/.test(f)) files.push(p); } };
  walk(root);
  // [tệp, mẫu lời gọi được phép, lý do]
  const ALLOW: [string, RegExp, string][] = [
    ["lib/db.ts", /.*/, "chính kho"],
    ["lib/cloud-sync.ts", /saveDocs\(got\)/, "kéo bản từ mây về (dữ liệu ngoài) — BL-05b"],
    ["routes/me.tsx", /saveDocs\(plan\.toSave\)/, "khôi phục sao lưu GỘP (dữ liệu ngoài)"],
  ];
  it("mọi saveDoc(...) ngoài db.ts đều tạo tài liệu MỚI (newDoc); saveDocs chỉ ở danh sách cho phép", () => {
    const bad: string[] = [];
    for (const f of files) {
      const rel = f.slice(root.length + 1).replace(/\\/g, "/");
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/\bsaveDocs?\(([^\n]{0,60})/g)) {
        const call = m[0];
        if (/^saveDoc\((\{ \.\.\.)?newDoc\(/.test(call)) continue;
        if (/function saveDocs?\(/.test(src.slice(Math.max(0, m.index! - 16), m.index! + call.length))) continue;
        if (ALLOW.some(([af, re]) => af === rel && re.test(call))) continue;
        bad.push(`${rel}: ${call}`);
      }
    }
    expect(bad).toEqual([]);
  });
});
