import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";

// LN-P23-01: ảnh giải mã lấy từ bộ đệm 2 chỗ có thể bị làn khác đẩy ra (xoá src) giữa các await. Mọi nơi dùng ảnh gốc đã giải mã
// phải đi qua withDecoded (giữ ảnh tới khi xong); gọi thẳng decodeOrig ở nơi khác là mở lại lỗi "Failed to construct ImageData".
describe("LN-P23-01 kiểm tĩnh: ảnh giải mã chỉ dùng qua withDecoded", () => {
  const src = readFileSync(join(__dirname, "image.ts"), "utf8");
  it("decodeOrig( chỉ xuất hiện trong định nghĩa và trong withDecoded", () => {
    const calls = [...src.matchAll(/decodeOrig\(/g)].map((m) => src.slice(src.lastIndexOf("\n", m.index!) + 1, src.indexOf("\n", m.index!)).trim());
    const bad = calls.filter((l) => !/^async function decodeOrig\(/.test(l) && !/decodeOrig\(orig\)/.test(l));
    expect(bad).toEqual([]);
    const inWith = src.slice(src.indexOf("async function withDecoded"), src.indexOf("/** Giải phóng toàn bộ ảnh giải mã"));
    expect(calls.length - 1).toBe([...inWith.matchAll(/decodeOrig\(/g)].length);
  });
  it("bộ đệm ảnh giải mã không xoá ảnh đang dùng (hoãn tới khi trả)", () => {
    expect(src).toMatch(/if \(inUse\.has\(v\.img\)\) freeLater\.set\(v\.img, free\); else free\(\);/);
  });
});
