// LN-P22-01: thông báo (sonner) cũ xếp chồng phía sau — thu gọn, trong suốt — vẫn bắt chạm; thông báo cao (có mô tả/nút) bị đẩy lên
// đè nút Đóng ở đầu màn Chụp → bấm Đóng không ra hộp hỏi (tái hiện V3: camera mép mờ, CPU 6×). Chặn bằng CSS toàn app.
import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { join } from "node:path";

describe("LN-P22-01 thông báo ẩn phía sau không bắt chạm", () => {
  it("styles.css: toast đang trượt vào/ra và toast thu gọn phía sau (kể cả ::before) có pointer-events: none", () => {
    const css = readFileSync(join(__dirname, "..", "styles.css"), "utf8").replace(/\s+/g, " ");
    expect(css).toContain('[data-sonner-toast][data-mounted="false"], [data-sonner-toast][data-removed="true"], [data-sonner-toast][data-expanded="false"][data-front="false"], [data-sonner-toast][data-expanded="false"][data-front="false"]::before { pointer-events: none; }');
  });
  it("styles.css: thông báo đặt trên trượt vào/ra chỉ 12 px (không quét qua đầu màn)", () => {
    const css = readFileSync(join(__dirname, "..", "styles.css"), "utf8").replace(/\s+/g, " ");
    expect(css).toContain('[data-sonner-toaster] [data-sonner-toast][data-y-position="top"][data-mounted="false"], [data-sonner-toaster] [data-sonner-toast][data-y-position="top"][data-removed="true"][data-front="true"][data-swipe-out="false"] { --y: translateY(-12px); }');
  });
});
