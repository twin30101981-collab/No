import { describe, expect, it, vi } from "vitest";
vi.mock("./image", () => ({
  detectQuadInfo: vi.fn(async (src: string) => (src === "mo" ? { quad: null, sure: false } : { quad: [[0.1, 0.1], [0.9, 0.1], [0.9, 0.9], [0.1, 0.9]], sure: src !== "nghi" })),
  renderPageUrl: vi.fn(async (orig: string) => `xem-truoc:${orig}`),
  targetLong: () => 3000,
}));
vi.mock("./settings", () => ({ getSettings: () => ({ quality: "high", defaultFilter: "auto" }) }));
import { EDGE_WARNING } from "./batch-review";
import type { Page } from "./db";
import { needsPipeline, processImported } from "./import-pipeline";

const pg = (id: string, extra: Partial<Page> = {}): Page => ({ id, orig: id, src: id, edit: { rotation: 0, filter: "original", brightness: 0, contrast: 0 }, status: "xong", ...extra });

describe("CS-09 processImported — ảnh Thêm đi chung dây chuyền", () => {
  it("chỉ ảnh CHỤP chưa có khung; ảnh phẳng/PDF giữ nguyên", () => {
    expect(needsPipeline(pg("a", { importKind: "photo" }))).toBe(true);
    expect(needsPipeline(pg("b", { importKind: "screenshot" }))).toBe(false);
    expect(needsPipeline(pg("c"))).toBe(false);
  });
  it("dò khung + bộ lọc mặc định + xem trước + 'dang' (dựng nền); máy không chắc → cảnh báo Kiểm mép; báo tiến độ", async () => {
    const prog: string[] = [];
    const out = await processImported([pg("ok", { importKind: "photo" }), pg("nghi", { importKind: "photo" }), pg("mo", { importKind: "photo" }), pg("pdf")], (d, t) => prog.push(`${d}/${t}`));
    expect(out.map((p) => p.id)).toEqual(["ok", "nghi", "mo", "pdf"]);
    expect(out[0]).toMatchObject({ src: "xem-truoc:ok", status: "dang", edit: { filter: "auto" } });
    expect(out[0]!.edit.quad).toHaveLength(4); expect(out[0]!.warnings).toBeUndefined();
    expect(out[1]!.warnings).toEqual([EDGE_WARNING]);
    expect(out[2]!.edit.quad).toBeUndefined(); expect(out[2]!.warnings).toEqual([EDGE_WARNING]);
    expect(out[3]).toEqual(pg("pdf"));
    expect(prog[0]).toBe("0/3"); expect(prog[prog.length - 1]).toBe("3/3");
  });
});
