// CS-09: đo chất lượng trang + hậu xử lý sau khi thêm trang (công thức tự chọn bộ lọc, đặt tên, OCR) — trước nằm riêng trong màn Chụp,
// nên ảnh "Thêm" từ máy/PDF không bao giờ được chạy. Nay mọi nguồn dùng chung.
import type { Doc } from "./db";
import { glare, grayscale, loadImg, yieldTask } from "./image";
import { lapVarGray, sharpSize, skewFromGray, skewSize } from "./grade-core";
import { runInPool } from "./worker-pool";
import { gradePage, type PageGrade, type PageMetrics } from "./page-grade";

/** CS-05 (G-05): số đo chất lượng lưu theo ẢNH GỐC (GradeBadge nhận pg.orig) nhưng trước đây tra theo p.src (ảnh đã dựng)
 *  → trúng 0/10, và chỉ ô đang hiện mới được tính (2/10). Nay tra theo ảnh gốc, tính bù cho mọi trang MỚI — ở nền, sau khi đã điều hướng. */
export async function postCaptureWithMetrics(saved: Doc, before: Set<string>, isNew: boolean, opts: { heal?: boolean } = {}) {
  const m = new Map<string, PageMetrics>();
  // Không tranh luồng chính với màn tài liệu vừa mở: chờ lúc rảnh trước mỗi trang CẦN TÍNH (tối đa 3 s/lần)
  const idle = () => new Promise<void>((r) => ("requestIdleCallback" in window ? requestIdleCallback(() => r(), { timeout: 3000 }) : setTimeout(r, 200)));
  const fresh = saved.pages.filter((p) => !before.has(p.id));
  try {
    // CS-09b: Thêm/Nhập (heal) đã chấm điểm trong làn → không chờ 1,5 s khi đủ số đo (việc dựng bản đầy đủ đang chờ công thức).
    // Màn Chụp giữ nguyên: chờ 1,5 s để không tranh luồng chính với màn tài liệu vừa mở (CS-04).
    if (!opts.heal || fresh.some((p) => !metricsCache.has(p.orig || p.src))) await new Promise((r) => setTimeout(r, 1500));
    for (const p of fresh) {
      const k = p.orig || p.src;
      if (!metricsCache.has(k)) { await idle(); await gradeOf(k).catch(() => null); }
      const x = metricsCache.get(k); if (x) m.set(p.id, x);
    }
    const { runPostCapture } = await import("./post-capture");
    await runPostCapture(saved, before, isNew, m, opts);
  } catch (e) {
    // không để trang "dang" mồ côi: hậu xử lý hỏng giữa chừng vẫn xếp việc dựng bản đầy đủ
    if (opts.heal) await import("./pipeline/runner").then((r) => r.healPending([saved])).catch(() => {});
    throw e;
  }
}

export const gradeCache = new Map<string, PageGrade>();
export const metricsCache = new Map<string, PageMetrics>(); // P8.4
export async function gradeOf(src: string) {
  const hit = gradeCache.get(src); if (hit) return hit;
  const img = await loadImg(src); const W = img.naturalWidth, H = img.naturalHeight;
  const s = Math.min(1, 600 / Math.max(W, H)); const c = document.createElement("canvas");
  c.width = Math.round(W * s); c.height = Math.round(H * s); const g = c.getContext("2d")!; g.drawImage(img, 0, 0, c.width, c.height);
  const d = g.getImageData(0, 0, c.width, c.height).data; let sum = 0, sq = 0; const n = d.length / 4;
  for (let i = 0; i < d.length; i += 4) { const l = 0.299 * d[i]! + 0.587 * d[i + 1]! + 0.114 * d[i + 2]!; sum += l; sq += l * l; }
  // CS-17d: mỗi phép đo (vẽ thu nhỏ ảnh gốc) là một tác vụ riêng — không gộp thành long task khi đang dựng trang nền
  // CS-04b: luồng chính chỉ VẼ ảnh xám (cùng phép vẽ estimateSkew/sharpness → số đo giống hệt); phần tính nặng (~2 s/20 trang ở
  // CPU 6×, chặn nút Xong) chạy trong Worker. Không có Worker → tính tại chỗ như cũ.
  const mean = sum / n; await yieldTask();
  const k1 = skewSize(c.width, c.height); let g1: Uint8ClampedArray | null = null; try { g1 = grayscale(c, k1.w, k1.h); } catch { /* như estimateSkew lỗi → 0 */ }
  await yieldTask(); const k2 = sharpSize(W, H); const g2 = grayscale(img, k2.w, k2.h);
  await yieldTask(); const gl = glare(img, W, H);
  const job = g1 ? runInPool<{ out: [number, number] }>("grade", { g1, w1: k1.w, h1: k1.h, g2, w2: k2.w, h2: k2.h }, [g1.buffer, g2.buffer]) : null;
  const viaPool = job ? await job.then((r) => r.out, () => null) : null;
  let skew = 0, blur: number;
  if (viaPool) [skew, blur] = viaPool;
  else { // Worker lỗi sau khi đã chuyển quyền → vẽ lại
    try { if (g1) skew = skewFromGray(g1.byteLength ? g1 : grayscale(c, k1.w, k1.h), k1.w, k1.h); } catch { /* */ }
    blur = lapVarGray(g2.byteLength ? g2 : grayscale(img, k2.w, k2.h), k2.w, k2.h);
  }
  const m = { blur, glare: gl, skew, brightness: mean, contrast: Math.sqrt(Math.max(0, sq / n - mean * mean)) }; const r = gradePage(m); metricsCache.set(src, m);
  c.width = 0; gradeCache.set(src, r); return r;
}
