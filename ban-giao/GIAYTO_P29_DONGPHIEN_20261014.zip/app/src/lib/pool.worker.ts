/// <reference lib="webworker" />
/**
 * R2.1: Worker hợp nhất cho bể chung — một Worker xử lý được cả 4 loại việc:
 * - "pixels": các op điểm ảnh (runJob từ pixels.ts), chuyển quyền bộ đệm hai chiều.
 * - "detect": dò khung giấy + độ nét + lóa trên bản mẫu RGBA nhỏ.
 * - "normalize": giải mã Blob → thu nhỏ → JPEG (createImageBitmap + OffscreenCanvas).
 * - "preview": vẽ ImageBitmap thu nhỏ → JPEG cho ảnh xem trước.
 * - "grade" (CS-04b): tính độ nghiêng + độ nét trên 2 ảnh xám đã vẽ sẵn ở luồng chính (chấm điểm trang).
 * - "frame" (CS-03b): một nhịp ngắm từ VideoFrame — lấy mẫu dò + khung nhỏ + ảnh vòng đệm đều ở đây, luồng chính không chép khung.
 * Lỗi "pixels" trả lại chính bộ đệm vào để luồng chính chạy dự phòng.
 */
import { runJob, type PixelJob } from "./pixels";
import { gpuWarpMesh, gpuWarpStats } from "./warp-mesh";
import type { Curves } from "./dewarp";
import { detectFromRgba, sharpnessRgba, glareRgba } from "./detect";
import { lapVarGray, skewFromGray } from "./grade-core";
import { fitBox, thumbBox, type QuadPts } from "./page-pipeline-shared";
import { bwPng, pageBox, rgbaToLum } from "./page-compress";
import { bytesToDataUrl } from "./content-crop";
import { cleanEdgesPx, finishPx, flattenLightPx, rotatePx, straightWarpPx, type FilterOpts, type Img, type RenderEnv } from "./render-core";
import type { Quad } from "./db";
import type { Paper } from "./detect";

type Msg =
  | { id: number; kind: "pixels"; job: PixelJob }
  | { id: number; kind: "detect"; d: Uint8ClampedArray; w: number; h: number; robust: boolean }
  | { id: number; kind: "grade"; g1: Uint8ClampedArray; w1: number; h1: number; g2: Uint8ClampedArray; w2: number; h2: number }
  | { id: number; kind: "frame"; vf: VideoFrame; w: number; h: number; robust: boolean; detect: boolean; tw: number; th: number; ring: boolean }
  | { id: number; kind: "normalize"; blob: Blob; max: number; q: number }
  | { id: number; kind: "preview"; bmp: ImageBitmap; w: number; h: number }
  // R2.2: dựng trang nền (cắt khung → thu nhỏ → nén → ảnh thu nhỏ), gộp từ page-pipeline.worker
  | { id: number; kind: "page"; bmp: ImageBitmap; max: number; q: number; thumbMax: number; quad?: QuadPts | null }
  // R2.2: nén trang PDF, gộp từ compress-page.worker
  | { id: number; kind: "compress"; src: string; maxSide: number; q: number; bw: boolean; isJpeg: boolean }
  // CS-17b: nắn lưới trên GPU của Worker (OffscreenCanvas) — nguồn là điểm ảnh RGBA đã đọc sẵn (bản sao, chuyển quyền)
  | { id: number; kind: "gpuwarp"; src: Uint8ClampedArray; W: number; H: number; q: [number, number][]; ow: number; oh: number; curves: Curves }
  // CS-17d: dựng trang trong Worker — geo (tải ảnh gốc + nắn + làm sạch mép + xoay), flat (chuẩn sáng), fin (bộ lọc + nắn dải 0 + JPEG)
  | ({ id: number; kind: "render" } & RenderMsg);
type RenderMsg =
  | { op: "geo"; src: string; quad: Quad | null; max: number; paper: Paper; flatten?: boolean; rotation: number }
  | { op: "flat"; d: Uint8ClampedArray; w: number; h: number; lend?: boolean }
  | { op: "fin"; d: Uint8ClampedArray; w: number; h: number; o: FilterOpts & { q: number }; lend?: boolean };

/** CS-17d: GPU trong Worker không nắn được → luồng chính làm lại theo thứ tự CS-17b (trùng byte với bản cũ). */
class Fallback extends Error {}
function workerEnv(t: [string, number][]): RenderEnv {
  return {
    canvas(w, h) {
      const c = new OffscreenCanvas(Math.max(1, Math.round(w)), Math.max(1, Math.round(h)));
      const ctx = c.getContext("2d", { willReadFrequently: true }); if (!ctx) throw new Fallback("no-canvas");
      return [c, ctx];
    },
    run: async (job) => runJob(job),
    async warp(sd, W, H, q, ow, oh, curves) {
      const od = gpuWarpMesh(sd, W, H, q, ow, oh, curves);
      if (!od) throw new Fallback(gpuWarpStats.reason ?? "gpu");
      return { od, engine: "gpu" };
    },
    jpeg: (c, q) => (c as OffscreenCanvas).convertToBlob({ type: "image/jpeg", quality: q }),
    bitmap: (b) => createImageBitmap(b),
    mark: (step, ms) => { t.push([step, ms]); },
  };
}
async function render(m: RenderMsg & { id: number }) {
  const t: [string, number][] = []; const env = workerEnv(t);
  // CS-17d: bộ đệm được cho mượn → sao chép ở đây (ngoài luồng chính) rồi trả lại bản gốc
  const back = m.op !== "geo" && m.lend ? m.d : null;
  const bt: Transferable[] = back ? [back.buffer] : [];
  const src = m.op !== "geo" ? (back ? back.slice() : m.d) : null;
  try {
    if (m.op === "geo") {
      if (!m.quad) throw new Fallback("no-quad"); // không khung: luồng chính (thu nhỏ ảnh <img>, trùng byte bản cũ)
      const bmp = await createImageBitmap(await (await fetch(m.src)).blob(), { imageOrientation: "from-image" });
      const W = bmp.width, H = bmp.height, perf: { engine: string; ms: number }[] = [];
      const [c, ctx] = env.canvas(W, H); ctx.drawImage(bmp, 0, 0); bmp.close();
      const sd = ctx.getImageData(0, 0, W, H).data; c.width = 0; const reads = 1;
      let g: Img = await straightWarpPx(env, sd, W, H, m.quad, m.max, m.paper, m.flatten, perf);
      g = await cleanEdgesPx(env, g);
      g = rotatePx(env, g, m.rotation);
      post({ id: m.id, out: g.d, w: g.w, h: g.h, perf, reads, t }, [g.d.buffer]);
    } else if (m.op === "flat") {
      const out = await flattenLightPx(env, src!, m.w, m.h);
      post({ id: m.id, out, back, t }, [out.buffer, ...bt]);
    } else {
      const log: string[] = [];
      const blob = await finishPx(env, { d: src!, w: m.w, h: m.h }, m.o, log);
      post({ id: m.id, blob, log, back, t }, bt);
    }
  } catch (err) {
    post({ id: m.id, fallback: err instanceof Fallback ? err.message : "error", error: String(err).slice(0, 200), back, t }, bt);
  }
}

const toDataUrl = (b: Blob) => new FileReaderSync().readAsDataURL(b);

const post = (m: unknown, t: Transferable[] = []) =>
  (self as unknown as Worker).postMessage(m, t);

self.onmessage = async (e: MessageEvent<Msg>) => {
  const m = e.data;
  try {
    if (m.kind === "pixels") {
      const out = runJob(m.job);
      post({ id: m.id, out }, [out.buffer]);
    } else if (m.kind === "render") {
      await render(m);
    } else if (m.kind === "gpuwarp") {
      const out = gpuWarpMesh(m.src, m.W, m.H, m.q, m.ow, m.oh, m.curves);
      if (out) post({ id: m.id, out }, [out.buffer]); else post({ id: m.id, out: null, reason: gpuWarpStats.reason });
    } else if (m.kind === "detect") {
      const det = detectFromRgba(m.d, m.w, m.h, m.robust);
      const quad = det?.quad ?? null;
      post({ id: m.id, det, sharp: sharpnessRgba(m.d, m.w, m.h, quad), glare: glareRgba(m.d, m.w, m.h, quad) });
    } else if (m.kind === "grade") {
      let skew = 0; try { skew = skewFromGray(m.g1, m.w1, m.h1); } catch { /* như gradeOf: lỗi đo nghiêng → 0 */ }
      post({ id: m.id, out: [skew, lapVarGray(m.g2, m.w2, m.h2)] });
    } else if (m.kind === "frame") {
      // CS-03b: vẽ VideoFrame (chuyển quyền, không sao chép) thành bản mẫu dò + khung nhỏ; ảnh vòng đệm cũng tạo ở đây; đóng khung camera sớm nhất có thể
      let d: Uint8ClampedArray, px: Uint8ClampedArray, bmp: ImageBitmap | null = null;
      try {
        const grab = (w: number, h: number) => { const x = new OffscreenCanvas(w, h).getContext("2d", { willReadFrequently: true })!; x.drawImage(m.vf, 0, 0, w, h); return x.getImageData(0, 0, w, h).data; };
        d = m.detect ? grab(m.w, m.h) : new Uint8ClampedArray(0); px = grab(m.tw, m.th);
        if (m.ring) bmp = await createImageBitmap(m.vf);
      } finally { m.vf.close(); }
      const det = m.detect ? detectFromRgba(d, m.w, m.h, m.robust) : null; const quad = det?.quad ?? null;
      post({ id: m.id, det, sharp: m.detect ? sharpnessRgba(d, m.w, m.h, quad) : 0, glare: m.detect ? glareRgba(d, m.w, m.h, quad) : 0, px, bmp }, bmp ? [px.buffer, bmp] : [px.buffer]);
    } else if (m.kind === "normalize") {
      const bmp = await createImageBitmap(m.blob);
      const s = Math.min(1, m.max / Math.max(bmp.width, bmp.height));
      const w = Math.max(1, Math.round(bmp.width * s)), h = Math.max(1, Math.round(bmp.height * s));
      const c = new OffscreenCanvas(w, h);
      const ctx = c.getContext("2d")!; ctx.imageSmoothingQuality = "high"; ctx.drawImage(bmp, 0, 0, w, h); bmp.close();
      const out = await c.convertToBlob({ type: "image/jpeg", quality: m.q });
      post({ id: m.id, blob: out });
    } else if (m.kind === "page") {
      // 1) Cắt theo khung giấy (bao hình chữ nhật của quad, kẹp trong ảnh)
      let src: ImageBitmap | OffscreenCanvas = m.bmp;
      if (m.quad) {
        const xs = m.quad.map((p) => p[0]), ys = m.quad.map((p) => p[1]);
        const x = Math.max(0, Math.floor(Math.min(...xs)));
        const y = Math.max(0, Math.floor(Math.min(...ys)));
        const w = Math.min(m.bmp.width - x, Math.ceil(Math.max(...xs) - x));
        const h = Math.min(m.bmp.height - y, Math.ceil(Math.max(...ys) - y));
        if (w > 8 && h > 8 && (w < m.bmp.width || h < m.bmp.height)) {
          const c = new OffscreenCanvas(w, h);
          c.getContext("2d")!.drawImage(m.bmp, x, y, w, h, 0, 0, w, h);
          src = c;
        }
      }
      const sw = src.width, sh = src.height;
      // 2) Ảnh chính: thu nhỏ về max, nén JPEG
      const main = fitBox(sw, sh, m.max);
      const mc = new OffscreenCanvas(main.w, main.h);
      const mg = mc.getContext("2d")!;
      mg.imageSmoothingQuality = "high";
      mg.fillStyle = "#fff"; mg.fillRect(0, 0, main.w, main.h);
      mg.drawImage(src, 0, 0, main.w, main.h);
      const mainBlob = await mc.convertToBlob({ type: "image/jpeg", quality: m.q });
      // 3) Ảnh thu nhỏ
      const tb = thumbBox(sw, sh, m.thumbMax);
      const tc = new OffscreenCanvas(tb.w, tb.h);
      tc.getContext("2d")!.drawImage(src, 0, 0, tb.w, tb.h);
      const thumbBlob = await tc.convertToBlob({ type: "image/jpeg", quality: 0.8 });
      m.bmp.close();
      post({ id: m.id, main: mainBlob, thumb: thumbBlob, w: main.w, h: main.h });
    } else if (m.kind === "compress") {
      const bmp = await createImageBitmap(await (await fetch(m.src)).blob());
      const s = Math.min(1, m.maxSide / Math.max(bmp.width, bmp.height));
      const W = Math.round(bmp.width * s), H = Math.round(bmp.height * s);
      const c = new OffscreenCanvas(W, H);
      const x = c.getContext("2d", { willReadFrequently: true })!;
      x.imageSmoothingEnabled = true; x.imageSmoothingQuality = "high"; x.fillStyle = "#fff"; x.fillRect(0, 0, W, H); x.drawImage(bmp, 0, 0, W, H);
      const big = Math.max(bmp.width, bmp.height) > m.maxSide; bmp.close();
      const lum = rgbaToLum(x.getImageData(0, 0, W, H).data, W, H);
      const box = pageBox(lum, W, H);
      const map = { ox: box.x, oy: box.y, scale: s }; // BL-06: để lớp chữ OCR khớp ảnh đã nén
      if (box.w === W && box.h === H && !(m.bw || !m.isJpeg || big)) return post({ id: m.id, page: { src: m.src, w: W, h: H, fmt: "JPEG", ...map } });
      if (m.bw) return post({ id: m.id, page: { src: bytesToDataUrl(bwPng(lum, W, H, box)), w: box.w, h: box.h, fmt: "PNG", ...map } });
      let out2: OffscreenCanvas = c;
      if (box.w !== W || box.h !== H) { out2 = new OffscreenCanvas(box.w, box.h); out2.getContext("2d")!.drawImage(c, box.x, box.y, box.w, box.h, 0, 0, box.w, box.h); }
      const blob = await out2.convertToBlob({ type: "image/jpeg", quality: m.q });
      post({ id: m.id, page: { src: toDataUrl(blob), w: box.w, h: box.h, fmt: "JPEG", ...map } });
    } else {
      const c = new OffscreenCanvas(m.w, m.h);
      const g = c.getContext("2d");
      if (!g) throw new Error("no-2d");
      g.drawImage(m.bmp, 0, 0, m.w, m.h);
      m.bmp.close();
      const blob = await c.convertToBlob({ type: "image/jpeg", quality: 0.8 });
      post({ id: m.id, blob });
    }
  } catch (err) {
    if (m.kind === "pixels") {
      const back = m.job.op === "warp" ? m.job.src : m.job.d;
      const live = back && back.buffer.byteLength > 0;
      post({ id: m.id, error: String(err), back: live ? back : undefined }, live ? [back.buffer] : []);
    } else {
      if (m.kind === "preview" || m.kind === "page") { try { m.bmp.close(); } catch { /* bỏ qua */ } }
      if (m.kind === "frame") { try { m.vf.close(); } catch { /* đã đóng */ } }
      post({ id: m.id, error: String(err) });
    }
  }
};
