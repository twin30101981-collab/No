import { describe, expect, it } from "vitest";
import { JournalWriter, memoryKV, newJournal, stateCounts } from "./scan-journal";
import type { Page } from "./db";

const pg = (id: string): Page => ({ id, orig: "o" + id, src: "s" + id, edit: { rotation: 0, filter: "auto", brightness: 0, contrast: 0 } });

describe("scan-journal (S8)", () => {
  it("khôi phục đủ trang sau 'tải lại' (writer mới, cùng kho)", async () => {
    const kv = memoryKV(); const w = new JournalWriter(kv); const j = newJournal("doc");
    for (let i = 0; i < 30; i++) { j.pages.push(pg(String(i))); void w.save(j); }
    await w.flush();
    const back = await new JournalWriter(kv).load();
    expect(back?.pages.map((p) => p.id)).toEqual(j.pages.map((p) => p.id));
  });
  it("bản ghi cuối thắng, xoá trang được lưu", async () => {
    const kv = memoryKV(); const w = new JournalWriter(kv); const j = newJournal("doc");
    j.pages = [pg("a"), pg("b"), pg("c")]; void w.save(j);
    j.pages = [pg("a"), pg("c")]; await w.save(j);
    expect((await w.load())?.pages.map((p) => p.id)).toEqual(["a", "c"]);
  });
  it("commit gọi lưu đúng 1 lần với id phiên, sau đó không còn gì để khôi phục", async () => {
    const kv = memoryKV(); const w = new JournalWriter(kv); const j = newJournal("doc"); j.pages = [pg("a")];
    await w.save(j); const ids: string[] = [];
    await w.commit(j, async (cid) => { ids.push(cid); return "doc1"; });
    expect(ids).toEqual([j.id]); expect(await w.load()).toBeUndefined();
  });
  it("CS-04: commit không chờ lần ghi nhật ký chậm; dọn xong sau flush, không còn gì để khôi phục", async () => {
    const mem = memoryKV(); let release!: () => void; const gate = new Promise<void>((r) => { release = r; });
    const slow = { ...mem, set: async (k: string, v: Parameters<typeof mem.set>[1]) => { if (v.pages.length) await gate; return mem.set(k, v); } };
    const w = new JournalWriter(slow); const j = newJournal("doc"); j.pages = [pg("a")];
    void w.save(j); let done = false;
    const c = w.commit(j, async () => "doc1").then(() => { done = true; });
    await c; expect(done).toBe(true); // trả về dù lần ghi ảnh còn treo
    release(); await w.flush();
    expect(await w.load()).toBeUndefined(); expect(await mem.get("current")).toBeUndefined();
  });
  it("CS-04: nhiều save dồn lại chỉ ghi bản mới nhất vào kho (không ghi 20 bản đầy ảnh)", async () => {
    const mem = memoryKV(); let writes = 0; const kv = { ...mem, set: async (k: string, v: Parameters<typeof mem.set>[1]) => { writes++; return mem.set(k, v); } };
    const w = new JournalWriter(kv); const j = newJournal("doc");
    for (let i = 0; i < 20; i++) { j.pages.push(pg(String(i))); void w.save(j); }
    await w.flush();
    expect(writes).toBeLessThanOrEqual(2); expect((await w.load())?.pages).toHaveLength(20);
  });
  it("phiên rỗng không lưu", async () => {
    const kv = memoryKV(); const w = new JournalWriter(kv); await w.save(newJournal("doc"));
    expect(await kv.get("current")).toBeUndefined();
  });
  it("đếm trạng thái", () => {
    expect(stateCounts({ pages: [pg("a"), pg("b")], states: { b: "error" }, pending: 2 })).toEqual({ queued: 2, running: 0, done: 1, error: 1 });
  });
});
