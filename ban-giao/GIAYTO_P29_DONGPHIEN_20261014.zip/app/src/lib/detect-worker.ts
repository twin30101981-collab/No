/**
 * V7: dò khung trong một Worker riêng (không xếp hàng sau việc dựng trang nặng).
 * Luồng chính chỉ lấy mẫu RGBA ~320 px rồi chuyển quyền bộ đệm. Không có Worker / lỗi → dò trên luồng chính.
 */
import { detectFromRgba, detectSize, sampleRgba, sharpnessRgba, glareRgba, type Detection } from "./detect";
import { poolCanvasSupported, runInPool } from "./worker-pool";

/** B09: kết quả một nhịp ngắm — khung giấy + độ nét + lóa, tính trong Worker. */
export type FrameResult = { det: Detection | null; sharp: number; glare: number; fromWorker: boolean };

/** CS-03b: thời gian luồng chính (ms) của lần lấy mẫu khung gần nhất trong detectFrameAsync. */
export let lastSampleMs = 0;
export const v7Stats = { worker: 0, main: 0, mainMs: 0, workerMs: 0, dropped: 0 };
if (typeof globalThis !== "undefined") (globalThis as { __v7?: typeof v7Stats }).__v7 = v7Stats;

type DetectReply = { det?: Detection | null; sharp?: number; glare?: number; error?: string };
/** R2.1: gọi bể chung ưu tiên cao nhất (nhịp ngắm trực tiếp); null khi không có Worker. */
function detectViaPool(d: Uint8ClampedArray, w: number, h: number, robust: boolean): Promise<DetectReply> | null {
  return runInPool<DetectReply>("detect", { d, w, h, robust }, [d.buffer]);
}

/** Dò khung bất đồng bộ; kết quả giống hệt detectPaper(src, sw, sh, size). */
export async function detectPaperAsync(src: CanvasImageSource, sw: number, sh: number, size = 360): Promise<Detection | null> {
  if (!sw || !sh) return null;
  const { w, h } = detectSize(sw, sh, size); const robust = size >= 500;
  const d = sampleRgba(src, w, h);
  const viaPool = detectViaPool(d, w, h, robust);
  if (viaPool) {
    const t0 = performance.now();
    const r = await viaPool.catch((): DetectReply => ({ error: "worker" }));
    if (!r.error) { v7Stats.worker++; v7Stats.workerMs += performance.now() - t0; return r.det ?? null; }
    return detectPaperAsync(src, sw, sh, size); // Worker vừa lỗi → lần này chạy luồng chính
  }
  const t0 = performance.now(); const det = detectFromRgba(d, w, h, robust);
  v7Stats.main++; v7Stats.mainMs += performance.now() - t0; return det;
}

/** B09: một nhịp ngắm trọn gói — dò khung + độ nét + lóa đều tính trong Worker trên cùng bản mẫu RGBA.
 *  Không có Worker / lỗi → tính trên luồng chính nhưng vẫn trên bản mẫu nhỏ (không vẽ lại canvas). */
export async function detectFrameAsync(src: CanvasImageSource, sw: number, sh: number, size = 320): Promise<FrameResult> {
  if (!sw || !sh) return { det: null, sharp: 0, glare: 0, fromWorker: false };
  const { w, h } = detectSize(sw, sh, size); const robust = size >= 500;
  const ts = performance.now(); const d = sampleRgba(src, w, h); lastSampleMs = performance.now() - ts; // CS-03b: phần luồng chính
  const viaPool = detectViaPool(d, w, h, robust);
  if (viaPool) {
    const t0 = performance.now();
    const r = await viaPool.catch((): DetectReply => ({ error: "worker" }));
    if (!r.error) {
      v7Stats.worker++; v7Stats.workerMs += performance.now() - t0;
      return { det: r.det ?? null, sharp: r.sharp ?? 0, glare: r.glare ?? 0, fromWorker: true };
    }
    return detectFrameAsync(src, sw, sh, size); // Worker vừa lỗi → chạy luồng chính
  }
  const t0 = performance.now();
  const det = detectFromRgba(d, w, h, robust);
  const sharp = sharpnessRgba(d, w, h, det?.quad ?? null);
  const gl = glareRgba(d, w, h, det?.quad ?? null);
  v7Stats.main++; v7Stats.mainMs += performance.now() - t0;
  return { det, sharp, glare: gl, fromWorker: false };
}

/** CS-03b: kết quả nhịp ngắm qua VideoFrame — thêm khung nhỏ RGBA (tw×th) và ảnh vòng đệm cỡ đầy đủ (nếu xin). */
export type VideoFrameResult = FrameResult & { px: Uint8ClampedArray; bmp: ImageBitmap | null };
type VideoLike = { videoWidth: number; videoHeight: number };
type VfCtor = new (src: VideoLike) => { displayWidth: number; displayHeight: number; close(): void };
let vfOff = false;
/** Cho kiểm thử: bật lại đường VideoFrame. */
export function resetVideoFramePath() { vfOff = false; }

/**
 * CS-03b: một nhịp ngắm gần như không tốn luồng chính. new VideoFrame(video) chỉ tham chiếu khung camera (không chép);
 * Worker vẽ nó thành bản mẫu dò (cùng detectSize/robust như detectFrameAsync), khung nhỏ tw×th và — khi `ring` —
 * ImageBitmap cỡ đầy đủ cho vòng đệm (trước đây createImageBitmap(video) + 2 lần drawImage(video) trên luồng chính,
 * ~250 ms/nhịp ở CPU 6×). Trả null khi trình duyệt không có VideoFrame/Worker, khung có xoay (cỡ lệch video) hoặc
 * Worker lỗi (tắt hẳn đường này) → gọi nơi dùng đường cũ.
 */
export async function detectVideoFrameAsync(v: VideoLike, size: number, tw: number, th: number, ring: boolean, detect = true): Promise<VideoFrameResult | null> {
  const VF = (globalThis as unknown as { VideoFrame?: VfCtor }).VideoFrame;
  if (vfOff || !VF || !poolCanvasSupported() || !v.videoWidth || !v.videoHeight) return null;
  const ts = performance.now();
  let vf: InstanceType<VfCtor>;
  try { vf = new VF(v); } catch { vfOff = true; return null; }
  if (vf.displayWidth !== v.videoWidth || vf.displayHeight !== v.videoHeight) { vf.close(); vfOff = true; return null; } // khung xoay/cắt: giữ đường cũ
  const { w, h } = detectSize(v.videoWidth, v.videoHeight, size);
  const job = runInPool<DetectReply & { px?: Uint8ClampedArray; bmp?: ImageBitmap | null }>("frame", { vf, w, h, robust: size >= 500, detect, tw, th, ring }, [vf as unknown as Transferable]);
  lastSampleMs = performance.now() - ts;
  if (!job) { vf.close(); vfOff = true; return null; }
  const r = await job.catch((): DetectReply => ({ error: "worker" }));
  if (r.error || !("px" in r) || !r.px) { vfOff = true; return null; }
  v7Stats.worker++;
  return { det: r.det ?? null, sharp: r.sharp ?? 0, glare: r.glare ?? 0, fromWorker: true, px: r.px, bmp: r.bmp ?? null };
}
