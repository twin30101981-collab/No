// CS-04b: phần tính của chấm điểm trang chuyển sang grade-core (dùng chung luồng chính/Worker) — kết quả phải giống HỆT mã cũ.
// Mã cũ (estimateSkew/sharpness sau bước xám, P27) chép nguyên làm mốc so.
import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { lapVarGray, otsu, sharpSize, skewFromGray, skewSize } from "./grade-core";
import { PRIORITY } from "./worker-pool";

function oldOtsu(g: Uint8ClampedArray) {
  const hist = new Array(256).fill(0); for (const v of g) hist[v | 0]++;
  const total = g.length; let sum = 0; for (let i = 0; i < 256; i++) sum += i * hist[i];
  let sumB = 0, wB = 0, best = 0, t = 127;
  for (let i = 0; i < 256; i++) { wB += hist[i]; if (!wB) continue; const wF = total - wB; if (!wF) break;
    sumB += i * hist[i]; const mB = sumB / wB, mF = (sum - sumB) / wF; const between = wB * wF * (mB - mF) ** 2; if (between > best) { best = between; t = i; } }
  return t;
}
function oldSkew(g: Uint8ClampedArray, w: number, h: number) {
  const t = oldOtsu(g); const ink: number[] = []; const mx = Math.round(w * 0.05), my = Math.round(h * 0.05);
  for (let y = my; y < h - my; y++) for (let x = mx; x < w - mx; x++) if (g[y * w + x] < t - 10) ink.push(x, y);
  if (ink.length < 400 || ink.length / 2 > w * h * 0.35) return 0;
  const score = (deg: number) => { const a = (deg * Math.PI) / 180, tn = Math.tan(a); const rows = new Float64Array(h * 2);
    for (let i = 0; i < ink.length; i += 2) { const r = Math.round(ink[i + 1] - (ink[i] - w / 2) * tn) + h / 2; if (r >= 0 && r < rows.length) rows[r]++; }
    let v = 0; for (let i = 1; i < rows.length; i++) v += (rows[i] - rows[i - 1]) ** 2; return v; };
  let best = 0, bs = score(0);
  for (let d = -5; d <= 5; d += 0.5) { const v = score(d); if (v > bs) { bs = v; best = d; } }
  const c0 = best; for (let d = c0 - 0.4; d <= c0 + 0.4; d += 0.1) { const v = score(d); if (v > bs) { bs = v; best = d; } }
  return Math.abs(best) < 0.25 || bs < score(0) * 1.05 ? 0 : best;
}
function oldLap(g: Uint8ClampedArray, w: number, h: number, quad?: [number, number][] | null) {
  let x0 = 1, y0 = 1, x1 = w - 1, y1 = h - 1;
  if (quad) { const xs = quad.map((p) => p[0] * w), ys = quad.map((p) => p[1] * h);
    x0 = Math.max(1, Math.round(Math.min(...xs) + w * 0.03)); x1 = Math.min(w - 1, Math.round(Math.max(...xs) - w * 0.03));
    y0 = Math.max(1, Math.round(Math.min(...ys) + h * 0.03)); y1 = Math.min(h - 1, Math.round(Math.max(...ys) - h * 0.03)); }
  let sum = 0, sq = 0, n = 0;
  for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) { const i = y * w + x; const l = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w]; sum += l; sq += l * l; n++; }
  return n ? sq / n - (sum / n) ** 2 : 0;
}
/** Trang chữ giả: dòng mực nghiêng `deg` độ trên nền sáng, có nhiễu (hạt cố định). */
function textPage(w: number, h: number, deg: number, seed: number) {
  let s = seed; const rnd = () => ((s = (s * 1103515245 + 12345) >>> 0) / 2 ** 32);
  const g = new Uint8ClampedArray(w * h); const tn = Math.tan((deg * Math.PI) / 180);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const yy = y + (x - w / 2) * tn; const line = Math.floor(yy / 14); const inLine = yy - line * 14 < 4 && x > w * 0.1 && x < w * 0.9 && (Math.floor(x / 9) + line) % 5 !== 0;
    g[y * w + x] = inLine ? 30 + rnd() * 20 : 235 + rnd() * 15;
  }
  return g;
}

describe("CS-04b grade-core = mã cũ", () => {
  it("độ nghiêng giống hệt trên trang chữ nghiêng −4..+4° và ảnh phẳng/nhiễu", () => {
    for (const [deg, seed] of [[-4, 1], [-1.3, 2], [0, 3], [0.6, 4], [2.4, 5], [4, 6]] as const) {
      const { w, h } = skewSize(1240, 1754); const g = textPage(w, h, deg, seed);
      const v = skewFromGray(g, w, h); expect(v).toBe(oldSkew(g, w, h));
      if (Math.abs(deg) >= 1) expect(Math.abs(v)).toBeGreaterThan(0.5); // thực sự đi nhánh đo nghiêng
    }
    const flat = new Uint8ClampedArray(300 * 400).fill(200); expect(skewFromGray(flat, 300, 400)).toBe(oldSkew(flat, 300, 400));
    expect(otsu(textPage(120, 160, 0, 9))).toBe(oldOtsu(textPage(120, 160, 0, 9)));
  });

  it("độ nét (phương sai Laplace) giống hệt, cả khi có khung giấy", () => {
    const { w, h } = sharpSize(1920, 2560); const g = textPage(w, h, 1.5, 7);
    expect(lapVarGray(g, w, h)).toBe(oldLap(g, w, h));
    const q: [number, number][] = [[0.1, 0.12], [0.88, 0.1], [0.9, 0.9], [0.12, 0.92]];
    expect(lapVarGray(g, w, h, q)).toBe(oldLap(g, w, h, q));
  });

  it("cỡ ảnh xám như mã cũ (600 / 480 cạnh dài)", () => {
    expect(skewSize(600, 450)).toEqual({ w: 600, h: 450 }); expect(skewSize(1200, 900)).toEqual({ w: 600, h: 450 });
    expect(sharpSize(1920, 1080)).toEqual({ w: 480, h: 270 }); expect(sharpSize(4, 4000)).toEqual({ w: 8, h: 480 });
  });

  it("gradeOf: luồng chính chỉ vẽ ảnh xám, phần tính gửi Worker 'grade' (ưu tiên dưới nhịp ngắm/xem trước)", () => {
    const src = readFileSync("src/lib/post-capture-metrics.ts", "utf8");
    expect(src).toMatch(/runInPool<\{ out: \[number, number\] \}>\("grade"/);
    expect(src).not.toMatch(/estimateSkew\(c\)/); expect(src).not.toMatch(/sharpness\(img, W, H\)/);
    expect(PRIORITY.grade).toBeGreaterThan(PRIORITY.preview); expect(PRIORITY.grade).toBeLessThan(PRIORITY.pixels);
    const w = readFileSync("src/lib/pool.worker.ts", "utf8"); expect(w).toMatch(/m\.kind === "grade"/);
  });
});
