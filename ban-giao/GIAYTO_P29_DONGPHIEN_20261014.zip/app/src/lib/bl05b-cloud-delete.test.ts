// BL-05b: xoá / xoá hẳn / khoá PIN phải đi lên mây; xoá thu hồi liên kết chia sẻ; tài liệu khoá không gửi bản rõ (QD-5).
import { beforeEach, describe, expect, it, vi } from "vitest";
import type { Doc } from "./db";

const { local } = vi.hoisted(() => ({ local: { docs: [] as Doc[] } }));
vi.mock("./auth", () => ({ cloudReady: () => true, NO_CLOUD: "chưa cấu hình mây" }));
vi.mock("@/integrations/supabase/client", async () => ({ supabase: (await import("../test/fake-supabase")).fake.client }));
vi.mock("./db", () => ({ getDocs: () => local.docs, saveDocs: vi.fn(async () => {}), loadDocs: vi.fn(async () => {}) }));
import { fake } from "../test/fake-supabase";
import { downloadAll, uploadAll } from "./cloud-sync";
import { addTombstones, readTombstones } from "./tombstones";

const edit = { rotation: 0, filter: "auto" as const, brightness: 0, contrast: 0 };
const doc = (id: string, extra: Partial<Doc> = {}): Doc => ({ id, name: "TL " + id, folder: "Chung", kind: "Tài liệu", createdAt: 1, updatedAt: 10,
  pages: [{ id: id + "-p1", orig: "data:image/jpeg;base64,AAAA", src: "data:image/jpeg;base64,BBBB", edit }], ...extra });
const remoteRow = (id: string) => fake.db.documents.find((r) => r.local_id === id);
const linksOf = (id: string) => fake.db.share_links.filter((l) => l.document_id === remoteRow(id)?.id);

beforeEach(async () => {
  fake.db.documents = []; fake.db.pages = []; fake.db.folders = []; fake.db.share_links = []; fake.files.clear(); localStorage.clear(); fake.log.length = 0;
  // trên mây có sẵn tài liệu "a" (đã đồng bộ, có 1 liên kết chia sẻ còn hiệu lực)
  local.docs = [doc("a")];
  await uploadAll(local.docs);
  fake.db.share_links.push({ id: "L1", document_id: remoteRow("a")!.id, token: "t", revoked_at: null });
});

describe("BL-05b đồng bộ xoá lên mây", () => {
  it("chuẩn bị: bản trên mây có trang + ảnh + liên kết", () => {
    expect(remoteRow("a")).toBeTruthy(); expect(fake.files.size).toBe(2); expect(linksOf("a")[0]!.revoked_at).toBeNull();
  });
  it("chuyển vào thùng rác → mây đánh dấu xoá + THU HỒI liên kết chia sẻ", async () => {
    local.docs = [doc("a", { deletedAt: 20, updatedAt: 20 })];
    const r = await uploadAll(local.docs);
    expect(r.failed).toEqual([]);
    expect(remoteRow("a")!.deleted_at).toBeTruthy();
    expect(linksOf("a")[0]!.revoked_at).toBeTruthy();
  });
  it("xoá hẳn trên máy → lần đồng bộ sau KHÔNG kéo về lại, rồi gỡ hẳn bản trên mây (hàng, trang, ảnh, liên kết)", async () => {
    local.docs = []; addTombstones(["a"]);
    const down = await downloadAll([]);
    expect(down.received).toBe(0);
    const up = await uploadAll([]);
    expect(up.failed).toEqual([]);
    expect(remoteRow("a")).toBeUndefined(); expect(fake.db.pages.length).toBe(0); expect(fake.files.size).toBe(0);
    expect(readTombstones()).toEqual({}); // đã gỡ xong → bỏ dấu
  });
  it("khôi phục lại từ sao lưu (máy lại có tài liệu cùng id) → dấu xoá bị bỏ qua, không gỡ bản trên mây", async () => {
    addTombstones(["a"]); local.docs = [doc("a")];
    await uploadAll(local.docs);
    expect(remoteRow("a")).toBeTruthy();
  });
  it("QD-5: tài liệu khoá PIN (đang mở) không gửi bản rõ; đã từng gửi → gỡ khỏi mây, thu hồi liên kết", async () => {
    local.docs = [doc("a", { locked: true, updatedAt: 30 }), doc("b", { locked: true, updatedAt: 30 })];
    const r = await uploadAll(local.docs);
    expect(r.failed).toEqual([]);
    expect(remoteRow("a")).toBeUndefined(); expect(remoteRow("b")).toBeUndefined();
    expect(fake.db.share_links.length).toBe(0);
  });
  it("QD-5: bản trên mây mới hơn không đè tài liệu đang khoá trên máy", async () => {
    remoteRow("a")!.client_updated_at = 999;
    const r = await downloadAll([doc("a", { locked: true })]);
    expect(r.received).toBe(0);
  });
});
