// CS-09b: (1) trang Thêm/Nhập chọn công thức bộ lọc TRƯỚC khi xếp việc dựng bản đầy đủ → mỗi trang dựng đúng một lần;
// (2) hàng đợi nền chạy được nhiều làn (máy ≥ 4 nhân, RAM > 4 GB: 2 việc dựng song song).
import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { BgQueue, memoryJobStore } from "@/lib/bg-queue";
import type { IdleScheduler } from "@/lib/deferred-finish";
import { finishLanes } from "@/lib/machine-lanes";

const payload = { orig: "data:image/jpeg;base64,x", targetLong: 3000 };
const now: IdleScheduler = (cb) => { setTimeout(cb, 0); };
const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));
const src = (p: string) => readFileSync(join(__dirname, "..", p), "utf8");

describe("CS-09b hàng đợi nền nhiều làn", () => {
  it("2 làn: hai việc chạy chồng nhau, không quá 2; flush chờ hết", async () => {
    let live = 0, peak = 0; const done: string[] = [];
    const q = new BgQueue(memoryJobStore(), { finish: async (j) => { live++; peak = Math.max(peak, live); await wait(20); live--; done.push(j.pageId); } }, now);
    q.setLanes(2);
    for (const id of ["a", "b", "c", "d", "e"]) await q.enqueue(id, "finish", payload);
    await q.flush();
    expect(peak).toBe(2);
    expect(done.sort()).toEqual(["a", "b", "c", "d", "e"]);
    expect(q.size).toBe(0);
  });

  it("mặc định 1 làn: tuần tự đúng thứ tự (hành vi cũ)", async () => {
    let live = 0, peak = 0; const done: string[] = [];
    const q = new BgQueue(memoryJobStore(), { finish: async (j) => { live++; peak = Math.max(peak, live); await wait(5); live--; done.push(j.pageId); } }, now);
    for (const id of ["a", "b", "c"]) await q.enqueue(id, "finish", payload);
    await q.flush();
    expect(peak).toBe(1); expect(done).toEqual(["a", "b", "c"]);
  });

  it("finishLanes: 3 làn (CS-17e) chỉ khi ≥ 4 nhân và RAM > 4 GB", () => {
    expect(finishLanes(8, 8)).toBe(3); expect(finishLanes(4, 8)).toBe(3);
    expect(finishLanes(2, 8)).toBe(1); expect(finishLanes(8, 4)).toBe(1); expect(finishLanes(3, 8)).toBe(1);
  });
});

describe("CS-09b chọn công thức trước khi xếp việc dựng (kiểm tĩnh)", () => {
  it("Thêm (doc.$id) và Nhập (importer) KHÔNG xếp việc dựng ngay sau processImported — để hậu xử lý (heal) xếp sau công thức", () => {
    const doc = src("routes/doc.$id.tsx"); const imp = src("lib/importer.ts");
    const ins = doc.slice(doc.indexOf("async function insertImages"), doc.indexOf("async function pasteImages"));
    expect(ins).toContain("processImported");
    expect(ins).not.toMatch(/healPending\(/);
    expect(ins).toMatch(/postCaptureWithMetrics\(.*\{ heal: true \}\)/);
    expect(imp).not.toMatch(/healPending\(/);
    expect(imp).toMatch(/postCaptureWithMetrics\(.*\{ heal: true \}\)/);
  });
  it("dây chuyền nhập chấm điểm trang trong làn (gradeOf) → công thức có số đo ngay", () => {
    expect(src("lib/import-pipeline.ts")).toMatch(/await gradeOf\(p\.orig\)/);
  });
  it("runPostCapture với heal: xếp việc SAU khi áp công thức (kể cả công thức lỗi)", () => {
    expect(src("lib/post-capture.ts")).toMatch(/if \(opts\.heal\) void recipes\.finally\(/);
  });
});
