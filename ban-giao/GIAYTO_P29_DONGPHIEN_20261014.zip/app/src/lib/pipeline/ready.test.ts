import { beforeEach, describe, expect, it, vi } from "vitest";
import type { Doc } from "../db";

// CS-04: lối xuất phải chờ trang còn "dang" hoàn thiện; không việc chờ thì không chặn, không báo.
const { st, toast } = vi.hoisted(() => ({
  st: { jobs: [] as { pageId: string; kind: string; state: string }[], docs: [] as Doc[], flushed: 0 },
  toast: { loading: vi.fn(() => "t1"), dismiss: vi.fn(), warning: vi.fn() },
}));
vi.mock("sonner", () => ({ toast }));
vi.mock("../db", () => ({ getDocs: () => st.docs }));
vi.mock("./runner", () => ({ healPending: vi.fn(async () => 0) }));
vi.mock("../bg-queue", () => ({ bgQueue: {
  list: () => st.jobs,
  flush: vi.fn(async () => { st.flushed++; st.jobs = []; st.docs = st.docs.map((d) => ({ ...d, pages: d.pages.map((p) => ({ ...p, src: "FULL", status: "xong" as const })) })); }),
} }));
import { pendingFinishCount, readyDocs } from "./ready";

const doc = (id: string, pageIds: string[]): Doc => ({ id, name: id, folder: "Chung", kind: "Tài liệu", createdAt: 1, updatedAt: 1,
  pages: pageIds.map((p) => ({ id: p, orig: "o", src: "NHAP", status: "dang" as const, edit: { rotation: 0, filter: "auto", brightness: 0, contrast: 0 } })) }) as Doc;

beforeEach(() => { st.jobs = []; st.docs = []; st.flushed = 0; toast.loading.mockClear(); toast.dismiss.mockClear(); toast.warning.mockClear(); });

describe("CS-04 readyDocs", () => {
  it("còn việc finish của trang thuộc tài liệu → báo, chờ hàng đợi, trả bản mới (ảnh đầy đủ)", async () => {
    const d = doc("d1", ["a", "b"]); st.docs = [d]; st.jobs = [{ pageId: "a", kind: "finish", state: "queued" }, { pageId: "b", kind: "finish", state: "running" }];
    expect(pendingFinishCount([d])).toBe(2);
    const [r] = await readyDocs([d]);
    expect(st.flushed).toBe(1); expect(toast.loading).toHaveBeenCalledOnce(); expect(toast.dismiss).toHaveBeenCalledWith("t1");
    expect(r.pages.map((p) => p.src)).toEqual(["FULL", "FULL"]);
  });
  it("không có việc chờ (hoặc chỉ việc của tài liệu khác / việc đã lỗi hết lượt) → không chặn, không báo", async () => {
    const d = doc("d1", ["a"]); st.docs = [d]; st.jobs = [{ pageId: "x", kind: "finish", state: "queued" }, { pageId: "a", kind: "finish", state: "error" }];
    const out = await readyDocs([d]);
    expect(out[0]).toBe(d); expect(st.flushed).toBe(0); expect(toast.loading).not.toHaveBeenCalled();
    expect(toast.warning).toHaveBeenCalledOnce(); // trang vẫn "dang" mà không chữa được → báo, không im lặng
  });
});
