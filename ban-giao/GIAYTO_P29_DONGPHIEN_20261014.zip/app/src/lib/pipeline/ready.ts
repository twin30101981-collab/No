// CS-04: "Xong" lưu tài liệu NGAY (trang chưa có bản đầy đủ mang status "dang"; bộ điều phối CS-02 ghi bản đầy đủ sau).
// Vì vậy mọi lối XUẤT phải chờ các trang của tài liệu hoàn thiện trước — không bao giờ xuất bản nháp ~1200 px.
import { toast } from "sonner";
import { bgQueue } from "../bg-queue";
import { getDocs, type Doc } from "../db";
import { healPending } from "./runner";

/** Số việc "finish" còn chờ/đang chạy của các trang thuộc `docs` (việc đã lỗi hết lượt không tính: không còn ai chạy nó). */
export function pendingFinishCount(docs: Pick<Doc, "pages">[]): number {
  const ids = new Set(docs.flatMap((d) => d.pages.map((p) => p.id)));
  return bgQueue.list().filter((j) => j.kind === "finish" && (j.state === "queued" || j.state === "running") && ids.has(j.pageId)).length;
}

/** Chờ các trang của `docs` hoàn thiện (có thông báo tiến độ), trả về bản mới nhất của từng tài liệu. Không có việc chờ → trả nguyên. */
export async function readyDocs<D extends Doc>(docs: D[]): Promise<D[]> {
  const latest = () => { const m = new Map(getDocs().map((d) => [d.id, d])); return docs.map((d) => (m.get(d.id) as D | undefined) ?? d); };
  let cur = latest(); let tid: string | number | undefined;
  try {
    // Tối đa 3 vòng: một lần ghi tài liệu khác có thể đè mất bản đầy đủ vừa ghi (BL-05) → trang lại "dang" → chữa và chờ tiếp.
    for (let round = 0; round < 3; round++) {
      await healPending(cur);
      const n = pendingFinishCount(cur);
      if (!n) break;
      tid ??= toast.loading(`Đang hoàn thiện ${n} trang trước khi xuất…`, { description: "Ảnh chất lượng đầy đủ đang được dựng." });
      await bgQueue.flush(); cur = latest();
    }
  } finally { if (tid !== undefined) toast.dismiss(tid); }
  const left = cur.reduce((n, d) => n + d.pages.filter((p) => p.status === "dang" || p.status === "loi").length, 0); // BL-04: cả trang "loi"
  if (left) toast.warning(`${left} trang chưa hoàn thiện được ảnh đầy đủ`, { description: "Bản xuất dùng ảnh xem trước cho các trang này — mở tài liệu để thử lại." }); // không im lặng
  return cur;
}
