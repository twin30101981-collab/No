import { createHash } from "node:crypto";
import { describe, expect, it } from "vitest";
import { docChain, EDGE_CLEAN_STEPS } from "./pixels";
import { lineSkewRefine, regionAngle, roundHalfRow } from "./line-skew";
import { sharpenAdaptive } from "./sharpen-adaptive";

/** CS-17a: tối ưu làm sạch mép/docChain phải cho ảnh ra GIỐNG HỆT từng byte mã trước tối ưu (băm vàng lấy từ mã P24). */
// CS-17a: ảnh thử tất định (dòng chữ nghiêng/cong, mép tối, vạch mép, mảng xám, dấu góc) cho kiểm trùng byte.
function makeImg(kind: number, W = 600, H = 840): Uint8ClampedArray {
  const d = new Uint8ClampedArray(W * H * 4); let seed = 11 + kind * 977;
  const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
  const tilt = [0.026, -0.018, 0.012][kind % 3], bend = [0.00004, 0, -0.00003][kind % 3];
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    let v = 222 - Math.round((14 * x) / W) + Math.round(rnd() * 6);
    const u = x - W / 2, top = y < H / 2, ly = y - (top ? -tilt : tilt) * u - bend * u * u;
    if (x > 50 && x < W - 50 && y > 50 && y < H - 50 && ly % 26 < 7 && (x >> 3) % 5 !== 0 && rnd() > 0.25) v = 35 + Math.round(rnd() * 30);
    if (kind === 0 && (x < 10 + ((y * 12) / H) || y < 8)) v = 55;
    if (kind === 1) {
      if (x >= 6 && x <= 7 && y > 40 && y < H - 40) v = 60;
      if (y >= H - 18 && y <= H - 17 && (x >> 4) % 2 === 0 && x > 30 && x < W - 30) v = 70;
      if (y >= 24 && y <= 25 && x > 60 && x < W - 60) v = 206;
      if (x > W - 120 && x < W - 20 && y > 300 && y < 420) v = Math.min(v, 185);
      if (x > W - 30 && x < W - 26 && y > 12 && y < 40) v = 50;
    }
    if (kind === 2 && x > W - 90 && y > H - 90) v = Math.min(v, 150 + ((x + y) % 40));
    const i = (y * W + x) * 4; d[i] = v; d[i + 1] = v - (kind === 2 ? 4 : 0); d[i + 2] = v - 3; d[i + 3] = 255;
  }
  return d;
}
const VANG: string[][] = [["6c90d0db23d4d015","6c90d0db23d4d015","fef37e8f638a236e","222190ee821dda11","222190ee821dda11","646e8630f4596a35","342cc6a6960b3a8a","342cc6a6960b3a8a","342cc6a6960b3a8a","342cc6a6960b3a8a","342cc6a6960b3a8a","342cc6a6960b3a8a","7d7ca1679a6b7c4f","36d9893cb6c6d09f"],["3a794125bbf3d7cf","3a794125bbf3d7cf","514ee8217bc99381","b842e576f48273db","b842e576f48273db","ce03b1bc96d39dea","cb941af01e6a681b","cb941af01e6a681b","cb941af01e6a681b","021cedfb98054c8f","021cedfb98054c8f","021cedfb98054c8f","109b6143b5bde7bb","86e28bc242616bce"],["1d30b5f53defc0ee","efc79bcde5953020","8eb7399da2c7d274","f4c6f80d21bd7126","f4c6f80d21bd7126","3394067583a180df","f76232b50a61d8cf","f76232b50a61d8cf","f76232b50a61d8cf","f76232b50a61d8cf","e6ab91801eaa1f3d","e6ab91801eaa1f3d","fccae908821611f8","d0b5e513e67c52fe"]];
const h = (a: Uint8ClampedArray) => createHash("sha1").update(a).digest("hex").slice(0, 16);

/** Bản tham chiếu = regionAngle mã P24 (quét cả vùng cho mỗi góc). */
function regionAngleRef(g: Uint8Array, W: number, x0: number, x1: number, y0: number, y1: number, maxDeg = 3, step = 0.25, thr = 140) {
  const H = y1 - y0, cx = (x0 + x1) / 2;
  let best = 0, bestScore = -1, ink = 0;
  const xs = Math.max(1, ((x1 - x0) / 200) | 0);
  for (let y = y0; y < y1; y += 2) for (let x = x0; x < x1; x += xs) if (g[y * W + x] < thr) ink++;
  for (let a = -maxDeg; a <= maxDeg + 1e-9; a += step) {
    const t = Math.tan((a * Math.PI) / 180);
    const prof = new Float64Array(H + 1);
    for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x += xs) {
      if (g[y * W + x] >= thr) continue;
      const r = Math.round(y - y0 - (x - cx) * t);
      if (r >= 0 && r <= H) prof[r]++;
    }
    let s = 0;
    for (let r = 1; r <= H; r++) { const d = prof[r] - prof[r - 1]; s += d * d; }
    if (s > bestScore) { bestScore = s; best = a; }
  }
  return { angle: best, ink };
}

/** Bản tham chiếu = sharpenAdaptive mã P24. */
function sharpenRef(d: Uint8ClampedArray, W: number, H: number, amount: number, threshold = 4) {
  const ci = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
  const n = W * H, L = new Float32Array(n), t = new Float32Array(n), B = new Float32Array(n);
  for (let i = 0; i < n; i++) L[i] = d[i * 4] * 0.3 + d[i * 4 + 1] * 0.59 + d[i * 4 + 2] * 0.11;
  const k = [1, 4, 6, 4, 1];
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { let s = 0; for (let j = -2; j <= 2; j++) s += k[j + 2] * L[y * W + ci(x + j, 0, W - 1)]; t[y * W + x] = s / 16; }
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { let s = 0; for (let j = -2; j <= 2; j++) s += k[j + 2] * t[ci(y + j, 0, H - 1) * W + x]; B[y * W + x] = s / 16; }
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = y * W + x, diff = L[i] - B[i];
    if (Math.abs(diff) <= threshold) continue;
    let lo = 255, hi = 0;
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const v = L[ci(y + dy, 0, H - 1) * W + ci(x + dx, 0, W - 1)]; if (v < lo) lo = v; if (v > hi) hi = v; }
    const g = amount / (1 + Math.abs(diff) / 40), target = ci(L[i] + g * diff, lo, hi), add = target - L[i];
    d[i * 4] = d[i * 4] + add; d[i * 4 + 1] = d[i * 4 + 1] + add; d[i * 4 + 2] = d[i * 4 + 2] + add;
  }
  return d;
}

describe("CS-17a làm sạch mép + docChain trùng byte mã cũ", () => {
  for (const k of [0, 1, 2]) it(`ảnh thử ${k}: 12 bước làm sạch + docChain thường/sắc`, () => {
    const W = 600, H = 840; let a = makeImg(k); const got: string[] = [];
    for (const f of EDGE_CLEAN_STEPS) { a = f(a, W, H); got.push(h(a)); }
    got.push(h(docChain(a.slice(), W, H, false)), h(docChain(a.slice(), W, H, true)));
    expect(got).toEqual(VANG[k]);
  });
  it("ảnh thử có nắn dòng thật (đi qua nhánh lấy mẫu dọc, không chỉ nhánh dòng đứng yên)", () => {
    expect(lineSkewRefine(makeImg(0), 600, 840, 2).passes).toBeGreaterThan(0);
  });
  it("regionAngle = bản tham chiếu (ngẫu nhiên, bước 0,25/0,125, cx lẻ nửa, mực dày/thưa)", () => {
    let seed = 5; const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
    for (let n = 0; n < 60; n++) {
      const W = 40 + ((rnd() * 900) | 0), H = 20 + ((rnd() * 200) | 0), g = new Uint8Array(W * H), p = rnd();
      for (let i = 0; i < g.length; i++) g[i] = rnd() < p ? (rnd() * 140) | 0 : 141 + ((rnd() * 114) | 0);
      for (let y = 0; y < H; y += 7 + (n % 5)) for (let x = 0; x < W; x++) if (rnd() < 0.8) g[Math.min(H - 1, y + ((x * (n % 3)) / 40 | 0)) * W + x] = 20;
      const x0 = (rnd() * W * 0.3) | 0, x1 = x0 + 1 + ((rnd() * (W - x0 - 1)) | 0), y0 = (rnd() * H * 0.3) | 0, y1 = y0 + ((rnd() * (H - y0)) | 0);
      const step = n % 2 ? 0.125 : 0.25;
      expect(regionAngle(g, W, x0, x1, y0, y1, 3, step)).toEqual(regionAngleRef(g, W, x0, x1, y0, y1, 3, step));
    }
  });
  it("sharpenAdaptive = bản tham chiếu, cả ảnh hẹp 1–8 px (nhánh kẹp mép)", () => {
    let seed = 9; const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
    for (const [W, H] of [[1, 1], [1, 6], [2, 3], [3, 3], [4, 7], [5, 2], [8, 8], [37, 29]]) {
      const d = new Uint8ClampedArray(W * H * 4); for (let i = 0; i < d.length; i++) d[i] = (rnd() * 256) | 0;
      for (const amt of [0.9, 1.4]) expect(Array.from(sharpenAdaptive(d.slice(), W, H, amt))).toEqual(Array.from(sharpenRef(d.slice(), W, H, amt)));
    }
  });
  it("roundHalfRow = gán v + 0,5 vào Uint8ClampedArray (làm tròn nửa về chẵn)", () => {
    const src = Uint8ClampedArray.from({ length: 256 }, (_, v) => v), a = new Uint8ClampedArray(256), b = new Uint8ClampedArray(256);
    roundHalfRow(src, a, 0, 256);
    for (let v = 0; v < 256; v++) b[v] = src[v] * 1 + src[v] * 0 + 0.5;
    expect(Array.from(a)).toEqual(Array.from(b));
  });
});
