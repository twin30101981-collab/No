import { afterEach, describe, expect, it, vi } from "vitest";
import { jobFromDisk, jobToDisk, type BgJob } from "./bg-queue";
import { adoptBlob, blobFor } from "./disk-pack";

// CS-12: việc nền mang ảnh gốc dạng blob: (chỉ sống trong phiên) → ghi Blob thật; đọc lại cấp URL mới dùng được.
const job = (orig: string): BgJob => ({ id: "j1", pageId: "p1", kind: "finish", state: "queued", payload: { orig, targetLong: 3508 }, attempts: 0, createdAt: 1, updatedAt: 1 });
let n = 0;
afterEach(() => { vi.restoreAllMocks(); });
const stubUrl = () => {
  vi.spyOn(URL, "createObjectURL").mockImplementation(() => `blob:test/${++n}`);
  vi.spyOn(URL, "revokeObjectURL").mockImplementation(() => {});
};

describe("CS-12 jobToDisk / jobFromDisk", () => {
  it("blob: đã đăng ký → lưu Blob, không giữ chuỗi blob: chết; đọc lại ra URL mới trỏ đúng Blob", () => {
    stubUrl();
    const b = new Blob(["anh"], { type: "image/jpeg" }); const u = adoptBlob(b);
    const disk = jobToDisk(job(u));
    expect(disk.payload.orig).toBe(""); expect((disk as { origB?: Blob }).origB).toBe(b);
    const back = jobFromDisk(disk);
    expect(back.payload.orig.startsWith("blob:")).toBe(true); expect(back.payload.orig).not.toBe(u);
    expect(blobFor(back.payload.orig)).toBe(b); expect("origB" in back).toBe(false);
  });
  it("data URL / blob: lạ → giữ nguyên (tương thích việc cũ)", () => {
    const d = job("data:image/jpeg;base64,AAAA"); expect(jobToDisk(d)).toBe(d); expect(jobFromDisk(d)).toEqual(d);
    const x = job("blob:khong-dang-ky"); expect(jobToDisk(x)).toBe(x);
  });
});
