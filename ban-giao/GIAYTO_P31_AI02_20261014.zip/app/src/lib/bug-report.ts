/**
 * FX-04: gói "Báo lỗi" — nhật ký quét/AI + số đo tốc độ (ngân sách §17.1) + công cụ hay dùng + cài đặt không nhạy cảm.
 * KHÔNG kèm ảnh/nội dung tài liệu: mọi chuỗi data:/blob:/base64 dài bị thay bằng "[đã bỏ]"; không có PIN, khoá két, quy tắc thư mục.
 */
import { budgetReport, readPerf, type PerfSample } from "./perf-stats";
import { deviceInfo, readScanLog, type ScanLogEntry } from "./scan-log";
import { getSettings, type Settings } from "./settings";
import { readUses } from "./tool-usage";

/** Cài đặt được phép gửi (cờ chức năng); bỏ pin/pinSalt/vaultWrap/nameTemplate/folderRules. */
const SAFE_SETTINGS = ["quality", "paper", "ocrLang", "dark", "autoLock", "autoCapture", "maxQuality", "captureSound", "captureVibrate", "defaultFilter",
  "autoName", "autoOcr", "autoRecipe", "globalPipeline", "continuousCapture", "largeText", "voiceGuide", "guideVibrate"] as const;
export const DROPPED = "[đã bỏ]";

/** Bỏ mọi giá trị có thể là ảnh/tệp: data:/blob: URL, chuỗi base64 dài (≥ 200 ký tự liền), chuỗi > 2000 ký tự. */
export function scrub(v: unknown, depth = 0): unknown {
  if (typeof v === "string") return /^(data|blob):/i.test(v) || /[A-Za-z0-9+/=]{200,}/.test(v) || v.length > 2000 ? DROPPED : v;
  if (v === null || typeof v !== "object") return v;
  if (depth > 6) return DROPPED;
  if (Array.isArray(v)) return v.map((x) => scrub(x, depth + 1));
  return Object.fromEntries(Object.entries(v as Record<string, unknown>).map(([k, x]) => [k, scrub(x, depth + 1)]));
}

export type BugReport = {
  kind: "ghi-nhanh-bao-loi"; createdAt: string; build: string; device: string; note: string;
  settings: Partial<Settings>; scanLog: unknown; perf: { samples: number; budget: ReturnType<typeof budgetReport> }; toolUses: Record<string, number>;
};

export function buildBugReport(src: { log: ScanLogEntry[]; perf: PerfSample[]; uses: Record<string, number>; settings: Settings; build: string; device: string; note?: string; now?: Date }): BugReport {
  const settings = Object.fromEntries(SAFE_SETTINGS.filter((k) => k in src.settings).map((k) => [k, src.settings[k]])) as Partial<Settings>;
  return {
    kind: "ghi-nhanh-bao-loi", createdAt: (src.now ?? new Date()).toISOString(), build: src.build, device: src.device,
    note: (scrub((src.note ?? "").slice(0, 1000)) as string),
    settings, scanLog: scrub(src.log), perf: { samples: src.perf.length, budget: budgetReport(src.perf) }, toolUses: src.uses,
  };
}

/** Gói từ dữ liệu trên máy → Blob JSON + tên tệp. */
export function currentBugReport(note = "") {
  const build = typeof __BUILD_ID__ === "string" ? __BUILD_ID__ : "dev";
  const r = buildBugReport({ log: readScanLog(), perf: readPerf(), uses: readUses(), settings: getSettings(), build, device: deviceInfo(), note });
  const name = `ghi-nhanh-bao-loi-${r.createdAt.slice(0, 19).replace(/[:T]/g, "-")}.json`;
  return { report: r, name, blob: new Blob([JSON.stringify(r, null, 2)], { type: "application/json" }) };
}
