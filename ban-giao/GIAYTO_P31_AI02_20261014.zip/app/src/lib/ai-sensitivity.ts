/**
 * AI-05 (QD-13, đề án 12.6): định tuyến theo độ nhạy cảm — giấy tờ nhạy cảm (CCCD/hộ chiếu, sổ đỏ, sao kê, hợp đồng, đăng ký xe,
 * tài liệu khoá PIN, nội dung có số CCCD/điện thoại/tài khoản) KHÔNG gửi tới nguồn miễn phí (Mistral/Gemini có thể dùng dữ liệu để huấn
 * luyện): chỉ Lovable → Claude → xử lý trên máy. Không biết loại tài liệu → coi là nhạy cảm (an toàn trước). Bài tập (Giải bài tập) là
 * tài liệu thường trừ khi có số cá nhân. Màn tài liệu báo gợi ý cho máy chủ qua tiêu đề x-ai-sensitive (1/0).
 */
import { classifyNumber } from "./sensitive";

export const SENSITIVE_DOC_TYPES = ["CCCD/Hộ chiếu", "Hợp đồng", "Sao kê/Chứng từ ngân hàng", "Sổ đỏ", "Giấy đăng ký xe"] as const;
const SENSITIVE_WORDS = /cccd|cmnd|căn cước|hộ chiếu|passport|sổ đỏ|sổ hồng|sao kê|chứng từ ngân hàng|hợp đồng|đăng ký xe/i;
export const AI_SENSITIVE_HEADER = "x-ai-sensitive";

/** Tài liệu nhạy cảm: đang khoá PIN, hoặc loại/loại AI đặt thuộc nhóm nhạy cảm. */
export function isSensitiveDoc(d: { kind?: string | undefined; fields?: Record<string, string> | undefined; enc?: unknown; locked?: boolean | undefined }): boolean {
  if (d.enc || d.locked) return true;
  const types = [d.kind, d.fields?.["docType"]].filter((x): x is string => !!x);
  return types.some((t) => (SENSITIVE_DOC_TYPES as readonly string[]).includes(t) || SENSITIVE_WORDS.test(t));
}
/** Chữ có số CCCD/CMND, điện thoại hoặc tài khoản/thẻ (cùng luật với che số cá nhân — sensitive.ts). */
export function textHasSensitiveNumbers(text: string): boolean {
  for (const m of text.matchAll(/\+?\d[\d .\-–]{6,}\d/g)) { const raw = m[0]; const digits = raw.replace(/\D/g, ""); if (classifyNumber(digits, raw)) return true; }
  return false;
}
/** Chuỗi chữ trong dữ liệu gửi AI (bỏ ảnh data URL). */
function texts(v: unknown, out: string[] = [], depth = 0): string[] {
  if (typeof v === "string") { if (!v.startsWith("data:")) out.push(v); }
  else if (v && typeof v === "object" && depth < 5) for (const x of Object.values(v as Record<string, unknown>)) texts(x, out, depth + 1);
  return out;
}
/** Quyết định cho một lệnh AI (máy chủ): số cá nhân trong chữ → nhạy cảm; gợi ý của màn tài liệu; bài tập → thường; còn lại → nhạy cảm. */
export function sensitiveFor(task: string, data: unknown, hint: string | null | undefined): boolean {
  if (texts(data).some(textHasSensitiveNumbers)) return true;
  if (hint === "1") return true;
  if (hint === "0") return false;
  if (task === "aiText" && (data as { task?: string } | null)?.task === "solve") return false;
  return true;
}

// Gợi ý phía máy khách: màn tài liệu đặt theo tài liệu đang mở; null = không rõ (máy chủ coi là nhạy cảm).
let hint: boolean | null = null;
export const setAiSensitivity = (v: boolean | null) => { hint = v; };
export const aiSensitivityHint = () => hint;
