import { beforeEach, describe, expect, it, vi } from "vitest";

// BL-07 (RS-27): chuyển PDF scan — giới hạn canvas sống, table() ném lỗi rơi về OCR, luôn pdf.destroy().
const st = vi.hoisted(() => ({ live: new Set<HTMLCanvasElement>(), maxLive: 0, destroyed: 0, cleaned: 0, ocrCalls: 0, pages: 12 }));
const liveCount = () => [...st.live].filter((c) => c.width * c.height > 0).length;

vi.mock("./files", () => ({
  pdfjs: async () => ({
    getDocument: () => ({ destroy: async () => { st.destroyed++; }, promise: Promise.resolve({
      numPages: st.pages,
      getPage: async () => ({
        getTextContent: async () => ({ items: [] }), // trang scan: không có lớp chữ
        getViewport: ({ scale }: { scale: number }) => ({ width: Math.round(600 * scale), height: Math.round(800 * scale) }),
        render: ({ canvas }: { canvas: HTMLCanvasElement }) => { st.live.add(canvas); st.maxLive = Math.max(st.maxLive, liveCount()); return { promise: new Promise((r) => setTimeout(r, 2)) }; },
        cleanup: () => { st.cleaned++; },
      }),
    }) }),
  }),
}));
vi.mock("./image", () => ({ normalize: async () => "data:image/jpeg;base64,AA==" }));
vi.mock("./ocr", async (orig) => ({
  ...(await orig<typeof import("./ocr")>()),
  ocrSession: async () => ({ words: async () => { st.ocrCalls++; return { text: "Cột A  Cột B", words: [], confidence: 90 }; }, close: async () => {} }),
}));

import { readPdf } from "./pdf-convert";

HTMLCanvasElement.prototype.getContext = (() => ({})) as never; // jsdom: không có canvas thật
beforeEach(() => { st.live.clear(); st.maxLive = 0; st.destroyed = 0; st.cleaned = 0; st.ocrCalls = 0; st.pages = 12; });
const file = () => ({ arrayBuffer: async () => new ArrayBuffer(8) }) as unknown as Blob;
const okTable = async () => { await new Promise((r) => setTimeout(r, 3)); return { ok: true as const, data: { rows: [["a", "b"]] } }; };

describe("BL-07 readPdf (PDF scan)", () => {
  it("không giữ canvas của mọi trang: tối đa 3 canvas sống cùng lúc (trước: = số trang)", async () => {
    const out = await readPdf(file(), { table: okTable as never });
    expect(out.filter((p) => p?.ai)).toHaveLength(12);
    expect(st.maxLive).toBeLessThanOrEqual(3);
    expect(liveCount()).toBe(0); // giải phóng hết sau khi xong
  });
  it("table() NÉM lỗi (mất mạng) → không hỏng cả lượt, rơi về OCR từng trang (trước: reject cả lượt)", async () => {
    st.pages = 4;
    const warn = vi.fn();
    const out = await readPdf(file(), { table: (async () => { throw new TypeError("Failed to fetch"); }) as never, warn });
    expect(out.every((p) => p.ocr && !p.ai)).toBe(true);
    expect(st.ocrCalls).toBe(4);
    expect(warn).toHaveBeenCalledTimes(1);
    expect(st.maxLive).toBeLessThanOrEqual(3);
  });
  it("luôn gọi loadingTask.destroy() — cả khi thành công lẫn khi lỗi", async () => {
    await readPdf(file(), { table: okTable as never });
    expect(st.destroyed).toBe(1);
    st.pages = 2;
    const bad = vi.fn(async () => { throw new Error("hỏng"); });
    await readPdf(file(), { table: bad as never }).catch(() => {});
    expect(st.destroyed).toBe(2);
  });
});

describe("BL-07 (RS-34) unrotateBox: toạ độ OCR trên ảnh đã xoay → ảnh gốc", async () => {
  const { unrotateBox } = await vi.importActual<typeof import("./ocr")>("./ocr");
  // ảnh gốc 400×300; điểm gốc (x,y) sau khi xoay 90° cw (ảnh 300×400) nằm ở (H−y, x); xoay 270° nằm ở (y, W−x)
  const W = 400, H = 300;
  it("90°: khung quay về đúng chỗ", () => {
    // khung gốc x 10..50, y 20..40 → trên ảnh xoay: x' = H−y (260..280), y' = x (10..50)
    expect(unrotateBox({ x0: 260, y0: 10, x1: 280, y1: 50 }, 90, W, H)).toEqual({ x0: 10, y0: 20, x1: 50, y1: 40 });
  });
  it("270°: khung quay về đúng chỗ", () => {
    // trên ảnh xoay: x' = y (20..40), y' = W−x (350..390)
    expect(unrotateBox({ x0: 20, y0: 350, x1: 40, y1: 390 }, 270, W, H)).toEqual({ x0: 10, y0: 20, x1: 50, y1: 40 });
  });
  it("0°: giữ nguyên", () => expect(unrotateBox({ x0: 1, y0: 2, x1: 3, y1: 4 }, 0, W, H)).toEqual({ x0: 1, y0: 2, x1: 3, y1: 4 }));
});
