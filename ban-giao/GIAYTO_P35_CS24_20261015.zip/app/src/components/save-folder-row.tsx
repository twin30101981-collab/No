import { FolderDown } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { folderError, folderForSave, folderSupported, forgetFolder, savedFolder, writeToFolder } from "@/lib/save-folder";

/** TF-03: "Lưu vào thư mục" — nhớ thư mục mặc định; chỉ hiện khi trình duyệt hỗ trợ (Chrome/Edge PC). */
export function SaveFolderRow({ getBlob, name, busy, onBusy, onError }: { getBlob: () => Promise<Blob>; name: string; busy: boolean; onBusy: (b: boolean) => void; onError: (e: unknown) => void }) {
  const [ok, setOk] = useState(false); const [folder, setFolder] = useState<string | null>(null);
  useEffect(() => { // đọc ở effect (SSR không có window)
    if (!folderSupported()) return;
    setOk(true); void savedFolder().then((h) => setFolder(h?.name ?? null));
  }, []);
  if (!ok) return null;
  async function save(change: boolean) {
    onBusy(true);
    try {
      const dir = await folderForSave({ change });
      if (!dir) { toast("Chưa lưu: bạn chưa chọn thư mục hoặc chưa cho phép ghi."); return; }
      setFolder(dir.name);
      const used = await writeToFolder(dir, await getBlob(), name);
      toast.success(`Đã lưu “${used}” vào thư mục “${dir.name}”`);
    } catch (e) {
      if ((e as { name?: string } | null)?.name && /NotAllowed|Security|Quota|NotFound|InvalidState/.test((e as { name: string }).name)) { toast.error(folderError(e)); if (/NotFound|InvalidState/.test((e as { name: string }).name)) { await forgetFolder(); setFolder(null); } }
      else onError(e);
    } finally { onBusy(false); }
  }
  return (
    <div className="mt-2 flex gap-2">
      <Button className="min-w-0 flex-1" disabled={busy} variant="glass" onClick={() => void save(false)}><FolderDown className="shrink-0" /><span className="truncate">{folder ? `Lưu vào thư mục “${folder}”` : "Lưu vào thư mục…"}</span></Button>
      {folder && <Button disabled={busy} variant="glass" aria-label="Đổi thư mục lưu" onClick={() => void save(true)}>Đổi</Button>}
    </div>
  );
}
