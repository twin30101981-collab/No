/**
 * CS-11: utif2 lấy pako bằng `require("pako")`, nếu không có thì `self.pako`. Trong gói build (ESM) không có require
 * → TIFF nén deflate báo lỗi. Gán pako toàn cục TRƯỚC khi nạp utif2 (tiff-decode.ts import tệp này trước).
 * Phải là giá trị được dùng (không phải import chỉ để chạy): package.json có "sideEffects": false → Rollup bỏ import trần.
 */
import pako from "pako";
const g = globalThis as { pako?: unknown };
export const TIFF_PAKO = (g.pako ??= pako);
