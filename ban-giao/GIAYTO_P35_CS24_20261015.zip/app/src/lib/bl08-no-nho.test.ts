import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { EXPENDABLE_KEYS, StorageFullError, safeSet } from "./safe-storage";
import { aiErrorLine, redactSecrets } from "./ai-log";
import { CSP, SECURITY_HEADERS, headersFileText, withSecurityHeaders } from "./security-headers";
import { randomOwnerPassword } from "./files";

/** Storage giả có hạn mức ký tự (mô phỏng localStorage ≈ 5 MB đầy). */
function fakeStorage(limit: number, blocked = false): Storage {
  const m = new Map<string, string>();
  const used = () => [...m].reduce((s, [k, v]) => s + k.length + v.length, 0);
  return {
    get length() { return m.size; }, clear: () => m.clear(), key: (i: number) => [...m.keys()][i] ?? null,
    getItem: (k: string) => m.get(k) ?? null, removeItem: (k: string) => { m.delete(k); },
    setItem: (k: string, v: string) => {
      if (blocked) throw new DOMException("blocked", "SecurityError");
      const before = m.get(k); m.set(k, v);
      if (used() > limit) { if (before === undefined) m.delete(k); else m.set(k, before); throw new DOMException("full", "QuotaExceededError"); }
    },
  };
}

describe("BL-08 safeSet localStorage", () => {
  it("đầy vì nhật ký → xoá nhật ký không thiết yếu rồi ghi được, dữ liệu khác giữ nguyên", () => {
    const s = fakeStorage(200);
    s.setItem("ghi-nhanh:perf", "x".repeat(120)); s.setItem("ghi-nhanh-library", "thư mục");
    safeSet("ghi-nhanh-settings", "y".repeat(60), s);
    expect(s.getItem("ghi-nhanh-settings")).toBe("y".repeat(60));
    expect(s.getItem("ghi-nhanh:perf")).toBeNull();
    expect(s.getItem("ghi-nhanh-library")).toBe("thư mục");
  });
  it("vẫn đầy hoặc bị chặn → lỗi tiếng Việt rõ ràng (không mất âm thầm, không DOMException thô)", () => {
    const s = fakeStorage(50); s.setItem("gn-receipts", "z".repeat(30));
    expect(() => safeSet("ghi-nhanh-settings", "y".repeat(40), s)).toThrow(StorageFullError);
    expect(() => safeSet("k", "v", fakeStorage(1000, true))).toThrow(/Bộ nhớ trình duyệt đã đầy hoặc bị chặn/);
  });
  it("chỉ nhật ký/thống kê là khoá được xoá", () => {
    expect(EXPENDABLE_KEYS.every((k) => /perf|scan-log|tool-uses/.test(k))).toBe(true);
  });
  it("các nơi ghi dữ liệu người dùng dùng safeSet (không còn localStorage.setItem trần)", () => {
    for (const f of ["settings.ts", "receipt.ts", "library.ts", "cloud-sync.ts"]) expect(readFileSync(`src/lib/${f}`, "utf8")).not.toMatch(/localStorage\.setItem/);
  });
});

describe("BL-08 log AI không lộ ảnh/khoá", () => {
  it("lỗi APICallError: chỉ tên, mã, thông điệp đã che; không in requestBodyValues/responseBody", () => {
    const e = Object.assign(new Error("Bad request for key=AIzaSyA1234567890abcdefghijklmnop"), {
      name: "AI_APICallError", statusCode: 400,
      requestBodyValues: { messages: [{ content: [{ type: "image", image: "data:image/jpeg;base64," + "A".repeat(5000) }] }] },
      responseBody: "{\"error\":\"…\"}",
    });
    const line = aiErrorLine(e);
    expect(line).toMatch(/^\[ai\] AI_APICallError 400: /);
    expect(line).not.toMatch(/AAAAAAAAAA|base64|AIzaSyA1234567890abc/);
    expect(line.length).toBeLessThan(400);
  });
  it("che data URL, chuỗi base64 dài, khoá sk-/Bearer", () => {
    const s = redactSecrets(`data:image/png;base64,${"Q".repeat(300)} sk-ant-api03-abcdefghijklmnop Bearer eyJhbGciOi.xyz`);
    expect(s).not.toMatch(/QQQQ|abcdefghijklmnop|eyJhbGciOi/);
  });
  it("ai.functions.ts không còn console.error(e) trần", () => {
    const src = readFileSync("src/lib/ai.functions.ts", "utf8");
    expect(src).not.toMatch(/console\.error\(e\)/);
    expect(src).toMatch(/console\.error\(aiErrorLine\(e\)\)/);
  });
});

describe("BL-08 (Q7) tiêu đề bảo mật", () => {
  it("public/_headers khớp nguồn sự thật security-headers.ts", () => {
    expect(readFileSync("public/_headers", "utf8")).toBe(headersFileText());
  });
  it("CSP: có nguồn đang dùng, chặn object/base, không có * tràn lan cho script/connect", () => {
    for (const s of ["https://*.supabase.co", "wss://*.supabase.co", "https://cdn.jsdelivr.net", "https://accounts.google.com", "'wasm-unsafe-eval'", "worker-src 'self' blob:", "object-src 'none'", "base-uri 'self'"]) expect(CSP).toContain(s);
    const dir = (n: string) => CSP.split("; ").find((d) => d.startsWith(n + " ")) ?? "";
    expect(dir("script-src")).not.toMatch(/\s(\*|https:)(\s|$)/);
    expect(dir("connect-src")).not.toMatch(/\s(\*|https:)(\s|$)/);
    expect(SECURITY_HEADERS["Permissions-Policy"]).toMatch(/camera=\(self\)/);
    expect(SECURITY_HEADERS["X-Content-Type-Options"]).toBe("nosniff");
  });
  it("withSecurityHeaders thêm tiêu đề, không ghi đè tiêu đề phản hồi đã đặt", () => {
    const r = withSecurityHeaders(new Response("x", { headers: { "content-type": "text/html", "Referrer-Policy": "no-referrer" } }), true);
    expect(withSecurityHeaders(new Response("x"), false).headers.has("content-security-policy")).toBe(false); // dev: không áp
    expect(r.headers.get("content-security-policy")).toBe(CSP);
    expect(r.headers.get("referrer-policy")).toBe("no-referrer");
    expect(r.headers.get("content-type")).toBe("text/html");
  });
  it("server.ts gắn tiêu đề cho phản hồi SSR và trang lỗi", () => {
    const src = readFileSync("src/server.ts", "utf8");
    expect(src.match(/withSecurityHeaders\(/g)?.length).toBeGreaterThanOrEqual(2);
  });
});

describe("BL-08 (RS-17) mật khẩu chủ PDF", () => {
  it("ngẫu nhiên 128 bit, không suy ra từ mật khẩu mở", () => {
    const a = randomOwnerPassword(), b = randomOwnerPassword();
    expect(a).toMatch(/^[0-9a-f]{32}$/);
    expect(a).not.toBe(b);
    expect(readFileSync("src/lib/files.ts", "utf8")).not.toMatch(/password \+ "#owner"/);
  });
});
