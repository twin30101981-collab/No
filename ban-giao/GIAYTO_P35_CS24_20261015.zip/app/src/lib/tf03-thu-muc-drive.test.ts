import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { folderError, freeName, writeToFolder } from "./save-folder";
import { readStoredToken } from "./drive";
import { uniqueNames } from "./batch";

/** Thư mục giả: tên → nội dung, đủ API getFileHandle/createWritable. */
function fakeDir(existing: string[] = [], opt: { failWrite?: boolean } = {}) {
  const files = new Map<string, Blob>(existing.map((n) => [n, new Blob(["cũ"])]));
  const dir = {
    files,
    async getFileHandle(n: string, o?: { create?: boolean }) {
      if (!files.has(n) && !o?.create) throw Object.assign(new Error("nf"), { name: "NotFoundError" });
      return { async createWritable() { let chunk: Blob | null = null; return { async write(b: Blob) { if (opt.failWrite) throw Object.assign(new Error("full"), { name: "QuotaExceededError" }); chunk = b; }, async close() { files.set(n, chunk ?? new Blob([])); }, async abort() {} }; } };
    },
  };
  return dir as unknown as FileSystemDirectoryHandle & { files: Map<string, Blob> };
}

describe("TF-03 lưu vào thư mục", () => {
  it("freeName không đè tệp có sẵn: a.pdf → a (2).pdf → a (3).pdf", async () => {
    expect(await freeName(fakeDir(), "a.pdf")).toBe("a.pdf");
    expect(await freeName(fakeDir(["a.pdf"]), "a.pdf")).toBe("a (2).pdf");
    expect(await freeName(fakeDir(["a.pdf", "a (2).pdf"]), "a.pdf")).toBe("a (3).pdf");
    expect(await freeName(fakeDir(["ghi"]), "ghi")).toBe("ghi (2)");
  });
  it("writeToFolder ghi đúng nội dung, giữ tệp cũ, trả tên đã dùng", async () => {
    const d = fakeDir(["a.pdf"]);
    const mới = new Blob(["mới"]), cũ = d.files.get("a.pdf");
    expect(await writeToFolder(d, mới, "a.pdf")).toBe("a (2).pdf");
    expect(d.files.get("a (2).pdf")).toBe(mới);
    expect(d.files.get("a.pdf")).toBe(cũ); // tệp cũ nguyên vẹn
  });
  it("ghi lỗi (ổ đầy) → ném lỗi gốc, không để lại tệp dở", async () => {
    const d = fakeDir([], { failWrite: true });
    await expect(writeToFolder(d, new Blob(["x"]), "b.pdf")).rejects.toMatchObject({ name: "QuotaExceededError" });
    expect(d.files.size).toBe(0);
  });
  it("thông báo lỗi tiếng Việt theo loại lỗi", () => {
    expect(folderError({ name: "NotAllowedError" })).toMatch(/quyền ghi/);
    expect(folderError({ name: "QuotaExceededError" })).toMatch(/Ổ đĩa đầy/);
    expect(folderError({ name: "NotFoundError" })).toMatch(/xoá hoặc di chuyển/);
    expect(folderError(new Error("lạ"))).toMatch(/chọn lại thư mục/);
  });
  it("xuất hàng loạt: tên tệp theo tài liệu, trùng tên được đánh số", () => {
    const n = uniqueNames(["Hợp đồng", "Hợp đồng", "CCCD"], "pdf"); expect(new Set(n).size).toBe(3); expect(n[1]).toMatch(/-2\.pdf$/);
  });
  it("batchSeparate có sink (thư mục) — không gói zip; nguồn: nhánh sink có mặt, giao diện xin thư mục TRƯỚC khi chờ", () => {
    const b = readFileSync("src/lib/batch.ts", "utf8"), ui = readFileSync("src/components/batch-export.tsx", "utf8");
    expect(b).toMatch(/sink\?: \(name: string, blob: Blob\) => Promise<string>/);
    expect(ui.indexOf("folderForSave()")).toBeGreaterThan(-1);
    expect(ui.indexOf("folderForSave()")).toBeLessThan(ui.indexOf("await readyDocs(docsProp); // CS-04", ui.indexOf("async function run()")));
  });
  it("không đụng schema IndexedDB chính (handle ở cơ sở dữ liệu riêng gn-save-folder)", () => {
    const s = readFileSync("src/lib/save-folder.ts", "utf8");
    expect(s).toContain('"gn-save-folder"');
    expect(s).not.toMatch(/from "\.\/db"/);
  });
});

describe("TF-03 token Drive giữ theo phiên", () => {
  const store = (v: string | null) => ({ removed: false, getItem: () => v, removeItem() { this.removed = true; } });
  it("token còn hạn (> 30 s) được dùng lại", () => {
    const now = 1_000_000;
    expect(readStoredToken(store(JSON.stringify({ value: "t", until: now + 600_000 })), now)).toEqual({ value: "t", until: now + 600_000 });
  });
  it("hết hạn / hỏng / thiếu trường → null và xoá", () => {
    const now = 1_000_000;
    for (const v of [JSON.stringify({ value: "t", until: now + 10_000 }), "không phải json", JSON.stringify({ value: 1, until: "x" }), "null", null]) {
      const s = store(v); expect(readStoredToken(s, now)).toBeNull();
    }
    const s = store(JSON.stringify({ value: "t", until: now - 1 })); readStoredToken(s, now); expect(s.removed).toBe(true);
    expect(readStoredToken(null)).toBeNull(); // sessionStorage bị chặn
  });
  it("token KHÔNG nằm localStorage (chỉ sessionStorage của thẻ)", () => {
    const d = readFileSync("src/lib/drive.ts", "utf8");
    expect(d).not.toMatch(/localStorage/);
    expect(d).toMatch(/sessionStorage\.setItem\(TOKEN_KEY/);
  });
  it("nút Drive ẩn khi chưa cấu hình (FX-01 giữ nguyên)", () => {
    expect(readFileSync("src/routes/doc.$id.tsx", "utf8")).toMatch(/driveReady\(\) && <Button/);
  });
});
