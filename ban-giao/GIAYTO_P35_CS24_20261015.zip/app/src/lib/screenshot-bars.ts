/**
 * CS-11 — Ảnh chụp màn hình điện thoại: tự bỏ thanh trạng thái (giờ/pin ở hai góc trên) và
 * thanh điều hướng (vạch "home" giữa đáy hoặc 3 nút) bằng KHUNG CẮT — ảnh gốc giữ nguyên, người dùng kéo lại được.
 * Chỉ cắt khi nhận dạng chắc: nhóm nét ở mép trên chỉ nằm ở hai góc (giữa trống), mép dưới chỉ có vạch giữa
 * hoặc 3 cụm nút; vùng giữa thanh và nội dung phải trống. Không chắc → không cắt (0).
 * Hàm thuần trên RGBA đã thu nhỏ (rộng ~360) để kiểm thử bằng Node.
 */
export interface Bars { top: number; bottom: number } // tỉ lệ chiều cao cần bỏ ở trên / dưới (0 = giữ)

const INK = 40; // lệch độ sáng so với nền hàng ≥ INK = nét

type Row = { ink: number; left: number; right: number; center: number; mid: number; xmin: number; xmax: number; lmax: number; rmin: number; bg: number };

function rows(d: Uint8ClampedArray | Uint8Array, w: number, h: number): Row[] {
  const out: Row[] = [], lum = new Uint8Array(w), hist = new Uint32Array(256);
  for (let y = 0; y < h; y++) {
    hist.fill(0);
    for (let x = 0; x < w; x++) { const p = (y * w + x) * 4; const l = (d[p] * 77 + d[p + 1] * 150 + d[p + 2] * 29) >> 8; lum[x] = l; hist[l]++; }
    // nền hàng = mức sáng phổ biến nhất (gộp ±3 để chịu nén JPEG)
    let bg = 0, best = -1;
    for (let l = 0; l < 256; l++) { let s = 0; for (let k = Math.max(0, l - 3); k <= Math.min(255, l + 3); k++) s += hist[k]; if (s > best) { best = s; bg = l; } }
    const r: Row = { ink: 0, left: 0, right: 0, center: 0, mid: 0, xmin: w, xmax: -1, lmax: -1, rmin: w, bg };
    for (let x = 0; x < w; x++) {
      if (Math.abs(lum[x] - bg) < INK) continue;
      r.ink++; if (x < r.xmin) r.xmin = x; r.xmax = x;
      const f = x / w;
      if (f < 0.4) r.left++; else if (f > 0.6) r.right++;
      if (f < 0.5) r.lmax = x; else if (r.rmin === w) r.rmin = x;
      if (f >= 0.45 && f <= 0.55) r.center++;
      if (f >= 0.4 && f <= 0.6) r.mid++;
    }
    out.push(r);
  }
  return out;
}

/** Nhóm hàng có nét liên tiếp (cho phép hở ≤ gap hàng) trong [from, to). */
function groups(rs: Row[], from: number, to: number, gap: number): [number, number][] {
  const g: [number, number][] = [];
  let s = -1, e = -1;
  for (let y = from; y < to; y++) {
    if (!rs[y].ink) continue;
    if (s >= 0 && y - e - 1 <= gap) e = y;
    else { if (s >= 0) g.push([s, e]); s = e = y; }
  }
  if (s >= 0) g.push([s, e]);
  return g;
}

const sameBg = (a: Row, b: Row) => Math.abs(a.bg - b.bg) <= 6;

function topBar(rs: Row[], w: number, h: number, strict: boolean): number {
  const lim = Math.round(h * 0.075), gap = Math.max(1, Math.round(h * 0.003));
  const gs = groups(rs, 0, lim, gap);
  if (!gs.length) return 0;
  const [s, e] = gs[0];
  const tall = e - s + 1;
  if (tall < h * 0.006 || tall > h * 0.035 || e >= lim - 1 || (strict && s > h * 0.03)) return 0;
  let left = 0, right = 0, xmin = w, lmax = -1, rmin = w, xmax = -1;
  for (let y = s; y <= e; y++) {
    const r = rs[y];
    if (r.center > 0 || r.mid > w * 0.04) return 0; // giữa phải trống (giờ bên trái, pin bên phải)
    left += r.left; right += r.right;
    if (r.ink) { xmin = Math.min(xmin, r.xmin); xmax = Math.max(xmax, r.xmax); lmax = Math.max(lmax, r.lmax); rmin = Math.min(rmin, r.rmin); }
  }
  if (!left || !right) return 0;
  // giờ sát mép trái, cụm sóng/pin sát mép phải, mỗi cụm hẹp — tiêu đề công văn (hai khối chữ rộng) không khớp
  if (xmin > w * 0.2 || lmax > w * 0.42 || rmin < w * 0.62 || xmax < w * 0.8) return 0;
  for (let y = 0; y < s; y++) if (!sameBg(rs[y], rs[s])) return 0; // phía trên nhóm: cùng một nền trống
  // cắt đối xứng: lề dưới ≈ lề trên của nét; dừng sớm nếu gặp nội dung hoặc nền đổi màu (thanh tiêu đề app)
  const want = Math.min(lim, e + 1 + Math.max(s, gap));
  let cut = e + 1;
  while (cut < want && !rs[cut].ink && sameBg(rs[cut], rs[0])) cut++;
  if (cut - e - 1 < 2) return 0; // không có khoảng trống giữa thanh trạng thái và nội dung
  return cut / h;
}

function bottomBar(rs: Row[], w: number, h: number, strict: boolean): number {
  const from = h - Math.round(h * 0.07), gap = Math.max(1, Math.round(h * 0.003));
  const gs = groups(rs, from, h, gap);
  if (!gs.length) return 0;
  const [s, e] = gs[gs.length - 1];
  const tall = e - s + 1;
  if (tall > h * 0.03 || s <= from) return 0;
  for (let y = e + 1; y < h; y++) if (rs[y].ink) return 0;
  let xmin = w, xmax = -1, l = 0, m = 0, r = 0, full = 0;
  for (let y = s; y <= e; y++) {
    const row = rs[y];
    if (!row.ink) continue;
    xmin = Math.min(xmin, row.xmin); xmax = Math.max(xmax, row.xmax);
    l += row.left; m += row.mid; r += row.right; full = Math.max(full, row.ink);
  }
  const pill = xmin >= w * 0.25 && xmax <= w * 0.75 && (xmax - xmin) >= w * 0.15 && tall <= h * 0.01 && m > 0 && full >= (xmax - xmin + 1) * 0.8; // vạch đặc, không phải chữ chân trang
  const buttons = !strict && xmin >= w * 0.08 && xmax <= w * 0.92 && l > 0 && m > 0 && r > 0 && tall >= h * 0.008;
  if (!pill && !buttons) return 0;
  // vùng trống ngay trên thanh (≥ 0,4 % chiều cao) — nội dung app không dính vào thanh
  const need = Math.max(2, Math.round(h * 0.004));
  let y = s - 1, blank = 0;
  while (y >= from - need && !rs[y].ink && sameBg(rs[y], rs[s - 1])) { blank++; y--; }
  if (blank < need) return 0;
  const cut = Math.max(y + 1, s - Math.max(h - 1 - e, gap));
  return (h - cut) / h;
}

/** Thanh hệ thống cần bỏ trên ảnh chụp màn hình dọc (rộng w, cao h, RGBA).
 *  strict (ảnh loại "flat" — có thể là trang quét): nét trên phải bắt đầu trong 3 % đầu, đáy chỉ nhận vạch home. */
export function detectSystemBars(d: Uint8ClampedArray | Uint8Array, w: number, h: number, strict = false): Bars {
  if (h < w * 1.3 || w < 100) return { top: 0, bottom: 0 }; // chỉ ảnh dọc kiểu điện thoại/máy tính bảng
  const rs = rows(d, w, h);
  return { top: topBar(rs, w, h, strict), bottom: bottomBar(rs, w, h, strict) };
}

/** Khung cắt (toạ độ 0..1) bỏ thanh hệ thống; null khi không có gì để bỏ. */
export function barsQuad(b: Bars): [number, number][] | null {
  if (b.top <= 0 && b.bottom <= 0) return null;
  const t = +b.top.toFixed(4), u = +(1 - b.bottom).toFixed(4);
  return [[0, t], [1, t], [1, u], [0, u]];
}

/** Bản cho trình duyệt: nguồn ảnh → khung cắt bỏ thanh hệ thống (dò trên bản rộng 360) + ảnh trang đã cắt; null khi không có/không đọc được. */
export async function cropSystemBars(src: string, strict = false): Promise<{ quad: [number, number][]; src: string } | null> {
  if (typeof document === "undefined") return null;
  try {
    const bmp = await createImageBitmap(await (await fetch(src)).blob());
    const w = 360, h = Math.max(1, Math.round((bmp.height * w) / bmp.width));
    const c = document.createElement("canvas"); c.width = w; c.height = h;
    const ctx = c.getContext("2d", { willReadFrequently: true });
    if (!ctx) { bmp.close(); return null; }
    ctx.drawImage(bmp, 0, 0, w, h);
    const quad = barsQuad(detectSystemBars(ctx.getImageData(0, 0, w, h).data, w, h, strict));
    if (!quad) { bmp.close(); return null; }
    // cắt thẳng hàng điểm ảnh (không nắn/không đổi khổ): cùng vùng với khung để dựng lại từ ảnh gốc cho kết quả như nhau
    const y0 = Math.round(quad[0][1] * bmp.height), y1 = Math.round(quad[2][1] * bmp.height);
    const out = document.createElement("canvas"); out.width = bmp.width; out.height = Math.max(1, y1 - y0);
    out.getContext("2d")!.drawImage(bmp, 0, y0, bmp.width, out.height, 0, 0, bmp.width, out.height); bmp.close();
    const { canvasToPageUrl } = await import("./canvas-url");
    return { quad, src: await canvasToPageUrl(out, "image/jpeg", 0.92) };
  } catch { return null; }
}
