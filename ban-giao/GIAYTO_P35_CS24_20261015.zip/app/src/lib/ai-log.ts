/**
 * BL-08 (log AI): một dòng log gọn cho lỗi AI ở máy chủ. KHÔNG in nguyên đối tượng lỗi: APICallError của AI SDK mang
 * `requestBodyValues` (ảnh base64 của giấy tờ — CCCD, hoá đơn) và `responseBody`; console.error(e) đổ cả vào log máy chủ.
 */
export function redactSecrets(s: string): string {
  return s
    .replace(/data:[\w/+.-]+;base64,[A-Za-z0-9+/=]+/g, "data:…")
    .replace(/[A-Za-z0-9+/=_-]{120,}/g, "…") // chuỗi base64/khoá dài
    .replace(/\b(sk-[A-Za-z0-9]{0,6}|AIza[0-9A-Za-z_-]{0,4})[0-9A-Za-z_-]{8,}/g, "$1…")
    .replace(/([?&](?:key|api_key|token)=)[^&\s"]+/gi, "$1…")
    .replace(/(Bearer\s+)[^\s"]+/gi, "$1…");
}
export function aiErrorLine(e: unknown, where = "ai"): string {
  const o = (e && typeof e === "object" ? e : {}) as { name?: unknown; message?: unknown; statusCode?: unknown; code?: unknown };
  const msg = redactSecrets(String(o.message ?? e)).slice(0, 300);
  const status = typeof o.statusCode === "number" ? ` ${o.statusCode}` : "";
  const code = typeof o.code === "string" ? ` ${o.code}` : "";
  return `[${where}] ${typeof o.name === "string" ? o.name : "Error"}${status}${code}: ${msg}`;
}
