/**
 * CS-11 — Giải mã TIFF (Chromium/Firefox không tự đọc TIFF; Safari đọc được nhưng chỉ trang đầu).
 * Dùng utif2 (đã duyệt P30), chạy trong tiff.worker.ts; hàm thuần ở đây để kiểm thử bằng Node.
 * Mỗi IFD là một trang (TIFF nhiều trang từ máy fax/máy quét); bỏ ảnh thu nhỏ (NewSubfileType bit 0).
 * Trang quá lớn được thu nhỏ trung bình hộp trước khi trả về: canvas iOS giới hạn ~16,7 triệu điểm ảnh.
 */
import { TIFF_PAKO } from "./tiff-pako"; // phải đứng trước utif2
import UTIF from "utif2";

export interface TiffPage { width: number; height: number; data: Uint8Array }
export interface TiffOpts { maxPages?: number; maxSide?: number; maxArea?: number }

export const TIFF_MAX_PAGES = 100;
const MAX_SIDE = 4096, MAX_AREA = 16_000_000;

/** Đầu tệp TIFF: "II*\0" (little-endian) hoặc "MM\0*" (big-endian); BigTIFF dùng 43 thay 42. */
export function isTiffBytes(b: Uint8Array): boolean {
  if (b.length < 4) return false;
  return (b[0] === 0x49 && b[1] === 0x49 && (b[2] === 42 || b[2] === 43) && b[3] === 0) || (b[0] === 0x4d && b[1] === 0x4d && b[2] === 0 && (b[3] === 42 || b[3] === 43));
}

/** Thu nhỏ RGBA bằng trung bình hộp (giữ nét chữ tốt hơn lấy mẫu gần nhất). */
export function downscaleRgba(src: Uint8Array, w: number, h: number, tw: number, th: number): Uint8Array {
  const out = new Uint8Array(tw * th * 4);
  for (let y = 0; y < th; y++) {
    const y0 = Math.floor((y * h) / th), y1 = Math.max(y0 + 1, Math.floor(((y + 1) * h) / th));
    for (let x = 0; x < tw; x++) {
      const x0 = Math.floor((x * w) / tw), x1 = Math.max(x0 + 1, Math.floor(((x + 1) * w) / tw));
      let r = 0, g = 0, b = 0, a = 0;
      for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) { const p = (yy * w + xx) * 4; r += src[p]; g += src[p + 1]; b += src[p + 2]; a += src[p + 3]; }
      const n = (y1 - y0) * (x1 - x0), q = (y * tw + x) * 4;
      out[q] = Math.round(r / n); out[q + 1] = Math.round(g / n); out[q + 2] = Math.round(b / n); out[q + 3] = Math.round(a / n);
    }
  }
  return out;
}

/** Trộn kênh trong suốt lên nền trắng (JPEG không có alpha: vùng trong suốt sẽ thành đen). */
export function flattenOnWhite(d: Uint8Array): Uint8Array {
  for (let p = 3; p < d.length; p += 4) {
    const a = d[p];
    if (a === 255) continue;
    const k = 255 - a;
    d[p - 3] = Math.round((d[p - 3] * a + 255 * k) / 255); d[p - 2] = Math.round((d[p - 2] * a + 255 * k) / 255); d[p - 1] = Math.round((d[p - 1] * a + 255 * k) / 255); d[p] = 255;
  }
  return d;
}

/** Cỡ đích sau khi kẹp cạnh dài và diện tích. */
export function fitSize(w: number, h: number, maxSide = MAX_SIDE, maxArea = MAX_AREA): [number, number] {
  const s = Math.min(1, maxSide / Math.max(w, h), Math.sqrt(maxArea / (w * h)));
  return s >= 1 ? [w, h] : [Math.max(1, Math.round(w * s)), Math.max(1, Math.round(h * s))];
}

/** Giải mọi trang của tệp TIFF thành RGBA. `total` = số trang trong tệp (có thể > số trang trả về). */
export function decodeTiffPages(buf: ArrayBuffer, o: TiffOpts = {}): { pages: TiffPage[]; total: number } {
  if (!isTiffBytes(new Uint8Array(buf, 0, Math.min(4, buf.byteLength)))) throw new Error("Không phải tệp TIFF");
  if (!TIFF_PAKO) throw new Error("Thiếu bộ giải nén"); // giữ import tiff-pako (chạy trước utif2) trong gói build
  const ifds = UTIF.decode(buf).filter((ifd) => {
    const sub = ifd["t254"] as number[] | undefined; // NewSubfileType: bit 0 = ảnh thu nhỏ
    return !(sub && sub[0] & 1) && ifd["t256"] && ifd["t257"];
  });
  if (!ifds.length) throw new Error("Tệp TIFF không có trang ảnh");
  const pages: TiffPage[] = [];
  for (const ifd of ifds.slice(0, o.maxPages ?? TIFF_MAX_PAGES)) {
    (UTIF.decodeImage as (b: ArrayBuffer, img: UTIF.IFD, all: UTIF.IFD[]) => void)(buf, ifd, ifds); // ifds: bảng JPEG dùng chung (typings thiếu tham số 3)
    const w = ifd.width, h = ifd.height;
    if (!w || !h) continue;
    let data: Uint8Array = flattenOnWhite(UTIF.toRGBA8(ifd));
    const [tw, th] = fitSize(w, h, o.maxSide, o.maxArea);
    if (tw !== w || th !== h) data = downscaleRgba(data, w, h, tw, th);
    (ifd as { data?: unknown }).data = undefined; // nhả bộ đệm giải nén của trang trước khi sang trang kế
    pages.push({ width: tw, height: th, data });
  }
  if (!pages.length) throw new Error("Tệp TIFF không có trang ảnh");
  return { pages, total: ifds.length };
}
