/// <reference lib="webworker" />
/** CS-11: giải TIFF ngoài luồng chính; trả JPEG (OffscreenCanvas) hoặc RGBA để luồng chính tự mã hoá. */
import { decodeTiffPages } from "./tiff-decode";

type Out = { width: number; height: number; blob?: Blob; rgba?: ArrayBuffer };
self.onmessage = async (e: MessageEvent<{ id: number; buf: ArrayBuffer }>) => {
  const { id, buf } = e.data;
  try {
    const { pages, total } = decodeTiffPages(buf);
    const out: Out[] = [];
    const transfer: Transferable[] = [];
    for (const p of pages) {
      if (typeof OffscreenCanvas !== "undefined") {
        const c = new OffscreenCanvas(p.width, p.height);
        const ctx = c.getContext("2d");
        if (ctx) {
          ctx.putImageData(new ImageData(new Uint8ClampedArray(p.data.buffer as ArrayBuffer, p.data.byteOffset, p.data.byteLength), p.width, p.height), 0, 0);
          out.push({ width: p.width, height: p.height, blob: await c.convertToBlob({ type: "image/jpeg", quality: 0.95 }) });
          continue;
        }
      }
      const rgba = p.data.byteOffset === 0 && p.data.byteLength === p.data.buffer.byteLength ? (p.data.buffer as ArrayBuffer) : p.data.slice().buffer;
      out.push({ width: p.width, height: p.height, rgba });
      transfer.push(rgba);
    }
    (self as unknown as Worker).postMessage({ id, pages: out, total }, transfer);
  } catch (err) {
    (self as unknown as Worker).postMessage({ id, error: err instanceof Error ? err.message : String(err) });
  }
};
