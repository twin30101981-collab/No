import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import UTIF from "utif2";
import { decodeTiffPages, downscaleRgba, fitSize, flattenOnWhite, isTiffBytes } from "./tiff-decode";
import { barsQuad, detectSystemBars } from "./screenshot-bars";
import { isImageFile, isTiffFile, IMAGE_ACCEPT } from "./image-input";

function tiff(w: number, h: number, px: (x: number, y: number) => [number, number, number, number]): ArrayBuffer {
  const d = new Uint8Array(w * h * 4);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) d.set(px(x, y), (y * w + x) * 4);
  return UTIF.encodeImage(d, w, h);
}

describe("CS-11 TIFF", () => {
  it("nhận đầu tệp II*/MM* (cả BigTIFF), không nhận PNG/JPEG", () => {
    expect(isTiffBytes(new Uint8Array([0x49, 0x49, 42, 0]))).toBe(true);
    expect(isTiffBytes(new Uint8Array([0x4d, 0x4d, 0, 42]))).toBe(true);
    expect(isTiffBytes(new Uint8Array([0x49, 0x49, 43, 0]))).toBe(true);
    expect(isTiffBytes(new Uint8Array([0x89, 0x50, 0x4e, 0x47]))).toBe(false);
    expect(isTiffBytes(new Uint8Array([0xff, 0xd8, 0xff]))).toBe(false);
  });
  it("giải đúng điểm ảnh, trong suốt trộn lên nền trắng", () => {
    const buf = tiff(20, 10, (x) => (x < 10 ? [200, 10, 10, 255] : [0, 0, 0, 0]));
    const { pages, total } = decodeTiffPages(buf);
    expect(total).toBe(1);
    expect([pages[0].width, pages[0].height]).toEqual([20, 10]);
    expect(Array.from(pages[0].data.slice(0, 4))).toEqual([200, 10, 10, 255]);
    expect(Array.from(pages[0].data.slice(15 * 4, 15 * 4 + 4))).toEqual([255, 255, 255, 255]); // không thành đen
  });
  it("trang quá lớn thu nhỏ theo cạnh dài/diện tích", () => {
    expect(fitSize(6000, 8000)).toEqual([3072, 4096]);
    expect(fitSize(1000, 1000)).toEqual([1000, 1000]);
    const [w, h] = fitSize(5000, 5000); expect(w * h).toBeLessThanOrEqual(16_000_000);
    const buf = tiff(40, 20, () => [50, 100, 150, 255]);
    const p = decodeTiffPages(buf, { maxSide: 10 }).pages[0];
    expect([p.width, p.height]).toEqual([10, 5]);
    expect(Array.from(p.data.slice(0, 4))).toEqual([50, 100, 150, 255]);
  });
  it("thu nhỏ hộp lấy trung bình; trộn alpha nửa trong suốt", () => {
    const src = new Uint8Array([0, 0, 0, 255, 255, 255, 255, 255]);
    expect(Array.from(downscaleRgba(src, 2, 1, 1, 1))).toEqual([128, 128, 128, 255]);
    expect(Array.from(flattenOnWhite(new Uint8Array([0, 0, 0, 128])))).toEqual([127, 127, 127, 255]);
  });
  it("tệp hỏng/không phải TIFF → ném lỗi (không trả trang đen)", () => {
    expect(() => decodeTiffPages(new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0, 0]).buffer)).toThrow();
    const good = new Uint8Array(tiff(8, 8, () => [0, 0, 0, 255]));
    expect(() => decodeTiffPages(good.slice(0, 12).buffer)).toThrow();
  });
  it("gói build: pako gán toàn cục trước utif2, import có dùng giá trị (sideEffects: false không bỏ được)", () => {
    const src = readFileSync("src/lib/tiff-decode.ts", "utf8");
    expect(src.indexOf('from "./tiff-pako"')).toBeGreaterThan(-1);
    expect(src.indexOf('from "./tiff-pako"')).toBeLessThan(src.indexOf('from "utif2"'));
    expect(src).toMatch(/import \{ TIFF_PAKO \} from "\.\/tiff-pako"/);
    expect(src).toMatch(/if \(!TIFF_PAKO\)/);
  });
  it("nhận tệp .tif/.tiff, kiểu image/tiff và TIFF mang đuôi khác (đọc 4 byte đầu)", async () => {
    expect(isImageFile(new File([], "fax.TIF"))).toBe(true);
    expect(IMAGE_ACCEPT).toContain(".tiff");
    expect(await isTiffFile(new File([], "a.tiff"))).toBe(true);
    expect(await isTiffFile(new File([new Uint8Array([0, 0])], "a.png", { type: "image/tiff" }))).toBe(true);
    expect(await isTiffFile(new File([new Uint8Array(tiff(4, 4, () => [0, 0, 0, 255]))], "anh.png", { type: "image/png" }))).toBe(true);
    expect(await isTiffFile(new File([new Uint8Array([0xff, 0xd8, 0xff, 0xe0])], "anh.jpg", { type: "image/jpeg" }))).toBe(false);
  });
});

// Ảnh chụp màn hình tổng hợp rộng 360: nền + các hình chữ nhật đặc (nét chữ/biểu tượng)
function shot(h: number, bg: number, fg: number, rects: [number, number, number, number][]) {
  const w = 360, d = new Uint8ClampedArray(w * h * 4).fill(bg);
  for (let p = 3; p < d.length; p += 4) d[p] = 255;
  for (const [x0, y0, x1, y1] of rects) for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) { const p = (y * w + x) * 4; d[p] = d[p + 1] = d[p + 2] = fg; }
  return { d, w, h };
}
const glyphs = (x0: number, x1: number, y0: number, y1: number): [number, number, number, number][] => {
  const r: [number, number, number, number][] = [];
  for (let x = x0; x < x1; x += 7) r.push([x, y0, Math.min(x + 4, x1), y1]);
  return r;
};
const text = (y: number) => glyphs(20, 340, y, y + 8); // dòng chữ nội dung trải ngang

describe("CS-11 thanh hệ thống của ảnh chụp màn hình", () => {
  it("điện thoại: giờ trái + pin phải ở trên, vạch home dưới → cắt cả hai, chừa nội dung", () => {
    const content = [80, 100, 120, 140, 700].flatMap(text);
    const s = shot(780, 255, 0, [...glyphs(25, 70, 14, 26), ...glyphs(300, 340, 15, 25), [120, 766, 240, 770], ...content]);
    const b = detectSystemBars(s.d, s.w, s.h);
    expect(b.top * s.h).toBeGreaterThan(26);
    expect(b.top * s.h).toBeLessThan(80); // không ăn vào dòng nội dung đầu
    expect(b.bottom * s.h).toBeGreaterThan(780 - 766);
    expect((1 - b.bottom) * s.h).toBeGreaterThan(708);
    expect(barsQuad(b)![0][1]).toBeCloseTo(b.top, 3);
  });
  it("nền tối, 3 nút điều hướng", () => {
    const s = shot(800, 18, 230, [...glyphs(20, 60, 8, 20), ...glyphs(310, 345, 9, 19), ...[100, 120, 400].flatMap(text), [80, 765, 100, 785], [170, 765, 190, 785], [260, 765, 280, 785]]);
    const b = detectSystemBars(s.d, s.w, s.h);
    expect(b.top).toBeGreaterThan(0);
    expect(b.bottom * s.h).toBeGreaterThan(800 - 765);
  });
  it("không cắt: chữ giữa mép trên, ảnh ngang, tiêu đề công văn hai khối rộng, chữ chân trang", () => {
    const mid = shot(780, 255, 0, [...glyphs(25, 70, 14, 26), ...glyphs(150, 210, 14, 26), ...glyphs(300, 340, 15, 25), ...text(80)]);
    expect(detectSystemBars(mid.d, mid.w, mid.h).top).toBe(0);
    const land = shot(200, 255, 0, [...glyphs(25, 70, 4, 10), ...glyphs(300, 340, 4, 10)]);
    expect(detectSystemBars(land.d, land.w, land.h)).toEqual({ top: 0, bottom: 0 });
    const cv = shot(510, 255, 0, [...glyphs(20, 130, 10, 18), ...glyphs(165, 340, 10, 18), ...text(60)]);
    expect(detectSystemBars(cv.d, cv.w, cv.h, true).top).toBe(0);
    const foot = shot(510, 255, 0, [...text(60), ...glyphs(150, 215, 495, 499)]); // "Trang 1/3" mảnh giữa đáy
    expect(detectSystemBars(foot.d, foot.w, foot.h, true).bottom).toBe(0);
  });
  it("chế độ chặt (ảnh flat): nét trên bắt đầu muộn (lề trang quét) → không cắt", () => {
    const s = shot(780, 255, 0, [...glyphs(25, 70, 30, 42), ...glyphs(300, 340, 31, 41), ...text(100)]);
    expect(detectSystemBars(s.d, s.w, s.h, false).top).toBeGreaterThan(0);
    expect(detectSystemBars(s.d, s.w, s.h, true).top).toBe(0);
  });
});
