/**
 * TF-03 — Lưu thẳng vào thư mục trên máy (File System Access API: Chrome/Edge PC, Android Chrome mới).
 * Thư mục mặc định được nhớ: FileSystemDirectoryHandle lưu trong một IndexedDB riêng nhỏ ("gn-save-folder")
 * — KHÔNG đụng schema IndexedDB chính. Lần sau chỉ cần xin lại quyền (1 chạm), không phải chọn lại.
 * Trình duyệt không hỗ trợ (Safari/Firefox, iOS) → supported() = false, giao diện ẩn mục này.
 */
type DirHandle = FileSystemDirectoryHandle & {
  queryPermission?: (d: { mode: "readwrite" }) => Promise<PermissionState>;
  requestPermission?: (d: { mode: "readwrite" }) => Promise<PermissionState>;
};
type Picker = (o?: { mode?: "readwrite"; id?: string; startIn?: string }) => Promise<DirHandle>;

const DB = "gn-save-folder", STORE = "h", KEY = "default";
const picker = (): Picker | undefined => (typeof window === "undefined" ? undefined : (window as unknown as { showDirectoryPicker?: Picker }).showDirectoryPicker);
export const folderSupported = () => typeof picker() === "function";

function idb<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return new Promise((ok, fail) => {
    const o = indexedDB.open(DB, 1);
    o.onupgradeneeded = () => { o.result.createObjectStore(STORE); };
    o.onerror = () => fail(o.error);
    o.onsuccess = () => {
      const r = fn(o.result.transaction(STORE, mode).objectStore(STORE));
      r.onsuccess = () => { o.result.close(); ok(r.result); };
      r.onerror = () => { o.result.close(); fail(r.error); };
    };
  });
}

/** Thư mục mặc định đã nhớ (null nếu chưa chọn / không đọc được). Không xin quyền. */
export async function savedFolder(): Promise<DirHandle | null> {
  try { return ((await idb<DirHandle | undefined>("readonly", (s) => s.get(KEY))) ?? null); } catch { return null; }
}
export async function forgetFolder(): Promise<void> { try { await idb("readwrite", (s) => s.delete(KEY)); } catch { /* bỏ qua */ } }

/** Mở hộp chọn thư mục của hệ điều hành (PHẢI gọi từ thao tác chạm) và nhớ làm mặc định. null = người dùng huỷ. */
export async function pickFolder(): Promise<DirHandle | null> {
  const p = picker();
  if (!p) throw new Error("Trình duyệt này chưa cho lưu thẳng vào thư mục. Hãy dùng Chrome hoặc Edge trên máy tính.");
  try {
    const h = await p({ mode: "readwrite", id: "ghi-nhanh", startIn: "documents" });
    try { await idb("readwrite", (s) => s.put(h, KEY)); } catch { /* không nhớ được: vẫn dùng cho lần này */ }
    return h;
  } catch (e) {
    if ((e as { name?: string } | null)?.name === "AbortError") return null;
    throw e;
  }
}

/** Đảm bảo có quyền ghi (xin lại nếu hết; cần thao tác chạm). false = bị từ chối. */
export async function ensureWritable(h: DirHandle): Promise<boolean> {
  try {
    if (!h.queryPermission) return true;
    if ((await h.queryPermission({ mode: "readwrite" })) === "granted") return true;
    return (await h.requestPermission?.({ mode: "readwrite" })) === "granted";
  } catch { return false; }
}

/** Thư mục để lưu: mặc định đã nhớ (có quyền) hoặc hỏi chọn lần đầu. null = huỷ/từ chối quyền. */
export async function folderForSave(opts: { change?: boolean } = {}): Promise<DirHandle | null> {
  if (!opts.change) {
    const h = await savedFolder();
    if (h && (await ensureWritable(h))) return h;
  }
  const h = await pickFolder();
  return h && (await ensureWritable(h)) ? h : null;
}

/** Tên chưa dùng trong thư mục: "a.pdf" → "a (2).pdf" → "a (3).pdf" (không ghi đè tệp có sẵn). */
export async function freeName(dir: FileSystemDirectoryHandle, name: string): Promise<string> {
  const dot = name.lastIndexOf("."), base = dot > 0 ? name.slice(0, dot) : name, ext = dot > 0 ? name.slice(dot) : "";
  for (let k = 1; k < 1000; k++) {
    const n = k === 1 ? name : `${base} (${k})${ext}`;
    try { await dir.getFileHandle(n); } catch (e) { if ((e as { name?: string } | null)?.name === "NotFoundError") return n; throw e; }
  }
  return `${base}-${Date.now()}${ext}`;
}

/** Ghi một tệp; trả tên đã dùng. */
export async function writeToFolder(dir: FileSystemDirectoryHandle, blob: Blob, name: string): Promise<string> {
  const n = await freeName(dir, name);
  const w = await (await dir.getFileHandle(n, { create: true })).createWritable();
  try { await w.write(blob); } catch (e) { await w.abort().catch(() => {}); throw e; }
  await w.close();
  return n;
}

export function folderError(e: unknown): string {
  const n = (e as { name?: string } | null)?.name;
  if (n === "NotAllowedError" || n === "SecurityError") return "Không có quyền ghi vào thư mục này. Hãy chọn lại thư mục.";
  if (n === "QuotaExceededError") return "Ổ đĩa đầy — chưa lưu được vào thư mục.";
  if (n === "NotFoundError" || n === "InvalidStateError") return "Thư mục đã bị xoá hoặc di chuyển. Hãy chọn lại thư mục.";
  return "Không lưu được vào thư mục. Hãy chọn lại thư mục rồi thử lại.";
}
