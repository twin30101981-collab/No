import type { Doc } from "./db";
import { readyDocs } from "./pipeline/ready"; // CS-04: không xuất trang còn là bản nháp
import { loadImg } from "./image";
import { canvasToBlob, canvasToPageUrl } from "./canvas-url";
import { fillMarkText, hasMarks, markMargins, pageNumberText, type PageMarks } from "./pdf-marks";

/** BL-08 (RS-17): mật khẩu chủ PDF ngẫu nhiên 128 bit (trước: mật khẩu mở + "#owner" → ai biết mật khẩu mở đều gỡ được giới hạn quyền). */
export function randomOwnerPassword(): string {
  return Array.from(crypto.getRandomValues(new Uint8Array(16)), (b) => b.toString(16).padStart(2, "0")).join("");
}

/** CS-20: nguồn dựng lại của một trang (ảnh gốc + tham số) — xuất PDF dựng thẳng ở cỡ mức xuất, nén JPEG một lần. */
export type PageSource = { orig: string; edit: import("./db").PageEdit };
export type ExportOptions = { /** CS-20 (QD-10): mặc định "fit" = khổ khớp ảnh, lề 0. */ paper?: import("./pdf-page").PdfPaper | undefined; sources?: (PageSource | undefined)[] | undefined; /** CS-21: loại từng trang (thiếu = màu) */ kinds?: (PageKind | undefined)[] | undefined; watermark?: string | undefined; password?: string | undefined; searchable?: boolean | undefined; size?: PdfSize | undefined; bw?: boolean | undefined; marks?: PageMarks | undefined; name?: string | undefined; lanes?: number | undefined; signal?: AbortSignal | undefined };

/** B15: nhường luồng giao diện giữa các trang PDF để màn hình không treo (scheduler.yield, dự phòng setTimeout 0). */
export function yieldUi(): Promise<void> {
  const s = (globalThis as { scheduler?: { yield?: () => Promise<void> } }).scheduler;
  return s?.yield ? s.yield() : new Promise((r) => setTimeout(r, 0));
}

/** B15: ném lỗi hủy khi người dùng bấm Hủy giữa chừng. */
export function throwIfAborted(signal?: AbortSignal) {
  if (signal?.aborted) throw new DOMException("Đã hủy xuất PDF", "AbortError");
}

export function download(blob: Blob, name: string) {
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
export async function dataUrlToBlob(src: string) { return (await fetch(src)).blob(); }
export const safeName = (s: string) => s.replace(/[\\/:*?"<>|]+/g, "-").trim() || "ghi-nhanh";

/** Chia sẻ qua bảng chia sẻ của máy (Zalo, Messenger, thư…); không được thì lưu về máy và BÁO RÕ (TF-01). */
export async function shareOrDownload(blob: Blob, name: string): Promise<"shared" | "cancelled" | "downloaded" | "needs-tap"> {
  const { shareOrSave } = await import("./share");
  return shareOrSave(blob, name, download);
}

// R5.1: PDF đúng 3 mức Nhỏ / Chuẩn / Cao (mặc định Chuẩn).
export type PdfSize = "high" | "balanced" | "small";
// CS-21 (bảng 11.3): Chuẩn JPEG q0,82; trang Đen trắng 1-bit ở bwDpi (Nhỏ 200 dpi — 150 dpi làm đứt nét chữ mảnh, Chuẩn/Cao 300 dpi).
export const PDF_SIZES: Record<PdfSize, { label: string; maxSide: number; q: number; bwDpi: number }> = {
  small: { label: "Nhỏ", maxSide: 1754, q: 0.75, bwDpi: 200 },
  balanced: { label: "Chuẩn", maxSide: 2339, q: 0.82, bwDpi: 300 },
  high: { label: "Cao", maxSide: 3508, q: 0.9, bwDpi: 300 },
};
/** CS-21: loại trang khi xuất — theo bộ lọc của trang (Đen trắng → 1-bit, Xám → xám 1 kênh, còn lại màu). */
export type PageKind = "bw" | "gray" | "color";
export const pageKindOf = (filter: string | undefined): PageKind => (filter === "mono" ? "bw" : filter === "gray" ? "gray" : "color");

/** B1: chỉ nén lại khi cần thu nhỏ hoặc đổi định dạng – ảnh JPEG đã đúng cỡ đi thẳng vào PDF (tránh nén chồng). */
export function needsReencode(w: number, h: number, size: PdfSize, bw: boolean, isJpeg: boolean) {
  if (bw || !isJpeg) return true;
  return Math.max(w, h) > PDF_SIZES[size].maxSide;
}

/** Downscale + re-encode a page; bw = adaptive black & white (great for text, tiny files). */
export async function compressPage(src: string, size: PdfSize, bw = false, crop = true): Promise<import("./compress-pool").CompressedPage> {
  const { maxSide, q } = PDF_SIZES[size];
  // S7e: ưu tiên Worker (OffscreenCanvas); lỗi/không hỗ trợ → chạy trên luồng chính như cũ.
  const { compressInWorker } = await import("./compress-pool");
  const wp = compressInWorker(src, maxSide, q, bw, src.startsWith("data:image/jpeg"), crop);
  if (wp) { try { return await wp; } catch { /* rơi về luồng chính */ } }
  // CS-20: trang khớp ảnh, JPEG đúng cỡ (cả object URL) → nguyên byte vào PDF, không nén lại
  if (!crop && !bw) {
    const blob = await (await fetch(src)).blob();
    const { imageSize } = await import("./pdf-page");
    const head = blob.type === "image/jpeg" || src.startsWith("data:image/jpeg") ? imageSize(new Uint8Array(await blob.slice(0, 65536).arrayBuffer())) : null;
    if (head && head.fmt === "JPEG" && !head.exif && Math.max(head.w, head.h) <= maxSide) {
      const { fileToDataUrl } = await import("./image");
      return { src: src.startsWith("data:") ? src : await fileToDataUrl(blob), w: head.w, h: head.h, fmt: "JPEG" as const, ox: 0, oy: 0, scale: 1 };
    }
  }
  const img = await loadImg(src);
  const s = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
  const W = Math.round(img.naturalWidth * s), H = Math.round(img.naturalHeight * s);
  const c = document.createElement("canvas"); c.width = W; c.height = H;
  const x = c.getContext("2d")!; x.imageSmoothingEnabled = true; x.imageSmoothingQuality = "high"; x.fillStyle = "#fff"; x.fillRect(0, 0, W, H); x.drawImage(img, 0, 0, W, H);
  const d = x.getImageData(0, 0, W, H), p = d.data;
  const lum = new Uint8Array(W * H);
  for (let i = 0; i < W * H; i++) lum[i] = (p[i * 4] * 299 + p[i * 4 + 1] * 587 + p[i * 4 + 2] * 114) / 1000;
  // B8: cắt theo nội dung + lề đều (bỏ dải nền xám còn sót ở mép). Chỉ cắt khi hộp còn ≥ 25 % diện tích.
  const { contentBox, encodePng1bit, bytesToDataUrl } = await import("./content-crop");
  let box = crop ? contentBox(lum, W, H) : { x: 0, y: 0, w: W, h: H };
  if (box.w * box.h < W * H * 0.25) box = { x: 0, y: 0, w: W, h: H };
  // B1: JPEG đúng cỡ, không cần cắt → đi thẳng vào PDF (tránh nén chồng).
  const map = { ox: box.x, oy: box.y, scale: s }; // BL-06: để lớp chữ OCR (chạy trên ảnh nguồn) khớp ảnh đã nén
  if (box.w === W && box.h === H && src.startsWith("data:") && !needsReencode(img.naturalWidth, img.naturalHeight, size, bw, src.startsWith("data:image/jpeg"))) { c.width = 0; return { src, w: W, h: H, fmt: "JPEG", ...map }; }
  if (bw) {
    const g = new Float64Array((W + 1) * (H + 1));
    for (let y = 0; y < H; y++) { let row = 0; for (let xx = 0; xx < W; xx++) { row += lum[y * W + xx]; g[(y + 1) * (W + 1) + xx + 1] = g[y * (W + 1) + xx + 1] + row; } }
    const r = Math.max(8, Math.round(Math.min(W, H) / 40));
    const bin = new Uint8Array(box.w * box.h);
    for (let y = box.y; y < box.y + box.h; y++) for (let xx = box.x; xx < box.x + box.w; xx++) {
      const x0 = Math.max(0, xx - r), x1 = Math.min(W, xx + r + 1), y0 = Math.max(0, y - r), y1 = Math.min(H, y + r + 1);
      const mean = (g[y1 * (W + 1) + x1] - g[y0 * (W + 1) + x1] - g[y1 * (W + 1) + x0] + g[y0 * (W + 1) + x0]) / ((x1 - x0) * (y1 - y0));
      bin[(y - box.y) * box.w + xx - box.x] = lum[y * W + xx] < mean * 0.88 ? 0 : 255;
    }
    c.width = 0;
    // B8: PNG 1-bit (thay PNG RGBA 8-bit) → PDF Đen trắng nhẹ hơn nhiều.
    return { src: bytesToDataUrl(encodePng1bit(bin, box.w, box.h)), w: box.w, h: box.h, fmt: "PNG", ...map };
  }
  let out: string;
  if (box.w !== W || box.h !== H) {
    const cc = document.createElement("canvas"); cc.width = box.w; cc.height = box.h;
    cc.getContext("2d")!.drawImage(c, box.x, box.y, box.w, box.h, 0, 0, box.w, box.h);
    out = cc.toDataURL("image/jpeg", q); cc.width = 0;
  } else out = c.toDataURL("image/jpeg", q);
  c.width = 0; return { src: out, w: box.w, h: box.h, fmt: "JPEG", ...map };
}

/** Chất lượng JPEG ảnh trang đã dựng (render-core / renderPage). */
const PAGE_Q = 0.92;
/** CS-21: số trang xuất được dựng lại từ ảnh gốc (re), thử lệch cỡ (miss), lỗi (err) — kiểm chứng "nén một lần". */
export const exportStats = { re: 0, miss: 0, err: 0 };
if (typeof globalThis !== "undefined") (globalThis as { __cs21?: typeof exportStats }).__cs21 = exportStats;
const headOf = async (src: string) => { const { imageSize } = await import("./pdf-page"); return imageSize(new Uint8Array(await (await (await fetch(src)).blob()).slice(0, 65536).arrayBuffer())); };
/**
 * CS-20/21 (QP-04): nén MỘT lần. Ảnh trang đã lưu là JPEG q0,92 → dựng lại từ ảnh gốc + tham số ở ĐÚNG cỡ ảnh trang (cùng chuỗi dựng
 * nên cùng điểm ảnh), nén với chất lượng `q` (= mức xuất, hoặc 1 = gần không mất mát cho bước xám / 4:4:4 phía sau).
 * KHÔNG dựng thẳng ở cỡ nhỏ hơn ảnh trang (đo P33: mất nét dấu "năm" → "nàm"). Không dựng lại được → ảnh trang.
 */
async function fromOrig(src: string, so: PageSource | undefined, q: number): Promise<string> {
  if (!so || !so.orig || so.orig === src || src === "=") return src;
  const head = await headOf(src);
  if (!head || head.fmt !== "JPEG") return src;
  try {
    const { renderExport, TARGET_LONG, targetLong } = await import("./image");
    const { getSettings } = await import("./settings");
    // cạnh dài đích lúc dựng ảnh trang = mức chất lượng trong cài đặt (CS-16: thực tế = min(mức, giấy thật)); khác cỡ → thử mức kia, rồi đúng cạnh ảnh
    for (const max of [...new Set([targetLong(getSettings().quality), TARGET_LONG.high, TARGET_LONG.normal, Math.max(head.w, head.h)])]) {
      const out = await renderExport(so.orig, so.edit, max, q);
      const re = await headOf(out);
      if (re && re.w === head.w && re.h === head.h) { exportStats.re++; return out; }
      exportStats.miss++;
    }
    return src; // khác cỡ (tham số đổi sau khi dựng) → giữ ảnh trang
  } catch (e) { exportStats.err++; console.warn("export re-render skipped", e); return src; }
}

/** CS-20/21: một trang PDF theo loại trang + mức xuất. */
async function exportPage(s: string, so: PageSource | undefined, kind: PageKind, size: PdfSize, fit: boolean, adaptive: boolean): Promise<import("./compress-pool").CompressedPage> {
  const { maxSide, q, bwDpi } = PDF_SIZES[size];
  const pool = await import("./compress-pool");
  const head = await headOf(s).catch(() => null);
  const long = head ? Math.max(head.w, head.h) : 0;
  if (kind === "bw" && head) {
    // 1-bit ở bwDpi theo khổ giấy thật của trang (ảnh 160–200 dpi được phóng mượt trước khi nhị phân → mép chữ trơn)
    const { fitFormat } = await import("./pdf-page");
    const k = Math.min(2.5, Math.max(0.5, bwDpi / fitFormat(head.w, head.h).dpi));
    const wp = pool.pdfPageInWorker(s, "bw", q, maxSide, k, adaptive);
    if (wp) { try { return await wp; } catch { /* rơi về PNG 1-bit cũ */ } }
    return compressPage(s, size, true, !fit);
  }
  if (kind === "gray" && head) {
    const wp = pool.pdfPageInWorker(long <= maxSide ? await fromOrig(s, so, 1) : s, "gray", q, maxSide);
    if (wp) { try { return await wp; } catch { /* rơi về JPEG màu */ } }
  }
  if (kind === "color" && fit && head && q >= PAGE_Q - 0.02) {
    // Cao: trang có mực màu (dấu đỏ, chữ ký xanh) → JPEG 4:4:4 (canvas chỉ cho 4:2:0 → mép dấu đỏ lem); không có → nguyên ảnh trang
    const ink = await (pool.inkShareInWorker(s) ?? Promise.resolve(0)).catch(() => 0);
    if (ink > 0.002) {
      const wp = pool.pdfPageInWorker(await fromOrig(s, so, 1), "c444", q, maxSide);
      if (wp) { try { return await wp; } catch { /* rơi về đường thường */ } }
    }
    return compressPage(s, size, false, false);
  }
  // cùng cỡ → dựng lại, nén một lần (+1,2 dB); phải thu nhỏ (Nhỏ) → thu nhỏ ảnh trang (nén lại chỉ kém ~0,3 dB, khỏi tốn ~1 s/trang dựng lại)
  if (fit && head && q < PAGE_Q - 0.02) return compressPage(long <= maxSide ? await fromOrig(s, so, q) : s, size, false, false);
  return compressPage(s, size, kind === "bw", !fit);
}

/** CS-21: định dạng ảnh "G4" cho jsPDF — gói packG4 (g4.ts) → luồng CCITTFaxDecode K = −1, DeviceGray 1 bit. */
let g4Ready = false;
function registerG4(api: Record<string, unknown>) {
  if (g4Ready) return; g4Ready = true;
  api["processG4"] = function (this: { __addimage__: { arrayBufferToBinaryString: (b: Uint8Array) => string } }, data: Uint8Array, index: number, alias: string) {
    const v = new DataView(data.buffer, data.byteOffset, data.byteLength), w = v.getUint32(4), h = v.getUint32(8);
    return { data: this.__addimage__.arrayBufferToBinaryString(data.subarray(12)), width: w, height: h, colorSpace: "DeviceGray", bitsPerComponent: 1,
      filter: "CCITTFaxDecode", decodeParameters: `/K -1 /Columns ${w} /Rows ${h} /BlackIs1 false`, index, alias };
  };
}

export async function imagesToPdf(srcs: string[], opts: ExportOptions = {}) {
  const { jsPDF } = await import("jspdf");
  const { fitFormat, pdfProperties } = await import("./pdf-page");
  const paper = opts.paper ?? "fit", fit = paper === "fit", size = opts.size ?? "balanced", bw = !!opts.bw;
  const enc = opts.password ? { encryption: { userPassword: opts.password, ownerPassword: randomOwnerPassword() /* BL-08 (RS-17): không suy ra được từ mật khẩu mở */, userPermissions: ["print", "copy"] as ("print" | "copy")[] } } : {};
  let pdf: InstanceType<typeof jsPDF> | null = null;
  const m = fit ? 0 : 6;
  const marks = opts.marks ?? {}, mm = markMargins(marks), date = new Date();
  const dpis: number[] = [];
  // S7c: dựng ảnh trang song song (tối đa pdfLanes() trang), ghép vào PDF đúng thứ tự.
  const { orderedPool, pdfLanes } = await import("./ordered-pool");
  let i = -1;
  registerG4(jsPDF.API as unknown as Record<string, unknown>);
  // CS-20/21: nén một lần theo loại trang (1-bit G4 / xám 1 kênh / màu), khớp ảnh không cắt theo nội dung (lề 0)
  const build = (s: string, k: number) => { const kind = opts.kinds?.[k] ?? "color"; return exportPage(s, opts.sources?.[k], bw ? "bw" : kind, size, fit, kind !== "bw"); }; // trang lọc Đen trắng đã nhị phân → không Sauvola
  for await (const page of orderedPool(srcs, opts.lanes ?? pdfLanes(), build)) {
    throwIfAborted(opts.signal);
    i++;
    let PW: number, PH: number, x: number, y: number, w: number, h: number, r: number;
    if (fit) {
      const f = fitFormat(page.w, page.h);
      PW = f.wMm; PH = f.hMm + mm.top + mm.bottom; w = f.wMm; h = f.hMm; x = 0; y = mm.top; r = f.wMm / page.w;
      const fmt: [number, number] = [PW, PH], orient = PW > PH ? "l" : "p";
      if (!pdf) pdf = new jsPDF({ unit: "mm", format: fmt, orientation: orient, compress: true, ...enc });
      else pdf.addPage(fmt, orient);
    } else {
      if (!pdf) pdf = new jsPDF({ unit: "mm", format: paper, compress: true, ...enc }); else pdf.addPage(paper);
      PW = pdf.internal.pageSize.getWidth(); PH = pdf.internal.pageSize.getHeight();
      const aw = PW - m * 2, ah = PH - m * 2 - mm.top - mm.bottom;
      r = Math.min(aw / page.w, ah / page.h);
      w = page.w * r; h = page.h * r; x = (PW - w) / 2; y = m + mm.top + (ah - h) / 2;
    }
    dpis.push(Math.round(25.4 / r));
    if (i === 0 && hasMarks(marks) && !pdf.getFontList()["DejaVu"]) { pdf.addFileToVFS("DejaVuSans.ttf", await loadFont()); pdf.addFont("DejaVuSans.ttf", "DejaVu", "normal", undefined, "Identity-H"); }
    if (page.fmt === "G4" && page.data) pdf.addImage(page.data, "G4" as never, x, y, w, h, undefined, "NONE");
    else pdf.addImage(page.src, page.fmt as "JPEG" | "PNG", x, y, w, h, undefined, "FAST");
    if (opts.searchable) await addTextLayer(pdf, srcs[i], x, y, r, { ox: page.ox ?? 0, oy: page.oy ?? 0, scale: page.scale ?? 1, w: page.w, h: page.h }); // BL-06: bù thu nhỏ + cắt lề
    if (opts.watermark) {
      pdf.saveGraphicsState();
      pdf.setGState(new (pdf as unknown as { GState: new (o: object) => unknown }).GState({ opacity: 0.18 }) as never);
      pdf.setTextColor(0, 140, 120); pdf.setFontSize(46 * Math.min(1, PW / 180)); // trang khớp ảnh nhỏ (thẻ) → chữ hình mờ co theo
      pdf.text(opts.watermark, PW / 2, PH / 2, { align: "center", angle: 35 });
      pdf.restoreGraphicsState();
    }
    if (hasMarks(marks)) {
      const mk = Math.max(m, 2); // khớp ảnh: dải đầu/chân trang nằm trong lề dấu trang (mm.top/bottom), cách mép 2 mm
      pdf.setFont("DejaVu", "normal"); pdf.setFontSize(9); pdf.setTextColor(90, 90, 90);
      const name = opts.name ?? "";
      if (marks.header?.trim()) pdf.text(fillMarkText(marks.header, i + 1, srcs.length, name, date), PW / 2, mk + 4, { align: "center", maxWidth: PW - mk * 2 });
      const foot = marks.footer?.trim() ? fillMarkText(marks.footer, i + 1, srcs.length, name, date) : "";
      const num = marks.numbers ? pageNumberText(marks.numberStyle, i + 1, srcs.length) : "";
      if (foot) pdf.text(foot, num ? mk + 2 : PW / 2, PH - mk - 1, { align: num ? "left" : "center", maxWidth: PW - mk * 2 - (num ? 30 : 0) });
      if (num) pdf.text(num, foot ? PW - mk - 2 : PW / 2, PH - mk - 1, { align: foot ? "right" : "center" });
      pdf.setTextColor(0, 0, 0);
    }
    // B15: nhường luồng sau mỗi trang — dựng PDF 20 trang không khựng giao diện.
    await yieldUi();
  }
  throwIfAborted(opts.signal);
  if (!pdf) pdf = new jsPDF({ unit: "mm", format: fit ? "a4" : paper, compress: true, ...enc });
  pdf.setProperties(pdfProperties(opts.name, dpis, paper)); // CS-20 (QP-08): tiêu đề, số trang + DPI thật, ứng dụng
  return pdf.output("blob");
}

/** fromOrig = false khi ảnh trang đã bị đổi so với bản lưu (vd. đóng hình mờ CCCD) → không dựng lại từ ảnh gốc. */
export async function docToPdf(doc0: Doc, opts: ExportOptions & { fromOrig?: boolean } = {}) {
  const [doc] = await readyDocs([doc0]);
  const { fromOrig: useOrig = true, ...rest } = opts;
  const sources = useOrig ? doc.pages.map((p): PageSource | undefined => (p.orig ? { orig: p.orig, edit: p.edit } : undefined)) : undefined;
  return imagesToPdf(doc.pages.map((p) => p.src), { searchable: true, name: doc.name, sources, kinds: doc.pages.map((p) => pageKindOf(p.edit?.filter)), ...rest });
}

/* ---- Searchable PDF: invisible OCR text over the page image (Vietnamese font embedded) ---- */
type JsPdf = InstanceType<typeof import("jspdf").jsPDF>;
let fontB64: Promise<string> | null = null;
function loadFont() {
  fontB64 ??= fetch("/fonts/DejaVuSans.ttf").then((r) => r.arrayBuffer()).then((b) => {
    const u = new Uint8Array(b); let s = ""; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); return btoa(s);
  });
  return fontB64;
}
/** R5.2: một dòng chữ OCR đã đặt vị trí trên trang PDF (mm). Thuần, kiểm thử được. */
export type TextOp = { text: string; x: number; y: number; size: number; charSpace: number };
export type OcrLine = { text: string; bbox: { x0: number; y0: number; x1: number; y1: number } };

/** Đặt các dòng OCR lên khung ảnh trong PDF: co theo tỉ lệ r (mm/px), chữ vô hình phủ đúng vị trí ảnh. */
/** BL-06 (RS-22): ánh xạ từ toạ độ ảnh NGUỒN (nơi chạy OCR) sang ảnh ĐÃ NÉN đặt vào PDF: thu nhỏ `scale` rồi cắt lề (ox, oy);
 *  w/h = cỡ ảnh đã nén (để bỏ dòng nằm hẳn trong phần lề đã cắt). Thiếu = như cũ (không thu nhỏ, không cắt). */
export type SrcMap = { ox: number; oy: number; scale: number; w?: number; h?: number };
export function textLayerOps(lines: OcrLine[], x0: number, y0: number, r: number, map: SrcMap = { ox: 0, oy: 0, scale: 1 }): TextOp[] {
  const ops: TextOp[] = [];
  const { ox, oy, scale: k } = map;
  for (const ln of lines) {
    const t = ln.text.trim();
    if (!t) continue;
    const lx = ln.bbox.x0 * k - ox, ly = ln.bbox.y0 * k - oy, lx1 = ln.bbox.x1 * k - ox, ly1 = ln.bbox.y1 * k - oy;
    if (lx1 <= 0 || ly1 <= 0 || (map.w !== undefined && lx >= map.w) || (map.h !== undefined && ly >= map.h)) continue; // dòng nằm trong lề đã cắt
    const hMm = (ly1 - ly) * r;
    const size = Math.max(2, (hMm / 0.3528) * 0.85);
    // R5.2: KHÔNG giãn ký tự — mọi charSpace > 0 đều khiến trình đọc (pdfjs, Acrobat)
    // tách từng ký tự thành từ riêng, đánh mất khả năng tìm kiếm tiếng Việt (đã kiểm chứng).
    ops.push({ text: t, x: x0 + lx * r, y: y0 + ly1 * r - hMm * 0.2, size, charSpace: 0 });
  }
  return ops;
}

/** Ghi các dòng chữ vô hình vào PDF (phông DejaVu nhúng sẵn → tìm/sao chép được tiếng Việt ở mọi trình đọc). */
export async function writeTextLayer(pdf: JsPdf, ops: TextOp[]) {
  if (!ops.length) return;
  if (!pdf.getFontList()["DejaVu"]) { pdf.addFileToVFS("DejaVuSans.ttf", await loadFont()); pdf.addFont("DejaVuSans.ttf", "DejaVu", "normal", undefined, "Identity-H"); }
  pdf.setFont("DejaVu", "normal");
  for (const op of ops) {
    pdf.setFontSize(op.size);
    pdf.text(op.text, op.x, op.y, { renderingMode: "invisible", charSpace: op.charSpace } as never);
  }
}

async function addTextLayer(pdf: JsPdf, src: string, x0: number, y0: number, r: number, map?: SrcMap) {
  try {
    const { sharedOcr, currentLang } = await import("./ocr-worker");
    const res = await sharedOcr().run(await currentLang(), src, { out: { blocks: true } });
    const lines = (res.data.blocks ?? []).flatMap((b) => b.paragraphs.flatMap((p) => p.lines));
    if (!lines.length) return;
    await writeTextLayer(pdf, textLayerOps(lines, x0, y0, r, map));
  } catch (e) { console.warn("text layer skipped", e); }
}

export async function pdfjs() {
  const lib = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const worker = await import("pdfjs-dist/legacy/build/pdf.worker.min.mjs?url");
  lib.GlobalWorkerOptions.workerSrc = worker.default;
  return lib;
}
export async function pdfToImages(file: Blob, scale = 2, q = 0.88, withAnnotations = true) {
  const lib = await pdfjs();
  const task = lib.getDocument({ data: new Uint8Array(await file.arrayBuffer())});
  try {
    const pdf = await task.promise;
    const out: string[] = [];
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i); const vp = page.getViewport({ scale });
      const c = document.createElement("canvas"); c.width = vp.width; c.height = vp.height;
      await page.render({ canvas: c, canvasContext: c.getContext("2d")!, viewport: vp, ...(withAnnotations ? {} : { annotationMode: 0 }) }).promise;
      page.cleanup();
      out.push(await canvasToPageUrl(c, "image/jpeg", q)); // R1.4: object URL, canvas giải phóng ngay
    }
    return out;
  } finally { await task.destroy(); } // BL-07: trả bộ nhớ pdf.js (trước: không bao giờ destroy)
}

/** BL-06 (RS-26): KHÔNG dùng ignoreEncryption — pdf-lib nạp PDF mã hoá mà không giải mã, gộp/tách/xoay ra tệp hỏng hoặc trang trắng, im lặng. */
async function loadPlainPdf(file: Blob) {
  const lib = await import("pdf-lib");
  try { return { doc: await lib.PDFDocument.load(await file.arrayBuffer()), lib }; }
  catch (e) {
    if (e instanceof lib.EncryptedPDFError || /encrypt/i.test(String((e as Error)?.message ?? e)))
      throw Object.assign(new Error("PDF này có mật khẩu hoặc được mã hoá — chưa sửa trực tiếp được. Hãy mở khoá PDF trước, hoặc dùng công cụ “PDF → ảnh”.", { cause: e }), { name: "EncryptedPdf" });
    throw e;
  }
}
export async function mergePdfs(files: Blob[]) {
  const { PDFDocument } = await import("pdf-lib");
  const out = await PDFDocument.create();
  for (const f of files) {
    const { doc: src } = await loadPlainPdf(f);
    (await out.copyPages(src, src.getPageIndices())).forEach((p) => out.addPage(p));
  }
  return new Blob([await out.save() as BlobPart], { type: "application/pdf" });
}
export async function splitPdf(file: Blob) {
  const { PDFDocument } = await import("pdf-lib");
  const { doc: src } = await loadPlainPdf(file);
  const parts: Blob[] = [];
  for (const i of src.getPageIndices()) {
    const d = await PDFDocument.create(); const [p] = await d.copyPages(src, [i]); d.addPage(p);
    parts.push(new Blob([await d.save() as BlobPart], { type: "application/pdf" }));
  }
  return parts;
}

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
/** Word opens HTML saved as .doc, keeping Vietnamese text intact. */
export function textToWord(text: string, title: string) {
  const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word"><head><meta charset="utf-8"><title>${esc(title)}</title></head><body style="font-family:Arial;font-size:12pt">${text.split(/\n/).map((l) => `<p>${esc(l) || "&nbsp;"}</p>`).join("")}</body></html>`;
  return new Blob(["\ufeff" + html], { type: "application/msword" });
}
/** Turn OCR lines into spreadsheet rows (columns split on wide gaps). */
export function textToCsv(text: string) {
  const rows = text.split(/\n/).filter((l) => l.trim()).map((l) => l.trim().split(/\s{2,}|\t|\s\|\s/).map((c) => `"${c.replace(/"/g, '""')}"`).join(","));
  return new Blob(["\ufeff" + rows.join("\n")], { type: "text/csv" });
}

/* ---- Direct PDF edits (pdf-lib): keep original text/vector quality, no re-rendering ---- */
const pdfBlob = (b: Uint8Array) => new Blob([b as BlobPart], { type: "application/pdf" });
async function loadPdf(file: Blob) {
  const { doc, lib } = await loadPlainPdf(file);
  return { doc, PDFDocument: lib.PDFDocument, degrees: lib.degrees };
}
export async function pdfPageCount(file: Blob) { return (await loadPdf(file)).doc.getPageCount(); }

/** Rotate pages (1-based list, empty = all) by a multiple of 90°. */
export async function rotatePdf(file: Blob, angle: number, pages: number[] = []) {
  const { doc, degrees } = await loadPdf(file);
  doc.getPages().forEach((p, i) => { if (!pages.length || pages.includes(i + 1)) p.setRotation(degrees((p.getRotation().angle + angle) % 360)); });
  return pdfBlob(await doc.save());
}

/** Build a new PDF with the given 1-based page order (omitted pages are removed). */
export async function reorderPdf(file: Blob, order: number[]) {
  const { doc, PDFDocument } = await loadPdf(file);
  const out = await PDFDocument.create();
  for (const p of await out.copyPages(doc, order.map((n) => n - 1))) out.addPage(p);
  return pdfBlob(await out.save());
}

/** Stamp a text watermark (rendered to PNG so Vietnamese accents work) on every page. */
export async function watermarkPdf(file: Blob, text: string) {
  const { doc } = await loadPdf(file);
  const c = document.createElement("canvas"); const ctx = c.getContext("2d")!;
  ctx.font = "bold 96px sans-serif"; c.width = Math.ceil(ctx.measureText(text).width) + 40; c.height = 130;
  ctx.font = "bold 96px sans-serif"; ctx.fillStyle = "rgba(0,140,120,0.22)"; ctx.textBaseline = "middle"; ctx.fillText(text, 20, 65);
  const png = await doc.embedPng(await (await canvasToBlob(c, "image/png")).arrayBuffer());
  const { degrees } = await import("pdf-lib");
  for (const p of doc.getPages()) {
    const { width, height } = p.getSize(); const w = width * 0.8, h = (w * c.height) / c.width;
    const a = Math.atan2(height, width);
    p.drawImage(png, { x: width / 2 - (w / 2) * Math.cos(a) + (h / 2) * Math.sin(a), y: height / 2 - (w / 2) * Math.sin(a) - (h / 2) * Math.cos(a), width: w, height: h, rotate: degrees((a * 180) / Math.PI) });
  }
  return pdfBlob(await doc.save());
}

/** Parse "1-3, 5, 7" into page numbers within 1..max (keeps order and repeats). */
export function parsePages(s: string, max: number) {
  const out: number[] = [];
  for (const part of s.split(/[,;\s]+/).filter(Boolean)) {
    const m = part.match(/^(\d+)(?:-(\d+))?$/); if (!m) continue;
    // BL-06 (RS-29): kẹp dải về [1, max] TRƯỚC khi lặp — "1-999999999" từng lặp ~1 tỉ lần (đơ máy)
    const a0 = +m[1], b0 = m[2] ? +m[2] : a0;
    if ((a0 < 1 && b0 < 1) || (a0 > max && b0 > max)) continue;
    const clamp = (v: number) => Math.min(max, Math.max(1, v));
    const a = clamp(a0), b = clamp(b0), step = a <= b ? 1 : -1;
    for (let i = a; step > 0 ? i <= b : i >= b; i += step) out.push(i);
  }
  return out;
}
