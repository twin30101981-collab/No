import { createMiddleware, createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { MAX_DATA_CHARS, diagLogLine, normalizeDiagnosis } from "./scan-diagnose";
import { aiErrorLine } from "./ai-log";

const img = z.string().startsWith("data:image/").max(4_000_000);

/** AI-04: chỉ các lệnh AI gắn tiêu đề x-ai-keys (key người dùng đã lưu mã hoá trên máy); không có key thì không gắn gì. */
const aiKeysMw = createMiddleware({ type: "function" }).client(async ({ next }) => {
  if (typeof window === "undefined") return next();
  const { aiKeysHeader, AI_KEYS_HEADER } = await import("./ai-keys");
  const { aiSensitivityHint, AI_SENSITIVE_HEADER } = await import("./ai-sensitivity");
  const h = await aiKeysHeader().catch(() => null), s = aiSensitivityHint();
  const headers: Record<string, string> = {};
  if (h) headers[AI_KEYS_HEADER] = h;
  if (s !== null) headers[AI_SENSITIVE_HEADER] = s ? "1" : "0"; // AI-05: gợi ý độ nhạy cảm của tài liệu đang mở
  return next({ headers });
});

/** AI-01: chạy việc AI trong ngữ cảnh chuỗi nguồn; kết quả thành công kèm `source` (nguồn đã phục vụ: lovable/claude/mistral/gemini). */
async function tracked<R>(task: string, data: unknown, fn: () => Promise<R>): Promise<R> {
  const { withAiSource, aiKeysOverrides } = await import("./ai-chain.server");
  const { sensitiveFor } = await import("./ai-sensitivity");
  const { getRequest } = await import("@tanstack/react-start/server");
  const h = getRequest()?.headers;
  // AI-04: key người dùng; AI-05: nhạy cảm → không gửi nguồn miễn phí
  const { value, source, tried } = await withAiSource(fn, aiKeysOverrides(h?.get("x-ai-keys")), sensitiveFor(task, data, h?.get("x-ai-sensitive")));
  // AI-02: kèm nguồn đã phục vụ + các nguồn đã thử (chỉ tên + mã lỗi) để client báo "đang dùng nguồn dự phòng" và trang Tình trạng AI
  if (!value || typeof value !== "object" || !("ok" in value)) return value;
  return { ...value, ...(source ? { source } : {}), ...(tried.length ? { tried } : {}) };
}

export const aiExtract = createServerFn({ method: "POST" }).middleware([aiKeysMw])
  .inputValidator((d) => z.object({ images: z.array(img).min(1).max(4), template: z.enum(["vat", "xe", "sodo"]).optional() }).parse(d))
  .handler(async ({ data }) => tracked("aiExtract", data, async () => {
    const { extractFromImages, toFail, aiGate } = await import("./ai.server");
    const limited = await aiGate(); if (limited) return limited;
    try { return { ok: true as const, data: await extractFromImages(data.images, data.template) }; } catch (e) { console.error(aiErrorLine(e)); return toFail(e); }
  }));

export const aiText = createServerFn({ method: "POST" }).middleware([aiKeysMw])
  .inputValidator((d) => z.object({
    task: z.enum(["translate", "summarize", "solve", "handwrite"]),
    text: z.string().max(30_000).optional(),
    images: z.array(img).max(4).optional(),
    lang: z.string().max(40).optional(),
  }).refine((v) => v.text?.trim() || v.images?.length, "empty").parse(d))
  .handler(async ({ data }) => tracked("aiText", data, async () => {
    const { runTextTask, toFail, aiGate } = await import("./ai.server");
    const limited = await aiGate(); if (limited) return limited;
    try { return { ok: true as const, text: await runTextTask(data.task, data) }; } catch (e) { console.error(aiErrorLine(e)); return toFail(e); }
  }));

/** Đọc từng dòng kèm toạ độ ô (dữ liệu thô). */
export const aiRows = createServerFn({ method: "POST" }).middleware([aiKeysMw])
  .inputValidator((d) => z.object({ images: z.array(img).min(1).max(4) }).parse(d))
  .handler(async ({ data }) => tracked("aiRows", data, async () => {
    const { rowsFromImages, toFail, aiGate } = await import("./ai.server");
    const limited = await aiGate(); if (limited) return limited;
    try { return { ok: true as const, data: await rowsFromImages(data.images) }; } catch (e) { console.error(aiErrorLine(e)); return toFail(e); }
  }));

/** Bảng từ ảnh gốc: AI đọc từng dòng, cột được ghép bằng toạ độ (columns.ts). */
export const aiTable = createServerFn({ method: "POST" }).middleware([aiKeysMw])
  .inputValidator((d) => z.object({ images: z.array(img).min(1).max(4) }).parse(d))
  .handler(async ({ data }) => tracked("aiTable", data, async () => {
    const { rowsFromImages, toFail, aiGate } = await import("./ai.server");
    const limited = await aiGate(); if (limited) return limited;
    const { rowsToGrid } = await import("./columns");
    try {
      const r = await rowsFromImages(data.images);
      return { ok: true as const, data: { title: r.title, rows: rowsToGrid(r.rows) } };
    } catch (e) { console.error(aiErrorLine(e)); return toFail(e); }
  }));

export const aiLayout = createServerFn({ method: "POST" }).middleware([aiKeysMw])
  .inputValidator((d) => z.object({ images: z.array(img).min(1).max(4) }).parse(d))
  .handler(async ({ data }) => tracked("aiLayout", data, async () => {
    const { layoutFromImages, toFail, aiGate } = await import("./ai.server");
    const limited = await aiGate(); if (limited) return limited;
    try { return { ok: true as const, data: await layoutFromImages(data.images) }; } catch (e) { console.error(aiErrorLine(e)); return toFail(e); }
  }));

/** Hỏi đáp với tài liệu (G3-10): nhận chữ các trang, tự chọn đoạn liên quan, trả lời kèm trang. */
export const aiDocAsk = createServerFn({ method: "POST" }).middleware([aiKeysMw])
  .inputValidator((d) => z.object({
    question: z.string().trim().min(1).max(1_000),
    pages: z.array(z.string().max(50_000)).min(1).max(60),
  }).parse(d))
  .handler(async ({ data }) => tracked("aiDocAsk", data, async () => {
    const { answerDocQuestion, toFail, aiGate } = await import("./ai.server");
    const limited = await aiGate(); if (limited) return limited;
    const { chunkDocument, selectChunks, buildContext } = await import("./doc-qa");
    try {
      const chunks = selectChunks(chunkDocument(data.pages.map((text) => ({ text }))), data.question);
      if (!chunks.length) return { ok: false as const, code: 422, message: "Tài liệu chưa có chữ. Hãy nhận chữ (OCR/AI) trước rồi hỏi lại." };
      const r = await answerDocQuestion(data.question, buildContext(chunks));
      return { ok: true as const, answer: r.answer, pages: r.pages, usedPages: [...new Set(chunks.map((c) => c.page))] };
    } catch (e) { console.error(aiErrorLine(e)); return toFail(e); }
  }));

/** G3-12: AI tự đặt tên & phân loại sau khi quét. */
export const aiClassify = createServerFn({ method: "POST" }).middleware([aiKeysMw])
  .inputValidator((d) => z.object({ images: z.array(img).min(1).max(2) }).parse(d))
  .handler(async ({ data }) => tracked("aiClassify", data, async () => {
    const { classifyImages, toFail, aiGate } = await import("./ai.server");
    const limited = await aiGate(); if (limited) return limited;
    try { return { ok: true as const, data: await classifyImages(data.images) }; } catch (e) { console.error(aiErrorLine(e)); return toFail(e); }
  }));

/** G3-14: dịch các khối chữ đã lấy khung từ ảnh. */
export const aiTranslateBlocks = createServerFn({ method: "POST" }).middleware([aiKeysMw])
  .inputValidator((d) => z.object({ texts: z.array(z.string().max(4000)).min(1).max(200), lang: z.string().min(1).max(40) }).parse(d))
  .handler(async ({ data }) => tracked("aiTranslateBlocks", data, async () => {
    const { translateBlocks, toFail, aiGate } = await import("./ai.server");
    const limited = await aiGate(); if (limited) return limited;
    try { return { ok: true as const, texts: await translateBlocks(data.texts, data.lang) }; } catch (e) { console.error(aiErrorLine(e)); return toFail(e); }
  }));

/** G3-16: ảnh người trên nền xanh lục để tách nền ảnh thẻ. */
export const aiPersonGreen = createServerFn({ method: "POST" }).middleware([aiKeysMw])
  .inputValidator((d) => z.object({ image: img }).parse(d))
  .handler(async ({ data }) => tracked("aiPersonGreen", data, async () => {
    const { greenScreenPerson, toFail, aiGate } = await import("./ai.server");
    const limited = await aiGate(); if (limited) return limited;
    try { return { ok: true as const, image: await greenScreenPerson(data.image) }; } catch (e) { console.error(aiErrorLine(e)); return toFail(e); }
  }));

/** G3-18: trích tổng tiền, ngày từ ảnh hoá đơn/biên lai. */
export const aiReceipt = createServerFn({ method: "POST" }).middleware([aiKeysMw])
  .inputValidator((d) => z.object({ image: img }).parse(d))
  .handler(async ({ data }) => tracked("aiReceipt", data, async () => {
    const { receiptFromImage, toFail, aiGate } = await import("./ai.server");
    const limited = await aiGate(); if (limited) return limited;
    try { return { ok: true as const, data: await receiptFromImage(data.image) }; } catch (e) { console.error(aiErrorLine(e)); return toFail(e); }
  }));

export const aiPaperCorners = createServerFn({ method: "POST" }).middleware([aiKeysMw])
  .inputValidator((d) => z.object({ image: img }).parse(d))
  .handler(async ({ data }) => tracked("aiPaperCorners", data, async () => {
    const { paperCornersFromImage, toFail, aiGate } = await import("./ai.server");
    const limited = await aiGate(); if (limited) return limited;
    try { return { ok: true as const, data: await paperCornersFromImage(data.image) }; } catch (e) { console.error(aiErrorLine(e)); return toFail(e); }
  }));

/** Chấm độ rõ, ánh sáng, độ chói, góc chụp và gợi ý chụp lại. */
export const aiPhotoCheck = createServerFn({ method: "POST" }).middleware([aiKeysMw])
  .inputValidator((d) => z.object({ image: img }).parse(d))
  .handler(async ({ data }) => tracked("aiPhotoCheck", data, async () => {
    const { checkDocPhoto, toFail, aiGate } = await import("./ai.server");
    const limited = await aiGate(); if (limited) return limited;
    try { return { ok: true as const, data: await checkDocPhoto(data.image) }; } catch (e) { console.error(aiErrorLine(e)); return toFail(e); }
  }));

/** S12 – chẩn đoán ảnh quét (chỉ gọi khi người dùng bấm); log không chứa nội dung. */
export const aiScanDiagnose = createServerFn({ method: "POST" }).middleware([aiKeysMw])
  .inputValidator((d) => z.object({ image: z.string().startsWith("data:image/").max(MAX_DATA_CHARS), version: z.string().max(200) }).parse(d))
  .handler(async ({ data }) => tracked("aiScanDiagnose", data, async () => {
    const { diagnoseScan, toFail, aiGate } = await import("./ai.server");
    const limited = await aiGate(); if (limited) return limited;
    try {
      const d = normalizeDiagnosis(await diagnoseScan(data.image), data.version);
      console.log(diagLogLine(data.version, d));
      return { ok: true as const, data: d };
    } catch (e) { const f = toFail(e); console.log(diagLogLine(data.version, null, f.code)); return f; }
  }));

/** AI-04: "Kiểm tra" một nguồn bằng key đã lưu (hoặc key máy chủ) — Sẵn sàng / Key sai / Hết lượt / Lỗi. */
export const aiKeyCheck = createServerFn({ method: "POST" }).middleware([aiKeysMw])
  .inputValidator((d) => z.object({ provider: z.enum(["lovable", "claude", "mistral", "gemini"]) }).parse(d))
  .handler(async ({ data }) => tracked("aiKeyCheck", data, async () => {
    const { pingProvider } = await import("./ai.server"); const { aiEnv, errorCode, providerOrder } = await import("./ai-chain.server");
    if (!providerOrder({}, { ...aiEnv(), AI_PROVIDERS: data.provider }).length) return { ok: false as const, status: "no-key" as const, code: 401 };
    try { await pingProvider(data.provider); return { ok: true as const, status: "ready" as const }; }
    catch (e) { const code = errorCode(e); return { ok: false as const, code, status: code === 401 || code === 403 ? ("bad-key" as const) : code === 402 || code === 429 ? ("quota" as const) : ("error" as const) }; }
  }));

/** AI-02: nguồn AI đã cấu hình (key máy chủ hay key của người dùng), theo thứ tự dùng — không gọi AI, không trả key. */
export const aiProviders = createServerFn({ method: "POST" }).middleware([aiKeysMw])
  .handler(async () => {
    const { ALL_PROVIDERS, FREE_PROVIDERS, PROVIDER_KEY_ENV, PROVIDER_LABEL, aiKeysOverrides } = await import("./ai-chain.server");
    const { getRequest } = await import("@tanstack/react-start/server");
    const user = aiKeysOverrides(getRequest()?.headers.get("x-ai-keys")) ?? {};
    const server = typeof process !== "undefined" ? process.env : {};
    const wanted = (user["AI_PROVIDERS"] ?? server["AI_PROVIDERS"] ?? "").split(",").map((s) => s.trim()).filter((s) => (ALL_PROVIDERS as readonly string[]).includes(s));
    const order = [...new Set([...wanted, ...ALL_PROVIDERS])] as (typeof ALL_PROVIDERS)[number][];
    return { ok: true as const, providers: order.map((id) => {
      const env = PROVIDER_KEY_ENV[id], keySource = user[env]?.trim() ? ("user" as const) : server[env]?.trim() ? ("server" as const) : null;
      return { id, label: PROVIDER_LABEL[id], free: FREE_PROVIDERS.has(id), keySource, enabled: !wanted.length || wanted.includes(id) };
    }) };
  });
