import { normalizeInWorker } from "./normalize-pool";
import type { Filter, PageEdit, Quad } from "./db";
import { detectPaper } from "./detect";
import { detectPaperAsync } from "./detect-worker";
export { normalizeFilter } from "./render-core";
import { edgeStripBox, refineQuadSampler, stripSampler } from "./detect-refine";
import { unsharp as unsharpPx, type Px } from "./pixels";
import { gpuWarpOff, runPixels } from "./worker-call";
import { runInPool, poolCanvasSupported } from "./worker-pool";
import { cleanEdgesPx, finishPx, flattenLightPx, rotatePx, straightWarpPx, type FilterOpts, type Img, type RenderEnv } from "./render-core";
import { webglWarp } from "./webgl-warp";
import { gpuWarpMesh } from "./warp-mesh";
import { recordPerf } from "./perf-stats";
import { adoptBlob } from "./disk-pack";
import { Lru, MB, limiter, srcKey, geoKey, resultKey, PREVIEW_LONG } from "./render-cache";

/** Đo tốc độ nắn gần nhất (G2-04): "gpu" | "cpu" và số ms. */
export const warpStats: { engine: "gpu" | "cpu" | ""; ms: number } = { engine: "", ms: 0 };

export function loadImg(src: string | Blob): Promise<HTMLImageElement> {
  // S4: nhận Blob trực tiếp (object URL) – tránh chuỗi base64 lớn trên luồng chính
  const url = typeof src === "string" ? src : URL.createObjectURL(src);
  return new Promise((resolve, reject) => {
    const img = new Image();
    const done = () => { if (typeof src !== "string") URL.revokeObjectURL(url); };
    // CS-17d: giải mã trước (decode() chạy ngoài luồng chính) — lần vẽ đầu không còn giải mã đồng bộ ảnh 12 MP trên luồng chính
    img.onload = () => { const ok = () => { done(); resolve(img); }; if (typeof img.decode === "function") img.decode().then(ok, ok); else ok(); };
    img.onerror = (e) => { done(); reject(e); }; img.src = url;
  });
}
/** CS-17d: nhường luồng chính một nhịp (tác vụ mới) — tách các bước vẽ/đo nối tiếp để mỗi tác vụ < 50 ms. */
export const yieldTask = () => new Promise<void>((r) => setTimeout(r, 0));
export function fileToDataUrl(file: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader(); r.onload = () => resolve(r.result as string); r.onerror = reject; r.readAsDataURL(file);
  });
}
function canvas(w: number, h: number) {
  const c = document.createElement("canvas"); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h));
  return [c, c.getContext("2d", { willReadFrequently: true })!] as const;
}
export function toJpeg(c: HTMLCanvasElement, q = 0.92) { return c.toDataURL("image/jpeg", q); }
/** S4: nén JPEG thành Blob ngoài luồng chính; rơi về chuyển từ toDataURL khi thiếu toBlob. */
export function toJpegBlob(c: HTMLCanvasElement, q = 0.92): Promise<Blob> {
  if (typeof c.toBlob !== "function") return Promise.resolve(dataUrlToBlob(toJpeg(c, q)));
  return new Promise((res) => c.toBlob((b) => res(b ?? dataUrlToBlob(toJpeg(c, q))), "image/jpeg", q));
}
/** S3: nén JPEG không chặn luồng chính – toBlob mã hoá ngoài luồng chính, rơi về toDataURL khi thiếu. */
export function toJpegAsync(c: HTMLCanvasElement, q = 0.92): Promise<string> {
  if (typeof c.toBlob !== "function") return Promise.resolve(toJpeg(c, q));
  return new Promise((res) => c.toBlob((b) => (b ? fileToDataUrl(b).then(res, () => res(toJpeg(c, q))) : res(toJpeg(c, q))), "image/jpeg", q));
}

async function drawNormalized(src: string | Blob | CanvasImageSource, max: number) {
  const img = typeof src === "string" ? await loadImg(src.startsWith("data:") ? dataUrlToBlob(src) : src)
    : src instanceof Blob ? await loadImg(src) : src;
  const w = (img as HTMLImageElement).naturalWidth || (img as HTMLVideoElement).videoWidth || (img as HTMLCanvasElement).width;
  const h = (img as HTMLImageElement).naturalHeight || (img as HTMLVideoElement).videoHeight || (img as HTMLCanvasElement).height;
  const s = Math.min(1, max / Math.max(w, h));
  const [c, ctx] = canvas(w * s, h * s); ctx.drawImage(img, 0, 0, c.width, c.height);
  return c;
}
/** B07: ảnh thu nhỏ mới nhất từ page-pipeline (khoá = Blob nguồn), để lưới trang dùng ngay. */
export const lastThumbs = new WeakMap<Blob, Blob>();
/** S5d/B07: Blob → Worker (giải mã/thu nhỏ/nén ngoài luồng chính); lỗi hoặc không hỗ trợ → null.
 *  B07: ưu tiên page-pipeline — một lượt nền duy nhất cho cả ảnh chính lẫn ảnh thu nhỏ. */
async function viaWorker(src: unknown, max: number, q: number): Promise<Blob | null> {
  if (!(src instanceof Blob)) return null;
  try {
    const { processPageInWorker } = await import("./page-pipeline");
    const bmp = await createImageBitmap(src);
    const pp = processPageInWorker(bmp, { max, q, thumbMax: 512 });
    if (pp) {
      try {
        const r = await pp;
        lastThumbs.set(src, r.thumb);
        return r.main;
      } catch { /* rơi xuống worker cũ */ }
    }
  } catch { /* thiếu createImageBitmap → worker cũ */ }
  const p = normalizeInWorker(src, max, q); if (!p) return null;
  try { return await p; } catch { return null; }
}
/** Downscale any image source to a max dimension and return a jpeg data URL. */
export async function normalize(src: string | Blob | CanvasImageSource, max = 2000, q = 0.9) {
  const wb = await viaWorker(src, max, q); if (wb) return fileToDataUrl(wb);
  const c = await drawNormalized(src, max);
  const out = await toJpegAsync(c, q); c.width = 0; return out;
}
/** S4: như normalize nhưng trả Blob – không tạo chuỗi base64 (giảm RAM, nhanh hơn). */
export async function normalizeBlob(src: string | Blob | CanvasImageSource, max = 2000, q = 0.9) {
  const wb = await viaWorker(src, max, q); if (wb) return wb;
  const c = await drawNormalized(src, max);
  const out = await toJpegBlob(c, q); c.width = 0; return out;
}

/** Đo tốc độ nắn gần nhất — ghi từ số đo Worker hoặc luồng chính. */
function recordWarps(perf: { engine: string; ms: number }[]) {
  for (const p of perf) { warpStats.engine = p.engine as "gpu" | "cpu"; warpStats.ms = p.ms; recordPerf(p.engine === "gpu" ? "warp-gpu" : "warp-cpu", p.ms); }
}
/** V4: số lần đọc toàn ảnh gốc (getImageData W×H) — đích 1 lần/trang. */
export const v4Stats = { fullReads: 0 };
if (typeof globalThis !== "undefined") (globalThis as { __v4?: typeof v4Stats }).__v4 = v4Stats;
/** V4: đọc điểm ảnh gốc một lần; straightWarpPx dùng lại cho cả bản dò lẫn bản chính. */
function readSrc(img: HTMLImageElement) {
  const W = img.naturalWidth, H = img.naturalHeight;
  const [sc, sctx] = canvas(W, H); sctx.drawImage(img, 0, 0);
  const d = sctx.getImageData(0, 0, W, H).data; sc.width = 0; v4Stats.fullReads++;
  return d;
}
/**
 * CS-17d: môi trường luồng chính cho render-core — chỉ dùng khi Worker không dựng được (thiếu Worker/OffscreenCanvas,
 * Worker không có WebGL2, lỗi). Thứ tự nắn giữ như CS-17b: GPU trong Worker → GPU luồng chính → GPU cũ (phẳng) → CPU trong Worker.
 */
function mainEnv(img?: HTMLImageElement): RenderEnv {
  return {
    canvas, run: runPixels,
    async warp(sd, W, H, q, ow, oh, curves, keep) {
      if (!img) throw new Error("warp: thiếu ảnh gốc");
      const curved = curves.some(Boolean);
      let od: Uint8ClampedArray | null = (await gpuWarpOff(sd, W, H, q, ow, oh, curves)) ?? gpuWarpMesh(img, W, H, q, ow, oh, curves); let engine: "gpu" | "cpu" = od ? "gpu" : "cpu";
      if (!od && !curved) {
        const gpu = webglWarp(img, W, H, q, ow, oh);
        if (gpu) { od = new Uint8ClampedArray(gpu.getContext("2d", { willReadFrequently: true })!.getImageData(0, 0, ow, oh).data); gpu.width = 0; engine = "gpu"; }
      }
      if (!od) od = await runPixels({ op: "warp", src: keep ? new Uint8ClampedArray(sd) : sd, W, H, q, ow, oh, curves });
      return { od, engine };
    },
    jpeg: (c, q) => new Promise<Blob | null>((res) => (c as HTMLCanvasElement).toBlob(res, "image/jpeg", q)),
    bitmap: (b) => createImageBitmap(b),
    mark: pushV0,
  };
}

/**
 * CS-17d: việc dựng trong Worker của bể ("render": geo / flat / fin) — luồng chính chỉ gửi bộ đệm (chuyển quyền) và nhận kết quả.
 * null = không làm được → tầng trên chạy render-core ở luồng chính (cùng phép tính, trùng byte).
 */
let offOk = true, offGeo = true;
type OffReply = { fallback?: string; t?: [string, number][]; back?: Px };
async function offRun<T>(payload: Record<string, unknown>, transfer: Transferable[] = [], onBack?: (d: Px) => void): Promise<T | null> {
  if (!offOk || !poolCanvasSupported()) return null;
  const p = runInPool<T & OffReply>("render", payload, transfer);
  if (!p) return null;
  // Lỗi/không làm được đến qua reject (pool.worker gửi kèm error) — cùng xử lý: nhận lại bộ đệm mượn, ghi cờ dự phòng
  const r = await p.catch((e: unknown) => ({ ...(e as OffReply), failed: true }) as T & OffReply & { failed?: boolean });
  if (r.back) onBack?.(r.back);
  for (const [step, ms] of r.t ?? []) pushV0(step, ms);
  if (r.fallback === "no-canvas") offOk = false;
  if (r.fallback === "no-webgl2" || r.fallback === "no-dom") offGeo = false; // Worker không có WebGL2 → hình học ở luồng chính như CS-17b
  return r.fallback || (r as { failed?: boolean }).failed ? null : r;
}
/** Bản sao để chuyển quyền sang Worker (bản trong bộ đệm giữ nguyên) — chỉ dùng cho ảnh nhỏ và đường dự phòng luồng chính. */
const copyImg = (g: Img): Img => ({ d: g.d.slice(), w: g.w, h: g.h });
/** Ảnh trong bộ đệm dựng; lost = bộ đệm đã mất khi cho Worker mượn (Worker sập) → bỏ khỏi bộ đệm, dựng lại. */
type CImg = Img & { lost?: boolean; lock?: Promise<unknown> };
const LEND_MIN = 8 * MB;
/**
 * CS-17d: gửi ảnh trong bộ đệm cho Worker. Ảnh lớn: CHO MƯỢN (chuyển quyền, Worker tự sao chép rồi trả lại) — luồng chính
 * không sao chép 35 MB (đo: copyImg ~60 ms/lần là long task). Mỗi ảnh một lượt mượn tại một thời điểm. Ảnh nhỏ: sao chép.
 */
function sendImg<T>(g: CImg, payload: Record<string, unknown>): Promise<T | null> {
  if (g.d.byteLength < LEND_MIN && !g.lock) { const c = copyImg(g); return offRun<T>({ ...payload, d: c.d, w: c.w, h: c.h }, [c.d.buffer]); }
  const run = (g.lock ?? Promise.resolve()).catch(() => {}).then(async () => {
    if (g.lost) return null;
    const d = g.d;
    const r = await offRun<T>({ ...payload, d, w: g.w, h: g.h, lend: true }, [d.buffer], (b) => { g.d = b; });
    if (!g.d.byteLength) g.lost = true; // không nhận lại (Worker sập) — tầng trên báo lỗi để dựng lại trang
    return r;
  });
  g.lock = run; return run;
}

/** Estimate small text tilt (±5°) via row projection-profile sharpness. */
export function estimateSkew(c: HTMLCanvasElement) {
  const s = Math.min(1, 600 / Math.max(c.width, c.height)); const w = Math.max(8, Math.round(c.width * s)), h = Math.max(8, Math.round(c.height * s));
  const g = grayscale(c, w, h); const t = otsu(g);
  const ink: number[] = []; const mx = Math.round(w * 0.05), my = Math.round(h * 0.05);
  for (let y = my; y < h - my; y++) for (let x = mx; x < w - mx; x++) if (g[y * w + x] < t - 10) ink.push(x, y);
  if (ink.length < 400 || ink.length / 2 > w * h * 0.35) return 0;
  const score = (deg: number) => {
    const a = (deg * Math.PI) / 180, tn = Math.tan(a); const rows = new Float64Array(h * 2);
    for (let i = 0; i < ink.length; i += 2) { const r = Math.round(ink[i + 1] - (ink[i] - w / 2) * tn) + h / 2; if (r >= 0 && r < rows.length) rows[r]++; }
    let v = 0; for (let i = 1; i < rows.length; i++) v += (rows[i] - rows[i - 1]) ** 2; return v;
  };
  let best = 0, bs = score(0);
  for (let d = -5; d <= 5; d += 0.5) { const v = score(d); if (v > bs) { bs = v; best = d; } }
  const c0 = best; for (let d = c0 - 0.4; d <= c0 + 0.4; d += 0.1) { const v = score(d); if (v > bs) { bs = v; best = d; } }
  return Math.abs(best) < 0.25 || bs < score(0) * 1.05 ? 0 : best;
}

/** Rotate away small tilt; fills exposed corners with edge-matching paper colour by slight zoom. Chạy trong Worker. */
async function deskew(c: HTMLCanvasElement) {
  const ctx = c.getContext("2d", { willReadFrequently: true })!;
  const im = ctx.getImageData(0, 0, c.width, c.height);
  const out = await runPixels({ op: "deskew", d: new Uint8ClampedArray(im.data), W: c.width, H: c.height });
  im.data.set(out); ctx.putImageData(im, 0, 0);
  return c;
}

/** B1: cạnh dài đích (px) theo chất lượng: Nét nhất = A4 300 dpi, Cân bằng = A4 200 dpi. */
export const TARGET_LONG = { high: 3508, normal: 2339 } as const;
export function targetLong(quality: "high" | "normal" = "high") { return TARGET_LONG[quality] ?? TARGET_LONG.high; }

// B2b: ảnh gốc giải mã một lần từ Blob (object URL), tối đa 2 ảnh lớn giải mã cùng lúc, giữ 2 ảnh gần nhất.
const decodeGate = limiter(2);
// LN-P23-01: bộ đệm chỉ 2 chỗ nhưng nhập ảnh/dựng chạy tới 3 làn → ảnh thứ 3 đẩy ảnh làn khác ĐANG dùng ra và xoá img.src
// (naturalWidth = 0 → khổ NaN → "Failed to construct ImageData" → cả lượt Thêm hỏng). Nay ảnh đang dùng (withDecoded) chỉ được
// giải phóng khi lượt cuối trả lại.
const inUse = new Map<HTMLImageElement, number>();
const freeLater = new Map<HTMLImageElement, () => void>();
const decoded = new Lru<{ img: HTMLImageElement; url: string | null }>(2, (v) => {
  const free = () => { if (v.url) URL.revokeObjectURL(v.url); v.img.src = ""; };
  if (inUse.has(v.img)) freeLater.set(v.img, free); else free();
}, (v) => v.img.naturalWidth * v.img.naturalHeight * 4, 128 * MB);
/** Phần hình học đã dựng (nắn → thẳng → làm sạch mép → xoay), dùng lại khi chỉ đổi bộ lọc. */
const geoCache = new Lru<CImg>(8, () => {}, (g) => g.d.byteLength, 160 * MB); // S15f: trần theo MB; CS-17d: bộ đệm điểm ảnh (không còn canvas)
/** Kết quả cuối theo (ảnh, hình học, bộ lọc, sáng, tương phản). */
const resultCache = new Lru<string>(24, (u) => { if (u.startsWith("blob:")) URL.revokeObjectURL(u); });
const inflight = new Map<string, Promise<unknown>>();
function once<T>(k: string, fn: () => Promise<T>): Promise<T> {
  const p = inflight.get(k) as Promise<T> | undefined; if (p) return p;
  const q = fn().finally(() => inflight.delete(k)); inflight.set(k, q); return q;
}
export function dataUrlToBlob(u: string) {
  const i = u.indexOf(","); const meta = u.slice(5, i); const b64 = meta.endsWith(";base64");
  const raw = b64 ? atob(u.slice(i + 1)) : decodeURIComponent(u.slice(i + 1));
  const a = new Uint8Array(raw.length); for (let k = 0; k < raw.length; k++) a[k] = raw.charCodeAt(k);
  return new Blob([a], { type: meta.replace(";base64", "") || "image/jpeg" });
}
async function decodeOrig(orig: string) {
  const k = srcKey(orig); const hit = decoded.get(k); if (hit) return hit.img;
  return once("d:" + k, () => decodeGate(async () => {
    const url = orig.startsWith("data:") ? URL.createObjectURL(dataUrlToBlob(orig)) : null;
    const img = await loadImg(url ?? orig); try { await img.decode?.(); } catch { /* đã tải xong */ }
    decoded.set(k, { img, url }); return img;
  }));
}
/** Dùng ảnh gốc đã giải mã trong suốt `fn` (kể cả qua các await) — không bị giải phóng giữa chừng khi bộ đệm đẩy ra. */
async function withDecoded<T>(orig: string, fn: (img: HTMLImageElement) => Promise<T> | T, step?: string): Promise<T> {
  let img = await (step ? v0(step, () => decodeOrig(orig)) : decodeOrig(orig)); // step: tên bước đo V0 (renderGeometry: "decode")
  // giữa lúc giải mã xong và lúc tiếp tục, làn khác có thể đã đẩy ảnh ra (đã xoá src) → giải mã lại
  for (let i = 0; i < 3 && !img.naturalWidth; i++) img = await decodeOrig(orig);
  inUse.set(img, (inUse.get(img) ?? 0) + 1);
  try { return await fn(img); } finally {
    const n = (inUse.get(img) ?? 1) - 1;
    if (n > 0) inUse.set(img, n); else { inUse.delete(img); const free = freeLater.get(img); if (free) { freeLater.delete(img); free(); } }
  }
}
/** Giải phóng toàn bộ ảnh giải mã + bộ đệm (gọi khi rời màn hình chỉnh/chụp). */
export function releaseRenderCache() { decoded.clear(); geoCache.clear(); resultCache.clear(); }
export const renderCacheStats = () => ({ decoded: decoded.size, geo: geoCache.size, results: resultCache.size, decode: decodeGate.stats() });
export function resetDecodePeak() { decodeGate.resetPeak(); }

/** V0: ghi thời gian từng bước dựng trang vào globalThis.__v0 (chỉ số đo, không ảnh hưởng ảnh ra). */
function pushV0(step: string, ms: number) {
  const g = globalThis as { __v0?: { step: string; ms: number }[] };
  (g.__v0 ??= []).push({ step, ms });
}
async function v0<T>(step: string, fn: () => Promise<T> | T): Promise<T> {
  const t0 = performance.now();
  try { return await fn(); } finally { pushV0(step, Math.round(performance.now() - t0)); }
}

/** Hình học ở luồng chính (dự phòng CS-17d): nắn → thẳng → làm sạch mép, hoặc thu nhỏ khi không có khung. */
async function geoMain(img: HTMLImageElement, edit: PageEdit, max: number): Promise<Img> {
  const env = mainEnv(img), perf: { engine: string; ms: number }[] = [];
  let g: Img;
  if (edit.quad) {
    const sd = readSrc(img); // V4: một lần đọc 12 MP cho cả trang
    g = await v0("warp", () => straightWarpPx(env, sd, img.naturalWidth, img.naturalHeight, edit.quad!, max, edit.paper, edit.flatten, perf));
    g = await v0("edge-clean", () => cleanEdgesPx(env, g));
  } else {
    const s = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight)); const [cc, ctx] = canvas(img.naturalWidth * s, img.naturalHeight * s); ctx.drawImage(img, 0, 0, cc.width, cc.height);
    g = { d: ctx.getImageData(0, 0, cc.width, cc.height).data, w: cc.width, h: cc.height }; cc.width = 0;
  }
  recordWarps(perf);
  return rotatePx(env, g, edit.rotation);
}
/** CS-17d: hình học trong Worker — Worker tự tải ảnh gốc (fetch + createImageBitmap), luồng chính không giải mã/đọc điểm ảnh. */
async function geoOff(orig: string, edit: PageEdit, max: number): Promise<Img | null> {
  // Không khung: thu nhỏ ảnh <img> ở luồng chính như cũ (drawImage thu nhỏ từ ImageBitmap trong Worker lệch byte — đo CS-17d)
  if (!offGeo || !edit.quad) return null;
  const r = await offRun<{ out: Px; w: number; h: number; perf: { engine: string; ms: number }[]; reads: number }>(
    { op: "geo", src: orig, quad: edit.quad ?? null, max, paper: edit.paper ?? "auto", flatten: edit.flatten, rotation: edit.rotation });
  if (!r) return null;
  v4Stats.fullReads += r.reads; recordWarps(r.perf);
  return { d: r.out, w: r.w, h: r.h };
}
async function renderGeometry(orig: string, edit: PageEdit, max: number): Promise<CImg> {
  const k = geoKey(orig, edit, max); const hit = geoCache.get(k); if (hit && !hit.lost) return hit;
  return once("g:" + k, async () => {
    const g = (await v0("geo", () => geoOff(orig, edit, max))) ?? await withDecoded(orig, (img) => geoMain(img, edit, max), "decode");
    geoCache.set(k, g); return g;
  });
}

/** Lớp đã chuẩn hoá ánh sáng (dùng chung cho Tự động/Nét/Màu kỳ diệu/Tiết kiệm mực). */
const FLAT_FILTERS = new Set<Filter>(["auto", "sharp", "magic", "eco"]);
async function renderFlat(orig: string, edit: PageEdit, max: number): Promise<CImg> {
  const k = geoKey(orig, edit, max) + "|flat"; const hit = geoCache.get(k); if (hit && !hit.lost) return hit;
  return once("f:" + k, async () => {
    const g = await renderGeometry(orig, edit, max);
    const d = await v0("flatten", async () => {
      const r = await sendImg<{ out: Px }>(g, { op: "flat" });
      if (r) return r.out;
      if (g.lost) { geoCache.delete(geoKey(orig, edit, max)); throw new Error("worker: mất bộ đệm hình học"); }
      return flattenLightPx(mainEnv(), g.d.slice(), g.w, g.h);
    });
    const f = { d, w: g.w, h: g.h }; geoCache.set(k, f); return f;
  });
}

/** Bộ lọc → nắn dải 0 → JPEG: Worker trước, luồng chính dự phòng. */
async function finish(g: CImg, o: FilterOpts & { q: number }, key: string): Promise<Blob> {
  const log: string[] = [];
  const r = await sendImg<{ blob: Blob | null; log: string[] }>(g, { op: "fin", o });
  let blob: Blob | null;
  if (r) { blob = r.blob; log.push(...r.log); } else {
    if (g.lost) { geoCache.delete(key); throw new Error("worker: mất bộ đệm hình học"); }
    blob = await finishPx(mainEnv(), copyImg(g), o, log);
  }
  if (log.length) (globalThis as { __s11?: string[] }).__s11 = [...((globalThis as { __s11?: string[] }).__s11 ?? []), ...log];
  if (!blob) throw new Error("toBlob");
  return blob;
}

async function renderTo(orig: string, edit: PageEdit, max: number, as: "data" | "blob" | "page") {
  const k = resultKey(orig, edit, max) + "|" + as; const hit = as === "page" ? undefined : resultCache.get(k); if (hit) return hit;
  return once("r:" + k, async () => {
    const flat = FLAT_FILTERS.has(edit.filter);
    const g = flat ? await renderFlat(orig, edit, max) : await renderGeometry(orig, edit, max);
    const gk = geoKey(orig, edit, max) + (flat ? "|flat" : "");
    // B1: nén JPEG duy nhất một lần ở cuối đường ống
    const blob = await finish(g, { filter: edit.filter, brightness: edit.brightness, contrast: edit.contrast, preFlat: flat, tools: edit.tools, level: edit.level ?? 100, q: as === "blob" ? 0.9 : 0.92 }, gk);
    // CS-17c: bản đầy đủ (> cỡ xem trước) dựng một lần ở nền — không giữ hình học/chuẩn sáng 15–35 MB mỗi trang trong bộ đệm
    // (đo: 20 trang giữ ~140 MB sau khi dựng xong). Cỡ xem trước vẫn giữ để đổi bộ lọc nhanh.
    if (max > PREVIEW_LONG) { geoCache.delete(geoKey(orig, edit, max)); geoCache.delete(geoKey(orig, edit, max) + "|flat"); }
    const out = as === "data" ? await fileToDataUrl(blob)
      : as === "page" ? adoptBlob(blob) // CS-12: ảnh trang dạng Blob đã đăng ký
      : URL.createObjectURL(blob);
    if (as !== "page") resultCache.set(k, out); return out; // "page": URL thuộc tài liệu (có thể bị thu hồi khi xoá) → không giữ trong bộ đệm
  });
}

/** Dựng đầy đủ (A4 300 dpi mặc định) – dùng khi lưu/xuất. Trả data URL. */
export function renderPage(orig: string, edit: PageEdit, max: number = TARGET_LONG.high) { return renderTo(orig, edit, max, "data"); }
/** CS-12: như renderPage nhưng trả object URL ĐÃ ĐĂNG KÝ (disk-pack) — lưu tài liệu/nhật ký không phải giải base64. */
export function renderPageUrl(orig: string, edit: PageEdit, max: number = TARGET_LONG.high) { return renderTo(orig, edit, max, "page"); }
/** CS-12: ảnh gốc từ khung chụp → Blob JPEG → object URL đã đăng ký (không qua data URL). */
export async function normalizeUrl(src: string | Blob | CanvasImageSource, max = 2000, q = 0.9) { return adoptBlob(await normalizeBlob(src, max, q)); }
/** Tầng xem trước ~1200 px, trả object URL (bộ đệm sở hữu – không tự revoke). */
export function renderPreview(orig: string, edit: PageEdit) { return renderTo(orig, edit, PREVIEW_LONG, "blob"); }

function otsu(g: Uint8ClampedArray | number[]) {
  const hist = new Array(256).fill(0); for (const v of g) hist[v | 0]++;
  const total = g.length; let sum = 0; for (let i = 0; i < 256; i++) sum += i * hist[i];
  let sumB = 0, wB = 0, best = 0, t = 127;
  for (let i = 0; i < 256; i++) {
    wB += hist[i]; if (!wB) continue; const wF = total - wB; if (!wF) break;
    sumB += i * hist[i]; const mB = sumB / wB, mF = (sum - sumB) / wF; const between = wB * wF * (mB - mF) ** 2;
    if (between > best) { best = between; t = i; }
  }
  return t;
}
function grayscale(src: CanvasImageSource, w: number, h: number) {
  const [c, ctx] = canvas(w, h); ctx.drawImage(src, 0, 0, w, h);
  const d = ctx.getImageData(0, 0, w, h).data; const g = new Uint8ClampedArray(w * h);
  for (let i = 0; i < g.length; i++) g[i] = d[i * 4] * 0.3 + d[i * 4 + 1] * 0.59 + d[i * 4 + 2] * 0.11;
  return g;
}

/** Find the paper sheet (edge + straight-line based). Returns null if nothing convincing. */
export function detectQuad(src: CanvasImageSource, sw: number, sh: number, size = 360): Quad | null {
  const d = detectPaper(src, sw, sh, size);
  return d && d.score > 0.35 ? d.quad : null;
}
/** S2: dò nhanh trên khung hình kèm điểm tin cậy (không cần giải mã ảnh gốc). */
export function detectQuadScored(src: CanvasImageSource, sw: number, sh: number, size = 720): { quad: Quad; score: number } | null {
  const d = detectPaper(src, sw, sh, size);
  return d && d.score > 0.35 ? { quad: d.quad, score: d.score } : null;
}
export async function detectQuadFromSrc(src: string) {
  const quad = await withDecoded(src, async (img) => { const d = await detectPaperAsync(img, img.naturalWidth, img.naturalHeight, 640); return d && d.score > 0.35 ? d.quad : null; });
  if (!quad) return null;
  return refineQuadOnSrc(src, quad);
}
/**
 * Local detection plus a trust flag. Not sure = weak score or a side lying on the image border
 * (sheet edge not actually seen, e.g. white paper on white paper) — callers should then ask the AI.
 */
export async function detectQuadInfo(src: string): Promise<{ quad: Quad | null; sure: boolean }> {
  return withDecoded(src, async (img) => {
  // CS-17d: dò khung trong Worker (luồng chính chỉ lấy mẫu RGBA) — kết quả giống hệt detectPaper
  const d = await detectPaperAsync(img, img.naturalWidth, img.naturalHeight, 640);
  if (!d || d.score <= 0.35) return { quad: null, sure: false };
  const e = 0.012, q = d.quad;
  const onEdge = [0, 1, 2, 3].some((i) => { const a = q[i], b = q[(i + 1) % 4];
    return (a[0] < e && b[0] < e) || (a[1] < e && b[1] < e) || (a[0] > 1 - e && b[0] > 1 - e) || (a[1] > 1 - e && b[1] > 1 - e); });
  let sure = d.score >= 0.7 && !onEdge;
  const refined = await refineQuadOnSrc(src, q);
  // S15l/V10: dò chồng giấy trên khung ĐÃ tinh chỉnh (khung thô có thể bám vào mép tờ lót)
  if (sure) { await yieldTask(); sure = !(await looksStacked(img, refined)); }
  return { quad: refined, sure };
  });
}
async function looksStacked(img: HTMLImageElement, q: Quad): Promise<boolean> {
  try {
    const { stackedSides } = await import("./paper-stack");
    const s = 640 / Math.max(img.naturalWidth, img.naturalHeight);
    const w = Math.max(1, Math.round(img.naturalWidth * s)), h = Math.max(1, Math.round(img.naturalHeight * s));
    const c = document.createElement("canvas"); c.width = w; c.height = h;
    const x = c.getContext("2d", { willReadFrequently: true }); if (!x) return false;
    x.drawImage(img, 0, 0, w, h);
    const rgba = x.getImageData(0, 0, w, h).data, g = new Uint8Array(w * h);
    for (let i = 0; i < g.length; i++) g[i] = (rgba[i * 4] * 77 + rgba[i * 4 + 1] * 150 + rgba[i * 4 + 2] * 29) >> 8;
    return stackedSides({ data: g, w, h }, q).length > 0;
  } catch { return false; }
}
/** Snap a rough quad (e.g. from the AI model) onto real paper edges of the original. */
export async function refineQuadOnSrc(src: string, quad: Quad) {
  // B3: dùng ảnh đã giải mã trong bộ đệm, chỉ đọc 4 dải quanh cạnh (không getImageData cả ảnh 4096 px)
  return withDecoded(src, (img) => {
  const W = img.naturalWidth, H = img.naturalHeight, pad = 24;
  const strips = [0, 1, 2, 3].map((i) => {
    const b = edgeStripBox(quad, W, H, i, pad);
    const [c, ctx] = canvas(b.w, b.h);
    ctx.drawImage(img, b.x, b.y, b.w, b.h, 0, 0, b.w, b.h);
    const data = ctx.getImageData(0, 0, b.w, b.h).data; c.width = 0;
    return { ...b, data };
  });
  return refineQuadSampler(stripSampler(strips), W, H, quad);
  });
}

/** Cheap luminance signature for stability checks while auto-capturing. */
export function frameSignature(video: HTMLVideoElement) {
  return grayscale(video, 32, 24);
}
export function frameDiff(a: Uint8ClampedArray, b: Uint8ClampedArray) {
  let s = 0; for (let i = 0; i < a.length; i++) s += Math.abs(a[i] - b[i]); return s / a.length;
}

export async function splitBook(src: string) {
  const img = await loadImg(src); const W = img.naturalWidth, H = img.naturalHeight;
  return [0, 1].map((i) => { const [c, ctx] = canvas(W / 2, H); ctx.drawImage(img, -i * (W / 2), 0); return toJpeg(c); });
}

/** Place both sides of an ID card at real size (85.6 × 54 mm) on an A4 sheet. */
export async function composeIdCard(front: string, back: string) {
  const px = 150 / 25.4; const [c, ctx] = canvas(210 * px, 297 * px);
  ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, c.width, c.height);
  const cw = 85.6 * px, ch = 54 * px, x = (c.width - cw) / 2;
  for (const [i, s] of [front, back].entries()) {
    const img = await loadImg(s); ctx.drawImage(img, x, 50 * px + i * (ch + 30 * px), cw, ch);
  }
  return toJpeg(c, 0.92);
}

export async function compress(src: string, max = 1400, q = 0.6) { return normalize(src, max, q); }

/** Count distinct objects on a contrasting background. Returns count + annotated image. */
export async function countObjects(src: string) {
  const img = await loadImg(src); const s = 360 / Math.max(img.naturalWidth, img.naturalHeight);
  const w = Math.round(img.naturalWidth * s), h = Math.round(img.naturalHeight * s);
  const g = grayscale(img, w, h); const t = otsu(g);
  let dark = 0; for (const v of g) if (v <= t) dark++;
  const fgDark = dark < g.length / 2;
  const mask = new Uint8Array(w * h); for (let i = 0; i < g.length; i++) mask[i] = (fgDark ? g[i] <= t : g[i] > t) ? 1 : 0;
  const label = new Int32Array(w * h); const boxes: number[][] = []; const minArea = w * h * 0.0008;
  for (let i = 0; i < mask.length; i++) {
    if (!mask[i] || label[i]) continue;
    const stack = [i]; label[i] = 1; let area = 0, x0 = w, y0 = h, x1 = 0, y1 = 0;
    while (stack.length) {
      const p = stack.pop()!; area++; const x = p % w, y = (p / w) | 0;
      x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y);
      for (const q of [p - 1, p + 1, p - w, p + w]) if (q >= 0 && q < mask.length && mask[q] && !label[q] && Math.abs((q % w) - x) <= 1) { label[q] = 1; stack.push(q); }
    }
    if (area >= minArea && area < w * h * 0.5) boxes.push([x0, y0, x1, y1]);
  }
  const [c, ctx] = canvas(img.naturalWidth, img.naturalHeight); ctx.drawImage(img, 0, 0);
  ctx.strokeStyle = "#00BFA5"; ctx.lineWidth = Math.max(3, c.width / 250); ctx.fillStyle = "#00BFA5"; ctx.font = `bold ${Math.max(16, c.width / 40)}px sans-serif`;
  boxes.forEach(([a, b, cc, d], i) => { ctx.strokeRect(a / s, b / s, (cc - a) / s, (d - b) / s); ctx.fillText(String(i + 1), a / s, b / s - 4); });
  return { count: boxes.length, image: toJpeg(c) };
}

/** Overlay a transparent drawing (signature / annotation) onto a page image. */
export async function stamp(base: string, overlay: string) {
  const [a, b] = await Promise.all([loadImg(base), loadImg(overlay)]);
  const [c, ctx] = canvas(a.naturalWidth, a.naturalHeight); ctx.drawImage(a, 0, 0); ctx.drawImage(b, 0, 0, c.width, c.height);
  return toJpeg(c, 0.92);
}

/** Focus/shake score: variance of the Laplacian on a ~480px grey copy (optionally only inside the paper quad).
 *  Higher = sharper. Scale-normalised so video frames and full-res stills are comparable. */
export function sharpness(src: CanvasImageSource, sw: number, sh: number, quad?: Quad | null) {
  const s = 480 / Math.max(sw, sh); const w = Math.max(8, Math.round(sw * s)), h = Math.max(8, Math.round(sh * s));
  const g = grayscale(src, w, h);
  let x0 = 1, y0 = 1, x1 = w - 1, y1 = h - 1;
  if (quad) { const xs = quad.map((p) => p[0] * w), ys = quad.map((p) => p[1] * h);
    x0 = Math.max(1, Math.round(Math.min(...xs) + w * 0.03)); x1 = Math.min(w - 1, Math.round(Math.max(...xs) - w * 0.03));
    y0 = Math.max(1, Math.round(Math.min(...ys) + h * 0.03)); y1 = Math.min(h - 1, Math.round(Math.max(...ys) - h * 0.03)); }
  let sum = 0, sq = 0, n = 0;
  for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
    const i = y * w + x; const l = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w];
    sum += l; sq += l * l; n++; }
  return n ? sq / n - (sum / n) ** 2 : 0;
}

/** Share of blown-out (glare) pixels inside the paper area, 0..1. */
export function glare(src: CanvasImageSource, sw: number, sh: number, quad?: Quad | null) {
  const s = 240 / Math.max(sw, sh); const w = Math.max(8, Math.round(sw * s)), h = Math.max(8, Math.round(sh * s));
  const [c, ctx] = canvas(w, h); ctx.drawImage(src, 0, 0, w, h); const d = ctx.getImageData(0, 0, w, h).data;
  let x0 = 0, y0 = 0, x1 = w, y1 = h;
  if (quad) { const xs = quad.map((p) => p[0] * w), ys = quad.map((p) => p[1] * h);
    x0 = Math.max(0, Math.round(Math.min(...xs))); x1 = Math.min(w, Math.round(Math.max(...xs)));
    y0 = Math.max(0, Math.round(Math.min(...ys))); y1 = Math.min(h, Math.round(Math.max(...ys))); }
  let hot = 0, n = 0;
  for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) { const i = (y * w + x) * 4; n++;
    if (d[i] > 250 && d[i + 1] > 250 && d[i + 2] > 250) hot++; }
  c.width = 0; return n ? hot / n : 0;
}

/** How strongly the phone is tilted: 0 = flat above the page, ~0.3+ = strong angle. */
export function tilt(q: Quad) {
  const L = (a: number[], b: number[]) => Math.hypot(a[0] - b[0], a[1] - b[1]);
  const top = L(q[0], q[1]), bot = L(q[3], q[2]), lef = L(q[0], q[3]), rig = L(q[1], q[2]);
  return Math.max(Math.abs(top - bot) / Math.max(top, bot), Math.abs(lef - rig) / Math.max(lef, rig));
}

/** Bản ảnh tăng cường cho lần đọc AI thứ 2: thẳng hoá, xám, kéo giãn tương phản, khử nhiễu nhẹ, làm nét, cỡ tối ưu OCR. */
export async function enhanceForOcr(src: string, max = 1600) {
  const img = await loadImg(src);
  const s = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
  let [c, ctx] = canvas(Math.round(img.naturalWidth * s), Math.round(img.naturalHeight * s));
  ctx.imageSmoothingQuality = "high"; ctx.drawImage(img, 0, 0, c.width, c.height);
  c = await deskew(c); ctx = c.getContext("2d")!;
  const W = c.width, H = c.height, im = ctx.getImageData(0, 0, W, H), d = im.data, n = W * H;
  const g = new Float32Array(n); const hist = new Uint32Array(256);
  for (let p = 0; p < n; p++) { const v = 0.299 * d[p * 4] + 0.587 * d[p * 4 + 1] + 0.114 * d[p * 4 + 2]; g[p] = v; hist[v | 0]++; }
  let lo = 0, hi = 255, acc = 0; for (; lo < 255 && (acc += hist[lo]) < n * 0.01; lo++); acc = 0; for (; hi > 0 && (acc += hist[hi]) < n * 0.01; hi--);
  const range = Math.max(30, hi - lo);
  // khử nhiễu 3x3 trung bình có trọng số rồi kéo giãn tương phản
  const out = new Uint8ClampedArray(n * 4);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const p = y * W + x; let v = g[p];
    if (x > 0 && y > 0 && x < W - 1 && y < H - 1) v = (4 * g[p] + g[p - 1] + g[p + 1] + g[p - W] + g[p + W]) / 8;
    v = ((v - lo) / range) * 255;
    out[p * 4] = out[p * 4 + 1] = out[p * 4 + 2] = v; out[p * 4 + 3] = 255;
  }
  unsharpPx(out, W, H, 0.8);
  d.set(out); ctx.putImageData(im, 0, 0);
  return toJpeg(c, 0.85);
}
