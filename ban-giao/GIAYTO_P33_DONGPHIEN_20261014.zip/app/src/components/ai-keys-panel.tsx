// AI-04 (QD-12): Tôi → "Khoá AI của tôi": nhập/đổi/xoá key, chọn mô hình Claude, đổi thứ tự nguồn, nút Kiểm tra từng nguồn.
import { useServerFn } from "@tanstack/react-start";
import { ArrowDown, ArrowUp, KeyRound, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { aiKeyCheck } from "@/lib/ai.functions";
import { AI_PROVIDER_ORDER, CLAUDE_MODELS, clearAiKeys, cleanKeys, loadAiKeys, maskKey, saveAiKeys, type AiKeys, type AiProvider } from "@/lib/ai-keys";
import { confirmDialog } from "@/lib/dialog";

const NAME: Record<AiProvider, string> = { lovable: "Lovable AI (máy chủ)", claude: "Claude", mistral: "Mistral (miễn phí)", gemini: "Gemini (miễn phí)" };
const HINT: Partial<Record<AiProvider, string>> = { claude: "sk-ant-…", mistral: "Key Mistral", gemini: "AIza…" };
const STATUS: Record<string, string> = { ready: "Sẵn sàng", "bad-key": "Key sai", quota: "Hết lượt / quá tải", error: "Lỗi — thử lại sau", "no-key": "Chưa có key" };
type KeyProvider = "claude" | "mistral" | "gemini";
const KEYED: KeyProvider[] = ["claude", "mistral", "gemini"];

export function AiKeysPanel() {
  const check = useServerFn(aiKeyCheck);
  const [saved, setSaved] = useState<AiKeys>({});
  const [locked, setLocked] = useState(false);
  const [draft, setDraft] = useState<Record<KeyProvider, string>>({ claude: "", mistral: "", gemini: "" });
  const [model, setModel] = useState<string>(CLAUDE_MODELS[0].id);
  const [order, setOrder] = useState<AiProvider[]>([...AI_PROVIDER_ORDER]);
  const [status, setStatus] = useState<Partial<Record<AiProvider, string>>>({});
  const [busy, setBusy] = useState("");
  const apply = (k: AiKeys | null) => { const v = k ?? {}; setSaved(v); setModel(v.claudeModel ?? CLAUDE_MODELS[0].id); setOrder(v.order?.length ? [...v.order, ...AI_PROVIDER_ORDER.filter((p) => !v.order!.includes(p))] : [...AI_PROVIDER_ORDER]); };
  useEffect(() => { void loadAiKeys().then((r) => { setLocked(r.locked); apply(r.keys); }).catch(() => {}); }, []);

  const save = async (quiet = false) => {
    const next: AiKeys = { ...saved, claudeModel: model, order };
    for (const p of KEYED) if (draft[p].trim()) next[p] = draft[p].trim();
    const mode = await saveAiKeys(next); apply(cleanKeys(next)); setDraft({ claude: "", mistral: "", gemini: "" });
    if (!quiet) toast.success(mode === "pin" ? "Đã lưu khoá AI (trong két PIN)" : "Đã lưu khoá AI (mã hoá trên máy này)");
  };
  const remove = async (p: KeyProvider) => { const next = { ...saved }; delete next[p]; await saveAiKeys(next); apply(cleanKeys(next)); setStatus((s) => ({ ...s, [p]: undefined })); toast(`Đã xoá key ${NAME[p]}`); };
  const test = async (p: AiProvider) => {
    setBusy(p);
    try {
      if (p !== "lovable" && draft[p as KeyProvider].trim()) await save(true);
      const r = await check({ data: { provider: p } });
      setStatus((s) => ({ ...s, [p]: r.ok ? "ready" : r.status }));
    } catch { setStatus((s) => ({ ...s, [p]: "error" })); } finally { setBusy(""); }
  };
  const move = (i: number, d: -1 | 1) => setOrder((o) => { const n = [...o]; const j = i + d; if (j < 0 || j >= n.length) return o; [n[i], n[j]] = [n[j]!, n[i]!]; return n; });

  if (locked) return <p className="p-4 text-sm text-muted-foreground" role="status">Khoá AI đang nằm trong két PIN — mở khoá PIN để xem hoặc sửa.</p>;
  return (
    <div className="space-y-4 p-4" data-testid="ai-keys">
      <p className="text-xs text-muted-foreground">Key được mã hoá trên máy này (bật mã PIN thì nằm trong két PIN); không có trong sao lưu, đồng bộ hay báo lỗi. Claude không có gói miễn phí (nạp tiền trong Anthropic Console); Mistral/Gemini miễn phí nhưng có thể dùng dữ liệu để huấn luyện nên giấy tờ nhạy cảm không gửi tới đó.</p>
      {KEYED.map((p) => (
        <div key={p} className="space-y-1.5">
          <div className="flex items-center justify-between gap-2 text-sm"><span className="font-semibold">{NAME[p]}</span>
            <span data-testid={`ai-key-${p}`} className="text-xs text-muted-foreground">{saved[p] ? maskKey(saved[p]) : "chưa có"}</span></div>
          <div className="flex gap-2">
            <input type="password" autoComplete="off" spellCheck={false} aria-label={`Key ${NAME[p]}`} placeholder={saved[p] ? "Dán key mới để đổi" : HINT[p]} value={draft[p]}
              onChange={(e) => setDraft((d) => ({ ...d, [p]: e.target.value }))} className="h-11 min-w-0 flex-1 rounded-[12px] border border-border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/40" />
            <button type="button" onClick={() => void test(p)} disabled={!!busy || (!saved[p] && !draft[p].trim())} className="h-11 shrink-0 rounded-[12px] border border-border px-3 text-xs font-semibold disabled:opacity-50">{busy === p ? <Loader2 className="size-4 animate-spin" /> : "Kiểm tra"}</button>
            {saved[p] && <button type="button" onClick={() => void remove(p)} className="h-11 shrink-0 rounded-[12px] px-2 text-xs text-destructive">Xoá</button>}
          </div>
          {status[p] && <p role="status" data-testid={`ai-status-${p}`} className={`text-xs ${status[p] === "ready" ? "text-primary" : "text-destructive"}`}>{STATUS[status[p]!]}</p>}
        </div>
      ))}
      <label className="block space-y-1.5 text-sm"><span className="font-semibold">Mô hình Claude</span>
        <select aria-label="Mô hình Claude" value={model} onChange={(e) => setModel(e.target.value)} className="h-11 w-full rounded-[12px] border border-border bg-background px-3 text-sm">
          {CLAUDE_MODELS.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
        </select></label>
      <div className="space-y-1.5"><p className="text-sm font-semibold">Thứ tự dùng nguồn AI</p>
        <ol className="space-y-1" data-testid="ai-order">{order.map((p, i) => (
          <li key={p} className="flex items-center justify-between gap-2 rounded-[12px] bg-secondary/50 pl-3 text-sm"><span>{i + 1}. {NAME[p]}</span>
            <span className="flex">
              <button type="button" aria-label={`Đưa ${NAME[p]} lên`} disabled={i === 0} onClick={() => move(i, -1)} className="grid size-11 place-items-center disabled:opacity-30"><ArrowUp className="size-4" /></button>
              <button type="button" aria-label={`Đưa ${NAME[p]} xuống`} disabled={i === order.length - 1} onClick={() => move(i, 1)} className="grid size-11 place-items-center disabled:opacity-30"><ArrowDown className="size-4" /></button>
            </span></li>))}</ol></div>
      <div className="flex gap-2">
        <button type="button" onClick={() => void save()} className="flex h-11 flex-1 items-center justify-center gap-2 rounded-[12px] bg-primary text-sm font-semibold text-primary-foreground"><KeyRound className="size-4" /> Lưu khoá AI</button>
        <button type="button" onClick={async () => { if (await confirmDialog("Xoá mọi khoá AI trên máy này?", { okText: "Xoá", danger: true })) { await clearAiKeys(); apply(null); setStatus({}); toast("Đã xoá khoá AI"); } }} className="h-11 rounded-[12px] border border-border px-3 text-sm">Xoá hết</button>
      </div>
      <button type="button" onClick={() => void test("lovable")} disabled={!!busy} className="text-xs text-muted-foreground underline">{busy === "lovable" ? "Đang kiểm tra…" : "Kiểm tra Lovable AI (key máy chủ)"}</button>
      {status["lovable"] && <p role="status" data-testid="ai-status-lovable" className="text-xs">{STATUS[status["lovable"]]}</p>}
    </div>
  );
}
