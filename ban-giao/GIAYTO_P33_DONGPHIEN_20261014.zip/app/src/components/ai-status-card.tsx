// AI-02: Tôi → "Tình trạng AI": từng nguồn (thứ tự dùng), có key máy chủ hay key của bạn, kết quả gần nhất; nguồn đang phục vụ (dự phòng?).
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { aiProviders } from "@/lib/ai.functions";
import { AI_NAME, providerState, readAiStatus, type AiProviderId } from "@/lib/ai-status";

type Row = { id: AiProviderId; label: string; free: boolean; keySource: "user" | "server" | null; enabled: boolean };
const DOT = { ok: "bg-emerald-500", warn: "bg-amber-500", off: "bg-muted-foreground/50" } as const;

export function AiStatusCard() {
  const load = useServerFn(aiProviders);
  const [rows, setRows] = useState<Row[] | null>(null);
  const [err, setErr] = useState(false);
  const [tick, setTick] = useState(0);
  useEffect(() => { let live = true; setErr(false); load().then((r) => { if (live) setRows(r.providers as Row[]); }).catch(() => { if (live) setErr(true); }); return () => { live = false; }; }, [load, tick]);
  // đọc localStorage SAU khi gắn (tránh lệch hydrate React #418)
  const [st, setSt] = useState<ReturnType<typeof readAiStatus>>({ providers: {} });
  useEffect(() => { setSt(readAiStatus()); }, [rows, tick]);
  const last = st.last;
  return (
    <div className="space-y-1 p-4" data-testid="ai-status">
      {err && <p role="status" className="text-sm text-muted-foreground">Không hỏi được máy chủ (mất mạng?) — việc AI sẽ chờ có mạng.</p>}
      {!rows && !err && <p className="text-sm text-muted-foreground">Đang kiểm tra…</p>}
      {rows?.map((r, i) => { const s = providerState(r.keySource, r.enabled, st.providers[r.id]); return (
        <div key={r.id} data-provider={r.id} data-state={s.state} className="flex min-h-[44px] items-center gap-3 text-sm">
          <span aria-hidden className={`size-2.5 shrink-0 rounded-full ${DOT[s.state]}`} />
          <span className="min-w-0 flex-1"><span className="font-medium">{i + 1}. {r.label}</span>{r.free && <span className="ml-1 text-[0.6875rem] text-muted-foreground">(miễn phí, không nhận giấy tờ nhạy cảm)</span>}</span>
          <span className={`shrink-0 text-xs ${s.state === "warn" ? "text-amber-600" : "text-muted-foreground"}`}>{s.text}</span>
        </div>); })}
      {last && <p data-testid="ai-last" className="pt-1 text-xs text-muted-foreground">Lần gần nhất: {AI_NAME[last.source]}{last.fallback ? " (nguồn dự phòng)" : ""} · {new Date(last.at).toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" })}</p>}
      <button type="button" onClick={() => setTick((n) => n + 1)} className="min-h-[44px] text-xs font-semibold text-primary">Làm mới</button>
    </div>
  );
}
