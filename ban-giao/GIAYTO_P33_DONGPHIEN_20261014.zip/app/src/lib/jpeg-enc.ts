/**
 * CS-21 (QP-04, QP-05): bộ mã hoá JPEG baseline thuần TS — XÁM 1 kênh và MÀU 4:4:4 (không lấy mẫu thưa sắc độ).
 * canvas.toBlob/convertToBlob của Chromium luôn 4:2:0 3 kênh (chỉ q = 1 mới 4:4:4) → trang Xám vẫn mang 2 kênh màu thừa,
 * chữ/dấu đỏ bị lem viền. Bảng lượng tử IJG chuẩn (Annex K) co theo chất lượng như libjpeg; bảng Huffman chuẩn.
 * Chạy được trong Worker (không DOM).
 */
const ZZ = [0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63];
const QL = [16, 11, 10, 16, 24, 40, 51, 61, 12, 12, 14, 19, 26, 58, 60, 55, 14, 13, 16, 24, 40, 57, 69, 56, 14, 17, 22, 29, 51, 87, 80, 62, 18, 22, 37, 56, 68, 109, 103, 77, 24, 35, 55, 64, 81, 104, 113, 92, 49, 64, 78, 87, 103, 121, 120, 101, 72, 92, 95, 98, 112, 100, 103, 99];
const QC = [17, 18, 24, 47, 99, 99, 99, 99, 18, 21, 26, 66, 99, 99, 99, 99, 24, 26, 56, 99, 99, 99, 99, 99, 47, 66, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99];
// Annex K.3 — bảng Huffman chuẩn: số mã theo độ dài 1..16 + giá trị
const DC_L = { n: [0, 1, 5, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0], v: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] };
const DC_C = { n: [0, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0], v: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] };
const AC_L = { n: [0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 0x7d], v: [
  0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21, 0x31, 0x41, 0x06, 0x13, 0x51, 0x61, 0x07, 0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xa1, 0x08,
  0x23, 0x42, 0xb1, 0xc1, 0x15, 0x52, 0xd1, 0xf0, 0x24, 0x33, 0x62, 0x72, 0x82, 0x09, 0x0a, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x25, 0x26, 0x27, 0x28,
  0x29, 0x2a, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59,
  0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89,
  0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6,
  0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7, 0xc8, 0xc9, 0xca, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda, 0xe1, 0xe2,
  0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8, 0xf9, 0xfa] };
const AC_C = { n: [0, 2, 1, 2, 4, 4, 3, 4, 7, 5, 4, 4, 0, 1, 2, 0x77], v: [
  0x00, 0x01, 0x02, 0x03, 0x11, 0x04, 0x05, 0x21, 0x31, 0x06, 0x12, 0x41, 0x51, 0x07, 0x61, 0x71, 0x13, 0x22, 0x32, 0x81, 0x08, 0x14, 0x42, 0x91,
  0xa1, 0xb1, 0xc1, 0x09, 0x23, 0x33, 0x52, 0xf0, 0x15, 0x62, 0x72, 0xd1, 0x0a, 0x16, 0x24, 0x34, 0xe1, 0x25, 0xf1, 0x17, 0x18, 0x19, 0x1a, 0x26,
  0x27, 0x28, 0x29, 0x2a, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58,
  0x59, 0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
  0x88, 0x89, 0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4,
  0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7, 0xc8, 0xc9, 0xca, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda,
  0xe2, 0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8, 0xf9, 0xfa] };

type Huff = { code: Uint16Array; len: Uint8Array };
function huff(t: { n: number[]; v: number[] }): Huff {
  const code = new Uint16Array(256), len = new Uint8Array(256);
  let c = 0, k = 0;
  for (let l = 1; l <= 16; l++) { for (let i = 0; i < t.n[l - 1]; i++) { code[t.v[k]] = c; len[t.v[k]] = l; c++; k++; } c <<= 1; }
  return { code, len };
}
/** Bảng lượng tử theo chất lượng 1–100 (công thức libjpeg jpeg_quality_scaling). */
export function quantTable(base: number[], quality: number) {
  const q = Math.min(100, Math.max(1, Math.round(quality)));
  const s = q < 50 ? 5000 / q : 200 - q * 2;
  return base.map((b) => Math.min(255, Math.max(1, Math.floor((b * s + 50) / 100))));
}
// DCT 8×8 tách hàng/cột với bảng cos dựng sẵn
const COS = new Float64Array(64);
for (let u = 0; u < 8; u++) for (let x = 0; x < 8; x++) COS[u * 8 + x] = Math.cos(((2 * x + 1) * u * Math.PI) / 16) * (u === 0 ? Math.SQRT1_2 : 1) / 2;

class Bits {
  buf: Uint8Array; n = 0; acc = 0; nb = 0;
  constructor(size: number) { this.buf = new Uint8Array(size); }
  private grow(k: number) { if (this.n + k > this.buf.length) { const b = new Uint8Array(Math.max(this.buf.length * 2, this.n + k + 1024)); b.set(this.buf); this.buf = b; } }
  byte(b: number) { this.grow(1); this.buf[this.n++] = b; }
  bytes(a: number[]) { for (const b of a) this.byte(b); }
  put(code: number, len: number) {
    this.acc = (this.acc << len) | code; this.nb += len;
    while (this.nb >= 8) { const b = (this.acc >>> (this.nb - 8)) & 255; this.byte(b); if (b === 255) this.byte(0); this.nb -= 8; }
    this.acc &= (1 << this.nb) - 1;
  }
  flush() { if (this.nb > 0) this.put((1 << (8 - this.nb)) - 1, 8 - this.nb); }
}
const cat = (v: number) => { let a = v < 0 ? -v : v, n = 0; while (a) { n++; a >>= 1; } return n; };

/**
 * Mã hoá ảnh RGBA (w×h) thành JPEG baseline. gray = true → 1 kênh độ sáng (Y); ngược lại YCbCr 4:4:4.
 * quality theo thang 1–100 như libjpeg (0,82 → 82).
 */
export function encodeJpeg(rgba: Uint8ClampedArray | Uint8Array, w: number, h: number, quality: number, gray: boolean): Uint8Array {
  const nc = gray ? 1 : 3;
  const ql = quantTable(QL, quality), qc = quantTable(QC, quality);
  const dcL = huff(DC_L), acL = huff(AC_L), dcC = huff(DC_C), acC = huff(AC_C);
  const out = new Bits(Math.max(4096, (w * h * nc) >> 3));
  // tiêu đề
  out.bytes([0xff, 0xd8, 0xff, 0xe0, 0, 16, 0x4a, 0x46, 0x49, 0x46, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0]);
  const dqt = (id: number, t: number[]) => { out.bytes([0xff, 0xdb, 0, 67, id]); for (let i = 0; i < 64; i++) out.byte(t[ZZ[i]]); };
  dqt(0, ql); if (!gray) dqt(1, qc);
  out.bytes([0xff, 0xc0, 0, 8 + nc * 3, 8, h >> 8, h & 255, w >> 8, w & 255, nc]);
  for (let c = 0; c < nc; c++) out.bytes([c + 1, 0x11, c === 0 ? 0 : 1]);
  const dht = (cls: number, id: number, t: { n: number[]; v: number[] }) => { out.bytes([0xff, 0xc4, 0, 19 + t.v.length, (cls << 4) | id, ...t.n, ...t.v]); };
  dht(0, 0, DC_L); dht(1, 0, AC_L); if (!gray) { dht(0, 1, DC_C); dht(1, 1, AC_C); }
  out.bytes([0xff, 0xda, 0, 6 + nc * 2, nc]);
  for (let c = 0; c < nc; c++) out.bytes([c + 1, c === 0 ? 0 : 0x11]);
  out.bytes([0, 63, 0]);
  // dữ liệu
  const blk = new Float64Array(64), tmp = new Float64Array(64), coef = new Int32Array(64);
  const pred = [0, 0, 0];
  const fdivL = ql.map((q) => 1 / q), fdivC = qc.map((q) => 1 / q);
  const enc = (c: number, bx: number, by: number) => {
    for (let y = 0; y < 8; y++) {
      const yy = Math.min(h - 1, by + y);
      for (let x = 0; x < 8; x++) {
        const i = (yy * w + Math.min(w - 1, bx + x)) * 4, r = rgba[i], g = rgba[i + 1], b = rgba[i + 2];
        blk[y * 8 + x] = c === 0 ? 0.299 * r + 0.587 * g + 0.114 * b - 128 : c === 1 ? -0.168736 * r - 0.331264 * g + 0.5 * b : 0.5 * r - 0.418688 * g - 0.081312 * b;
      }
    }
    for (let y = 0; y < 8; y++) for (let u = 0; u < 8; u++) { let s = 0; for (let x = 0; x < 8; x++) s += COS[u * 8 + x] * blk[y * 8 + x]; tmp[y * 8 + u] = s; }
    const fd = c === 0 ? fdivL : fdivC;
    for (let u = 0; u < 8; u++) for (let v = 0; v < 8; v++) { let s = 0; for (let y = 0; y < 8; y++) s += COS[v * 8 + y] * tmp[y * 8 + u]; coef[v * 8 + u] = Math.round(s * fd[v * 8 + u]); }
    const dc = c === 0 ? dcL : dcC, ac = c === 0 ? acL : acC;
    const d = coef[0] - pred[c]; pred[c] = coef[0];
    const dn = cat(d); out.put(dc.code[dn], dc.len[dn]); if (dn) out.put(d < 0 ? d + (1 << dn) - 1 : d, dn);
    let run = 0;
    for (let k = 1; k < 64; k++) {
      const v = coef[ZZ[k]];
      if (!v) { run++; continue; }
      while (run > 15) { out.put(ac.code[0xf0], ac.len[0xf0]); run -= 16; }
      const n = cat(v), s = (run << 4) | n; out.put(ac.code[s], ac.len[s]); out.put(v < 0 ? v + (1 << n) - 1 : v, n); run = 0;
    }
    if (run) out.put(ac.code[0], ac.len[0]);
  };
  for (let by = 0; by < h; by += 8) for (let bx = 0; bx < w; bx += 8) for (let c = 0; c < nc; c++) enc(c, bx, by);
  out.flush(); out.bytes([0xff, 0xd9]);
  return out.buf.subarray(0, out.n);
}
