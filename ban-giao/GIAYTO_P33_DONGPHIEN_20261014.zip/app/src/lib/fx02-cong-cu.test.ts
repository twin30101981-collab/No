// FX-02: tìm công cụ không dấu + nhóm "Hay dùng" theo số lần dùng.
import { beforeEach, describe, expect, it } from "vitest";
import { fold, matchTool, readUses, recordUse, topUsed } from "./tool-usage";

describe("FX-02 công cụ", () => {
  beforeEach(() => localStorage.clear());
  it("tìm không dấu, nhiều từ, hoa thường", () => {
    expect(fold("  Đếm SỐ   vật ")).toBe("dem so vat");
    expect(matchTool("Ảnh → Word", "anh word")).toBe(true);
    expect(matchTool("Ghép PDF", "ghep")).toBe(true);
    expect(matchTool("Ghép PDF", "tach")).toBe(false);
    expect(matchTool("Mật khẩu", "")).toBe(true);
  });
  it("Hay dùng: nhiều lần trước, bằng nhau giữ thứ tự, bỏ nhãn không còn", () => {
    recordUse("Nén PDF"); recordUse("Nén PDF"); recordUse("Ghép PDF"); recordUse("Ảnh → PDF"); recordUse("Công cụ đã bỏ"); recordUse("Công cụ đã bỏ"); recordUse("Công cụ đã bỏ");
    expect(readUses()["Nén PDF"]).toBe(2);
    expect(topUsed(["Ảnh → PDF", "Ghép PDF", "Nén PDF", "Tách PDF"])).toEqual(["Nén PDF", "Ảnh → PDF", "Ghép PDF"]);
    expect(topUsed(["Ảnh → PDF", "Ghép PDF", "Nén PDF"], 1)).toEqual(["Nén PDF"]);
  });
  it("dữ liệu hỏng → rỗng, không lỗi", () => {
    localStorage.setItem("ghi-nhanh:tool-uses", "[1,2"); expect(readUses()).toEqual({});
    localStorage.setItem("ghi-nhanh:tool-uses", "[1,2]"); expect(readUses()).toEqual({});
    expect(topUsed(["A"])).toEqual([]);
  });
});
