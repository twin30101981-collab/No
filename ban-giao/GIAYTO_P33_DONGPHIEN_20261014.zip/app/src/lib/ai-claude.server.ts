/**
 * AI-01 (QD-13): nguồn Claude qua SDK chính thức @anthropic-ai/sdk — ảnh base64, đầu ra JSON theo schema (structured outputs).
 * Mô hình mặc định claude-opus-5-5 (đổi bằng ANTHROPIC_MODEL); bật fallbacks "default" phía máy chủ khi mô hình từ chối;
 * vẫn từ chối (stop_reason "refusal") → ném lỗi 451 để chuỗi chuyển nguồn kế. Hết giờ 60 s.
 */
import Anthropic from "@anthropic-ai/sdk";
import { AI_TIMEOUT_MS } from "./ai-chain.server";

export const CLAUDE_DEFAULT_MODEL = "claude-opus-5-5";
export type ClaudePart = { type: "text"; text: string } | { type: "image"; dataUrl: string };

const IMAGE_TYPES = ["image/jpeg", "image/png", "image/gif", "image/webp"] as const;
type ImageType = (typeof IMAGE_TYPES)[number];

/** data:image/…;base64,… → khối ảnh base64 của Messages API. */
export function imageBlock(dataUrl: string): Anthropic.ImageBlockParam {
  const m = /^data:(image\/[a-z+.-]+);base64,(.*)$/s.exec(dataUrl);
  if (!m) throw Object.assign(new Error("ảnh không phải data URL base64"), { statusCode: 400 });
  const media = (IMAGE_TYPES as readonly string[]).includes(m[1]!) ? (m[1] as ImageType) : "image/jpeg";
  return { type: "image", source: { type: "base64", media_type: media, data: m[2]! } };
}

export async function claudeGenerate(req: { system: string; parts: ClaudePart[]; schema?: Record<string, unknown> | undefined; apiKey: string; model?: string | undefined }): Promise<string> {
  const client = new Anthropic({ apiKey: req.apiKey, timeout: AI_TIMEOUT_MS, maxRetries: 1 });
  const content: Anthropic.ContentBlockParam[] = req.parts.map((p) => (p.type === "text" ? { type: "text" as const, text: p.text } : imageBlock(p.dataUrl)));
  const res = await client.beta.messages.create({
    model: req.model || CLAUDE_DEFAULT_MODEL,
    max_tokens: 16000,
    system: req.system,
    betas: ["server-side-fallback-2026-07-01"],
    fallbacks: "default",
    output_config: { effort: "medium", ...(req.schema ? { format: { type: "json_schema" as const, schema: req.schema } } : {}) },
    messages: [{ role: "user", content }],
  });
  if (res.stop_reason === "refusal") throw Object.assign(new Error("Claude từ chối yêu cầu"), { statusCode: 451, refusal: true, category: res.stop_details?.category ?? null });
  if (res.stop_reason === "max_tokens") throw Object.assign(new Error("Claude: vượt giới hạn độ dài trả lời"), { statusCode: 502 });
  const text = res.content.map((b) => (b.type === "text" ? b.text : "")).join("");
  if (!text.trim()) throw Object.assign(new Error("Claude: trả lời rỗng"), { statusCode: 502 });
  return text;
}
