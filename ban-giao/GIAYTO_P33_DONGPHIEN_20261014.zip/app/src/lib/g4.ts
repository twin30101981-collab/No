/**
 * CS-21 (QP-05): mã hoá ảnh 1-bit CCITT nhóm 4 (T.6, MMR) — chuẩn nén trang chữ đen trắng trong PDF (CCITTFaxDecode, K = -1).
 * Nhỏ hơn PNG 1-bit ~40 % trên trang chữ (đo P33: 61 KB so với 99 KB trang A4 300 dpi). Thuần TS, chạy trong Worker.
 * Thuật toán theo libtiff Fax3Encode2DRow. Ảnh vào: Uint8Array w×h, 0 = đen, khác 0 = trắng.
 */
const WT = "00110101 000111 0111 1000 1011 1100 1110 1111 10011 10100 00111 01000 001000 000011 110100 110101 101010 101011 0100111 0001100 0001000 0010111 0000011 0000100 0101000 0101011 0010011 0100100 0011000 00000010 00000011 00011010 00011011 00010010 00010011 00010100 00010101 00010110 00010111 00101000 00101001 00101010 00101011 00101100 00101101 00000100 00000101 00001010 00001011 01010010 01010011 01010100 01010101 00100100 00100101 01011000 01011001 01011010 01011011 01001010 01001011 00110010 00110011 00110100";
const WM = "11011 10010 010111 0110111 00110110 00110111 01100100 01100101 01101000 01100111 011001100 011001101 011010010 011010011 011010100 011010101 011010110 011010111 011011000 011011001 011011010 011011011 010011000 010011001 010011010 011000 010011011";
const BT = "0000110111 010 11 10 011 0011 0010 00011 000101 000100 0000100 0000101 0000111 00000100 00000111 000011000 0000010111 0000011000 0000001000 00001100111 00001101000 00001101100 00000110111 00000101000 00000010111 00000011000 000011001010 000011001011 000011001100 000011001101 000001101000 000001101001 000001101010 000001101011 000011010010 000011010011 000011010100 000011010101 000011010110 000011010111 000001101100 000001101101 000011011010 000011011011 000001010100 000001010101 000001010110 000001010111 000001100100 000001100101 000001010010 000001010011 000000100100 000000110111 000000111000 000000100111 000000101000 000001011000 000001011001 000000101011 000000101100 000001011010 000001100110 000001100111";
const BM = "0000001111 000011001000 000011001001 000001011011 000000110011 000000110100 000000110101 0000001101100 0000001101101 0000001001010 0000001001011 0000001001100 0000001001101 0000001110010 0000001110011 0000001110100 0000001110101 0000001110110 0000001110111 0000001010010 0000001010011 0000001010100 0000001010101 0000001011010 0000001011011 0000001100100 0000001100101";
/** Mã mở rộng 1792–2560 (chung trắng/đen). */
const XM = "00000001000 00000001100 00000001101 000000010010 000000010011 000000010100 000000010101 000000010110 000000010111 000000011100 000000011101 000000011110 000000011111";
type Code = [number, number]; // [giá trị, số bit]
const parse = (s: string): Code[] => s.split(" ").map((b) => [parseInt(b, 2), b.length]);
const T = { w: parse(WT), b: parse(BT) }, M = { w: parse(WM), b: parse(BM) }, X = parse(XM);
const V: Code[] = [[0b0000011, 7], [0b000011, 6], [0b011, 3], [0b1, 1], [0b010, 3], [0b000010, 6], [0b0000010, 7]]; // d = b1 − a1 = −3…3
const PASS: Code = [0b0001, 4], HORIZ: Code = [0b001, 3], EOL: Code = [0b000000000001, 12];

class Out {
  buf = new Uint8Array(1 << 16); n = 0; acc = 0; nb = 0;
  put([v, l]: Code) {
    this.acc = (this.acc << l) | v; this.nb += l;
    while (this.nb >= 8) {
      if (this.n >= this.buf.length) { const b = new Uint8Array(this.buf.length * 2); b.set(this.buf); this.buf = b; }
      this.buf[this.n++] = (this.acc >>> (this.nb - 8)) & 255; this.nb -= 8;
    }
    this.acc &= (1 << this.nb) - 1;
  }
  end() { if (this.nb) this.put([0, 8 - this.nb]); return this.buf.subarray(0, this.n); }
}
function span(o: Out, run: number, black: boolean) {
  const t = black ? T.b : T.w, m = black ? M.b : M.w;
  while (run >= 2624) { o.put(X[12]); run -= 2560; }
  if (run >= 64) {
    const k = run >> 6; // bội của 64
    if (k <= 27) o.put(m[k - 1]); else o.put(X[k - 28]);
    run -= k << 6;
  }
  o.put(t[run]);
}

/** px: 0 = đen. Trả dòng bit CCITT G4 (kết thúc bằng EOFB). */
export function encodeG4(px: Uint8Array, w: number, h: number): Uint8Array {
  const o = new Out();
  let ref = new Uint8Array(w), cur = new Uint8Array(w); // 1 = đen
  // vị trí đầu tiên ≥ s mà điểm khác màu c (c: 1 đen/0 trắng); hết dòng → w
  const diff = (l: Uint8Array, s: number, c: number) => { while (s < w && l[s] === c) s++; return s; };
  for (let y = 0; y < h; y++) {
    const row = y * w;
    for (let x = 0; x < w; x++) cur[x] = px[row + x] === 0 ? 1 : 0;
    let a0 = 0;
    let a1 = cur[0] ? 0 : diff(cur, 0, 0);
    let b1 = ref[0] ? 0 : diff(ref, 0, 0);
    for (;;) {
      const b2 = b1 < w ? diff(ref, b1, ref[b1]) : w;
      if (b2 >= a1) {
        const d = b1 - a1;
        if (d < -3 || d > 3) {
          const a2 = a1 < w ? diff(cur, a1, cur[a1]) : w;
          o.put(HORIZ);
          if (a0 + a1 === 0 || cur[a0] === 0) { span(o, a1 - a0, false); span(o, a2 - a1, true); }
          else { span(o, a1 - a0, true); span(o, a2 - a1, false); }
          a0 = a2;
        } else { o.put(V[d + 3]); a0 = a1; }
      } else { o.put(PASS); a0 = b2; }
      if (a0 >= w) break;
      const c = cur[a0];
      a1 = diff(cur, a0, c);
      b1 = diff(ref, a0, c ? 0 : 1);
      b1 = diff(ref, b1, c);
    }
    const t = ref; ref = cur; cur = t;
  }
  o.put(EOL); o.put(EOL);
  return o.end();
}

/** Gói G4 cho jsPDF (định dạng "G4" — xem files.ts): "G4\0\0" + rộng + cao (uint32 BE) + dòng bit. */
export function packG4(data: Uint8Array, w: number, h: number): Uint8Array {
  const out = new Uint8Array(12 + data.length), v = new DataView(out.buffer);
  out.set([0x47, 0x34, 0, 0]); v.setUint32(4, w); v.setUint32(8, h); out.set(data, 12);
  return out;
}
