/**
 * AI-02: nhớ kết quả AI gần nhất theo từng nguồn (chỉ tên nguồn, mã lỗi, giờ — không nội dung) để trang "Tình trạng AI" hiện Sẵn sàng /
 * Hết lượt / Lỗi key; báo một lần (tối đa mỗi 10 phút) khi việc AI vừa chạy bằng nguồn dự phòng.
 */
export type AiProviderId = "lovable" | "claude" | "mistral" | "gemini";
export const AI_NAME: Record<AiProviderId, string> = { lovable: "Lovable AI", claude: "Claude", mistral: "Mistral", gemini: "Gemini" };
type Tried = { provider: AiProviderId; code: number };
export type AiResultLike = { ok?: boolean; code?: number; source?: AiProviderId; tried?: Tried[] };
export type ProviderMemo = { at: number; ok: boolean; code?: number };
const KEY = "ghi-nhanh:ai-status", NOTE_EVERY = 10 * 60_000;

export function readAiStatus(): { last?: { source: AiProviderId; at: number; fallback: boolean }; providers: Partial<Record<AiProviderId, ProviderMemo>>; notedAt?: number } {
  try { const v = JSON.parse(localStorage.getItem(KEY) ?? "{}"); return v && typeof v === "object" && !Array.isArray(v) ? { providers: {}, ...v } : { providers: {} }; } catch { return { providers: {} }; }
}
/** Ghi một kết quả AI; trả tên nguồn dự phòng nếu cần báo người dùng (đã giãn 10 phút), ngược lại null. */
export function noteAiResult(r: unknown, now = Date.now()): string | null {
  if (!r || typeof r !== "object") return null;
  const x = r as AiResultLike; if (!x.source && !x.tried?.length) return null;
  const st = readAiStatus();
  for (const t of x.tried ?? []) st.providers[t.provider] = { at: now, ok: false, code: t.code };
  let note: string | null = null;
  if (x.ok && x.source) {
    st.providers[x.source] = { at: now, ok: true };
    const fallback = !!x.tried?.length; st.last = { source: x.source, at: now, fallback };
    if (fallback && (!st.notedAt || now - st.notedAt > NOTE_EVERY)) { note = AI_NAME[x.source]; st.notedAt = now; }
  }
  try { localStorage.setItem(KEY, JSON.stringify(st)); } catch { /* bộ nhớ đầy/bị chặn */ }
  return note;
}
/** Trạng thái hiển thị một nguồn. */
export function providerState(keySource: "user" | "server" | null, enabled: boolean, memo?: ProviderMemo): { state: "ok" | "warn" | "off"; text: string } {
  if (!enabled) return { state: "off", text: "Đã tắt trong thứ tự" };
  if (!keySource) return { state: "off", text: "Chưa có key" };
  if (memo && !memo.ok) {
    if (memo.code === 401 || memo.code === 403) return { state: "warn", text: "Lỗi key (lần gần nhất)" };
    if (memo.code === 402 || memo.code === 429) return { state: "warn", text: "Hết lượt / quá tải (lần gần nhất)" };
    if (memo.code === 451) return { state: "warn", text: "Từ chối nội dung (lần gần nhất)" };
    return { state: "warn", text: "Lỗi lần gần nhất — có thể tạm thời" };
  }
  return { state: "ok", text: `Sẵn sàng · ${keySource === "user" ? "key của bạn" : "key máy chủ"}` };
}
