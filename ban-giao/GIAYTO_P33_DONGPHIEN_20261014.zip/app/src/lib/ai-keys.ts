/**
 * AI-04 (QD-12): "Khoá AI của tôi" — người dùng nhập/đổi/xoá key Claude/Mistral/Gemini ngay trong app, chọn mô hình Claude, đổi thứ tự nguồn.
 * Lưu MÃ HOÁ AES-GCM trên máy: khoá thiết bị (WebCrypto, không xuất được) trong IndexedDB riêng "ghi-nhanh-khoa-ai"; đang bật khoá PIN
 * (két đang mở) thì mã hoá bằng khoá két. KHÔNG nằm trong sao lưu (CSDL riêng), đồng bộ mây, nhật ký, gói báo lỗi hay URL.
 * Gửi tới máy chủ của app qua tiêu đề x-ai-keys CHỈ ở các lệnh AI (middleware trong ai.functions.ts); máy chủ dùng cho lượt đó, không lưu/ghi log.
 */
import { decryptJson, encryptJson, getVaultKey, type EncBlob } from "./vault";

export type AiProvider = "lovable" | "claude" | "mistral" | "gemini";
export const AI_PROVIDER_ORDER: readonly AiProvider[] = ["lovable", "claude", "mistral", "gemini"];
export const CLAUDE_MODELS = [
  { id: "claude-opus-5-5", label: "Claude Opus 5.5 (chính xác nhất)" },
  { id: "claude-sonnet-5-5", label: "Claude Sonnet 5.5 (cân bằng)" },
  { id: "claude-haiku-5-5", label: "Claude Haiku 5.5 (rẻ nhất)" },
] as const;
export type AiKeys = { claude?: string; mistral?: string; gemini?: string; claudeModel?: string; order?: AiProvider[] };
export const AI_KEYS_HEADER = "x-ai-keys";

const DB = "ghi-nhanh-khoa-ai", STORE = "kv";
type Stored = { mode: "device" | "pin"; blob: EncBlob };

function open(): Promise<IDBDatabase> {
  return new Promise((res, rej) => { const r = indexedDB.open(DB, 1); r.onupgradeneeded = () => r.result.createObjectStore(STORE); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
}
async function kv<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await open();
  try { return await new Promise<T>((res, rej) => { const q = fn(db.transaction(STORE, mode).objectStore(STORE)); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); }); } finally { db.close(); }
}
async function deviceKey(): Promise<CryptoKey> {
  const k = await kv<CryptoKey | undefined>("readonly", (s) => s.get("device-key"));
  if (k) return k;
  const nk = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]); // không xuất được
  await kv("readwrite", (s) => s.put(nk, "device-key"));
  return nk;
}

/** Chuẩn hoá: bỏ khoảng trắng, key rỗng; thứ tự chỉ gồm nguồn hợp lệ, không trùng. */
export function cleanKeys(k: AiKeys): AiKeys {
  const out: AiKeys = {};
  for (const p of ["claude", "mistral", "gemini"] as const) { const v = k[p]?.trim(); if (v) out[p] = v.slice(0, 400); }
  if (k.claudeModel && CLAUDE_MODELS.some((m) => m.id === k.claudeModel)) out.claudeModel = k.claudeModel;
  const ord = [...new Set((k.order ?? []).filter((p) => AI_PROVIDER_ORDER.includes(p)))];
  if (ord.length) out.order = ord;
  return out;
}
export const hasAnyKey = (k: AiKeys | null | undefined) => !!(k && (k.claude || k.mistral || k.gemini));
/** Hiện key dạng che: 6 ký tự đầu … 4 ký tự cuối. */
export const maskKey = (k?: string) => (!k ? "" : k.length <= 12 ? "••••" : `${k.slice(0, 6)}…${k.slice(-4)}`);

let cache: AiKeys | null | undefined; // undefined = chưa đọc
export type LoadState = { keys: AiKeys | null; locked: boolean };

export async function loadAiKeys(): Promise<LoadState> {
  if (typeof indexedDB === "undefined") return { keys: null, locked: false };
  const st = await kv<Stored | undefined>("readonly", (s) => s.get("keys"));
  if (!st) { cache = null; return { keys: null, locked: false }; }
  const key = st.mode === "pin" ? getVaultKey() : await deviceKey();
  if (!key) return { keys: null, locked: true }; // két PIN đang khoá
  try { cache = cleanKeys(await decryptJson<AiKeys>(key, st.blob)); return { keys: cache, locked: false }; }
  catch { return { keys: null, locked: st.mode === "pin" }; } // sai khoá két (đã đổi/tắt PIN) → coi như khoá
}
export async function saveAiKeys(k: AiKeys): Promise<"device" | "pin"> {
  const keys = cleanKeys(k); const vk = getVaultKey(); const mode = vk ? "pin" : "device";
  const blob = await encryptJson(vk ?? (await deviceKey()), keys);
  await kv("readwrite", (s) => s.put({ mode, blob } satisfies Stored, "keys"));
  cache = keys; return mode;
}
export async function clearAiKeys() { await kv("readwrite", (s) => s.delete("keys")); cache = null; }

/** Giá trị tiêu đề x-ai-keys cho lệnh AI (base64 JSON), hoặc null khi không có key/két khoá. */
export async function aiKeysHeader(): Promise<string | null> {
  if (cache === undefined) { try { await loadAiKeys(); } catch { cache = null; } }
  if (!cache || (!hasAnyKey(cache) && !cache.order && !cache.claudeModel)) return null;
  return encodeAiKeys(cache);
}
/** base64(UTF-8 JSON) — máy chủ giải bằng aiKeysOverrides (ai-chain.server.ts). */
export function encodeAiKeys(k: AiKeys): string {
  const bytes = new TextEncoder().encode(JSON.stringify(cleanKeys(k))); let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s);
}
/** Chỉ cho kiểm thử: quên bộ nhớ đệm. */
export const _resetAiKeysCache = () => { cache = undefined; };
