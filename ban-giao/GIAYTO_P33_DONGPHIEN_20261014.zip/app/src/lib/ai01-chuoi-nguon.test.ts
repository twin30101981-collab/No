// AI-01: chuỗi nguồn AI dự phòng — thứ tự, bỏ nguồn thiếu key/nhạy cảm, chuyển nguồn khi lỗi/từ chối/hết giờ, ghi nguồn, Claude qua SDK chính thức.
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const create = vi.fn();
vi.mock("@anthropic-ai/sdk", () => {
  class Anthropic { opts: unknown; beta = { messages: { create } }; constructor(o: unknown) { this.opts = o; ctor(o); } }
  return { default: Anthropic };
});
const ctor = vi.fn();
const streamText = vi.fn();
vi.mock("ai", async (orig) => ({ ...(await orig<typeof import("ai")>()), streamText: (...a: unknown[]) => streamText(...a) }));

import { errorCode, providerOrder, runChain, withAiSource } from "./ai-chain.server";

const ENV_KEYS = ["AI_PROVIDERS", "LOVABLE_API_KEY", "ANTHROPIC_API_KEY", "MISTRAL_API_KEY", "GEMINI_API_KEY", "ANTHROPIC_MODEL"];
const saved: Record<string, string | undefined> = {};
beforeEach(() => { for (const k of ENV_KEYS) { saved[k] = process.env[k]; delete process.env[k]; } create.mockReset(); ctor.mockReset(); streamText.mockReset(); vi.spyOn(console, "warn").mockImplementation(() => {}); vi.spyOn(console, "log").mockImplementation(() => {}); });
afterEach(() => { for (const k of ENV_KEYS) { if (saved[k] === undefined) delete process.env[k]; else process.env[k] = saved[k]; } vi.restoreAllMocks(); });

describe("AI-01 thứ tự nguồn", () => {
  const all = { LOVABLE_API_KEY: "l", ANTHROPIC_API_KEY: "c", MISTRAL_API_KEY: "m", GEMINI_API_KEY: "g" };
  it("mặc định Lovable → Claude → Mistral → Gemini; thiếu key thì bỏ", () => {
    expect(providerOrder({}, all)).toEqual(["lovable", "claude", "mistral", "gemini"]);
    expect(providerOrder({}, { ANTHROPIC_API_KEY: "c", GEMINI_API_KEY: " " })).toEqual(["claude"]);
  });
  it("AI_PROVIDERS đổi thứ tự, bỏ tên lạ/trùng; nhạy cảm bỏ nguồn miễn phí", () => {
    expect(providerOrder({}, { ...all, AI_PROVIDERS: "gemini, claude,foo,claude" })).toEqual(["gemini", "claude"]);
    expect(providerOrder({ sensitive: true }, all)).toEqual(["lovable", "claude"]);
  });
  it("mã lỗi: hết giờ 408, từ chối 451, SDK status, lastError", () => {
    expect(errorCode(Object.assign(new Error("t"), { name: "TimeoutError" }))).toBe(408);
    expect(errorCode({ refusal: true, statusCode: 451 })).toBe(451);
    expect(errorCode({ status: 429 })).toBe(429);
    expect(errorCode({ lastError: { statusCode: 402 } })).toBe(402);
    expect(errorCode(new Error("x"))).toBe(500);
  });
});

describe("AI-01 runChain", () => {
  const env = { LOVABLE_API_KEY: "l", ANTHROPIC_API_KEY: "c", MISTRAL_API_KEY: "m" };
  it("nguồn đầu lỗi → nguồn kế; ghi nguồn đã phục vụ + nguồn đã thử", async () => {
    const r = await withAiSource(() => runChain("t", async (p) => { if (p === "lovable") throw { statusCode: 402 }; if (p === "claude") throw { refusal: true }; return p; }, {}, env));
    expect(r).toEqual({ value: "mistral", source: "mistral", tried: [{ provider: "lovable", code: 402 }, { provider: "claude", code: 451 }] });
  });
  it("hết nguồn → lỗi của nguồn đầu; không nguồn nào có key → 401", async () => {
    await expect(runChain("t", async (p) => { throw { statusCode: p === "lovable" ? 429 : 500 }; }, {}, env)).rejects.toEqual({ statusCode: 429 });
    await expect(runChain("t", async () => 1, {}, {})).rejects.toMatchObject({ statusCode: 401 });
  });
  it("nhạy cảm: không bao giờ gọi Mistral/Gemini", async () => {
    const seen: string[] = [];
    await expect(runChain("t", async (p) => { seen.push(p); throw { statusCode: 500 }; }, { sensitive: true }, { ...env, GEMINI_API_KEY: "g" })).rejects.toBeTruthy();
    expect(seen).toEqual(["lovable", "claude"]);
  });
});

describe("AI-01 qua ai.server: Lovable hết lượt → Claude (SDK chính thức)", () => {
  it("trích xuất chuyển sang Claude: ảnh base64, schema JSON, fallbacks default, hết giờ 60 s; kết quả + nguồn", async () => {
    process.env["LOVABLE_API_KEY"] = "l"; process.env["ANTHROPIC_API_KEY"] = "sk-test";
    streamText.mockImplementation(() => ({ get output() { return Promise.reject(Object.assign(new Error("402"), { statusCode: 402 })); }, get text() { return Promise.reject(new Error("x")); } }));
    const want = { type: "Hoá đơn", title: "HĐ điện", summary: "s", keyPoints: [], confidence: 0.9, fields: [], tags: [] };
    create.mockResolvedValue({ stop_reason: "end_turn", stop_details: null, content: [{ type: "text", text: JSON.stringify(want) }] });
    const { extractFromImages } = await import("./ai.server");
    const r = await withAiSource(() => extractFromImages(["data:image/png;base64,iVBORw0KGgo="]));
    expect(r.value).toEqual(want); expect(r.source).toBe("claude");
    expect(ctor).toHaveBeenCalledWith(expect.objectContaining({ apiKey: "sk-test", timeout: 60_000 }));
    const req = create.mock.calls[0]![0];
    expect(req).toMatchObject({ model: "claude-opus-5-5", fallbacks: "default", betas: ["server-side-fallback-2026-07-01"], output_config: { format: { type: "json_schema" } } });
    expect(req.output_config.format.schema.required).toContain("fields");
    expect(req.messages[0].content).toContainEqual({ type: "image", source: { type: "base64", media_type: "image/png", data: "iVBORw0KGgo=" } });
    expect(streamText.mock.calls[0]![0]).toHaveProperty("abortSignal");
  });
  it("Claude từ chối → 451 → hết nguồn: thông báo tiếng Việt", async () => {
    process.env["ANTHROPIC_API_KEY"] = "sk-test";
    create.mockResolvedValue({ stop_reason: "refusal", stop_details: { category: "bio" }, content: [] });
    const { runTextTask, toFail } = await import("./ai.server");
    const e = await runTextTask("summarize", { text: "abc" }).catch((x) => x);
    expect(errorCode(e)).toBe(451); expect(toFail(e).message).toContain("từ chối");
  });
});

describe("AI-01 lỗi báo cho người dùng khi hết nguồn", () => {
  it("bỏ lỗi chung (500/401) khi có lỗi cụ thể của nguồn sau", async () => {
    const env = { LOVABLE_API_KEY: "l", ANTHROPIC_API_KEY: "c" };
    await expect(runChain("t", async (p) => { throw p === "lovable" ? { statusCode: 500 } : { refusal: true }; }, {}, env)).rejects.toEqual({ refusal: true });
    await expect(runChain("t", async () => { throw { statusCode: 500 }; }, {}, env)).rejects.toEqual({ statusCode: 500 });
  });
});
