// FX-04: gói báo lỗi kèm nhật ký — không kèm ảnh/nội dung, không lộ PIN/khoá.
import { describe, expect, it } from "vitest";
import { buildBugReport, DROPPED, scrub } from "./bug-report";
import type { Settings } from "./settings";

const settings = { quality: "high", paper: "a4", ocrLang: "vie", dark: false, pin: "1234", pinSalt: "muoi", vaultWrap: { k: "x" }, autoLock: 1, autoCapture: true,
  maxQuality: false, captureSound: true, captureVibrate: true, defaultFilter: "auto", autoName: true, largeText: false, onboarded: true, voiceGuide: false,
  guideVibrate: true, nameTemplate: "{ten} bí mật", folderRules: [{ x: 1 }] } as unknown as Settings;

describe("FX-04 báo lỗi", () => {
  it("bỏ ảnh/tệp: data:, blob:, base64 dài, chuỗi quá dài — kể cả lồng trong meta", () => {
    const b64 = "A".repeat(300);
    expect(scrub({ a: "data:image/jpeg;base64,/9j/xx", b: "blob:http://x/1", c: `ok ${b64}`, d: "x".repeat(2500), e: "Lỗi mạng", f: [1, { g: "data:x" }] }))
      .toEqual({ a: DROPPED, b: DROPPED, c: DROPPED, d: DROPPED, e: "Lỗi mạng", f: [1, { g: DROPPED }] });
  });
  it("gói có nhật ký + ngân sách + công cụ; không có PIN/khoá/quy tắc tên", () => {
    const r = buildBugReport({ log: [{ at: "2026-10-14T00:00:00Z", code: "AI_FAIL", message: "429", meta: { src: "data:image/png;base64,AAAA" } }],
      perf: [{ k: "release", ms: 100, at: 0 }], uses: { "Nén PDF": 2 }, settings, build: "b1", device: "Android · Chrome", note: "chụp bị mờ", now: new Date("2026-10-14T01:02:03Z") });
    const s = JSON.stringify(r);
    expect(s).not.toMatch(/1234|muoi|bí mật|vaultWrap|folderRules|data:image/);
    expect(r.settings).toMatchObject({ quality: "high", autoCapture: true }); expect(r.toolUses).toEqual({ "Nén PDF": 2 });
    expect((r.scanLog as { code: string }[])[0].code).toBe("AI_FAIL"); expect(r.perf.samples).toBe(1); expect(r.perf.budget.length).toBe(5);
    expect(r.createdAt).toBe("2026-10-14T01:02:03.000Z"); expect(r.note).toBe("chụp bị mờ");
  });
});
