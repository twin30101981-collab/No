import { describe, expect, it, vi } from "vitest";
import { readFileSync } from "node:fs";
import { OcrQueue } from "./ocr-queue";
import { warpSize } from "./render-core";

const docs: { id: string; pages: { id: string; src: string; status?: string }[] }[] = [];
vi.mock("./db", () => ({ getDocs: () => docs }));

describe("CS-18 xem trước GPU, dựng CPU một lần, OCR sau cùng", () => {
  it("warpSize: cạnh dài = min(mức, giấy thật); bản dò (keep) giữ mức", () => {
    const quad = [[0.1, 0.1], [0.9, 0.1], [0.9, 0.9], [0.1, 0.9]] as [number, number][];
    const a = warpSize(quad, 2000, 2000, 1200, "auto", false);
    expect(Math.max(a.ow, a.oh)).toBe(1200);
    const b = warpSize(quad, 1000, 1000, 1200, "auto", false); // giấy thật 800 px → không phóng to
    expect(Math.max(b.ow, b.oh)).toBe(800);
    expect(Math.max(warpSize(quad, 1000, 1000, 1200, "auto", true).ow, warpSize(quad, 1000, 1000, 1200, "auto", true).oh)).toBe(1200);
  });

  it("finishedSrc chờ bản đầy đủ (status 'dang' → 'xong') rồi trả ảnh mới nhất", async () => {
    const { finishedSrc } = await import("./post-capture");
    docs.splice(0, docs.length, { id: "d", pages: [{ id: "p", src: "nhap", status: "dang" }] });
    const got = finishedSrc("d", "p", 5000, 10);
    setTimeout(() => { docs[0]!.pages[0] = { id: "p", src: "day-du", status: "xong" }; }, 40);
    await expect(got).resolves.toBe("day-du");
    docs[0]!.pages[0] = { id: "p", src: "van-dang", status: "dang" };
    await expect(finishedSrc("d", "p", 30, 10)).resolves.toBe("van-dang"); // quá hạn → đọc ảnh hiện có
    await expect(finishedSrc("d", "khong-co", 30, 10)).rejects.toThrow();
  });

  it("OcrQueue đọc ảnh từ latest() khi có; latest lỗi → đọc src", async () => {
    const seen: string[] = [];
    const q = new OcrQueue(() => ({ run: async (src) => { seen.push(src); return "chu"; }, abort: async () => {} }), () => {}, 1, async () => {});
    await Promise.all(q.add([
      { docId: "d", pageId: "1", label: "1", src: "nhap1", latest: async () => "day-du1" },
      { docId: "d", pageId: "2", label: "2", src: "nhap2", latest: async () => { throw new Error("x"); } },
      { docId: "d", pageId: "3", label: "3", src: "nhap3" },
    ]));
    expect(seen).toEqual(["day-du1", "nhap2", "nhap3"]);
  });

  it("màn Chụp và Nhập ảnh: chỉ dùng xem trước GPU khi còn bản đầy đủ dựng sau (không thì dựng CPU như cũ)", () => {
    const scan = readFileSync("src/routes/scan.tsx", "utf8"), imp = readFileSync("src/lib/import-pipeline.ts", "utf8");
    expect(scan).toMatch(/full > PREVIEW_LONG \? await renderQuickUrl\(orig, edit, pre\) : null\) \?\? renderPageUrl\(orig, edit, pre\)/);
    expect(imp).toMatch(/full > PREVIEW_LONG \? await renderQuickUrl\(p\.orig, edit, pre\) : null\) \?\? await renderPageUrl\(p\.orig, edit, pre\)/);
  });
});
