// CS-13: ngân sách thời gian §17.1 — bảng p90 so ngưỡng, cảnh báo khi vượt (đủ mẫu).
import { describe, expect, it } from "vitest";
import { BUDGET_171, budgetReport, overBudget, overBudgetText, type PerfSample } from "./perf-stats";

const s = (k: PerfSample["k"], ...ms: number[]): PerfSample[] => ms.map((m) => ({ k, ms: m, at: 0 }));

describe("CS-13 ngân sách §17.1", () => {
  it("đủ các công đoạn với ngưỡng của đề án", () => {
    expect(Object.fromEntries(BUDGET_171.map((b) => [b.k, b.ms]))).toEqual({ release: 500, "preview-shown": 300, render: 800, finish: 1200, done: 1000 });
  });
  it("chưa đủ 5 mẫu → chưa kết luận; đủ mẫu → đạt/vượt theo p90", () => {
    const perf = [...s("release", 100, 200, 300, 400, 450), ...s("finish", 900, 1000, 1100, 1300, 2500), ...s("done", 5000, 5000)];
    const r = Object.fromEntries(budgetReport(perf).map((x) => [x.k, x]));
    expect(r["release"]).toMatchObject({ count: 5, p90: 450, ok: true });
    expect(r["finish"]).toMatchObject({ count: 5, p90: 2500, ok: false });
    expect(r["done"]?.ok).toBeNull(); expect(r["preview-shown"]).toMatchObject({ count: 0, ok: null });
    expect(overBudget(perf).map((x) => x.k)).toEqual(["finish"]);
    expect(overBudgetText(overBudget(perf)[0])).toContain("vượt ngân sách 1200 ms");
  });
  it("vượt nhiều nhất xếp trước", () => {
    const perf = [...s("release", 600, 600, 600, 600, 600), ...s("render", 2400, 2400, 2400, 2400, 2400)];
    expect(overBudget(perf).map((x) => x.k)).toEqual(["render", "release"]);
  });
});
