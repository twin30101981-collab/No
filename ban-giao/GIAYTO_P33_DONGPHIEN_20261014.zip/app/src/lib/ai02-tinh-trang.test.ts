// AI-02: ghi kết quả AI theo nguồn, báo nguồn dự phòng (giãn 10 phút), trạng thái hiển thị từng nguồn.
import { beforeEach, describe, expect, it } from "vitest";
import { noteAiResult, providerState, readAiStatus } from "./ai-status";

describe("AI-02 tình trạng AI", () => {
  beforeEach(() => localStorage.clear());
  it("nguồn dự phòng phục vụ → báo tên một lần trong 10 phút; ghi lỗi nguồn đã thử", () => {
    const r = { ok: true, source: "claude", tried: [{ provider: "lovable", code: 402 }] };
    expect(noteAiResult(r, 1_000)).toBe("Claude");
    expect(noteAiResult(r, 2_000)).toBeNull();
    expect(noteAiResult(r, 1_000 + 10 * 60_000 + 1)).toBe("Claude");
    const st = readAiStatus();
    expect(st.providers.lovable).toMatchObject({ ok: false, code: 402 }); expect(st.providers.claude).toMatchObject({ ok: true });
    expect(st.last).toMatchObject({ source: "claude", fallback: true });
  });
  it("nguồn chính phục vụ → không báo; kết quả không có nguồn → bỏ qua", () => {
    expect(noteAiResult({ ok: true, source: "lovable" })).toBeNull();
    expect(readAiStatus().last).toMatchObject({ source: "lovable", fallback: false });
    expect(noteAiResult({ ok: true, data: 1 })).toBeNull(); expect(noteAiResult(null)).toBeNull();
  });
  it("trạng thái: tắt / chưa key / lỗi key / hết lượt / sẵn sàng", () => {
    expect(providerState("server", false).text).toContain("tắt");
    expect(providerState(null, true)).toMatchObject({ state: "off", text: "Chưa có key" });
    expect(providerState("user", true, { at: 1, ok: false, code: 401 }).text).toContain("Lỗi key");
    expect(providerState("server", true, { at: 1, ok: false, code: 429 }).text).toContain("Hết lượt");
    expect(providerState("user", true, { at: 1, ok: true })).toMatchObject({ state: "ok", text: "Sẵn sàng · key của bạn" });
  });
  it("dữ liệu hỏng → rỗng", () => { localStorage.setItem("ghi-nhanh:ai-status", "[x"); expect(readAiStatus()).toEqual({ providers: {} }); });
});
