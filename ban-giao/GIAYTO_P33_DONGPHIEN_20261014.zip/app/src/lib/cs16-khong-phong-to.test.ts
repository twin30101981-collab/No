// CS-16 (SP-01, QP-02): bản dựng không phóng to quá cạnh dài thật của tờ giấy trên ảnh gốc.
import { describe, expect, it } from "vitest";
import { paperLongPx, straightWarpPx, type RenderEnv } from "./render-core";

type Pt = [number, number];
const sizes: [number, number][] = [];
const env = {
  warp: async (_sd: Uint8ClampedArray, _W: number, _H: number, _q: Pt[], ow: number, oh: number) => { sizes.push([ow, oh]); return { od: new Uint8ClampedArray(ow * oh * 4).fill(255), engine: "cpu" as const }; },
  run: async (j: { d: Uint8ClampedArray }) => j.d,
} as unknown as RenderEnv;

describe("CS-16 cạnh dài thật", () => {
  it("paperLongPx = cạnh dài nhất của khung (làm tròn lên)", () => {
    expect(paperLongPx([[0, 0], [100, 0], [100, 200.2], [0, 200]])).toBe(201);
    expect(paperLongPx([[10, 10], [40, 50], [40, 50], [10, 10]])).toBe(50);
  });
  it("khung nhỏ hơn mức chất lượng → dựng đúng cỡ thật, không 3508", async () => {
    sizes.length = 0; const W = 1600, H = 2133;
    const quad: [number, number][] = [[0.1, 0.1], [0.9, 0.1], [0.9, 0.9], [0.1, 0.9]]; // giấy 1280 × 1706 px
    const g = await straightWarpPx(env, new Uint8ClampedArray(W * H * 4), W, H, quad, 3508, "auto", false, []);
    expect(Math.max(g.w, g.h)).toBeLessThanOrEqual(1707);
    expect(Math.max(g.w, g.h)).toBeGreaterThanOrEqual(1700);
    expect(Math.max(...sizes[0])).toBeLessThanOrEqual(720); // bản dò nghiêng giữ khổ 720
  });
  it("khung lớn hơn mức → giữ mức chất lượng", async () => {
    const W = 4000, H = 5000; const quad: [number, number][] = [[0, 0], [1, 0], [1, 1], [0, 1]];
    const g = await straightWarpPx(env, new Uint8ClampedArray(W * H * 4), W, H, quad, 2339, "auto", false, []);
    expect(Math.max(g.w, g.h)).toBe(2339);
  });
});
