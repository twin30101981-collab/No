/**
 * FX-02: màn Công cụ gọn — đếm số lần dùng từng công cụ (nhóm "Hay dùng") và tìm công cụ không dấu.
 * Chỉ lưu tên công cụ + số lần trên máy (localStorage), không lưu tệp hay nội dung.
 */
const KEY = "ghi-nhanh:tool-uses";

export function readUses(): Record<string, number> {
  try { const v = JSON.parse(localStorage.getItem(KEY) ?? "{}"); return v && typeof v === "object" && !Array.isArray(v) ? v : {}; } catch { return {}; }
}
export function recordUse(label: string) {
  try { const u = readUses(); u[label] = (u[label] ?? 0) + 1; localStorage.setItem(KEY, JSON.stringify(u)); } catch { /* bộ nhớ đầy hoặc bị chặn */ }
}
/** Tối đa n công cụ đã dùng (≥ 1 lần), nhiều lần trước; bằng nhau giữ thứ tự trong `labels`. Chỉ trả nhãn còn tồn tại. */
export function topUsed(labels: readonly string[], n = 4, uses = readUses()): string[] {
  return labels.map((l, i) => ({ l, i, c: uses[l] ?? 0 })).filter((x) => x.c > 0).sort((a, b) => b.c - a.c || a.i - b.i).slice(0, n).map((x) => x.l);
}
/** Gấp chữ để tìm: thường, bỏ dấu tiếng Việt (đ → d), gộp khoảng trắng. */
export function fold(s: string) {
  return s.normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/gi, "d").toLowerCase().replace(/\s+/g, " ").trim();
}
/** Khớp khi mọi từ của truy vấn có trong nhãn (không dấu, không phân biệt hoa thường). */
export function matchTool(label: string, query: string) {
  const q = fold(query); if (!q) return true;
  const l = fold(label); return q.split(" ").every((w) => l.includes(w));
}
