import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { dpiSummary, fitFormat, imageSize, pdfProperties } from "./pdf-page";
import { quickExportOpts } from "./quick-export";

/** JPEG tối thiểu: SOI + APP0 (+ APP1 Exif tuỳ chọn) + SOF0 w×h. */
function jpegHead(w: number, h: number, exif = false, progressive = false) {
  const app0 = [0xff, 0xe0, 0, 16, 0x4a, 0x46, 0x49, 0x46, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0];
  const app1 = exif ? [0xff, 0xe1, 0, 8, 0x45, 0x78, 0x69, 0x66, 0, 0] : [];
  const sof = [0xff, progressive ? 0xc2 : 0xc0, 0, 17, 8, h >> 8, h & 255, w >> 8, w & 255, 3, 1, 0x22, 0, 2, 0x11, 1, 3, 0x11, 1];
  return new Uint8Array([0xff, 0xd8, ...app0, ...app1, ...sof, 0xff, 0xd9]);
}

describe("CS-20 khổ khớp ảnh + DPI thật", () => {
  it("ảnh tỉ lệ A4 → trang 210×297 mm, DPI = cạnh px / 11,69 in", () => {
    const f = fitFormat(2339, 3308);
    expect(f.paper).toBe("A4");
    expect(f.wMm).toBeCloseTo(210, 0); expect(f.hMm).toBeCloseTo(297, 5);
    expect(f.dpi).toBe(283); // 3308 px / 11,69 in
    const g = fitFormat(1654, 2339); // CS-16: ảnh thật nhỏ hơn mức → DPI thật thấp hơn, KHÔNG ghi 300
    expect(g.dpi).toBe(200); expect(g.hMm).toBeCloseTo(297, 5);
  });
  it("ngang, Letter, thẻ CCCD, tỉ lệ lạ", () => {
    const a = fitFormat(3508, 2480); expect(a.paper).toBe("A4"); expect(a.wMm).toBeCloseTo(297, 5); expect(a.hMm).toBeCloseTo(210, 0);
    const l = fitFormat(2550, 3300); expect(l.paper).toBe("Letter"); expect(l.hMm).toBeCloseTo(279.4, 5); expect(l.dpi).toBe(300);
    const c = fitFormat(1012, 638); expect(c.paper).toBe("Thẻ"); expect(c.wMm).toBeCloseTo(85.6, 5); expect(c.dpi).toBe(300);
    const r = fitFormat(800, 3000); expect(r.paper).toBe("Tự do"); expect(r.hMm).toBeCloseTo(297, 5); expect(r.wMm / r.hMm).toBeCloseTo(800 / 3000, 6);
  });
  it("đọc cỡ JPEG/PNG từ phần đầu tệp, nhận khối EXIF", () => {
    expect(imageSize(jpegHead(2339, 3308))).toEqual({ w: 2339, h: 3308, fmt: "JPEG", exif: false });
    expect(imageSize(jpegHead(1200, 900, true, true))).toEqual({ w: 1200, h: 900, fmt: "JPEG", exif: true });
    const png = new Uint8Array(32); png.set([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 13, 0x49, 0x48, 0x44, 0x52, 0, 0, 3, 0, 0, 0, 2, 0]);
    expect(imageSize(png)).toEqual({ w: 768, h: 512, fmt: "PNG" });
    expect(imageSize(new Uint8Array([1, 2, 3]))).toBeNull();
  });
  it("siêu dữ liệu: tiêu đề, số trang + DPI thật, ứng dụng", () => {
    expect(dpiSummary([200, 200])).toBe("200 dpi"); expect(dpiSummary([150, 283])).toBe("150–283 dpi");
    const p = pdfProperties("Hợp đồng", [200, 283], "fit");
    expect(p).toEqual({ title: "Hợp đồng", subject: "2 trang · 200–283 dpi · khổ khớp ảnh", creator: "Ghi Nhanh", keywords: "dpi=200,283" });
    expect(pdfProperties("", [200], "a4").subject).toBe("1 trang · 200 dpi · A4 có lề");
  });
  it("QD-10: Xuất 1 chạm = Chuẩn – khớp ảnh", () => {
    expect(quickExportOpts()).toEqual({ paper: "fit", size: "balanced" });
  });
  it("mã nguồn: khớp ảnh lề 0, không cắt theo nội dung, dựng lại từ ảnh gốc, nén một lần, ghi siêu dữ liệu", () => {
    const f = readFileSync("src/lib/files.ts", "utf8");
    expect(f).toMatch(/const paper = opts\.paper \?\? "fit"/);
    expect(f).toMatch(/const m = fit \? 0 : 6/);
    expect(f).toMatch(/return compressPage\(s, size, false, false\)/); // Cao không mực màu: nguyên ảnh trang
    expect(f).toMatch(/renderExport\(so\.orig, so\.edit, max, q\)/); expect(f).toMatch(/re\.w === head\.w && re\.h === head\.h\) { exportStats\.re\+\+; return out; \}/); // dựng lại ĐÚNG cỡ ảnh trang
    expect(f).toMatch(/long <= maxSide \? await fromOrig\(s, so, q\) : s/); // nén một lần (cùng cỡ)
    expect(f).toMatch(/pdf\.setProperties\(pdfProperties\(/);
    const w = readFileSync("src/lib/pool.worker.ts", "utf8");
    expect(w).toMatch(/srcBlob\.type === "image\/jpeg"/); // object URL JPEG không bị nén lại
  });
});
