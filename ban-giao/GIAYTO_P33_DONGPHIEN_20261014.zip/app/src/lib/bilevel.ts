/**
 * CS-21 (QP-06): nhị phân Sauvola cho trang xuất Đen trắng 1-bit. Ngưỡng cục bộ T = m·(1 + k·(s/R − 1)) theo trung bình m và độ lệch
 * chuẩn s trong cửa sổ — nét mảnh/nhạt và vùng bóng đổ vẫn giữ (cách cũ: m·0,88 trên ảnh đã thu nhỏ → nét mảnh đứt, nền tối thành mảng đen).
 * k = 0,25: đo P33 trên nền bóng đổ có nhiễu ±12 — nét mảnh −60 giữ 100 %, đốm đen trên nền 0 (cách cũ 104 đốm; k 0,3 bắt đầu đứt nét).
 * Bộ nhớ O(rộng): cộng dồn cột trượt theo hàng (không dựng ảnh tích phân W×H Float64 ~140 MB cho trang A4 300 dpi).
 * Ra: Uint8Array w×h, 0 = đen, 255 = trắng. Thuần TS, chạy trong Worker.
 */
export function sauvola(lum: Uint8Array | Uint8ClampedArray, w: number, h: number, r = Math.max(8, Math.round(Math.min(w, h) / 80)), k = 0.25, R = 128): Uint8Array {
  const out = new Uint8Array(w * h);
  const cs = new Float64Array(w), cq = new Float64Array(w); // tổng cột (giá trị, bình phương) trên các hàng trong cửa sổ
  const addRow = (y: number, sgn: number) => { const o = y * w; for (let x = 0; x < w; x++) { const v = lum[o + x]; cs[x] += sgn * v; cq[x] += sgn * v * v; } };
  for (let y = 0; y < Math.min(h, r + 1); y++) addRow(y, 1);
  for (let y = 0; y < h; y++) {
    if (y > 0) { if (y + r < h) addRow(y + r, 1); if (y - r - 1 >= 0) addRow(y - r - 1, -1); }
    const rows = Math.min(h - 1, y + r) - Math.max(0, y - r) + 1;
    let s = 0, q = 0;
    for (let x = 0; x < Math.min(w, r + 1); x++) { s += cs[x]; q += cq[x]; }
    const o = y * w;
    for (let x = 0; x < w; x++) {
      if (x > 0) { if (x + r < w) { s += cs[x + r]; q += cq[x + r]; } if (x - r - 1 >= 0) { s -= cs[x - r - 1]; q -= cq[x - r - 1]; } }
      const n = rows * (Math.min(w - 1, x + r) - Math.max(0, x - r) + 1);
      const m = s / n, sd = Math.sqrt(Math.max(0, q / n - m * m));
      out[o + x] = lum[o + x] > m * (1 + k * (sd / R - 1)) ? 255 : 0;
    }
  }
  return out;
}

/** Độ sáng (BT.601 như compressPage cũ) từ RGBA. */
export function lumOf(rgba: Uint8ClampedArray | Uint8Array, n: number): Uint8Array {
  const g = new Uint8Array(n);
  for (let i = 0; i < n; i++) g[i] = (rgba[i * 4] * 299 + rgba[i * 4 + 1] * 587 + rgba[i * 4 + 2] * 114) / 1000;
  return g;
}

/** Tỉ lệ điểm có mực màu (sắc độ YCbCr lớn, không quá sáng) — trang có dấu đỏ/chữ ký xanh → xuất JPEG 4:4:4 ở mức Cao. */
export function inkShare(rgba: Uint8ClampedArray | Uint8Array, n: number, step = 4): number {
  let c = 0, t = 0;
  for (let i = 0; i < n; i += step) {
    const r = rgba[i * 4], g = rgba[i * 4 + 1], b = rgba[i * 4 + 2];
    const cb = -0.1687 * r - 0.3313 * g + 0.5 * b, cr = 0.5 * r - 0.4187 * g - 0.0813 * b, y = 0.299 * r + 0.587 * g + 0.114 * b;
    t++; if (Math.hypot(cb, cr) > 40 && y < 200) c++;
  }
  return t ? c / t : 0;
}
