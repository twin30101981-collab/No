import { describe, expect, it } from "vitest";
import { aiUnavailable, extractFromText, findDate, findTotal, fold, guessCategory, receiptFromText } from "./offline-extract";
import { normalizeReceipt } from "./receipt";
import { checkExtraction } from "./extract-check";

const BILL = `CÀ PHÊ PHỐ CỔ
Địa chỉ: 12 Hàng Bạc, Hà Nội
ĐT: 0912 345 678
HOÁ ĐƠN BÁN HÀNG
Số: 000123   Ngày: 14/10/2026 08:35
Bạc xỉu x2        58.000
Bánh mì x1        25.000
Cộng tiền hàng    83.000
Giảm giá          -8.000
TỔNG CỘNG         75.000
Tiền khách đưa   100.000
Tiền thừa         25.000`;

// OCR mất dấu, tổng ở dòng kế
const BILL_NO_MARKS = `SIEU THI WINMART
MST: 0104918404
TONG THANH TOAN
1,250,500
Ngay 02 thang 09 nam 2026`;

const VAT = `HÓA ĐƠN GIÁ TRỊ GIA TĂNG
Ký hiệu: 1C26TAA   Số: 0004567
Ngày 05 tháng 10 năm 2026
Đơn vị bán hàng: CÔNG TY TNHH ABC
Mã số thuế: 0101234567
Tổng cộng tiền thanh toán: 11.880.000`;

const CCCD = `CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
CĂN CƯỚC CÔNG DÂN
Số / No.: 001090012345
Họ và tên / Full name: NGUYỄN VĂN A
Ngày sinh / Date of birth: 01/02/1990`;

describe("AI-03 đường không AI — hoá đơn", () => {
  it("tổng tiền theo dòng TỔNG CỘNG, bỏ tiền khách đưa/tiền thừa/số điện thoại", () => {
    expect(findTotal(BILL)).toBe(75000);
  });
  it("OCR mất dấu, số ở dòng kế, ngày viết bằng chữ", () => {
    expect(findTotal(BILL_NO_MARKS)).toBe(1250500);
    expect(findDate(BILL_NO_MARKS)).toBe("2026-09-02");
  });
  it("receiptFromText đi qua normalizeReceipt: có tổng, ngày, cửa hàng, nhóm; luôn 'chưa chắc'", () => {
    const n = normalizeReceipt(receiptFromText(BILL));
    expect(n.total).toBe(75000);
    expect(n.date).toBe("2026-10-14");
    expect(n.merchant).toBe("CÀ PHÊ PHỐ CỔ");
    expect(n.category).toBe("Ăn uống");
    expect(n.unsure).toBe(true);
    expect(guessCategory(BILL_NO_MARKS)).toBe("Mua sắm");
  });
  it("chữ rỗng → không có tổng/ngày, không lỗi", () => {
    const n = normalizeReceipt(receiptFromText(""));
    expect(n.total).toBeNull();
    expect(n.date).toBe("");
    expect(n.category).toBe("Khác");
  });
  it("không có từ khoá tổng → số lớn nhất, bỏ mã số/ngày", () => {
    expect(findTotal("Quán bún\nMST 0312345678\n12/10/2026\nBún bò 45.000\nTrà đá 5.000")).toBe(45000);
  });
});

describe("AI-03 đường không AI — trích xuất", () => {
  it("hoá đơn VAT theo mẫu: đủ trường bắt buộc của mẫu", () => {
    const x = extractFromText(VAT, "vat");
    const get = (l: string) => x.fields.find((f) => f.label === l)?.value;
    expect(x.type).toBe("Hoá đơn");
    expect(get("Số hoá đơn")).toBe("0004567");
    expect(get("Ngày")).toBe("05/10/2026");
    expect(get("Mã số thuế bên bán")).toBe("0101234567");
    expect(get("Bên bán")).toBe("CÔNG TY TNHH ABC");
    expect(get("Tổng thanh toán")).toBe((11880000).toLocaleString("vi-VN"));
    const c = checkExtraction(x);
    expect(c.valid).toBe(true);
    expect(c.verdict).toBe("review"); // luôn xem lại vì không AI
  });
  it("CCCD: loại, số giấy tờ, họ tên, ngày sinh", () => {
    const x = extractFromText(CCCD);
    const get = (l: string) => x.fields.find((f) => f.label === l)?.value;
    expect(x.type).toBe("CCCD/Hộ chiếu");
    expect(get("Số giấy tờ")).toBe("001090012345");
    expect(get("Họ tên")).toBe("NGUYỄN VĂN A");
    expect(get("Ngày sinh")).toBe("01/02/1990");
    expect(checkExtraction(x).missing).toEqual([]);
  });
  it("chữ rỗng → kết quả rỗng hợp lệ (để báo không đọc được)", () => {
    const x = extractFromText("   ");
    expect(checkExtraction(x).empty).toBe(true);
  });
  it("fold bỏ dấu, đ→d", () => { expect(fold("TỔNG CỘNG Đồng")).toBe("tong cong dong"); });
  it("aiUnavailable: 401/402/429/408/451/5xx/lỗi mạng → có; 400 hoặc ok → không", () => {
    for (const code of [0, 401, 402, 403, 408, 429, 451, 500, 503]) expect(aiUnavailable({ ok: false, code })).toBe(true);
    expect(aiUnavailable({ ok: false, code: 400 })).toBe(false);
    expect(aiUnavailable({ ok: true })).toBe(false);
  });
});
