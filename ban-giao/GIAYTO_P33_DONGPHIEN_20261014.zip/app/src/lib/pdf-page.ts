/**
 * CS-20 (QP-03, QP-04, QP-08): khổ trang PDF "Khớp ảnh" + DPI thật + siêu dữ liệu. Hàm thuần, kiểm thử không cần DOM.
 * Trang khớp ảnh: khổ trang = cỡ giấy thật suy từ tỉ lệ ảnh (A4/A5, Letter, Legal, thẻ), lề 0 → DPI ghi trong PDF = DPI thật
 * của ảnh (cạnh px / cạnh giấy inch). Tỉ lệ lạ (hoá đơn dài, ảnh vuông…) → coi cạnh dài là 297 mm như a4Dpi() (capture.ts).
 */
export type PdfPaper = "fit" | "a4" | "letter";
export const PDF_PAPER_LABEL: Record<PdfPaper, string> = { fit: "Khớp ảnh", a4: "A4 có lề", letter: "Letter có lề" };

/** Giấy chuẩn (mm, cạnh ngắn × cạnh dài). A5 cùng tỉ lệ A4 → không phân biệt được theo tỉ lệ, chọn A4. */
const STD: { name: string; s: number; l: number }[] = [
  { name: "A4", s: 210, l: 297 },
  { name: "Letter", s: 215.9, l: 279.4 },
  { name: "Legal", s: 215.9, l: 355.6 },
  { name: "Thẻ", s: 54, l: 85.6 },
];
/** Sai lệch tỉ lệ tối đa để nhận là giấy chuẩn (snapAspect dùng 6 % khi nắn; ảnh đã nắn rơi đúng tỉ lệ). */
const TOL = 0.03;

export type PageFormat = { wMm: number; hMm: number; dpi: number; paper: string };

/** Khổ trang khớp ảnh cho ảnh w×h px. */
export function fitFormat(w: number, h: number): PageFormat {
  const long = Math.max(w, h), short = Math.min(w, h), r = long / Math.max(1, short);
  let best: (typeof STD)[number] | null = null, bestD = TOL;
  for (const p of STD) { const d = Math.abs(r - p.l / p.s) / (p.l / p.s); if (d < bestD) { bestD = d; best = p; } }
  const longMm = best ? best.l : 297;
  const dpi = (long / longMm) * 25.4;
  const k = 25.4 / dpi; // mm mỗi px
  return { wMm: w * k, hMm: h * k, dpi: Math.round(dpi), paper: best ? best.name : "Tự do" };
}

/** Kích thước ảnh JPEG/PNG từ phần đầu tệp (không giải mã). null = không đọc được. exif = JPEG có khối EXIF (có thể xoay
 *  theo Orientation → cỡ hiển thị khác cỡ lưu; nơi gọi không đưa nguyên byte vào PDF). */
export function imageSize(b: Uint8Array): { w: number; h: number; fmt: "JPEG" | "PNG"; exif?: boolean } | null {
  if (b.length > 24 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) {
    const v = new DataView(b.buffer, b.byteOffset, b.byteLength);
    return { w: v.getUint32(16), h: v.getUint32(20), fmt: "PNG" };
  }
  if (b[0] !== 0xff || b[1] !== 0xd8) return null;
  let i = 2, exif = false;
  while (i + 9 < b.length) {
    if (b[i] !== 0xff) { i++; continue; }
    const m = b[i + 1];
    if (m === 0xff) { i++; continue; }
    if (m === 0xd8 || m === 0x01 || (m >= 0xd0 && m <= 0xd7)) { i += 2; continue; }
    const len = (b[i + 2] << 8) | b[i + 3];
    if (m === 0xe1 && b[i + 4] === 0x45 && b[i + 5] === 0x78 && b[i + 6] === 0x69 && b[i + 7] === 0x66) exif = true; // "Exif"
    // SOF0–SOF15 trừ DHT (C4), JPG (C8), DAC (CC)
    if (m >= 0xc0 && m <= 0xcf && m !== 0xc4 && m !== 0xc8 && m !== 0xcc) return { h: (b[i + 5] << 8) | b[i + 6], w: (b[i + 7] << 8) | b[i + 8], fmt: "JPEG", exif };
    i += 2 + len;
  }
  return null;
}

/** Chuỗi DPI cho siêu dữ liệu: "200 dpi" hoặc "150–200 dpi". */
export function dpiSummary(dpis: number[]): string {
  if (!dpis.length) return "";
  const lo = Math.min(...dpis), hi = Math.max(...dpis);
  return lo === hi ? `${lo} dpi` : `${lo}–${hi} dpi`;
}

/** Siêu dữ liệu PDF (QP-08): tiêu đề, chủ đề (số trang + DPI thật), ứng dụng, từ khoá máy đọc được. */
export function pdfProperties(name: string | undefined, dpis: number[], paper: PdfPaper) {
  const n = dpis.length, dpi = dpiSummary(dpis);
  return {
    title: name?.trim() || "Ghi Nhanh",
    subject: `${n} trang · ${dpi}${paper === "fit" ? " · khổ khớp ảnh" : ` · ${PDF_PAPER_LABEL[paper]}`}`,
    creator: "Ghi Nhanh",
    keywords: `dpi=${dpis.join(",")}`,
  };
}
