/**
 * CS-17d: lõi dựng trang trên BỘ ĐỆM điểm ảnh (không gắn với canvas DOM) — một nguồn sự thật cho cả hai nơi chạy:
 * - Worker của bể (pool.worker.ts, "render"): OffscreenCanvas + runJob tại chỗ → luồng chính không còn đọc/ghi điểm ảnh.
 * - Luồng chính (dự phòng khi thiếu Worker/OffscreenCanvas/WebGL2 trong Worker): canvas DOM + runPixels.
 * Mỗi bước giữ nguyên từng phép tính của bản canvas cũ (image.ts trước CS-17d) — ảnh ra trùng byte (kiem-cs17d-trung-byte.mjs).
 * Chỉ import tĩnh (Worker dạng iife không tách chunk).
 */
import type { Filter, Quad } from "./db";
import { estimateSkewPx, type PixelJob, type Px } from "./pixels";
import { edgeCurves, trimBox, type Curves } from "./dewarp";
import { deskewQuad } from "./deskew-quad";
import { quadAspect, snapAspect, type Paper } from "./detect";
import { edgeSaturatedMask, inkDeepen } from "./ink-deepen";
import { autoLevel } from "./auto-level";
import { denoise } from "./denoise";
import { lineSkewRefineBand0, lineSkewRefineBand1 } from "./line-skew";
import { hasTools, type Tools } from "./tool-levels";

export type Cv = HTMLCanvasElement | OffscreenCanvas;
export type Ctx2 = CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D;
/** Ảnh RGBA trên bộ đệm (hàng trên cùng trước). */
export type Img = { d: Px; w: number; h: number };
type Pt = [number, number];

export interface RenderEnv {
  canvas(w: number, h: number): readonly [Cv, Ctx2];
  run(job: PixelJob): Promise<Px>;
  /** Nắn phối cảnh/cong (kèm thứ tự dự phòng riêng của nơi chạy). */
  warp(sd: Px, W: number, H: number, q: Pt[], ow: number, oh: number, curves: Curves, keep: boolean): Promise<{ od: Px; engine: "gpu" | "cpu" }>;
  jpeg(c: Cv, q: number): Promise<Blob | null>;
  bitmap(b: Blob): Promise<ImageBitmap>;
  /** Số đo từng bước (V0) — luồng chính ghi thẳng, Worker gửi kèm kết quả. */
  mark?(step: string, ms: number): void;
}

export const FILTER_ALIAS: Record<string, Filter> = { bw: "mono", blackwhite: "mono", "black-white": "mono", grey: "gray", grayscale: "gray", document: "auto", light: "auto", color: "original" };
export const FILTERS: Filter[] = ["original", "magic", "auto", "sharp", "mono", "gray", "ink", "eco", "vivid", "bright", "shadow", "denoise"];
/** S15b: tên bộ lọc cũ/ngoài → tên nội bộ; tên lạ rơi về "original" có cảnh báo. */
export function normalizeFilter(f: string | undefined | null): Filter {
  const k = String(f ?? "original").trim().toLowerCase();
  if ((FILTERS as string[]).includes(k)) return k as Filter;
  if (FILTER_ALIAS[k]) return FILTER_ALIAS[k];
  console.warn(`[filter] tên bộ lọc không hợp lệ: ${f} → original`);
  return "original";
}

const im = (d: Px, w: number, h: number) => new ImageData(d as Uint8ClampedArray<ArrayBuffer>, w, h);
/** Bộ đệm → canvas (putImageData, không sao chép). */
export function toCanvas(env: RenderEnv, d: Px, w: number, h: number) {
  const [c, ctx] = env.canvas(w, h); ctx.putImageData(im(d, w, h), 0, 0); return [c, ctx] as const;
}
async function timed<T>(env: RenderEnv, step: string, fn: () => Promise<T>): Promise<T> {
  const t0 = performance.now(); try { return await fn(); } finally { env.mark?.(step, Math.round(performance.now() - t0)); }
}

/** Nắn một lần (bản dò khi max nhỏ). Trả bộ đệm ow×oh + cờ giấy cong. */
/** CS-16: cạnh dài thật (px ảnh gốc) của tờ giấy = cạnh dài nhất của khung (làm tròn lên, tối thiểu 1). */
export function paperLongPx(q: Pt[]) {
  let m = 0;
  for (let i = 0; i < 4; i++) { const [ax, ay] = q[i], [bx, by] = q[(i + 1) % 4]; m = Math.max(m, Math.hypot(bx - ax, by - ay)); }
  return Math.max(1, Math.ceil(m));
}
/** Khung nguồn (px) + cỡ đích ow×oh của một lần nắn — dùng chung cho dựng chính và xem trước GPU (CS-18). */
export function warpSize(quad: Quad, W: number, H: number, max: number, paper: Paper, keep: boolean) {
  const q = quad.map(([x, y]) => [x * W, y * H] as Pt);
  const ratio = snapAspect(quadAspect(quad, W, H), paper);
  // CS-16 (SP-01, QP-02): cạnh dài đích = min(mức chất lượng, cạnh dài thật của tờ giấy trên ảnh gốc) — không phóng to giả
  // (trước đây luôn dựng 3508 px dù khung ~5 MP: lọc trên số điểm ảnh gấp ~1,8× mà không thêm chi tiết, mép chữ mềm).
  // Bản dò nghiêng (keep) giữ khổ cũ. Muốn phóng to: "Làm nét HD" (sr-enhance) là tuỳ chọn riêng.
  const long = keep ? max : Math.min(max, paperLongPx(q));
  const ow = ratio >= 1 ? long : long * ratio, oh = ratio >= 1 ? long / ratio : long;
  return { q, ow: Math.round(ow), oh: Math.round(oh) };
}
async function warpPx(env: RenderEnv, sd: Px, W: number, H: number, quad: Quad, max: number, paper: Paper, keep: boolean, flatten: boolean | undefined, perf: { engine: string; ms: number }[]) {
  const { q, ow, oh } = warpSize(quad, W, H, max, paper, keep);
  const t0 = performance.now();
  // P4/TD-09: flatten === false → người dùng tắt nắn cong, chỉ nắn phối cảnh thẳng
  const tc = performance.now();
  const curves = flatten === false ? [] : edgeCurves(sd, W, H, q);
  env.mark?.(keep ? "geo:curves0" : "geo:curves", Math.round(performance.now() - tc));
  const curved = curves.some(Boolean);
  const w = await timed(env, keep ? "geo:warp0" : "geo:warp", () => env.warp(sd, W, H, q, ow, oh, curves, keep)); const engine = w.engine; let od = w.od;
  // G4-06: nắn theo dòng chữ bên trong — cho CẢ nhánh GPU lẫn CPU
  if (flatten !== false) od = await timed(env, keep ? "geo:textflat0" : "geo:textflat", () => env.run({ op: "textflat", d: od, W: ow, H: oh }));
  perf.push({ engine, ms: Math.round(performance.now() - t0) });
  return { d: od, w: ow, h: oh, curved };
}

/**
 * B5: xoay thẳng → nắn/cắt. Đo độ nghiêng trên bản nắn thô nhỏ, rồi xoay khung nguồn và nắn một lần.
 * Giấy cong: nắn rồi xoay thẳng điểm ảnh (deskew).
 */
export async function straightWarpPx(env: RenderEnv, sd: Px, W: number, H: number, quad: Quad, max: number, paper: Paper = "auto", flatten: boolean | undefined, perf: { engine: string; ms: number }[]): Promise<Img> {
  const probe = await warpPx(env, sd, W, H, quad, Math.min(max, 720), paper, true, flatten, perf);
  if (probe.curved) {
    const w = await warpPx(env, sd, W, H, quad, max, paper, false, flatten, perf);
    return { d: await env.run({ op: "deskew", d: w.d, W: w.w, H: w.h }), w: w.w, h: w.h };
  }
  const deg = estimateSkewPx(probe.d, probe.w, probe.h);
  if (!deg) return warpPx(env, sd, W, H, quad, max, paper, false, flatten, perf);
  const q2 = deskewQuad(quad.map(([x, y]) => [x * W, y * H] as Pt), probe.w, probe.h, deg).map(([x, y]) => [x / W, y / H]) as Quad;
  return warpPx(env, sd, W, H, q2, max, paper, false, flatten, perf);
}

/** Bỏ mép nền thừa sau khi nắn: cắt dải tối sát cạnh (trimBox), rồi xoá nêm nền dính viền (op "clean"). */
export async function cleanEdgesPx(env: RenderEnv, g: Img): Promise<Img> {
  const { d: src, w: W, h: H } = g;
  const b = trimBox(src, W, H);
  const w = b.x1 - b.x0, h = b.y1 - b.y0;
  let d: Px;
  if (w === W && h === H) d = src;
  else if (w === W) d = src.slice(b.y0 * W * 4, b.y1 * W * 4);
  else { d = new Uint8ClampedArray(w * h * 4); for (let y = 0; y < h; y++) { const s = ((y + b.y0) * W + b.x0) * 4; d.set(src.subarray(s, s + w * 4), y * w * 4); } }
  const res = await env.run({ op: "clean", d, W: w, H: h });
  return { d: res.byteLength === w * h * 4 && res.byteOffset === 0 ? res : new Uint8ClampedArray(res.buffer as ArrayBuffer, res.byteOffset, w * h * 4), w, h };
}

/** Xoay 90/180/270° bằng canvas như bản cũ. */
export function rotatePx(env: RenderEnv, g: Img, rotation: number): Img {
  const r = ((rotation % 360) + 360) % 360;
  if (!r) return g;
  const [c] = toCanvas(env, g.d, g.w, g.h);
  const [rc, rctx] = env.canvas(r % 180 ? g.h : g.w, r % 180 ? g.w : g.h);
  rctx.translate(rc.width / 2, rc.height / 2); rctx.rotate((r * Math.PI) / 180); rctx.drawImage(c, -c.width / 2, -c.height / 2); c.width = 0;
  return { d: rctx.getImageData(0, 0, rc.width, rc.height).data, w: rc.width, h: rc.height };
}

/** Chuẩn hoá ánh sáng: đo nền trên bản ≤ 1000 px (thu nhỏ làm mịn "high"), áp lên bản lớn. */
export async function flattenLightPx(env: RenderEnv, d: Px, W: number, H: number): Promise<Px> {
  if (Math.max(W, H) > 1000) {
    const s = 1000 / Math.max(W, H);
    const sw = Math.max(1, Math.round(W * s)), sh = Math.max(1, Math.round(H * s));
    const [c] = toCanvas(env, d, W, H);
    const [sm, smx] = env.canvas(sw, sh); smx.imageSmoothingQuality = "high"; smx.drawImage(c, 0, 0, sw, sh);
    const sd = smx.getImageData(0, 0, sw, sh).data; sm.width = 0; c.width = 0;
    return env.run({ op: "flatten-small", d, W, H, s: sd, sw, sh });
  }
  return env.run({ op: "flatten", d, W, H });
}

export type FilterOpts = { filter: Filter; brightness: number; contrast: number; preFlat?: boolean; tools?: Tools | undefined; level?: number };

/** Áp bộ lọc trên bộ đệm (giữ nguyên từng phép tính của applyFilter cũ). */
export async function applyFilterPx(env: RenderEnv, d0: Px, W: number, H: number, o: FilterOpts): Promise<Px> {
  const filter = normalizeFilter(o.filter); const preFlat = !!o.preFlat, level = o.level ?? 100;
  let d = d0; const n = d.length;
  // R2.4: cấp độ bộ lọc < 100 → giữ bản gốc để trộn lại ở cuối (0 = giữ gốc).
  const keep = level < 100 ? new Uint8ClampedArray(d) : null;
  if (filter === "auto" || filter === "sharp") {
    if (!preFlat) d = await flattenLightPx(env, d, W, H);
    d = await env.run({ op: "docchain", d, W, H, sharp: filter === "sharp", deep: true }); // CS-17b: đậm hoá dịu R6.1d trong Worker
  } else if (filter === "magic") {
    // "magic colour": nền giấy trắng, chữ xám → gần đen, giữ màu mực (dấu đỏ, chữ ký xanh) và làm rực hơn.
    if (!preFlat) d = await flattenLightPx(env, d, W, H);
    const hist = new Uint32Array(256);
    for (let i = 0; i < n; i += 16) hist[(d[i] * 0.3 + d[i + 1] * 0.59 + d[i + 2] * 0.11) | 0]++;
    let acc = 0, lo = 0; const total = n / 16; for (let i = 0; i < 256; i++) { acc += hist[i]; if (acc > total * 0.005) { lo = i; break; } }
    const white = 205; // R6.1a: nén sớm vùng sáng, dành dải cho nét tối
    const keepSat = edgeSaturatedMask(d, W, H); // HM-11: khối màu ở mép không bị nén xuống đen
    for (let i = 0; i < n; i += 4) {
      const r = d[i], g = d[i + 1], b = d[i + 2];
      const mx = Math.max(r, g, b), mn = Math.min(r, g, b); const sat = mx ? (mx - mn) / mx : 0;
      const y = r * 0.3 + g * 0.59 + b * 0.11;
      const t = Math.min(1, Math.max(0, (y - lo) / Math.max(30, white - lo))); const ny = 255 * Math.pow(t, 2.3); // R6.1a: gamma 2.3
      if (sat > 0.22 && mx - mn > 35 && y < 235) {
        const k = Math.max(ny / Math.max(1, y), keepSat[i >> 2] ? 0.6 : 0); const boost = 1.35;
        for (let ch = 0; ch < 3; ch++) { const v = d[i + ch]; d[i + ch] = Math.min(255, Math.max(0, (y + (v - y) * boost) * k)); }
      } else { d[i] = d[i + 1] = d[i + 2] = ny; }
    }
    d = await env.run({ op: "sharpen", d, W, H, amount: 1.0 });
  } else if (filter === "shadow") {
    d = await env.run({ op: "deshadow", d, W, H });
  } else if (filter === "denoise") {
    d = denoise(d, W, H);
  } else if (filter === "gray") {
    if (!preFlat) d = await flattenLightPx(env, d, W, H); // R6.1b-2: chuẩn hoá nền
    const keepSat = edgeSaturatedMask(d, W, H); // HM-11: nhớ điểm màu bão hoà trước khi xám hoá
    d = await env.run({ op: "gray", d, W, H });
    autoLevel(d, 1.7); // R6.1a: kéo mức đậm hoá nét mực, nền neo về PAPER_TARGET
    inkDeepen(d, undefined, undefined, keepSat); // R6.1b-2
    inkDeepen(d, 160, 2.2, keepSat); // R6.1d: lượt hai dịu hơn cho mực rất nhạt
  } else if (filter === "mono" || filter === "ink") {
    const keepSat = filter === "mono" ? edgeSaturatedMask(d, W, H) : null; // HM-11
    d = await env.run({ op: "threshold", d, W, H, ink: filter === "ink" });
    // HM-11: khối màu bão hoà (số trang đỏ, logo) hiện thành xám giữa để không nuốt mép trang.
    if (keepSat) for (let i = 0; i < keepSat.length; i++) if (keepSat[i] && d[i * 4]! < 110) { d[i * 4] = d[i * 4 + 1] = d[i * 4 + 2] = 110; }
  } else if (filter === "eco" || filter === "vivid" || filter === "bright") {
    if (filter === "eco" && !preFlat) d = await flattenLightPx(env, d, W, H);
    d = await env.run({ op: "style", d, W, H, mode: filter });
  }
  if (hasTools(o.tools)) d = await env.run({ op: "tools", d, W, H, tools: o.tools! });
  if (o.brightness || o.contrast) d = await env.run({ op: "tone", d, W, H, brightness: o.brightness, contrast: o.contrast });
  if (keep) {
    const m = Math.max(0, Math.min(100, level)) / 100;
    for (let i = 0; i < d.length; i += 4) {
      d[i] = keep[i]! + (d[i]! - keep[i]!) * m;
      d[i + 1] = keep[i + 1]! + (d[i + 1]! - keep[i + 1]!) * m;
      d[i + 2] = keep[i + 2]! + (d[i + 2]! - keep[i + 2]!) * m;
    }
  }
  return d;
}

/**
 * S11r: nắn riêng ô dải 0 lệch nhất. Đo trên ảnh đã nén JPEG (giống ảnh lưu). S15c: đo trước trên bản ≤ 1000 px;
 * đa số trang không cần nắn → bỏ vòng nén/giải nén. Sửa thẳng trên canvas `c` (đang chứa ảnh sau bộ lọc).
 */
export async function band0FixCanvas(env: RenderEnv, c: Cv, ctx: Ctx2, log: string[]) {
  try {
    const s = Math.min(1, 1000 / Math.max(c.width, c.height));
    const sw = Math.max(1, Math.round(c.width * s)), sh = Math.max(1, Math.round(c.height * s));
    const [sm, smx] = env.canvas(sw, sh); smx.imageSmoothingQuality = "high"; smx.drawImage(c, 0, 0, sw, sh);
    const sd = smx.getImageData(0, 0, sw, sh).data; sm.width = 0;
    const p0 = lineSkewRefineBand0(sd, sw, sh, 3);
    const p1 = lineSkewRefineBand1(p0.data, sw, sh, 2);
    if (p0.passes === 0 && p1.passes === 0) return;
    const blob = await env.jpeg(c, 0.92);
    if (!blob) return;
    const bmp = await env.bitmap(blob);
    const [t, tctx] = env.canvas(c.width, c.height); tctx.drawImage(bmp, 0, 0); bmp.close();
    const id = tctx.getImageData(0, 0, c.width, c.height); t.width = 0;
    const r = lineSkewRefineBand0(id.data, c.width, c.height, 3);
    const r1 = lineSkewRefineBand1(r.data, c.width, c.height, 2); // S11s: nắn ô dải 1 còn lệch, bù dải 0 trong cùng lượt
    log.push(...r1.log);
    if (r.passes > 0 || r1.passes > 0) { id.data.set(r1.data); ctx.putImageData(id, 0, 0); }
  } catch { /* bỏ qua: giữ ảnh như cũ */ }
}

/** Bộ lọc → (nắn dải 0 với Tự động/Nét) → JPEG. `d` thuộc quyền hàm này. */
export async function finishPx(env: RenderEnv, g: Img, o: FilterOpts & { q: number }, log: string[]): Promise<Blob | null> {
  const d = await timed(env, "filter", () => applyFilterPx(env, g.d, g.w, g.h, o));
  const [c, ctx] = toCanvas(env, d, g.w, g.h);
  if (o.filter === "auto" || o.filter === "sharp") await timed(env, "band0", () => band0FixCanvas(env, c, ctx, log));
  const out = await timed(env, "jpeg", () => env.jpeg(c, o.q));
  c.width = 0; return out;
}
