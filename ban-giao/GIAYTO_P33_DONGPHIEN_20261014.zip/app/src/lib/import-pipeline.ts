// CS-09 (đóng TD-37): ảnh chụp đưa vào bằng "Thêm"/"Nhập" (thư viện, máy ảnh hệ thống, dán, kéo-thả) đi CHUNG dây chuyền với ảnh chụp camera:
// dò khung → bộ lọc mặc định → bản xem trước ~1200 px ngay → bản đầy đủ dựng ở nền (status "dang") → sau khi lưu: công thức/đặt tên/OCR.
// Trước: chỉ chuẩn hoá ảnh, không dò khung (TD-37 chỉ gợi ý bấm "Tự dò góc"), bộ lọc "Màu gốc", không hậu xử lý.
import { EDGE_WARNING } from "./batch-review";
import type { Page } from "./db";
import { detectQuadInfo, renderPageUrl, renderQuickUrl, targetLong } from "./image";
import { pmapOrdered } from "./pmap";
import { gradeOf } from "./post-capture-metrics";
import { PREVIEW_LONG } from "./render-cache";
import { getSettings } from "./settings";

/** Trang cần đi dây chuyền: ảnh CHỤP (importKind "photo") chưa có khung. Ảnh phẳng/chụp màn hình, trang PDF giữ nguyên. */
export const needsPipeline = (p: Page) => p.importKind === "photo" && !p.edit.quad;

export async function processImported(pages: Page[], onProgress?: (done: number, total: number) => void): Promise<Page[]> {
  const todo = pages.filter(needsPipeline);
  if (!todo.length) return pages;
  const st = getSettings(); const full = targetLong(st.quality);
  const lanes = Math.min(3, Math.max(1, (typeof navigator !== "undefined" ? navigator.hardwareConcurrency || 2 : 2) - 1));
  const out = new Map<string, Page>(); let done = 0;
  onProgress?.(0, todo.length);
  await pmapOrdered(todo, lanes, async (p) => {
    const info = await detectQuadInfo(p.orig).catch(() => ({ quad: null, sure: false }));
    // CS-09b: chấm điểm trang NGAY trong làn (ảnh đang nóng) → công thức bộ lọc chọn được trước khi xếp việc dựng bản đầy đủ
    // (postCaptureWithMetrics trúng bộ đệm metricsCache theo ảnh gốc, không phải chờ lúc rảnh từng trang).
    await gradeOf(p.orig).catch(() => null);
    const edit = { ...p.edit, quad: info.quad ?? undefined, filter: st.defaultFilter };
    const pre = Math.min(PREVIEW_LONG, full); // CS-18: bản đầy đủ dựng sau → xem trước nháp trên GPU, không chạy chuỗi CPU hai lần
    const src = (full > PREVIEW_LONG ? await renderQuickUrl(p.orig, edit, pre) : null) ?? await renderPageUrl(p.orig, edit, pre);
    const next: Page = { ...p, edit, src, status: full > PREVIEW_LONG ? "dang" : "xong" };
    if (!info.quad || !info.sure) next.warnings = [...new Set([...(p.warnings ?? []), EDGE_WARNING])]; // CS-06: vào lớp Xem lại
    return next;
  }, (r) => { out.set(r.id, r); onProgress?.(++done, todo.length); });
  return pages.map((p) => out.get(p.id) ?? p);
}
