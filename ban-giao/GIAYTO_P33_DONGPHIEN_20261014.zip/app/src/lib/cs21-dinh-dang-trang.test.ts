import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { encodeJpeg, quantTable } from "./jpeg-enc";
import { encodeG4, packG4 } from "./g4";
import { inkShare, sauvola } from "./bilevel";
import { PDF_SIZES, pageKindOf } from "./files";
import { imageSize } from "./pdf-page";

/** Trang thử: nền sáng có bóng đổ (235 → 65 sang phải) + nhiễu ±12, nét mảnh −60 dài 1 px, khối chữ đậm. */
function page(w = 240, h = 120) {
  const g = new Uint8Array(w * h); let seed = 7; const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) g[y * w + x] = Math.max(0, Math.min(255, 235 - Math.round((x / w) * 170) + Math.round((rnd() - 0.5) * 24)));
  for (let x = 10; x < w - 10; x++) g[30 * w + x] = Math.max(0, g[30 * w + x] - 60);
  for (let y = 60; y < 90; y++) for (let x = 20; x < 26; x++) g[y * w + x] = 20; // nét chữ đậm 6 px
  return g;
}
/** Cách cũ (files.ts trước CS-21): ngưỡng = trung bình cửa sổ × 0,88. */
function oldBw(g: Uint8Array, w: number, h: number) {
  const r = Math.max(8, Math.round(Math.min(w, h) / 40)), out = new Uint8Array(w * h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    let s = 0, n = 0;
    for (let yy = Math.max(0, y - r); yy <= Math.min(h - 1, y + r); yy++) for (let xx = Math.max(0, x - r); xx <= Math.min(w - 1, x + r); xx++) { s += g[yy * w + xx]; n++; }
    out[y * w + x] = g[y * w + x] < (s / n) * 0.88 ? 0 : 255;
  }
  return out;
}

describe("CS-21 định dạng theo loại trang", () => {
  it("bảng 11.3: Chuẩn q0,82; 1-bit Nhỏ 200 dpi, Chuẩn/Cao 300 dpi; loại trang theo bộ lọc", () => {
    expect(PDF_SIZES.balanced.q).toBe(0.82); expect(PDF_SIZES.small.q).toBe(0.75); expect(PDF_SIZES.high.q).toBe(0.9);
    expect([PDF_SIZES.small.bwDpi, PDF_SIZES.balanced.bwDpi, PDF_SIZES.high.bwDpi]).toEqual([200, 300, 300]);
    expect(pageKindOf("mono")).toBe("bw"); expect(pageKindOf("gray")).toBe("gray"); expect(pageKindOf("auto")).toBe("color"); expect(pageKindOf(undefined)).toBe("color");
  });
  it("JPEG xám = 1 kênh, màu = 4:4:4; bảng lượng tử theo libjpeg", () => {
    const w = 37, h = 21, d = new Uint8Array(w * h * 4).map((_, i) => (i * 37) % 251);
    const g = encodeJpeg(d, w, h, 82, true), c = encodeJpeg(d, w, h, 90, false);
    expect(imageSize(g)).toMatchObject({ w, h, fmt: "JPEG" }); expect(imageSize(c)).toMatchObject({ w, h, fmt: "JPEG" });
    const sof = (b: Uint8Array) => { for (let i = 2; i < b.length; ) { if (b[i + 1] === 0xc0) return b.subarray(i, i + 19); i += 2 + ((b[i + 2] << 8) | b[i + 3]); } return null; };
    expect(sof(g)![9]).toBe(1); // 1 thành phần
    expect(sof(c)![9]).toBe(3); expect([sof(c)![11], sof(c)![14], sof(c)![17]]).toEqual([0x11, 0x11, 0x11]); // 4:4:4
    expect(g[g.length - 2]).toBe(0xff); expect(g[g.length - 1]).toBe(0xd9);
    expect(quantTable([16, 11], 50)).toEqual([16, 11]); expect(quantTable([16, 11], 82)).toEqual([6, 4]);
  });
  it("G4: dòng trắng = mã V0 '1'; kết thúc EOFB; gói có cỡ ảnh", () => {
    const g = encodeG4(new Uint8Array(16 * 8).fill(255), 16, 8);
    expect([...g]).toEqual([0xff, 0x00, 0x10, 0x01]);
    const p = packG4(g, 16, 8); expect([...p.subarray(0, 12)]).toEqual([0x47, 0x34, 0, 0, 0, 0, 0, 16, 0, 0, 0, 8]);
    const b = new Uint8Array(16 * 2).fill(255); b.fill(0, 4, 9); // 1 hàng có đoạn đen
    expect(encodeG4(b, 16, 2).length).toBeGreaterThan(4);
  });
  it("Sauvola giữ nét mảnh, nền bóng đổ có nhiễu không lấm đốm đen (cách cũ: >50 đốm)", () => {
    const w = 240, h = 120, g = page(w, h);
    const nu = sauvola(g, w, h), ol = oldBw(g, w, h);
    const line = (o: Uint8Array) => { let k = 0; for (let x = 10; x < w - 10; x++) if (o[30 * w + x] === 0) k++; return k / (w - 20); };
    const speck = (o: Uint8Array) => { let k = 0; for (let y = 100; y < h; y++) for (let x = 0; x < w; x++) if (o[y * w + x] === 0) k++; return k; };
    expect(line(nu)).toBeGreaterThan(0.97); // nét mảnh không đứt
    expect(speck(ol)).toBeGreaterThan(50); // cách cũ: nền bóng có nhiễu thành đốm đen
    expect(speck(nu)).toBeLessThan(speck(ol) / 10);
    let blk = 0; for (let y = 60; y < 90; y++) for (let x = 20; x < 26; x++) if (nu[y * w + x] === 0) blk++;
    expect(blk).toBe(30 * 6); // nét đậm đặc, không rỗng ruột
  });
  it("đo mực màu: trang có dấu đỏ > 0, trang đen trắng = 0", () => {
    const n = 100, red = new Uint8Array(n * 4), gray = new Uint8Array(n * 4);
    for (let i = 0; i < n; i++) { red.set(i < 20 ? [200, 25, 30, 255] : [240, 240, 235, 255], i * 4); gray.set([i, i, i, 255], i * 4); }
    expect(inkShare(red, n, 1)).toBeCloseTo(0.2, 2); expect(inkShare(gray, n, 1)).toBe(0);
  });
  it("mã nguồn: xuất theo loại trang trong Worker, jsPDF nhận G4 (CCITTFaxDecode K −1)", () => {
    const f = readFileSync("src/lib/files.ts", "utf8");
    expect(f).toMatch(/kinds: doc\.pages\.map\(\(p\) => pageKindOf\(p\.edit\?\.filter\)\)/);
    expect(f).toMatch(/filter: "CCITTFaxDecode", decodeParameters: `\/K -1/);
    const wk = readFileSync("src/lib/pool.worker.ts", "utf8");
    expect(wk).toMatch(/m\.adaptive \? sauvola\(lum, W, H\) : lum\.map/); // Sauvola chỉ cho trang chưa đen trắng
    expect(wk).toMatch(/packG4\(encodeG4\(bin, W, H\), W, H\)/);
    expect(wk).toMatch(/encodeJpeg\(d, W, H, m\.q \* 100, m\.mode === "gray"\)/);
  });
});
