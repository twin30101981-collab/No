// AI-05: định tuyến theo độ nhạy cảm — giấy tờ nhạy cảm không tới Mistral/Gemini; từ chối/429 → nguồn kế (xem ai01).
import { describe, expect, it } from "vitest";
import { isSensitiveDoc, sensitiveFor, textHasSensitiveNumbers } from "./ai-sensitivity";
import { runChain, withAiSource } from "./ai-chain.server";

describe("AI-05 độ nhạy cảm", () => {
  it("loại tài liệu nhạy cảm / khoá PIN", () => {
    expect(isSensitiveDoc({ kind: "CCCD/Hộ chiếu" })).toBe(true);
    expect(isSensitiveDoc({ kind: "Khác", fields: { docType: "Sổ đỏ" } })).toBe(true);
    expect(isSensitiveDoc({ kind: "Hợp đồng thuê nhà" })).toBe(true);
    expect(isSensitiveDoc({ kind: "Ghi chú", enc: { v: 1 } })).toBe(true);
    expect(isSensitiveDoc({ kind: "Ghi chú" })).toBe(false); expect(isSensitiveDoc({ kind: "Công văn" })).toBe(false);
  });
  it("số cá nhân trong chữ (CCCD, điện thoại, tài khoản); tiền có dấu chấm không tính", () => {
    expect(textHasSensitiveNumbers("Số CCCD: 001 203 012 345")).toBe(true);
    expect(textHasSensitiveNumbers("Gọi 0912 345 678")).toBe(true);
    expect(textHasSensitiveNumbers("STK 1903 4567 8901 23")).toBe(true);
    expect(textHasSensitiveNumbers("Tổng 15.000.000 đồng, năm 2026")).toBe(false);
  });
  it("quyết định: số cá nhân > gợi ý màn > bài tập > mặc định nhạy cảm", () => {
    expect(sensitiveFor("aiText", { task: "solve", text: "x + 2 = 5" }, null)).toBe(false);
    expect(sensitiveFor("aiText", { task: "solve", text: "SĐT 0912345678" }, "0")).toBe(true);
    expect(sensitiveFor("aiExtract", { images: ["data:image/jpeg;base64,0912345678"] }, "0")).toBe(false); // ảnh không quét chữ
    expect(sensitiveFor("aiExtract", { images: [] }, "1")).toBe(true);
    expect(sensitiveFor("aiClassify", { images: [] }, null)).toBe(true);
  });
  it("nhạy cảm (theo lệnh) → chuỗi không gọi Mistral/Gemini dù có key", async () => {
    const env = { MISTRAL_API_KEY: "m", GEMINI_API_KEY: "g", ANTHROPIC_API_KEY: "c" }; const seen: string[] = [];
    const go = (s: boolean) => withAiSource(() => runChain("t", async (p) => { seen.push(p); throw { statusCode: 429 }; }, {}, env).catch(() => null), null, s);
    await go(true); expect(seen).toEqual(["claude"]);
    seen.length = 0; await go(false); expect(seen).toEqual(["claude", "mistral", "gemini"]);
  });
});
