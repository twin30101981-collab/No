// AI-04: khoá AI người dùng — chuẩn hoá, che key, tiêu đề x-ai-keys ↔ biến ghi đè máy chủ, key người dùng đè key máy chủ trong chuỗi nguồn.
import { describe, expect, it } from "vitest";
import { cleanKeys, encodeAiKeys, hasAnyKey, maskKey } from "./ai-keys";
import { aiKeysOverrides, providerKey, providerOrder, runChain, withAiSource, aiEnv } from "./ai-chain.server";

describe("AI-04 khoá AI", () => {
  it("chuẩn hoá: bỏ rỗng/khoảng trắng, mô hình lạ, nguồn lạ/trùng", () => {
    expect(cleanKeys({ claude: "  sk-ant-1 ", mistral: "   ", claudeModel: "gpt-x", order: ["gemini", "gemini", "foo" as never, "claude"] }))
      .toEqual({ claude: "sk-ant-1", order: ["gemini", "claude"] });
    expect(hasAnyKey({ order: ["claude"] })).toBe(false); expect(hasAnyKey({ gemini: "g" })).toBe(true);
    expect(maskKey("sk-ant-api03-abcdefgh1234")).toBe("sk-ant…1234"); expect(maskKey("ngan")).toBe("••••"); expect(maskKey()).toBe("");
  });
  it("tiêu đề → biến ghi đè máy chủ (key, mô hình, thứ tự)", () => {
    const h = encodeAiKeys({ claude: "sk-ant-x", gemini: "AIza-y", claudeModel: "claude-haiku-5-5", order: ["claude", "gemini", "lovable"] });
    expect(aiKeysOverrides(h)).toEqual({ ANTHROPIC_API_KEY: "sk-ant-x", GEMINI_API_KEY: "AIza-y", ANTHROPIC_MODEL: "claude-haiku-5-5", AI_PROVIDERS: "claude,gemini,lovable" });
  });
  it("tiêu đề hỏng/rỗng/quá dài → bỏ qua", () => {
    expect(aiKeysOverrides(null)).toBeNull(); expect(aiKeysOverrides("@@@")).toBeNull(); expect(aiKeysOverrides(btoa("[1]"))).toBeNull();
    expect(aiKeysOverrides("A".repeat(5000))).toBeNull(); expect(aiKeysOverrides(btoa(JSON.stringify({ claude: 5, claudeModel: "x y" })))).toBeNull();
  });
  it("key người dùng đè key máy chủ chỉ trong lượt đó; thứ tự người dùng được dùng", async () => {
    const before = process.env["ANTHROPIC_API_KEY"]; process.env["ANTHROPIC_API_KEY"] = "server-key";
    try {
      const r = await withAiSource(async () => ({ key: providerKey("claude"), order: providerOrder(), model: aiEnv()["ANTHROPIC_MODEL"], v: await runChain("t", async (p) => p) }),
        aiKeysOverrides(encodeAiKeys({ claude: "user-key", order: ["claude"], claudeModel: "claude-sonnet-5-5" })));
      expect(r.value).toEqual({ key: "user-key", order: ["claude"], model: "claude-sonnet-5-5", v: "claude" });
      expect(providerKey("claude")).toBe("server-key");
    } finally { if (before === undefined) delete process.env["ANTHROPIC_API_KEY"]; else process.env["ANTHROPIC_API_KEY"] = before; }
  });
});
