/**
 * AI-01 (QD-13): chuỗi nguồn AI dự phòng phía máy chủ — Lovable → Claude → Mistral → Gemini; nguồn nào lỗi/hết lượt/từ chối/quá
 * 60 s thì chuyển nguồn kế; hết nguồn thì báo lỗi (client còn đường xử lý trên máy). Thứ tự đổi bằng AI_PROVIDERS; nguồn thiếu key bị bỏ qua.
 * AI-05 dùng `sensitive`: giấy tờ nhạy cảm không gửi tới nguồn miễn phí (Mistral/Gemini có thể dùng dữ liệu để huấn luyện).
 * Nguồn đã dùng ghi vào ngữ cảnh yêu cầu (AsyncLocalStorage) để trả về client ("ghi nguồn") và ghi nhật ký máy chủ (không chứa nội dung).
 */
import { AsyncLocalStorage } from "node:async_hooks";

export type ProviderId = "lovable" | "claude" | "mistral" | "gemini";
export const ALL_PROVIDERS: readonly ProviderId[] = ["lovable", "claude", "mistral", "gemini"];
/** Nguồn gói miễn phí — không nhận giấy tờ nhạy cảm. */
export const FREE_PROVIDERS: ReadonlySet<ProviderId> = new Set(["mistral", "gemini"]);
export const PROVIDER_KEY_ENV: Record<ProviderId, string> = { lovable: "LOVABLE_API_KEY", claude: "ANTHROPIC_API_KEY", mistral: "MISTRAL_API_KEY", gemini: "GEMINI_API_KEY" };
export const PROVIDER_LABEL: Record<ProviderId, string> = { lovable: "Lovable AI", claude: "Claude", mistral: "Mistral", gemini: "Gemini" };
export const AI_TIMEOUT_MS = 60_000;

type Env = Record<string, string | undefined>;
type Ctx = { source?: ProviderId; tried: { provider: ProviderId; code: number }[]; env?: Env | undefined };
const als = new AsyncLocalStorage<Ctx>();
/** Biến môi trường AI của lượt hiện tại: key người dùng (AI-04, tiêu đề x-ai-keys) đè lên biến máy chủ. */
export const aiEnv = (): Env => als.getStore()?.env ?? (typeof process !== "undefined" ? process.env : {});
const envOf = aiEnv;

/** Thứ tự nguồn dùng được: AI_PROVIDERS (danh sách phẩy, bỏ tên lạ/trùng) hoặc mặc định; chỉ nguồn có key; bỏ nguồn miễn phí khi nhạy cảm. */
export function providerOrder(opts: { sensitive?: boolean | undefined } = {}, env: Env = envOf()): ProviderId[] {
  const wanted = (env["AI_PROVIDERS"] ?? "").split(",").map((s) => s.trim().toLowerCase()).filter((s): s is ProviderId => (ALL_PROVIDERS as readonly string[]).includes(s));
  const list = [...new Set(wanted.length ? wanted : ALL_PROVIDERS)];
  return list.filter((p) => !!env[PROVIDER_KEY_ENV[p]]?.trim() && !(opts.sensitive && FREE_PROVIDERS.has(p)));
}
export const providerKey = (p: ProviderId, env: Env = envOf()) => env[PROVIDER_KEY_ENV[p]]?.trim() ?? "";

/** Mã lỗi HTTP của một lỗi nguồn (SDK: status / statusCode; hết giờ: 408; từ chối: 451). */
export function errorCode(e: unknown): number {
  const x = (e ?? {}) as { statusCode?: number; status?: number; name?: string; refusal?: boolean; lastError?: unknown };
  if (x.refusal) return 451;
  if (x.name === "TimeoutError" || x.name === "AbortError" || x.name === "APIConnectionTimeoutError") return 408;
  const inner = (x.lastError ?? x) as typeof x;
  return inner.statusCode ?? inner.status ?? x.statusCode ?? x.status ?? 500;
}


/** Chạy `attempt` lần lượt trên từng nguồn tới khi có kết quả. Hết nguồn → ném lỗi có nghĩa đầu tiên (bỏ qua lỗi chung 500/401 khi có lỗi
 * cụ thể hơn như hết lượt 402, quá tải 429, từ chối 451, hết giờ 408) để thông báo cho người dùng đúng nguyên nhân. */
export async function runChain<T>(task: string, attempt: (p: ProviderId) => Promise<T>, opts: { sensitive?: boolean | undefined } = {}, env: Env = envOf()): Promise<T> {
  const order = providerOrder(opts, env);
  if (!order.length) throw Object.assign(new Error("no provider"), { statusCode: 401 });
  const ctx = als.getStore(); const errs: unknown[] = [];
  for (const p of order) {
    try {
      const v = await attempt(p);
      if (ctx) ctx.source = p;
      if (errs.length) console.log(`[ai] ${task}: dùng nguồn dự phòng ${p} sau ${errs.length} nguồn lỗi`);
      return v;
    } catch (e) {
      const code = errorCode(e); errs.push(e); ctx?.tried.push({ provider: p, code });
      console.warn(`[ai] ${task}: ${p} lỗi ${code}${p === order[order.length - 1] ? " — hết nguồn" : " → nguồn kế"}`);
    }
  }
  throw errs.find((e) => ![500, 401].includes(errorCode(e))) ?? errs[0];
}

/** Bao một lời gọi AI: trả kết quả kèm nguồn đã phục vụ (và các nguồn đã thử). */
export async function withAiSource<T>(fn: () => Promise<T>, overrides?: Env | null): Promise<{ value: T; source?: ProviderId | undefined; tried: Ctx["tried"] }> {
  const ctx: Ctx = { tried: [], ...(overrides ? { env: { ...(typeof process !== "undefined" ? process.env : {}), ...overrides } } : {}) };
  const value = await als.run(ctx, fn);
  return { value, source: ctx.source, tried: ctx.tried };
}

/**
 * AI-04: đọc tiêu đề x-ai-keys (base64 JSON do ai-keys.ts tạo) → biến ghi đè cho lượt này. Hỏng/thiếu → null.
 * Chỉ nhận chuỗi ngắn; không bao giờ ghi log nội dung.
 */
export function aiKeysOverrides(header: string | null | undefined): Env | null {
  if (!header || header.length > 4000) return null;
  let j: Record<string, unknown>;
  try { j = JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(header), (c) => c.charCodeAt(0)))) as Record<string, unknown>; } catch { return null; }
  if (!j || typeof j !== "object") return null;
  const s = (v: unknown) => (typeof v === "string" && v.trim() && v.length <= 400 ? v.trim() : undefined);
  const out: Env = {};
  const map = { claude: "ANTHROPIC_API_KEY", mistral: "MISTRAL_API_KEY", gemini: "GEMINI_API_KEY" } as const;
  for (const [k, envName] of Object.entries(map)) { const v = s(j[k]); if (v) out[envName] = v; }
  const model = s(j["claudeModel"]); if (model && /^claude-[a-z0-9-]+$/.test(model)) out["ANTHROPIC_MODEL"] = model;
  if (Array.isArray(j["order"])) { const ord = j["order"].filter((p): p is ProviderId => typeof p === "string" && (ALL_PROVIDERS as readonly string[]).includes(p)); if (ord.length) out["AI_PROVIDERS"] = ord.join(","); }
  return Object.keys(out).length ? out : null;
}
