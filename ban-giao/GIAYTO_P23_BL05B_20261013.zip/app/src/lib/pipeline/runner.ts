// CS-02: bộ điều phối nền DÙNG CHUNG TOÀN APP (đề án "Chụp trước – Xử lý sau", báo cáo mục 8.1).
// Lỗi gốc (G-03): bộ xử lý việc "finish" chỉ được đăng ký trong màn Chụp (scan.tsx) và hàng đợi bị huỷ khi rời màn →
// rời màn giữa chừng/tải lại thì không ai hoàn thiện trang. Nay bộ xử lý đăng ký ở gốc app (__root), không huỷ khi đổi màn,
// tiếp tục việc còn dở sau khi tải lại, và ghi kết quả thẳng vào tài liệu đã lưu (nếu trang đã nằm trong tài liệu).
// Đặt sau cờ `globalPipeline` (mặc định bật; tắt = hành vi cũ: bộ xử lý cục bộ trong màn Chụp).
import { bgQueue, type BgJob } from "../bg-queue";
import { ensureDocsLoaded, getDocs, mutateDoc, type Doc, type PageEdit } from "../db";
import { renderPageUrl, targetLong } from "../image";
import { timed } from "../perf-stats";
import { getSettings } from "../settings";

export const pipelineEnabled = (): boolean => getSettings().globalPipeline !== false;

// ——— kết quả "bản đầy đủ" của trang CHƯA nằm trong tài liệu nào (còn trong khay màn Chụp) ———
type Listener = (pageId: string, src: string) => void;
const finished = new Map<string, string>();
const listeners = new Set<Listener>();
export const finishedStore = {
  get: (id: string) => finished.get(id),
  delete: (id: string) => { finished.delete(id); },
  subscribe: (fn: Listener) => { listeners.add(fn); return () => { listeners.delete(fn); }; },
  size: () => finished.size,
};

const DEFAULT_EDIT: PageEdit = { rotation: 0, filter: "original", brightness: 0, contrast: 0 };
// CS-04: so sánh KHÔNG phụ thuộc thứ tự khoá — newPage() trộn trường mặc định theo thứ tự khác với `edit` lưu trong việc nền,
// nên JSON.stringify thẳng coi hai edit giống hệt là khác → bản đầy đủ không bao giờ được ghi vào trang đã lưu (lỗi bị che vì Xong từng chờ flush).
const canon = (v: unknown): unknown => (Array.isArray(v) ? v.map(canon) : v && typeof v === "object"
  ? Object.fromEntries(Object.keys(v).filter((k) => (v as Record<string, unknown>)[k] !== undefined).sort().map((k) => [k, canon((v as Record<string, unknown>)[k])])) : v);
export const sameEdit = (a: PageEdit | undefined, b: PageEdit | undefined) => JSON.stringify(canon(a ?? null)) === JSON.stringify(canon(b ?? null));

/** Ghi bản đầy đủ vào trang trong tài liệu đã lưu. Trả true nếu đã ghi. BL-05a: ghi qua mutateDoc (bản mới nhất, hàng ghi tuần tự)
 *  → không đè thay đổi của nơi khác (xoá, đổi thư mục, OCR…) và hai trang cùng tài liệu không ghi đè nhau. */
export async function applyFinished(pageId: string, src: string, edit: PageEdit | undefined): Promise<boolean> {
  await ensureDocsLoaded().catch(() => {}); // tải lại ở màn không nạp tài liệu → vẫn tìm được trang trong kho
  const doc = getDocs().find((d) => d.pages.some((p) => p.id === pageId)); if (!doc) return false;
  let wrote = false;
  await mutateDoc(doc.id, (d) => {
    if (d.locked || d.enc || d.deletedAt) return null;
    const pg = d.pages.find((p) => p.id === pageId);
    if (!pg || !sameEdit(pg.edit, edit)) return null; // người dùng đã sửa trang này trong lúc chờ → không ghi đè
    wrote = true;
    return { ...d, pages: d.pages.map((p) => (p.id === pageId ? { ...p, src, status: "xong" as const } : p)) }; // CS-04: dang → xong
  });
  return wrote;
}

/** Bộ xử lý việc "finish": dựng bản đầy đủ; ghi vào tài liệu nếu trang đã lưu, không thì giữ cho màn Chụp nhận. */
export async function finishHandler(j: BgJob): Promise<void> {
  const full = j.payload.targetLong ?? targetLong(getSettings().quality === "normal" ? "normal" : "high");
  const src = await timed("finish", () => renderPageUrl(j.payload.orig, j.payload.edit ?? DEFAULT_EDIT, full)); // CS-12: Blob đã đăng ký
  if (await applyFinished(j.pageId, src, j.payload.edit ?? DEFAULT_EDIT)) return;
  finished.set(j.pageId, src);
  listeners.forEach((l) => l(j.pageId, src));
}

/** CS-04 — bất biến "trang dang ⇒ có việc finish trong hàng đợi". Trang dang mà không có việc (kết quả bị một lần ghi tài liệu khác
 *  đè mất — nhiều nơi cùng saveDoc, xem BL-05 — hoặc việc đã lỗi hết lượt) được xếp lại để dựng bản đầy đủ. Trả số việc đã xếp. */
export async function healPending(docs: Doc[] = getDocs()): Promise<number> {
  const full = targetLong(getSettings().quality === "normal" ? "normal" : "high"); let n = 0;
  // Việc đang chờ mang edit CŨ (vd. công thức tự đổi bộ lọc sau khi đã xếp việc) → kết quả của nó sẽ bị từ chối (sameEdit) → phải xếp lại.
  const jobEdit = new Map(bgQueue.list().filter((j) => j.kind === "finish" && (j.state === "queued" || j.state === "running")).map((j) => [j.pageId, j.payload.edit]));
  for (const d of docs) {
    if (d.locked || d.enc || d.deletedAt) continue;
    for (const p of d.pages) {
      if (p.status !== "dang" || !p.orig) continue;
      if (jobEdit.has(p.id) && sameEdit(jobEdit.get(p.id), p.edit)) continue;
      await bgQueue.enqueue(p.id, "finish", { orig: p.orig, edit: p.edit, targetLong: full }); n++;
    }
  }
  return n;
}

/** BL-04: dựng bản đầy đủ hỏng hết lượt → trang "loi" kèm lý do (thay vì "dang" mãi). healPending không tự thử lại trang "loi". */
export async function markFailed(pageId: string, err: unknown): Promise<boolean> {
  const doc = getDocs().find((d) => d.pages.some((p) => p.id === pageId)); if (!doc) return false;
  const why = err instanceof Error ? err.message : err && typeof err === "object" && "type" in err ? "không đọc được ảnh gốc" : String(err); // ảnh lỗi ném Event, không phải Error
  const error = `Chưa dựng được ảnh đầy đủ: ${why.slice(0, 160)}`;
  let wrote = false;
  await mutateDoc(doc.id, (d) => {
    if (d.locked || d.enc || d.deletedAt || d.pages.find((p) => p.id === pageId)?.status !== "dang") return null;
    wrote = true;
    return { ...d, pages: d.pages.map((p) => (p.id === pageId ? { ...p, status: "loi" as const, error } : p)) };
  });
  return wrote;
}

let started = false;
/** Gọi một lần ở gốc app: đăng ký bộ xử lý và chạy tiếp việc còn dở sau khi tải lại. Trả true nếu vừa khởi động. */
export function startPipeline(): boolean {
  if (started || typeof window === "undefined" || !pipelineEnabled()) return false;
  started = true;
  bgQueue.setHandler("finish", finishHandler);
  bgQueue.onGiveUp((j, err) => { if (j.kind === "finish") void markFailed(j.pageId, err); }); // BL-04
  void bgQueue.resume().then(() => ensureDocsLoaded()).then(() => healPending()).catch(() => {}); // CS-04: chữa trang dang mồ côi
  return true;
}
/** Chỉ cho kiểm thử. */
export function _resetPipelineForTest() { started = false; finished.clear(); }
