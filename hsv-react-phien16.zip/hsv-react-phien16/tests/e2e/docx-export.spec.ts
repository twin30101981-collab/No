import { expect, test } from "@playwright/test";
import { readFileSync } from "node:fs";
import { TEMPLATES, deadLabels, templateLabels } from "../../src/lib/hsv/docTemplate";

/**
 * PHIÊN 8 — kiểm chứng "sinh văn bản": không nhãn chết, xuất DOCX thật (tệp mở
 * được, đúng cấu trúc OOXML), chặn xuất khi thiếu trường bắt buộc.
 */

test("mẫu văn bản không có nhãn chết — 100% nhãn tồn tại trong FIELD_META", () => {
  const dead = deadLabels().filter((d) => d.labels.length > 0);
  expect(dead, JSON.stringify(dead, null, 2)).toEqual([]);
  expect(TEMPLATES.length).toBeGreaterThanOrEqual(4);
  for (const t of TEMPLATES) expect(templateLabels(t).length).toBeGreaterThan(5);
});

test("xuất DOCX thật cho từng mẫu — tệp tải về mở được", async ({ page }, testInfo) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error") errors.push(`console.error: ${m.text()}`);
  });

  await page.goto("/xem-truoc", { waitUntil: "domcontentloaded" });
  await page.getByTestId("san-sang").waitFor({ state: "attached" });
  await expect(page.getByTestId("nhan-chet")).toContainText("0/");

  for (const t of TEMPLATES) {
    await page.getByTestId(`mau-${t.id}`).click();
    const [download] = await Promise.all([
      page.waitForEvent("download"),
      page.getByTestId("xuat-docx").click(),
    ]);
    const name = download.suggestedFilename();
    expect(name).toBe(`${t.id.toUpperCase()}_1247_Nguyen-Van-Truong.docx`);

    const file = testInfo.outputPath(name);
    await download.saveAs(file);
    const buf = readFileSync(file);
    // Tệp DOCX là ZIP (PK\x03\x04) và phải chứa word/document.xml
    expect(buf.subarray(0, 4)).toEqual(Buffer.from([0x50, 0x4b, 0x03, 0x04]));
    expect(buf.toString("latin1")).toContain("word/document.xml");
    expect(buf.byteLength).toBeGreaterThan(3000);
    await expect(page.getByTestId("ket-qua-xuat")).toContainText(name);
  }

  await page.screenshot({ path: testInfo.outputPath("anh-xuat-docx-phien8.png") });
  expect(errors).toEqual([]);
});

test("chặn xuất khi hồ sơ thiếu trường bắt buộc", async ({ page }, testInfo) => {
  await page.goto("/xem-truoc", { waitUntil: "domcontentloaded" });
  await page.getByTestId("san-sang").waitFor({ state: "attached" });
  await page.getByTestId("hoso-thieu").click();

  await expect(page.getByTestId("chan-xuat")).toContainText("Chặn xuất");
  await expect(page.getByTestId("xuat-docx")).toBeDisabled();

  await page.screenshot({ path: testInfo.outputPath("anh-chan-xuat-phien8.png") });

  await page.getByTestId("hoso-day-du").click();
  await expect(page.getByTestId("xuat-docx")).toBeEnabled();
});
