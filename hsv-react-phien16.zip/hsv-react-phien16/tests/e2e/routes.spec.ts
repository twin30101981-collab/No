import { test, expect } from "@playwright/test";
import { checkRoute, LEGACY_ALLOWED } from "./helpers";

test("route / — trang phân tích tải sạch", async ({ page }, testInfo) => {
  const errors = await checkRoute(page, testInfo, "/", "home");
  expect(errors, errors.join("\n")).toHaveLength(0);
});

test("route /lo-trinh — lộ trình 6 giai đoạn", async ({ page }, testInfo) => {
  const errors = await checkRoute(page, testInfo, "/lo-trinh", "lo-trinh");
  expect(errors, errors.join("\n")).toHaveLength(0);
});

test("route /pilot — pilot FIELD_META", async ({ page }, testInfo) => {
  const errors = await checkRoute(page, testInfo, "/pilot", "pilot");
  expect(errors, errors.join("\n")).toHaveLength(0);
});

test("route /he-cu — iframe hệ cũ nguyên trạng", async ({ page }, testInfo) => {
  const errors = await checkRoute(page, testInfo, "/he-cu", "he-cu");
  const appErrors = errors.filter((e) => !LEGACY_ALLOWED.some((r) => r.test(e)));
  expect(appErrors, appErrors.join("\n")).toHaveLength(0);
});
