import { expect, test, type Page } from "@playwright/test";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { LEGACY_ALLOWED } from "./helpers";

/**
 * PHIÊN 13:
 *  (1) tìm nhanh + sắp xếp danh mục hồ sơ theo khách hàng;
 *  (2) lưu/nạp bộ hồ sơ ra tệp `.hsv.json` (nạp phải validate như nhập tay);
 *  (3) bảng theo dõi tiến độ hồ sơ (đủ trường / còn thiếu / đã xuất);
 *  (4) hệ cũ vẫn CHỈ ĐỌC sau khi lưu/nạp tệp.
 * Mỗi kịch bản chụp ảnh minh chứng, không được có lỗi console/pageerror.
 */

/**
 * Thư mục tạm ĐƯỜNG DẪN THUẦN ASCII cho tệp tải về: thư mục kết quả của
 * Playwright sinh theo tên kịch bản (có dấu tiếng Việt) khiến trình duyệt
 * không nhận được tệp khi gán vào ô chọn tệp.
 */
const thuMucTep = () => {
  const dir = join(tmpdir(), "hsv-phien13");
  mkdirSync(dir, { recursive: true });
  return dir;
};

async function moTrang(page: Page) {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error" && !LEGACY_ALLOWED.some((r) => r.test(m.text())))
      errors.push(`console.error: ${m.text()}`);
  });
  await page.goto("/xem-truoc", { waitUntil: "domcontentloaded" });
  await page.getByTestId("san-sang").waitFor({ state: "attached" });
  return errors;
}

/** Tạo hồ sơ thứ hai bằng nhân bản rồi đổi tên khách hàng. */
async function themHoSoThuHai(page: Page, tenKH: string, tenHoSo: string) {
  await page.getByTestId("nhan-ban-ho-so").click();
  await page.getByTestId("o-hoso-tenKhachHang").fill(tenKH);
  await page.getByTestId("o-doi-ten-ho-so").fill(tenHoSo);
}

test("tìm nhanh hồ sơ theo tên khách hàng và sắp xếp danh mục", async ({ page }, testInfo) => {
  const errors = await moTrang(page);
  await themHoSoThuHai(page, "Trần Thị Bích Hạnh", "Hộ Trần Thị Bích Hạnh");
  await expect(page.locator('[data-testid^="the-ho-so-"]')).toHaveCount(2);

  await page.getByTestId("o-tim-ho-so").fill("Bích Hạnh");
  await expect(page.locator('[data-testid^="the-ho-so-"]')).toHaveCount(1);
  await expect(page.locator('[data-testid^="the-ho-so-"]').first()).toHaveAttribute(
    "data-ten",
    "Hộ Trần Thị Bích Hạnh",
  );

  await page.getByTestId("o-tim-ho-so").fill("khong-co-ai");
  await expect(page.getByTestId("khong-tim-thay")).toBeVisible();

  // Tìm theo mã khách hàng cũng ra đúng hồ sơ.
  const maKH = await page.getByTestId("o-hoso-maKhachHang").inputValue();
  expect(maKH.length).toBeGreaterThan(0);
  await page.getByTestId("o-tim-ho-so").fill(maKH);
  await expect(page.locator('[data-testid^="the-ho-so-"]')).toHaveCount(2);

  // Sắp xếp theo tên A→Z đổi thứ tự hiển thị.
  await page.getByTestId("o-tim-ho-so").fill("");
  await page.getByTestId("sap-xep-ho-so").selectOption("ten");
  const tenTheoAZ = await page.locator('[data-testid^="the-ho-so-"]').evaluateAll((els) =>
    els.map((e) => e.getAttribute("data-ten") ?? ""),
  );
  expect(tenTheoAZ).toEqual([...tenTheoAZ].sort((a, b) => a.localeCompare(b, "vi")));

  const shot = testInfo.outputPath("anh-tim-kiem-phien13.png");
  await page.getByTestId("khoi-danh-sach-ho-so").screenshot({ path: shot });
  await testInfo.attach("tim-kiem", { path: shot, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("lưu bộ hồ sơ ra tệp .hsv.json rồi nạp lại đủ dữ liệu", async ({ page }, testInfo) => {
  const errors = await moTrang(page);
  await themHoSoThuHai(page, "Trần Thị Bích Hạnh", "Hộ Trần Thị Bích Hạnh");

  const download = await Promise.all([
    page.waitForEvent("download"),
    page.getByTestId("luu-tep-bo-ho-so").click(),
  ]).then(([d]) => d);
  expect(download.suggestedFilename()).toMatch(/^BO-HO-SO_2-ho-so_\d{8}\.hsv\.json$/);
  const file = join(thuMucTep(), download.suggestedFilename());
  await download.saveAs(file);

  const data = JSON.parse(readFileSync(file, "utf8"));
  expect(data.kind).toBe("hsv.boHoSo");
  expect(data.version).toBe(1);
  expect(data.items).toHaveLength(2);
  expect(data.items[1].hoSo.tenKhachHang).toBe("Trần Thị Bích Hạnh");
  expect(Object.keys(data.items[0].hoSo).length).toBeGreaterThan(50);
  await expect(page.getByTestId("ket-qua-tep-bo-ho-so")).toContainText("2 hồ sơ");

  // Nạp lại chính tệp đó: phiên có thêm 2 hồ sơ, dữ liệu nguyên vẹn.
  await page.getByTestId("input-nap-tep").setInputFiles(file);
  await expect(page.getByTestId("ket-qua-tep-bo-ho-so")).toContainText("Đã nạp 2 hồ sơ");
  await expect(page.locator('[data-testid^="the-ho-so-"]')).toHaveCount(4);
  await expect(page.getByTestId("nguon-ho-so")).toContainText(".hsv.json");
  await expect(page.getByTestId("o-hoso-tenKhachHang")).toHaveValue("Nguyễn Văn Trường");

  const shot = testInfo.outputPath("anh-luu-nap-tep-phien13.png");
  await page.getByTestId("khoi-danh-sach-ho-so").screenshot({ path: shot });
  await testInfo.attach("luu-nap-tep", { path: shot, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("tệp nạp vào đi qua đúng bộ kiểm tra như nhập tay", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  // Hồ sơ thiếu trường bắt buộc rồi mới lưu ra tệp.
  await page.getByTestId("hoso-thieu").click();
  await expect(page.getByTestId("chan-xuat")).toBeVisible();
  const download = await Promise.all([
    page.waitForEvent("download"),
    page.getByTestId("luu-tep-bo-ho-so").click(),
  ]).then(([d]) => d);
  const file = join(thuMucTep(), download.suggestedFilename());
  await download.saveAs(file);

  // Nạp lại: hồ sơ nạp vào vẫn bị bắt lỗi y như khi gõ tay, và bị chặn xuất.
  await page.getByTestId("input-nap-tep").setInputFiles(file);
  await expect(page.getByTestId("ket-qua-tep-bo-ho-so")).toContainText("Đã nạp 1 hồ sơ");
  await expect(page.getByTestId("chan-xuat")).toBeVisible();
  await expect(page.getByTestId("xuat-docx")).toBeDisabled();
  await expect(page.getByTestId("xuat-zip-tron-bo")).toBeDisabled();

  // Tệp sai định dạng: báo lỗi rõ ràng, không thêm hồ sơ nào.
  const soHoSo = await page.locator('[data-testid^="the-ho-so-"]').count();
  const bad = join(thuMucTep(), "khong-phai-hsv.json");
  writeFileSync(bad, JSON.stringify({ hello: "world" }));
  await page.getByTestId("input-nap-tep").setInputFiles(bad);
  await expect(page.getByTestId("loi-tep-bo-ho-so")).toContainText("Không phải tệp bộ hồ sơ HSV");
  await expect(page.locator('[data-testid^="the-ho-so-"]')).toHaveCount(soHoSo);

  const hong = join(thuMucTep(), "hong.json");
  writeFileSync(hong, "{ khong phai json");
  await page.getByTestId("input-nap-tep").setInputFiles(hong);
  await expect(page.getByTestId("loi-tep-bo-ho-so")).toContainText("không phải JSON hợp lệ");

  const shot = testInfo.outputPath("anh-nap-tep-validate-phien13.png");
  await page.screenshot({ path: shot });
  await testInfo.attach("nap-tep-validate", { path: shot, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("bảng tiến độ cho biết hồ sơ nào đủ trường, thiếu gì, đã xuất chưa", async ({
  page,
}, testInfo) => {
  const errors = await moTrang(page);

  const bang = page.getByTestId("bang-tien-do");
  await expect(bang).toBeVisible();
  await expect(page.getByTestId("tom-tat-tien-do")).toContainText("1/1 hồ sơ đủ trường");

  // Hồ sơ mới (trống) phải hiện "Thiếu N" kèm tên trường còn thiếu.
  await page.getByTestId("them-ho-so").click();
  const idMoi = await page
    .locator('[data-testid^="dong-tien-do-"][data-du="false"]')
    .first()
    .getAttribute("data-testid");
  expect(idMoi).toBeTruthy();
  await expect(page.locator(`[data-testid="${idMoi}"]`)).toContainText("Thiếu");
  await expect(page.getByTestId("tom-tat-tien-do")).toContainText("1 còn thiếu");

  // Quay lại hồ sơ mẫu (đủ trường), xuất DOCX ⇒ cột "Đã xuất" có mốc thời gian.
  await page.locator('[data-testid^="the-ho-so-"][data-ten*="Nguyễn Văn Trường"]').first().click();
  await expect(page.getByTestId("chan-xuat")).toHaveCount(0);
  const download = await Promise.all([
    page.waitForEvent("download"),
    page.getByTestId("xuat-docx").click(),
  ]).then(([d]) => d);
  await download.saveAs(testInfo.outputPath(download.suggestedFilename()));

  await expect(page.getByTestId("tom-tat-tien-do")).toContainText("1 đã xuất tài liệu");
  const daXuat = page.locator('[data-testid^="da-xuat-"]');
  const gia = await daXuat.allInnerTexts();
  expect(gia.some((t) => /\d{2}\/\d{2} \d{2}:\d{2}/.test(t))).toBe(true);

  const shot = testInfo.outputPath("anh-bang-tien-do-phien13.png");
  await bang.screenshot({ path: shot });
  await testInfo.attach("bang-tien-do", { path: shot, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("dữ liệu hệ cũ nguyên vẹn sau khi lưu và nạp tệp bộ hồ sơ (chỉ đọc)", async ({
  page,
}, testInfo) => {
  const legacy = { "hsv:hoso:KH909": JSON.stringify({ "Tên khách hàng vay HM": "Lê Thị Mai" }) };
  await page.addInitScript((data) => {
    for (const [k, v] of Object.entries(data as Record<string, string>))
      window.localStorage.setItem(k, v);
  }, legacy);

  const errors = await moTrang(page);
  const download = await Promise.all([
    page.waitForEvent("download"),
    page.getByTestId("luu-tep-bo-ho-so").click(),
  ]).then(([d]) => d);
  const file = join(thuMucTep(), download.suggestedFilename());
  await download.saveAs(file);
  await page.getByTestId("input-nap-tep").setInputFiles(file);
  await expect(page.getByTestId("ket-qua-tep-bo-ho-so")).toContainText("Đã nạp");

  const sau = await page.evaluate(() => ({
    khoa: Object.keys(window.localStorage),
    gia: window.localStorage.getItem("hsv:hoso:KH909"),
  }));
  expect(sau.khoa).toContain("hsv:hoso:KH909");
  expect(sau.gia).toBe(legacy["hsv:hoso:KH909"]);

  const shot = testInfo.outputPath("anh-he-cu-nguyen-ven-phien13.png");
  await page.screenshot({ path: shot });
  await testInfo.attach("he-cu-nguyen-ven", { path: shot, contentType: "image/png" });
  expect(errors).toEqual([]);
});
