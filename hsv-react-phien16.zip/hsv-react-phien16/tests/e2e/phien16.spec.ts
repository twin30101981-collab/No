import { expect, test, type Page, type TestInfo } from "@playwright/test";
import { LEGACY_ALLOWED } from "./helpers";

/**
 * PHIÊN 16 — "nhiều người cùng làm & lưu vết":
 *  (1) chủ sở hữu + luân chuyển Soạn → Trình → Duyệt, trả lại phải có lý do;
 *  (2) lưu mốc phiên bản và so sánh trước/sau;
 *  (3) đối chiếu số liệu giữa các tài liệu;
 *  (4) gói dùng chung theo phòng: chốt bản, xuất tệp;
 *  (5) phiếu kiểm tra một trang trước khi trình ký.
 * Mỗi kịch bản chụp ảnh minh chứng, không có lỗi console/pageerror.
 */

async function moTrang(page: Page) {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error" && !LEGACY_ALLOWED.some((r) => r.test(m.text())))
      errors.push(`console.error: ${m.text()}`);
  });
  await page.goto("/xem-truoc", { waitUntil: "domcontentloaded" });
  await page.getByTestId("san-sang").waitFor({ state: "attached" });
  await page.getByTestId("khoi-cong-cu-phien16").scrollIntoViewIfNeeded();
  return errors;
}

async function anh(page: Page, testInfo: TestInfo, slug: string) {
  const file = testInfo.outputPath(`${slug}.png`);
  await page.screenshot({ path: file });
  await testInfo.attach(slug, { path: file, contentType: "image/png" });
}

test("luân chuyển: soạn → trình → duyệt, trả lại phải có lý do", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await expect(page.getByTestId("trang-thai-ho-so")).toHaveText("Đang soạn");

  // Thiếu tên người thực hiện ⇒ chặn.
  await page.getByTestId("nut-trinh").click();
  await expect(page.getByTestId("thong-bao-luan-chuyen")).toBeVisible();
  await expect(page.getByTestId("trang-thai-ho-so")).toHaveText("Đang soạn");

  await page.getByTestId("o-chu-so-huu").fill("Nguyễn Văn A — CBTD");
  await page.getByTestId("o-nguoi-thuc-hien").fill("Nguyễn Văn A — CBTD");
  await page.getByTestId("nut-trinh").click();
  await expect(page.getByTestId("trang-thai-ho-so")).toHaveText("Chờ kiểm soát");
  await expect(page.getByTestId("dong-luan-chuyen")).toHaveCount(1);

  // Trả lại mà không ghi lý do ⇒ chặn.
  await page.getByTestId("o-nguoi-thuc-hien").fill("Trần Thị B — KSV");
  await page.getByTestId("nut-tra-lai").click();
  await expect(page.getByTestId("trang-thai-ho-so")).toHaveText("Chờ kiểm soát");

  await page.getByTestId("o-ghi-chu-luan-chuyen").fill("Thiếu chứng từ thu nhập");
  await page.getByTestId("nut-tra-lai").click();
  await expect(page.getByTestId("trang-thai-ho-so")).toHaveText("Trả lại để sửa");
  await expect(page.getByTestId("dong-luan-chuyen")).toHaveCount(2);

  await anh(page, testInfo, "p16-luan-chuyen");
  expect(errors).toEqual([]);
});

test("phiên bản: lưu hai mốc rồi so sánh ra đúng trường đã sửa", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await page.getByTestId("o-hoso-soTienVay").fill("500000000");
  await page.getByTestId("khoi-cong-cu-phien16").scrollIntoViewIfNeeded();
  await page.getByTestId("o-nguoi-thuc-hien").fill("Nguyễn Văn A");
  await page.getByTestId("o-nhan-phien-ban").fill("Trước khi sửa");
  await page.getByTestId("nut-luu-phien-ban").click();
  await expect(page.getByTestId("so-phien-ban")).toHaveText(/1 mốc/);

  await page.getByTestId("o-hoso-soTienVay").fill("650000000");
  await page.getByTestId("khoi-cong-cu-phien16").scrollIntoViewIfNeeded();
  await page.getByTestId("o-nhan-phien-ban").fill("Sau khi sửa");
  await page.getByTestId("nut-luu-phien-ban").click();
  await expect(page.getByTestId("so-phien-ban")).toHaveText(/2 mốc/);

  await expect(page.getByTestId("bang-so-sanh")).toBeVisible();
  await expect(page.getByTestId("khac-soTienVay")).toContainText(/650/);
  await expect(page.getByTestId("tom-tat-so-sanh")).toContainText(/trường khác nhau/);

  await anh(page, testInfo, "p16-so-sanh-phien-ban");
  expect(errors).toEqual([]);
});

test("đối chiếu tài liệu và phiếu kiểm tra một trang", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await expect(page.getByTestId("khoi-kiem-tra-tai-lieu")).toBeVisible();
  await expect(page.getByTestId("so-loi-tai-lieu")).toBeVisible();

  await expect(page.getByTestId("khoi-phieu-kiem-tra")).toBeVisible();
  await expect(page.getByTestId("phieu-ket-luan")).toContainText(/ĐỦ ĐIỀU KIỆN|CHƯA ĐỦ/);

  const tai = page.waitForEvent("download");
  await page.getByTestId("nut-tai-phieu").click();
  const file = await tai;
  expect(file).toBeTruthy();

  await anh(page, testInfo, "p16-phieu-kiem-tra");
  expect(errors).toEqual([]);
});

test("gói dùng chung theo phòng: chốt bản rồi xuất tệp .goi.hsv.json", async ({
  page,
}, testInfo) => {
  const errors = await moTrang(page);

  await expect(page.getByTestId("so-ban-ho-so")).toHaveText("bản 1");
  await page.getByTestId("nut-chot-ban").click();
  await expect(page.getByTestId("so-ban-ho-so")).toHaveText("bản 2");

  await page.getByTestId("o-ten-phong").fill("Phòng KHKD Thiên Trường");
  await page.getByTestId("o-nguoi-thuc-hien").fill("Nguyễn Văn A");
  const tai = page.waitForEvent("download");
  await page.getByTestId("nut-xuat-goi").click();
  const file = await tai;
  expect(file.suggestedFilename()).toMatch(/\.goi\.hsv\.json$/);
  await expect(page.getByTestId("thong-bao-goi")).toContainText("Đã xuất");

  await anh(page, testInfo, "p16-goi-phong");
  expect(errors).toEqual([]);
});

test("hệ cũ vẫn CHỈ ĐỌC sau các thao tác phiên 16", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await page.getByTestId("o-chu-so-huu").fill("Nguyễn Văn A");
  await page.getByTestId("o-nguoi-thuc-hien").fill("Nguyễn Văn A");
  await page.getByTestId("nut-trinh").click();

  const res = await page.request.post("/api/legacy/hoso", { data: {} });
  expect([403, 404, 405]).toContain(res.status());

  await anh(page, testInfo, "p16-he-cu-chi-doc");
  expect(errors).toEqual([]);
});
