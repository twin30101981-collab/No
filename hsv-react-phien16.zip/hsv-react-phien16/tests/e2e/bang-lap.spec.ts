import { expect, test } from "@playwright/test";
import { readFileSync } from "node:fs";
import { inflateRawSync } from "node:zlib";
import { TABLE_META } from "../../src/lib/hsv/tableMeta";

/**
 * PHIÊN 8 (nửa sau) — bảng lặp dòng nhập liệu + bảng thật trong DOCX.
 * 1) Thêm/xoá dòng cập nhật đúng tổng.
 * 2) Tệp DOCX xuất ra chứa bảng (w:tbl) đúng số dòng của danh mục TSBĐ.
 */

/** Giải nén word/document.xml từ tệp .docx (ZIP) mà không cần thư viện ngoài. */
function readDocumentXml(file: string): string {
  const buf = readFileSync(file);
  const name = Buffer.from("word/document.xml");
  for (let i = 0; i < buf.length - 4; i++) {
    if (buf.readUInt32LE(i) !== 0x04034b50) continue;
    const nameLen = buf.readUInt16LE(i + 26);
    const extraLen = buf.readUInt16LE(i + 28);
    const start = i + 30;
    if (!buf.subarray(start, start + nameLen).equals(name)) continue;
    const method = buf.readUInt16LE(i + 8);
    let size = buf.readUInt32LE(i + 18);
    const dataStart = start + nameLen + extraLen;
    if (size === 0) size = buf.length - dataStart; // streaming: giải nén tới hết
    const data = buf.subarray(dataStart, dataStart + size);
    return (method === 0 ? data : inflateRawSync(data)).toString("utf8");
  }
  throw new Error("Không tìm thấy word/document.xml trong tệp DOCX");
}

test("bảng lặp dòng — thêm/xoá dòng cập nhật đúng tổng", async ({ page }, testInfo) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error") errors.push(`console.error: ${m.text()}`);
  });

  await page.goto("/xem-truoc", { waitUntil: "domcontentloaded" });
  await page.getByTestId("san-sang").waitFor({ state: "attached" });

  const key = "danhSachTaiSan";
  const rows = page.locator(`section[data-table="${key}"] tbody tr`);
  await expect(rows).toHaveCount(3);
  await expect(page.getByTestId(`tong-bang-${key}`)).toContainText("3.670.000.000");

  // Thêm 1 tài sản mới ⇒ tổng tăng đúng bằng giá trị vừa nhập
  await page.getByTestId(`them-dong-${key}`).click();
  await expect(rows).toHaveCount(4);
  await page.getByTestId(`o-${key}-3-tenTaiSan`).fill("Máy gặt đập liên hợp");
  await page.getByTestId(`o-${key}-3-giayToSoHuu`).fill("Hoá đơn VAT 0012345");
  await page.getByTestId(`o-${key}-3-diaChi`).fill("Kho hộ vay, xã Nam Vân");
  await page.getByTestId(`o-${key}-3-giaTri`).fill("330000000");
  await expect(page.getByTestId(`tong-bang-${key}`)).toContainText("4.000.000.000");

  // Xoá dòng thứ 3 (xe tải 420 triệu) ⇒ tổng giảm đúng
  await page.getByTestId(`xoa-dong-${key}-2`).click();
  await expect(rows).toHaveCount(3);
  await expect(page.getByTestId(`tong-bang-${key}`)).toContainText("3.580.000.000");

  // Bảng chi phí vật tư giữ nguyên 14 dòng và tổng 152.000.000
  await expect(page.locator('section[data-table="chiPhiVatTu"] tbody tr')).toHaveCount(14);
  await expect(page.getByTestId("tong-bang-chiPhiVatTu")).toContainText("152.000.000");

  const shot = testInfo.outputPath("anh-bang-lap-phien8b.png");
  await page.screenshot({ path: shot });
  await testInfo.attach("bang-lap", { path: shot, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("xuất DOCX có bảng thật đúng số dòng (vá vòng lặp tài sản 16.7)", async ({
  page,
}, testInfo) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error") errors.push(`console.error: ${m.text()}`);
  });

  await page.goto("/xem-truoc", { waitUntil: "domcontentloaded" });
  await page.getByTestId("san-sang").waitFor({ state: "attached" });

  await page.getByTestId("them-dong-danhSachTaiSan").click();
  await page.getByTestId("o-danhSachTaiSan-3-tenTaiSan").fill("Máy gặt đập liên hợp");
  await page.getByTestId("o-danhSachTaiSan-3-giaTri").fill("330000000");

  await page.getByTestId("mau-hdtc").click();
  const [download] = await Promise.all([
    page.waitForEvent("download"),
    page.getByTestId("xuat-docx").click(),
  ]);
  const file = testInfo.outputPath(download.suggestedFilename());
  await download.saveAs(file);

  const xml = readDocumentXml(file);
  const tableCount = (xml.match(/<w:tbl>/g) ?? []).length;
  // PHIÊN 12B: + 1 bảng chữ ký (người lập – người kiểm soát – người duyệt) ở cuối văn bản.
  expect(tableCount).toBe(TABLE_META.length + 1);

  // Bảng TSBĐ: 1 dòng tiêu đề + 4 tài sản + 1 dòng tổng = 6 dòng
  const firstTable = xml.slice(xml.indexOf("<w:tbl>"), xml.indexOf("</w:tbl>"));
  expect((firstTable.match(/<w:tr[ >]/g) ?? []).length).toBe(6);
  expect(xml).toContain("DANH MỤC TÀI SẢN BẢO ĐẢM");
  expect(xml).toContain("Máy gặt đập liên hợp");
  expect(xml).toContain("Xe tải Hyundai 3,5 tấn");
  expect(xml).toContain("BẢNG CHI PHÍ VẬT TƯ PHƯƠNG ÁN SXKD");
  expect(xml).toContain("TỔNG CỘNG");

  await expect(page.getByTestId("ket-qua-xuat")).toContainText("dòng bảng lặp");
  const shot = testInfo.outputPath("anh-xuat-docx-bang-phien8b.png");
  await page.screenshot({ path: shot });
  await testInfo.attach("xuat-docx-bang", { path: shot, contentType: "image/png" });
  expect(errors).toEqual([]);
});
