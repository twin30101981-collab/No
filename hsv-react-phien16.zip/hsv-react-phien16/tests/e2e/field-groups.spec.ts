import { test, expect } from "@playwright/test";

/** Phiên 6 — đếm trực tiếp DOM số dòng từng nhóm trường trên /pilot. */
const EXPECTED: Record<string, number> = {
  "khach-hang": 37,
  "khoan-vay": 27,
  tsbd: 99,
  "pa-sxkd": 102,
  "giai-ngan": 55,
};

test("pilot — mỗi nhóm FIELD_META hiển thị đúng số dòng", async ({ page }) => {
  await page.goto("/pilot", { waitUntil: "domcontentloaded" });
  for (const [group, count] of Object.entries(EXPECTED)) {
    const rows = page.locator(`section[data-group="${group}"] dl > div`);
    await expect(rows).toHaveCount(count);
  }
  const total = Object.values(EXPECTED).reduce((a, b) => a + b, 0);
  expect(total).toBe(320);
});

test("pilot — bảng lặp dòng chi phí vật tư đúng 14 dòng và có tổng cộng", async ({ page }) => {
  await page.goto("/pilot", { waitUntil: "domcontentloaded" });
  const rows = page.locator('section[data-repeatable="chiPhiVatTu"] tbody tr');
  await expect(rows).toHaveCount(14);
  await expect(page.getByTestId("tong-chiPhiVatTu")).toContainText("152.000.000");
});
