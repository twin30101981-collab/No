import { expect, test, type Page } from "@playwright/test";
import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";
import { LEGACY_ALLOWED } from "./helpers";
import { TEMPLATES } from "../../src/lib/hsv/docTemplate";

/**
 * PHIÊN 12 — PHẦN 2 (12B):
 *  (3) xuất trọn bộ 4 mẫu trong MỘT tệp ZIP kèm trang bìa mục lục;
 *  (4) ký/duyệt nội bộ (người lập – người kiểm soát – người duyệt) in đúng chỗ trong DOCX.
 * Mỗi kịch bản chụp ảnh minh chứng và bắt buộc không có lỗi console/pageerror.
 */

async function moTrang(page: Page) {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error" && !LEGACY_ALLOWED.some((r) => r.test(m.text())))
      errors.push(`console.error: ${m.text()}`);
  });
  await page.goto("/xem-truoc", { waitUntil: "domcontentloaded" });
  await page.getByTestId("san-sang").waitFor({ state: "attached" });
  return errors;
}

const danhSachTepZip = (path: string) =>
  execFileSync("unzip", ["-Z1", path], { encoding: "utf8" })
    .split("\n")
    .map((s) => s.trim())
    .filter((s) => s && !s.endsWith("/"));

const docXml = (path: string) =>
  execFileSync("unzip", ["-p", path, "word/document.xml"], {
    encoding: "utf8",
    maxBuffer: 32 * 1024 * 1024,
  });

/** DOCX nằm bên trong ZIP: bung ra tệp tạm rồi mới đọc word/document.xml. */
const docXmlTrongZip = (zipPath: string, entry: string, out: string) => {
  const buf = execFileSync("unzip", ["-p", zipPath, entry], { maxBuffer: 64 * 1024 * 1024 });
  writeFileSync(out, buf);
  return docXml(out);
};

test("ký/duyệt nội bộ in đúng chỗ ký trong cả 4 mẫu DOCX", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await page.getByTestId("o-hoso-nguoiLap").fill("Nguyễn Thị Lan");
  await page.getByTestId("o-hoso-nguoiKiemSoat").fill("Trần Quang Huy");
  await page.getByTestId("o-hoso-nguoiPheDuyet").fill("Phạm Văn Sơn");
  await expect(page.getByTestId("chan-xuat")).toHaveCount(0);

  for (const t of TEMPLATES) {
    await page.getByTestId(`mau-${t.id}`).click();
    const download = await Promise.all([
      page.waitForEvent("download"),
      page.getByTestId("xuat-docx").click(),
    ]).then(([d]) => d);
    const file = testInfo.outputPath(download.suggestedFilename());
    await download.saveAs(file);

    const xml = docXml(file);
    const text = xml.replace(/<[^>]+>/g, "");
    for (const vaiTro of ["NGƯỜI LẬP", "NGƯỜI KIỂM SOÁT", "NGƯỜI DUYỆT"])
      expect(text, `${t.id}: thiếu chỗ ký ${vaiTro}`).toContain(vaiTro);
    expect(text).toContain("Nguyễn Thị Lan");
    expect(text).toContain("Trần Quang Huy");
    expect(text).toContain("Phạm Văn Sơn");
    expect(text).toContain("Nam Định, ngày 20 tháng 08 năm 2026");
    // Khối ký nằm CUỐI văn bản, sau phần nội dung và bảng lặp.
    expect(text.indexOf("NGƯỜI LẬP")).toBeGreaterThan(text.indexOf("TỔNG CỘNG"));
    // Bảng chữ ký là bảng thật, nằm sau các bảng dữ liệu.
    expect((xml.match(/<w:tbl>/g) ?? []).length, `số bảng ${t.id}`).toBe(3);
  }

  const shot = testInfo.outputPath("anh-ky-duyet-phien12b.png");
  await page.getByTestId("khoi-ky-duyet").screenshot({ path: shot });
  await testInfo.attach("ky-duyet", { path: shot, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("thiếu người ký thì chặn xuất như mọi trường bắt buộc khác", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await page.getByTestId("o-hoso-nguoiKiemSoat").fill("");
  await expect(page.getByTestId("chan-xuat")).toContainText("Người kiểm soát");
  await expect(page.getByTestId("xuat-docx")).toBeDisabled();
  await expect(page.getByTestId("xuat-zip-tron-bo")).toBeDisabled();

  await page.getByTestId("o-hoso-nguoiKiemSoat").fill("Trần Quang Huy");
  await expect(page.getByTestId("chan-xuat")).toHaveCount(0);
  await expect(page.getByTestId("xuat-zip-tron-bo")).toBeEnabled();

  const shot = testInfo.outputPath("anh-chan-xuat-ky-duyet-phien12b.png");
  await page.screenshot({ path: shot });
  await testInfo.attach("chan-xuat-ky-duyet", { path: shot, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("xuất trọn bộ 4 mẫu của hồ sơ đang chọn vào một tệp ZIP kèm trang bìa", async ({
  page,
}, testInfo) => {
  const errors = await moTrang(page);

  const download = await Promise.all([
    page.waitForEvent("download"),
    page.getByTestId("xuat-zip-tron-bo").click(),
  ]).then(([d]) => d);

  expect(download.suggestedFilename()).toMatch(/^BO-HO-SO_Nguyen-Van-Truong_\d{8}\.zip$/);
  const file = testInfo.outputPath(download.suggestedFilename());
  await download.saveAs(file);

  const tep = danhSachTepZip(file);
  expect(tep).toHaveLength(TEMPLATES.length + 1);
  expect(tep).toContain("00_TRANG-BIA-MUC-LUC.docx");
  for (const t of TEMPLATES)
    expect(tep).toContain(`${t.id.toUpperCase()}_1247_Nguyen-Van-Truong.docx`);

  // Trang bìa là DOCX thật và liệt kê đúng tên 4 tệp trong bộ.
  const bia = docXmlTrongZip(file, "00_TRANG-BIA-MUC-LUC.docx", testInfo.outputPath("bia.docx"));
  expect(bia.trimStart().slice(0, 5)).toBe("<?xml");
  const biaText = bia.replace(/<[^>]+>/g, "");
  expect(biaText).toContain("TRANG BÌA &amp; MỤC LỤC");
  expect(biaText).toContain("Nguyễn Văn Trường");
  expect(biaText).toContain("NGƯỜI DUYỆT: Phạm Văn Sơn");
  for (const t of TEMPLATES)
    expect(biaText, `trang bìa thiếu ${t.id}`).toContain(
      `${t.id.toUpperCase()}_1247_Nguyen-Van-Truong.docx`,
    );

  // Mỗi mẫu trong ZIP vẫn là DOCX mở được (ZIP lồng ZIP, đủ độ dài).
  expect(readFileSync(file).byteLength).toBeGreaterThan(10_000);

  await expect(page.getByTestId("ket-qua-zip")).toContainText("trang bìa mục lục");
  const shot = testInfo.outputPath("anh-xuat-zip-phien12b.png");
  await page.screenshot({ path: shot });
  await testInfo.attach("xuat-zip", { path: shot, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("xuất trọn bộ cho nhiều hồ sơ đã đánh dấu — mỗi hồ sơ một thư mục", async ({
  page,
}, testInfo) => {
  const errors = await moTrang(page);

  // Hồ sơ thứ hai: nhân bản hồ sơ mẫu rồi đổi tên khách hàng.
  await page.getByTestId("nhan-ban-ho-so").click();
  await page.getByTestId("o-hoso-tenKhachHang").fill("Trần Thị Bích Hạnh");
  await page.getByTestId("o-doi-ten-ho-so").fill("Hộ Trần Thị Bích Hạnh");

  const the = page.locator('[data-testid^="the-ho-so-"]');
  await expect(the).toHaveCount(2);
  for (const cb of await page.locator('[data-testid^="chon-xuat-"]').all()) await cb.check();

  await expect(page.getByTestId("xuat-zip-nhieu-ho-so")).toContainText("2 hồ sơ");
  const download = await Promise.all([
    page.waitForEvent("download"),
    page.getByTestId("xuat-zip-nhieu-ho-so").click(),
  ]).then(([d]) => d);

  expect(download.suggestedFilename()).toMatch(/^BO-HO-SO_2-ho-so_\d{8}\.zip$/);
  const file = testInfo.outputPath(download.suggestedFilename());
  await download.saveAs(file);

  const tep = danhSachTepZip(file);
  expect(tep).toHaveLength(2 * TEMPLATES.length + 1);
  expect(tep.filter((t) => t.startsWith("01_"))).toHaveLength(TEMPLATES.length);
  expect(tep.filter((t) => t.startsWith("02_"))).toHaveLength(TEMPLATES.length);
  expect(tep.some((t) => t.includes("Tran-Thi-Bich-Hanh.docx"))).toBe(true);

  const biaText = docXmlTrongZip(
    file,
    "00_TRANG-BIA-MUC-LUC.docx",
    testInfo.outputPath("bia.docx"),
  ).replace(/<[^>]+>/g, "");
  expect(biaText).toContain("Số hồ sơ trong bộ: 2");
  expect(biaText).toContain("Hộ Trần Thị Bích Hạnh");

  await expect(page.getByTestId("ket-qua-zip")).toContainText("2 hồ sơ");
  const shot = testInfo.outputPath("anh-xuat-zip-nhieu-ho-so-phien12b.png");
  await page.screenshot({ path: shot });
  await testInfo.attach("xuat-zip-nhieu", { path: shot, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("dữ liệu hệ cũ giữ nguyên sau khi xuất trọn bộ ZIP (chỉ đọc)", async ({ page }, testInfo) => {
  const legacy = { "hsv:hoso:KH777": JSON.stringify({ "Tên khách hàng vay HM": "Vũ Văn Bảo" }) };
  await page.addInitScript((data) => {
    for (const [k, v] of Object.entries(data as Record<string, string>))
      window.localStorage.setItem(k, v);
  }, legacy);

  const errors = await moTrang(page);
  const download = await Promise.all([
    page.waitForEvent("download"),
    page.getByTestId("xuat-zip-tron-bo").click(),
  ]).then(([d]) => d);
  await download.saveAs(testInfo.outputPath(download.suggestedFilename()));

  const conNguyen = await page.evaluate(
    (d) =>
      Object.entries(d as Record<string, string>).every(
        ([k, v]) => window.localStorage.getItem(k) === v,
      ),
    legacy,
  );
  expect(conNguyen).toBe(true);

  const shot = testInfo.outputPath("anh-he-cu-nguyen-ven-phien12b.png");
  await page.screenshot({ path: shot });
  await testInfo.attach("he-cu-nguyen-ven", { path: shot, contentType: "image/png" });
  expect(errors).toEqual([]);
});
