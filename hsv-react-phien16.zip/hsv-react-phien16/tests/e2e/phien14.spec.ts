import { expect, test, type Page } from "@playwright/test";
import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { LEGACY_ALLOWED } from "./helpers";

/**
 * PHIÊN 14:
 *  (1) mẫu dữ liệu dùng lại — lưu bộ trường chung, áp sang hồ sơ mới;
 *  (2) nhập hàng loạt danh sách khách hàng từ bảng CSV (dán và từ tệp);
 *  (3) bảng CSV sai tiêu đề bị từ chối kèm thông báo rõ ràng;
 *  (4) nhật ký thao tác + hoàn tác khôi phục hồ sơ vừa xoá;
 *  (5) hệ cũ vẫn CHỈ ĐỌC sau mọi thao tác trên.
 * Mỗi kịch bản chụp ảnh minh chứng, không được có lỗi console/pageerror.
 */

/** Đường dẫn tệp tải/nạp phải THUẦN ASCII (bài học phiên 13). */
const thuMucTep = () => {
  const dir = join(tmpdir(), "hsv-phien14");
  mkdirSync(dir, { recursive: true });
  return dir;
};

async function moTrang(page: Page) {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error" && !LEGACY_ALLOWED.some((r) => r.test(m.text())))
      errors.push(`console.error: ${m.text()}`);
  });
  await page.goto("/xem-truoc", { waitUntil: "domcontentloaded" });
  await page.getByTestId("san-sang").waitFor({ state: "attached" });
  return errors;
}

async function anh(page: Page, testInfo: import("@playwright/test").TestInfo, slug: string) {
  const file = testInfo.outputPath(`${slug}.png`);
  await page.screenshot({ path: file });
  await testInfo.attach(slug, { path: file, contentType: "image/png" });
}

test("mẫu dữ liệu dùng lại: lưu một lần, áp sang hồ sơ mới không phải gõ lại", async ({
  page,
}, testInfo) => {
  const errors = await moTrang(page);

  // Đặt bộ trường dùng chung của chi nhánh trên hồ sơ đang soạn.
  await page.getByTestId("o-hoso-nguoiLap").fill("Vũ Minh Quân");
  await page.getByTestId("o-hoso-nguoiKiemSoat").fill("Đỗ Thị Lan");
  await page.getByTestId("o-hoso-nguoiPheDuyet").fill("Lê Văn Hùng");

  await page.getByTestId("o-ten-mau").fill("Mẫu tổ tín dụng số 1");
  await page.getByTestId("luu-mau-dung-lai").click();
  await expect(page.getByTestId("ket-qua-mau")).toContainText("Đã lưu mẫu");
  await expect(page.getByTestId("danh-sach-mau").locator("li")).toHaveCount(1);

  // Hồ sơ mới hoàn toàn trống các trường ký duyệt.
  await page.getByTestId("them-ho-so").click();
  await expect(page.getByTestId("o-hoso-nguoiLap")).toHaveValue("");

  await page.locator('[data-testid^="ap-mau-"]').first().click();
  await expect(page.getByTestId("ket-qua-mau")).toContainText("Đã áp mẫu");
  await expect(page.getByTestId("o-hoso-nguoiLap")).toHaveValue("Vũ Minh Quân");
  await expect(page.getByTestId("o-hoso-nguoiKiemSoat")).toHaveValue("Đỗ Thị Lan");
  await expect(page.getByTestId("o-hoso-nguoiPheDuyet")).toHaveValue("Lê Văn Hùng");

  // Mẫu KHÔNG chép trường riêng của khách hàng sang hồ sơ khác.
  await expect(page.getByTestId("o-hoso-tenKhachHang")).toHaveValue("");

  await anh(page, testInfo, "phien14-mau-dung-lai");
  expect(errors, errors.join("\n")).toEqual([]);
});

test("nhập hàng loạt từ bảng CSV: mỗi dòng thành một hồ sơ trong phiên", async ({
  page,
}, testInfo) => {
  const errors = await moTrang(page);
  const truoc = await page.locator('[data-testid^="the-ho-so-"]').count();

  await page.getByTestId("dien-csv-mau").click();
  await page.getByTestId("nhap-hang-loat").click();

  await expect(page.getByTestId("ket-qua-csv")).toContainText("Đã tạo 3/3 hồ sơ");
  await expect(page.locator('[data-testid^="the-ho-so-"]')).toHaveCount(truoc + 3);

  // Tìm đúng khách hàng vừa nhập hàng loạt và dữ liệu vào đúng ô.
  await page.getByTestId("o-tim-ho-so").fill("Trần Thị Bình");
  await expect(page.locator('[data-testid^="the-ho-so-"]')).toHaveCount(1);
  await page.locator('[data-testid^="the-ho-so-"]').first().click();
  await expect(page.getByTestId("o-hoso-tenKhachHang")).toHaveValue("Trần Thị Bình");
  await expect(page.getByTestId("o-hoso-maKhachHang")).toHaveValue("KH002");
  await expect(page.getByTestId("o-hoso-soTienVay")).toHaveValue("450000000");

  await anh(page, testInfo, "phien14-nhap-hang-loat");
  expect(errors, errors.join("\n")).toEqual([]);
});

test("nhập hàng loạt từ TỆP .csv và tiêu đề sai bị từ chối kèm lý do", async ({
  page,
}, testInfo) => {
  const errors = await moTrang(page);
  const dir = thuMucTep();

  // (a) Tệp đúng — dấu chấm phẩy kiểu Excel Việt hoá cũng phải nhận.
  const tepDung = join(dir, "danh-sach-kh.csv");
  writeFileSync(
    tepDung,
    ["Tên khách hàng;Mã khách hàng;Số tiền vay", "Hoàng Văn Dũng;KH100;120000000"].join("\n"),
    "utf8",
  );
  await page.getByTestId("input-tep-csv").setInputFiles(tepDung);
  await expect(page.getByTestId("ket-qua-csv")).toContainText("Đã tạo 1/1 hồ sơ");
  await page.getByTestId("o-tim-ho-so").fill("Hoàng Văn Dũng");
  await expect(page.locator('[data-testid^="the-ho-so-"]')).toHaveCount(1);
  await page.getByTestId("o-tim-ho-so").fill("");

  // (b) Tệp sai tiêu đề — không tạo hồ sơ nào, báo lỗi rõ ràng.
  const soHoSo = await page.locator('[data-testid^="the-ho-so-"]').count();
  const tepSai = join(dir, "sai-tieu-de.csv");
  writeFileSync(tepSai, ["cot-la-1,cot-la-2", "a,b"].join("\n"), "utf8");
  await page.getByTestId("input-tep-csv").setInputFiles(tepSai);
  await expect(page.getByTestId("loi-csv")).toContainText("Không có cột nào khớp FIELD_META");
  await expect(page.locator('[data-testid^="the-ho-so-"]')).toHaveCount(soHoSo);

  await anh(page, testInfo, "phien14-csv-tu-tep-va-loi");
  expect(errors, errors.join("\n")).toEqual([]);
});

test("nhật ký thao tác và hoàn tác: lấy lại hồ sơ vừa xoá nhầm", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await page.getByTestId("nhan-ban-ho-so").click();
  await page.getByTestId("o-doi-ten-ho-so").fill("Hồ sơ quan trọng");
  await expect(page.locator('[data-testid^="the-ho-so-"]')).toHaveCount(2);
  await expect(page.getByTestId("danh-sach-nhat-ky").locator("li")).toHaveCount(1);

  // Xoá nhầm hồ sơ vừa soạn.
  await page.getByTestId("xoa-ho-so").click();
  await expect(page.locator('[data-testid^="the-ho-so-"]')).toHaveCount(1);
  await expect(page.getByTestId("tom-tat-nhat-ky")).toContainText("Xoá hồ sơ");

  // Hoàn tác → hồ sơ trở lại nguyên vẹn.
  await page.getByTestId("hoan-tac").click();
  await expect(page.getByTestId("ket-qua-hoan-tac")).toContainText("Đã hoàn tác");
  await expect(page.locator('[data-testid^="the-ho-so-"]')).toHaveCount(2);
  await expect(
    page.locator('[data-testid^="the-ho-so-"][data-ten="Hồ sơ quan trọng"]'),
  ).toHaveCount(1);

  // Hoàn tác tiếp bước nhân bản → còn lại một hồ sơ, hết mốc để hoàn tác.
  await page.getByTestId("hoan-tac").click();
  await expect(page.locator('[data-testid^="the-ho-so-"]')).toHaveCount(1);
  await expect(page.getByTestId("hoan-tac")).toBeDisabled();

  await anh(page, testInfo, "phien14-nhat-ky-hoan-tac");
  expect(errors, errors.join("\n")).toEqual([]);
});

test("hoàn tác cũng khôi phục được nhập hàng loạt, và hệ cũ vẫn CHỈ ĐỌC", async ({
  page,
}, testInfo) => {
  const errors = await moTrang(page);
  const truoc = await page.locator('[data-testid^="the-ho-so-"]').count();

  await page.getByTestId("dien-csv-mau").click();
  await page.getByTestId("nhap-hang-loat").click();
  await expect(page.locator('[data-testid^="the-ho-so-"]')).toHaveCount(truoc + 3);

  await page.getByTestId("hoan-tac").click();
  await expect(page.locator('[data-testid^="the-ho-so-"]')).toHaveCount(truoc);

  await anh(page, testInfo, "phien14-hoan-tac-nhap-hang-loat");

  // Hệ cũ nguyên trạng: route /he-cu vẫn nạp được iframe hệ cũ.
  await page.goto("/he-cu", { waitUntil: "domcontentloaded" });
  await expect(page.locator("iframe")).toHaveCount(1);
  await anh(page, testInfo, "phien14-he-cu-nguyen-ven");

  expect(errors, errors.join("\n")).toEqual([]);
});
