import { expect, test } from "@playwright/test";
import { readFileSync } from "node:fs";
import { formFields, derivedFields } from "../../src/lib/hsv/hoSoDraft";

/**
 * PHIÊN 10 (PHẦN 2 — 10B) — NHẬP HỒ SƠ THẬT TRÊN /xem-truoc.
 * Form sinh từ FIELD_META, dùng chung lớp validate + cửa chặn xuất,
 * bản nháp giữ trong bộ nhớ phiên, trường suy ra chỉ đọc.
 */

async function moTrang(page: import("@playwright/test").Page) {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error") errors.push(`console.error: ${m.text()}`);
  });
  await page.setViewportSize({ width: 1280, height: 1800 });
  await page.goto("/xem-truoc", { waitUntil: "domcontentloaded" });
  await page.getByTestId("san-sang").waitFor({ state: "attached" });
  return errors;
}

test("form sinh đủ ô từ FIELD_META (khách hàng + khoản vay) và trường suy ra chỉ đọc", async ({
  page,
}, testInfo) => {
  const errors = await moTrang(page);

  for (const f of formFields()) await expect(page.getByTestId(`o-hoso-${f.key}`)).toBeVisible();
  expect(formFields().length).toBeGreaterThanOrEqual(50);

  for (const f of derivedFields()) {
    const o = page.getByTestId(`o-hoso-${f.key}`);
    await expect(o).toHaveAttribute("readonly", "");
    await expect(page.getByTestId(`nguon-hoso-${f.key}`)).toContainText("Tự tính từ bảng");
  }
  await expect(page.getByTestId("o-hoso-tongGiaTriTs")).toHaveValue("3670000000");
  await expect(page.getByTestId("o-hoso-tgttsBangChu")).toHaveValue(
    "Ba tỷ sáu trăm bảy mươi triệu đồng",
  );

  await page.getByTestId("tieu-de-form").scrollIntoViewIfNeeded();
  await page.screenshot({ path: testInfo.outputPath("anh-form-hoso-phien10b.png") });
  await page
    .locator('[data-form-group="suy-ra"]')
    .screenshot({ path: testInfo.outputPath("anh-truong-suy-ra-chi-doc-phien10b.png") });
  expect(errors).toEqual([]);
});

test("nhập tên khách hàng mới ⇒ tên tệp và nội dung DOCX đổi theo", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await page.getByTestId("o-hoso-tenKhachHang").fill("Trần Thị Bích Hạnh");
  await page.getByTestId("o-hoso-soHoSo").fill("2099");
  await expect(page.getByTestId("xem-truoc-mau")).toContainText("Trần Thị Bích Hạnh");

  const [download] = await Promise.all([
    page.waitForEvent("download"),
    page.getByTestId("xuat-docx").click(),
  ]);
  const name = download.suggestedFilename();
  expect(name).toBe("HDTD_2099_Tran-Thi-Bich-Hanh.docx");

  const file = testInfo.outputPath(name);
  await download.saveAs(file);
  const raw = readFileSync(file).toString("latin1");
  expect(raw.slice(0, 4)).toContain("PK");
  await expect(page.getByTestId("ket-qua-xuat")).toContainText(name);

  await page.getByTestId("o-hoso-tenKhachHang").scrollIntoViewIfNeeded();
  await page.screenshot({ path: testInfo.outputPath("anh-nhap-tay-docx-phien10b.png") });
  expect(errors).toEqual([]);
});

test("xoá trường bắt buộc trên form ⇒ lỗi dưới ô + chặn xuất, nhập lại thì mở khoá", async ({
  page,
}, testInfo) => {
  const errors = await moTrang(page);

  await page.getByTestId("o-hoso-tenKhachHang").fill("");
  await expect(page.getByTestId("loi-hoso-tenKhachHang")).toContainText("bắt buộc");
  await expect(page.getByTestId("chan-xuat")).toContainText("Chặn xuất");
  await expect(page.getByTestId("xuat-docx")).toBeDisabled();

  await page.getByTestId("loi-hoso-tenKhachHang").scrollIntoViewIfNeeded();
  await page.screenshot({ path: testInfo.outputPath("anh-chan-xuat-form-phien10b.png") });

  await page.getByTestId("o-hoso-tenKhachHang").fill("Nguyễn Văn Trường");
  await expect(page.getByTestId("xuat-docx")).toBeEnabled();
  expect(errors).toEqual([]);
});

test("bản nháp hồ sơ còn nguyên sau khi tải lại trang; nút đặt lại trả về hồ sơ mẫu", async ({
  page,
}) => {
  const errors = await moTrang(page);

  await page.getByTestId("o-hoso-diaChi").fill("Xã Mỹ Tân, huyện Mỹ Lộc, Nam Định");
  await page.getByTestId("o-hoso-soTienVay").fill("1500000000");
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.getByTestId("san-sang").waitFor({ state: "attached" });

  await expect(page.getByTestId("o-hoso-diaChi")).toHaveValue("Xã Mỹ Tân, huyện Mỹ Lộc, Nam Định");
  await expect(page.getByTestId("o-hoso-soTienVay")).toHaveValue("1500000000");

  await page.getByTestId("hoso-day-du").click();
  await expect(page.getByTestId("o-hoso-diaChi")).toHaveValue("Xã Nam Vân, TP Nam Định");
  expect(errors).toEqual([]);
});
