import { test, expect } from "@playwright/test";
import { checkRoute } from "./helpers";

test("route /xem-truoc — xem trước mẫu HĐTD điền từ FIELD_META", async ({ page }, testInfo) => {
  const errors = await checkRoute(page, testInfo, "/xem-truoc", "xem-truoc");
  await expect(page.getByTestId("xem-truoc-mau")).toBeVisible();
  await expect(page.getByTestId("dong-mau").first()).toContainText("HỢP ĐỒNG TÍN DỤNG số");
  await expect(page.getByTestId("xem-truoc-mau")).toContainText("Nguyễn Văn Trường");
  await expect(page.getByTestId("so-cho-trong")).toBeVisible();
  expect(errors, errors.join("\n")).toHaveLength(0);
});
