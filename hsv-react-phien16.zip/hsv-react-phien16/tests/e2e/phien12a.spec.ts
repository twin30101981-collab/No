import { expect, test, type Page } from "@playwright/test";
import { LEGACY_ALLOWED } from "./helpers";

/**
 * PHIÊN 12 — PHẦN 1: nhiều hồ sơ trong một phiên làm việc + nhập hồ sơ từ hệ cũ
 * (chỉ đọc). Mỗi kịch bản đều chụp ảnh minh chứng và bắt buộc không có lỗi console.
 */

async function moTrang(page: Page) {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error" && !LEGACY_ALLOWED.some((r) => r.test(m.text())))
      errors.push(`console.error: ${m.text()}`);
  });
  await page.goto("/xem-truoc", { waitUntil: "domcontentloaded" });
  await page.getByTestId("san-sang").waitFor({ state: "attached" });
  return errors;
}

const the = (page: Page) => page.locator('[data-testid^="the-ho-so-"]');

test("phiên làm việc giữ nhiều hồ sơ, dữ liệu từng hồ sơ tách biệt", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await expect(the(page)).toHaveCount(1);
  await page.getByTestId("o-hoso-tenKhachHang").fill("Nguyễn Văn A");

  await page.getByTestId("them-ho-so").click();
  await expect(the(page)).toHaveCount(2);
  await page.getByTestId("o-doi-ten-ho-so").fill("Hộ Trần Thị B");
  await page.getByTestId("o-hoso-tenKhachHang").fill("Trần Thị B");

  // Quay lại hồ sơ đầu: dữ liệu không bị lẫn.
  await the(page).first().click();
  await expect(page.getByTestId("o-hoso-tenKhachHang")).toHaveValue("Nguyễn Văn A");
  await the(page).nth(1).click();
  await expect(page.getByTestId("o-hoso-tenKhachHang")).toHaveValue("Trần Thị B");
  await expect(the(page).nth(1)).toHaveAttribute("data-ten", "Hộ Trần Thị B");

  const file = testInfo.outputPath("anh-danh-sach-ho-so-phien12a.png");
  await page.getByTestId("khoi-danh-sach-ho-so").screenshot({ path: file });
  await testInfo.attach("danh-sach-ho-so", { path: file, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("nhân bản hồ sơ giữ nguyên dữ liệu và sửa độc lập", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await page.getByTestId("o-hoso-tenKhachHang").fill("Hộ Lê Văn C");
  await page.getByTestId("nhan-ban-ho-so").click();
  await expect(the(page)).toHaveCount(2);
  await expect(page.getByTestId("o-hoso-tenKhachHang")).toHaveValue("Hộ Lê Văn C");
  await expect(page.getByTestId("nguon-ho-so")).toContainText("Nhân bản");

  // Sửa bản sao không ảnh hưởng bản gốc.
  await page.getByTestId("o-hoso-tenKhachHang").fill("Hộ Lê Văn C (khoản vay 2)");
  await the(page).first().click();
  await expect(page.getByTestId("o-hoso-tenKhachHang")).toHaveValue("Hộ Lê Văn C");

  const file = testInfo.outputPath("anh-nhan-ban-phien12a.png");
  await page.getByTestId("khoi-danh-sach-ho-so").screenshot({ path: file });
  await testInfo.attach("nhan-ban", { path: file, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("nhập hồ sơ từ hệ cũ — chỉ đọc, không sửa dữ liệu hệ cũ", async ({ page }, testInfo) => {
  const legacy = {
    "hsv:hoso:KH001": JSON.stringify({
      "Tên khách hàng vay HM": "Phạm Thị Duyên",
      "Mã khách hàng HM": "KH-8899001",
      "Số tiền vay HM": 250000000,
      "Địa chỉ HM": "Xã Nghĩa Hưng, Nam Định",
    }),
    "hsv:hoso:KH002": JSON.stringify({
      "Tên khách hàng vay HM": "Đỗ Văn Hùng",
      "Mã khách hàng HM": "KH-8899002",
      "Số tiền vay HM": 80000000,
    }),
  };
  await page.addInitScript((data) => {
    for (const [k, v] of Object.entries(data as Record<string, string>))
      window.localStorage.setItem(k, v);
  }, legacy);

  const errors = await moTrang(page);
  await page.getByTestId("nhap-tu-he-cu").click();

  await expect(page.getByTestId("ket-qua-nhap-he-cu")).toContainText("Đã nhập 2 hồ sơ từ hệ cũ");
  await expect(the(page)).toHaveCount(3);
  await expect(page.getByTestId("o-hoso-tenKhachHang")).toHaveValue("Phạm Thị Duyên");
  await expect(page.getByTestId("nguon-ho-so")).toContainText("hsv:hoso:KH001");

  // Dữ liệu hệ cũ giữ NGUYÊN sau khi nhập.
  const conNguyen = await page.evaluate(
    (d) =>
      Object.entries(d as Record<string, string>).every(
        ([k, v]) => window.localStorage.getItem(k) === v,
      ),
    legacy,
  );
  expect(conNguyen).toBe(true);

  const file = testInfo.outputPath("anh-nhap-he-cu-phien12a.png");
  await page.getByTestId("khoi-danh-sach-ho-so").screenshot({ path: file });
  await testInfo.attach("nhap-he-cu", { path: file, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("danh sách hồ sơ còn nguyên sau khi tải lại trang", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await page.getByTestId("them-ho-so").click();
  await page.getByTestId("o-doi-ten-ho-so").fill("Hồ sơ giữ qua tải lại");
  await page.getByTestId("o-hoso-tenKhachHang").fill("Hoàng Văn Kiên");
  await expect(the(page)).toHaveCount(2);

  await page.reload({ waitUntil: "domcontentloaded" });
  await page.getByTestId("san-sang").waitFor({ state: "attached" });

  await expect(the(page)).toHaveCount(2);
  await expect(page.getByTestId("o-doi-ten-ho-so")).toHaveValue("Hồ sơ giữ qua tải lại");
  await expect(page.getByTestId("o-hoso-tenKhachHang")).toHaveValue("Hoàng Văn Kiên");

  const file = testInfo.outputPath("anh-giu-qua-tai-lai-phien12a.png");
  await page.getByTestId("khoi-danh-sach-ho-so").screenshot({ path: file });
  await testInfo.attach("giu-qua-tai-lai", { path: file, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("xoá hồ sơ, luôn còn ít nhất một hồ sơ trong phiên", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await expect(page.getByTestId("xoa-ho-so")).toBeDisabled();
  await page.getByTestId("them-ho-so").click();
  await expect(the(page)).toHaveCount(2);
  await page.getByTestId("xoa-ho-so").click();
  await expect(the(page)).toHaveCount(1);
  await expect(page.getByTestId("xoa-ho-so")).toBeDisabled();

  const file = testInfo.outputPath("anh-xoa-ho-so-phien12a.png");
  await page.getByTestId("khoi-danh-sach-ho-so").screenshot({ path: file });
  await testInfo.attach("xoa-ho-so", { path: file, contentType: "image/png" });
  expect(errors).toEqual([]);
});
