import { execFileSync } from "node:child_process";
import { expect, test } from "@playwright/test";

/**
 * PHIÊN 9 — kiểm chứng 3 việc:
 *  1) validate theo cột của bảng lặp chặn xuất văn bản,
 *  2) bảng nằm ĐÚNG VỊ TRÍ mẫu khai báo trong tệp DOCX,
 *  3) bảng lặp giữ nguyên dữ liệu khi tải lại trang (bộ nhớ phiên).
 */
function watchErrors(page: import("@playwright/test").Page) {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error") errors.push(`console.error: ${m.text()}`);
  });
  return errors;
}

async function moTrang(page: import("@playwright/test").Page) {
  await page.goto("/xem-truoc", { waitUntil: "domcontentloaded" });
  await page.waitForSelector('[data-testid="san-sang"]', { state: "attached" });
  await page.getByTestId("dat-lai-bang").click();
}

test("Phiên 9 — validate theo cột của bảng lặp chặn xuất DOCX", async ({ page }, testInfo) => {
  const errors = watchErrors(page);
  await moTrang(page);

  await page.getByTestId("o-danhSachTaiSan-0-giaTri").fill("một tỷ hai");
  await expect(page.getByTestId("loi-danhSachTaiSan-0-giaTri")).toContainText("phải là số tiền");
  await expect(page.getByTestId("xuat-docx")).toBeDisabled();

  await page.getByTestId("o-danhSachTaiSan-1-tenTaiSan").fill("");
  await expect(page.getByTestId("so-loi-danhSachTaiSan")).toHaveText("2 lỗi");
  await expect(page.getByTestId("chan-xuat")).toContainText("còn 2 lỗi phải sửa");

  const file = testInfo.outputPath("anh-validate-bang-phien9.png");
  await page.screenshot({ path: file });
  await testInfo.attach("validate-bang", { path: file, contentType: "image/png" });

  await page.getByTestId("o-danhSachTaiSan-0-giaTri").fill("2400000000");
  await page.getByTestId("o-danhSachTaiSan-1-tenTaiSan").fill("Nhà ở gắn liền với đất");
  await expect(page.getByTestId("chan-xuat")).toHaveCount(0);
  await expect(page.getByTestId("xuat-docx")).toBeEnabled();

  expect(errors).toEqual([]);
});

test("Phiên 9 — bảng TSBĐ nằm đúng vị trí mẫu khai báo trong DOCX", async ({ page }, testInfo) => {
  const errors = watchErrors(page);
  await moTrang(page);

  await page.getByTestId("mau-hdtc").click();
  await expect(page.getByTestId("xem-truoc-mau")).toContainText("Vị trí bảng «danhSachTaiSan»");
  await expect(page.getByTestId("nhan-chet")).toHaveText("0/27");

  const download = await Promise.all([
    page.waitForEvent("download"),
    page.getByTestId("xuat-docx").click(),
  ]).then(([d]) => d);
  expect(download.suggestedFilename()).toBe("HDTC_1247_Nguyen-Van-Truong.docx");
  const path = await download.path();
  const xml = execFileSync("unzip", ["-p", path!, "word/document.xml"], {
    encoding: "utf8",
    maxBuffer: 32 * 1024 * 1024,
  });

  // 2 bảng dữ liệu + 1 bảng chữ ký (Phiên 12B).
  expect((xml.match(/<w:tbl>/g) ?? []).length).toBe(3);
  const text = xml.replace(/<[^>]+>/g, "");
  const viTriBang = text.indexOf("DANH MỤC TÀI SẢN BẢO ĐẢM");
  const viTriDieu2 = text.indexOf("Điều 2. Nghĩa vụ được bảo đảm");
  expect(viTriBang).toBeGreaterThan(-1);
  expect(viTriBang).toBeLessThan(viTriDieu2);
  expect(text).toContain("TỔNG CỘNG");

  const file = testInfo.outputPath("anh-vi-tri-bang-phien9.png");
  await page.screenshot({ path: file });
  await testInfo.attach("vi-tri-bang", { path: file, contentType: "image/png" });

  expect(errors).toEqual([]);
});

test("Phiên 9 — bảng lặp giữ nguyên dữ liệu khi tải lại trang", async ({ page }, testInfo) => {
  const errors = watchErrors(page);
  await moTrang(page);

  await page.getByTestId("them-dong-danhSachTaiSan").click();
  await page.getByTestId("o-danhSachTaiSan-3-tenTaiSan").fill("Máy cấy Kubota");
  await page.getByTestId("o-danhSachTaiSan-3-giayToSoHuu").fill("Hoá đơn VAT 0099887");
  await page.getByTestId("o-danhSachTaiSan-3-diaChi").fill("Xã Nam Vân, TP Nam Định");
  await page.getByTestId("o-danhSachTaiSan-3-giaTri").fill("330000000");
  await expect(page.getByTestId("tong-bang-danhSachTaiSan")).toHaveText("4.000.000.000 đ");

  await page.reload({ waitUntil: "domcontentloaded" });
  await page.waitForSelector('[data-testid="san-sang"]', { state: "attached" });
  await expect(page.getByTestId("so-dong-danhSachTaiSan")).toHaveText("4 dòng");
  await expect(page.getByTestId("o-danhSachTaiSan-3-tenTaiSan")).toHaveValue("Máy cấy Kubota");
  await expect(page.getByTestId("tong-bang-danhSachTaiSan")).toHaveText("4.000.000.000 đ");

  const file = testInfo.outputPath("anh-luu-trang-thai-phien9.png");
  await page.screenshot({ path: file });
  await testInfo.attach("luu-trang-thai", { path: file, contentType: "image/png" });

  await page.getByTestId("dat-lai-bang").click();
  await expect(page.getByTestId("so-dong-danhSachTaiSan")).toHaveText("3 dòng");

  expect(errors).toEqual([]);
});
