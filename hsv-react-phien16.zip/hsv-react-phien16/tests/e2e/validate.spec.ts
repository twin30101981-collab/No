import { test, expect } from "@playwright/test";
import { checkRoute } from "./helpers";
import { makeInvalidSample, makeValidSample, validateHoSo } from "../../src/lib/hsv/validation";
import { FIELD_META, REPEATABLE_CELLS } from "../../src/lib/hsv/fieldMeta";

test("validate — hồ sơ hợp lệ 0 lỗi, hồ sơ sai kiểu bị bắt lỗi", async () => {
  expect(validateHoSo(makeValidSample())).toHaveLength(0);
  const bad = makeInvalidSample();
  const issues = validateHoSo(bad.hoSo, bad.rows);
  expect(issues.length).toBeGreaterThanOrEqual(4);
  expect(issues.some((i) => /bắt buộc/.test(i.message))).toBe(true);
  expect(issues.some((i) => /số/.test(i.message))).toBe(true);
  expect(issues.some((i) => /ngày/.test(i.message))).toBe(true);
  expect(issues.some((i) => i.kind === "repeatable")).toBe(true);
});

test("route /kiem-tra — trang kiểm tra dữ liệu tải sạch và bắt lỗi trên UI", async ({
  page,
}, testInfo) => {
  const errors = await checkRoute(page, testInfo, "/kiem-tra", "kiem-tra");
  await expect(page.getByTestId("so-truong")).toHaveText(String(FIELD_META.length));
  await page.getByTestId("btn-sai-kieu").click();
  await expect(page.getByTestId("dong-loi").first()).toBeVisible();
  const loi = Number(await page.getByTestId("so-loi").innerText());
  expect(loi).toBeGreaterThan(0);
  await page.screenshot({ path: testInfo.outputPath("kiem-tra-sai-kieu.png") });
  await testInfo.attach("kiem-tra-sai-kieu", {
    path: testInfo.outputPath("kiem-tra-sai-kieu.png"),
    contentType: "image/png",
  });
  expect(REPEATABLE_CELLS).toBe(14);
  expect(errors, errors.join("\n")).toHaveLength(0);
});
