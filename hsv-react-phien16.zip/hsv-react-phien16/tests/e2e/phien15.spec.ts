import { expect, test, type Page, type TestInfo } from "@playwright/test";
import { LEGACY_ALLOWED } from "./helpers";

/**
 * PHIÊN 15 — "đúng ngay từ đầu":
 *  (1) quy tắc nghiệp vụ đổi theo sản phẩm vay (hạn mức / thời hạn / TSBĐ);
 *  (2) lịch trả nợ tự sinh (gốc đều và niên kim), tổng gốc = số tiền vay;
 *  (3) lưới kiểm tra CSV: ô sai tô đỏ, chặn tạo hồ sơ đến khi sửa xong;
 *  (4) báo cáo phiên làm việc tải về dạng .xlsx;
 *  (5) hệ cũ vẫn CHỈ ĐỌC sau mọi thao tác trên.
 * Mỗi kịch bản chụp ảnh minh chứng, không có lỗi console/pageerror.
 */

async function moTrang(page: Page) {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error" && !LEGACY_ALLOWED.some((r) => r.test(m.text())))
      errors.push(`console.error: ${m.text()}`);
  });
  await page.goto("/xem-truoc", { waitUntil: "domcontentloaded" });
  await page.getByTestId("san-sang").waitFor({ state: "attached" });
  return errors;
}

async function anh(page: Page, testInfo: TestInfo, slug: string) {
  const file = testInfo.outputPath(`${slug}.png`);
  await page.screenshot({ path: file });
  await testInfo.attach(slug, { path: file, contentType: "image/png" });
}

test("quy tắc sản phẩm vay: đổi sản phẩm thì bộ kiểm tra đổi theo", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await page.getByTestId("o-hoso-soTienVay").fill("400000000");
  await page.getByTestId("o-hoso-thoiHan").fill("48");
  await page.getByTestId("o-hoso-laiSuat").fill("9");

  // Tiêu dùng: 48 tháng > 36 tháng ⇒ chặn vượt thời hạn.
  await page.getByTestId("chon-san-pham").selectOption("tieu-dung");
  await expect(page.getByTestId("canh-bao-vuot-thoi-han")).toContainText("vượt mức tối đa 36 tháng");
  await anh(page, testInfo, "phien15-quy-tac-tieu-dung");

  // Trung hạn: 48 tháng hợp lệ, nhưng thiếu TSBĐ ⇒ chặn khác hẳn.
  await page.getByTestId("chon-san-pham").selectOption("trung-han");
  await expect(page.getByTestId("canh-bao-vuot-thoi-han")).toHaveCount(0);
  await expect(page.getByTestId("mo-ta-san-pham")).toContainText("tối đa 60 tháng");

  // Ngắn hạn SXKD: 48 tháng vượt trần 12 tháng ⇒ quay lại chặn.
  await page.getByTestId("chon-san-pham").selectOption("ngan-han-sxkd");
  await expect(page.getByTestId("canh-bao-vuot-thoi-han")).toContainText("tối đa 12 tháng");
  await anh(page, testInfo, "phien15-quy-tac-doi-theo-san-pham");

  expect(errors).toEqual([]);
});

test("quy tắc TSBĐ: vượt tỷ lệ cho vay trên tài sản bị chặn, hạ số tiền thì sạch", async ({
  page,
}, testInfo) => {
  const errors = await moTrang(page);

  await page.getByTestId("chon-san-pham").selectOption("trung-han");
  await page.getByTestId("o-hoso-soTienVay").fill("900000000");
  await page.getByTestId("o-hoso-thoiHan").fill("36");
  await page.getByTestId("o-hoso-laiSuat").fill("10");
  await page.getByTestId("o-hoso-tongGiaTriTaiSanTheChap").fill("1000000000");

  await expect(page.getByTestId("canh-bao-vuot-ty-le-tsbd")).toContainText("vượt mức tối đa 70%");
  await anh(page, testInfo, "phien15-tsbd-vuot-ty-le");

  await page.getByTestId("o-hoso-soTienVay").fill("600000000");
  await expect(page.getByTestId("canh-bao-vuot-ty-le-tsbd")).toHaveCount(0);
  await expect(page.getByTestId("tom-tat-quy-tac")).toContainText("đạt toàn bộ quy tắc");
  await anh(page, testInfo, "phien15-tsbd-dat-quy-tac");

  expect(errors).toEqual([]);
});

test("lịch trả nợ tự sinh: gốc đều và niên kim, tổng gốc đúng bằng số tiền vay", async ({
  page,
}, testInfo) => {
  const errors = await moTrang(page);

  await page.getByTestId("o-hoso-soTienVay").fill("120000000");
  await page.getByTestId("o-hoso-thoiHan").fill("12");
  await page.getByTestId("o-hoso-laiSuat").fill("12");
  await page.getByTestId("o-ky-thang").fill("3");

  // 12 tháng / kỳ 3 tháng = 4 kỳ; gốc đều 30.000.000 mỗi kỳ.
  await expect(page.getByTestId("bang-lich-tra-no").locator("tbody tr")).toHaveCount(4);
  await expect(page.getByTestId("ky-1")).toContainText("30.000.000");
  await expect(page.getByTestId("tom-tat-lich")).toContainText("tổng gốc 120.000.000 đ");
  await expect(page.getByTestId("ky-4")).toContainText("0");
  await anh(page, testInfo, "phien15-lich-goc-deu");

  await page.getByTestId("chon-kieu-tra").selectOption("nien-kim");
  await expect(page.getByTestId("tom-tat-lich")).toContainText("tổng gốc 120.000.000 đ");
  await expect(page.getByTestId("bang-lich-tra-no").locator("tbody tr")).toHaveCount(4);
  await anh(page, testInfo, "phien15-lich-nien-kim");

  expect(errors).toEqual([]);
});

test("lưới kiểm tra CSV: ô sai tô đỏ chặn tạo hồ sơ, sửa xong mới tạo", async ({
  page,
}, testInfo) => {
  const errors = await moTrang(page);

  const soBanDau = await page.getByTestId("danh-sach-ho-so").locator("li").count();

  await page.getByTestId("o-csv").fill(
    [
      "Tên khách hàng,Mã khách hàng,Số tiền vay,Ngày HĐ tín dụng,Ghi chú lạ",
      "Nguyễn Văn An,KH901,300000000,01/08/2026,abc",
      ",KH902,ba trăm triệu,32-13-2026,xyz",
    ].join("\n"),
  );
  await page.getByTestId("xem-truoc-luoi").click();

  // 3 ô sai ở dòng 2: thiếu tên bắt buộc, số tiền chữ, ngày sai định dạng.
  await expect(page.getByTestId("tom-tat-luoi")).toContainText("Còn 3 ô sai");
  await expect(page.getByTestId("cot-la")).toContainText("Ghi chú lạ");
  await expect(page.getByTestId("o-luoi-1-0")).toHaveAttribute("data-sai", "1");
  await expect(page.getByTestId("o-luoi-1-2")).toHaveAttribute("data-sai", "1");
  await expect(page.getByTestId("tao-ho-so-tu-luoi")).toBeDisabled();
  await anh(page, testInfo, "phien15-luoi-o-sai");

  // Sửa ngay trên lưới rồi mới tạo hồ sơ.
  await page.getByTestId("o-luoi-1-0").fill("Trần Thị Bình");
  await page.getByTestId("o-luoi-1-2").fill("450000000");
  await page.getByTestId("o-luoi-1-3").fill("02/08/2026");
  await expect(page.getByTestId("tom-tat-luoi")).toContainText("Lưới sạch");
  await expect(page.getByTestId("tao-ho-so-tu-luoi")).toBeEnabled();

  await page.getByTestId("tao-ho-so-tu-luoi").click();
  await expect(page.getByTestId("ket-qua-csv")).toContainText("Đã tạo 2/2 hồ sơ");
  await expect(page.getByTestId("danh-sach-ho-so").locator("li")).toHaveCount(soBanDau + 2);
  await expect(page.getByTestId("danh-sach-ho-so")).toContainText("Trần Thị Bình");
  await anh(page, testInfo, "phien15-luoi-da-sua-tao-ho-so");

  expect(errors).toEqual([]);
});

test("báo cáo phiên: tải về tệp XLSX danh mục hồ sơ", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await page.getByTestId("o-csv").fill(
    ["Tên khách hàng,Mã khách hàng,Số tiền vay", "Phạm Văn Cường,KH903,250000000"].join("\n"),
  );
  await page.getByTestId("nhap-hang-loat").click();
  await expect(page.getByTestId("ket-qua-csv")).toContainText("Đã tạo 1/1 hồ sơ");

  const tai = page.waitForEvent("download");
  await page.getByTestId("xuat-bao-cao-xlsx").click();
  const file = await tai;
  expect(file.suggestedFilename()).toMatch(/^BaoCaoPhien_HSV_.*\.xlsx$/);
  await expect(page.getByTestId("ket-qua-bao-cao")).toContainText("Đã xuất");
  await anh(page, testInfo, "phien15-bao-cao-xlsx");

  expect(errors).toEqual([]);
});

test("hệ cũ vẫn chỉ đọc sau các thao tác phiên 15", async ({ page }, testInfo) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  await page.goto("/he-cu", { waitUntil: "domcontentloaded" });
  await expect(page.locator("iframe")).toBeVisible();
  await anh(page, testInfo, "phien15-he-cu-nguyen-ven");
  expect(errors).toEqual([]);
});
