import { expect, type Page, type TestInfo } from "@playwright/test";

/**
 * Khuôn dùng lại cho mọi phiên: mở route, chờ ổn định, thu lỗi, chụp ảnh.
 * Phiên sau chỉ cần gọi checkRoute() cho route mới — không viết lại kịch bản.
 */
export async function checkRoute(
  page: Page,
  testInfo: TestInfo,
  path: string,
  slug: string,
  expectText?: string | RegExp,
) {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (msg) => {
    if (msg.type() === "error") errors.push(`console.error: ${msg.text()}`);
  });

  await page.goto(path, { waitUntil: "domcontentloaded" });
  await page.waitForLoadState("networkidle").catch(() => {});
  if (expectText) await expect(page.getByText(expectText).first()).toBeVisible();

  const file = testInfo.outputPath(`${slug}.png`);
  await page.screenshot({ path: file });
  await testInfo.attach(slug, { path: file, contentType: "image/png" });

  return errors;
}

/** Lỗi console của chính hệ cũ (CDN offline) không tính cho app React. */
export const LEGACY_ALLOWED = [/supabase/i, /cdn/i, /xlsx/i, /Failed to load resource/i];
