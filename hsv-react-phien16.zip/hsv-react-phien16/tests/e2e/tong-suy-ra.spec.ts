import { execFileSync } from "node:child_process";
import { expect, test, type Page } from "@playwright/test";
import { TEMPLATES, templateTableAnchors } from "../../src/lib/hsv/docTemplate";
import { soThanhChu } from "../../src/lib/hsv/derived";

/**
 * PHIÊN 10 — PHẦN 1. Kiểm chứng 3 việc:
 *  1) cả 4 mẫu đều tự khai báo vị trí bảng lặp,
 *  2) số tổng và phần "bằng chữ" suy ra từ bảng lặp (cán bộ không gõ lại),
 *  3) sửa một dòng bảng ⇒ số tổng trong tệp DOCX đổi theo.
 */
function watchErrors(page: Page) {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error") errors.push(`console.error: ${m.text()}`);
  });
  return errors;
}

async function moTrang(page: Page) {
  await page.goto("/xem-truoc", { waitUntil: "domcontentloaded" });
  await page.waitForSelector('[data-testid="san-sang"]', { state: "attached" });
  await page.getByTestId("dat-lai-bang").click();
}

function docXml(path: string) {
  const xml = execFileSync("unzip", ["-p", path, "word/document.xml"], {
    encoding: "utf8",
    maxBuffer: 32 * 1024 * 1024,
  });
  return { xml, text: xml.replace(/<[^>]+>/g, "") };
}

test("Phiên 10 — số tiền thành chữ đúng cách đọc tiếng Việt", () => {
  expect(soThanhChu(0)).toBe("Không đồng");
  expect(soThanhChu(3_670_000_000)).toBe("Ba tỷ sáu trăm bảy mươi triệu đồng");
  expect(soThanhChu(4_000_000_000)).toBe("Bốn tỷ đồng");
  expect(soThanhChu(151_000)).toBe("Một trăm năm mươi mốt nghìn đồng");
  expect(soThanhChu(1_015)).toBe("Một nghìn không trăm mười lăm đồng");
});

test("Phiên 10 — cả 4 mẫu đều khai báo vị trí bảng lặp", () => {
  expect(TEMPLATES.length).toBe(4);
  for (const t of TEMPLATES) {
    const anchors = templateTableAnchors(t);
    expect(anchors.length, `mẫu ${t.id} chưa khai báo vị trí bảng`).toBeGreaterThan(0);
  }
});

test("Phiên 10 — bảng nằm đúng chỗ trong DOCX của cả 4 mẫu", async ({ page }, testInfo) => {
  const errors = watchErrors(page);
  await moTrang(page);

  const moc: Record<string, { truoc: string; sau: string }> = {
    hdtd: { truoc: "BẢNG CHI PHÍ VẬT TƯ", sau: "Điều 2. Bảo đảm tiền vay" },
    hdtc: { truoc: "DANH MỤC TÀI SẢN BẢO ĐẢM", sau: "Điều 2. Nghĩa vụ được bảo đảm" },
    gnn: { truoc: "BẢNG CHI PHÍ VẬT TƯ", sau: "2. Lãi suất và trả nợ" },
    bbdg: { truoc: "DANH MỤC TÀI SẢN BẢO ĐẢM", sau: "Cán bộ thẩm định" },
  };

  for (const t of TEMPLATES) {
    await page.getByTestId(`mau-${t.id}`).click();
    await expect(page.getByTestId("vi-tri-bang-mau")).not.toHaveText("chưa khai báo");
    const download = await Promise.all([
      page.waitForEvent("download"),
      page.getByTestId("xuat-docx").click(),
    ]).then(([d]) => d);
    const { xml, text } = docXml((await download.path())!);
    expect((xml.match(/<w:tbl>/g) ?? []).length, `số bảng trong ${t.id}`).toBe(3); // +1 bảng chữ ký (12B)
    const m = moc[t.id]!;
    const viTri = text.indexOf(m.truoc);
    const viTriSau = text.indexOf(m.sau);
    expect(viTri, `${t.id}: thiếu bảng ${m.truoc}`).toBeGreaterThan(-1);
    expect(viTri, `${t.id}: bảng bị dồn xuống sau "${m.sau}"`).toBeLessThan(viTriSau);
    expect(text).toContain("TỔNG CỘNG");
  }

  const file = testInfo.outputPath("anh-vi-tri-bang-4-mau-phien10.png");
  await page.screenshot({ path: file });
  await testInfo.attach("vi-tri-bang-4-mau", { path: file, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("Phiên 10 — sửa bảng lặp thì tổng và bằng chữ trong DOCX đổi theo", async ({ page }, testInfo) => {
  const errors = watchErrors(page);
  await moTrang(page);

  await expect(page.getByTestId("suy-ra-tong-danhSachTaiSan")).toHaveText("3.670.000.000 đ");
  await expect(page.getByTestId("suy-ra-chu-danhSachTaiSan")).toHaveText(
    "Ba tỷ sáu trăm bảy mươi triệu đồng",
  );

  await page.getByTestId("mau-hdtc").click();
  const truoc = await Promise.all([
    page.waitForEvent("download"),
    page.getByTestId("xuat-docx").click(),
  ]).then(([d]) => d);
  expect(docXml((await truoc.path())!).text).toContain("Ba tỷ sáu trăm bảy mươi triệu đồng");

  // Cán bộ sửa giá trị định giá của tài sản thứ 3: 420.000.000 ⇒ 750.000.000
  await page.getByTestId("o-danhSachTaiSan-2-giaTri").fill("750000000");
  await expect(page.getByTestId("tong-bang-danhSachTaiSan")).toHaveText("4.000.000.000 đ");
  await expect(page.getByTestId("suy-ra-tong-danhSachTaiSan")).toHaveText("4.000.000.000 đ");
  await expect(page.getByTestId("suy-ra-chu-danhSachTaiSan")).toHaveText("Bốn tỷ đồng");
  await expect(page.getByTestId("xem-truoc-mau")).toContainText("Bốn tỷ đồng");

  const sau = await Promise.all([
    page.waitForEvent("download"),
    page.getByTestId("xuat-docx").click(),
  ]).then(([d]) => d);
  const { text } = docXml((await sau.path())!);
  expect(text).toContain("4.000.000.000 đ");
  expect(text).toContain("Bốn tỷ đồng");
  expect(text).not.toContain("Ba tỷ sáu trăm bảy mươi triệu đồng");

  const file = testInfo.outputPath("anh-tong-suy-ra-phien10.png");
  await page.screenshot({ path: file });
  await testInfo.attach("tong-suy-ra", { path: file, contentType: "image/png" });
  expect(errors).toEqual([]);
});
