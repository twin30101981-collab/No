import { expect, test } from "@playwright/test";
import { LEGACY_ALLOWED } from "./helpers";

/**
 * PHIÊN 11 — kiểm chứng: form mở rộng sang PA SXKD + Giải ngân, tài sản bảo đảm
 * nhiều thửa/giấy tờ, câu ghép trong hợp đồng thế chấp, và kiểm tra chéo nghiệp vụ.
 */

async function moTrang(page: import("@playwright/test").Page) {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
  page.on("console", (m) => {
    if (m.type() === "error" && !LEGACY_ALLOWED.some((r) => r.test(m.text())))
      errors.push(`console.error: ${m.text()}`);
  });
  await page.goto("/xem-truoc", { waitUntil: "domcontentloaded" });
  await page.getByTestId("san-sang").waitFor({ state: "attached" });
  return errors;
}

test("form nhập mở rộng sang nhóm Phương án SXKD và Giải ngân", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await expect(page.locator('[data-form-group="pa-sxkd"]')).toBeVisible();
  await expect(page.locator('[data-form-group="giai-ngan"]')).toBeVisible();
  await expect(page.getByTestId("o-hoso-vonTuCo")).toBeVisible();
  await expect(page.getByTestId("o-hoso-tongNhuCauVon")).toHaveAttribute("readonly", "");

  // Ô nhập tay của nhóm mới hoạt động thật.
  await page.getByTestId("o-hoso-vonTuCo").fill("1500000000");
  await expect(page.getByTestId("o-hoso-vonTuCo")).toHaveValue("1500000000");

  const file = testInfo.outputPath("anh-form-pa-giai-ngan-phien11.png");
  await page.locator('[data-form-group="pa-sxkd"]').screenshot({ path: file });
  await testInfo.attach("form-pa-sxkd", { path: file, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("một tài sản có nhiều thửa và câu hợp đồng ghép tự động", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await expect(page.getByTestId("so-thua-0")).toHaveText("2 thửa/giấy tờ");
  await expect(page.getByTestId("cau-the-chap")).toContainText("gồm 2 thửa/giấy tờ");
  await expect(page.getByTestId("cau-the-chap")).toContainText("Tài sản 3:");

  // Thêm thửa thứ 3 cho tài sản 1 ⇒ câu ghép đổi theo ngay.
  await page.getByTestId("them-thua-0").click();
  await page.getByTestId("o-thua-0-2-soThua").fill("47");
  await page.getByTestId("o-thua-0-2-toBanDo").fill("12");
  await page.getByTestId("o-thua-0-2-dienTich").fill("54");
  await page.getByTestId("o-thua-0-2-soGiayChungNhan").fill("CX 123458");
  await page.getByTestId("o-thua-0-2-loaiDat").fill("Đất trồng lúa");

  await expect(page.getByTestId("so-thua-0")).toHaveText("3 thửa/giấy tờ");
  await expect(page.getByTestId("cau-the-chap")).toContainText("gồm 3 thửa/giấy tờ");
  await expect(page.getByTestId("cau-the-chap")).toContainText("thửa số 47");
  await expect(page.getByTestId("cau-the-chap")).toContainText("260 m²");
  await expect(page.getByTestId("tong-hop-thua")).toContainText("5 thửa/giấy tờ");

  // Câu ghép chảy thẳng vào hợp đồng thế chấp.
  await page.getByTestId("mau-hdtc").click();
  await expect(page.getByTestId("xem-truoc-mau")).toContainText("thửa số 47");

  const file = testInfo.outputPath("anh-nhieu-thua-phien11.png");
  await page.getByTestId("khoi-thua-tai-san").screenshot({ path: file });
  await testInfo.attach("nhieu-thua", { path: file, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("thửa thiếu giấy chứng nhận ⇒ báo lỗi và chặn xuất DOCX", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await expect(page.getByTestId("chan-xuat")).toHaveCount(0);
  await page.getByTestId("o-thua-0-0-soGiayChungNhan").fill("");
  await expect(page.getByTestId("loi-thua-0-0-soGiayChungNhan")).toContainText("bắt buộc");
  await expect(page.getByTestId("chan-xuat")).toBeVisible();
  await expect(page.getByTestId("xuat-docx")).toBeDisabled();

  const file = testInfo.outputPath("anh-chan-xuat-thua-phien11.png");
  await page.screenshot({ path: file });
  await testInfo.attach("chan-xuat-thua", { path: file, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("kiểm tra chéo: số tiền vay vượt nhu cầu vốn và vượt tỷ lệ TSBĐ", async ({
  page,
}, testInfo) => {
  const errors = await moTrang(page);

  await expect(page.locator('[data-testid="cheo-vonVsVay"]')).toHaveAttribute("data-dat", "true");
  await expect(page.locator('[data-testid="cheo-tsbdVsVay"]')).toHaveAttribute("data-dat", "true");

  // Vay 900 triệu > tổng nhu cầu vốn 152 triệu ⇒ quy tắc 1 không đạt.
  await page.getByTestId("o-hoso-soTienVay").fill("900000000");
  await expect(page.locator('[data-testid="cheo-vonVsVay"]')).toHaveAttribute("data-dat", "false");
  await expect(page.getByTestId("cheo-loi-vonVsVay")).toContainText("vượt tổng nhu cầu vốn");
  await expect(page.getByTestId("chan-xuat")).toBeVisible();
  await expect(page.getByTestId("xuat-docx")).toBeDisabled();

  // Hạ giá trị tài sản xuống 100 triệu ⇒ quy tắc tỷ lệ TSBĐ cũng không đạt.
  await page.getByTestId("o-danhSachTaiSan-0-giaTri").fill("100000000");
  await page.getByTestId("o-danhSachTaiSan-1-giaTri").fill("0");
  await page.getByTestId("o-danhSachTaiSan-2-giaTri").fill("0");
  await expect(page.locator('[data-testid="cheo-tsbdVsVay"]')).toHaveAttribute("data-dat", "false");
  await expect(page.getByTestId("cheo-loi-tsbdVsVay")).toContainText("thấp hơn mức tối thiểu");

  const file = testInfo.outputPath("anh-kiem-tra-cheo-phien11.png");
  await page.getByTestId("khoi-kiem-tra-cheo").screenshot({ path: file });
  await testInfo.attach("kiem-tra-cheo", { path: file, contentType: "image/png" });
  expect(errors).toEqual([]);
});

test("hồ sơ nhất quán ⇒ xuất được DOCX kèm mô tả nhiều thửa", async ({ page }, testInfo) => {
  const errors = await moTrang(page);

  await page.getByTestId("mau-hdtc").click();
  await expect(page.getByTestId("xuat-docx")).toBeEnabled();
  const [download] = await Promise.all([
    page.waitForEvent("download"),
    page.getByTestId("xuat-docx").click(),
  ]);
  expect(download.suggestedFilename()).toMatch(/\.docx$/);
  await expect(page.getByTestId("ket-qua-xuat")).toContainText("Đã xuất tệp");

  const file = testInfo.outputPath("anh-xuat-docx-phien11.png");
  await page.screenshot({ path: file });
  await testInfo.attach("xuat-docx", { path: file, contentType: "image/png" });
  expect(errors).toEqual([]);
});
