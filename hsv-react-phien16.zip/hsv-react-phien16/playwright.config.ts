import { defineConfig, devices } from "@playwright/test";

/**
 * Lưới an toàn GĐ0 — đóng gói vào repo (Phiên 0).
 * Chạy: bun run test:e2e
 * Ảnh chụp mỗi route được lưu vào test-results/.
 */
export default defineConfig({
  testDir: "./tests/e2e",
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: [["list"]],
  outputDir: "test-results",
  timeout: 60_000,
  use: {
    baseURL: process.env["E2E_BASE_URL"] ?? "http://localhost:8080",
    viewport: { width: 1280, height: 1800 },
    // E2E_CHROMIUM: dùng Chromium có sẵn của máy/CI (nếu chưa `playwright install`).
    launchOptions: process.env["E2E_CHROMIUM"]
      ? { executablePath: process.env["E2E_CHROMIUM"] }
      : {},
  },
  projects: [
    {
      name: "chromium",
      use: { ...devices["Desktop Chrome"], channel: undefined },
    },
  ],
});
