/* ==================================================================
   HSV UI PATCH v25.5.2 (2026-07-15) — additive-only
   A) Đổi nhãn nút "Nhóm tiếp →" thành "Nhóm sau →" trong sticky-nav.
   B) "Bảng đối chiếu số liệu" (#hsv16-summary): KHÔNG còn bung
      popover nổi đè lên input nữa. Thay vào đó, panel được dời hẳn
      vào #wizard-sidebar (sidebar trái), gắn ngay sau nút nhóm
      "Giải Ngân", và bọc thành 1 accordion gọn (bấm để mở/đóng).
   C) Gom thanh trạng thái dưới cùng (#v13-statusbar) vào sidebar
      trái, đặt ngay sau nút "Xuất hồ sơ".
   Lưu ý quan trọng: CHỈ dùng 1 MutationObserver + 1 polling nhẹ duy
   nhất trong toàn bộ file này (đã có sẵn từ v25.5.1) để không góp
   thêm vào tình trạng "bão mutation" từng gây treo UI khi chọn
   khách hàng trong app.js. Không thêm observer mới, không sửa hàm/
   biến toàn cục của các bản trước — chỉ quan sát DOM và chỉnh sau
   khi phần tử được vẽ.
   ================================================================== */
(function () {
  'use strict';

  /* ---------- Bỏ dấu tiếng Việt để so khớp tên nhóm ổn định ---------- */
  function normalizeVi(s) {
    return (s || '').toString()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/gi, 'd')
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .trim();
  }

  /* ---------- A) Đổi nhãn "Nhóm tiếp →" -> "Nhóm sau →" ---------- */
  function relabelStickyNav(bar) {
    if (!bar || bar.__hsvV4Labeled) return;
    var nextBtn = bar.querySelector('#v8-next');
    if (nextBtn && /Nhóm tiếp/.test(nextBtn.textContent)) {
      nextBtn.textContent = nextBtn.textContent.replace('Nhóm tiếp', 'Nhóm sau');
    }
    bar.__hsvV4Labeled = true;
  }

  /* ---------- B) Bảng đối chiếu số liệu: accordion trong sidebar ---------- */
  var RECON_KEY = 'hsv_recon_table_expanded_v1';
  function isExpanded() {
    try { return localStorage.getItem(RECON_KEY) === '1'; } catch (e) { return false; }
  }
  function setExpanded(v) {
    try { localStorage.setItem(RECON_KEY, v ? '1' : '0'); } catch (e) {}
  }

  function findGroupBtnByName(sidebar, target) {
    var btns = sidebar.querySelectorAll('.group-btn');
    for (var i = 0; i < btns.length; i++) {
      var nameEl = btns[i].querySelector('.group-name');
      var txt = normalizeVi(nameEl ? nameEl.textContent : btns[i].textContent);
      if (txt === target) return btns[i];
    }
    return null;
  }

  /* HSV-FIX v19 (2026-07-17): renderSummary() (bên app.js gốc) ghi đè
     TOÀN BỘ innerHTML của #hsv16-summary mỗi khi người dùng gõ phím ở
     bất kỳ đâu trong form (debounce ~180ms). Cách làm cũ ở đây từng
     "gói" (move) toàn bộ nội dung hiện có vào 1 <div class="hsv16-acc-body">
     mỗi lần dựng shell — nhưng renderSummary() xoá sạch div đó ngay sau,
     nên mỗi lần gõ phím, người dùng thấy bảng "xổ tung" ra rồi mới gập
     lại (chính là hiện tượng nháy/chập chờn được báo cáo).
     Cách mới: KHÔNG di chuyển nội dung vào wrapper nữa — chỉ đảm bảo có
     đúng 1 nút "head" là con đầu tiên của panel; việc ẩn/hiện phần nội
     dung còn lại (mọi node khác ngoài head) do CSS đảm nhiệm bằng
     selector "> *:not(.hsv16-acc-head)" (xem hsv-ui2026-patch-v4.css).
     → Khi renderSummary() ghi đè innerHTML, chỉ cần chèn lại 1 nút nhỏ
     (rẻ, không gây giật hình) thay vì tháo/lắp toàn bộ cây DOM nội dung. */
  function ensureAccordionShell(panel) {
    panel.classList.add('hsv16-sidebar-acc');
    var checked = isExpanded();
    panel.classList.toggle('hsv16-expanded', checked);

    var head = panel.querySelector(':scope > .hsv16-acc-head');
    if (head) return; // đã có sẵn — không cần dựng lại

    // Lấy tiêu đề từ thẻ H4 hiện có (nếu có) để hiển thị trên nút head
    var titleText = 'Bảng đối chiếu số liệu';
    var h4 = panel.querySelector('h4');
    if (h4 && h4.textContent && h4.textContent.trim()) titleText = h4.textContent.trim();

    head = document.createElement('button');
    head.type = 'button';
    head.className = 'hsv16-acc-head';
    head.innerHTML = '<span class="hsv16-ico">📊</span>' +
                      '<span class="hsv16-acc-label"></span>' +
                      '<span class="hsv16-chevron">▸</span>';
    head.querySelector('.hsv16-acc-label').textContent = titleText;
    head.addEventListener('click', function () {
      var v = !panel.classList.contains('hsv16-expanded');
      setExpanded(v);
      panel.classList.toggle('hsv16-expanded', v);
    });

    panel.insertBefore(head, panel.firstChild);
  }

  function relocateReconPanel() {
    var panel = document.getElementById('hsv16-summary');
    var sidebar = document.getElementById('wizard-sidebar');
    if (!panel || !sidebar) return;
    panel.classList.add('hsv16-sidebar-acc');

    if (panel.parentElement !== sidebar) {
      var anchor = findGroupBtnByName(sidebar, 'giai ngan');
      if (anchor) {
        anchor.insertAdjacentElement('afterend', panel);
      } else {
        // Không tìm thấy nhóm "Giải Ngân" (một số sản phẩm không có) —
        // gắn trước khối nút hành động cuối sidebar (Tổng hợp TSBĐ / Xuất hồ sơ)
        var actionsWrap = sidebar.querySelector('[data-hsv-sb-actions]');
        if (actionsWrap) actionsWrap.insertAdjacentElement('beforebegin', panel);
        else sidebar.appendChild(panel);
      }
    }
    ensureAccordionShell(panel);
  }

  /* ---------- C) Gom statusbar dưới cùng vào sidebar trái ---------- */
  function relocateStatusbar() {
    var sb = document.getElementById('v13-statusbar');
    var sidebar = document.getElementById('wizard-sidebar');
    if (!sb || !sidebar) return;
    var anchor = sidebar.querySelector('[data-hsv-sb-actions]');
    if (!anchor) return; // chưa kịp vẽ nút "Xuất hồ sơ" — thử lại ở lượt scan sau
    sb.classList.add('hsv-sb-embedded');
    if (anchor.nextElementSibling !== sb) {
      anchor.insertAdjacentElement('afterend', sb);
    }
  }

  var scanning = false;
  function scan() {
    if (scanning) return;
    scanning = true;
    try {
      var bar = document.querySelector('.v8-sticky-nav');
      if (bar) relabelStickyNav(bar);
      relocateReconPanel();
      relocateStatusbar();
    } finally {
      scanning = false;
    }
  }

  var obs = new MutationObserver(function () { scan(); });
  try {
    obs.observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) {}

  // Quét định kỳ để bắt các trường hợp DOM bị ghi đè hàng loạt
  // (renderWizard/renderSummary) mà observer gộp batch không kịp.
  setInterval(scan, 800);
  document.addEventListener('DOMContentLoaded', scan);
  setTimeout(scan, 500);
})();
