/* ============================================================
   HSV Diagnostics v1 — "F12 di động"
   Panel chẩn đoán trong app: ghi lại lỗi/cảnh báo console theo thời
   gian thực (giống DevTools F12 trên PC) và chạy tự kiểm tra toàn diện
   bằng một nút bấm — dành cho máy tính bảng/điện thoại không mở được
   F12.

   AN TOÀN TUYỆT ĐỐI: file này KHÔNG chỉnh sửa bất kỳ hàm/biến nào của
   app hiện có. Nó chỉ:
     1) "Nghe" console.error/console.warn (vẫn gọi lại hàm gốc, không
        chặn/thay đổi hành vi cũ).
     2) "Nghe" window.onerror / unhandledrejection (thụ động).
     3) Gọi các hàm CHẨN ĐOÁN CHỈ-ĐỌC đã có sẵn (np5SelfTest,
        getTemplatePlaceholders...) — không ghi/sửa dữ liệu hồ sơ.
     4) Vẽ thêm 1 nút nổi + 1 panel mới, không đụng tới DOM/CSS hiện có.
   Nếu bất kỳ hàm nào ở trên không tồn tại (phiên bản cũ hơn/khác), mọi
   thao tác đều được bọc try/catch — không bao giờ làm vỡ trang.
   ============================================================ */
(function () {
  "use strict";
  if (window.__hsvDiagInstalled) return; // không cài 2 lần
  window.__hsvDiagInstalled = true;

  var MAX_LOG = 300;
  var log = [];

  function safeStr(a) {
    try {
      if (typeof a === "string") return a;
      if (a instanceof Error) return a.message + (a.stack ? "\n" + a.stack : "");
      return JSON.stringify(a);
    } catch (e) {
      return String(a);
    }
  }

  function pushLog(level, argsLike) {
    try {
      var msg = Array.prototype.map.call(argsLike, safeStr).join(" ");
      log.push({ t: Date.now(), level: level, msg: msg });
      if (log.length > MAX_LOG) log.shift();
      updateBadge();
    } catch (e) {
      /* không bao giờ để việc ghi log làm vỡ trang */
    }
  }

  // ---- 1) Bọc console.error / console.warn (KHÔNG thay hành vi gốc) ----
  ["error", "warn"].forEach(function (level) {
    var orig = console[level] ? console[level].bind(console) : function () {};
    console[level] = function () {
      try { pushLog(level, arguments); } catch (e) {}
      return orig.apply(console, arguments);
    };
  });

  // ---- 2) Bắt lỗi JS chưa được xử lý ----
  window.addEventListener("error", function (e) {
    var loc = (e && e.filename) ? (" @ " + e.filename.split("/").pop() + ":" + e.lineno) : "";
    pushLog("error", [((e && e.message) || "Lỗi JS không xác định") + loc]);
  });
  window.addEventListener("unhandledrejection", function (e) {
    var reason = e && e.reason;
    var msg = reason && reason.message ? reason.message : safeStr(reason);
    pushLog("error", ["Promise bị từ chối (unhandled): " + msg]);
  });

  function errorCount() {
    return log.filter(function (l) { return l.level === "error"; }).length;
  }

  function updateBadge() {
    var b = document.getElementById("hsv-diag-badge");
    if (!b) return;
    var n = errorCount();
    b.textContent = n > 0 ? String(n) : "";
    b.style.display = n > 0 ? "inline-block" : "none";
  }

  // ---- 3) Bộ tự kiểm tra toàn diện (chỉ đọc, không sửa dữ liệu) ----
  async function runFullCheck() {
    var report = { time: new Date().toLocaleString("vi-VN"), sections: [] };

    // 3a. Công thức (dùng lại self-test có sẵn của app, không đổi gì)
    try {
      if (typeof window.np5SelfTest === "function") {
        var st = window.np5SelfTest({ silent: true });
        report.sections.push({
          name: "Công thức tính toán",
          ok: st ? st.totalUnresolved === 0 : null,
          detail: st
            ? (st.totalUnresolved === 0
                ? "Tất cả công thức khớp field đúng"
                : st.totalUnresolved + " công thức chưa khớp field")
            : "Không đọc được kết quả self-test",
        });
      } else {
        report.sections.push({ name: "Công thức tính toán", ok: null, detail: "Không tìm thấy công cụ self-test (np5SelfTest)" });
      }
    } catch (e) {
      report.sections.push({ name: "Công thức tính toán", ok: false, detail: "Lỗi khi tự kiểm tra: " + e.message });
    }

    // 3b. Template DOCX — thử parse tất cả template hiện có (chỉ đọc)
    try {
      if (typeof window.getTemplatesByProduct === "function" && typeof window.getTemplatePlaceholders === "function") {
        var products = ["CAM_CO", "HMTD", "TIEU_DUNG"];
        var all = [];
        products.forEach(function (p) {
          try { all = all.concat(window.getTemplatesByProduct(p) || []); } catch (e) {}
        });
        var bad = [];
        for (var i = 0; i < all.length; i++) {
          try { await window.getTemplatePlaceholders(all[i]); } catch (e) { bad.push(all[i].name + ": " + e.message); }
        }
        report.sections.push({
          name: "Template DOCX (" + all.length + " file)",
          ok: bad.length === 0,
          detail: bad.length === 0 ? "Tất cả template đọc được, không lỗi cú pháp" : bad.slice(0, 5).join("; "),
        });
      } else {
        report.sections.push({ name: "Template DOCX", ok: null, detail: "Không tìm thấy công cụ kiểm tra template" });
      }
    } catch (e) {
      report.sections.push({ name: "Template DOCX", ok: false, detail: "Lỗi: " + e.message });
    }

    // 3c. Sức khoẻ localStorage (chỉ đọc, có 1 ghi/xoá thử nghiệm tối thiểu)
    try {
      var testKey = "__hsv_diag_probe__";
      localStorage.setItem(testKey, "1");
      localStorage.removeItem(testKey);
      var total = 0, corrupt = 0;
      for (var k = 0; k < localStorage.length; k++) {
        var key = localStorage.key(k);
        if (key && key.indexOf("hsv:hoso:") === 0) {
          total++;
          try { JSON.parse(localStorage.getItem(key)); } catch (e) { corrupt++; }
        }
      }
      report.sections.push({
        name: "Bộ nhớ trình duyệt (localStorage)",
        ok: corrupt === 0,
        detail: corrupt === 0 ? "OK — " + total + " mục dữ liệu hồ sơ" : corrupt + "/" + total + " mục dữ liệu bị hỏng (không đọc được JSON)",
      });
    } catch (e) {
      report.sections.push({ name: "Bộ nhớ trình duyệt", ok: false, detail: "Không truy cập được localStorage (chế độ ẩn danh? hết dung lượng?): " + e.message });
    }

    // 3d. Hồ sơ "mồ côi" — sai product không khớp bất kỳ sản phẩm nào
    try {
      var validProducts = ["CAM_CO", "HMTD", "TIEU_DUNG"];
      var cases = (window.store && window.store.cases) || {};
      var zombies = Object.keys(cases).filter(function (id) {
        return validProducts.indexOf(cases[id].product) === -1;
      });
      report.sections.push({
        name: "Hồ sơ hợp lệ",
        ok: zombies.length === 0,
        detail: zombies.length === 0 ? "Không có hồ sơ nào sai sản phẩm" : zombies.length + " hồ sơ có product không hợp lệ",
      });
    } catch (e) {
      report.sections.push({ name: "Hồ sơ hợp lệ", ok: false, detail: "Lỗi: " + e.message });
    }

    // 3e. Tóm tắt lỗi console gần đây
    var recent = log.filter(function (l) { return l.level === "error" && Date.now() - l.t < 5 * 60 * 1000; });
    report.sections.push({
      name: "Lỗi console (5 phút gần đây)",
      ok: recent.length === 0,
      detail: recent.length === 0 ? "Không có lỗi nào được ghi nhận" : recent.length + " lỗi — xem tab \"Nhật ký lỗi\"",
    });

    return report;
  }

  window.HSVDiag = {
    getLog: function () { return log.slice(); },
    clearLog: function () { log = []; updateBadge(); },
    runFullCheck: runFullCheck,
  };

  // ------------------------- Giao diện -------------------------
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  var activeTab = "log";

  function ensureUI() {
    if (document.getElementById("hsv-diag-fab")) return;

    var fab = document.createElement("button");
    fab.id = "hsv-diag-fab";
    fab.type = "button";
    fab.innerHTML = '🩺 Chẩn đoán <span id="hsv-diag-badge" style="display:none"></span>';
    fab.title = "Chẩn đoán hệ thống — xem lỗi console & tự kiểm tra (thay F12 trên di động)";
    fab.style.cssText =
      "position:fixed;right:16px;bottom:52px;z-index:2147483401;padding:10px 14px;border-radius:999px;" +
      "background:#0f172a;color:#fff;border:none;font-size:13px;font-weight:600;cursor:pointer;" +
      "box-shadow:0 4px 14px rgba(0,0,0,.25);display:flex;align-items:center;gap:6px;font-family:system-ui,sans-serif";
    var badgeStyle = "background:#dc2626;border-radius:999px;padding:1px 6px;font-size:11px;display:none";
    fab.addEventListener("click", togglePanel);
    document.body.appendChild(fab);
    document.getElementById("hsv-diag-badge").style.cssText = badgeStyle;

    var panel = document.createElement("div");
    panel.id = "hsv-diag-panel";
    panel.style.cssText =
      "position:fixed;right:16px;bottom:108px;z-index:2147483401;width:min(420px,92vw);" +
      "max-height:65vh;display:none;flex-direction:column;background:#fff;border-radius:12px;" +
      "box-shadow:0 10px 40px rgba(0,0,0,.3);overflow:hidden;font-family:system-ui,sans-serif;color:#0f172a";
    panel.innerHTML =
      '<div style="padding:10px 14px;background:#0f172a;color:#fff;display:flex;justify-content:space-between;align-items:center">' +
      '<strong style="font-size:13px">🩺 Chẩn đoán hệ thống</strong>' +
      '<button id="hsv-diag-close" style="background:none;border:none;color:#fff;font-size:16px;cursor:pointer;line-height:1">✕</button></div>' +
      '<div style="display:flex;border-bottom:1px solid #e2e8f0">' +
      '<button class="hsv-diag-tab" data-tab="log" style="flex:1;padding:8px;border:none;background:#f1f5f9;cursor:pointer;font-size:12px;font-weight:600">Nhật ký lỗi</button>' +
      '<button class="hsv-diag-tab" data-tab="check" style="flex:1;padding:8px;border:none;background:#fff;cursor:pointer;font-size:12px;font-weight:600">Tự kiểm tra</button>' +
      '<button class="hsv-diag-tab" data-tab="history" style="flex:1;padding:8px;border:none;background:#fff;cursor:pointer;font-size:12px;font-weight:600">Lịch sử</button>' +
      "</div>" +
      '<div id="hsv-diag-body" style="padding:10px 14px;overflow:auto;flex:1;font-size:12px"></div>' +
      '<div style="padding:8px 14px;border-top:1px solid #e2e8f0;display:flex;gap:8px">' +
      '<button id="hsv-diag-copy" style="flex:1;padding:6px;border-radius:6px;border:1px solid #cbd5e1;background:#fff;cursor:pointer;font-size:12px">📋 Sao chép</button>' +
      '<button id="hsv-diag-clear" style="flex:1;padding:6px;border-radius:6px;border:1px solid #cbd5e1;background:#fff;cursor:pointer;font-size:12px">🗑 Xoá nhật ký</button>' +
      "</div>";
    document.body.appendChild(panel);

    function renderLog() {
      var body = document.getElementById("hsv-diag-body");
      var entries = log.slice().reverse();
      if (!entries.length) {
        body.innerHTML = '<div style="color:#64748b;text-align:center;padding:20px">Chưa có lỗi/cảnh báo nào được ghi nhận. Đây là dấu hiệu tốt.</div>';
        return;
      }
      body.innerHTML = entries
        .map(function (e) {
          var color = e.level === "error" ? "#dc2626" : "#d97706";
          var time = new Date(e.t).toLocaleTimeString("vi-VN");
          return (
            '<div style="padding:6px 0;border-bottom:1px solid #f1f5f9">' +
            '<span style="color:' + color + ';font-weight:700">[' + e.level.toUpperCase() + "]</span> " +
            '<span style="color:#94a3b8">' + time + "</span><br>" +
            '<span style="word-break:break-word;white-space:pre-wrap">' + escapeHtml(e.msg) + "</span></div>"
          );
        })
        .join("");
    }

    async function renderCheck() {
      var body = document.getElementById("hsv-diag-body");
      body.innerHTML = '<div style="text-align:center;padding:20px;color:#64748b">⏳ Đang kiểm tra...</div>';
      var report = await runFullCheck();
      body.innerHTML =
        '<div style="color:#64748b;font-size:11px;margin-bottom:8px">Lúc: ' + escapeHtml(report.time) + "</div>" +
        report.sections
          .map(function (s) {
            var icon = s.ok === true ? "✅" : s.ok === false ? "❌" : "⚪";
            return (
              '<div style="padding:6px 0;border-bottom:1px solid #f1f5f9">' +
              icon + " <strong>" + escapeHtml(s.name) + "</strong><br>" +
              '<span style="color:#475569;font-size:11px">' + escapeHtml(s.detail) + "</span></div>"
            );
          })
          .join("");
    }

    function renderHistory() {
      var body = document.getElementById("hsv-diag-body");
      try {
        var caseId = window.currentCaseId;
        if (!caseId) {
          body.innerHTML = '<div style="color:#64748b;text-align:center;padding:20px">Chưa mở hồ sơ nào để xem lịch sử.</div>';
          return;
        }
        var hist = (window.HSVAuditLog && window.HSVAuditLog.getHistory(caseId)) || [];
        if (!hist.length) {
          body.innerHTML = '<div style="color:#64748b;text-align:center;padding:20px">Chưa có thay đổi nào được ghi nhận cho hồ sơ này.</div>';
          return;
        }
        body.innerHTML = hist
          .map(function (h) {
            var time = new Date(h.t).toLocaleString("vi-VN");
            return (
              '<div style="padding:6px 0;border-bottom:1px solid #f1f5f9">' +
              '<span style="color:#94a3b8;font-size:11px">' + time + "</span> — " +
              "<strong>" + h.n + " field đã đổi</strong><br>" +
              '<span style="color:#475569;font-size:11px;word-break:break-word">' + escapeHtml(h.fields.join(", ")) + "</span></div>"
            );
          })
          .join("");
      } catch (e) {
        body.innerHTML = '<div style="color:#dc2626;text-align:center;padding:20px">Lỗi đọc lịch sử: ' + escapeHtml(e.message) + "</div>";
      }
    }

    panel.querySelectorAll(".hsv-diag-tab").forEach(function (btn) {
      btn.addEventListener("click", function () {
        activeTab = btn.getAttribute("data-tab");
        panel.querySelectorAll(".hsv-diag-tab").forEach(function (b) {
          b.style.background = b === btn ? "#f1f5f9" : "#fff";
        });
        if (activeTab === "log") renderLog();
        else if (activeTab === "check") renderCheck();
        else renderHistory();
      });
    });
    document.getElementById("hsv-diag-close").addEventListener("click", togglePanel);
    document.getElementById("hsv-diag-copy").addEventListener("click", function () {
      var text =
        activeTab === "log"
          ? log.map(function (e) { return "[" + e.level + "] " + new Date(e.t).toLocaleString("vi-VN") + " — " + e.msg; }).join("\n") ||
            "Không có nhật ký."
          : document.getElementById("hsv-diag-body").innerText;
      try {
        navigator.clipboard.writeText(text).then(function () {
          if (typeof window.toast === "function") window.toast("Đã sao chép nội dung chẩn đoán", "success");
        });
      } catch (e) {}
    });
    document.getElementById("hsv-diag-clear").addEventListener("click", function () {
      log = [];
      updateBadge();
      renderLog();
    });

    panel._renderLog = renderLog;
    panel._renderCheck = renderCheck;
    panel._renderHistory = renderHistory;
  }

  function togglePanel() {
    ensureUI();
    var panel = document.getElementById("hsv-diag-panel");
    var isOpen = panel.style.display !== "none";
    if (isOpen) {
      panel.style.display = "none";
    } else {
      panel.style.display = "flex";
      if (activeTab === "log") panel._renderLog();
      else panel._renderCheck();
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", ensureUI);
  } else {
    ensureUI();
  }
})();
