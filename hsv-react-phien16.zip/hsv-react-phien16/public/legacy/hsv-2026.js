/* ============================================================
   HSV 2026 — Overlay JS (safe, additive)
   Only touches: <html class>, injects theme button + version chip.
   Does NOT modify app.js state or DOM inside main content.
   ============================================================ */
(function () {
  'use strict';

  var LS_KEY = 'hsv-2026-theme';   // v25.6.1: chỉ còn 'light' | 'dark' (bỏ 'auto')
  var doc = document.documentElement;

  function currentPref() {
    try {
      var v = localStorage.getItem(LS_KEY);
      // migrate legacy 'auto' -> 'light'
      if (v !== 'dark' && v !== 'light') v = 'light';
      return v;
    } catch (e) { return 'light'; }
  }
  function savePref(v) {
    try { localStorage.setItem(LS_KEY, v); } catch (e) {}
  }
  function applyTheme(pref) {
    doc.classList.toggle('hsv-dark', pref === 'dark');
    updateBtnLabel(pref);
  }

  function iconSun() {
    return '<svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>';
  }
  function iconMoon() {
    return '<svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
  }

  var btn = null;
  function updateBtnLabel(pref) {
    if (!btn) return;
    var icon = pref === 'dark' ? iconMoon() : iconSun();
    var label = pref === 'dark' ? 'Tối' : 'Sáng';
    btn.innerHTML = icon + '<span>' + label + '</span>';
    btn.setAttribute('title', 'Giao diện: ' + label + ' — bấm để đổi');
  }

  function cyclePref(cur) {
    return cur === 'dark' ? 'light' : 'dark';
  }

  function injectControls() {
    var nav = document.querySelector('header nav');
    if (!nav || document.querySelector('.hsv2026-theme-btn')) return;

    btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'hsv2026-theme-btn';
    btn.addEventListener('click', function () {
      var next = cyclePref(currentPref());
      savePref(next);
      applyTheme(next);
    });
    nav.appendChild(btn);

    // Version chip next to logo
    var logoText = document.querySelector('.logo-text');
    if (logoText && !document.querySelector('.hsv2026-badge')) {
      var chip = document.createElement('span');
      chip.className = 'hsv2026-badge';
      chip.textContent = 'UI 2026';
      chip.style.marginLeft = '8px';
      logoText.appendChild(chip);
    }

    applyTheme(currentPref());
  }

  // v25.6.1: bỏ theo dõi prefers-color-scheme (không còn chế độ auto)

  // Apply theme immediately (before nav is ready) to avoid flash
  applyTheme(currentPref());

  function boot() {
    injectControls();
    // Retry once in case header renders after app.js init
    setTimeout(injectControls, 400);
    requestAnimationFrame(injectControls);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
