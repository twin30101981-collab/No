/* HSV UI 2026 — Command Palette (⌘K)
 * Safe overlay: chỉ đọc DOM và click phần tử gốc, KHÔNG gọi hàm nội bộ app.js.
 */
(function () {
  'use strict';
  if (window.__HSV_CMDK__) return;
  window.__HSV_CMDK__ = true;

  const MAX_RESULTS = 40;

  // ---- Fuzzy score (Vietnamese diacritics friendly) ----
  const stripDiacritics = (s) =>
    (s || '').toString().normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

  function fuzzyScore(needle, hay) {
    const n = stripDiacritics(needle);
    const h = stripDiacritics(hay);
    if (!n) return 1;
    if (h.includes(n)) return 100 - Math.min(50, h.indexOf(n));
    // subsequence
    let i = 0, score = 0, prev = -2;
    for (let j = 0; j < h.length && i < n.length; j++) {
      if (h[j] === n[i]) {
        score += 10;
        if (j - prev === 1) score += 5;
        prev = j;
        i++;
      }
    }
    return i === n.length ? score : 0;
  }

  // ---- Collect commands from live DOM ----
  function collectCommands() {
    const out = [];
    const seen = new Set();
    const push = (label, group, el, hint) => {
      const key = (group || '') + '|' + label;
      if (!label || seen.has(key)) return;
      seen.add(key);
      out.push({ label: label.trim().replace(/\s+/g, ' '), group, el, hint });
    };

    // Nav / tabs / buttons in header, tabs, sidebar
    const navSelectors = [
      'header button', 'header a',
      'nav button', 'nav a',
      '.tabs button', '.tab-list button', '[role="tab"]',
      '.sidebar button', '.sidebar a',
      '.toolbar button', '.actions button'
    ];
    document.querySelectorAll(navSelectors.join(',')).forEach((el) => {
      if (el.closest('#hsv-cmdk')) return;
      if (el.offsetParent === null && !el.getClientRects().length) return;
      const label = (el.getAttribute('aria-label') || el.title || el.textContent || '').trim();
      if (label && label.length <= 80) push(label, 'Điều hướng', el);
    });

    // Any button with visible short text (fallback global)
    document.querySelectorAll('button').forEach((el) => {
      if (el.closest('#hsv-cmdk')) return;
      const label = (el.getAttribute('aria-label') || el.title || el.textContent || '').trim();
      if (!label || label.length > 60) return;
      if (el.offsetParent === null) return;
      push(label, 'Hành động', el);
    });

    // Customer / profile rows (heuristic: rows/cards with data-id or common class names)
    const rowSelectors = ['[data-id]', '[data-customer-id]', '[data-profile-id]',
      '.customer-row', '.customer-card', '.profile-row', '.profile-card',
      '.record-row', '.record-card', '.list-item', 'tr[data-id]'];
    document.querySelectorAll(rowSelectors.join(',')).forEach((el) => {
      const label = (el.getAttribute('data-label') || el.getAttribute('title') ||
        el.querySelector('.title, .name, h3, h4, td')?.textContent || el.textContent || '').trim();
      if (label && label.length <= 120) push(label.slice(0, 120), 'Hồ sơ', el);
    });

    return out.slice(0, 2000);
  }

  // ---- UI ----
  const root = document.createElement('div');
  root.id = 'hsv-cmdk';
  root.hidden = true;
  root.innerHTML = `
    <div class="hsv-cmdk-scrim" data-close="1"></div>
    <div class="hsv-cmdk-panel" role="dialog" aria-modal="true" aria-label="Bảng lệnh">
      <div class="hsv-cmdk-input-row">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
        <input type="text" placeholder="Tìm lệnh, tab, hồ sơ… (Esc để đóng)" autocomplete="off" spellcheck="false" />
        <kbd>ESC</kbd>
      </div>
      <ul class="hsv-cmdk-list" role="listbox"></ul>
      <div class="hsv-cmdk-foot">
        <span><kbd>↑</kbd><kbd>↓</kbd> chọn</span>
        <span><kbd>↵</kbd> mở</span>
        <span><kbd>Alt</kbd>+<kbd>K</kbd> bật/tắt</span>
      </div>
    </div>`;
  document.addEventListener('DOMContentLoaded', () => document.body.appendChild(root));
  if (document.body) document.body.appendChild(root);

  const input = root.querySelector('input');
  const list = root.querySelector('.hsv-cmdk-list');
  let items = [];
  let active = 0;

  function open() {
    items = collectCommands();
    root.hidden = false;
    root.classList.add('is-open');
    input.value = '';
    render('');
    setTimeout(() => input.focus(), 20);
  }
  function close() {
    root.classList.remove('is-open');
    root.hidden = true;
  }
  function render(q) {
    const scored = items
      .map((it) => ({ it, s: fuzzyScore(q, it.label + ' ' + (it.group || '')) }))
      .filter((x) => x.s > 0)
      .sort((a, b) => b.s - a.s)
      .slice(0, MAX_RESULTS);
    list.innerHTML = scored.length
      ? scored.map((x, i) => `
        <li role="option" class="${i === 0 ? 'is-active' : ''}" data-idx="${i}">
          <span class="hsv-cmdk-label">${escapeHtml(x.it.label)}</span>
          <span class="hsv-cmdk-group">${escapeHtml(x.it.group || '')}</span>
        </li>`).join('')
      : `<li class="hsv-cmdk-empty">Không có kết quả</li>`;
    list._scored = scored;
    active = 0;
  }
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function activate(delta) {
    const els = list.querySelectorAll('li[data-idx]');
    if (!els.length) return;
    active = (active + delta + els.length) % els.length;
    els.forEach((el, i) => el.classList.toggle('is-active', i === active));
    els[active].scrollIntoView({ block: 'nearest' });
  }
  function commit() {
    const scored = list._scored || [];
    const pick = scored[active];
    if (!pick) return;
    close();
    try { pick.it.el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (_) {}
    setTimeout(() => { try { pick.it.el.click(); } catch (_) {} }, 60);
  }

  input.addEventListener('input', (e) => render(e.target.value));
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { e.preventDefault(); close(); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); activate(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); activate(-1); }
    else if (e.key === 'Enter') { e.preventDefault(); commit(); }
  });
  root.addEventListener('click', (e) => {
    if (e.target.closest('[data-close]')) close();
    const li = e.target.closest('li[data-idx]');
    if (li) { active = +li.dataset.idx; commit(); }
  });

  // Global hotkey: Ctrl/Cmd + Shift + K (app đã dùng Ctrl+K cho tìm KH)
  document.addEventListener('keydown', (e) => {
    const isK = e.key === 'k' || e.key === 'K';
    if (isK && e.altKey && !e.ctrlKey && !e.metaKey) {
      e.preventDefault();
      root.hidden ? open() : close();
    }
  }, true);

  // Expose tiny API
  window.HSVCmdK = { open, close };
})();
