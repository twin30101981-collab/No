/* ══════════════════════════════════════════════════════════════════════
 *  HSV v25.5.2 · FIX v15 — Nạp PA SXKD ẩn + đọc seed dvh-inputs.json
 *  ---------------------------------------------------------------------
 *  Nối tiếp FIX v14. Vá 4 nguyên nhân còn lại khiến Bảng đối chiếu số liệu
 *  hiện 0 đ ở toàn bộ mục PA SXKD:
 *
 *   (1) DOM PA SXKD chưa mount khi user ở tab HMTD → v14 loose-scan
 *       không thấy input. v15 hidden-mount tab pa_sxkd vào container
 *       ngoài viewport để mọi label/input tồn tại trong DOM top.
 *
 *   (2) Không có PA đính kèm → v14 nhánh PALib bỏ qua. v15 fallback
 *       đọc trực tiếp seed dvh-inputs.json (đóng gói cạnh index.html).
 *
 *   (3) _readSoHD của v14 dò 'Số hợp đồng/soHD/HĐTD' — form HMTD dùng
 *       'Số hồ sơ' / 'Mã khách hàng'. v15 mở rộng dò thêm.
 *
 *   (4) Alias thiếu các nhãn thật (Hàng tồn kho1, Vốn đối ứng,
 *       Lãi ước của nhận nợ, key có suffix ' HM' …). v15 nối thêm.
 *
 *  Additive, KHÔNG sửa app.js / v14. Idempotent.
 * ══════════════════════════════════════════════════════════════════════ */
(function (global) {
  'use strict';
  if (global.__hsvFixV15Loaded) return;
  global.__hsvFixV15Loaded = true;

  var LOG = '[fix-v15]';
  function log(){ try{ console.log.apply(console, [LOG].concat([].slice.call(arguments))); }catch(_){} }

  /* ── Utils (dùng lại logic v14 nếu có, fallback nội bộ) ──────── */
  function toNum(v){
    if (v == null) return 0;
    if (typeof v === 'number') return isFinite(v) ? v : 0;
    var s = String(v).trim();
    if (!s) return 0;
    s = s.replace(/[^\d,.\-]/g, '');
    if (s.indexOf(',') >= 0 && s.indexOf('.') >= 0) s = s.replace(/\./g, '').replace(',', '.');
    else if (s.indexOf(',') >= 0) s = s.replace(',', '.');
    else s = s.replace(/\./g, '');
    var n = parseFloat(s);
    return isFinite(n) ? n : 0;
  }
  function norm(s){
    return String(s || '')
      .toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/g, 'd')
      .replace(/^[\s\+\-\*·•\.\d]+/, '')
      .replace(/\bhm\b\s*$/, '')      // strip suffix " HM" của seed keys
      .replace(/[\s:\.\-_]+/g, ' ')
      .trim();
  }
  function fmtVND(n){ return (Math.round(Number(n)||0)).toLocaleString('vi-VN') + ' đ'; }

  /* ── 1) Fetch seed dvh-inputs.json (bundled) ─────────────────── */
  var _seedPool = null;
  var _seedLoading = false;
  function loadSeed(){
    if (_seedPool || _seedLoading) return;
    _seedLoading = true;
    try {
      /* file:// safe: use inline data if available, fallback to fetch */
      var _fetchPromise;
      if (window.DVH_INPUTS_DATA) {
        _fetchPromise = Promise.resolve(window.DVH_INPUTS_DATA);
      } else {
        _fetchPromise = fetch('./dvh-inputs.json', { cache: 'force-cache' })
          .then(function(r){ return r.ok ? r.json() : null; });
      }
      _fetchPromise.then(function(d){
          _seedLoading = false;
          if (!d || typeof d !== 'object') return;
          var pool = { byLabelNorm: {}, byRegKey: {} };
          function ingest(obj){
            if (!obj || typeof obj !== 'object') return;
            Object.keys(obj).forEach(function(k){
              var v = obj[k];
              if (v && typeof v === 'object') return;
              var n = toNum(v);
              if (!n) return;
              var kn = norm(k);
              if (kn && !pool.byLabelNorm[kn]) pool.byLabelNorm[kn] = n;
              // strip prefixes ".ts." / suffix HM đã handle trong norm
              var k2 = k.replace(/^\.[a-z]+\./i, '');
              var kn2 = norm(k2);
              if (kn2 && !pool.byLabelNorm[kn2]) pool.byLabelNorm[kn2] = n;
            });
          }
          ingest(d.values);
          (d.assets || []).forEach(function(a){ ingest(a && a.values); });
          _seedPool = pool;
          log('seed loaded:', Object.keys(pool.byLabelNorm).length, 'keys');
          rerender();
        })
        .catch(function(e){ _seedLoading = false; log('seed fetch fail', e && e.message); });
    } catch(e){ _seedLoading = false; }
  }

  /* ── 2) Alias mở rộng cho v14 ────────────────────────────────── */
  var EXTRA_ALIAS = {
    'tong doanh thu':                     ['tong ncv theo dung phuong an', 'doanh thu bcdxgn', 'doanh thu ke hoach', 'doanh thu du kien nam'],
    'loi nhuan du kien (muc tieu)':       ['loi nhuan muc tieu nam', 'ln du kien nam', 'loi nhuan ke hoach'],
    'nhu cau von':                        ['tong nhu cau von luu dong', 'ncv luu dong', 'nhu cau vay von'],
    'von tu co':                          ['von doi ung', 'von bang tien', 'von tu co tham gia', 'von tham gia cua khach hang'],
    'hmtd duyet':                         ['han muc tin dung duyet', 'muc de nghi cap', 'so tien cap tin dung', 'so tien vay', 'hmtd duyet hm', 'so tien vay hm'],
    'von vay tctd khac':                  ['du no tctd khac', 'vay ngan hang khac', 'no khac 1', 'no khac 2', 'no khac 1 hm', 'no khac 2 hm'],
    'vong quay vld':                      ['so vong quay', 'vong quay von', 'vong quay', 'vong quay hm'],
    'tong cp (chua lai, kh)':             ['tong chi phi truoc lai kh', 'tong cp truoc lai khau hao', 'tong chi phi san xuat kinh doanh'],
    'lai':                                ['lai uoc cua nhan no', 'lai vay uoc tinh', 'chi phi lai vay uoc', 'lai suat vay', 'lai suat vay hm'],
    'khau hao':                           ['chi phi khau hao tsc', 'khau hao tai san co dinh'],
    'cp vat tu':                          ['chi phi nguyen vat lieu', 'chi phi vat tu du kien'],
    'chi phi khac':                       ['cp khac du kien', 'chi phi bang tien khac'],
    'hang hoa cac loai':                  ['hang ton kho', 'hang ton kho1', 'hang hoa', 'ton kho vat tu', 'hang hoa cac loai hm'],
    'tien mat':                           ['tien mat hm', 'tien mat va tuong duong'],
    'no phai thu':                        ['no phai thu1', 'cong no phai thu', 'khoan phai thu khach hang', 'no phai thu hm'],
    'no phai tra':                        ['no phai tra1', 'cong no phai tra', 'no phai tra hm'],
    'no phai tra pa':                     ['no phai tra ke hoach', 'no phai tra du kien'],
    'du no':                              ['du no agribank', 'du no hien tai', 'du no ngan hang'],
    'no nguoi ban':                       ['no nguoi ban hm', 'phai tra ncc'],
    'no phai tra khac':                   ['cong no khac', 'phai tra khac'],
    'tong gia tri ts':                    ['tong gia tri tai san hien co', 'gia tri tai san bao dam'],
    'gia tri ld':                         ['gia tri luu dong', 'gia tri von luu dong'],
    'ts khac':                            ['tai san khac', 'tsc khac'],
    'chenh lech cp':                      ['chenh lech thu chi', 'chenh lech thu chi bcdxgn'],
    'ty suat ln (%)':                     ['ty suat loi nhuan', 'ty suat ln nam'],
    'loi nhuan thuc te':                  ['ln thuc te nam', 'lai thuc te'],
    'dt can dat':                         ['doanh thu can dat', 'doanh thu muc tieu']
  };

  /* ── 3) Monkey-patch v14 buildPool để trộn seed pool ─────────── */
  function installBuildPoolPatch(){
    if (!global.hsvFixV14 || global.__hsvFixV15PatchedPool) return;
    var _origBuild = global.hsvFixV14.buildPool;
    if (typeof _origBuild !== 'function') return;
    global.__hsvFixV15PatchedPool = true;

    global.hsvFixV14.buildPool = function(){
      var pool = _origBuild.apply(this, arguments) || { byRegKey:{}, byLabelNorm:{} };
      pool.byRegKey  = pool.byRegKey  || {};
      pool.byLabelNorm = pool.byLabelNorm || {};

      // Trộn seed nếu đã tải
      if (_seedPool) {
        Object.keys(_seedPool.byLabelNorm).forEach(function(k){
          if (!pool.byLabelNorm[k]) pool.byLabelNorm[k] = _seedPool.byLabelNorm[k];
        });
      }
      return pool;
    };

    // Patch lookup để thêm alias mở rộng + partial match nới
    var _origLookup = global.hsvFixV14.lookup;
    global.hsvFixV14.lookup = function(label){
      var v = _origLookup.call(this, label);
      if (v) return v;
      var pool = global.hsvFixV14.buildPool();
      var key = norm(label);
      var extra = EXTRA_ALIAS[key] || [];
      for (var i=0; i<extra.length; i++) {
        var a = extra[i];
        if (pool.byLabelNorm[a]) return pool.byLabelNorm[a];
        var ks = Object.keys(pool.byLabelNorm);
        for (var j=0; j<ks.length; j++) {
          var k = ks[j];
          if (k === a || k.indexOf(a) >= 0 || a.indexOf(k) >= 0) {
            if (pool.byLabelNorm[k]) return pool.byLabelNorm[k];
          }
        }
      }
      return null;
    };
    log('v14 pool + lookup patched');
  }

  /* ── 4) Derived formulas: điền nốt các ô còn 0 sau lookup ───── */
  function applyDerivedFormulas(summaryEl){
    if (!summaryEl || !global.hsvFixV14) return 0;
    var lookup = global.hsvFixV14.lookup;
    var rows = summaryEl.querySelectorAll('.hsv16-row');
    var map = {};
    rows.forEach(function(r){
      var k = r.querySelector('.k'); var v = r.querySelector('.v');
      if (!k || !v) return;
      map[norm(k.textContent||'')] = { row:r, k:k, v:v };
    });
    function isZero(cell){
      var t = (cell.v.textContent||'').trim();
      return !t || /^0\s*đ?$/.test(t) || /^0[.,]0+\s*%?$/.test(t) || t === '—';
    }
    function setV(row, val, pct){
      if (!row) return false;
      if (!isZero(row)) return false;
      row.v.textContent = pct
        ? (Number(val).toFixed(2).replace(/\.00$/, '.0') + '%')
        : fmtVND(val);
      row.v.setAttribute('data-fixv15', '1');
      if (val > 0) row.v.classList.add('pos');
      return true;
    }
    function getV(row){
      if (!row) return 0;
      return toNum(row.v.textContent);
    }
    var patched = 0;

    var vonTuCo   = getV(map['von tu co']);
    var hmtdDuyet = getV(map['hmtd duyet']);
    var vonTctdKhac = getV(map['von vay tctd khac']);
    var nhuCauVon = vonTuCo + hmtdDuyet + vonTctdKhac;
    if (nhuCauVon > 0) {
      if (setV(map['nhu cau von'], nhuCauVon)) patched++;
      if (setV(map['ty le vtc (%)'], vonTuCo / nhuCauVon * 100, true)) patched++;
    }

    var tongCP  = getV(map['tong cp (chua lai, kh)']);
    var lai     = getV(map['lai']);
    var khauHao = getV(map['khau hao']);
    var thue    = getV(map['thue']);
    var tongCpPA = tongCP + lai + khauHao + thue;
    if (tongCpPA > 0 && setV(map['tong cp pa sxkd'], tongCpPA)) patched++;

    var tongDT   = getV(map['tong doanh thu']);
    if (tongDT > 0 && tongCpPA > 0) {
      var chenh = tongDT - tongCpPA;
      if (setV(map['chenh lech cp'], chenh)) patched++;
      var lnTT = chenh - thue;
      if (setV(map['loi nhuan thuc te'], lnTT)) patched++;
    }

    var tySuat = toNum((map['ty suat ln (%)'] && map['ty suat ln (%)'].v.textContent) || 0);
    var lnMT   = getV(map['ln muc tieu']) || getV(map['loi nhuan du kien (muc tieu)']);
    if (tySuat > 0 && lnMT > 0 && setV(map['dt can dat'], lnMT / (tySuat/100))) patched++;

    // Tổng TSHS = giá trị TS + LĐ + khác + hàng hoá + tiền mặt + nợ phải thu + nợ phải trả (điều chỉnh dấu)
    var giaTriTS = getV(map['tong gia tri ts']);
    var giaTriLD = getV(map['gia tri ld']);
    var tsKhac   = getV(map['ts khac']);
    var hangHoa  = getV(map['hang hoa cac loai']);
    var tienMat  = getV(map['tien mat']);
    var noThu    = getV(map['no phai thu']);
    var noTra    = getV(map['no phai tra']);
    var tongTSHS = giaTriTS + giaTriLD + tsKhac + hangHoa + tienMat + noThu + noTra;
    if (tongTSHS > 0 && setV(map['tong tshs'], tongTSHS)) patched++;

    // Nợ phải trả tổng hợp
    var noPA = getV(map['no phai tra pa']);
    var duNo = getV(map['du no']);
    var noNB = getV(map['no nguoi ban']);
    var noKhac = getV(map['no phai tra khac']);
    var noTraSum = noPA + duNo + noNB + noKhac;
    if (noTraSum > 0 && setV(map['no phai tra'], noTraSum)) patched++;

    if (patched > 0) log('derived patched', patched);
    return patched;
  }

  /* ── 5) Hidden-mount PA SXKD (best-effort) ───────────────────── */
  function ensurePaShadow(){
    if (document.getElementById('hsv-v15-pa-shadow')) return;
    try {
      var sh = document.createElement('div');
      sh.id = 'hsv-v15-pa-shadow';
      sh.setAttribute('aria-hidden', 'true');
      sh.style.cssText = 'position:fixed;left:-99999px;top:0;width:1280px;height:1px;overflow:hidden;pointer-events:none;opacity:0;';
      document.body.appendChild(sh);

      // Best-effort: nếu app có bus + emitter render tab
      var bus = global.hsvBus || global.bus;
      if (bus && typeof bus.emit === 'function') {
        try { bus.emit('nav:prefetch', { tab: 'pa_sxkd', target: sh, silent: true }); } catch(_){}
      }
      // Copy nội dung tab pa_sxkd (nếu đã render sẵn ở đâu đó) — clone không mount lại
      var src = document.querySelector('[data-tab="pa_sxkd"], #tab-pa-sxkd, [data-nav="pa_sxkd"] + .tab-panel');
      if (src) {
        try { sh.innerHTML = ''; sh.appendChild(src.cloneNode(true)); } catch(_){}
      }
      log('shadow mount ready');
    } catch(e){ log('shadow mount fail', e && e.message); }
  }

  /* ── 6) Rerender + hooks ─────────────────────────────────────── */
  var _t = null;
  function rerender(){
    if (_t) return;
    _t = setTimeout(function(){
      _t = null;
      try {
        if (global.hsvFixV14 && typeof global.hsvFixV14.rerender === 'function') {
          global.hsvFixV14.rerender();
        }
      } catch(_){}
      // Sau khi v14 render xong, chạy derived formulas
      setTimeout(function(){
        document.querySelectorAll('#hsv16-summary').forEach(applyDerivedFormulas);
      }, 120);
    }, 80);
  }

  function attachBus(){
    var bus = global.hsvBus || global.bus;
    if (!bus || typeof bus.on !== 'function' || global.__hsvFixV15Bus) return;
    global.__hsvFixV15Bus = true;
    ['pa_sxkd:imported','pa_sxkd:changed','pa:updated','form:hoso:changed','hsv:sync','nav:tab','nav:goto']
      .forEach(function(ev){ try{ bus.on(ev, rerender); }catch(_){} });
    log('bus v15 hooked');
  }

  function attachSummaryObserver(){
    if (global.__hsvFixV15Obs) return;
    try {
      var mo = new MutationObserver(function(muts){
        for (var i=0; i<muts.length; i++){
          var t = muts[i].target;
          if (t && ((t.id === 'hsv16-summary') || (t.closest && t.closest('#hsv16-summary')))) {
            setTimeout(function(){
              document.querySelectorAll('#hsv16-summary').forEach(applyDerivedFormulas);
            }, 100);
            return;
          }
        }
      });
      mo.observe(document.body || document.documentElement, { childList:true, subtree:true });
      global.__hsvFixV15Obs = mo;
    } catch(_){}
  }

  function boot(){
    loadSeed();
    installBuildPoolPatch();
    ensurePaShadow();
    attachBus();
    attachSummaryObserver();
    rerender();
    log('boot ok');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
  // Kick lại để bắt v14 load muộn hơn / render trễ
  setTimeout(function(){ installBuildPoolPatch(); attachBus(); rerender(); }, 800);
  setTimeout(function(){ installBuildPoolPatch(); rerender(); }, 2000);
  setTimeout(function(){ installBuildPoolPatch(); rerender(); }, 4500);
  setTimeout(function(){ installBuildPoolPatch(); rerender(); }, 7000);

  global.hsvFixV15 = {
    version: 'v15.0.0',
    rerender: rerender,
    reloadSeed: function(){ _seedPool = null; loadSeed(); },
    seedPool: function(){ return _seedPool; },
    applyDerived: function(){ document.querySelectorAll('#hsv16-summary').forEach(applyDerivedFormulas); }
  };
})(typeof window !== 'undefined' ? window : this);
