/* ==================================================================
   HSV UI REDESIGN v6 (2026-07-16) — overlay bổ sung, additive-only.
   Không sửa app.js / fix-v13.js / hsv-ui2026-patch-v4.js / hsv-2026.js /
   hsv-polish.js / hsv-cmdk.js. Chỉ "wrap" (bọc) các hàm toàn cục sẵn có
   (renderWizard, setWizardSearch) theo đúng khuôn mẫu đã dùng ở các bản
   vá trước (v8-patch, v9-patch trong app.js).

   AN TOÀN VỚI CÁC OVERLAY KHÁC:
   - KHÔNG di dời (reparent) bất kỳ .group-btn / #hsv16-summary /
     #v13-statusbar nào — chỉ CHÈN thêm phần tử tiêu đề section làm
     anh em (sibling) và bật/tắt class ẩn/hiện. Nhờ vậy không xung đột
     với MutationObserver + polling 800ms của hsv-ui2026-patch-v4.js
     (hàm relocateReconPanel dựa vào việc .group-btn vẫn là con trực
     tiếp của #wizard-sidebar để tính view-parent).
   Rollback: xoá 2 dòng <link>/<script> của v6 khỏi index.html.
   ================================================================== */
(function () {
  'use strict';
  var TAG = '[hsv6]';

  var openSections = {};     // { [sectionLabel]: true } — nhớ trạng thái mở/đóng trong phiên
  var lastProduct = null;
  var panelCollapsed = false;

  function escHtml(s) {
    s = s == null ? '' : String(s);
    return s.replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* ============================================================
     A. SIDEBAR — gom nút nhóm thành accordion theo sectionLabel
     ============================================================ */
  function buildSidebarAccordion() {
    var sidebar = document.getElementById('wizard-sidebar');
    if (!sidebar) return;
    if (typeof store === 'undefined' || typeof currentCaseId === 'undefined') return;
    var c = store.cases[currentCaseId];
    if (!c || typeof getGroupsByProduct !== 'function') return;
    var groups = getGroupsByProduct(c.product);

    // Xoá các tiêu đề section đã chèn ở lượt trước (để build lại không lặp)
    Array.prototype.slice.call(sidebar.querySelectorAll(':scope > .hsv6-section-head'))
      .forEach(function (h) { h.remove(); });

    var btns = Array.prototype.filter.call(sidebar.children, function (el) {
      return el.classList && el.classList.contains('group-btn');
    });
    if (!btns.length || btns.length !== groups.length) return; // dữ liệu không khớp — bỏ qua an toàn

    if (lastProduct !== c.product) { openSections = {}; lastProduct = c.product; }
    var active = (typeof wizardState !== 'undefined') ? (wizardState.activeGroup || 0) : 0;
    var activeSec = groups[active] ? (groups[active].sectionLabel || 'Khác') : 'Khác';
    openSections[activeSec] = true;

    var flat = (typeof caseFlatValues === 'function') ? caseFlatValues(c) : {};
    var i = 0;
    while (i < btns.length) {
      var sec = groups[i] ? (groups[i].sectionLabel || 'Khác') : 'Khác';
      var j = i, filled = 0, total = 0;
      while (j < btns.length && (groups[j] ? (groups[j].sectionLabel || 'Khác') : 'Khác') === sec) {
        var g = groups[j];
        if (g) {
          filled += g.fields.filter(function (fd) { return (flat[fd.key] || '').toString().trim(); }).length;
          total += g.fields.length;
        }
        j++;
      }
      var isOpen = !!openSections[sec];
      var pct = total ? Math.round((filled / total) * 100) : 0;

      var head = document.createElement('button');
      head.type = 'button';
      head.className = 'hsv6-section-head' + (isOpen ? ' open' : '');
      head.innerHTML =
        '<span class="hsv6-sec-chevron">\u25B8</span>' +
        '<span class="hsv6-sec-name"></span>' +
        '<span class="hsv6-sec-pct' + (pct === 100 ? ' complete' : '') + '">' + filled + '/' + total + '</span>';
      head.querySelector('.hsv6-sec-name').textContent = sec;
      (function (secName, headEl) {
        headEl.addEventListener('click', function () {
          openSections[secName] = !openSections[secName];
          buildSidebarAccordion();
        });
      })(sec, head);

      sidebar.insertBefore(head, btns[i]);
      for (var k = i; k < j; k++) {
        btns[k].classList.add('hsv6-grouped');
        btns[k].classList.toggle('hsv6-hidden', !isOpen);
      }
      i = j;
    }
  }

  /* ============================================================
     B. SUBSECTION TRONG KHUNG NHẬP — chèn tiêu đề khi chủ đề đổi
     ============================================================ */
  var BUCKETS = [
    [/thừa\s*kế/i, 'Người thừa kế'],
    [/chủ\s*tài\s*sản|bên\s*thế\s*chấp/i, 'Chủ tài sản / bên thế chấp'],
    [/tên\s*khách\s*hàng|mã\s*khách\s*hàng|cmnd|căn\s*cước|xưng\s*hô|năm\s*sinh|nam\/nữ|nghề\s*nghiệp/i, 'Thông tin khách hàng'],
    [/thửa|diện\s*tích\s*đất|loại\s*đất|đất\s*ở|dtđ|nguồn\s*gốc|hạn\s*chế|vị\s*trí\s*theo\s*bảng\s*giá|bbđg|bìa\s*đỏ|địa\s*chỉ\s*đất/i, 'Thửa đất'],
    [/nhà|kết\s*cấu|số\s*tầng|diện\s*tích\s*(sàn|xd|sd)/i, 'Nhà / công trình'],
    [/giá\s*trị|giá\s*đất/i, 'Định giá tài sản'],
    [/thế\s*chấp|hđtc|nghĩa\s*vụ|nvđb|nvbđ|gtcv/i, 'Hợp đồng thế chấp'],
    [/hợp\s*đồng\s*tín\s*dụng|hđ\s*tín\s*dụng|lãi\s*suất|thời\s*hạn\s*vay|thể\s*loại\s*vay|kỳ\s*hạn/i, 'Hợp đồng vay / lãi suất'],
    [/thu\s*nhập|chi\s*phí|lợi\s*nhuận|doanh\s*thu/i, 'Thu nhập – chi phí'],
    [/nợ|dư\s*nợ|trả\s*nợ|trả\s*gốc|trả\s*lãi/i, 'Dư nợ / trả nợ'],
    [/vốn\s*tự\s*có|nhu\s*cầu\s*vốn|vốn\s*đối\s*ứng/i, 'Vốn / nhu cầu vốn']
  ];
  function classify(label) {
    for (var i = 0; i < BUCKETS.length; i++) if (BUCKETS[i][0].test(label)) return BUCKETS[i][1];
    return 'Thông tin khác';
  }
  function insertSubsectionDividers() {
    var wrap = document.getElementById('wizard-fields');
    if (!wrap) return;
    var rows = Array.prototype.slice.call(wrap.querySelectorAll(':scope > .field-row'));
    if (rows.length < 4) return;
    var buckets = rows.map(function (row) {
      var el = row.querySelector('.field-label-text');
      return classify(el ? el.textContent : '');
    });
    var distinct = {};
    buckets.forEach(function (b) { distinct[b] = true; });
    if (Object.keys(distinct).length < 2) return; // 1 chủ đề duy nhất — không cần chia nhỏ

    var prev = null;
    rows.forEach(function (row, idx) {
      if (buckets[idx] !== prev) {
        var div = document.createElement('div');
        div.className = 'hsv6-subsection';
        div.textContent = buckets[idx];
        wrap.insertBefore(div, row);
        prev = buckets[idx];
      }
    });
  }

  /* ============================================================
     C. TÌM KIẾM TOÀN HỒ SƠ (ngoài nhóm đang mở)
     ============================================================ */
  var origSetWizardSearch = null;
  function renderGlobalSearchResults(v) {
    var searchRow = document.querySelector('.wizard-layout .search-row');
    if (!searchRow) return;
    var box = document.getElementById('hsv6-global-results');
    var q = (v || '').trim().toLowerCase();
    if (q.length < 2) { if (box) box.style.display = 'none'; return; }
    if (typeof store === 'undefined' || typeof currentCaseId === 'undefined') return;
    var c = store.cases[currentCaseId];
    if (!c || typeof getGroupsByProduct !== 'function') return;
    var groups = getGroupsByProduct(c.product);
    var activeIdx = (typeof wizardState !== 'undefined') ? wizardState.activeGroup : -1;

    var results = [];
    groups.forEach(function (g, gi) {
      if (gi === activeIdx) return; // nhóm hiện tại đã lọc sẵn tại chỗ
      g.fields.forEach(function (f) {
        if (f.label.toLowerCase().indexOf(q) !== -1) results.push({ g: g, gi: gi, f: f });
      });
    });

    if (!box) {
      box = document.createElement('div');
      box.id = 'hsv6-global-results';
      searchRow.insertAdjacentElement('afterend', box);
    }
    if (!results.length) { box.style.display = 'none'; box.innerHTML = ''; return; }

    var shown = results.slice(0, 8);
    box.style.display = 'block';
    box.innerHTML =
      '<div class="hsv6-gr-label">Ngoài nhóm hiện tại (' + results.length + ' kết quả):</div>' +
      shown.map(function (r) {
        return '<button type="button" class="hsv6-gr-item" data-gi="' + r.gi + '">' +
          '<span class="hsv6-gr-field">' + escHtml(r.f.label) + '</span>' +
          '<span class="hsv6-gr-group">' + escHtml(r.g.sectionLabel || '') + ' \u203A ' + escHtml(r.g.groupLabel || '') + '</span>' +
          '</button>';
      }).join('');
    Array.prototype.slice.call(box.querySelectorAll('.hsv6-gr-item')).forEach(function (btn) {
      btn.addEventListener('click', function () {
        var gi = parseInt(btn.getAttribute('data-gi'), 10);
        if (typeof setWizardGroup === 'function') setWizardGroup(gi);
      });
    });
  }

  /* ============================================================
     D. TIẾN ĐỘ HỒ SƠ THEO TỪNG PHẦN
     ============================================================ */
  function buildProgressCardHtml(c) {
    if (typeof getGroupsByProduct !== 'function' || typeof caseFlatValues !== 'function') return '';
    var groups = getGroupsByProduct(c.product);
    var flat = caseFlatValues(c);
    var bySection = {}, order = [];
    groups.forEach(function (g) {
      var sec = g.sectionLabel || 'Khác';
      if (!bySection[sec]) { bySection[sec] = { filled: 0, total: 0 }; order.push(sec); }
      bySection[sec].filled += g.fields.filter(function (f) { return (flat[f.key] || '').toString().trim(); }).length;
      bySection[sec].total += g.fields.length;
    });
    var rows = order.map(function (sec) {
      var s = bySection[sec];
      var pct = s.total ? Math.round((s.filled / s.total) * 100) : 0;
      return '<div class="hsv6-prog-row">' +
        '<div class="hsv6-prog-top"><span>' + escHtml(sec) + '</span><span class="mono">' + s.filled + '/' + s.total + '</span></div>' +
        '<div class="hsv6-prog-bar"><div class="hsv6-prog-fill' + (pct === 100 ? ' complete' : '') + '" style="width:' + pct + '%"></div></div>' +
        '</div>';
    }).join('');
    return '<div class="card smart-card hsv6-progress-card"><h3 class="serif" style="margin:0 0 10px">Tiến độ hồ sơ</h3>' + rows + '</div>';
  }

  function injectMobileProgress(c) {
    var ph = document.querySelector('#main-content .page-header');
    if (!ph) return;
    var old = document.getElementById('hsv6-mobile-progress');
    if (old) old.remove();
    var div = document.createElement('div');
    div.id = 'hsv6-mobile-progress';
    div.className = 'hsv6-mobile-progress';
    div.innerHTML = buildProgressCardHtml(c);
    ph.insertAdjacentElement('afterend', div);
  }

  /* ============================================================
     E. NÚT ẨN/HIỆN CỘT PHẢI
     ============================================================ */
  function applyPanelState() {
    var wl = document.querySelector('.wizard-layout');
    if (wl) wl.classList.toggle('hsv6-panel-collapsed', panelCollapsed);
    var btn = document.getElementById('hsv6-panel-toggle');
    if (btn) btn.textContent = panelCollapsed ? '\u2039 Hiện bảng' : 'Ẩn bảng \u203A';
  }
  function ensurePanelToggle() {
    var searchRow = document.querySelector('.wizard-layout .search-row');
    if (!searchRow) return;
    var btn = document.getElementById('hsv6-panel-toggle');
    if (!btn) {
      btn = document.createElement('button');
      btn.type = 'button';
      btn.id = 'hsv6-panel-toggle';
      btn.className = 'hsv6-panel-toggle-btn';
      btn.title = 'Ẩn/hiện cột tiến độ & tiện ích';
      searchRow.appendChild(btn);
      btn.addEventListener('click', function () {
        panelCollapsed = !panelCollapsed;
        applyPanelState();
      });
    }
    applyPanelState();
  }

  /* ============================================================
     POST-PROCESS — chạy sau mỗi lần renderWizard()
     ============================================================ */
  function postProcess() {
    if (typeof store === 'undefined' || typeof currentCaseId === 'undefined') return;
    var c = store.cases[currentCaseId];
    if (!c) return;
    try { buildSidebarAccordion(); } catch (e) { console.warn(TAG, 'sidebar', e); }
    try { insertSubsectionDividers(); } catch (e) { console.warn(TAG, 'subsection', e); }
    try {
      var panel = document.querySelector('.wizard-layout > .smart-panel');
      if (panel) panel.insertAdjacentHTML('afterbegin', buildProgressCardHtml(c));
    } catch (e) { console.warn(TAG, 'progress-card', e); }
    try { injectMobileProgress(c); } catch (e) { console.warn(TAG, 'mobile-progress', e); }
    try { ensurePanelToggle(); } catch (e) { console.warn(TAG, 'panel-toggle', e); }
  }

  function whenReady(cb) {
    if (typeof window.renderWizard === 'function' &&
        typeof window.FIELD_META !== 'undefined' &&
        typeof window.store !== 'undefined') return cb();
    setTimeout(function () { whenReady(cb); }, 100);
  }

  whenReady(function () {
    if (window.__hsv6_installed__) return;
    window.__hsv6_installed__ = true;

    if (typeof window.setWizardSearch === 'function') {
      origSetWizardSearch = window.setWizardSearch;
      window.setWizardSearch = function (v) {
        origSetWizardSearch(v);
        try { insertSubsectionDividers(); } catch (e) {}
        try { renderGlobalSearchResults(v); } catch (e) {}
      };
    }

    var _origRenderWizard = window.renderWizard;
    window.renderWizard = function () {
      _origRenderWizard.apply(this, arguments);
      // Chạy sau injectStickyNav() của v8-patch (setTimeout ~30ms) để không bị ghi đè.
      setTimeout(function () { postProcess(); }, 60);
    };

    // Nếu trang wizard đã hiển thị sẵn khi script này nạp xong, xử lý ngay.
    setTimeout(postProcess, 250);

    console.log(TAG, 'Overlay v6 đã kích hoạt (sidebar accordion, subsection, tìm kiếm toàn hồ sơ, panel phải, tiến độ).');
  });
})();
