/* fix-v18-cleanup.js — 2026-07-16
 * Loại bỏ panel "Trường tuỳ chỉnh (HSV15 Builder)" (VÒNG QUAY, v.v.) khỏi form.
 * Chiến lược 3 lớp:
 *   1) Dọn layout.custom trong mọi key localStorage builder.
 *   2) Xoá phần tử #hsv15-custom-host mỗi khi nó xuất hiện.
 *   3) MutationObserver theo dõi <body> để chặn tái xuất hiện.
 */
(function(){
  'use strict';

  function purgeLocalStorage(){
    try {
      for (var i = 0; i < localStorage.length; i++){
        var k = localStorage.key(i);
        if (!k) continue;
        var v = localStorage.getItem(k);
        if (!v || v.indexOf('custom') === -1) continue;
        var obj;
        try { obj = JSON.parse(v); } catch(_) { continue; }
        var changed = false;
        if (obj && typeof obj === 'object'){
          if (Array.isArray(obj.custom) && obj.custom.length){
            obj.custom = []; changed = true;
          }
          // Layout dạng {sections:[{custom:[]}]} hoặc {product:{custom:[]}}
          if (obj.layout && Array.isArray(obj.layout.custom) && obj.layout.custom.length){
            obj.layout.custom = []; changed = true;
          }
        }
        if (changed){
          try { localStorage.setItem(k, JSON.stringify(obj)); } catch(_){}
        }
      }
    } catch(_){}
  }

  function killHost(){
    var nodes = document.querySelectorAll('#hsv15-custom-host');
    nodes.forEach(function(n){ n.remove(); });
  }

  function boot(){
    purgeLocalStorage();
    killHost();
    var mo = new MutationObserver(function(muts){
      for (var i = 0; i < muts.length; i++){
        var m = muts[i];
        if (m.addedNodes && m.addedNodes.length){
          for (var j = 0; j < m.addedNodes.length; j++){
            var n = m.addedNodes[j];
            if (n && n.nodeType === 1){
              if (n.id === 'hsv15-custom-host'){ n.remove(); }
              else if (n.querySelector){
                var inner = n.querySelector('#hsv15-custom-host');
                if (inner) inner.remove();
              }
            }
          }
        }
      }
    });
    mo.observe(document.documentElement, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }
})();
