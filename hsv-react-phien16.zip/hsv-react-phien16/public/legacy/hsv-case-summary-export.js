/* ============================================================
   HSV Case Summary Export v1 — Xuất Excel tổng hợp nhiều hồ sơ
   Thêm 1 nút trên trang chủ để xuất danh sách toàn bộ hồ sơ hiện có
   (tên KH, sản phẩm, số tiền vay, % hoàn thành, ngày cập nhật) ra 1
   file Excel — dùng khi cần báo cáo/thống kê nhanh nhiều hồ sơ.

   AN TOÀN TUYỆT ĐỐI: tái sử dụng đúng engine ghi Excel đã có sẵn
   (window.hsvExport.excel — dùng cho PA SXKD), không viết lại bộ ghi
   XLSX mới. Không sửa store/dữ liệu hồ sơ, chỉ ĐỌC để tổng hợp. Nút chỉ
   được chèn thêm cạnh nút "Tạo hồ sơ mới" có sẵn — không thay thế logic
   render trang chủ.
   ============================================================ */
(function () {
  "use strict";
  if (window.__hsvCaseSummaryInstalled) return;
  window.__hsvCaseSummaryInstalled = true;

  var SUFFIX_BY_PRODUCT = { TIEU_DUNG: "TD", CAM_CO: "CC", HMTD: "HM" };

  function moneyField(c, candidates) {
    var flat;
    try { flat = window.caseFlatValues(c); } catch (e) { flat = c.values || {}; }
    var suf = SUFFIX_BY_PRODUCT[c.product] || "";
    for (var i = 0; i < candidates.length; i++) {
      var base = candidates[i];
      var v = flat[base + (suf ? " " + suf : "")] || flat[base];
      if (v) return v;
    }
    return "";
  }

  function buildRows() {
    var cases = Object.values((window.store && window.store.cases) || {});
    return cases.map(function (c) {
      var allFields = [];
      try { allFields = window.getAllFieldsByProduct(c.product) || []; } catch (e) {}
      var flat = {};
      try { flat = window.caseFlatValues(c) || {}; } catch (e) {}
      var filled = allFields.filter(function (f) { return (flat[f.key] || "").toString().trim(); }).length;
      var pct = allFields.length ? Math.round((filled / allFields.length) * 100) : 0;
      return {
        "Tên khách hàng": c.customerName || "",
        "Mã KH": c.customerCode || "",
        "Sản phẩm": c.productLabel || c.product || "",
        "Số tiền vay": moneyField(c, ["Số tiền vay", "Tổng nhu cầu vốn"]),
        "Tiến độ (%)": pct,
        "Cập nhật lúc": c.updatedAt ? new Date(c.updatedAt).toLocaleString("vi-VN") : "",
        "Tạo lúc": c.createdAt ? new Date(c.createdAt).toLocaleString("vi-VN") : "",
      };
    });
  }

  function doExportSummary() {
    try {
      var rows = buildRows();
      if (!rows.length) {
        if (typeof window.toast === "function") window.toast("Chưa có hồ sơ nào để xuất", "warn");
        return;
      }
      if (!window.hsvExport || typeof window.hsvExport.excel !== "function") {
        if (typeof window.toast === "function") window.toast("Không tìm thấy công cụ xuất Excel", "error");
        return;
      }
      window.hsvExport.excel(
        [{ name: "Danh sách hồ sơ", data: rows }],
        "DanhSachHoSo_" + new Date().toISOString().slice(0, 10) + ".xlsx"
      );
      if (typeof window.toast === "function") window.toast("Đã xuất " + rows.length + " hồ sơ ra Excel", "success");
    } catch (e) {
      if (typeof window.toast === "function") window.toast("Lỗi xuất Excel: " + e.message, "error");
    }
  }

  window.HSVExportCaseSummary = doExportSummary;

  function ensureButton() {
    try {
      var btnBar = document.querySelector(".page-header-btns");
      if (!btnBar || document.getElementById("hsv-export-summary-btn")) return;
      var btn = document.createElement("button");
      btn.id = "hsv-export-summary-btn";
      btn.className = "btn btn-ghost";
      btn.type = "button";
      btn.innerHTML = "📊 Xuất Excel tổng hợp";
      btn.addEventListener("click", doExportSummary);
      btnBar.insertBefore(btn, btnBar.firstChild);
    } catch (e) {
      /* nếu cấu trúc trang thay đổi — bỏ qua, không hiện nút */
    }
  }

  function start() {
    var target = document.getElementById("main-content");
    if (!target) { setTimeout(start, 300); return; }
    ensureButton();
    var obs = new MutationObserver(function () { ensureButton(); });
    obs.observe(target, { childList: true, subtree: false });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
