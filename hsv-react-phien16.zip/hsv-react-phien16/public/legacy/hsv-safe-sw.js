/* HSV SAFE v25.6.0 — Service Worker
   Strategy: network-first for HTML, cache-first for hashed/static assets.
   Never precache 9.6MB templates-data.js — served on first use only. */
'use strict';
const CACHE = 'hsv-safe-v2560';
const CORE = [
  './',
  'index.html',
  'hsv-consolidated.css',
  'hsv-safe-sw.js',
  'hsv-safe-v25.6.0/loader.js',
  'hsv-safe-v25.6.0/styles.css',
  'hsv-safe-v25.6.0/a11y.js',
  'hsv-safe-v25.6.0/theme.js',
  'hsv-safe-v25.6.0/ios.js',
  'hsv-safe-v25.6.0/autosave.js',
  'hsv-safe-v25.6.0/backup-io.js',
  'hsv-safe-v25.6.0/validate.js',
  'hsv-safe-v25.6.0/palette.js',
  'hsv-safe-v25.6.0/print.js',
  'hsv-safe-v25.6.0/template-lazy.js',
  'hsv-safe-v25.6.0/pwa.js'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(CORE).catch(() => {})));
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;

  const isHtml = req.mode === 'navigate' ||
                 (req.headers.get('accept') || '').includes('text/html');

  if (isHtml) {
    // Network-first for HTML
    e.respondWith((async () => {
      try {
        const fresh = await fetch(req);
        const c = await caches.open(CACHE);
        c.put(req, fresh.clone()).catch(() => {});
        return fresh;
      } catch (err) {
        return (await caches.match(req)) || (await caches.match('index.html'));
      }
    })());
    return;
  }

  // Cache-first for assets
  e.respondWith((async () => {
    const cached = await caches.match(req);
    if (cached) return cached;
    try {
      const fresh = await fetch(req);
      if (fresh.ok && fresh.type === 'basic') {
        const c = await caches.open(CACHE);
        c.put(req, fresh.clone()).catch(() => {});
      }
      return fresh;
    } catch (err) {
      return new Response('', { status: 504 });
    }
  })());
});
