# FIX v21 — Sửa gốc lỗi "loop nhiều TSBĐ (2+ tài sản) không hoạt động"

## 1. Nguyên nhân gốc rễ (root cause) — có 2 lỗi độc lập cộng hưởng

### Lỗi A — Sai khớp label cho field `.ts.*` (khiến MỌI công thức TSBĐ = 0,
kể cả khi chỉ có 1 tài sản)
Các công thức trong `F_HANMUC`/`F_TSBD`/`F_CAMCO` đặt `target` là
`".ts.Chủ tài sản viết hoa"` (có tiền tố `.ts.`), nhưng field thật trong
`FIELD_META` lại có `label` KHÔNG có tiền tố này (`"Chủ tài sản viết hoa"`).
Hàm `findKeyByLabel()` chỉ so khớp **chính xác chuỗi** label →
`".ts.chủ tài sản viết hoa" !== "chủ tài sản viết hoa"` → luôn trả về
`null` → bảng "Kiểm tra công thức" báo `[chưa có field]`, giá trị công thức
ra `0`/`OVR`/`ERR` đúng như trong ảnh chụp màn hình.

**Nghiêm trọng hơn:** hàm `findKeyByLabel()` bị **copy-paste độc lập ở 5
nơi khác nhau** trong `app.js` (dòng ~18582, ~20062, ~27169, ~27376,
~27775 — mỗi bản vá `fix-vXX` tự viết lại một bản riêng). Vì vậy sửa 1 chỗ
không lan ra các chỗ khác — đây là lý do lỗi tồn tại qua nhiều đời "fix".

### Lỗi B — Hai hệ thống "loop nhiều tài sản" độc lập, tranh nhau cùng
một bộ input (khiến 2+ tài sản cụ thể bị hỏng)
Codebase có **2 cơ chế multi-TSBĐ song song, không biết đến nhau**:

1. **Hệ gốc** (`c.assets[]`, `c.activeAsset`, `setActiveAsset()`,
   `renderAssetTabs()`, `caseFlatValues()`) — lưu theo **từng hồ sơ**, ghi
   qua `doSetValue`/`updateValues` nên kích hoạt tính lại công thức đúng
   cách.
2. **Module "AM — Assets Manager"** (IIFE `"Loop nhiều tài sản — v1"`) —
   lưu trong `localStorage['agri_assets_v1']` theo **từng LOẠI SẢN PHẨM**
   (dùng chung cho mọi hồ sơ!), tự vẽ thêm một thanh tab TSBĐ thứ hai
   (`.am-bar`) chồng lên thanh tab gốc (`.asset-tabs-bar`), và khi đổi tab
   chỉ gán thẳng `el.value = ...` vào DOM — **bỏ qua `doSetValue`**, nên
   không cập nhật `store.cases`, không kích hoạt `recalc()`.

   Hệ quả khi có ≥2 tài sản: dữ liệu gõ vào tài sản #2 có thể bị ghi vào
   bucket của hệ này trong khi công thức lại đọc từ hệ kia (hoặc ngược
   lại), bảng công thức không tự tính lại khi đổi tab, và cả 2 thanh tab
   cùng hiển thị gây nhầm lẫn "tài sản #2" nào mới là thật.

## 2. Đã sửa trong `app.js` (không đổi file nào khác)

1. **Thêm bộ giải field-key dùng chung** `window.hsvResolveFieldKey()`
   (đặt ngay sau `isAssetKey()`): chuẩn hoá label, tự bỏ tiền tố `.ts.`,
   ưu tiên field cùng "loại" (asset-scoped hay không) với target, có
   fallback so khớp gần đúng (Dice bigram ≥ 86%) cho trường hợp lệch dấu
   câu/khoảng trắng nhẹ trong tương lai. Có cache theo `product`, tự làm
   mới qua `window.hsvInvalidateFieldIndex()`.
2. **Trỏ cả 5 bản `findKeyByLabel()`** về dùng chung
   `hsvResolveFieldKey()` (giữ lại logic cũ làm fallback nếu hàm dùng
   chung chưa kịp nạp) — sửa một lần, có hiệu lực ở mọi nơi.
3. **Tắt module "AM" trùng lặp**: `init()` của AM giờ kiểm tra nếu hệ gốc
   (`setActiveAsset`/`renderAssetTabs`) đã tồn tại thì AM tự vô hiệu hoá
   hoàn toàn (không cài hook, không vẽ thanh tab thứ hai, không đụng vào
   `localStorage['agri_assets_v1']` nữa). Hệ gốc vốn đã có đủ tính năng
   thêm/xoá/nhân bản/sắp xếp TSBĐ và export DOCX dạng mảng
   (`buildExportData` → `TSBD`/`assets`), nên không mất chức năng.
4. **Nâng cấp bảng "Kiểm tra công thức"**:
   - Hiện rõ **đang xem TSBĐ #mấy / tổng bao nhiêu TSBĐ** của hồ sơ, nhắc
     đổi tab rồi bấm ↻ để soi từng tài sản.
   - Với mọi target còn `[chưa có field]` sau khi đã fallback, tự động
     gợi ý field gần đúng nhất (`window.hsvSuggestFieldKey`) kèm % khớp,
     thay vì chỉ báo lỗi — để người quản trị thấy ngay công thức nào cần
     cập nhật khi FIELD_META đổi label/placeholder trong tương lai.

## 3. Cách kiểm thử nhanh
1. Mở hồ sơ HMTD/TSBĐ có ≥2 TSBĐ (dùng "+ Thêm"/"⎘ Nhân bản" ở thanh tab
   `.asset-tabs-bar` — thanh `.am-bar` sẽ không còn xuất hiện nữa).
2. Nhập số liệu khác nhau cho TSBĐ #1 và #2.
3. Mở "ƒ Kiểm tra công thức" (Ctrl+Shift+F): các dòng `.ts.*` phải ra
   `OK` với giá trị đúng theo TSBĐ đang chọn, không còn
   `[chưa có field]`.
4. Đổi sang TSBĐ #2, bấm ↻ — giá trị trong bảng phải đổi theo đúng TSBĐ
   #2 (không còn kẹt số của TSBĐ #1).
5. Console log sẽ in `[AM] Phát hiện hệ thống TSBĐ gốc... — tắt module AM
   cũ` xác nhận không còn xung đột.

## 4. Đề xuất tiếp theo (nâng cấp toàn diện hơn, chưa làm trong bản này)
- Gộp nốt phần **ghi** giá trị (không chỉ đọc) qua một hàm
  `hsvSetFormulaResult()` dùng chung, tránh mỗi patch tự viết
  `updateValues`/DOM update riêng.

---

# FIX v22 — Đã thực thi toàn bộ mục "Đề xuất tiếp theo"

## Phát hiện thêm khi rà lại toàn diện (quan trọng)
Khi thực hiện "gộp evalExpr/fmtNumberVN" đã phát hiện **một hệ loop-tài-sản
THỨ BA**, độc lập hoàn toàn với 2 hệ đã nêu ở FIX v21:

- **`js/47-asset-loop-tabs.js`**: bọc thẳng `window.selectPart` /
  `window.updateSelectPartTabs`, lưu snapshot toàn bộ form theo "part giả"
  (vd `ttTaiSan__2`) trong `localStorage['assetLoopInstances.v1']` — hoàn
  toàn khác cơ chế `.ts.*`/`c.assets[]`. Module này tự khởi động không
  điều kiện và có thể can thiệp vào việc chuyển tab TRƯỚC CẢ khi hệ gốc
  kịp render — rất có thể là nguyên nhân chính (không chỉ là 1 trong nhiều
  nguyên nhân) khiến việc chuyển qua lại giữa 2+ tài sản "chập chờn".
  → **Đã tắt** theo cùng cách với module AM: tự vô hiệu hoá khi phát hiện
  hệ gốc (`c.assets[]`) đã sẵn sàng.

- **`window.np5EvalExpr`**: phát hiện đây là **hàm chết (dead code)** — được
  định nghĩa và được 2 bản vá (`v17`, `v20-unifier`) sửa đi sửa lại với
  mục đích "root-cause fix cho lỗi …triệuđồng dính chữ", nhưng **không có
  nơi nào trong toàn bộ code gọi `np5EvalExpr(...)`** — engine chính
  (`recalc()`) dùng hàm `evalExpr` cục bộ khác hoàn toàn. Tức là các bản
  vá v17/v20 tưởng đã sửa lỗi hiển thị số tiền/chữ dính nhau nhưng **thực
  ra chưa từng có hiệu lực**. Không tự ý sửa mục này (rủi ro hành vi khác
  local `evalExpr` chưa kiểm chứng hết) — **khuyến nghị QA thủ công**: nếu
  vẫn thấy lỗi dạng "…triệuđồng" dính chữ trên UI, cần chuyển logic đã vá
  trong `np5EvalExpr` (script#73/#75) vào thẳng hàm `evalStringExpr` cục
  bộ (dòng ~18403) — đây là hàm thực sự đang chạy.

## Đã thực thi
1. ✅ **Hàm ghi kết quả công thức dùng chung** — `window.hsvApplyFieldValue()`
   (so sánh giá trị cũ/mới, gọi `updateValues`, đồng bộ DOM), engine chính
   (`recalc()`) đã trỏ qua hàm này thay vì tự viết logic ghi riêng.
2. ✅ **Self-test tự động khi tải trang** — `window.np5SelfTest()`: quét
   toàn bộ công thức của cả 4 sản phẩm (han_muc/cam_co/tieu_dung/tsbd),
   in báo cáo console (bảng `console.table`) nếu có target chưa khớp
   field nào, kèm gợi ý field gần đúng nhất. Tự chạy 1 lần ~1.5s sau khi
   trang tải, và có thể gọi lại bất kỳ lúc nào từ console.
3. ✅ **Tắt thêm hệ loop-tài-sản thứ ba** (`asset-loop-tabs.js`) — xem phần
   phát hiện ở trên.
4. ⚠️ **`np5EvalExpr` dead code** — đã ghi nhận, KHÔNG tự sửa (xem lý do ở
   trên). Cần QA xác nhận trước khi đổi.

## Cách kiểm thử thêm (bổ sung cho mục kiểm thử ở FIX v21)
- Mở Console (F12), tải lại trang: sau ~1.5s sẽ thấy dòng
  `[np5 self-test] OK — ...` hoặc cảnh báo kèm bảng chi tiết nếu còn công
  thức lỗi.
- Gõ `window.np5SelfTest()` trong Console để chạy lại thủ công bất cứ lúc
  nào (ví dụ sau khi sửa FIELD_META).
- Vào tab "TT Tài Sản" của hồ sơ HMTD/TSBĐ có ≥2 TSBĐ: chỉ còn **một**
  thanh tab tài sản duy nhất (thanh gốc `.asset-tabs-bar`); không còn
  thanh `.am-bar` hay các nút "TS #2 / +" kiểu `asset-loop-tab` của 2 hệ
  cũ chồng lên.

---

# FIX v23 — Tìm ra & sửa đúng nguyên nhân gốc còn sót (rà soát song song
toàn diện, tiếp nối v22)

## Phát hiện quan trọng nhất: fix "dư dấu ' - '" của v22 CHƯA từng chạy
trong engine thật

Khi rà lại toàn bộ các bản sao `evalString`/`evalStringExpr` rải rác
trong `app.js` (cùng bệnh copy-paste như `findKeyByLabel` ở FIX v21),
phát hiện có **5 bản sao độc lập** của hàm ghép chuỗi công thức
(`&`/`&-`/`docso[...]`/`inhoa[...]`):

| Vị trí (dòng cũ) | Vai trò | Có fix "dư dấu -" chưa? |
|---|---|---|
| ~18428 `evalStringExpr` | **Engine chính** — được `evalExpr()`/`recalc()` gọi trực tiếp, chạy cho MỌI hồ sơ | ❌ Chưa |
| ~20194 `evalStringExpr` (script "v15/patch B") | Bản sao phụ, cũng có `findKeyByLabel` riêng | ❌ Chưa |
| ~27313 `evalString` (script v16, `recalcFallback`) | Chạy **thêm 50ms sau mỗi lần** `renderWizard()`/`doSetValue()` — ghi đè trực tiếp qua `updateValues`/`el.value` | ❌ Chưa |
| ~27520 `evalString` (script v17, gắn vào `window.np5EvalExpr`) | Hàm chết — không ai gọi (đã ghi nhận ở v22) | ❌ Chưa (nhưng vô hại vì chết) |
| ~27899 `evalString` (script v20-unifier) | Chỉ chạy khi `renderWizard()` được gọi qua bản wrap riêng của chính nó | ✅ Đã có (đây là bản mà v22 tưởng là đại diện chung) |

**Hệ quả:** bản fix "ROOT-CAUSE FIX (v22)" (bỏ dấu `" - "` dư khi field
tham chiếu — VD `[Người thừa kế chủ tài sản]` — rỗng, tránh kết quả kiểu
`"NGUYỄN VĂN A -"`) **chỉ nằm trong 1/5 bản sao**. Bản sao đó (v20-unifier)
không phải là engine chạy chính; engine chính (~18428) và đặc biệt là
`recalcFallback` (v16, ~27313) — chạy **lặp lại mỗi 50ms sau mọi thao
tác nhập liệu** — vẫn dùng logic cũ, nên có thể **ghi đè lại giá trị lỗi
ngay sau khi** engine đúng vừa tính xong. Đây là lý do hợp lý nhất khiến
lỗi "dính chữ"/dư dấu vẫn được báo cáo dù v22 tưởng đã xử lý.

Field bị ảnh hưởng trực tiếp: `Bên vay`, `Bên thế chấp`, `.ts.Bên thế
chấp` (mọi sản phẩm HMTD/CAM_CO/TIEU_DUNG/TSBĐ) — bất cứ công thức nào
dùng cú pháp nối `&-` giữa 2 field mà field thứ 2 có thể để trống.

## Đã sửa
1. **Sửa gốc tại `evalStringExpr` (engine chính, ~18428)** — áp dụng đúng
   logic "resolve trước, chỉ chèn dấu nối nếu phần sau không rỗng" (giống
   bản v20-unifier đã kiểm chứng đúng). Đây là hàm `recalc()` thực sự
   dùng nên đây mới là bản fix có hiệu lực thật.
2. **Expose dùng chung**: `window.hsvEvalStringExpr = evalStringExpr;`
   ngay sau khi định nghĩa — theo đúng mô hình `hsvResolveFieldKey`/
   `hsvApplyFieldValue` đã áp dụng ở v21/v22.
3. **Trỏ 2 bản sao đang hoạt động thật** (~20194 và `recalcFallback`
   v16 ~27313, cả bản v17 chết ~27520 để phòng trường hợp bị "hồi sinh"
   sau này) **về dùng `window.hsvEvalStringExpr` khi có sẵn**, giữ logic
   cũ làm fallback nếu hàm dùng chung chưa kịp nạp (thứ tự script).
   → Từ nay `recalcFallback` (chạy 50ms sau mỗi thao tác) sẽ ghi ra kết
   quả **giống hệt** engine chính, không còn ghi đè giá trị lỗi lên giá
   trị đúng.
4. Bản sao ~27899 (v20-unifier) giữ nguyên logic riêng (đã đúng, có xử lý
   thêm gỡ `"đồng đồng"` trùng lặp trong `docso()` cục bộ) — không đổi để
   tránh rủi ro không cần thiết.

## Phát hiện thêm (chỉ ghi nhận, KHÔNG cần sửa — vô hại)
- `window.numberToVietnamese` bị định nghĩa/ghi đè **5 lần**: 2 lần khai
  báo `function numberToVietnamese(){}` trùng tên ở scope global (dòng
  cũ ~13764 — chết, bị dòng ~17139 ghi đè hoàn toàn do hoisting), rồi bị
  patch tiếp 3 lần nữa (v18 ~20111, v16 ~27208, v20 ~27807). Trong đó
  bản v16 (~27208) **thay thế toàn bộ, không gọi lại bản trước** (không
  giống các bản wrap khác luôn gọi `_orig.apply(...)`), nên fix của v18
  (~20111) bị vô hiệu hoàn toàn. Tuy nhiên đã kiểm tra: bản v16 tự nó đã
  đạt được đúng mục tiêu của v18 (không tự thêm " đồng", hỗ trợ số thập
  phân bằng "phảy") theo cách viết lại từ đầu — nên **hành vi cuối cùng
  hiện tại vẫn đúng**, chỉ là kiến trúc "ghi đè im lặng" này rủi ro cho
  tương lai (nếu ai đó sửa v18 mong đợi có tác dụng, sẽ không thấy gì
  thay đổi). Khuyến nghị dọn dẹp khi có dịp nhưng không khẩn cấp.
- Đã quét toàn bộ `window.renderWizard`/`window.doSetValue` (9 và 7 lần
  ghi đè) — xác nhận **tất cả đều wrap đúng cách** (luôn gọi lại bản
  trước qua `_orig`/`_prev`/`_rw`/`orig`), không có kiểu "thay thế hoàn
  toàn" nguy hiểm như trường hợp `numberToVietnamese` ở trên.
- `node --check` toàn bộ các file `.js` trong gói (kể cả 3 file
  `app.js`/`FIX-v21-v22-CHANGELOG.md` sau khi sửa) — không có lỗi cú
  pháp.

## Cách kiểm thử
1. Mở hồ sơ HMTD/TSBĐ, để trống trường "Người thừa kế" (hoặc "Người thừa
   kế chủ tài sản"), điền "Tên khách hàng vay"/"Chủ tài sản".
2. Xem field "Bên vay"/"Bên thế chấp" — phải ra đúng tên, **không còn**
   dấu `" - "` dư ở cuối, kể cả sau khi gõ thêm 1-2 giây (chờ qua mốc
   50ms/500ms để các bản `recalcFallback`/v20 chạy lại).
3. Gõ tiếp giá trị vào "Người thừa kế" — dấu `" - "` phải tự xuất hiện
   lại đúng vị trí.
4. Console không có lỗi mới; `window.np5SelfTest()` vẫn chạy báo cáo như
   FIX v22.


---

# FIX v23.1 — Rà soát thêm module "HSV SAFE v25.6.0" (autosave/backup/UI phụ trợ)

## 1) [NGHIÊM TRỌNG — an toàn dữ liệu] Autosave có thể khôi phục NHẦM dữ liệu
khách hàng này sang hồ sơ khách hàng khác

`hsv-safe-v25.6.0/autosave.js` là một hệ **lưu nháp tự động độc lập**,
hoàn toàn tách biệt với `store.cases`/IndexedDB chính của app: cứ 800ms
sau khi người dùng gõ bất kỳ đâu, nó gom **toàn bộ** input/select/textarea
đang hiển thị trên trang (dựa theo `id`/`name`) thành 1 "snapshot" chung,
không hề gắn với hồ sơ (case) nào.

**Vấn đề:** ID của field trong app có dạng cố định `'f-' + key` (VD
`f-ten_khach_hang`) — **giống hệt nhau ở mọi hồ sơ**, không đổi theo
khách hàng. Khi mở một hồ sơ MỚI (trống), nếu `offerRestore()` thấy form
trống và có snapshot < 7 ngày tuổi, nó sẽ bật hộp thoại "Khôi phục phiên
trước?" — nếu người dùng bấm OK (tưởng là tiếp tục hồ sơ của chính mình),
**toàn bộ tên khách hàng, số CCCD, số tiền vay... của hồ sơ TRƯỚC ĐÓ
(có thể là khách hàng hoàn toàn khác) sẽ bị điền nhầm vào hồ sơ đang mở**.
Đây là rủi ro sai lệch dữ liệu nghiêm trọng với một hệ thống tín dụng
ngân hàng.

**Đã sửa** trong `autosave.js`:
- `collect()` giờ gắn thêm `caseId: window.currentCaseId` vào mỗi snapshot.
- `offerRestore()` chỉ xét các snapshot **cùng `caseId`** với hồ sơ đang
  mở; snapshot của hồ sơ khác (hoặc snapshot cũ trước bản vá, không có
  `caseId`) sẽ bị bỏ qua hoàn toàn, không bao giờ được chào khôi phục
  nhầm nữa.
- Vì `window.currentCaseId` thường vẫn là `null` lúc trang vừa tải (chưa
  mở hồ sơ nào) nên đã thêm móc vào `renderWizard()` (wrap an toàn, luôn
  gọi lại bản gốc) để tự kiểm tra lại mỗi khi người dùng vừa mở 1 hồ sơ —
  chỉ hỏi tối đa 1 lần cho mỗi hồ sơ trong phiên làm việc, tránh hỏi lặp.

**Cách kiểm thử:** Mở hồ sơ A, gõ vài trường, đợi >1s (autosave), đóng.
Mở hồ sơ B (hồ sơ khác, trống) → KHÔNG được thấy hộp thoại chào khôi phục
dữ liệu của hồ sơ A. Mở lại đúng hồ sơ A (nếu form đang trống) → có thể
được chào khôi phục lại đúng dữ liệu của A.

## 2) [Nhỏ — lỗi giao diện] Nút "Sao lưu JSON / Nhập JSON" bị nhân đôi

`hsv-safe-v25.6.0/backup-io.js`, hàm `mountSidebar()` được gọi lại nhiều
lần (ngay khi tải, rồi lại sau 2s và 5s để phòng sidebar mount muộn).
Điều kiện cũ `if (!sb || sb.querySelector('.hsv-sidebar-actions'))` vô
tình coi luôn cả trường hợp "sidebar đã có nút rồi" là phải dùng nhánh
fallback → ở lần gọi lặp lại (2s/5s), sau khi nút đã được gắn đúng vào
sidebar thật ở lần gọi đầu, code vẫn tạo thêm 1 khối nút nổi trùng lặp ở
góc trái dưới màn hình.

**Đã sửa:** tách rõ 3 trường hợp — sidebar có & đã có nút → không làm gì;
sidebar có, chưa có nút → gắn vào sidebar; không có sidebar → mới dùng
fallback (giữ nguyên chống trùng bằng id `hsv-bkp-fallback`).

## 3) Đã xác nhận an toàn (không cần sửa)
- `hsv-safe-v25.6.0/loader.js`: cơ chế nạp động 10 module con
  (`a11y/theme/ios/autosave/backup-io/validate/palette/print/
  template-lazy/pwa`) — đã kiểm tra `document.currentScript`/thứ tự
  Promise tuần tự đều đúng, không phải code chết.
- `validate.js` (kiểm tra logic SĐT/CCCD/ngày tháng/tỷ lệ vay-TSBĐ):
  chỉ cảnh báo (advisory), không ghi đè giá trị field nào → không có rủi
  ro dữ liệu.
- Đã quét toàn bộ `window.renderWizard`/`window.doSetValue` bị ghi đè
  (9 và 7 lần trong `app.js`) — xác nhận 100% đều gọi lại bản trước đúng
  cách (không có kiểu "thay thế hoàn toàn" nguy hiểm).
- `node --check` toàn bộ `.js` trong gói (kể cả sau các sửa ở mục 1—2):
  không có lỗi cú pháp.
