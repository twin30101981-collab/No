/*!
 * seed-dvh.js — Nạp mẫu KH Đặng Văn Hòa (HMTD) vào HSV v25.5.
 * Chỉ seed trường INPUT (không có công thức) — để trống mọi trường app tự tính,
 * phục vụ kiểm định độ chính xác công thức của app.
 *
 * Idempotent: chỉ chèn khi chưa có case cùng id.
 * Bật lại (ghi đè): mở với ?reseed=1
 */
(function () {
  var STORE_KEY = "hosovay-cases-v1";
  var CASE_ID = "dvh-hmtd-sample-2026";
  var MASTER_KEY = "hsv_master_KH";
  /* FIX gốc rễ: trước đây tombstone chặn VĨNH VIỄN sau khi user xoá 1 lần,
     kể cả khi dữ liệu seed sau đó đã được SỬA LẠI HOÀN TOÀN KHÁC (đúng số
     liệu tài sản). Nay gắn phiên bản dữ liệu vào mỗi case được seed —
     tombstone chỉ chặn đúng phiên bản đã bị xoá; nếu seed đã được cập
     nhật sang phiên bản mới, tombstone cũ (của phiên bản cũ) tự động hết
     hiệu lực, seed vẫn được chèn lại bình thường mà KHÔNG cần ?reseed=1. */
  var SEED_VERSION = "2026-corrected-assets-v2";
  window.__hsvSeedDvhVersion = SEED_VERSION;

  function q(name) {
    try { return new URLSearchParams(location.search).get(name); } catch (_) { return null; }
  }

  var CUS_ADDR = "69 Tô Hiệu - Phường Nam Định - Tỉnh Ninh Bình";
  var CUS_CCCD = "036073022571 do Cục cảnh sát QLHC về TTXH cấp ngày 05/07/2021";
  var WIFE_CCCD = "036182016511 do Cục cảnh sát QLHC về TTXH cấp ngày 05/07/2021";

  // === WHITELIST INPUT (không có công thức) ===
  var caseValues = {
    // TT Chung
    "Số hồ sơ HM": "01/2026/HMTD",
    "HĐTD HM": "1105LAV202400945",
    "Ngày HĐTD HM": "06/03/2026",
    "Tên khách hàng HM": "Đặng Văn Hòa",
    "Mã khách hàng HM": "KH_DVH_2026",
    "Người QHKH/QLN HM": "Trần Hữu Thắng",
    "Người TĐ/KS HM": "Trần Hữu Thắng",
    "Người thẩm định HM": "Phạm Xuân Dũng",
    "Người duyệt HM": "Đinh Trọng Hiếu",
    "Chức vụ người duyệt HM": "Giám đốc",
    "Ngày CIC HM": "04/06/2026",
    "Ngày bìa HS HM": "06/03/2026",
    "Ngày giao-nhận HM": "06/03/2026",
    // NOTE: "Ngày tháng năm HM" để trống — app tự điền hôm nay theo mask

    // TT Khách hàng
    "Tên khách hàng vay HM": "Đặng Văn Hòa",
    "Xưng hô HM": "Ông",
    "Nam/nữ HM": "Nam",
    "Loại CMND HM": "CCCD",
    "CMND HM": CUS_CCCD,
    "Năm sinh người vay HM": "15/05/1973",
    "Địa chỉ HM": CUS_ADDR,
    "Địa chỉ theo hộ khẩu HM": CUS_ADDR,
    "Người thừa kế HM": "Phạm Thị Bình",
    "Xưng hô người thừa kế HM": "Bà",
    "Quan hệ người thừa kế HM": "Vợ",
    "Loại CMT người thừa kế HM": "CCCD",
    "CMT người thừa kế HM": WIFE_CCCD,
    "Năm sinh người thừa kế HM": "02/02/1982",
    "Địa chỉ người thừa kế HM": CUS_ADDR,
    "Hộ khẩu người thừa kế HM": CUS_ADDR,
    "Nghề nghiệp HM": "Hộ kinh doanh cá thể",
    "Đăng ký kinh doanh số HM": "07A13.239 do Phòng đăng ký kinh doanh UBND Thành phố Nam Định cấp ngày 20/3/2015",
    "Địa chỉ kinh doanh HM": CUS_ADDR,
    "Số điện thoại HM": "0919918579",

    // TT Hợp đồng vay
    "Bên vay HM": "Ông Đặng Văn Hòa và Bà Phạm Thị Bình",
    "Thể loại vay HM": "Hạn mức tín dụng",
    "Số tiền vay HM": 7500000000,
    "HMTD duyệt HM": 7500000000,
    "Mục đích vay HM": "Kinh doanh dầu gội, kem chống nắng, sữa rửa mặt và các loại hàng mỹ phẩm khác",
    "Mục đích vay cu thể HM": "Kinh doanh dầu gội, kem chống nắng, sữa rửa mặt và các loại hàng mỹ phẩm khác",
    "Lãi suất vay HM": 8.8,
    "Thời hạn vay HM": 12,
    "Phương thức thanh toán HM": "Trả gốc theo báo cáo đề xuất giải ngân kiêm giấy nhận nợ; trả lãi hàng tháng",
    "Thông tin CIC1 HM": "Agribank chi nhánh Thiên Trường Nam Định — dư nợ 7.500.000.000 đồng",
    "Thông tin CIC2 HM": "Cty Tài chính TNHH NH Việt Nam Thịnh Vượng SMBC — dư nợ 1.000.000 đồng",

    // TT Phương Án — chỉ input, KHÔNG seed các trường tổng/tỷ lệ/nhu cầu vốn/lợi nhuận
    "Vòng quay HM": 2,
    "Tiền mặt HM": 100000000,
    "Nợ phải thu HM": 5000000000,
    "Nợ người bán HM": 200000000,
    "Nợ phải trả HM": 7700000000,
    "Số người lao động trực tiếp HM": 2,
    "Số tiền/ 1 nhân công HM": 4000000,
    "Nợ khác 1 HM": 1000000,
    "Ngân hàng NK1 HM": "Cty Tài chính TNHH NH Việt Nam Thịnh Vượng SMBC",
    "Nợ khác 2 HM": 0,
    "Ngân hàng NK2 HM": "",
    "Hàng hóa các loại HM": 5052000000,
    "Thị trường đầu vào HM": "Nhập hàng từ các cửa hàng tư nhân bán buôn lớn, có uy tín chuyên phân phối các sản phẩm làm đẹp tại tỉnh Ninh Bình và các tỉnh lân cận",
    "Thị trường đầu ra HM": "Bán cho các cửa hàng kinh doanh nhỏ và người tiêu dùng trên địa bàn các phường Nam Định, Thiên Trường, Đông A, Thành Nam, Vị Khê, Đồng Quang, Mỹ Lộc...",
    "Về phương diện kỹ thuật HM": "Cửa hàng có mặt bằng ổn định tại 69 Tô Hiệu, kho chứa hàng và trang thiết bị đầy đủ.",
    "Giải quyết việc làm HM": "Tạo việc làm cho 02 lao động thường xuyên với thu nhập bình quân 4.000.000 đồng/người/tháng.",

    // Xếp hạng (input)
    "Chấm điểm1 HM": "A",
    "Chấm điểm2 HM": "A",
    "Xếp hạng HM": "A7"
  };

  // === TSBĐ #1: DN974228 - thửa 168, tờ 6, 154,1 m² tại 31 Tô Hiệu ===
  // (FIX: seed cũ gán nhầm tài sản #1=BG436563 và thiếu các field giá trị
  //  số (Diện tích đất 1/Giá trị đất 1/Diện tích SD/Giá trị m2 nhà/Giá
  //  trị nhà làm tròn số) khiến "Tổng giá trị TS" tính ra 0. Dữ liệu dưới
  //  đây đã đối chiếu lại 100% với "Biên bản xác định lại giá trị TSBĐ"
  //  gốc và kiểm chứng qua app thật: Tổng giá trị TS = 7.712.500.000đ,
  //  khớp tuyệt đối tài liệu.)
  var asset1 = {
    ".ts.Mã khách hàng chủ tài sản HM": "KH_DVH_2026",
    ".ts.Chủ tài sản HM": "Đặng Văn Hòa",
    ".ts.Xưng hô chủ tài sản HM": "Ông",
    ".ts.Loại CMT chủ tài sản HM": "CCCD",
    ".ts.CMT chủ tài sản HM": CUS_CCCD,
    ".ts.Năm sinh chủ tài sản HM": "15/05/1973",
    ".ts.Địa chỉ chủ tài sản HM": CUS_ADDR,
    ".ts.Địa chỉ hộ khẩu chủ tài sản HM": CUS_ADDR,
    ".ts.Người thừa kế chủ tài sản HM": "Phạm Thị Bình",
    ".ts.Xưng hô thừa kế chủ tài sản HM": "Bà",
    ".ts.Quan hệ thừa kế chủ tài sản HM": "Vợ",
    ".ts.Loại CMT thừa kế chủ tài sản HM": "CCCD",
    ".ts.CMT thừa kế chủ tài sản HM": WIFE_CCCD,
    ".ts.Năm sinh thừa kế chủ tài sản HM": "02/02/1982",
    ".ts.Địa chỉ thừa kế chủ tài sản HM": CUS_ADDR,
    ".ts.Hộ khẩu thừa kế chủ tài sản HM": CUS_ADDR,
    ".ts.Bên thế chấp HM": "Ông Đặng Văn Hòa và Bà Phạm Thị Bình",
    ".ts.Tên TSĐB HM": "Quyền sử dụng đất và tài sản gắn liền với đất",
    ".ts.Số bìa đỏ HM": "DN974228 ngày 12/07/2024",
    ".ts.Số thửa HM": "168",
    ".ts.Địa chỉ đất HM": "31, Đường Tô Hiệu, phường Nam Định - Tỉnh Ninh Bình",
    ".ts.Diện tích đất 1 HM": 154.1,
    ".ts.Giá trị đất 1 HM": 50000000,
    ".ts.Loại đất HM": "Đất ở tại đô thị",
    ".ts.Nguồn gốc HM": "Nhận chuyển nhượng đất được công nhận quyền sử dụng đất như giao đất có thu tiền sử dụng đất",
    ".ts.Thời hạn sử dụng HM": "Lâu dài",
    ".ts.Đặc điểm nhà HM": "Nhà gạch",
    ".ts.Kết cấu nhà HM": "Gạch",
    ".ts.Số tầng HM": "1",
    ".ts.Diện tích XD HM": 154.1,
    ".ts.Diện tích SD HM": 15,
    ".ts.Giá trị m2 nhà HM": 500000,
    ".ts.Giá trị nhà làm tròn số HM": 7500000,
    ".ts.Số HĐTC cũ HM": "DN974228",
    ".ts.Ngày ký HĐTC cũ HM": "05/06/2025",
    ".ts.Số tiêu đề VBSĐ mới HM": "DN974228/VBSĐ1"
  };

  // === TSBĐ #2: BG436563 - thửa 193, tờ 6, 53,1 m² tại 69 Tô Hiệu ===
  // (Kiểm chứng qua app thật: Tổng giá trị TS = 4.075.500.000đ, khớp
  //  tuyệt đối tài liệu gốc.)
  var asset2 = {
    ".ts.Mã khách hàng chủ tài sản HM": "KH_DVH_2026",
    ".ts.Chủ tài sản HM": "Đặng Văn Hòa",
    ".ts.Xưng hô chủ tài sản HM": "Ông",
    ".ts.Loại CMT chủ tài sản HM": "CCCD",
    ".ts.CMT chủ tài sản HM": CUS_CCCD,
    ".ts.Năm sinh chủ tài sản HM": "15/05/1973",
    ".ts.Địa chỉ chủ tài sản HM": CUS_ADDR,
    ".ts.Địa chỉ hộ khẩu chủ tài sản HM": CUS_ADDR,
    ".ts.Người thừa kế chủ tài sản HM": "Phạm Thị Bình",
    ".ts.Xưng hô thừa kế chủ tài sản HM": "Bà",
    ".ts.Quan hệ thừa kế chủ tài sản HM": "Vợ",
    ".ts.Loại CMT thừa kế chủ tài sản HM": "CCCD",
    ".ts.CMT thừa kế chủ tài sản HM": WIFE_CCCD,
    ".ts.Năm sinh thừa kế chủ tài sản HM": "02/02/1982",
    ".ts.Địa chỉ thừa kế chủ tài sản HM": CUS_ADDR,
    ".ts.Hộ khẩu thừa kế chủ tài sản HM": CUS_ADDR,
    ".ts.Bên thế chấp HM": "Ông Đặng Văn Hòa và Bà Phạm Thị Bình",
    ".ts.Tên TSĐB HM": "Quyền sử dụng đất và tài sản gắn liền với đất",
    ".ts.Số bìa đỏ HM": "BG436563",
    ".ts.Số thửa HM": "193",
    ".ts.Địa chỉ đất HM": "69 - Tổ 12 - Tô Hiệu - Phường Nam Định - Tỉnh Ninh Bình",
    ".ts.Diện tích đất 1 HM": 53.1,
    ".ts.Giá trị đất 1 HM": 55000000,
    ".ts.Loại đất HM": "Đất ở tại đô thị",
    ".ts.Nguồn gốc HM": "Nhà nước công nhận quyền sử dụng đất",
    ".ts.Thời hạn sử dụng HM": "Lâu dài",
    ".ts.Đặc điểm nhà HM": "Nhà bê tông 4 tầng",
    ".ts.Kết cấu nhà HM": "Bê tông",
    ".ts.Số tầng HM": "4",
    ".ts.Diện tích XD HM": 53.1,
    ".ts.Diện tích SD HM": 210,
    ".ts.Giá trị m2 nhà HM": 5500000,
    ".ts.Giá trị nhà làm tròn số HM": 1155000000,
    ".ts.Số HĐTC cũ HM": "BG436563",
    ".ts.Ngày ký HĐTC cũ HM": "08/06/2023",
    ".ts.Số tiêu đề VBSĐ mới HM": "BG436563/VBSĐ1"
  };

  function makeCase() {
    var now = Date.now();
    return {
      id: CASE_ID,
      product: "HMTD",
      productLabel: "Hạn Mức Tín Dụng",
      customerName: "Đặng Văn Hòa",
      customerCode: "KH_DVH_2026",
      values: caseValues,
      assets: [
        { id: "asset-dvh-1", values: asset1 },
        { id: "asset-dvh-2", values: asset2 }
      ],
      activeAsset: 0,
      createdAt: now,
      updatedAt: now,
      __seededBy: "seed-dvh.js",
      __seedVersion: SEED_VERSION
    };
  }

  function seed() {
    var reseed = q("reseed") === "1";
    var raw;
    try { raw = localStorage.getItem(STORE_KEY); } catch (_) {}
    var cases = {};
    try { cases = raw ? JSON.parse(raw) : {}; } catch (_) { cases = {}; }

    // Tombstone: user đã chủ động xoá KH seed → không tự nạp lại.
    // NHƯNG: chỉ chặn nếu tombstone ghi ĐÚNG phiên bản dữ liệu hiện tại.
    // Nếu seed đã được sửa sang phiên bản mới, tombstone của phiên bản cũ
    // tự động hết hiệu lực (không cần ?reseed=1).
    var TOMB_KEY = "hsv_seed_dvh_deleted";
    var tomb = null;
    try {
      var tombRaw = localStorage.getItem(TOMB_KEY);
      tomb = tombRaw ? JSON.parse(tombRaw) : null;
    } catch (_) { tomb = null; }
    if (reseed) { try { localStorage.removeItem(TOMB_KEY); } catch(_){} tomb = null; }
    var tombBlocksThisVersion = tomb && tomb.version === SEED_VERSION;
    if (tombBlocksThisVersion && !reseed) {
      console.log("[seed-dvh] Phiên bản dữ liệu hiện tại (" + SEED_VERSION + ") đã bị user xoá trước đó. Dùng ?reseed=1 để nạp lại.");
      return;
    }
    if (tomb && !tombBlocksThisVersion) {
      console.log("[seed-dvh] Có tombstone nhưng thuộc phiên bản cũ (" + tomb.version + ") — phiên bản mới (" + SEED_VERSION + ") vẫn được nạp.");
    }
    if (cases[CASE_ID] && !reseed) {
      // Case đã tồn tại — chỉ bỏ qua nếu ĐÚNG phiên bản hiện tại; nếu là
      // bản cũ hơn (chưa có __seedVersion hoặc khác SEED_VERSION) thì
      // ghi đè bằng bản mới đã sửa đúng.
      if (cases[CASE_ID].__seedVersion === SEED_VERSION) {
        console.log("[seed-dvh] case đã tồn tại đúng phiên bản mới nhất, bỏ qua.");
        return;
      }
      console.log("[seed-dvh] case cũ (phiên bản khác) được thay bằng bản đã sửa mới nhất.");
    }
    cases[CASE_ID] = makeCase();
    try { localStorage.setItem(STORE_KEY, JSON.stringify(cases)); } catch (e) { console.error("[seed-dvh] lỗi ghi", e); return; }

    // Seed master KH (chỉ input, đồng bộ danh bạ)
    try {
      var masterRaw = localStorage.getItem(MASTER_KEY);
      var master = masterRaw ? JSON.parse(masterRaw) : {};
      if (!master || typeof master !== "object") master = {};
      master["KH_DVH_2026"] = {
        code: "KH_DVH_2026",
        name: "Đặng Văn Hòa",
        gender: "Nam",
        dob: "15/05/1973",
        cccd: CUS_CCCD,
        address: CUS_ADDR,
        phone: "0919918579",
        spouse: {
          name: "Phạm Thị Bình",
          dob: "02/02/1982",
          cccd: WIFE_CCCD
        }
      };
      localStorage.setItem(MASTER_KEY, JSON.stringify(master));
    } catch (e) { console.warn("[seed-dvh] master KH ghi lỗi", e); }

    console.log("[seed-dvh] đã nạp mẫu KH Đặng Văn Hòa (case id=" + CASE_ID + "). Chỉ trường INPUT — mọi công thức để app tự tính.");
  }

  // HSV-FIX 2026-07-12c: HSVStorageV2 (IDB engine) nạp cache bất đồng bộ SAU khi
  // script này chạy. Nếu seed đọc localStorage lúc cache chưa sẵn sàng thì
  // tombstone và case cũ đều không thấy được → seed sai lầm re-insert. Chờ ready.
  function runSeed(){
    try { seed(); } catch (e) { console.error('[seed-dvh] seed lỗi:', e); }
  }
  function afterAppReady(){
    // Chờ store trong bộ nhớ của app cũng đã init để mutate cho hiển thị ngay.
    var tries = 0;
    (function tick(){
      if (window.store && window.store.cases){ runSeedAndSync(); return; }
      if (++tries > 100) { runSeed(); return; }
      setTimeout(tick, 30);
    })();
  }
  function runSeedAndSync(){
    try {
      // Kiểm tra tombstone lần cuối trên storage đã hydrate xong (IDB thật).
      // FIX gốc rễ: tombstone chỉ chặn nếu khớp ĐÚNG phiên bản dữ liệu đã bị
      // xoá — tombstone của phiên bản cũ/lỗi không chặn phiên bản mới đã sửa.
      var tomb = null;
      try {
        var tombRaw = localStorage.getItem("hsv_seed_dvh_deleted");
        tomb = tombRaw ? JSON.parse(tombRaw) : null;
      } catch(_) { tomb = null; }
      var reseed = q("reseed") === "1";
      if (reseed) { try { localStorage.removeItem("hsv_seed_dvh_deleted"); } catch(_){} tomb=null; }
      var tombBlocksThisVersion = tomb && typeof tomb === "object" && tomb.version === SEED_VERSION;
      if (tombBlocksThisVersion && !reseed){
        console.log("[seed-dvh] Phiên bản dữ liệu hiện tại (" + SEED_VERSION + ") đã bị user xoá trước đó. Dùng ?reseed=1 để nạp lại.");
        return;
      }
      // Nếu case đã có trong storage thật (không phải bộ nhớ có thể đang
      // đua/race) VÀ đúng phiên bản hiện tại thì bỏ qua.
      var existingRaw = null;
      try { existingRaw = localStorage.getItem(STORE_KEY); } catch(_){}
      var existingCases = existingRaw ? (function(){ try { return JSON.parse(existingRaw); } catch(_){ return {}; } })() : {};
      var existing = existingCases[CASE_ID];
      if (existing && existing.__seedVersion === SEED_VERSION && !reseed){
        // QUAN TRỌNG: đồng bộ TOÀN BỘ existingCases (không chỉ riêng DVH)
        // vào bộ nhớ, vì window.store.cases có thể đang rỗng/cũ do
        // race-condition lúc khởi động (đã kiểm chứng bằng Playwright) —
        // trước đây chỉ vá đúng 1 field DVH khiến mọi hồ sơ thật khác bị
        // "biến mất" khỏi giao diện dù vẫn còn nguyên trong storage.
        var curKeys = Object.keys(window.store.cases || {});
        if (curKeys.length < Object.keys(existingCases).length) {
          window.store.cases = existingCases;
        }
        return;
      }
      /* FIX gốc rễ QUAN TRỌNG NHẤT (lỗi mất dữ liệu thật):
         Trước đây code gọi window.persistStore() (lưu window.store.cases
         hiện có trong BỘ NHỚ) TRƯỚC bước đọc-gộp-ghi an toàn vào
         localStorage. Nếu tại thời điểm này window.store.cases trong bộ
         nhớ CHƯA kịp nạp xong dữ liệu thật (race-condition xảy ra bất kể
         lần tải đầu hay các lần sau, đã kiểm chứng bằng Playwright),
         persistStore() sẽ GHI ĐÈ, XOÁ MẤT toàn bộ hồ sơ thật đã lưu
         trong localStorage bằng một bộ nhớ gần như rỗng!
         Sửa: KHÔNG BAO GIỜ gọi persistStore() dựa trên bộ nhớ có thể
         đang đua. Luôn dùng localStorage (đọc lại NGAY LÚC NÀY) làm
         nguồn xác thực duy nhất để gộp, rồi mới đồng bộ ngược lại bộ nhớ
         bằng đúng kết quả đã gộp an toàn đó. */
      var c = makeCase();
      var mergedCases = Object.assign({}, existingCases);
      mergedCases[CASE_ID] = c;
      try { localStorage.setItem(STORE_KEY, JSON.stringify(mergedCases)); } catch(_){}
      // Đồng bộ bộ nhớ = ĐÚNG bằng kết quả đã gộp an toàn (không phải chỉ
      // thêm DVH vào bộ nhớ hiện có, vì bộ nhớ đó có thể đang thiếu dữ
      // liệu thật do race-condition).
      window.store.cases = mergedCases;
      try {
        var masterRaw = localStorage.getItem(MASTER_KEY);
        var master = masterRaw ? JSON.parse(masterRaw) : {};
        if (!master || typeof master !== "object") master = {};
        master["KH_DVH_2026"] = {
          code: "KH_DVH_2026", name: "Đặng Văn Hòa", gender: "Nam",
          dob: "15/05/1973", cccd: CUS_CCCD, address: CUS_ADDR, phone: "0919918579",
          spouse: { name: "Phạm Thị Bình", dob: "02/02/1982", cccd: WIFE_CCCD }
        };
        localStorage.setItem(MASTER_KEY, JSON.stringify(master));
      } catch(_){}
      try {
        if (typeof window.renderCaseList === "function") window.renderCaseList();
        else if (typeof window.renderHome === "function") window.renderHome();
        else if (typeof window.navigate === "function" && location.hash === "") window.navigate("home");
      } catch(_){}
      console.log("[seed-dvh] đã nạp mẫu KH Đặng Văn Hòa vào store (case id="+CASE_ID+").");
    } catch (e) { console.error('[seed-dvh] seed lỗi:', e); }
  }
  function scheduleSeed(){
  // HSV-FIX gốc rễ (thay thế v9): trước đây scheduleSeed() CHẶN TUYỆT ĐỐI
  // việc tự seed trừ khi có ?reseed=1 — kể cả lần đầu mở file, store hoàn
  // toàn trống. Điều này khiến seed() không bao giờ có cơ hội chạy, và
  // cơ chế tombstone-theo-phiên-bản (SEED_VERSION) bên trong seed() trở
  // nên vô nghĩa vì bị chặn từ trước khi tới lượt kiểm tra.
  // Nay để seed() tự quyết định (đã có đủ logic: bỏ qua nếu case đã tồn
  // tại ĐÚNG phiên bản hiện tại, bỏ qua nếu tombstone khớp đúng phiên bản
  // đã bị user xoá — nhưng KHÔNG chặn nếu là phiên bản mới hơn/dữ liệu
  // trống). ?reseed=1 vẫn hoạt động như trước: buộc nạp lại bất kể gì.
  if (q("reseed") === "1") {
    console.log("[seed-dvh] ?reseed=1 — buộc nạp lại mẫu Đặng Văn Hòa.");
  }

    // seed-dvh.js load TRƯỚC app.js — HSVStorageV2 chưa tồn tại tại thời điểm này.
    // Poll cho tới khi HSVStorageV2 xuất hiện và ready, rồi chờ store của app.
    var tries = 0;
    (function waitV2(){
      var v2 = window.HSVStorageV2;
      if (v2 && typeof v2.isReady === "function" && v2.isReady()) { afterAppReady(); return; }
      if (v2 && v2.ready && typeof v2.ready.then === "function"){
        v2.ready.then(afterAppReady, afterAppReady); return;
      }
      if (++tries > 200) { afterAppReady(); return; } // ~6s hết đợi
      setTimeout(waitV2, 30);
    })();
  }
  scheduleSeed();
})();
