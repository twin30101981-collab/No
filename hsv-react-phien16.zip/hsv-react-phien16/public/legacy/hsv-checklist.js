/**
 * HSV Phần 8 — Tính năng bổ sung
 * 8.1 Bảng đối chiếu localStorage ↔ IndexedDB
 * 8.2 Badge % hoàn thành trên danh sách hồ sơ
 * 8.3 Lịch sử sửa công thức (metadata)
 * 8.4 Checklist trước khi xuất hồ sơ theo nhóm
 * 8.5 Điều hướng nhanh tới trường còn thiếu
 * CỘNG THÊM — không sửa FIELD_META, không đổi F[product].
 * Ngày: 2026-07-28 · HSV-UPGRADE-FEAT8
 */
(function(global) {
  'use strict';

  /* ══════════════════════════════════════════════════════════════
   * 8.1 — Panel đối chiếu localStorage ↔ IndexedDB
   * ══════════════════════════════════════════════════════════════ */
  function renderStorageComparePanel() {
    if (!global.hsvStorageBridge) return;
    var report = global.hsvStorageBridge.getDiffReport();
    if (report.length === 0) {
      return '<div class="hsv-feat8-empty">✅ Không phát hiện lệch dữ liệu giữa localStorage và IndexedDB.</div>';
    }
    var rows = report.map(function(d) {
      var ts = new Date(d.ts).toLocaleTimeString('vi-VN');
      return '<tr>' +
        '<td style="font-family:monospace;font-size:12px">' + escHtml(d.key) + '</td>' +
        '<td>' + escHtml(String(d.lsValue).substring(0,30)) + '</td>' +
        '<td>' + escHtml(String(d.idbValue).substring(0,30)) + '</td>' +
        '<td style="font-size:11px;color:var(--muted-fg)">' + ts + '</td>' +
        '</tr>';
    }).join('');
    return '<div class="hsv-feat8-diff-panel">' +
      '<h4 style="margin:0 0 8px;font-size:13px;color:var(--destructive)">⚠ Lệch dữ liệu: ' + report.length + ' trường</h4>' +
      '<table style="width:100%;font-size:12px;border-collapse:collapse">' +
      '<thead><tr><th style="text-align:left;padding:4px 8px;background:var(--secondary)">Trường</th>' +
      '<th style="text-align:left;padding:4px 8px;background:var(--secondary)">localStorage</th>' +
      '<th style="text-align:left;padding:4px 8px;background:var(--secondary)">IndexedDB</th>' +
      '<th style="text-align:left;padding:4px 8px;background:var(--secondary)">Thời gian</th></tr></thead>' +
      '<tbody>' + rows + '</tbody></table>' +
      '<button onclick="hsvFeat8.syncStorage()" style="margin-top:8px;padding:4px 10px;font-size:12px;cursor:pointer;' +
      'background:var(--primary);color:#fff;border:none;border-radius:4px">Đồng bộ LS → IDB</button>' +
      '</div>';
  }

  /* ══════════════════════════════════════════════════════════════
   * 8.2 — Badge % hoàn thành
   * Đếm placeholder rỗng theo FIELD_META của sản phẩm
   * ══════════════════════════════════════════════════════════════ */
  function calcCompletionPct(caseObj) {
    if (!caseObj || !caseObj.product) return { pct: 0, filled: 0, total: 0 };
    var fields = [];
    if (typeof global.getAllFieldsByProduct === 'function') {
      fields = global.getAllFieldsByProduct(caseObj.product) || [];
    } else if (typeof global.FIELD_META !== 'undefined') {
      var meta = global.FIELD_META[caseObj.product] || {};
      Object.keys(meta).forEach(function(sec) {
        var section = meta[sec];
        if (Array.isArray(section)) {
          fields = fields.concat(section);
        } else if (typeof section === 'object') {
          Object.keys(section).forEach(function(grp) {
            if (Array.isArray(section[grp])) fields = fields.concat(section[grp]);
          });
        }
      });
    }
    if (fields.length === 0) return { pct: 0, filled: 0, total: 0 };
    var data = caseObj.data || caseObj.fields || {};
    var filled = fields.filter(function(f) {
      var v = data[f.key] || data[f.placeholder] || '';
      return v && String(v).trim().length > 0 && !String(v).includes('{{');
    }).length;
    return {
      pct: Math.round(filled / fields.length * 100),
      filled: filled,
      total: fields.length
    };
  }

  function getBadgeColor(pct) {
    if (pct >= 80) return 'var(--success, #00753C)';
    if (pct >= 40) return 'var(--warning, #D8A31A)';
    return 'var(--destructive, #C0392B)';
  }

  function renderCompletionBadge(caseObj) {
    var result = calcCompletionPct(caseObj);
    var color = getBadgeColor(result.pct);
    return '<span class="hsv-feat8-badge" style="' +
      'display:inline-flex;align-items:center;gap:4px;' +
      'padding:2px 7px;border-radius:10px;font-size:11px;font-weight:600;' +
      'background:' + color + '20;color:' + color + '">' +
      result.pct + '% (' + result.filled + '/' + result.total + ')</span>';
  }

  /* Inject badge vào danh sách hồ sơ nếu đang hiển thị */
  function injectCompletionBadges() {
    if (!global.store || !global.store.cases) return;
    var rows = document.querySelectorAll('[data-case-id]');
    rows.forEach(function(row) {
      var cid = row.getAttribute('data-case-id');
      if (!cid) return;
      var c = global.store.cases[cid];
      if (!c) return;
      var existing = row.querySelector('.hsv-feat8-badge');
      if (existing) return; // đã có rồi
      var badgeHtml = renderCompletionBadge(c);
      var target = row.querySelector('.case-status, .case-meta, td:last-child');
      if (target) {
        target.insertAdjacentHTML('beforeend', ' ' + badgeHtml);
      }
    });
  }

  /* ══════════════════════════════════════════════════════════════
   * 8.4 — Checklist trước khi xuất hồ sơ
   * ══════════════════════════════════════════════════════════════ */
  function buildExportChecklist(caseId) {
    if (!global.store || !global.store.cases) return null;
    var c = global.store.cases[caseId];
    if (!c) return null;

    var fields = [];
    if (typeof global.getAllFieldsByProduct === 'function') {
      fields = global.getAllFieldsByProduct(c.product) || [];
    }

    if (fields.length === 0) return null;

    var data = c.data || c.fields || {};

    // Nhóm các trường theo group
    var groups = {};
    fields.forEach(function(f) {
      var gk = f.groupKey || f.group || f.sectionLabel || 'Khác';
      if (!groups[gk]) groups[gk] = { fields: [], filled: 0, total: 0 };
      groups[gk].fields.push(f);
      groups[gk].total++;
      var v = data[f.key] || data[f.placeholder] || '';
      if (v && String(v).trim().length > 0 && !String(v).includes('{{')) {
        groups[gk].filled++;
      }
    });

    var items = Object.keys(groups).map(function(gk) {
      var g = groups[gk];
      var pct = Math.round(g.filled / g.total * 100);
      var status = g.filled === g.total ? '✅' : g.filled > 0 ? '⚠' : '❌';
      var color = g.filled === g.total ? 'var(--success)' : g.filled > 0 ? 'var(--warning)' : 'var(--destructive)';
      var missingCount = g.total - g.filled;
      return {
        groupKey: gk,
        status: status,
        color: color,
        label: gk,
        filled: g.filled,
        total: g.total,
        pct: pct,
        missingCount: missingCount,
        allDone: g.filled === g.total
      };
    });

    return items;
  }

  function renderExportChecklist(caseId) {
    var items = buildExportChecklist(caseId);
    if (!items) return '';

    var allDone = items.every(function(i) { return i.allDone; });
    var html = '<div id="hsv-feat8-checklist" style="' +
      'border:1px solid var(--border);border-radius:var(--radius-md);' +
      'background:var(--card);margin-bottom:16px;overflow:hidden">' +
      '<div style="padding:12px 16px;background:var(--secondary);border-bottom:1px solid var(--border);' +
      'display:flex;align-items:center;justify-content:space-between">' +
      '<strong style="font-size:13px">📋 Checklist trước khi xuất</strong>' +
      (allDone ? '<span style="color:var(--success);font-size:12px">✅ Hồ sơ đầy đủ</span>' :
                 '<span style="color:var(--destructive);font-size:12px">⚠ Còn trường thiếu</span>') +
      '</div>';

    items.forEach(function(item) {
      html += '<div style="padding:10px 16px;border-bottom:1px solid var(--border);' +
        'display:flex;align-items:center;justify-content:space-between">' +
        '<div style="display:flex;align-items:center;gap:8px">' +
        '<span style="font-size:15px">' + item.status + '</span>' +
        '<span style="font-size:13px">' + escHtml(item.label) + '</span>' +
        (item.missingCount > 0 ? '<span style="font-size:11px;color:' + item.color + '">' +
          'thiếu ' + item.missingCount + '/' + item.total + '</span>' : '') +
        '</div>' +
        '<div style="display:flex;align-items:center;gap:8px">' +
        '<span style="font-size:11px;color:var(--muted-fg)">' + item.filled + '/' + item.total + '</span>' +
        (!item.allDone ? '<button onclick="hsvFeat8.jumpToMissingField(' + escHtml(JSON.stringify(caseId)) + ',' + escHtml(JSON.stringify(item.groupKey)) + ')" ' +
          'style="padding:2px 8px;font-size:11px;cursor:pointer;border:1px solid var(--border);' +
          'border-radius:4px;background:transparent">Đi tới</button>' : '') +
        '</div>' +
        '</div>';
    });

    html += '</div>';
    return html;
  }

  /* ══════════════════════════════════════════════════════════════
   * 8.5 — Nhảy tới trường còn thiếu
   * ══════════════════════════════════════════════════════════════ */
  function jumpToMissingField(caseId, groupKey) {
    if (!global.store || !global.store.cases) return;
    var c = global.store.cases[caseId];
    if (!c) return;

    var fields = [];
    if (typeof global.getAllFieldsByProduct === 'function') {
      fields = global.getAllFieldsByProduct(c.product) || [];
    }

    var data = c.data || c.fields || {};
    var missing = fields.find(function(f) {
      if ((f.groupKey || f.group || f.sectionLabel || 'Khác') !== groupKey) return false;
      var v = data[f.key] || data[f.placeholder] || '';
      return !v || String(v).trim().length === 0 || String(v).includes('{{');
    });

    if (!missing) return;

    // Tìm element trên DOM
    var id = 'f-' + (missing.key || '').replace(/[^a-zA-Z0-9]/g, '_');
    var el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.focus();
      el.style.outline = '2px solid var(--primary)';
      setTimeout(function() { el.style.outline = ''; }, 2000);
    } else {
      // Điều hướng về nhóm chứa trường
      if (typeof global.navigate === 'function') {
        global.navigate('wizard', caseId);
      }
      setTimeout(function() {
        var el2 = document.getElementById(id);
        if (el2) { el2.scrollIntoView({ behavior: 'smooth', block: 'center' }); el2.focus(); }
      }, 300);
    }
  }

  /* ══════════════════════════════════════════════════════════════
   * Tiện ích
   * ══════════════════════════════════════════════════════════════ */
  function escHtml(str) {
    return String(str)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;');
  }

  /* ── Inject checklist vào trang xuất hồ sơ nếu đang hiển thị ── */
  function tryInjectChecklist() {
    var exportPage = document.querySelector('[data-page="export"], #export-page, .export-page');
    if (!exportPage) return;
    var existing = document.getElementById('hsv-feat8-checklist');
    if (existing) return;
    var cid = exportPage.getAttribute('data-case-id') ||
      (global.wizardState && global.wizardState.caseId);
    if (!cid) return;
    var checklist = renderExportChecklist(cid);
    if (checklist) {
      exportPage.insertAdjacentHTML('afterbegin', checklist);
    }
  }

  /* ── MutationObserver: tự inject khi DOM thay đổi ── */
  var _observer = new MutationObserver(function() {
    tryInjectChecklist();
    injectCompletionBadges();
  });
  _observer.observe(document.body || document.documentElement, {
    childList: true,
    subtree: true
  });

  /* ── Expose public API ── */
  global.hsvFeat8 = {
    version:              'FEAT8-2026-07-28',
    renderStorageCompare: renderStorageComparePanel,
    calcCompletion:       calcCompletionPct,
    renderBadge:          renderCompletionBadge,
    renderChecklist:      renderExportChecklist,
    jumpToMissingField:   jumpToMissingField,
    syncStorage: function() {
      if (global.hsvStorageBridge) {
        global.hsvStorageBridge.syncLsToIdb()
          .then(function(n) { alert('Đã đồng bộ ' + n + ' keys từ localStorage sang IndexedDB.'); });
      }
    },
    injectBadges:         injectCompletionBadges
  };

  // Chạy ngay lần đầu sau DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      setTimeout(injectCompletionBadges, 500);
      setTimeout(tryInjectChecklist, 500);
    });
  } else {
    setTimeout(injectCompletionBadges, 500);
    setTimeout(tryInjectChecklist, 500);
  }

})(window);
