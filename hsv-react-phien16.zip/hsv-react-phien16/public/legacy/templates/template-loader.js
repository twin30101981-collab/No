/* ════════════════════════════════════════════════════════════════
   template-loader.js — Compatibility layer for template access
   Works with file:// protocol (templates-data.js sets window.TEMPLATES_B64)
   ════════════════════════════════════════════════════════════════ */
(function (global) {
  'use strict';
  if (global.__hsvTemplateLoader) return;
  global.__hsvTemplateLoader = true;

  // templates-data.js (loaded via <script> tag) populates window.TEMPLATES_B64
  // This layer provides a clean API on top of it

  function getBase64(path) {
    var b64 = global.TEMPLATES_B64 && global.TEMPLATES_B64[path];
    if (!b64) {
      // Try partial match
      var keys = Object.keys(global.TEMPLATES_B64 || {});
      for (var i = 0; i < keys.length; i++) {
        if (keys[i].indexOf(path) >= 0 || path.indexOf(keys[i]) >= 0) {
          b64 = global.TEMPLATES_B64[keys[i]];
          break;
        }
      }
    }
    if (!b64) return Promise.reject(new Error('Template not found: ' + path));
    return Promise.resolve(b64);
  }

  function getCached(path) {
    return (global.TEMPLATES_B64 && global.TEMPLATES_B64[path]) || null;
  }

  function list() {
    return Object.keys(global.TEMPLATES_B64 || {});
  }

  global.HSVTemplates = {
    getBase64: getBase64,
    getCached: getCached,
    list: list
  };

  // Wait for templates-data.js to load, then log
  function checkReady() {
    if (global.TEMPLATES_B64) {
      console.log('[template-loader] Ready — ' + Object.keys(global.TEMPLATES_B64).length + ' templates available');
    } else {
      setTimeout(checkReady, 100);
    }
  }
  checkReady();
})(window);
