/* ------------------------------------------------------------------ *
 * hsv-cp-vattu-detail-v1.js                                           *
 * Phiên 1 — #35: Bảng chi tiết Chi phí vật tư (14 dòng), product HMTD *
 *                                                                      *
 * Phạm vi CHỈ giới hạn trong: thêm 14 field mới trong FIELD_META      *
 * (đã thêm trực tiếp trong app.js, group "chi_tiet_cp_vat_tu") + nút  *
 * "Tính tổng → CP vật tư" để CỘNG DỒN 14 dòng vào field "CP vật tư    *
 * HM" đã có sẵn — dùng lại đúng hàm window.doSetValue() toàn cục mà   *
 * mọi input khác trong app đang dùng, KHÔNG tạo cơ chế đồng bộ mới,   *
 * KHÔNG tự động ghi đè khi người dùng chưa bấm nút (tránh phá vỡ      *
 * luồng đồng bộ hiện có từ bảng PA SXKD → CP vật tư HM).               *
 * Không đụng đến công thức Tổng CP dự án / Lợi nhuận hiện có.         *
 * ------------------------------------------------------------------ */
(function () {
  "use strict";

  var DETAIL_KEYS = [];
  for (var i = 1; i <= 14; i++) DETAIL_KEYS.push("Chi phí vật tư " + i + " HM");
  var TARGET_KEY = "CP vật tư HM";

  function fieldDomId(key) {
    return "f-" + key.replace(/[^a-zA-Z0-9]/g, "_");
  }

  function parseMoney(v) {
    if (v == null) return 0;
    var s = String(v).replace(/[^\d\-]/g, "");
    var n = parseInt(s, 10);
    return isNaN(n) ? 0 : n;
  }

  function formatMoney(n) {
    return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  }

  function sumDetailRows() {
    var total = 0;
    var found = 0;
    DETAIL_KEYS.forEach(function (k) {
      var el = document.getElementById(fieldDomId(k));
      if (el) { found++; total += parseMoney(el.value); }
    });
    return { total: total, found: found };
  }

  function applyTotal() {
    var r = sumDetailRows();
    if (r.found === 0) {
      alert("Chưa thấy 14 trường Chi phí vật tư trên màn hình — hãy mở đúng nhóm \"Chi tiết Chi phí vật tư (14 dòng)\" trước.");
      return;
    }
    var caseId = window.currentCaseId;
    if (!caseId || typeof window.doSetValue !== "function") {
      alert("Không tìm thấy hồ sơ đang mở — không thể ghi vào CP vật tư.");
      return;
    }
    // Ghi qua đúng hàm doSetValue toàn cục (giống mọi input khác trong app),
    // không tạo pipeline đồng bộ song song mới.
    window.doSetValue(caseId, TARGET_KEY, String(r.total));
    var targetEl = document.getElementById(fieldDomId(TARGET_KEY));
    if (targetEl) {
      targetEl.value = String(r.total);
      if (typeof window.doUpdateMoneyHint === "function") {
        window.doUpdateMoneyHint(targetEl, caseId, TARGET_KEY);
      }
    }
    var btn = document.getElementById("cpVatTuDetailSumBtn");
    if (btn) {
      var old = btn.textContent;
      btn.textContent = "✔ Đã cộng " + formatMoney(r.total) + " đ vào CP vật tư";
      setTimeout(function () { btn.textContent = old; }, 2500);
    }
  }

  function injectButtonIfNeeded() {
    if (document.getElementById("cpVatTuDetailSumBtn")) return;
    var lastRowKey = DETAIL_KEYS[DETAIL_KEYS.length - 1];
    var lastEl = document.getElementById(fieldDomId(lastRowKey));
    if (!lastEl) return;
    var row = lastEl.closest(".field-row");
    if (!row || !row.parentNode) return;
    var wrap = document.createElement("div");
    wrap.className = "field-row";
    wrap.style.cssText = "margin-top:4px;";
    wrap.innerHTML =
      '<div></div><div>' +
      '<button type="button" id="cpVatTuDetailSumBtn" class="btn btn-outline" ' +
      'style="font-size:12px;padding:6px 10px;">Σ Tính tổng 14 dòng → CP vật tư</button> ' +
      '<span style="color:#666;font-size:12px;margin-left:6px;">Cộng dồn 14 dòng phía trên, ghi vào trường "CP vật tư" hiện có (không tự động — bấm khi cần).</span>' +
      '</div>';
    row.parentNode.insertBefore(wrap, row.nextSibling);
    document.getElementById("cpVatTuDetailSumBtn").addEventListener("click", applyTotal);
  }

  // Nhóm field mới chỉ xuất hiện khi wizard render đúng group — dùng
  // MutationObserver nhẹ, không hook vào doSetValue/render pipeline hiện có.
  var mo = new MutationObserver(function () { injectButtonIfNeeded(); });
  function start() {
    injectButtonIfNeeded();
    mo.observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }

  window.__hsvCpVatTuDetail = { sumDetailRows: sumDetailRows, applyTotal: applyTotal, DETAIL_KEYS: DETAIL_KEYS };
})();
