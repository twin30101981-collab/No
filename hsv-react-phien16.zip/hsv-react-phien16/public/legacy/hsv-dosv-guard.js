/**
 * HSV J3 — Vá cờ canh doSetValue & bọc console.log production
 * CỘNG THÊM — nạp SAU app.js và toàn bộ file vá hiện có.
 * Không đổi tên hàm/biến/class hiện có.
 * Ngày: 2026-07-28 · HSV-UPGRADE-J3
 */
(function() {
  'use strict';

  /* ─────────────────────────────────────────────────────────────────
   * PHẦN 1: Vá cờ canh thiếu cho doSetValue (dòng ~27818 trong app.js)
   * Dòng đó gán window.doSetValue KHÔNG có cờ canh → nếu script chạy lại
   * sẽ bọc thêm 1 lớp không kiểm soát.
   * Giải pháp: kiểm tra và gắn cờ __hsv19_dset_guard_j3__ ngay bây giờ.
   * ─────────────────────────────────────────────────────────────────
   */
  function installJ3DoSetGuard() {
    if (window.__hsv_j3_guard_installed__) return;
    if (typeof window.doSetValue !== 'function') {
      // Thử lại sau khi DOM ready
      document.addEventListener('DOMContentLoaded', installJ3DoSetGuard, { once: true });
      return;
    }

    // Gắn cờ __hsv19_dset_guard__ nếu chưa có (vá lỗ hổng dòng 27818)
    if (!window.__hsv19_dset_guard__) {
      window.__hsv19_dset_guard__ = true;
      if (typeof window.__HSV_DEBUG__ !== 'undefined' && window.__HSV_DEBUG__) {
        console.log('[HSV-J3] Đã gắn cờ __hsv19_dset_guard__ (vá điểm hở dòng ~27818)');
      }
    }

    // Đảm bảo tất cả các cờ canh đã được đặt (kiểm tra và log nếu thiếu)
    var expectedGuards = [
      '__np5_wrapped__',
      '__v8_wrapped__',
      '__v16_wrap__',
      '__v17_wrap__',
      '__hsv19_dset_guard__',
      '__v20_wrap__'
    ];

    var missingGuards = expectedGuards.filter(function(g) { return !window[g]; });
    if (missingGuards.length > 0) {
      if (typeof window.__HSV_DEBUG__ !== 'undefined' && window.__HSV_DEBUG__) {
        console.warn('[HSV-J3] Cờ canh chưa được đặt:', missingGuards);
      }
      // Chờ thêm 500ms để các bản vá có thể đã chạy xong
      setTimeout(function() {
        missingGuards.forEach(function(g) {
          if (!window[g]) {
            window[g] = true; // gắn cờ mặc định để tránh bọc trùng
            if (typeof window.__HSV_DEBUG__ !== 'undefined' && window.__HSV_DEBUG__) {
              console.log('[HSV-J3] Đã gắn cờ mặc định:', g);
            }
          }
        });
      }, 500);
    }

    window.__hsv_j3_guard_installed__ = true;
    if (typeof window.__HSV_DEBUG__ !== 'undefined' && window.__HSV_DEBUG__) {
      console.log('[HSV-J3] Guard installation complete. Wrap depth measurement ready.');
    }
  }

  /* ─────────────────────────────────────────────────────────────────
   * PHẦN 2: Bọc console.log bằng cờ debug __HSV_DEBUG__
   * Mặc định TẮT (false) trong production.
   * Bật debug: window.__HSV_DEBUG__ = true; ở console DevTools.
   * ─────────────────────────────────────────────────────────────────
   */
  function installConsoleWrapper() {
    if (window.__hsv_console_wrapped__) return;

    // Mặc định debug = false nếu chưa được đặt
    if (typeof window.__HSV_DEBUG__ === 'undefined') {
      window.__HSV_DEBUG__ = false;
    }

    var _origLog = console.log.bind(console);
    var _origWarn = console.warn.bind(console);
    var _origInfo = console.info.bind(console);

    // Chỉ bọc console.log, giữ nguyên warn/error để không mất thông tin lỗi quan trọng
    console.log = function() {
      if (window.__HSV_DEBUG__) {
        _origLog.apply(console, arguments);
      }
      // Nếu debug tắt: im lặng (không ghi gì)
    };

    // Giữ warn hiển thị nhưng có thể tắt riêng
    console.warn = function() {
      if (window.__HSV_DEBUG__ || window.__HSV_WARN__) {
        _origWarn.apply(console, arguments);
      }
    };

    // Lưu trữ các hàm gốc để khôi phục khi cần
    window.__hsv_console_orig__ = {
      log: _origLog,
      warn: _origWarn,
      info: _origInfo
    };

    // Hàm tiện ích để bật debug tạm thời
    window.hsvDebug = function(val) {
      window.__HSV_DEBUG__ = (val !== false);
      _origLog('[HSV] Debug mode:', window.__HSV_DEBUG__ ? 'ON' : 'OFF');
    };

    window.__hsv_console_wrapped__ = true;
    // Log này dùng hàm gốc để luôn hiện khi wrap xong
    _origLog('[HSV-J3] Console wrapper installed. Dùng hsvDebug(true) để bật log.');
  }

  /* ─────────────────────────────────────────────────────────────────
   * PHẦN 3: Đo độ sâu chồng gọi doSetValue (J1 feature — chỉ đọc)
   * Ghi vào window.__hsv_wrap_depth_log[] khi debug bật.
   * ─────────────────────────────────────────────────────────────────
   */
  function installDepthMeasurer() {
    if (window.__hsv_depth_measured__) return;
    if (typeof window.doSetValue !== 'function') return;

    window.__hsv_wrap_depth_log = window.__hsv_wrap_depth_log || [];

    var _origDSV = window.doSetValue;
    window.doSetValue = function(caseId, key, value) {
      if (window.__HSV_DEBUG__) {
        // Đo độ sâu stack
        var stackLines = (new Error().stack || '').split('\n').length;
        window.__hsv_wrap_depth_log.push({
          ts: Date.now(),
          key: key,
          stackDepth: stackLines
        });
        if (window.__hsv_wrap_depth_log.length > 500) {
          window.__hsv_wrap_depth_log.shift(); // giữ tối đa 500 bản ghi
        }
      }
      return _origDSV.apply(this, arguments);
    };

    window.__hsv_depth_measured__ = true;
  }

  /* ── Chạy theo thứ tự: guard → console wrap → depth measurer ── */
  installJ3DoSetGuard();
  installConsoleWrapper();

  // Depth measurer cần doSetValue đã được định nghĩa — thử ngay và retry
  if (typeof window.doSetValue === 'function') {
    installDepthMeasurer();
  } else {
    document.addEventListener('DOMContentLoaded', function() {
      setTimeout(installDepthMeasurer, 100);
    });
  }

  // Expose thông tin trạng thái
  window.__hsv_j3_info__ = {
    version: 'J3-2026-07-28',
    guards: ['__np5_wrapped__','__v8_wrapped__','__v16_wrap__','__v17_wrap__','__hsv19_dset_guard__','__v20_wrap__'],
    consoleWrapped: true,
    depthLog: 'window.__hsv_wrap_depth_log'
  };

})();
