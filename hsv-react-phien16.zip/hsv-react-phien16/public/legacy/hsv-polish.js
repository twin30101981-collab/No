/* ================== HSV UI 2026 — POLISH LAYER v3 (safe overlay) ==================
 * Bổ sung: toast không chặn (hook alert), shortcut help (Alt+/), density toggle.
 * KHÔNG sửa app.js — chỉ thêm listener + DOM phụ.
 * ============================================================================== */
(function () {
  "use strict";
  if (window.__HSV_POLISH_V3__) return;
  window.__HSV_POLISH_V3__ = true;

  const $ = (s, r = document) => r.querySelector(s);
  const on = (t, e, h, o) => t && t.addEventListener(e, h, o);

  /* ---------- Toast system ---------- */
  const stack = document.createElement("div");
  stack.className = "hsv-toast-stack";
  stack.setAttribute("role", "status");
  stack.setAttribute("aria-live", "polite");
  document.body.appendChild(stack);

  function toast(msg, kind = "info", ttl = 3200) {
    if (!msg) return;
    const el = document.createElement("div");
    el.className = "hsv-toast";
    el.dataset.kind = kind;
    el.textContent = String(msg);
    stack.appendChild(el);
    const kill = () => { el.classList.add("leaving"); setTimeout(() => el.remove(), 240); };
    setTimeout(kill, ttl);
    on(el, "click", kill);
    return el;
  }
  window.hsvToast = toast;

  /* Hook window.alert để hiển thị toast thay vì popup chặn — an toàn: giữ fallback */
  try {
    const origAlert = window.alert.bind(window);
    window.alert = function (m) {
      try { toast(m, /lỗi|error|failed|thất bại/i.test(String(m)) ? "error" : "info", 4200); }
      catch (e) { origAlert(m); }
    };
    // Cho phép khôi phục nếu cần: window.__origAlert()
    window.__origAlert = origAlert;
  } catch (_) {}

  /* Bắt lỗi runtime → toast (chỉ dev-friendly, không lộ chi tiết) */
  on(window, "error", (ev) => {
    if (ev && ev.message && !/ResizeObserver|Script error/i.test(ev.message)) {
      toast("Có lỗi: " + ev.message.slice(0, 120), "error", 5000);
    }
  });

  /* ---------- Density toggle ---------- */
  const DKEY = "hsv-density";
  const applyDensity = (v) => document.documentElement.setAttribute("data-hsv-density", v || "comfortable");
  applyDensity(localStorage.getItem(DKEY) || "comfortable");

  /* ---------- Shortcut help modal ---------- */
  const help = document.createElement("div");
  help.className = "hsv-help";
  help.innerHTML = `
    <div class="hsv-help__panel" role="dialog" aria-label="Phím tắt">
      <h3>Phím tắt HSV 2026</h3>
      <div class="hsv-help__row"><span>Mở Command Palette</span><span class="hsv-kbd">Alt</span> <span class="hsv-kbd">K</span></div>
      <div class="hsv-help__row"><span>Mở bảng phím tắt</span><span class="hsv-kbd">Alt</span> <span class="hsv-kbd">/</span></div>
      <div class="hsv-help__row"><span>Đổi mật độ hiển thị</span><span class="hsv-kbd">Alt</span> <span class="hsv-kbd">D</span></div>
      <div class="hsv-help__row"><span>Chuyển chủ đề Sáng/Tối</span><span class="hsv-kbd">Alt</span> <span class="hsv-kbd">T</span></div>
      <div class="hsv-help__row"><span>Đóng cửa sổ / hộp thoại</span><span class="hsv-kbd">Esc</span></div>
    </div>`;
  document.body.appendChild(help);
  const openHelp = () => help.classList.add("is-open");
  const closeHelp = () => help.classList.remove("is-open");
  on(help, "click", (e) => { if (e.target === help) closeHelp(); });

  /* ---------- Global hotkeys ---------- */
  on(document, "keydown", (e) => {
    if (e.altKey && !e.ctrlKey && !e.metaKey) {
      const k = e.key.toLowerCase();
      if (k === "/") {
        e.preventDefault();
        help.classList.contains("is-open") ? closeHelp() : openHelp();
      } else if (k === "d") {
        e.preventDefault();
        const next = (localStorage.getItem(DKEY) === "compact") ? "comfortable" : "compact";
        localStorage.setItem(DKEY, next);
        applyDensity(next);
        toast("Mật độ: " + (next === "compact" ? "Gọn" : "Thoải mái"), "info", 1600);
      } else if (k === "t") {
        e.preventDefault();
        const btn = document.getElementById("hsv-theme-toggle");
        btn && btn.click();
      }
    }
    if (e.key === "Escape") closeHelp();
  });

  /* ---------- Header toolbar buttons (density + help) ---------- */
  function mountToolbar() {
    if ($("#hsv-density-btn")) return;
    // Neo cạnh nút theme nếu có, hoặc body
    const themeBtn = document.getElementById("hsv-theme-toggle");
    const host = themeBtn ? themeBtn.parentElement : null;
    if (!host) return setTimeout(mountToolbar, 600);

    const dBtn = document.createElement("button");
    dBtn.id = "hsv-density-btn";
    dBtn.className = "hsv-toolbar-btn";
    dBtn.type = "button";
    dBtn.title = "Đổi mật độ (Alt+D)";
    dBtn.setAttribute("aria-label", "Đổi mật độ hiển thị");
    dBtn.textContent = "⇅";
    on(dBtn, "click", () => {
      const next = (localStorage.getItem(DKEY) === "compact") ? "comfortable" : "compact";
      localStorage.setItem(DKEY, next);
      applyDensity(next);
      toast("Mật độ: " + (next === "compact" ? "Gọn" : "Thoải mái"), "info", 1500);
    });

    const hBtn = document.createElement("button");
    hBtn.id = "hsv-help-btn";
    hBtn.className = "hsv-toolbar-btn";
    hBtn.type = "button";
    hBtn.title = "Phím tắt (Alt+/)";
    hBtn.setAttribute("aria-label", "Xem phím tắt");
    hBtn.textContent = "?";
    on(hBtn, "click", openHelp);

    host.insertBefore(dBtn, themeBtn);
    host.insertBefore(hBtn, themeBtn);
  }
  if (document.readyState !== "loading") mountToolbar();
  else on(document, "DOMContentLoaded", mountToolbar);
  setTimeout(mountToolbar, 1200);

  /* ---------- Auto-skeleton for tables đang load ---------- */
  /* Nếu 1 bảng data hiện có class '.loading' hoặc thuộc tính data-loading, gán shimmer */
  new MutationObserver(() => {
    document.querySelectorAll("[data-loading='true']:not(.hsv-skeleton), .is-loading:not(.hsv-skeleton)")
      .forEach(el => el.classList.add("hsv-skeleton"));
    document.querySelectorAll(".hsv-skeleton[data-loading='false'], .hsv-skeleton:not(.is-loading):not([data-loading='true'])")
      .forEach(el => el.classList.remove("hsv-skeleton"));
  }).observe(document.body, { subtree: true, attributes: true, attributeFilter: ["data-loading", "class"] });

  console.info("[HSV Polish v3] toast + shortcuts + density loaded");
})();
