/**
 * HSV J4 — Cầu nối localStorage ↔ IndexedDB (data-access bridge)
 * CỘNG THÊM — không sửa code cũ, mọi ghi/đọc MỚI đi qua module này.
 * Giai đoạn CHUYỂN TIẾP: ghi song song cả 2 nơi, đo lệch, chưa chọn nguồn chân lý.
 * Ngày: 2026-07-28 · HSV-UPGRADE-J4
 */
(function(global) {
  'use strict';

  var BRIDGE_VERSION = 'J4-2026-07-28';
  var BRIDGE_DB = 'hsv-bridge-v1';
  var BRIDGE_STORE = 'kv';
  var _db = null;
  var _diffLog = []; // log lệch dữ liệu giữa 2 nguồn

  /* ── Mở IndexedDB ── */
  function openDB() {
    return new Promise(function(resolve, reject) {
      if (_db) { resolve(_db); return; }
      var req = indexedDB.open(BRIDGE_DB, 1);
      req.onupgradeneeded = function(e) {
        var db = e.target.result;
        if (!db.objectStoreNames.contains(BRIDGE_STORE)) {
          db.createObjectStore(BRIDGE_STORE); // keyPath không dùng, key riêng
        }
      };
      req.onsuccess = function(e) {
        _db = e.target.result;
        resolve(_db);
      };
      req.onerror = function(e) {
        reject(e.target.error);
      };
    });
  }

  /* ── Đọc từ IndexedDB ── */
  function idbGet(key) {
    return openDB().then(function(db) {
      return new Promise(function(resolve, reject) {
        try {
          var tx = db.transaction(BRIDGE_STORE, 'readonly');
          var store = tx.objectStore(BRIDGE_STORE);
          var req = store.get(key);
          req.onsuccess = function() { resolve(req.result !== undefined ? req.result : null); };
          req.onerror = function() { reject(req.error); };
        } catch(e) { reject(e); }
      });
    });
  }

  /* ── Ghi vào IndexedDB ── */
  function idbSet(key, value) {
    return openDB().then(function(db) {
      return new Promise(function(resolve, reject) {
        try {
          var tx = db.transaction(BRIDGE_STORE, 'readwrite');
          var store = tx.objectStore(BRIDGE_STORE);
          var req = store.put(value, key);
          req.onsuccess = function() { resolve(); };
          req.onerror = function() { reject(req.error); };
        } catch(e) { reject(e); }
      });
    });
  }

  /* ── Đọc từ localStorage ── */
  function lsGet(key) {
    try {
      var v = localStorage.getItem(key);
      return Promise.resolve(v);
    } catch(e) {
      return Promise.reject(e);
    }
  }

  /* ── Ghi vào localStorage ── */
  function lsSet(key, value) {
    try {
      localStorage.setItem(key, value);
      return Promise.resolve();
    } catch(e) {
      return Promise.reject(e);
    }
  }

  /* ── Ghi song song cả 2 nơi (giai đoạn chuyển tiếp) ── */
  function bridgeSet(key, value) {
    return Promise.all([
      lsSet(key, value).catch(function(e) {
        if (global.__HSV_DEBUG__) console.error('[HSV-J4] lsSet error:', key, e);
      }),
      idbSet(key, value).catch(function(e) {
        if (global.__HSV_DEBUG__) console.error('[HSV-J4] idbSet error:', key, e);
      })
    ]);
  }

  /* ── Đọc với ưu tiên IndexedDB, fallback localStorage ── */
  function bridgeGet(key) {
    return idbGet(key).then(function(idbVal) {
      var lsVal = null;
      try { lsVal = localStorage.getItem(key); } catch(e) {}

      // Phát hiện lệch
      if (lsVal !== null && idbVal !== null && String(lsVal) !== String(idbVal)) {
        var diffEntry = {
          key: key,
          lsValue: lsVal,
          idbValue: idbVal,
          ts: Date.now()
        };
        _diffLog.push(diffEntry);
        if (_diffLog.length > 200) _diffLog.shift();
        if (global.__HSV_DEBUG__) {
          console.warn('[HSV-J4] LỆCH DỮ LIỆU:', key,
            '| localStorage:', lsVal,
            '| IndexedDB:', idbVal);
        }
      }

      // Trả về IndexedDB nếu có, không thì localStorage
      if (idbVal !== null) return idbVal;
      return lsVal;
    }).catch(function() {
      // IndexedDB lỗi → fallback localStorage
      try { return localStorage.getItem(key); } catch(e) { return null; }
    });
  }

  /* ── Đọc trực tiếp IndexedDB (dùng trong Playwright test) ── */
  function readIndexedDB(key) {
    return idbGet(key);
  }

  /* ── Xem báo cáo lệch ── */
  function getDiffReport() {
    return _diffLog.slice(); // clone
  }

  /* ── Đồng bộ hóa: copy từ localStorage sang IndexedDB (migration một chiều) ── */
  function syncLsToIdb(keyPrefix) {
    var promises = [];
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (!keyPrefix || k.indexOf(keyPrefix) === 0) {
        var v = localStorage.getItem(k);
        if (v !== null) {
          promises.push(idbSet(k, v));
        }
      }
    }
    return Promise.all(promises).then(function() {
      if (global.__HSV_DEBUG__) {
        console.log('[HSV-J4] syncLsToIdb complete. Keys synced:', promises.length);
      }
      return promises.length;
    });
  }

  /* ── Expose public API ── */
  global.hsvStorageBridge = {
    version:       BRIDGE_VERSION,
    get:           bridgeGet,
    set:           bridgeSet,
    idbGet:        idbGet,
    idbSet:        idbSet,
    lsGet:         lsGet,
    lsSet:         lsSet,
    readIndexedDB: readIndexedDB,
    getDiffReport: getDiffReport,
    syncLsToIdb:   syncLsToIdb,
    // Để test Playwright
    _diffLog:      _diffLog
  };

  if (global.__HSV_DEBUG__) {
    console.log('[HSV-J4] hsvStorageBridge v' + BRIDGE_VERSION + ' ready.');
  }

})(window);
