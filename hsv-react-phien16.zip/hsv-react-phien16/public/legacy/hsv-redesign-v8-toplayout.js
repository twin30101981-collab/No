/* ══════════════════════════════════════════════════════════════════════
 *  HSV v25.5.3 · REDESIGN v8 — Sắp xếp lại đầu trang wizard (additive)
 *  ---------------------------------------------------------------------
 *  1) Ẩn dải bước "1. Khách hàng…5. Xuất hồ sơ", chỉ giữ % tiến độ.
 *  2) Đưa breadcrumb vào thanh tiến độ (thay chỗ dải bước).
 *  3) Ẩn dòng eyebrow trùng lặp trong .page-header.
 *  4) Đưa .wizard-layout (Nhóm thông tin + Form nhập) lên ngay sau thanh
 *     tiến độ; .page-header (tên KH + nút Lưu/Xuất) lùi xuống dưới.
 *
 *  Chạy 1 lần mỗi khi #main-content được vẽ lại (renderWizard), dùng
 *  requestAnimationFrame để gộp nhiều mutation liên tiếp thành 1 lần xử
 *  lý — tránh cộng thêm dao động/nháy DOM. Idempotent: mọi thao tác đều
 *  kiểm tra điều kiện trước khi động vào DOM, nên khi đã ở đúng vị trí,
 *  hàm relayout() thoát sớm mà không ghi gì thêm.
 * ══════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';
  if (window.__hsvV8TopLayout) return;
  window.__hsvV8TopLayout = true;

  function relayout() {
    var main = document.getElementById('main-content');
    if (!main) return;
    var bar = document.getElementById('hsv-progress-bar');
    if (!bar) return; // chỉ áp dụng cho trang wizard (có thanh tiến độ)

    // HSV-FIX v20 (2026-07-19): app.js gọi lại renderProgressBar() mỗi
    // ~400ms khi người dùng gõ phím (cập nhật % tiến độ), và hàm đó làm
    // "bar.innerHTML = ..." — TOÀN BỘ con của bar bị thay mới. Nếu
    // breadcrumb từng bị chèn LÀM CON của bar (cách làm cũ), nó sẽ bị
    // xoá mất ngay sau lần gõ phím đầu tiên. Cách mới: không đưa
    // breadcrumb vào BÊN TRONG bar nữa — bọc bar + breadcrumb làm 2 ANH
    // EM trong 1 wrapper ổn định (#hsv8-topbar) mà bar không hề đụng
    // tới khi tự vẽ lại nội dung riêng của nó.
    var wrap = document.getElementById('hsv8-topbar');
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.id = 'hsv8-topbar';
    }
    if (bar.parentElement !== wrap) {
      main.insertBefore(wrap, bar);
      wrap.appendChild(bar);
    }
    if (wrap.parentElement !== main || main.firstElementChild !== wrap) {
      main.insertBefore(wrap, main.firstChild);
    }

    var crumb = main.querySelector(':scope > .breadcrumb') || main.querySelector('.breadcrumb');
    var header = main.querySelector(':scope > .page-header') || main.querySelector('.page-header');
    var wizardLayout = main.querySelector(':scope > .wizard-layout') || main.querySelector('.wizard-layout');

    // 2) Đưa breadcrumb vào wrapper, TRƯỚC bar (anh em, không phải con của bar)
    if (crumb && crumb.parentElement !== wrap) {
      crumb.classList.add('hsv8-crumb-in-bar');
      wrap.insertBefore(crumb, bar);
    }

    // 3) Đánh dấu page-header để CSS thu gọn (không xoá — vẫn còn nút Lưu/Xuất hồ sơ)
    if (header && !header.classList.contains('hsv8-below')) {
      header.classList.add('hsv8-below');
    }

    // 4) Đưa wizard-layout lên ngay sau wrapper
    if (wizardLayout) {
      wizardLayout.classList.add('hsv8-pulled-up');
      if (wrap.nextElementSibling !== wizardLayout) {
        wrap.insertAdjacentElement('afterend', wizardLayout);
      }
      // page-header xuống ngay sau wizard-layout (thay vì nằm giữa bar và layout)
      if (header && wizardLayout.nextElementSibling !== header) {
        wizardLayout.insertAdjacentElement('afterend', header);
      }
    }
  }

  var scheduled = false;
  function scheduleRelayout() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(function () {
      scheduled = false;
      try { relayout(); } catch (e) { /* no-op: additive layer, never throw */ }
    });
  }

  var mo = new MutationObserver(function (muts) {
    // Chỉ phản ứng khi #main-content thực sự thay đổi con trực tiếp
    // (renderWizard ghi lại toàn bộ innerHTML) — bỏ qua các mutation vụn
    // vặt bên trong ô nhập để không góp phần vào "bão mutation".
    for (var i = 0; i < muts.length; i++) {
      var t = muts[i].target;
      if (t && (t.id === 'main-content' || (t.closest && t.closest('#main-content') === t))) {
        scheduleRelayout();
        return;
      }
    }
  });
  try {
    mo.observe(document.body, { childList: true, subtree: true });
  } catch (e) {}

  document.addEventListener('DOMContentLoaded', scheduleRelayout);
  setTimeout(scheduleRelayout, 300);
  requestAnimationFrame(scheduleRelayout);

  window.hsvV8TopLayout = { relayout: relayout };
})();
