/* ============================================================
   HSV Audit Log v1 — Lịch sử thay đổi hồ sơ
   Ghi lại: mỗi khi hồ sơ được lưu, field nào đã thay đổi, lúc nào.
   Mục đích: cán bộ tín dụng/kiểm soát viên có thể xem lại "ai đã sửa gì,
   khi nào" mà không cần công cụ ngoài.

   AN TOÀN TUYỆT ĐỐI: file này KHÔNG sửa cách lưu dữ liệu hiện có. Nó chỉ
   "quan sát" thời điểm gọi persistStore() (vẫn gọi lại hàm gốc y nguyên),
   so sánh dữ liệu trước/sau, rồi ghi một dòng nhật ký GỌN (tên field đổi,
   không lưu nội dung cũ/mới đầy đủ để tránh phình dung lượng) vào một
   khoá localStorage RIÊNG (không đụng tới khoá lưu hồ sơ chính). Nếu có
   lỗi bất kỳ, tự bỏ qua — không bao giờ chặn việc lưu hồ sơ thật.
   ============================================================ */
(function () {
  "use strict";
  if (window.__hsvAuditInstalled) return;
  window.__hsvAuditInstalled = true;

  var MAX_ENTRIES_PER_CASE = 200;
  var lastSnapshot = {}; // caseId -> { key: value } (bản chụp gần nhất để so sánh)

  function auditKey(caseId) {
    return "hsv:audit:" + caseId;
  }

  function readHistory(caseId) {
    try {
      var raw = localStorage.getItem(auditKey(caseId));
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  function writeHistory(caseId, arr) {
    try {
      if (arr.length > MAX_ENTRIES_PER_CASE) arr = arr.slice(arr.length - MAX_ENTRIES_PER_CASE);
      localStorage.setItem(auditKey(caseId), JSON.stringify(arr));
    } catch (e) {
      /* hết dung lượng hoặc lỗi khác — bỏ qua, không ảnh hưởng lưu hồ sơ thật */
    }
  }

  function diffKeys(before, after) {
    var changed = [];
    var allKeys = new Set(Object.keys(before || {}).concat(Object.keys(after || {})));
    allKeys.forEach(function (k) {
      var a = before ? before[k] : undefined;
      var b = after ? after[k] : undefined;
      if (a !== b) changed.push(k);
    });
    return changed;
  }

  function snapshotAllCases() {
    var out = {};
    try {
      var cases = (window.store && window.store.cases) || {};
      Object.keys(cases).forEach(function (id) {
        var c = cases[id];
        out[id] = Object.assign({}, c.values || {});
      });
    } catch (e) {}
    return out;
  }

  // chụp bản đầu tiên ngay khi cài đặt, để tránh log "thay đổi giả" so với trạng thái rỗng
  function initSnapshot() {
    lastSnapshot = snapshotAllCases();
  }

  function onBeforeSave() {
    try {
      var current = snapshotAllCases();
      Object.keys(current).forEach(function (caseId) {
        var before = lastSnapshot[caseId];
        var after = current[caseId];
        if (!before) return; // hồ sơ mới tạo lần đầu — không log (tránh log rác lúc khởi tạo)
        var changed = diffKeys(before, after);
        if (changed.length) {
          var hist = readHistory(caseId);
          hist.push({
            t: Date.now(),
            n: changed.length,
            fields: changed.slice(0, 15), // giới hạn 15 tên field/lần để nhật ký gọn
          });
          writeHistory(caseId, hist);
        }
      });
      lastSnapshot = current;
    } catch (e) {
      /* không bao giờ để lỗi ghi audit làm hỏng việc lưu hồ sơ thật */
    }
  }

  // ---- Cài đặt: bọc persistStore (vẫn gọi lại hàm gốc y nguyên) ----
  function installWrapper() {
    if (typeof window.persistStore !== "function") {
      setTimeout(installWrapper, 300); // app.js có thể chưa nạp xong — thử lại
      return;
    }
    initSnapshot();
    var _orig = window.persistStore;
    window.persistStore = function () {
      onBeforeSave();
      return _orig.apply(this, arguments);
    };
  }
  installWrapper();

  window.HSVAuditLog = {
    getHistory: function (caseId) {
      return readHistory(caseId).slice().reverse(); // mới nhất trước
    },
    clearHistory: function (caseId) {
      try {
        localStorage.removeItem(auditKey(caseId));
      } catch (e) {}
    },
  };
})();
