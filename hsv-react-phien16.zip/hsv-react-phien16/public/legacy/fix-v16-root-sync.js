/* HSV v25.5.2 · FIX v16 — Root sync PA v8 -> Bảng đối chiếu HMTD */
(function (global) {
  'use strict';
  if (global.__hsvFixV16Loaded) return;
  global.__hsvFixV16Loaded = true;

  var SOURCE_ID = 'hsv-v16-pa-source';
  var timer = null;
  var booting = false;

  function norm(s) {
    return String(s || '').toLowerCase().normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd')
      .replace(/&nbsp;/g, ' ').replace(/^[\s+\-*·•🎯📊]+/, '')
      .replace(/[\s:._-]+/g, ' ').trim();
  }
  function numberOf(v) {
    if (typeof v === 'number') return isFinite(v) ? v : 0;
    var s = String(v == null ? '' : v).trim().replace(/[^\d,.-]/g, '');
    if (!s) return 0;
    if (s.indexOf(',') >= 0) s = s.replace(/\./g, '').replace(',', '.');
    else s = s.replace(/\./g, '');
    var n = Number(s);
    return isFinite(n) ? n : 0;
  }
  function money(n) { return Math.round(n).toLocaleString('vi-VN') + ' đ'; }
  function percent(n) { return Number(n).toLocaleString('vi-VN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' %'; }

  var MAP = {
    'tong doanh thu': ['r_dt_kd', 'money'],
    'loi nhuan du kien (muc tieu)': ['r_ln_mt', 'money'],
    'nhu cau von': ['r_ncv', 'money'],
    'von tu co': ['r_vtc', 'money'],
    'hmtd duyet': ['r_hmtd', 'money'],
    'von vay tctd khac': ['r_tctd', 'money'],
    'ty le vtc (%)': ['r_tlvtc', 'percent'],
    'vong quay vld': ['r_vq', 'round'],
    'tong cp (chua lai, kh)': ['r_tcp_chua', 'money'],
    'lai': ['r_lai', 'money'],
    'khau hao': ['r_kh', 'money'],
    'thue': ['r_thue', 'money'],
    'tong cp pa sxkd': ['r_tcp_da', 'money'],
    'cp vat tu': ['r_cpvt2', 'money'],
    'chi phi khac': ['r_cpk2', 'money'],
    'tong tshs': ['r_tshc', 'money'],
    'tong gia tri ts': ['r_tsgt', 'money'],
    'gia tri ld': ['r_gtld', 'money'],
    'ts khac': ['r_tsk', 'money'],
    'hang hoa cac loai': ['r_hh', 'money'],
    'tien mat': ['r_tm', 'money'],
    'no phai thu': ['r_npt', 'money'],
    'no phai tra': ['r_nptr', 'money'],
    'no phai tra pa': ['r_nptr_pa', 'money'],
    'du no': ['r_duno', 'money'],
    'no nguoi ban': ['r_nnb', 'money'],
    'no phai tra khac': ['r_nptk', 'money'],
    'chenh lech cp': ['r_cl', 'money'],
    'ty suat ln (%)': ['r_tsln', 'percent'],
    'loi nhuan thuc te': ['r_ln_tt', 'money'],
    'ln muc tieu': ['r_ln_mt', 'money'],
    'dt can dat': ['r_dt_cadat', 'money']
  };

  function currentCaseId() {
    return global.currentCaseId || (global.G && global.G.currentCaseId) || null;
  }
  function savedPA() {
    var id = currentCaseId();
    if (!id) return null;
    var key = 'hsv:hoso:' + id + ':pa_sxkd_v8';
    try {
      return global.hsvStore && global.hsvStore.lsGet ? global.hsvStore.lsGet(key) : localStorage.getItem(key);
    } catch (_) { return null; }
  }
  function activeFrame() {
    var f = document.getElementById('paV8Frame');
    return f && f.contentDocument && f.contentDocument.getElementById('r_dt_kd') ? f : null;
  }
  function sourceFrame() {
    return activeFrame() || document.getElementById(SOURCE_ID);
  }
  function read(doc, id) {
    var el = doc && doc.getElementById(id);
    if (!el) return null;
    return numberOf(('value' in el) ? el.value : el.textContent);
  }
  function patchFrom(doc) {
    if (!doc || !doc.getElementById('r_dt_kd')) return 0;
    try { if (doc.defaultView && typeof doc.defaultView.recalc === 'function') doc.defaultView.recalc(); } catch (_) {}
    var patched = 0;
    document.querySelectorAll('#hsv16-summary .hsv16-row').forEach(function (row) {
      var keyEl = row.querySelector('.k');
      var valEl = row.querySelector('.v');
      if (!keyEl || !valEl) return;
      var spec = MAP[norm(keyEl.textContent)];
      if (!spec) return;
      var value = read(doc, spec[0]);
      if (value == null) return;
      valEl.textContent = spec[1] === 'percent' ? percent(value) : spec[1] === 'round' ? String(value).replace('.', ',') : money(value);
      valEl.classList.toggle('pos', value > 0);
      valEl.classList.toggle('neg', value < 0);
      valEl.setAttribute('data-fixv16', '1');
      patched++;
    });
    return patched;
  }
  function sync() {
    clearTimeout(timer);
    timer = setTimeout(function () {
      var f = sourceFrame();
      if (f && f.contentDocument) patchFrom(f.contentDocument);
      if (!activeFrame()) ensureSource();
    }, 80);
  }
  function hydrateFrame(frame) {
    var raw = savedPA();
    if (!frame || !frame.contentWindow) return;
    try {
      if (raw) {
        frame.contentWindow.localStorage.setItem('pa_sxkd_v12', raw);
        if (typeof frame.contentWindow.loadData === 'function') frame.contentWindow.loadData();
      }
      if (typeof frame.contentWindow.recalc === 'function') frame.contentWindow.recalc();
    } catch (_) {}
    [50, 250, 700].forEach(function (ms) {
      setTimeout(function () { try { patchFrom(frame.contentDocument); } catch (_) {} }, ms);
    });
  }
  function ensureSource() {
    if (activeFrame() || document.getElementById(SOURCE_ID) || booting || !global.__PA_SRCDOC) return;
    booting = true;
    var f = document.createElement('iframe');
    f.id = SOURCE_ID;
    f.setAttribute('aria-hidden', 'true');
    f.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-forms');
    f.style.cssText = 'position:fixed;left:-10000px;top:0;width:1280px;height:900px;opacity:0;pointer-events:none;border:0;';
    f.addEventListener('load', function () { booting = false; hydrateFrame(f); });
    document.body.appendChild(f);
    f.srcdoc = global.__PA_SRCDOC;
  }
  function boot() {
    ensureSource();
    sync();
    new MutationObserver(sync).observe(document.body, { childList: true, subtree: true });
    document.addEventListener('input', sync, true);
    document.addEventListener('change', sync, true);
    setInterval(sync, 1500);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
  global.hsvFixV16 = { version: 'v16.0.0', sync: sync, patchFrom: patchFrom };
})(window);