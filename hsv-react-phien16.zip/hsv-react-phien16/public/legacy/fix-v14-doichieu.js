/* ══════════════════════════════════════════════════════════════════════
 *  HSV v25.5.2 · FIX v14 — Bảng đối chiếu số liệu (HMTD ⇄ PA SXKD)
 *  ---------------------------------------------------------------------
 *  Vá 3 lỗi tầng đã chẩn đoán:
 *   (1) Sidebar cào DOM label → miss các trường thuộc PA SXKD.
 *   (2) Label matching quá cứng (startsWith).
 *   (3) Không đọc từ PA đính kèm / pa_draft (IndexedDB) / registry.
 *
 *  Cách hoạt động: additive, KHÔNG sửa app.js gốc.
 *   • MutationObserver theo #hsv16-summary, sau mỗi render:
 *       - Xây pool dữ liệu từ 4 nguồn: sync.fromFormHoSo (registry),
 *         PALib snapshot inputs, IndexedDB pa_draft, DOM loose-scan.
 *       - Duyệt mọi .hsv16-row có value "0đ" hoặc rỗng, tra pool
 *         theo alias-map, ghi đè bằng số thật.
 *   • bus.on('pa_sxkd:imported' | 'pa:updated') → click nút Refresh.
 *   • Debounced input listener trên form → re-render.
 *
 *  Idempotent, chạy được nhiều lần.
 * ══════════════════════════════════════════════════════════════════════ */
(function (global) {
  'use strict';
  if (global.__hsvFixV14Loaded) return;
  global.__hsvFixV14Loaded = true;

  var LOG_PREFIX = '[fix-v14]';
  function log(){ try{ console.log.apply(console, [LOG_PREFIX].concat([].slice.call(arguments))); }catch(_){} }

  /* ── Utils số/chuỗi ────────────────────────────────────────────── */
  function toNum(v){
    if (v == null) return 0;
    if (typeof v === 'number') return isFinite(v) ? v : 0;
    var s = String(v).trim();
    if (!s) return 0;
    // Bỏ ký tự tiền tệ / khoảng trắng / chữ
    s = s.replace(/[^\d,.\-]/g, '');
    // Định dạng VN: dùng '.' làm nghìn, ',' làm thập phân
    if (s.indexOf(',') >= 0 && s.indexOf('.') >= 0) {
      s = s.replace(/\./g, '').replace(',', '.');
    } else if (s.indexOf(',') >= 0 && s.indexOf('.') < 0) {
      // "1,5" → 1.5
      s = s.replace(',', '.');
    } else {
      // Chỉ có dấu chấm → coi là nghìn
      s = s.replace(/\./g, '');
    }
    var n = parseFloat(s);
    return isFinite(n) ? n : 0;
  }
  function norm(s){
    return String(s || '')
      .toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // bỏ dấu
      .replace(/đ/g, 'd')
      .replace(/^[\s\+\-\*·•\.\d]+/, '') // strip prefix "+ ", "- ", "1.", "III."
      .replace(/[\s:\.\-_]+/g, ' ')
      .trim();
  }
  function fmtVND(n){
    var v = Math.round(Number(n) || 0);
    var s = v.toLocaleString('vi-VN');
    return s + ' đ';
  }

  /* ── Alias-map: nhãn hiển thị trong Bảng đối chiếu ⇄ nhãn thật trong form ── */
  // Key = norm(label hiển thị trong sidebar).
  // Value = mảng norm(alias-label) và/hoặc registry-key (bắt đầu bằng '@').
  var ALIAS = {
    // III. Tổng doanh thu
    'tong doanh thu':                     ['tong doanh thu bcdxgn', 'tong doanh thu', 'iii tong doanh thu', 'doanh thu du kien', '@doanhThuDuKien'],
    'loi nhuan du kien (muc tieu)':       ['loi nhuan du kien (muc tieu)', 'loi nhuan du kien', 'ln muc tieu', 'ln du kien', 'loi nhuan muc tieu'],
    'ln muc tieu':                        ['ln muc tieu', 'loi nhuan muc tieu', 'loi nhuan du kien'],

    // Nhu cầu vốn
    'nhu cau von':                        ['nhu cau von', 'tong ncv theo dung phuong an', 'tong nhu cau von', 'ncv theo phuong an'],
    'von tu co':                          ['von tu co', 'von doi ung', 'von bang tien', '@vonTuCo'],
    'hmtd duyet':                         ['hmtd duyet', 'han muc tin dung toi da', 'han muc tin dung duyet'],
    'von vay tctd khac':                  ['von vay tctd khac', 'vay tctd khac', 'du no agribank'],
    'ty le vtc (%)':                      ['ty le vtc', 'ty le von tu co'],
    'vong quay vld':                      ['vong quay vld', 'so vong quay', 'vong quay von luu dong', '@vongQuayVon'],

    // Chi phí
    'tong cp (chua lai, kh)':             ['tong cp chua lai kh', 'tong chi phi bcdxgn', 'tong chi phi', 'tong cp'],
    'lai':                                ['lai uoc cua nhan no', 'lai vay', 'chi phi lai vay', '@laiVay'],
    'khau hao':                           ['khau hao', 'chi phi khau hao'],
    'thue':                               ['thue', 'chi phi thue'],
    'tong cp pa sxkd':                    ['tong cp pa sxkd', 'tong chi phi pa sxkd'],
    'cp vat tu':                          ['cp vat tu', 'chi phi vat tu', '@chiPhiDuKien'],
    'chi phi khac':                       ['chi phi khac', 'cp khac'],

    // Tài sản hiện có
    'tong tshs':                          ['tong tshs', 'tong tai san hien co'],
    'tong gia tri ts':                    ['tong gia tri ts', 'gia tri tai san'],
    'gia tri ld':                         ['gia tri ld', 'gia tri luu dong'],
    'ts khac':                            ['ts khac', 'tai san khac'],
    'hang hoa cac loai':                  ['hang hoa cac loai', 'hang hoa', 'hang ton kho', 'hang ton kho1'],
    'tien mat':                           ['tien mat'],
    'no phai thu':                        ['no phai thu', 'no phai thu1'],
    'no phai tra':                        ['no phai tra', 'no phai tra1'],
    'no phai tra pa':                     ['no phai tra pa'],
    'du no':                              ['du no', 'du no agribank'],
    'no nguoi ban':                       ['no nguoi ban'],
    'no phai tra khac':                   ['no phai tra khac'],

    // Kết quả
    'chenh lech cp':                      ['chenh lech cp', 'chenh lech thu chi bcdxgn', 'chenh lech thu chi'],
    'ty suat ln (%)':                     ['ty suat ln', 'ty suat loi nhuan'],
    'loi nhuan thuc te':                  ['loi nhuan thuc te', 'ln thuc te'],
    'dt can dat':                         ['dt can dat', 'doanh thu can dat']
  };

  /* ── Build data pool từ mọi nguồn khả dụng ────────────────────── */
  var _poolCache = null;
  var _poolCacheAt = 0;

  function buildPool(force){
    var now = Date.now();
    if (!force && _poolCache && (now - _poolCacheAt) < 400) return _poolCache;

    var pool = {
      byRegKey:   {},   // registry key → value
      byLabelNorm: {}   // norm(label/name/id/data-field) → value
    };

    // (a) sync.fromFormHoSo — chuẩn nhất, keyed theo registry
    try {
      if (global.hsvSyncEngine && typeof global.hsvSyncEngine.fromFormHoSo === 'function') {
        var d = global.hsvSyncEngine.fromFormHoSo(document);
        if (d && typeof d === 'object') {
          Object.keys(d).forEach(function(k){
            var v = toNum(d[k]);
            if (v) pool.byRegKey[k] = v;
          });
        }
      }
    } catch (e) { log('fromFormHoSo error', e && e.message); }

    // (b) PA đính kèm → snapshot inputs
    try {
      var paId = global.__hsv16AttachedPaId;
      if (paId && global.HsvPaLibrary) {
        var pa = global.HsvPaLibrary.get(paId);
        if (pa && pa.snapshot && pa.snapshot.inputs) {
          var ins = pa.snapshot.inputs;
          Object.keys(ins).forEach(function(k){
            var v = toNum(ins[k]);
            if (!v) return;
            pool.byLabelNorm[norm(k)] = v;
            // Cũng thử suy registry key qua alias
            try {
              var reg = global.hsvFieldRegistry;
              if (reg) {
                var f = reg.get && reg.get(k);
                if (!f && reg.byAlias) f = reg.byAlias(k);
                if (!f && reg.byDataField) f = reg.byDataField(k);
                if (f && f.key && !pool.byRegKey[f.key]) pool.byRegKey[f.key] = v;
              }
            } catch(_){}
          });
        }
      }
    } catch (e) { log('PALib error', e && e.message); }

    // (c) IndexedDB pa_draft (async → cache riêng, kick fetch nếu chưa có)
    try {
      if (global.hsvPAExport && typeof global.hsvPAExport.loadDraft === 'function') {
        var soHD = _readSoHD();
        if (soHD) {
          if (!global.__hsvV14DraftCache) global.__hsvV14DraftCache = {};
          var cached = global.__hsvV14DraftCache[soHD];
          if (cached && typeof cached === 'object') {
            Object.keys(cached).forEach(function(k){
              var v = toNum(cached[k]);
              if (v && !pool.byRegKey[k]) pool.byRegKey[k] = v;
            });
          } else if (cached !== 'loading') {
            global.__hsvV14DraftCache[soHD] = 'loading';
            global.hsvPAExport.loadDraft(soHD).then(function(draft){
              global.__hsvV14DraftCache[soHD] = draft || {};
              _poolCache = null; // invalidate
              scheduleRender();
            }).catch(function(){ global.__hsvV14DraftCache[soHD] = {}; });
          }
        }
      }
    } catch (e) { log('loadDraft error', e && e.message); }

    // (d) DOM loose-scan — bổ sung label→value từ mọi input hiện tại
    try {
      var nodes = document.querySelectorAll(
        'input[type="text"],input[type="number"],input:not([type]),textarea,select'
      );
      for (var i=0; i<nodes.length; i++) {
        var el = nodes[i];
        var v = toNum(el.value);
        if (!v) continue;

        // 1) data-field / name / id / aria-label
        ['data-field','name','id','aria-label','placeholder'].forEach(function(attr){
          var a = el.getAttribute(attr);
          if (a) {
            var k = norm(a);
            if (k && !pool.byLabelNorm[k]) pool.byLabelNorm[k] = v;
          }
        });

        // 2) Label liền kề trong cùng row
        try {
          var row = el.closest && el.closest('tr, .field-row, .form-row, .hsv-row, .grid, .row, [class*="row"]');
          if (row) {
            var labelEls = row.querySelectorAll('label, .field-label, .hsv-label, td, th');
            for (var j=0; j<labelEls.length; j++) {
              var t = (labelEls[j].textContent || '').trim();
              if (!t || t.length > 80) continue;
              var kk = norm(t);
              if (kk && !pool.byLabelNorm[kk]) pool.byLabelNorm[kk] = v;
            }
          }
          // 3) prevElementSibling text (patterns có label rời)
          var prev = el.previousElementSibling;
          if (prev) {
            var pt = (prev.textContent || '').trim();
            if (pt && pt.length < 80) {
              var pk = norm(pt);
              if (pk && !pool.byLabelNorm[pk]) pool.byLabelNorm[pk] = v;
            }
          }
        } catch(_){}
      }
    } catch (e) { log('DOM scan error', e && e.message); }

    _poolCache = pool;
    _poolCacheAt = now;
    return pool;
  }

  function _readSoHD(){
    try {
      var el = document.querySelector('[data-field="Số hợp đồng"],[name="soHD"],#soHD, [data-field="HĐTD"], [name="hdtd"], #hdtd');
      var v = el && (el.value || el.textContent || '').trim();
      return v || null;
    } catch(_) { return null; }
  }

  function lookup(labelHienThi, pool){
    var key = norm(labelHienThi);
    var aliases = ALIAS[key] || [key];
    for (var i=0; i<aliases.length; i++) {
      var a = aliases[i];
      if (a && a.charAt(0) === '@') {
        var regKey = a.slice(1);
        if (pool.byRegKey[regKey]) return pool.byRegKey[regKey];
      } else {
        if (pool.byLabelNorm[a]) return pool.byLabelNorm[a];
        // Cũng thử partial match cho các label dài
        var keys = Object.keys(pool.byLabelNorm);
        for (var j=0; j<keys.length; j++) {
          var k = keys[j];
          if (k === a || k.indexOf(a) >= 0 || a.indexOf(k) >= 0) {
            if (pool.byLabelNorm[k]) return pool.byLabelNorm[k];
          }
        }
      }
    }
    return null;
  }

  /* ── Patch giá trị cho một sidebar element ────────────────────── */
  function patchSummary(summaryEl){
    if (!summaryEl) return { patched: 0, total: 0 };
    var pool = buildPool(false);
    var rows = summaryEl.querySelectorAll('.hsv16-row');
    var patched = 0;
    for (var i=0; i<rows.length; i++) {
      var kEl = rows[i].querySelector('.k');
      var vEl = rows[i].querySelector('.v');
      if (!kEl || !vEl) continue;
      // HSV-FIX v19 (2026-07-17): nếu hàng này đã được patch trước đó VÀ
      // giá trị thật là 0 (vd "Vốn vay TCTD khác"), text hiển thị vẫn là
      // "0 đ" → vẫn khớp điều kiện isEmpty bên dưới mỗi lần chạy, khiến
      // hàng bị ghi lại textContent liên tục dù giá trị không đổi (mỗi
      // lần ghi là 1 mutation, tự kích observer chạy lại → nháy vô hạn).
      // Bỏ qua hẳn các hàng đã đánh dấu patched, không xét lại.
      if (vEl.hasAttribute('data-fixv14')) continue;
      var rawText = (vEl.textContent || '').trim();
      var isEmpty = !rawText || /^0\s*đ?$/.test(rawText) || rawText === '—' || rawText === '-';
      if (!isEmpty) continue;
      var label = kEl.textContent || '';
      // Skip nếu là hàng %/ratio đã có ký hiệu — vẫn thử patch nếu 0.0%
      var isPct = /%/.test(rawText) || /%/.test(label);
      var val = lookup(label, pool);
      if (val == null) continue;
      var newText = isPct ? (val.toFixed(2).replace(/\.00$/, '.0') + '%') : fmtVND(val);
      // Chỉ ghi DOM khi giá trị thực sự đổi — tránh mutation vô ích
      if (newText !== rawText) vEl.textContent = newText;
      vEl.classList.remove('neg');
      if (val > 0) vEl.classList.add('pos');
      vEl.setAttribute('data-fixv14', '1');
      patched++;
    }
    if (patched > 0) log('patched', patched, '/', rows.length, 'rows');
    return { patched: patched, total: rows.length };
  }

  /* ── Observer + hooks ─────────────────────────────────────────── */
  var _renderTimer = null;
  function scheduleRender(){
    if (_renderTimer) return;
    _renderTimer = setTimeout(function(){
      _renderTimer = null;
      _poolCache = null;
      document.querySelectorAll('#hsv16-summary').forEach(function(el){ patchSummary(el); });
      // Cả trong iframe same-origin
      try {
        document.querySelectorAll('iframe').forEach(function(f){
          try {
            var d = f.contentDocument;
            if (d) d.querySelectorAll('#hsv16-summary').forEach(function(el){ patchSummary(el); });
          } catch(_){}
        });
      } catch(_){}
    }, 60);
  }

  function attachObserver(doc){
    doc = doc || document;
    try {
      if (doc.__hsvFixV14Obs) return;
      var mo = new MutationObserver(function(muts){
        for (var i=0; i<muts.length; i++) {
          var m = muts[i];
          // Trigger nếu #hsv16-summary bị re-render (childList change bên trong)
          var target = m.target;
          if (!target) continue;
          if (target.id === 'hsv16-summary' ||
              (target.closest && target.closest('#hsv16-summary')) ||
              (m.addedNodes && [].some.call(m.addedNodes, function(n){
                return n && n.nodeType === 1 && (n.id === 'hsv16-summary' || (n.querySelector && n.querySelector('#hsv16-summary')));
              }))) {
            scheduleRender();
            return;
          }
        }
      });
      mo.observe(doc.body || doc.documentElement, { childList: true, subtree: true });
      doc.__hsvFixV14Obs = mo;
    } catch(e){ log('observer error', e && e.message); }
  }

  function attachInputListener(doc){
    doc = doc || document;
    if (doc.__hsvFixV14Input) return;
    doc.__hsvFixV14Input = true;
    var t = null;
    var handler = function(ev){
      var el = ev && ev.target;
      if (!el) return;
      if (!/^(INPUT|SELECT|TEXTAREA)$/.test(el.tagName || '')) return;
      // Skip nếu chính sidebar
      if (el.closest && el.closest('#hsv16-summary')) return;
      clearTimeout(t);
      t = setTimeout(scheduleRender, 250);
    };
    doc.addEventListener('input', handler, true);
    doc.addEventListener('change', handler, true);
  }

  function attachBus(){
    try {
      var bus = global.hsvBus || global.bus;
      if (bus && typeof bus.on === 'function' && !global.__hsvFixV14Bus) {
        global.__hsvFixV14Bus = true;
        ['pa_sxkd:imported', 'pa:updated', 'form:hoso:changed', 'hsv:sync'].forEach(function(evt){
          try { bus.on(evt, scheduleRender); } catch(_){}
        });
        log('bus hooked');
      }
    } catch(_){}
  }

  /* ── Boot ─────────────────────────────────────────────────────── */
  function boot(){
    attachObserver(document);
    attachInputListener(document);
    attachBus();
    // Also attempt iframes
    try {
      document.querySelectorAll('iframe').forEach(function(f){
        try {
          var d = f.contentDocument;
          if (d) { attachObserver(d); attachInputListener(d); }
        } catch(_){}
      });
    } catch(_){}
    scheduleRender();
    log('boot ok');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
  // Kick lại vài lần sau boot để cover render trễ
  setTimeout(scheduleRender, 500);
  setTimeout(scheduleRender, 1500);
  setTimeout(scheduleRender, 3500);
  setTimeout(function(){ attachBus(); scheduleRender(); }, 6000);

  // Expose API để QA
  global.hsvFixV14 = {
    version: 'v14.0.0',
    rerender: scheduleRender,
    patchSummary: patchSummary,
    buildPool: function(){ return buildPool(true); },
    lookup: function(label){ return lookup(label, buildPool(true)); }
  };
})(typeof window !== 'undefined' ? window : this);
