/* HSV v25.5 FIX v13 — Overlay JS
   Bước 2 (Save + toast), 3 (đảm bảo panel phải luôn render),
   6 (giảm chập chờn hàm F), 7 (bỏ placeholder "0"), 9 (statusbar)
*/
(function(){
  'use strict';
  var READY = false;
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded',fn); }

  /* ---------- Bước 2: Toast + nút Save ---------- */
  function v13Toast(msg){
    var t = document.getElementById('v13-toast');
    if (!t){ t=document.createElement('div'); t.id='v13-toast'; document.body.appendChild(t); }
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._h); t._h = setTimeout(function(){ t.classList.remove('show'); }, 1600);
  }
  window.v13Toast = v13Toast;

  function updateSaveBadge(){
    var el = document.getElementById('v13-save-badge');
    if (el) el.textContent = 'Đã lưu ' + new Date().toLocaleTimeString('vi-VN');
  }

  function wrapPersistStore(){
    if (window.__v13_ps__ || typeof window.persistStore !== 'function') return;
    window.__v13_ps__ = true;
    var _orig = window.persistStore;
    window.persistStore = function(){
      var r = _orig.apply(this, arguments);
      try { v13Toast('✓ Đã lưu ' + new Date().toLocaleTimeString('vi-VN')); updateSaveBadge(); } catch(e){}
      return r;
    };
  }

  function addSaveNavBtn(){
    if (document.getElementById('v13-nav-save')) return;
    var nav = document.querySelector('header nav'); if (!nav) return;
    var b = document.createElement('a');
    b.id='v13-nav-save'; b.href='#'; b.className='nav-btn v13-save-btn';
    b.innerHTML = '<svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg> Lưu';
    b.title = 'Lưu hồ sơ (Ctrl+S)';
    b.onclick = function(e){ e.preventDefault();
      try { if (typeof window.persistStore==='function') window.persistStore(); else v13Toast('✓ Đã lưu'); } catch(err){ v13Toast('Lỗi lưu: '+err.message); }
    };
    nav.appendChild(b);
  }

  /* ---------- Bước 9: Status bar dưới cùng ---------- */
  function buildStatusBar(){
    if (document.getElementById('v13-statusbar')) return;
    var sb = document.createElement('div'); sb.id='v13-statusbar';
    sb.innerHTML = '<span class="v13-save-badge" id="v13-save-badge">Chưa lưu</span>'
                 + '<span class="v13-spacer"></span>'
                 + '<span id="v13-slot-help"></span>'
                 + '<span id="v13-slot-check"></span>'
                 + '<span id="v13-slot-cloud"></span>'
                 + '<span id="v13-slot-version"></span>';
    document.body.appendChild(sb);
  }
  function moveFabsIntoStatusBar(){
    var helpSlot   = document.getElementById('v13-slot-help');
    var checkSlot  = document.getElementById('v13-slot-check');
    var cloudSlot  = document.getElementById('v13-slot-cloud');
    var verSlot    = document.getElementById('v13-slot-version');
    if (!helpSlot) return;
    var help = document.getElementById('np7-help-btn');
    var chk  = document.getElementById('hsv-v253-fab');
    var cld  = document.getElementById('hsvCloudFab');
    var ver  = document.getElementById('hsvUp-fab');
    if (help && help.parentElement !== helpSlot)  helpSlot.appendChild(help);
    if (chk  && chk.parentElement  !== checkSlot) checkSlot.appendChild(chk);
    if (cld  && cld.parentElement  !== cloudSlot) cloudSlot.appendChild(cld);
    if (ver  && ver.parentElement  !== verSlot)   verSlot.appendChild(ver);
  }

  /* ---------- Bước 7: Bỏ placeholder "0" trong input tự nhập ---------- */
  function cleanPlaceholders(root){
    var scope = root && root.querySelectorAll ? root : document;
    var ins = scope.querySelectorAll('input[placeholder="0"], input[placeholder="0,00"], input[placeholder="0.00"]');
    ins.forEach(function(el){ el.setAttribute('placeholder',''); });
  }

  /* ---------- Bước 5 (bổ trợ): thay " đ" ở text bảng bằng &nbsp;đ ---------- */
  function fixMoneyWrap(root){
    var scope = root && root.querySelectorAll ? root : document;
    var cells = scope.querySelectorAll('.smart-panel td, .smart-panel .val, #hsv16-summary td, .num-cell');
    cells.forEach(function(el){
      // Only leaf text nodes
      if (el.children.length === 0){
        var t = el.textContent;
        if (t && /\s+đ\s*$/.test(t)) el.textContent = t.replace(/\s+đ\s*$/, '\u00A0đ');
      }
    });
  }

  /* ---------- Bước 6 (giảm chập chờn hàm F): re-open on focus ---------- */
  // Popover hàm F chập chờn do re-render xoá popover đang mở.
  // Ghim class trên field-row đang mở popover và cho phép re-mount idempotent.
  function stabilizeFormulaPopover(){
    if (window.__v13_fpop__) return;
    window.__v13_fpop__ = true;
    // Sau mỗi mutation, nếu field đang focus có popover công thức thì giữ hiển thị
    var mo = new MutationObserver(function(){
      var f = document.activeElement;
      if (!f || !f.matches || !f.matches('input,textarea')) return;
      var row = f.closest('.field-row');
      if (!row) return;
      var badge = row.querySelector('.hint-icon, .formula-badge');
      if (badge && row.classList.contains('v13-fpop-open')){
        // Đảm bảo tooltip vẫn hiển thị
        var tt = row.querySelector('.hint-tooltip, .formula-popover');
        if (tt) tt.style.display = 'block';
      }
    });
    mo.observe(document.body, {childList:true, subtree:true});
    document.addEventListener('mouseenter', function(e){
      if (e.target.classList && e.target.classList.contains && e.target.classList.contains('hint-icon')){
        var row = e.target.closest('.field-row');
        if (row) row.classList.add('v13-fpop-open');
      }
    }, true);
    document.addEventListener('mouseleave', function(e){
      if (e.target.classList && e.target.classList.contains && e.target.classList.contains('hint-icon')){
        var row = e.target.closest('.field-row');
        if (row) row.classList.remove('v13-fpop-open');
      }
    }, true);
  }

  /* ---------- Global observer chạy các bước 5,7,9 mỗi khi DOM thay đổi ---------- */
  function installObserver(){
    var mo = new MutationObserver(function(muts){
      var need = false;
      for (var i=0;i<muts.length;i++){ if (muts[i].addedNodes && muts[i].addedNodes.length){ need=true; break; } }
      if (!need) return;
      cleanPlaceholders(document);
      fixMoneyWrap(document);
      moveFabsIntoStatusBar();
      addSaveNavBtn();
      wrapPersistStore();
    });
    mo.observe(document.body, {childList:true, subtree:true});
  }

  /* ---------- Ctrl+S ---------- */
  document.addEventListener('keydown', function(e){
    if ((e.ctrlKey||e.metaKey) && (e.key==='s'||e.key==='S')){
      e.preventDefault();
      try { if (typeof window.persistStore==='function') window.persistStore(); else v13Toast('✓ Đã lưu'); } catch(err){}
    }
  });

  ready(function(){
    buildStatusBar();
    addSaveNavBtn();
    wrapPersistStore();
    cleanPlaceholders(document);
    fixMoneyWrap(document);
    stabilizeFormulaPopover();
    moveFabsIntoStatusBar();
    installObserver();
    // Retry a few times as FABs mount async
    var n=0; var iv=setInterval(function(){
      moveFabsIntoStatusBar(); addSaveNavBtn(); wrapPersistStore();
      if (++n>20) clearInterval(iv);
    }, 400);
    console.log('[HSV v13] Overlay fix loaded');
  });
})();
