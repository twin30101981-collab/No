/* HSV SAFE v25.6.0 — Export / Import JSON */
(function () {
  'use strict';
  if (window.__hsv_v2560_bkp) return;
  window.__hsv_v2560_bkp = true;

  function exportJson() {
    var as = window.HSVSafe.modules.autosave;
    var snap = as ? as.collect() : { fields: {}, ts: Date.now(), version: '25.6.0' };
    snap.exportedAt = new Date().toISOString();
    var blob = new Blob([JSON.stringify(snap, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'hsv-backup-' + new Date().toISOString().replace(/[:.]/g, '-') + '.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 5000);
    if (window.HSVSafe.toast) window.HSVSafe.toast('Đã xuất backup JSON');
  }

  function importJsonFile(file) {
    return file.text().then(function (txt) {
      var data;
      try { data = JSON.parse(txt); }
      catch (e) { alert('File không phải JSON hợp lệ'); return; }
      if (!data || !data.fields) { alert('File thiếu trường "fields"'); return; }
      var n = Object.keys(data.fields).length;
      if (!confirm('Ghi đè ' + n + ' ô từ backup ngày ' +
        new Date(data.ts || data.exportedAt || Date.now()).toLocaleString('vi-VN') + '?')) return;
      var as = window.HSVSafe.modules.autosave;
      var restored = as ? as.restore(data) : 0;
      alert('Đã nhập ' + restored + ' / ' + n + ' ô.');
    });
  }

  function mountSidebar() {
    var sb = document.getElementById('wizard-sidebar') ||
             document.querySelector('.wizard-sidebar, [class*="sidebar"]');
    // FIX v23: điều kiện cũ `!sb || sb.querySelector('.hsv-sidebar-actions')`
    // khiến lần gọi lặp lại (setTimeout 2s/5s để phòng sidebar mount muộn) rơi
    // vào nhánh fallback NGAY CẢ KHI đã gắn nút vào sidebar thật ở lần gọi
    // trước — tạo thêm 1 khối nút nổi trùng lặp ở góc màn hình. Đã tách rõ 3
    // trường hợp: (1) sidebar có rồi & đã có nút → không làm gì; (2) sidebar
    // có, chưa có nút → gắn vào sidebar; (3) không có sidebar → dùng fallback.
    if (sb && sb.querySelector('.hsv-sidebar-actions')) return; // đã gắn vào sidebar thật rồi
    if (!sb) {
      // Fallback: put in body top-left corner
      if (document.getElementById('hsv-bkp-fallback')) return;
      var box = document.createElement('div');
      box.id = 'hsv-bkp-fallback';
      box.className = 'hsv-sidebar-actions';
      box.style.cssText = 'position:fixed;left:12px;bottom:12px;z-index:99996;background:#fff;padding:6px;border:1px solid #cbd5e1;border-radius:8px;box-shadow:0 2px 6px rgba(0,0,0,.08);';
      box.appendChild(makeBtn());
      box.appendChild(makeImportBtn());
      document.body.appendChild(box);
      return;
    }
    var wrap = document.createElement('div');
    wrap.className = 'hsv-sidebar-actions';
    wrap.appendChild(makeBtn());
    wrap.appendChild(makeImportBtn());
    sb.appendChild(wrap);
  }

  function makeBtn() {
    var b = document.createElement('button');
    b.type = 'button';
    b.textContent = '💾 Sao lưu JSON';
    b.setAttribute('aria-label', 'Sao lưu hồ sơ ra file JSON');
    b.addEventListener('click', exportJson);
    return b;
  }
  function makeImportBtn() {
    var b = document.createElement('button');
    b.type = 'button';
    b.textContent = '📥 Nhập JSON';
    b.setAttribute('aria-label', 'Nhập hồ sơ từ file JSON');
    b.addEventListener('click', function () {
      var inp = document.createElement('input');
      inp.type = 'file';
      inp.accept = 'application/json,.json';
      inp.addEventListener('change', function () {
        if (inp.files && inp.files[0]) importJsonFile(inp.files[0]);
      });
      inp.click();
    });
    return b;
  }

  if (document.body) mountSidebar();
  else document.addEventListener('DOMContentLoaded', mountSidebar, { once: true });
  // Also on later mount
  setTimeout(mountSidebar, 2000);
  setTimeout(mountSidebar, 5000);

  window.HSVSafe.modules.backup = { export: exportJson, importFile: importJsonFile };
})();
