/* HSV SAFE v25.6.0 — iOS Safari fixes */
(function () {
  'use strict';
  if (window.__hsv_v2560_ios) return;
  window.__hsv_v2560_ios = true;

  function setVh() {
    var h = (window.visualViewport && window.visualViewport.height) || window.innerHeight;
    document.documentElement.style.setProperty('--hsv-vh', (h * 0.01) + 'px');
  }
  setVh();
  window.addEventListener('resize', setVh, { passive: true });
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', setVh, { passive: true });
  }

  window.HSVSafe.modules.ios = { setVh: setVh };
})();
