/* HSV SAFE v25.6.0 — Print hooks (add doc title + timestamp header via CSS counters when possible) */
(function () {
  'use strict';
  if (window.__hsv_v2560_print) return;
  window.__hsv_v2560_print = true;

  window.addEventListener('beforeprint', function () {
    document.documentElement.classList.add('hsv-printing');
    // Ensure long tables get thead repeated (CSS already handles). Nothing else needed.
  });
  window.addEventListener('afterprint', function () {
    document.documentElement.classList.remove('hsv-printing');
  });

  window.HSVSafe.modules.print = { trigger: function () { window.print(); } };
})();
