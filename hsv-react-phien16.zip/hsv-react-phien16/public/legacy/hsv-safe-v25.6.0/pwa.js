/* HSV SAFE v25.6.0 — PWA registration (only under http/https; skipped on file://) */
(function () {
  'use strict';
  if (window.__hsv_v2560_pwa) return;
  window.__hsv_v2560_pwa = true;

  var proto = location.protocol;
  if (proto !== 'http:' && proto !== 'https:') {
    console.log('[HSVSafe/pwa] skipped (protocol=' + proto + ')');
    return;
  }
  if (!('serviceWorker' in navigator)) return;

  var params = new URLSearchParams(location.search);
  if (params.get('sw') === 'off') {
    navigator.serviceWorker.getRegistrations().then(function (regs) {
      regs.forEach(function (r) { r.unregister(); });
    });
    console.log('[HSVSafe/pwa] service worker unregistered via ?sw=off');
    return;
  }

  // Inject manifest
  if (!document.querySelector('link[rel="manifest"][data-hsv]')) {
    var l = document.createElement('link');
    l.rel = 'manifest';
    l.href = 'hsv-safe-v25.6.0/manifest.webmanifest';
    l.setAttribute('data-hsv', '1');
    document.head.appendChild(l);
  }

  window.addEventListener('load', function () {
    navigator.serviceWorker.register('hsv-safe-sw.js', { scope: './' })
      .then(function (reg) {
        console.log('[HSVSafe/pwa] registered', reg.scope);
        reg.addEventListener('updatefound', function () {
          var nw = reg.installing;
          if (!nw) return;
          nw.addEventListener('statechange', function () {
            if (nw.state === 'installed' && navigator.serviceWorker.controller) {
              try { window.HSVSafe && window.HSVSafe.toast && window.HSVSafe.toast('Đã có bản cập nhật — làm mới để dùng'); } catch (e) {}
            }
          });
        });
      })
      .catch(function (e) { console.warn('[HSVSafe/pwa] register fail', e); });
  });

  window.HSVSafe.modules.pwa = { registered: true };
})();
