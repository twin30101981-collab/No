/* HSV SAFE v25.6.0 — Templates lazy-load helper (does NOT unload existing script; only shows spinner if consumers query before ready) */
(function () {
  'use strict';
  if (window.__hsv_v2560_tpl) return;
  window.__hsv_v2560_tpl = true;

  function ready() { return !!(window.TEMPLATES_B64 && Object.keys(window.TEMPLATES_B64).length); }

  var spinner = null;
  function showSpinner() {
    if (spinner) return;
    spinner = document.createElement('div');
    spinner.id = 'hsv-tpl-spinner';
    spinner.setAttribute('role', 'status');
    spinner.setAttribute('aria-live', 'polite');
    spinner.style.cssText = 'position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);background:rgba(15,23,42,.9);color:#fff;padding:16px 22px;border-radius:10px;z-index:100001;font:14px system-ui,sans-serif';
    spinner.textContent = 'Đang tải templates…';
    document.body.appendChild(spinner);
  }
  function hideSpinner() {
    if (spinner) { spinner.remove(); spinner = null; }
  }

  // Wrap HSVTemplates.getBase64 to show spinner on wait
  function wrap() {
    var api = window.HSVTemplates;
    if (!api || api.__hsvWrapped) return;
    var orig = api.getBase64;
    api.getBase64 = function (p) {
      if (ready()) return orig(p);
      showSpinner();
      return new Promise(function (res, rej) {
        var tries = 0;
        (function poll() {
          if (ready()) { hideSpinner(); orig(p).then(res, rej); return; }
          if (tries++ > 200) { hideSpinner(); rej(new Error('templates timeout')); return; }
          setTimeout(poll, 100);
        })();
      });
    };
    api.__hsvWrapped = true;
  }

  if (window.HSVTemplates) wrap();
  else {
    var t = setInterval(function () {
      if (window.HSVTemplates) { wrap(); clearInterval(t); }
    }, 200);
    setTimeout(function () { clearInterval(t); }, 15000);
  }

  window.HSVSafe.modules.templateLazy = { ready: ready };
})();
