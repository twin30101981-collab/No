/* ============================================================
   HSV PLUS v25.6.4 — additive-only upgrade
   - v25.6.4: v25.6.3 chỉ DỜI chip "đã lưu" từ đè FAB sang đè
     topnav (nút "XUẤT PA SXKD") — vẫn là đè UI, chỉ đổi chỗ.
     Fix triệt để: ẨN chip này theo mặc định; có nút bật lại
     trong "🛠 Công cụ hồ sơ" cho ai cần xem.
   - Feature: Auto-save version history (per case)
   - Feature: Lock hồ sơ đang mở (cross-tab)
   - Feature: Export/Import JSON hồ sơ
   - Feature: Tìm kiếm & lọc hồ sơ nhanh
   ============================================================ */
(function(){
  'use strict';
  if (window.__HSV_PLUS_V2563__) return; window.__HSV_PLUS_V2563__ = true;

  var STORE_KEY = 'hosovay-cases-v1';
  var SNAP_KEY  = 'hsv:snapshots:v1';   // { caseId: [{ts, values, assets}] }
  var LOCK_KEY  = 'hsv:locks:v1';       // { caseId: {tabId, ts, name} }
  var TAB_ID    = (Math.random().toString(36).slice(2) + Date.now().toString(36));
  var SNAP_MAX  = 20;
  var SNAP_MIN_INTERVAL_MS = 60 * 1000; // tối đa 1 snapshot / phút / hồ sơ

  function log(){ try{ console.log.apply(console,['[HSV+]'].concat([].slice.call(arguments))); }catch(_){} }
  function lsGet(k, def){ try{ var v=localStorage.getItem(k); return v?JSON.parse(v):def; }catch(_){ return def; } }
  function lsSet(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){} }
  function nowVN(){ return new Date().toLocaleString('vi-VN'); }
  function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g,function(c){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c];}); }

  /* =========================================================
     1) ROOT-CAUSE FIX v25.6.4: chip "đã lưu ..." đè UI khác
     Nguồn: app.js line ~30389 tạo [data-hsv-fix="v6-savedot"]
     Lịch sử: bản v25.6.3 từng "sửa" bằng cách dời chip từ góc
     dưới (đè FAB "ƒ Công thức") lên góc trên-phải — nhưng góc
     trên-phải lại đúng chỗ topnav đặt nút "XUẤT PA SXKD", nên
     chip vẫn đè UI, chỉ đổi chỗ đè. Vì chip là 1 layer
     position:fixed độc lập, dời đi đâu trên màn hình cũng có
     nguy cơ đè lên topnav/FAB/toolbar đang chạy ở đó.
     Giải pháp triệt để: ẨN HẲN chip này theo mặc định (nó chỉ
     là hiển thị phụ, không mang chức năng — các thao tác lưu
     quan trọng đã có toast "✓ Đã lưu ..." riêng). Người dùng
     nào vẫn muốn xem có thể bật lại trong "🛠 Công cụ hồ sơ".
     ========================================================= */
  (function fixSaveDot(){
    var css = ''
      /* Mặc định: ẩn hoàn toàn, không chiếm layer nào cả */
      + '[data-hsv-fix="v6-savedot"]{ display:none !important; }'
      /* Chỉ hiện khi người dùng chủ động bật trong Công cụ */
      + 'html.hsv-show-savedot [data-hsv-fix="v6-savedot"]{'
      + '  display:block !important;'
      + '  position:fixed !important;'
      + '  right:6px !important; top:2px !important; bottom:auto !important;'
      + '  left:auto !important;'
      + '  z-index:1000 !important;'
      + '  font-size:10.5px !important;'
      + '  padding:2px 8px !important;'
      + '  background:rgba(0,0,0,.35) !important;'
      + '  color:#fff !important;'
      + '  border-radius:10px !important;'
      + '  pointer-events:none !important;'
      + '  opacity:.85 !important;'
      + '  max-width:60vw; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;'
      + '}'
      + '@media print{[data-hsv-fix="v6-savedot"]{display:none !important;}}'
      ;
    var st = document.createElement('style'); st.setAttribute('data-hsv','plus-savedot'); st.textContent = css;
    (document.head||document.documentElement).appendChild(st);
  })();

  /* =========================================================
     2) Helpers dùng chung
     ========================================================= */
  function getCases(){
    try { return JSON.parse(localStorage.getItem(STORE_KEY)||'{}') || {}; } catch(_){ return {}; }
  }
  function getCurrentCaseId(){
    try { return (window.currentCaseId) || null; } catch(_){ return null; }
  }
  function getCurrentCase(){
    var id = getCurrentCaseId(); if (!id) return null;
    var cs = (window.store && window.store.cases) || getCases();
    return cs[id] || null;
  }

  /* =========================================================
     3) Auto-save version history (snapshots per case)
     ========================================================= */
  var lastSnapAt = {};
  function snapshotCurrentCase(reason){
    var c = getCurrentCase(); if (!c) return;
    var id = c.id;
    var t = Date.now();
    if (lastSnapAt[id] && (t - lastSnapAt[id]) < SNAP_MIN_INTERVAL_MS) return;
    lastSnapAt[id] = t;
    var all = lsGet(SNAP_KEY, {}) || {};
    var arr = all[id] || [];
    var snap = {
      ts: t,
      reason: reason||'auto',
      customerName: c.customerName||'',
      values: JSON.parse(JSON.stringify(c.values||{})),
      assets: JSON.parse(JSON.stringify(c.assets||[])),
      _sxkd: c._sxkd ? JSON.parse(JSON.stringify(c._sxkd)) : undefined
    };
    arr.unshift(snap);
    if (arr.length > SNAP_MAX) arr.length = SNAP_MAX;
    all[id] = arr;
    lsSet(SNAP_KEY, all);
  }
  // Hook: mỗi khi STORE_KEY được ghi, tạo snapshot có throttle
  (function hookStore(){
    try {
      var _set = Storage.prototype.setItem;
      Storage.prototype.setItem = function(k, v){
        var r = _set.apply(this, arguments);
        if (this === localStorage && k === STORE_KEY){
          try { snapshotCurrentCase('save'); } catch(_){}
        }
        return r;
      };
    } catch(_){}
  })();

  function restoreSnapshot(caseId, index){
    var all = lsGet(SNAP_KEY, {}) || {};
    var arr = all[caseId] || []; var s = arr[index]; if (!s) return false;
    var cases = (window.store && window.store.cases) || getCases();
    var c = cases[caseId]; if (!c) return false;
    // Backup phiên bản hiện tại trước khi restore
    snapshotCurrentCase('pre-restore');
    c.values = JSON.parse(JSON.stringify(s.values||{}));
    c.assets = JSON.parse(JSON.stringify(s.assets||[]));
    if (s._sxkd) c._sxkd = JSON.parse(JSON.stringify(s._sxkd));
    c.updatedAt = Date.now();
    if (window.store) window.store.cases[caseId] = c;
    try { localStorage.setItem(STORE_KEY, JSON.stringify((window.store&&window.store.cases)||cases)); } catch(_){}
    try { if (typeof window.navigate === 'function') window.navigate('editor', caseId); else location.reload(); } catch(_){ location.reload(); }
    return true;
  }

  /* =========================================================
     4) Cross-tab lock cho hồ sơ đang mở
     ========================================================= */
  function acquireLock(caseId, name){
    if (!caseId) return;
    var locks = lsGet(LOCK_KEY, {}) || {};
    var l = locks[caseId];
    var t = Date.now();
    // Lock hết hạn sau 30s không heartbeat
    if (l && l.tabId !== TAB_ID && (t - (l.ts||0)) < 30000){
      showLockWarning(l);
    }
    locks[caseId] = { tabId: TAB_ID, ts: t, name: name||'' };
    lsSet(LOCK_KEY, locks);
  }
  function releaseLock(caseId){
    var locks = lsGet(LOCK_KEY, {}) || {};
    if (locks[caseId] && locks[caseId].tabId === TAB_ID){ delete locks[caseId]; lsSet(LOCK_KEY, locks); }
  }
  function showLockWarning(l){
    var bar = document.getElementById('hsv-plus-lockbar');
    if (!bar){
      bar = document.createElement('div'); bar.id='hsv-plus-lockbar';
      bar.style.cssText = 'position:fixed;left:0;right:0;top:0;z-index:100000;background:#f59e0b;color:#111;padding:6px 12px;font:600 12px/1.4 system-ui;text-align:center;box-shadow:0 1px 4px rgba(0,0,0,.2);';
      document.body.appendChild(bar);
    }
    bar.textContent = '⚠ Hồ sơ này đang mở ở tab khác — chỉnh sửa có thể ghi đè nhau. (tab: '+(l.tabId||'').slice(0,6)+')';
    setTimeout(function(){ if (bar) bar.remove(); }, 8000);
  }
  // Heartbeat + hook navigate
  setInterval(function(){ var id=getCurrentCaseId(); if (id) acquireLock(id, (getCurrentCase()||{}).customerName); }, 10000);
  window.addEventListener('beforeunload', function(){ var id=getCurrentCaseId(); if (id) releaseLock(id); });

  /* =========================================================
     5) Export / Import JSON hồ sơ (hiện tại hoặc toàn bộ)
     ========================================================= */
  function exportCurrent(){
    var c = getCurrentCase();
    if (!c){ alert('Chưa mở hồ sơ nào.'); return; }
    var payload = { __hsv:'case', version:1, exportedAt:new Date().toISOString(), case:c };
    var blob = new Blob([JSON.stringify(payload,null,2)], {type:'application/json'});
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'hoso-'+(c.customerName||c.id).replace(/[^\w\-]+/g,'_')+'-'+Date.now()+'.json';
    a.click();
  }
  function exportAll(){
    var cs = (window.store && window.store.cases) || getCases();
    var payload = { __hsv:'cases', version:1, exportedAt:new Date().toISOString(), cases:cs };
    var blob = new Blob([JSON.stringify(payload,null,2)], {type:'application/json'});
    var a = document.createElement('a'); a.href=URL.createObjectURL(blob);
    a.download = 'hsv-all-cases-'+Date.now()+'.json'; a.click();
  }
  function importFromFile(file, mode){
    var fr = new FileReader();
    fr.onload = function(){
      try {
        var obj = JSON.parse(fr.result);
        var cases = (window.store && window.store.cases) || getCases();
        var added = 0;
        function put(c){
          if (!c || !c.id) return;
          var id = c.id;
          if (cases[id] && mode !== 'overwrite'){
            id = c.id + '-imp-' + Date.now().toString(36);
            c = Object.assign({}, c, { id:id });
          }
          cases[id] = c; added++;
        }
        if (obj && obj.__hsv === 'case' && obj.case) put(obj.case);
        else if (obj && obj.__hsv === 'cases' && obj.cases) Object.values(obj.cases).forEach(put);
        else if (obj && typeof obj === 'object') Object.values(obj).forEach(put);
        if (window.store) window.store.cases = cases;
        localStorage.setItem(STORE_KEY, JSON.stringify(cases));
        alert('Đã nhập '+added+' hồ sơ. Sẽ tải lại trang.');
        location.reload();
      } catch(e){ alert('File JSON không hợp lệ: '+e.message); }
    };
    fr.readAsText(file);
  }

  /* =========================================================
     6) Tìm kiếm & lọc hồ sơ nhanh — cắm vào trang Home
     ========================================================= */
  function ensureSearchBar(){
    // Trang Hồ sơ có danh sách case; cắm ô search ở đầu #main-content
    var main = document.getElementById('main-content'); if (!main) return;
    if (document.getElementById('hsv-plus-search-wrap')) return;
    // chỉ hiện ở view "home" (có nút Hồ sơ active)
    var homeBtn = document.getElementById('nav-home');
    if (!homeBtn || !/active/.test(homeBtn.className||'')) return;
    var wrap = document.createElement('div');
    wrap.id = 'hsv-plus-search-wrap';
    wrap.style.cssText = 'display:flex;gap:8px;align-items:center;padding:10px 12px;background:#f8faf7;border-bottom:1px solid #e5e7eb;position:sticky;top:0;z-index:50;';
    wrap.innerHTML =
      '<input id="hsv-plus-search" type="search" placeholder="Tìm hồ sơ theo tên, mã KH, sản phẩm..." '
      + 'style="flex:1;padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px;font-size:14px;outline:none;background:#fff" />'
      + '<button id="hsv-plus-tools" type="button" title="Công cụ nâng cao" '
      + 'style="padding:8px 12px;border:1px solid #2e7d32;background:#2e7d32;color:#fff;border-radius:8px;font-weight:600;cursor:pointer">Công cụ</button>';
    main.insertBefore(wrap, main.firstChild);
    var q = document.getElementById('hsv-plus-search');
    q.addEventListener('input', filterCaseList);
    document.getElementById('hsv-plus-tools').addEventListener('click', openTools);
  }
  function filterCaseList(){
    var q = (document.getElementById('hsv-plus-search')||{}).value||''; q = q.trim().toLowerCase();
    // Danh sách hồ sơ thường là các thẻ trong #main-content với thông tin tên/mã.
    var main = document.getElementById('main-content'); if (!main) return;
    var cards = main.querySelectorAll('[data-case-id], .case-card, .case-item, .hs-card');
    if (!cards.length){
      // fallback: các thẻ trực tiếp trong main (loại wrap của mình)
      cards = main.querySelectorAll('main > *, section > *, .list > *');
    }
    cards.forEach(function(el){
      if (el.id === 'hsv-plus-search-wrap') return;
      var t = (el.textContent||'').toLowerCase();
      el.style.display = (!q || t.indexOf(q) >= 0) ? '' : 'none';
    });
  }
  // Quan sát DOM để nhúng search bar sau khi render
  var moSearch = new MutationObserver(function(){ try{ ensureSearchBar(); }catch(_){} });
  moSearch.observe(document.documentElement, {childList:true, subtree:true});

  /* =========================================================
     7) Bảng điều khiển "Công cụ" (modal) — gộp mọi tính năng
     ========================================================= */
  function openTools(){
    closeTools();
    var ov = document.createElement('div'); ov.id='hsv-plus-modal';
    ov.style.cssText='position:fixed;inset:0;z-index:100001;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;padding:16px;';
    ov.innerHTML =
      '<div style="background:#fff;max-width:640px;width:100%;max-height:85vh;overflow:auto;border-radius:12px;box-shadow:0 20px 50px rgba(0,0,0,.3);font-family:system-ui,sans-serif">'
      + '<div style="padding:14px 16px;border-bottom:1px solid #e5e7eb;display:flex;align-items:center;gap:8px">'
      +   '<strong style="flex:1;font-size:15px">🛠 Công cụ hồ sơ</strong>'
      +   '<button id="hsv-plus-close" style="border:0;background:transparent;font-size:22px;cursor:pointer">×</button>'
      + '</div>'
      + '<div style="padding:16px;display:grid;gap:14px">'
      +   '<section><h4 style="margin:0 0 6px;font-size:13px;color:#374151">Xuất / Nhập JSON</h4>'
      +     '<div style="display:flex;gap:8px;flex-wrap:wrap">'
      +       '<button class="hsv-plus-btn" data-act="exp-cur">Xuất hồ sơ hiện tại</button>'
      +       '<button class="hsv-plus-btn" data-act="exp-all">Xuất toàn bộ</button>'
      +       '<label class="hsv-plus-btn" style="cursor:pointer;background:#0ea5e9">Nhập JSON…<input id="hsv-plus-imp" type="file" accept="application/json" style="display:none"></label>'
      +     '</div>'
      +     '<div style="font-size:11px;color:#6b7280;margin-top:6px">Nhập trùng ID sẽ tự đặt lại ID để không ghi đè.</div>'
      +   '</section>'
      +   '<section><h4 style="margin:0 0 6px;font-size:13px;color:#374151">Lịch sử phiên bản (hồ sơ hiện tại)</h4>'
      +     '<div id="hsv-plus-snaps" style="max-height:260px;overflow:auto;border:1px solid #e5e7eb;border-radius:8px"></div>'
      +   '</section>'
      +   '<section><h4 style="margin:0 0 6px;font-size:13px;color:#374151">Hiển thị</h4>'
      +     '<label style="display:flex;gap:8px;align-items:center;font-size:13px">'
      +       '<input id="hsv-plus-hidesave" type="checkbox"> Hiện chip "đã lưu" ở góc màn hình (mặc định đang ẩn)'
      +     '</label>'
      +   '</section>'
      + '</div></div>';
    document.body.appendChild(ov);
    // style buttons
    var st = document.createElement('style'); st.textContent = '.hsv-plus-btn{border:0;background:#2e7d32;color:#fff;padding:8px 12px;border-radius:8px;font-weight:600;cursor:pointer;font-size:13px}';
    ov.appendChild(st);
    ov.addEventListener('click', function(e){ if (e.target === ov) closeTools(); });
    document.getElementById('hsv-plus-close').onclick = closeTools;
    ov.querySelector('[data-act="exp-cur"]').onclick = exportCurrent;
    ov.querySelector('[data-act="exp-all"]').onclick = exportAll;
    ov.querySelector('#hsv-plus-imp').onchange = function(e){
      var f = e.target.files && e.target.files[0]; if (!f) return;
      if (confirm('Nhập từ file "'+f.name+'"? (Trùng ID sẽ được đặt lại)')) importFromFile(f, 'append');
    };
    // snapshots
    renderSnaps();
    // savedot chip mặc định ẨN (root-cause fix); tick để hiện lại nếu muốn
    var hs = document.getElementById('hsv-plus-hidesave');
    hs.checked = localStorage.getItem('hsv:plus:showsave') === '1';
    if (hs.checked) document.documentElement.classList.add('hsv-show-savedot');
    hs.onchange = function(){
      if (hs.checked){ document.documentElement.classList.add('hsv-show-savedot'); localStorage.setItem('hsv:plus:showsave','1'); }
      else { document.documentElement.classList.remove('hsv-show-savedot'); localStorage.removeItem('hsv:plus:showsave'); }
    };
  }
  function closeTools(){ var m=document.getElementById('hsv-plus-modal'); if (m) m.remove(); }
  function renderSnaps(){
    var host = document.getElementById('hsv-plus-snaps'); if (!host) return;
    var id = getCurrentCaseId();
    if (!id){ host.innerHTML = '<div style="padding:12px;color:#6b7280;font-size:13px">Chưa mở hồ sơ nào. Mở một hồ sơ để xem lịch sử phiên bản.</div>'; return; }
    var all = lsGet(SNAP_KEY, {}) || {}; var arr = all[id] || [];
    if (!arr.length){ host.innerHTML = '<div style="padding:12px;color:#6b7280;font-size:13px">Chưa có snapshot nào. Snapshot được tạo tự động khi bạn lưu (tối đa '+SNAP_MAX+' bản, 1 phút/lần).</div>'; return; }
    host.innerHTML = arr.map(function(s, i){
      return '<div style="display:flex;gap:8px;align-items:center;padding:8px 10px;border-bottom:1px solid #f1f5f9">'
        + '<div style="flex:1;font-size:13px"><div>'+esc(new Date(s.ts).toLocaleString('vi-VN'))+' <span style="color:#94a3b8;font-size:11px">('+esc(s.reason||'')+')</span></div>'
        + '<div style="color:#6b7280;font-size:11px">'+esc(s.customerName||'(chưa đặt tên)')+' · '+Object.keys(s.values||{}).length+' trường</div></div>'
        + '<button class="hsv-plus-btn" data-snap="'+i+'" style="background:#0ea5e9">Khôi phục</button>'
      + '</div>';
    }).join('');
    host.querySelectorAll('[data-snap]').forEach(function(btn){
      btn.onclick = function(){
        var idx = +btn.getAttribute('data-snap');
        if (confirm('Khôi phục phiên bản này? Bản hiện tại sẽ được lưu snapshot tự động trước khi ghi đè.')){
          if (!restoreSnapshot(id, idx)) alert('Khôi phục thất bại.');
        }
      };
    });
  }

  // Áp dụng pref hiện lại savedot ngay từ đầu (mặc định là ẨN)
  if (localStorage.getItem('hsv:plus:showsave') === '1') document.documentElement.classList.add('hsv-show-savedot');
  // dọn cờ cũ của bản trước (v25.6.3) nếu còn sót lại, không còn tác dụng
  try { localStorage.removeItem('hsv:plus:hidesave'); } catch(_){}
  document.documentElement.classList.remove('hsv-hide-savedot');

  log('ready v25.6.4 — savedot hidden by default (root-cause), snapshots + lock + io + search enabled');
})();