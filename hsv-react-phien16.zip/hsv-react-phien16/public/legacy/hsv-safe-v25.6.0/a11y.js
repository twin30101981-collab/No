/* HSV SAFE v25.6.0 — A11y additions (labels, live regions, skip link) */
(function () {
  'use strict';
  if (window.__hsv_v2560_a11y) return;
  window.__hsv_v2560_a11y = true;

  function addSkipLink() {
    if (document.getElementById('hsv-skip')) return;
    var main = document.querySelector('main, #main, #app main, #app > *:not(header):not(nav)');
    if (main && !main.id) main.id = 'hsv-main';
    var a = document.createElement('a');
    a.id = 'hsv-skip';
    a.href = '#' + (main ? (main.id || 'hsv-main') : 'app');
    a.textContent = 'Bỏ qua tới nội dung';
    document.body.insertBefore(a, document.body.firstChild);
  }

  function labelIconButtons() {
    var buttons = document.querySelectorAll('button, a.nav-btn, [role="button"]');
    buttons.forEach(function (b) {
      if (b.getAttribute('aria-label')) return;
      var txt = (b.textContent || '').trim();
      if (!txt) return;
      // Icon-only (short emoji/text with no letters)
      var noLetters = !/[A-Za-zÀ-ỹ0-9]/.test(txt);
      if (noLetters && txt.length <= 3) {
        b.setAttribute('aria-label', b.getAttribute('title') || 'Nút chức năng');
      }
    });
  }

  function markLiveRegions() {
    document.querySelectorAll('.toast, [class*="toast"], [id*="toast"]').forEach(function (el) {
      if (!el.getAttribute('role')) el.setAttribute('role', 'status');
      if (!el.getAttribute('aria-live')) el.setAttribute('aria-live', 'polite');
    });
  }

  function run() {
    try { addSkipLink(); } catch (e) { console.warn(e); }
    try { labelIconButtons(); } catch (e) { console.warn(e); }
    try { markLiveRegions(); } catch (e) { console.warn(e); }
  }
  run();
  // Re-run when DOM grows
  var mo = new MutationObserver(function () { labelIconButtons(); markLiveRegions(); });
  mo.observe(document.body, { childList: true, subtree: true });

  window.HSVSafe.modules.a11y = { run: run };
})();
