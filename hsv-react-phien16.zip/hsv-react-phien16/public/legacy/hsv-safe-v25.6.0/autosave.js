/* HSV SAFE v25.6.0 — Auto-save + restore (IndexedDB with localStorage fallback) */
(function () {
  'use strict';
  if (window.__hsv_v2560_autosave) return;
  window.__hsv_v2560_autosave = true;

  var DB_NAME = 'hsv-safe-v2560';
  var STORE = 'drafts';
  var MAX_SNAPSHOTS = 20;
  var DEBOUNCE_MS = 800;
  var LS_KEY = 'hsv-drafts-fallback-v2560';

  var db = null;
  var useLs = false;

  function openDb() {
    return new Promise(function (res, rej) {
      try {
        var req = indexedDB.open(DB_NAME, 1);
        req.onupgradeneeded = function () {
          req.result.createObjectStore(STORE, { keyPath: 'id', autoIncrement: true });
        };
        req.onsuccess = function () { db = req.result; res(); };
        req.onerror = function () { rej(req.error); };
      } catch (e) { rej(e); }
    });
  }

  function idbAdd(snap) {
    return new Promise(function (res, rej) {
      var tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).add(snap);
      tx.oncomplete = res; tx.onerror = function () { rej(tx.error); };
    }).then(trim);
  }
  function idbAll() {
    return new Promise(function (res, rej) {
      var out = [];
      var tx = db.transaction(STORE, 'readonly');
      var req = tx.objectStore(STORE).openCursor(null, 'prev');
      req.onsuccess = function (e) {
        var c = e.target.result;
        if (c) { out.push(c.value); c.continue(); } else res(out);
      };
      req.onerror = function () { rej(req.error); };
    });
  }
  function trim() {
    return idbAll().then(function (list) {
      if (list.length <= MAX_SNAPSHOTS) return;
      var toDel = list.slice(MAX_SNAPSHOTS).map(function (x) { return x.id; });
      return new Promise(function (res) {
        var tx = db.transaction(STORE, 'readwrite');
        var st = tx.objectStore(STORE);
        toDel.forEach(function (id) { st.delete(id); });
        tx.oncomplete = res;
      });
    });
  }

  function lsAdd(snap) {
    try {
      var arr = JSON.parse(localStorage.getItem(LS_KEY) || '[]');
      arr.unshift(snap);
      arr = arr.slice(0, MAX_SNAPSHOTS);
      localStorage.setItem(LS_KEY, JSON.stringify(arr));
    } catch (e) { console.warn('[autosave] LS write failed', e); }
  }
  function lsAll() {
    try { return Promise.resolve(JSON.parse(localStorage.getItem(LS_KEY) || '[]')); }
    catch (e) { return Promise.resolve([]); }
  }

  function collect() {
    var fields = {};
    document.querySelectorAll('input, select, textarea').forEach(function (el) {
      var key = el.name || el.id;
      if (!key) return;
      if (el.type === 'password') return;
      if (el.type === 'file') return;
      if (el.type === 'checkbox' || el.type === 'radio') {
        if (el.checked) fields[key] = el.value || true;
      } else {
        var v = el.value;
        if (v !== '' && v != null) fields[key] = v;
      }
    });
    return {
      ts: Date.now(),
      url: location.href.split('#')[0],
      version: '25.6.0',
      // FIX v23 (an toàn dữ liệu): field id trong app (dạng 'f-<key>') KHÔNG
      // đổi theo hồ sơ — cùng 1 id có thể tồn tại ở mọi hồ sơ khác nhau. Nếu
      // không gắn caseId vào snapshot, offerRestore() có thể chào khôi phục
      // dữ liệu của KHÁCH HÀNG A vào hồ sơ đang mở của KHÁCH HÀNG B.
      caseId: (window.currentCaseId != null ? window.currentCaseId : null),
      fields: fields
    };
  }

  function save() {
    var snap = collect();
    var n = Object.keys(snap.fields).length;
    if (n === 0) return Promise.resolve();
    snap.count = n;
    var p = useLs ? Promise.resolve(lsAdd(snap)) : idbAdd(snap);
    return p.then(function () { showChip('Đã lưu · ' + n + ' ô'); });
  }

  function all() {
    return useLs ? lsAll() : idbAll();
  }

  function restore(snap) {
    if (!snap || !snap.fields) return 0;
    var n = 0;
    Object.keys(snap.fields).forEach(function (key) {
      var el = document.querySelector('[name="' + CSS.escape(key) + '"], #' + CSS.escape(key));
      if (!el) return;
      if (el.type === 'checkbox' || el.type === 'radio') el.checked = true;
      else el.value = snap.fields[key];
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      n++;
    });
    return n;
  }

  function showChip(msg) {
    var c = document.getElementById('hsv-save-chip');
    if (!c) {
      c = document.createElement('div');
      c.id = 'hsv-save-chip';
      c.setAttribute('role', 'status');
      c.setAttribute('aria-live', 'polite');
      document.body.appendChild(c);
    }
    c.textContent = msg;
    c.classList.add('on');
    clearTimeout(showChip._t);
    showChip._t = setTimeout(function () { c.classList.remove('on'); }, 1500);
  }

  var t = 0;
  function schedule() {
    clearTimeout(t);
    t = setTimeout(function () { save().catch(function (e) { console.warn(e); }); }, DEBOUNCE_MS);
  }

  function bindInputs() {
    document.addEventListener('input', schedule, true);
    document.addEventListener('change', schedule, true);
  }

  function offerRestore() {
    all().then(function (list) {
      if (!list.length) return;
      // FIX v23 (an toàn dữ liệu): chỉ xét các snapshot của ĐÚNG hồ sơ đang mở
      // (so caseId). Snapshot cũ (trước bản vá này) không có caseId — bỏ qua
      // luôn để tránh khôi phục nhầm dữ liệu khách hàng khác vào hồ sơ hiện tại.
      var curCase = (window.currentCaseId != null ? window.currentCaseId : null);
      var sameCase = list.filter(function (x) { return curCase != null && x.caseId === curCase; });
      if (!sameCase.length) return;
      var latest = sameCase[0];
      // Skip prompt if age > 7 days
      if (Date.now() - latest.ts > 7 * 864e5) return;
      // If any field already has value, skip auto-prompt
      var hasContent = false;
      document.querySelectorAll('input, select, textarea').forEach(function (el) {
        if (hasContent) return;
        if ((el.name || el.id) && el.value && el.value !== '0') hasContent = true;
      });
      if (hasContent) return;
      setTimeout(function () {
        var when = new Date(latest.ts).toLocaleString('vi-VN');
        if (confirm('Khôi phục phiên trước (' + when + ', ' + latest.count + ' ô)?')) {
          var n = restore(latest);
          showChip('Đã khôi phục ' + n + ' ô');
        }
      }, 300);
    });
  }

  var _promptedCases = {}; // tránh hỏi lại nhiều lần cho cùng 1 hồ sơ trong 1 phiên
  function offerRestoreOnce() {
    var curCase = (window.currentCaseId != null ? window.currentCaseId : null);
    if (curCase == null || _promptedCases[curCase]) return;
    _promptedCases[curCase] = true;
    offerRestore();
  }

  openDb().catch(function () {
    console.warn('[autosave] IndexedDB unavailable — using localStorage');
    useLs = true;
  }).then(function () {
    bindInputs();
    offerRestore(); // trường hợp đã có currentCaseId ngay khi tải trang
    // FIX v23: currentCaseId thường vẫn là null lúc trang vừa tải (chưa mở hồ
    // sơ nào) nên lời mời khôi phục trước đây gần như không bao giờ chạy đúng
    // lúc. Móc thêm vào renderWizard (theo đúng kiểu wrap-an-toàn luôn gọi lại
    // bản trước, giống các patch khác trong app) để hỏi lại mỗi khi người dùng
    // vừa mở một hồ sơ — nhưng chỉ hỏi 1 lần cho mỗi hồ sơ trong phiên làm việc.
    if (typeof window.renderWizard === 'function' && !window.__hsvsafe_rw_wrap__) {
      window.__hsvsafe_rw_wrap__ = true;
      var _rw = window.renderWizard;
      window.renderWizard = function () {
        var r = _rw.apply(this, arguments);
        setTimeout(offerRestoreOnce, 300);
        return r;
      };
    }
  });

  window.HSVSafe.modules.autosave = {
    save: save, all: all, restore: restore, collect: collect
  };
})();
