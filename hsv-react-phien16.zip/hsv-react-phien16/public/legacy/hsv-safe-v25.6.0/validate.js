/* HSV SAFE v25.6.0 — Financial / format validation (advisory only, never blocks) */
(function () {
  'use strict';
  if (window.__hsv_v2560_val) return;
  window.__hsv_v2560_val = true;

  var LOAN_LTV_MAX = 0.85;

  function num(el) {
    if (!el) return NaN;
    var v = String(el.value || '').replace(/[^\d.-]/g, '');
    if (!v) return NaN;
    return parseFloat(v);
  }
  function findAny(re) {
    var els = document.querySelectorAll('input, select, textarea');
    for (var i = 0; i < els.length; i++) {
      var k = ((els[i].name || '') + ' ' + (els[i].id || '')).toLowerCase();
      if (re.test(k)) return els[i];
    }
    return null;
  }
  function findAll(re) {
    var out = [];
    document.querySelectorAll('input, select, textarea').forEach(function (el) {
      var k = ((el.name || '') + ' ' + (el.id || '')).toLowerCase();
      if (re.test(k)) out.push(el);
    });
    return out;
  }

  function mark(el, msg) {
    if (!el) return;
    el.setAttribute('data-hsv-warn', '1');
    el.setAttribute('title', msg);
    // Attach a small tip once
    if (!el.dataset.hsvTipped) {
      el.dataset.hsvTipped = '1';
    }
  }
  function clear(el) {
    if (!el) return;
    el.removeAttribute('data-hsv-warn');
    if (el.dataset.hsvTipped) el.removeAttribute('title');
  }

  function run() {
    var warnings = [];
    // Clear previous
    document.querySelectorAll('[data-hsv-warn="1"]').forEach(clear);

    // 1. Phone VN
    findAll(/(phone|sdt|dien.?thoai|mobile)/i).forEach(function (el) {
      var v = String(el.value || '').replace(/\s/g, '');
      if (v && !/^0[3-9]\d{8}$/.test(v)) {
        mark(el, 'SĐT không hợp lệ (0[3-9]xxxxxxxx)');
        warnings.push({ el: el, msg: 'SĐT không hợp lệ: ' + v });
      }
    });

    // 2. CCCD 12 digits
    findAll(/(cccd|cmnd|so.?the|id.?card)/i).forEach(function (el) {
      var v = String(el.value || '').replace(/\s/g, '');
      if (v && !/^\d{9}$|^\d{12}$/.test(v)) {
        mark(el, 'Số CCCD/CMND phải 9 hoặc 12 chữ số');
        warnings.push({ el: el, msg: 'CCCD không đúng độ dài: ' + v });
      }
    });

    // 3. Dates: birth < issue < today
    var birthEl = findAny(/(ngay.?sinh|dob|birth)/i);
    var issueEl = findAny(/(ngay.?cap|issue.?date|cap.?cccd|cap.?cmnd)/i);
    var today = new Date();
    function d(el) { return el && el.value ? new Date(el.value) : null; }
    var db_ = d(birthEl), di = d(issueEl);
    if (db_ && !isNaN(db_) && db_ > today) {
      mark(birthEl, 'Ngày sinh không thể ở tương lai');
      warnings.push({ el: birthEl, msg: 'Ngày sinh ở tương lai' });
    }
    if (di && !isNaN(di) && di > today) {
      mark(issueEl, 'Ngày cấp không thể ở tương lai');
      warnings.push({ el: issueEl, msg: 'Ngày cấp ở tương lai' });
    }
    if (db_ && di && !isNaN(db_) && !isNaN(di) && db_ >= di) {
      mark(issueEl, 'Ngày cấp phải sau ngày sinh');
      warnings.push({ el: issueEl, msg: 'Ngày cấp ≤ ngày sinh' });
    }

    // 4. Loan end > disbursement
    var startEl = findAny(/(ngay.?giai.?ngan|disburse|start.?date|ngay.?vay)/i);
    var endEl = findAny(/(ngay.?ket.?thuc|end.?date|han.?tra|due)/i);
    var ds = d(startEl), de = d(endEl);
    if (ds && de && !isNaN(ds) && !isNaN(de) && de <= ds) {
      mark(endEl, 'Ngày kết thúc phải sau ngày giải ngân');
      warnings.push({ el: endEl, msg: 'Ngày kết thúc ≤ ngày giải ngân' });
    }

    // 5. Loan amount vs TSBĐ
    var loanEl = findAny(/(so.?tien.?vay|du.?no|loan.?amount|amount.?vay)/i);
    var tsbdEls = findAll(/(tsbd|tai.?san|collateral|gia.?tri.?tsbd|gia.?tri.?tai.?san)/i);
    var loan = num(loanEl);
    var tsbdTotal = 0;
    tsbdEls.forEach(function (el) {
      var v = num(el);
      if (!isNaN(v)) tsbdTotal += v;
    });
    if (!isNaN(loan) && tsbdTotal > 0) {
      if (loan > tsbdTotal) {
        mark(loanEl, 'Số tiền vay vượt tổng giá trị TSBĐ (' + tsbdTotal.toLocaleString('vi-VN') + ')');
        warnings.push({ el: loanEl, msg: 'Vay > TSBĐ' });
      } else if (loan / tsbdTotal > LOAN_LTV_MAX) {
        mark(loanEl, 'Tỉ lệ vay/TSBĐ ' + Math.round(loan / tsbdTotal * 100) + '% vượt ngưỡng ' + Math.round(LOAN_LTV_MAX * 100) + '%');
        warnings.push({ el: loanEl, msg: 'LTV ' + Math.round(loan / tsbdTotal * 100) + '% > ' + Math.round(LOAN_LTV_MAX * 100) + '%' });
      }
    }

    return warnings;
  }

  function ensurePanel() {
    var p = document.getElementById('hsv-validate-panel');
    if (p) return p;
    p = document.createElement('div');
    p.id = 'hsv-validate-panel';
    p.setAttribute('role', 'region');
    p.setAttribute('aria-label', 'Kết quả kiểm tra hồ sơ');
    p.innerHTML = '<h4>Kiểm tra hồ sơ <button type="button" aria-label="Đóng" style="float:right;background:none;border:0;font-size:16px;cursor:pointer" id="hsv-vp-close">×</button></h4><div id="hsv-vp-body"></div>';
    document.body.appendChild(p);
    p.querySelector('#hsv-vp-close').addEventListener('click', function () { p.classList.remove('on'); });
    return p;
  }

  function showPanel() {
    var warnings = run();
    var p = ensurePanel();
    var body = p.querySelector('#hsv-vp-body');
    if (!warnings.length) {
      body.innerHTML = '<p style="color:#059669;margin:0">✓ Không phát hiện vấn đề rõ ràng.</p>';
    } else {
      var ul = document.createElement('ul');
      warnings.forEach(function (w) {
        var li = document.createElement('li');
        li.textContent = '⚠ ' + w.msg;
        li.addEventListener('click', function () {
          if (w.el && w.el.focus) { w.el.focus(); w.el.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
        });
        ul.appendChild(li);
      });
      body.innerHTML = '';
      body.appendChild(ul);
    }
    p.classList.add('on');
  }

  function mountBtn() {
    if (document.getElementById('hsv-validate-btn')) return;
    var b = document.createElement('button');
    b.id = 'hsv-validate-btn';
    b.type = 'button';
    b.className = 'hsv-nav-icon-btn';
    b.textContent = '⚠';
    b.setAttribute('aria-label', 'Kiểm tra hồ sơ');
    b.title = 'Kiểm tra logic số liệu hồ sơ';
    b.addEventListener('click', showPanel);
    var nav = document.querySelector('header nav');
    (nav || document.body).appendChild(b);
  }
  function ensureMounted() {
    var b = document.getElementById('hsv-validate-btn');
    var nav = document.querySelector('header nav');
    if (b && nav && b.parentElement !== nav) nav.appendChild(b);
    if (!b) mountBtn();
  }

  if (document.body) mountBtn();
  else document.addEventListener('DOMContentLoaded', mountBtn, { once: true });
  setTimeout(ensureMounted, 300);
  setTimeout(ensureMounted, 1200);

  // Live-mark on change (silent, no panel popup)
  var t = 0;
  document.addEventListener('change', function () {
    clearTimeout(t);
    t = setTimeout(run, 400);
  }, true);

  window.HSVSafe.modules.validate = { run: run, show: showPanel };
})();
