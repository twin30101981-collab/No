# HSV SAFE v25.6.0 — Changelog

Bản vá additive-only cho HSV v25.5.10 "audited-fixed". Không sửa bất kỳ file cũ nào ngoại trừ append **2 dòng** vào cuối `index.html`.

## Cách revert
Xoá 2 dòng cuối `<body>` của `index.html` (khối `<!-- HSV SAFE v25.6.0 -->`) và xoá thư mục `hsv-safe-v25.6.0/`.

## Cấu trúc

| File | Vai trò |
| --- | --- |
| `loader.js` | Bootstrap; nạp styles.css + tuần tự các module |
| `styles.css` | Tokens dark, focus ring, print A4, palette UI. Toàn bộ dùng `:where()` → specificity=0 |
| `a11y.js` | Thêm skip-link, `aria-label` cho nút icon-only, `role="status"` cho toast |
| `theme.js` | Toggle Auto/Sáng/Tối bằng class `.hsv-dark`; nút góc phải trên |
| `ios.js` | `--hsv-vh` fallback cho iOS Safari qua `visualViewport` |
| `autosave.js` | Debounce 800 ms, IndexedDB (fallback localStorage), 20 snapshot; hỏi khôi phục khi mở lại |
| `backup-io.js` | Nút **💾 Sao lưu JSON / 📥 Nhập JSON** trong `#wizard-sidebar` (hoặc góc trái dưới nếu không tìm thấy) |
| `validate.js` | Cảnh báo SĐT/CCCD/ngày/tỉ lệ vay (LTV ≤ 85%); panel liệt kê + click nhảy tới field |
| `palette.js` | Ctrl/⌘+K bảng lệnh nhanh + shortcut Ctrl+S/P, Alt+←/→, `?` |
| `print.js` | Hook beforeprint/afterprint |
| `template-lazy.js` | Bọc `HSVTemplates.getBase64` để hiện spinner khi 9.6 MB templates chưa parse xong |
| `pwa.js` | Đăng ký service worker chỉ khi `http(s)`; hỗ trợ `?sw=off` để gỡ |
| `sw.js` | Network-first HTML, cache-first asset; **không** precache templates-data.js |
| `manifest.webmanifest` | Manifest PWA |

## Lỗi/rủi ro đã xử lý

1. Auto-save chống mất dữ liệu khi crash, mất điện, đóng nhầm tab.
2. Export/Import JSON để backup + chuyển máy.
3. Validate cảnh báo trực quan (không chặn submit).
4. Dark mode dùng class riêng `.hsv-dark`, không đè lên palette gốc.
5. Focus ring rõ, skip-link Tab-first cho A11y.
6. Ctrl+K palette mở rộng: tìm nhanh field/hành động.
7. Print A4 chuẩn: ẩn nổi, ngắt trang thông minh, `thead` lặp.
8. iOS Safari: `-webkit-tap-highlight-color`, `touch-action: manipulation`, `--hsv-vh` fallback.
9. Templates-data.js 9.6 MB: spinner "Đang tải templates…" khi user gọi trước lúc sẵn sàng.
10. PWA offline thật sự khi phục vụ qua http(s); giữ tương thích file://.

## Không thay đổi

- Không đụng `app.js`, `hsv-consolidated.css`, `fix-v*.js`, `hsv-*.js` cũ, `templates/*`.
- Không đổi ID/class/handler public nào.
- Không phát request ra Internet ngoài các CDN đã có trong bản cũ.

## v25.6.4 — Fix triệt để chip "đã lưu" đè topnav

- **Nguyên nhân gốc**: bản v25.6.3 "sửa" bằng cách dời chip `[data-hsv-fix="v6-savedot"]`
  từ góc dưới-phải (đè FAB "ƒ Công thức") lên góc trên-phải (`top:2px; right:6px`).
  Nhưng góc trên-phải lại đúng vị trí topnav đặt nút "XUẤT PA SXKD" → chip vẫn đè UI,
  chỉ đổi chỗ đè từ FAB sang topnav. Vì đây là 1 layer `position:fixed` độc lập,
  dời tới đâu cũng có nguy cơ đè lên toolbar/topnav/FAB đang chạy ở vị trí đó.
- **Fix**: ẩn hẳn chip theo mặc định (`display:none`), không còn chiếm layer nào trên
  màn hình → không thể đè lên bất kỳ UI nào nữa. Chip vẫn được tạo/cập nhật ngầm bởi
  `app.js` như cũ (không đụng code gốc), chỉ là không hiển thị.
- Ai vẫn muốn xem trạng thái autosave có thể bật lại qua **🛠 Công cụ hồ sơ → Hiển thị →
  "Hiện chip đã lưu ở góc màn hình"**. Khi bật, chip hiển thị ở vị trí cũ (góc trên-phải).
- Cờ localStorage cũ `hsv:plus:hidesave` được dọn tự động; cờ mới là `hsv:plus:showsave`.
