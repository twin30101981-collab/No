/* ══════════════════════════════════════════════════════════════════════
 *  HSV v25.6.1 · PATCH — Chuyển nút "Gán PA cho khách hàng" từ top-nav
 *  (.sxkd-toolbar) vào thanh sticky-nav ngay sau nút "Sang trang xuất".
 *
 *  Mục tiêu:
 *   • Giải phóng chỗ trên top-nav mobile (nút XUẤT không còn bị cắt).
 *   • Đặt "Gán PA" đúng nơi cần dùng khi đang nhập hồ sơ.
 *
 *  Additive: KHÔNG sửa app.js, KHÔNG sửa các patch fix-v13…v18.
 *  Idempotent: an toàn khi renderWizard vẽ lại nhiều lần.
 * ══════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';
  if (window.__hsvPaInStickynav) return;
  window.__hsvPaInStickynav = true;

  var STYLE_ID = 'hsv-pa-in-stickynav-style';
  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;
    var s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent = [
      /* Khi nút đã được relocate, ẩn mọi bản ở .sxkd-toolbar để tránh trùng lặp. */
      'body.hsv-pa-relocated .sxkd-toolbar #hsv16-pa-toolbtn{display:none!important;}',
      /* Style đồng bộ với #v8-export trong sticky-nav. */
      '.v8-sticky-nav #hsv16-pa-toolbtn{background:#0f766e;border-color:#0f766e;color:#fff;',
      'font-weight:600;padding:6px 10px;border-radius:8px;cursor:pointer;',
      'display:inline-flex;align-items:center;gap:6px;white-space:nowrap;}',
      '.v8-sticky-nav #hsv16-pa-toolbtn:hover{filter:brightness(1.05);}'
    ].join('');
    document.head.appendChild(s);
  }

  function relocate() {
    var nav = document.querySelector('.v8-sticky-nav');
    if (!nav) return;                     // Không phải trang wizard — bỏ qua.
    if (nav.getAttribute('data-hsv-pa-moved') === '1' &&
        nav.querySelector('#hsv16-pa-toolbtn')) return; // Đã xong.

    ensureStyle();

    var exportBtn = nav.querySelector('#v8-export');
    var existing = document.getElementById('hsv16-pa-toolbtn');
    var btn;

    if (existing && existing.parentElement !== nav) {
      /* Di chuyển node gốc → giữ nguyên onclick (assignCurrentPaToCustomer). */
      btn = existing;
    } else if (!existing) {
      /* Placeholder trước khi fix-v16 gọi mountPaAssignButtonIn.
         Cùng id → mountPaAssignButtonIn sẽ tự bỏ qua, không nhân đôi. */
      btn = document.createElement('button');
      btn.id = 'hsv16-pa-toolbtn';
      btn.type = 'button';
      btn.innerHTML = '👤 Gán PA cho khách hàng';
      btn.onclick = function () {
        try {
          if (typeof window.assignCurrentPaToCustomer === 'function') {
            window.assignCurrentPaToCustomer(document);
          }
        } catch (_) {}
      };
    } else {
      btn = existing; // Đã ở trong nav rồi.
    }

    if (exportBtn && exportBtn.nextSibling !== btn) {
      exportBtn.insertAdjacentElement('afterend', btn);
    } else if (!exportBtn && btn.parentElement !== nav) {
      nav.appendChild(btn);
    }

    nav.setAttribute('data-hsv-pa-moved', '1');
    document.body.classList.add('hsv-pa-relocated');
  }

  var scheduled = false;
  function schedule() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(function () {
      scheduled = false;
      try { relocate(); } catch (_) {}
    });
  }

  try {
    new MutationObserver(function (muts) {
      for (var i = 0; i < muts.length; i++) {
        var t = muts[i].target;
        if (t && (t.id === 'main-content' ||
                  (t.closest && t.closest('#main-content')))) {
          schedule();
          return;
        }
      }
    }).observe(document.body, { childList: true, subtree: true });
  } catch (_) {}

  document.addEventListener('DOMContentLoaded', schedule);
  setTimeout(schedule, 300);
  setTimeout(schedule, 1200);
  requestAnimationFrame(schedule);

  window.hsvPaInStickynav = { relocate: relocate };
})();
