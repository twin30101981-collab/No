/* HSV SAFE v25.6.0 — Theme toggle (light / dark) via html.hsv-dark
 * v25.6.1: bỏ chế độ 'auto' (chỉ còn light/dark), mount nút vào
 * header nav để không đè lên các nút nghiệp vụ ở topnav. */
(function () {
  'use strict';
  if (window.__hsv_v2560_theme) return;
  window.__hsv_v2560_theme = true;

  var KEY = 'hsv-theme-v2560';

  function apply(mode) {
    document.documentElement.classList.toggle('hsv-dark', mode === 'dark');
  }

  function current() {
    var v = localStorage.getItem(KEY);
    // v25.6.1: migrate legacy 'auto' → 'light'
    if (v !== 'dark' && v !== 'light') v = 'light';
    return v;
  }

  function cycle() {
    var next = current() === 'dark' ? 'light' : 'dark';
    try { localStorage.setItem(KEY, next); } catch (e) {}
    apply(next);
    updateBtn();
    if (window.HSVSafe && window.HSVSafe.toast) {
      window.HSVSafe.toast('Giao diện: ' + (next === 'dark' ? 'Tối' : 'Sáng'));
    }
  }

  function updateBtn() {
    var btn = document.getElementById('hsv-theme-btn');
    if (!btn) return;
    var m = current();
    btn.textContent = m === 'dark' ? '☀' : '🌙';
    btn.setAttribute('aria-label', 'Giao diện: ' + m + ' (bấm để đổi)');
    btn.title = 'Đổi giao diện — hiện: ' + (m === 'dark' ? 'Tối' : 'Sáng');
  }

  function mount() {
    if (document.getElementById('hsv-theme-btn')) return;
    var b = document.createElement('button');
    b.id = 'hsv-theme-btn';
    b.type = 'button';
    b.className = 'hsv-nav-icon-btn';
    b.addEventListener('click', cycle);
    var nav = document.querySelector('header nav');
    (nav || document.body).appendChild(b);
    updateBtn();
  }

  function ensureMounted() {
    // Nếu nút đã ở body (mount sớm), di chuyển vào header nav khi nav sẵn sàng
    var b = document.getElementById('hsv-theme-btn');
    var nav = document.querySelector('header nav');
    if (b && nav && b.parentElement !== nav) nav.appendChild(b);
    if (!b) mount();
  }

  apply(current());
  if (document.body) mount();
  else document.addEventListener('DOMContentLoaded', mount, { once: true });
  setTimeout(ensureMounted, 300);
  setTimeout(ensureMounted, 1200);

  window.HSVSafe = window.HSVSafe || { modules: {} };
  window.HSVSafe.modules = window.HSVSafe.modules || {};
  window.HSVSafe.modules.theme = { toggle: cycle, current: current };
})();
