/* HSV SAFE v25.6.0 — Command palette (Ctrl/Cmd+K) + shortcuts */
(function () {
  'use strict';
  if (window.__hsv_v2560_pal) return;
  window.__hsv_v2560_pal = true;

  var items = [];
  var filtered = [];
  var sel = 0;

  function buildIndex() {
    items = [];
    // Actions
    items.push({ label: 'Sao lưu JSON', desc: 'Ctrl+S', run: function () {
      var m = window.HSVSafe.modules.backup; if (m) m.export();
    }});
    items.push({ label: 'Kiểm tra hồ sơ', desc: 'Validate', run: function () {
      var m = window.HSVSafe.modules.validate; if (m) m.show();
    }});
    items.push({ label: 'Đổi giao diện (Sáng/Tối/Auto)', desc: 'Theme', run: function () {
      var m = window.HSVSafe.modules.theme; if (m) m.toggle();
    }});
    items.push({ label: 'In / Xuất PDF', desc: 'Ctrl+P', run: function () { window.print(); }});
    items.push({ label: 'Lưu ngay bản nháp', desc: 'Autosave', run: function () {
      var m = window.HSVSafe.modules.autosave; if (m) m.save();
    }});

    // Nav buttons in header
    document.querySelectorAll('a.nav-btn, nav a, nav button, [data-nav]').forEach(function (el) {
      var t = (el.textContent || '').trim().replace(/\s+/g, ' ');
      if (t && t.length < 40) {
        items.push({ label: t, desc: 'Điều hướng', run: function () { el.click(); }});
      }
    });

    // Labels of fields
    document.querySelectorAll('label').forEach(function (lb) {
      var t = (lb.textContent || '').trim().replace(/\s+/g, ' ');
      if (!t || t.length > 60) return;
      var target = null;
      if (lb.htmlFor) target = document.getElementById(lb.htmlFor);
      if (!target) target = lb.querySelector('input, select, textarea');
      if (!target) return;
      items.push({ label: t, desc: 'Field', run: function () {
        target.focus();
        target.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }});
    });
  }

  function ensureDom() {
    var d = document.getElementById('hsv-palette');
    if (d) return d;
    d = document.createElement('div');
    d.id = 'hsv-palette';
    d.setAttribute('role', 'dialog');
    d.setAttribute('aria-label', 'Bảng lệnh nhanh');
    d.innerHTML = '<div class="box"><input type="text" placeholder="Gõ để tìm lệnh, trường, hoặc bước…" aria-label="Ô tìm lệnh"/><ul role="listbox"></ul></div>';
    document.body.appendChild(d);
    var input = d.querySelector('input');
    var ul = d.querySelector('ul');
    input.addEventListener('input', function () { filter(input.value); });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown') { sel = Math.min(sel + 1, filtered.length - 1); render(); e.preventDefault(); }
      else if (e.key === 'ArrowUp') { sel = Math.max(sel - 1, 0); render(); e.preventDefault(); }
      else if (e.key === 'Enter') { runSel(); e.preventDefault(); }
      else if (e.key === 'Escape') { close(); }
    });
    d.addEventListener('click', function (e) { if (e.target === d) close(); });
    return d;
  }

  function filter(q) {
    q = (q || '').toLowerCase().trim();
    if (!q) filtered = items.slice(0, 30);
    else {
      filtered = items.filter(function (it) { return it.label.toLowerCase().indexOf(q) >= 0; }).slice(0, 50);
    }
    sel = 0;
    render();
  }
  function render() {
    var ul = document.querySelector('#hsv-palette ul');
    if (!ul) return;
    ul.innerHTML = '';
    filtered.forEach(function (it, i) {
      var li = document.createElement('li');
      li.setAttribute('role', 'option');
      if (i === sel) li.setAttribute('aria-selected', 'true');
      li.innerHTML = '<span></span><small></small>';
      li.firstChild.textContent = it.label;
      li.lastChild.textContent = it.desc || '';
      li.addEventListener('mouseenter', function () { sel = i; render(); });
      li.addEventListener('click', function () { runSel(); });
      ul.appendChild(li);
    });
  }
  function runSel() {
    var it = filtered[sel];
    close();
    if (it && it.run) try { it.run(); } catch (e) { console.warn(e); }
  }
  function open() {
    buildIndex();
    var d = ensureDom();
    d.classList.add('on');
    var input = d.querySelector('input');
    input.value = '';
    filter('');
    setTimeout(function () { input.focus(); }, 30);
  }
  function close() {
    var d = document.getElementById('hsv-palette');
    if (d) d.classList.remove('on');
  }

  window.addEventListener('keydown', function (e) {
    var mod = e.ctrlKey || e.metaKey;
    if (mod && (e.key === 'k' || e.key === 'K')) {
      e.preventDefault(); open();
    } else if (mod && (e.key === 's' || e.key === 'S')) {
      e.preventDefault();
      var m = window.HSVSafe.modules.backup; if (m) m.export();
    } else if (e.key === '?' && !e.target.matches('input,textarea,select')) {
      alert('Phím tắt HSV v25.6.0:\n' +
        'Ctrl/⌘+K — Bảng lệnh\n' +
        'Ctrl/⌘+S — Sao lưu JSON\n' +
        'Ctrl/⌘+P — In / PDF\n' +
        'Alt+←/→ — Chuyển bước (nếu có)\n' +
        '? — Trợ giúp');
    } else if (e.altKey && (e.key === 'ArrowRight' || e.key === 'ArrowLeft')) {
      var dir = e.key === 'ArrowRight' ? 1 : -1;
      var btns = Array.from(document.querySelectorAll('.wizard-next, .wizard-prev, [data-step-next], [data-step-prev], .btn-next, .btn-prev'));
      var target = btns.find(function (b) {
        var t = (b.textContent || '') + (b.className || '');
        return dir > 0 ? /next|tiếp|sau/i.test(t) : /prev|trước|back/i.test(t);
      });
      if (target) { target.click(); e.preventDefault(); }
    }
  });

  window.HSVSafe.modules.palette = { open: open, close: close };
})();
