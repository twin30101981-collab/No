/* HSV SAFE v25.6.0 — loader (additive-only)
   Loads styles.css + all modules once, in a safe order, without touching legacy files. */
(function () {
  'use strict';
  if (window.__hsv_v2560_loader) return;
  window.__hsv_v2560_loader = true;

  var BASE = (function () {
    var s = document.currentScript;
    if (!s) return 'hsv-safe-v25.6.0/';
    var src = s.getAttribute('src') || '';
    return src.replace(/[^/]+$/, '');
  })();

  function addCss(href) {
    var l = document.createElement('link');
    l.rel = 'stylesheet';
    l.href = BASE + href;
    document.head.appendChild(l);
  }
  function addJs(src) {
    return new Promise(function (res, rej) {
      var s = document.createElement('script');
      s.src = BASE + src;
      s.defer = true;
      s.onload = res;
      s.onerror = function () { rej(new Error('load fail ' + src)); };
      document.head.appendChild(s);
    });
  }

  addCss('styles.css');

  // Namespace
  window.HSVSafe = window.HSVSafe || { version: '25.6.0', modules: {} };

  var mods = [
    'a11y.js',
    'theme.js',
    'ios.js',
    'autosave.js',
    'backup-io.js',
    'validate.js',
    'palette.js',
    'print.js',
    'template-lazy.js',
    'pwa.js'
  ];

  function ready(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn, { once: true });
    } else fn();
  }

  ready(function () {
    (function next(i) {
      if (i >= mods.length) {
        console.log('[HSVSafe] v25.6.0 all modules loaded');
        window.dispatchEvent(new Event('hsvsafe:ready'));
        return;
      }
      addJs(mods[i]).catch(function (e) { console.warn('[HSVSafe]', e); })
        .then(function () { next(i + 1); });
    })(0);
  });
})();
