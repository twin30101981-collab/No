/* HSV UI 2026 — Lucide icon replacer (offline, safe)
 * Chỉ thay các phần tử có [data-icon] hoặc các emoji/ký tự mục tiêu KHI ở vị trí biệt lập
 * (button/span chỉ chứa emoji đó). Không đụng nội dung khác.
 */
(function () {
  'use strict';
  if (window.__HSV_ICONS__) return;
  window.__HSV_ICONS__ = true;

  // Lucide SVG paths (MIT) — subset
  const P = (d) => `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="hsv-icon">${d}</svg>`;
  const ICONS = {
    search:      P('<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>'),
    plus:        P('<path d="M5 12h14"/><path d="M12 5v14"/>'),
    trash:       P('<path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>'),
    edit:        P('<path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 1 1 3 3L7 19l-4 1 1-4Z"/>'),
    download:    P('<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/>'),
    upload:      P('<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M17 8l-5-5-5 5"/><path d="M12 3v12"/>'),
    settings:    P('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>'),
    moon:        P('<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>'),
    sun:         P('<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>'),
    x:           P('<path d="M18 6 6 18"/><path d="m6 6 12 12"/>'),
    check:       P('<path d="M20 6 9 17l-5-5"/>'),
    'chevron-down': P('<path d="m6 9 6 6 6-6"/>'),
    'file-text': P('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>'),
    users:       P('<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>'),
    folder:      P('<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>'),
    save:        P('<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/>'),
    copy:        P('<rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>'),
    printer:     P('<polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>'),
    refresh:     P('<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>'),
    menu:        P('<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>'),
    filter:      P('<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>'),
    eye:         P('<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>'),
  };

  // Emoji → icon name map
  const EMOJI_MAP = {
    '🔍': 'search', '🔎': 'search',
    '➕': 'plus', '+': 'plus',
    '🗑': 'trash', '🗑️': 'trash', '❌': 'x', '✖': 'x', '✕': 'x',
    '✏': 'edit', '✏️': 'edit', '📝': 'edit',
    '⬇': 'download', '⬇️': 'download', '📥': 'download',
    '⬆': 'upload', '⬆️': 'upload', '📤': 'upload',
    '⚙': 'settings', '⚙️': 'settings',
    '🌙': 'moon', '☀': 'sun', '☀️': 'sun',
    '✅': 'check', '✔': 'check', '✔️': 'check',
    '📄': 'file-text', '📃': 'file-text',
    '👥': 'users', '👤': 'users',
    '📁': 'folder', '📂': 'folder',
    '💾': 'save',
    '📋': 'copy',
    '🖨': 'printer', '🖨️': 'printer',
    '🔄': 'refresh', '♻': 'refresh',
    '☰': 'menu',
    '🔽': 'chevron-down', '▼': 'chevron-down',
    '🔧': 'settings',
    '👁': 'eye', '👁️': 'eye',
  };

  function replaceEl(el, name) {
    const svg = ICONS[name];
    if (!svg) return;
    el.innerHTML = svg;
    el.classList.add('hsv-has-icon');
  }

  function scan(root) {
    // 1) explicit data-icon
    (root || document).querySelectorAll('[data-icon]').forEach((el) => {
      if (el.classList.contains('hsv-has-icon')) return;
      replaceEl(el, el.getAttribute('data-icon'));
    });
    // 2) buttons/spans whose ONLY text is a known emoji (or emoji + short label)
    (root || document).querySelectorAll('button, .icon, .btn-icon, span.emoji, i.icon').forEach((el) => {
      if (el.classList.contains('hsv-has-icon')) return;
      if (el.querySelector('svg,img')) return;
      const t = (el.textContent || '').trim();
      if (!t || t.length > 24) return;
      // isolated emoji
      if (EMOJI_MAP[t]) { replaceEl(el, EMOJI_MAP[t]); return; }
      // emoji + " text"
      const m = t.match(/^(\S+)\s+(.+)$/);
      if (m && EMOJI_MAP[m[1]]) {
        const name = EMOJI_MAP[m[1]];
        el.innerHTML = ICONS[name] + '<span class="hsv-icon-label">' + escapeHtml(m[2]) + '</span>';
        el.classList.add('hsv-has-icon');
      }
    });
  }
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function boot() {
    try { scan(document); } catch (_) {}
    // observe future DOM changes
    const mo = new MutationObserver((muts) => {
      for (const m of muts) {
        m.addedNodes.forEach((n) => { if (n.nodeType === 1) { try { scan(n); } catch (_) {} } });
      }
    });
    mo.observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  window.HSVIcons = { scan, ICONS };
})();
