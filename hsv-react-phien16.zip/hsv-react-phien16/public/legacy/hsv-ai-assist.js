/**
 * HSV Phần 9 — Trợ lý AI gợi ý (quy tắc tĩnh, không gọi API ngoài)
 * CỘNG THÊM — không đụng F[], không gọi thẳng store/localStorage.
 * Mọi giá trị AI đề xuất CHỈ ghi khi người dùng bấm xác nhận,
 * và đi qua đúng window.doSetValue — giống gõ tay.
 * Ngày: 2026-07-28 · HSV-UPGRADE-FEAT9
 */
(function(global) {
  'use strict';

  var AI_VERSION = 'FEAT9-2026-07-28';

  /* ══════════════════════════════════════════════════════════════
   * Quy tắc nghiệp vụ tĩnh (không gọi API ngoài)
   * ══════════════════════════════════════════════════════════════ */
  var RULES = [
    {
      id: 'von-tu-co',
      label: 'Tỷ lệ vốn tự có',
      check: function(data) {
        var vtc = parseNum(data['Vốn tự có'] || data['von_tu_co'] || '');
        var tnv = parseNum(data['Tổng nhu cầu vốn'] || data['tong_nhu_cau_von'] || '');
        if (!vtc || !tnv) return null;
        var pct = vtc / tnv * 100;
        if (pct < 30) {
          return {
            level: 'warning',
            icon: '⚠',
            message: 'Tỷ lệ vốn tự có: ' + pct.toFixed(2) + '% — dưới mức tối thiểu 30%. Quy định nội bộ yêu cầu ≥30%.',
            suggestion: null
          };
        }
        return {
          level: 'ok',
          icon: '✅',
          message: 'Tỷ lệ vốn tự có: ' + pct.toFixed(2) + '% — ĐẠT (≥30%).',
          suggestion: null
        };
      }
    },
    {
      id: 'gtcv-gtts',
      label: 'GTCV / GTTS (Giá trị cấp vay / Giá trị tài sản)',
      check: function(data) {
        var gtcv = parseNum(data['GTCV'] || data['Giá trị cấp vay'] || data['gtcv'] || '');
        var gtts = parseNum(data['GTTS'] || data['Giá trị tài sản'] || data['gtts'] || '');
        if (!gtcv || !gtts) return null;
        var ratio = gtcv / gtts * 100;
        if (ratio > 70) {
          return {
            level: 'warning',
            icon: '⚠',
            message: 'GTCV/GTTS = ' + ratio.toFixed(1) + '% — vượt ngưỡng 70%. Cần xem xét lại tài sản đảm bảo.',
            suggestion: null
          };
        }
        return {
          level: 'ok',
          icon: '✅',
          message: 'GTCV/GTTS = ' + ratio.toFixed(1) + '% — trong giới hạn (≤70%).',
          suggestion: null
        };
      }
    },
    {
      id: 'no-phai-tra',
      label: 'Nợ phải trả / Nợ người bán',
      check: function(data) {
        var npt = parseNum(data['Nợ phải trả'] || data['no_phai_tra'] || '');
        var nnb = parseNum(data['Nợ người bán'] || data['no_nguoi_ban'] || '');
        if (!npt && nnb > 0) {
          return {
            level: 'hint',
            icon: '💡',
            message: 'Phát hiện: "Nợ người bán" đã có (' + formatVND(nnb) + ') nhưng "Nợ phải trả" đang trống — hồ sơ tương tự thường điền cả hai.',
            suggestion: null
          };
        }
        return null;
      }
    },
    {
      id: 'doanh-thu-chi-phi',
      label: 'Lợi nhuận hợp lý',
      check: function(data) {
        var dt = parseNum(data['Doanh thu'] || data['doanh_thu'] || data['Tổng doanh thu'] || '');
        var cp = parseNum(data['Chi phí'] || data['chi_phi'] || data['Tổng chi phí'] || '');
        if (!dt || !cp) return null;
        var ln = dt - cp;
        var margin = ln / dt * 100;
        if (margin < 0) {
          return {
            level: 'error',
            icon: '❌',
            message: 'Lợi nhuận âm (' + formatVND(ln) + '). Kiểm tra lại doanh thu và chi phí.',
            suggestion: null
          };
        }
        if (margin > 95) {
          return {
            level: 'warning',
            icon: '⚠',
            message: 'Biên lợi nhuận ' + margin.toFixed(1) + '% — cao bất thường. Xem xét lại số liệu.',
            suggestion: null
          };
        }
        return null;
      }
    },
    {
      id: 'so-tien-vay-bang-chu',
      label: 'Số tiền vay bằng chữ',
      check: function(data) {
        var stv = parseNum(data['Số tiền vay'] || data['so_tien_vay'] || '');
        var stvc = data['Số tiền vay bằng chữ'] || data['so_tien_vay_bang_chu'] || '';
        if (stv > 0 && (!stvc || stvc.includes('{{'))) {
          return {
            level: 'hint',
            icon: '💡',
            message: 'Trường "Số tiền vay bằng chữ" đang trống. Công thức sẽ tự điền sau khi nhập số tiền vay.',
            suggestion: null
          };
        }
        return null;
      }
    },
    {
      id: 'thoi-han-vay',
      label: 'Thời hạn vay hợp lệ',
      check: function(data) {
        var thv = parseNum(data['Thời hạn vay'] || data['thoi_han_vay'] || '');
        if (thv > 0 && (thv < 1 || thv > 360)) {
          return {
            level: 'warning',
            icon: '⚠',
            message: 'Thời hạn vay ' + thv + ' tháng — ngoài khoảng thông thường (1–360 tháng). Kiểm tra lại.',
            suggestion: null
          };
        }
        return null;
      }
    }
  ];

  /* ══════════════════════════════════════════════════════════════
   * AI Coach — 5 bước Wizard
   * ══════════════════════════════════════════════════════════════ */
  var STEP_HINTS = {
    1: {
      title: 'Bước 1 — Khách hàng',
      hints: [
        'Nhập đúng CMND/CCCD — đối chiếu với ảnh chụp giấy tờ tùy thân trước khi sang bước 2.',
        'Kiểm tra năm sinh, địa chỉ, danh xưng cho khớp với GTTT gốc.',
        'Thông tin người thừa kế cần đầy đủ: họ tên, CMND, quan hệ.'
      ]
    },
    2: {
      title: 'Bước 2 — PA Vay',
      hints: [
        'Tỷ lệ vốn tự có: Vốn tự có ÷ Tổng nhu cầu vốn × 100. Quy định ≥30%.',
        'Vòng quay vốn: Doanh thu ÷ Vốn lưu động bình quân. Phản ánh hiệu quả kinh doanh.',
        'Nhu cầu vốn 1 vòng quay: Tổng chi phí ÷ Số vòng quay. Là cơ sở tính mức vay.'
      ]
    },
    3: {
      title: 'Bước 3 — TSBĐ',
      hints: [
        'GTCV/GTTS không vượt quá 70% theo quy định.',
        'Kiểm tra giấy tờ pháp lý tài sản: sổ đỏ, sổ hồng, hợp đồng mua bán.',
        'Thông tin chủ tài sản cần khớp với giấy tờ gốc.'
      ]
    },
    4: {
      title: 'Bước 4 — Thẩm định',
      hints: [
        'Đối chiếu thông tin hồ sơ giấy với dữ liệu đã nhập trước khi duyệt.',
        'Kiểm tra CIC — ngày CIC không quá 90 ngày so với ngày lập hồ sơ.',
        'Xác nhận ủy quyền tín dụng đúng hạn mức.'
      ]
    },
    5: {
      title: 'Bước 5 — Xuất hồ sơ',
      hints: [
        'Xuất hồ sơ sẽ thay thế các placeholder {{...}} bằng dữ liệu đã nhập.',
        'Ô còn placeholder màu đỏ = chưa có dữ liệu — kiểm tra trước khi xuất.',
        'Sau khi xuất, kiểm tra file Word/Excel đầu ra trước khi nộp.'
      ]
    }
  };

  /* ══════════════════════════════════════════════════════════════
   * Render panel gợi ý AI
   * ══════════════════════════════════════════════════════════════ */
  function runChecks(data) {
    var results = [];
    RULES.forEach(function(rule) {
      try {
        var r = rule.check(data);
        if (r) results.push({ rule: rule, result: r });
      } catch(e) {}
    });
    return results;
  }

  function renderAIPanel(caseId, currentField) {
    if (!window.store || !window.store.cases) return '';
    var c = window.store.cases[caseId];
    if (!c) return '';
    var data = c.data || c.fields || {};
    var checks = runChecks(data);

    var step = (window.wizardState && window.wizardState.step) || 1;
    var hints = STEP_HINTS[step] || STEP_HINTS[1];

    var checksHtml = checks.length === 0
      ? '<div style="color:var(--muted-fg);font-size:12px;padding:8px 0">✅ Không có cảnh báo cho các quy tắc đã kiểm tra.</div>'
      : checks.map(function(item) {
          var r = item.result;
          var bg = r.level === 'error' ? 'var(--destructive-bg,#FDECEA)' :
                   r.level === 'warning' ? 'var(--warning-bg,#FFF8E6)' :
                   r.level === 'hint' ? 'var(--primary-light,#E6F4ED)' :
                   'var(--secondary,#EFF2F5)';
          var html = '<div style="padding:8px 10px;border-radius:6px;margin-bottom:6px;background:' + bg + ';font-size:12px">' +
            '<div style="font-weight:600;margin-bottom:2px">' + r.icon + ' ' + escHtml(item.rule.label) + '</div>' +
            '<div>' + escHtml(r.message) + '</div>';
          if (r.suggestion) {
            html += '<button onclick="hsvAI.applySuggestion(' + JSON.stringify(caseId) + ',' +
              JSON.stringify(r.suggestion.key) + ',' + JSON.stringify(r.suggestion.value) + ')" ' +
              'style="margin-top:6px;padding:3px 8px;font-size:11px;cursor:pointer;' +
              'background:var(--primary);color:#fff;border:none;border-radius:4px">' +
              'Chèn giá trị đề xuất</button> ' +
              '<button onclick="this.parentElement.style.display=\'none\'" ' +
              'style="padding:3px 8px;font-size:11px;cursor:pointer;' +
              'background:transparent;border:1px solid var(--border);border-radius:4px">Bỏ qua</button>';
          }
          html += '</div>';
          return html;
        }).join('');

    var hintsHtml = hints.hints.map(function(h) {
      return '<li style="font-size:12px;margin-bottom:4px;color:var(--fg)">' + escHtml(h) + '</li>';
    }).join('');

    return '<div id="hsv-ai-panel" style="' +
      'border:1px solid var(--border);border-radius:var(--radius-md);' +
      'background:var(--card);overflow:hidden;margin-top:12px">' +
      '<div style="padding:10px 14px;background:var(--primary);color:#fff;' +
      'display:flex;align-items:center;justify-content:space-between">' +
      '<strong style="font-size:13px">🤖 AI · Gợi ý</strong>' +
      '<span style="font-size:11px;opacity:0.8">' + escHtml(hints.title) + '</span>' +
      '</div>' +

      '<div style="padding:12px 14px;border-bottom:1px solid var(--border)">' +
      '<div style="font-size:11px;text-transform:uppercase;letter-spacing:0.08em;' +
      'color:var(--muted-fg);margin-bottom:8px">Kiểm tra quy tắc nghiệp vụ</div>' +
      checksHtml +
      '</div>' +

      '<div style="padding:12px 14px">' +
      '<div style="font-size:11px;text-transform:uppercase;letter-spacing:0.08em;' +
      'color:var(--muted-fg);margin-bottom:8px">Hướng dẫn ' + escHtml(hints.title) + '</div>' +
      '<ul style="padding-left:16px;margin:0">' + hintsHtml + '</ul>' +
      '</div>' +

      '<div style="padding:8px 14px;background:var(--secondary);' +
      'font-size:10px;color:var(--muted-fg);border-top:1px solid var(--border)">' +
      'AI chỉ CỐ VẤN — mọi thay đổi cần bạn xác nhận · Không gọi API ngoài</div>' +
      '</div>';
  }

  /* ══════════════════════════════════════════════════════════════
   * Áp dụng gợi ý qua doSetValue (KHÔNG có đường ghi tắt)
   * ══════════════════════════════════════════════════════════════ */
  function applySuggestion(caseId, key, value) {
    if (typeof window.doSetValue !== 'function') {
      alert('[HSV AI] Lỗi: doSetValue chưa sẵn sàng.');
      return;
    }
    // Đi qua pipeline doSetValue y hệt gõ tay — KHÔNG có đường tắt
    window.doSetValue(caseId, key, value);
    // Cập nhật panel
    var panel = document.getElementById('hsv-ai-panel');
    if (panel) {
      panel.outerHTML = renderAIPanel(caseId, key);
    }
  }

  /* ── Tiện ích ── */
  function parseNum(v) {
    if (!v) return 0;
    var n = parseFloat(String(v).replace(/[.,\s]/g,'').replace(/[^0-9.-]/g,''));
    return isNaN(n) ? 0 : n;
  }

  function formatVND(n) {
    if (!n) return '0';
    return new Intl.NumberFormat('vi-VN').format(Math.abs(n)) + ' đ';
  }

  function escHtml(str) {
    return String(str)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;');
  }

  /* ── Inject panel vào smart-panel khi wizard đang hiển thị ── */
  function tryInjectAIPanel() {
    var smartPanel = document.querySelector('.smart-panel');
    if (!smartPanel) return;
    var existing = document.getElementById('hsv-ai-panel');
    var cid = window.wizardState && window.wizardState.caseId;
    if (!cid) return;
    if (!existing) {
      smartPanel.insertAdjacentHTML('beforeend', renderAIPanel(cid));
    }
  }

  /* ── MutationObserver ── */
  var _aiObserver = new MutationObserver(function() {
    tryInjectAIPanel();
  });
  _aiObserver.observe(document.body || document.documentElement, {
    childList: true,
    subtree: true
  });

  /* ── Expose public API ── */
  window.hsvAI = {
    version:        AI_VERSION,
    runChecks:      runChecks,
    renderPanel:    renderAIPanel,
    applySuggestion: applySuggestion,
    stepHints:      STEP_HINTS,
    rules:          RULES
  };

  if (window.__HSV_DEBUG__) {
    console.log('[HSV-AI] hsvAI v' + AI_VERSION + ' ready. Rules:', RULES.length);
  }

})(window);
