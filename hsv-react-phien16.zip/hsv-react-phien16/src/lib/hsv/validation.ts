/**
 * PHIÊN 7 — lớp validate sinh TỪ FIELD_META (không gõ tay từng trường).
 * Một khai báo ⇒ Zod schema ⇒ báo lỗi nghiệp vụ (bắt buộc / kiểu / định dạng
 * tiền, ngày). Vẫn CHỈ ĐỌC: hàm chỉ kiểm tra, không ghi dữ liệu hệ cũ.
 */
import { z } from "zod";
import { TABLE_META, cellIssueKey, type TableRows } from "./tableMeta";
import {
  FIELD_META,
  REPEATABLE_META,
  type FieldKind,
  type FieldMeta,
  type HoSo,
} from "./fieldMeta";

export const MONEY_RE = /^-?\d+(\.\d{3})*(,\d+)?$|^-?\d+([.,]\d+)?$/;
export const DATE_RE = /^(\d{2}\/\d{2}\/\d{4}|\d{2}\/\d{4}|\d{4})$/;

export interface Issue {
  key: string;
  label: string;
  group: FieldMeta["group"];
  kind: FieldKind | "repeatable";
  message: string;
}

function toNumber(value: string | number): number | null {
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  const cleaned = value.trim().replace(/\s|đ|VND/gi, "").replace(/\./g, "").replace(/,/g, ".");
  if (cleaned === "" || !/^-?\d+(\.\d+)?$/.test(cleaned)) return null;
  return Number(cleaned);
}

/** Zod schema cho một trường, suy ra từ kind + required. */
export function fieldZod(f: Pick<FieldMeta, "kind" | "required">) {
  const numeric = z
    .union([z.number(), z.string()])
    .refine((v) => toNumber(v) !== null, "phải là số (tiền/số lượng), ví dụ 1.500.000")
    .refine((v) => (toNumber(v) ?? 0) >= 0, "không được âm");
  const dateish = z
    .union([z.number(), z.string()])
    .refine((v) => DATE_RE.test(String(v).trim()), "sai định dạng ngày (dd/mm/yyyy, mm/yyyy hoặc yyyy)");
  const base =
    f.kind === "money" || f.kind === "number" || f.kind === "percent"
      ? numeric
      : f.kind === "date"
        ? dateish
        : z.union([z.number(), z.string()]).refine((v) => String(v).trim() !== "", "không được để trống");
  return f.required ? base : base.optional();
}

/** Schema toàn hồ sơ — sinh từ đúng danh sách FIELD_META. */
export const hoSoZod = z.object(
  Object.fromEntries(FIELD_META.map((f) => [f.key, fieldZod(f)])) as Record<string, z.ZodTypeAny>,
);

export const VALIDATED_FIELD_COUNT = FIELD_META.length;

/** Kiểm tra hồ sơ + các bảng lặp dòng, trả về danh sách lỗi đọc được cho cán bộ. */
export function validateHoSo(hoSo: HoSo, rows: Record<string, Array<string | number>> = {}): Issue[] {
  const issues: Issue[] = [];

  for (const f of FIELD_META) {
    const value = hoSo[f.key];
    const empty = value === undefined || value === null || String(value).trim() === "";
    if (empty) {
      if (f.required)
        issues.push({ key: f.key, label: f.label, group: f.group, kind: f.kind, message: "bắt buộc nhưng đang trống" });
      continue;
    }
    const parsed = fieldZod({ kind: f.kind, required: true }).safeParse(value);
    if (!parsed.success) {
      issues.push({
        key: f.key,
        label: f.label,
        group: f.group,
        kind: f.kind,
        message: parsed.error.issues[0]?.message ?? "giá trị không hợp lệ",
      });
    }
  }

  for (const r of REPEATABLE_META) {
    (rows[r.key] ?? []).forEach((value, i) => {
      if (value === undefined || String(value).trim() === "") return;
      if (toNumber(value) === null)
        issues.push({
          key: `${r.key}[${i}]`,
          label: r.rowLabel(i),
          group: r.group,
          kind: "repeatable",
          message: "phải là số tiền (ví dụ 12.000.000)",
        });
    });
  }

  return issues;
}

/** Hồ sơ hợp lệ sinh tự động từ FIELD_META — dùng làm mốc so sánh trong E2E. */
export function makeValidSample(): HoSo {
  const out: HoSo = {};
  for (const f of FIELD_META) {
    out[f.key] =
      f.kind === "date"
        ? "20/08/2026"
        : f.kind === "money" || f.kind === "number" || f.kind === "percent"
          ? 1000
          : `${f.label} (mẫu)`;
  }
  return out;
}

/** Hồ sơ sai kiểu có chủ đích — chứng minh lớp validate thật sự bắt lỗi. */
export function makeInvalidSample(): { hoSo: HoSo; rows: Record<string, Array<string | number>> } {
  const hoSo = makeValidSample();
  const firstMoney = FIELD_META.find((f) => f.kind === "money");
  const firstDate = FIELD_META.find((f) => f.kind === "date");
  const firstRequired = FIELD_META.find((f) => f.required && f.kind === "text");
  if (firstMoney) hoSo[firstMoney.key] = "một tỷ hai";
  if (firstDate) hoSo[firstDate.key] = "32-13-2026";
  if (firstRequired) hoSo[firstRequired.key] = "";
  return {
    hoSo,
    rows: { chiPhiVatTu: ["12.000.000", "sai số liệu", "", "3.000.000"] },
  };
}

export const sumRows = (values: Array<string | number>): number =>
  values.reduce<number>((s, v) => s + (toNumber(v) ?? 0), 0);

/**
 * PHIÊN 9 — VALIDATE THEO CỘT CHO BẢNG LẶP, sinh từ đúng TABLE_META.
 * Không có nhánh riêng cho từng bảng: thêm bảng mới trong khai báo là tự có
 * validate. Cột `required` không được trống; cột tiền/số phải là số.
 */
export function validateTables(tables: TableRows): Issue[] {
  const issues: Issue[] = [];
  for (const meta of TABLE_META) {
    (tables[meta.key] ?? []).forEach((row, i) => {
      for (const col of meta.columns) {
        const raw = row[col.key];
        const empty = raw === undefined || raw === null || String(raw).trim() === "";
        const label = `${meta.label} · dòng ${i + 1} · ${col.label}`;
        if (empty) {
          if (col.required)
            issues.push({
              key: cellIssueKey(meta.key, i, col.key),
              label,
              group: meta.group,
              kind: "repeatable",
              message: "bắt buộc nhưng đang trống",
            });
          continue;
        }
        const numeric = col.kind === "money" || col.kind === "number" || col.kind === "percent";
        if (numeric && toNumber(raw) === null)
          issues.push({
            key: cellIssueKey(meta.key, i, col.key),
            label,
            group: meta.group,
            kind: "repeatable",
            message: "phải là số tiền (ví dụ 12.000.000)",
          });
      }
    });
  }
  return issues;
}
