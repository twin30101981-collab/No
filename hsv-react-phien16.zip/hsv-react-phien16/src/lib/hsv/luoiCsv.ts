/**
 * PHIÊN 15 (PHẦN 3) — XEM TRƯỚC & SỬA BẢNG CSV TRƯỚC KHI TẠO HỒ SƠ.
 *
 * Phiên 14 tạo hồ sơ ngay khi bấm nhập: một ô sai kiểu (số tiền có chữ, ngày
 * sai định dạng) chỉ lộ ra sau khi đã sinh ra 30 hồ sơ rác. Ở đây bảng được
 * dựng thành LƯỚI: ô sai kiểu / thiếu bắt buộc tô đỏ, sửa ngay trên lưới, chỉ
 * khi sạch mới tạo hồ sơ — vẫn đi qua đúng FIELD_META như nhập tay.
 */
import { FIELD_META, type FieldMeta } from "./fieldMeta";
import { khoaTuTieuDe, tachCsv } from "./nhapHangLoat";
import { DATE_RE, MONEY_RE } from "./validation";

export interface CotLuoi {
  tieuDe: string;
  key: string | null;
  meta: FieldMeta | null;
}

export interface LuoiCsv {
  cot: CotLuoi[];
  dong: string[][];
  loi: string[];
}

const META_BY_KEY = new Map(FIELD_META.map((f) => [f.key, f]));

export function dungLuoi(text: string): LuoiCsv {
  if (!text.trim()) return { cot: [], dong: [], loi: ["Chưa có nội dung bảng để xem trước."] };
  const rows = tachCsv(text);
  if (rows.length < 2) {
    return { cot: [], dong: [], loi: ["Bảng phải có dòng tiêu đề và ít nhất một dòng dữ liệu."] };
  }
  const cot: CotLuoi[] = rows[0]!.map((h) => {
    const tieuDe = h.trim();
    const key = khoaTuTieuDe(tieuDe);
    return { tieuDe, key, meta: key ? (META_BY_KEY.get(key) ?? null) : null };
  });
  const loi: string[] = [];
  if (cot.every((c) => c.key === null)) {
    loi.push("Không có cột nào khớp FIELD_META — kiểm tra lại dòng tiêu đề.");
  }
  const dong = rows.slice(1).map((r) => cot.map((_, i) => (r[i] ?? "").trim()));
  return { cot, dong, loi };
}

/** Lỗi của một ô: chuỗi rỗng nghĩa là ô hợp lệ. */
export function loiO(cot: CotLuoi, giaTri: string): string {
  const v = giaTri.trim();
  if (!cot.key) return "";
  const meta = cot.meta;
  if (!meta) return "";
  if (v === "") return meta.required ? `Thiếu “${meta.label}” (bắt buộc)` : "";
  if (meta.kind === "money" || meta.kind === "number" || meta.kind === "percent") {
    if (!MONEY_RE.test(v)) return `“${meta.label}” phải là số, ví dụ 300.000.000`;
    return "";
  }
  if (meta.kind === "date" && !DATE_RE.test(v)) {
    return `“${meta.label}” sai định dạng ngày (dd/mm/yyyy)`;
  }
  return "";
}

export interface ThongKeLuoi {
  soO: number;
  soOSai: number;
  soDongSai: number;
  soCotKhop: number;
  cotLa: string[];
}

export function loiLuoi(luoi: LuoiCsv): Map<string, string> {
  const m = new Map<string, string>();
  luoi.dong.forEach((r, ri) =>
    r.forEach((v, ci) => {
      const e = loiO(luoi.cot[ci]!, v);
      if (e) m.set(`${ri}:${ci}`, e);
    }),
  );
  return m;
}

export function thongKeLuoi(luoi: LuoiCsv, loi: Map<string, string>): ThongKeLuoi {
  const dongSai = new Set<number>();
  loi.forEach((_, k) => dongSai.add(Number(k.split(":")[0])));
  return {
    soO: luoi.dong.length * luoi.cot.length,
    soOSai: loi.size,
    soDongSai: dongSai.size,
    soCotKhop: luoi.cot.filter((c) => c.key).length,
    cotLa: luoi.cot.filter((c) => !c.key && c.tieuDe !== "").map((c) => c.tieuDe),
  };
}

export function datO(luoi: LuoiCsv, ri: number, ci: number, v: string): LuoiCsv {
  const dong = luoi.dong.map((r, i) => (i === ri ? r.map((c, j) => (j === ci ? v : c)) : r));
  return { ...luoi, dong };
}

export function xoaDong(luoi: LuoiCsv, ri: number): LuoiCsv {
  return { ...luoi, dong: luoi.dong.filter((_, i) => i !== ri) };
}

function boc(v: string): string {
  return /[",\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v;
}

/** Lưới đã sửa quay lại CSV để đi qua đúng đường nhập hàng loạt của phiên 14. */
export function luoiThanhCsv(luoi: LuoiCsv): string {
  return [luoi.cot.map((c) => boc(c.tieuDe)), ...luoi.dong.map((r) => r.map(boc))]
    .map((r) => r.join(","))
    .join("\n");
}

export function tomTatLuoi(tk: ThongKeLuoi, soDong: number): string {
  if (soDong === 0) return "Lưới trống — chưa có dòng nào để tạo hồ sơ.";
  if (tk.soOSai === 0) {
    return `Lưới sạch: ${soDong} dòng × ${tk.soCotKhop} cột khớp FIELD_META, không có ô sai.`;
  }
  return `Còn ${tk.soOSai} ô sai ở ${tk.soDongSai}/${soDong} dòng — sửa ô đỏ rồi mới tạo hồ sơ.`;
}
