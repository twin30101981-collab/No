/**
 * PHIÊN 11 — TÀI SẢN BẢO ĐẢM NÂNG CAO: NHIỀU TÀI SẢN, MỖI TÀI SẢN NHIỀU THỬA/GIẤY TỜ.
 *
 * Hệ cũ chỉ mô tả được MỘT thửa đất cho MỘT tài sản (bộ trường `.ts.Số thửa`,
 * `.ts.Diện tích đất`…), nên hồ sơ nhiều thửa phải gõ tay vào hợp đồng thế chấp
 * ⇒ sai sót và không kiểm soát được. Ở bản React, mỗi dòng tài sản trong bảng
 * `danhSachTaiSan` có danh sách thửa/giấy tờ riêng, và CÂU MÔ TẢ trong hợp đồng
 * thế chấp được GHÉP TỰ ĐỘNG từ dữ liệu đó — một nguồn số duy nhất.
 *
 * Vẫn CHỈ ĐỌC với hệ cũ: không ghi/xoá dữ liệu hệ cũ.
 */
import type { HoSo } from "./fieldMeta";
import { formatMoney, toNumber, type TableRow, type TableRows } from "./tableMeta";

export interface ThuaColumn {
  key: string;
  label: string;
  kind: "text" | "number";
  width: number;
  required?: boolean;
}

/** Khai báo cột của bảng thửa/giấy tờ — dùng chung cho giao diện và câu ghép. */
export const THUA_COLUMNS: readonly ThuaColumn[] = [
  { key: "soThua", label: "Số thửa", kind: "text", width: 14, required: true },
  { key: "toBanDo", label: "Tờ bản đồ", kind: "text", width: 14 },
  { key: "dienTich", label: "Diện tích (m²)", kind: "number", width: 16, required: true },
  { key: "soGiayChungNhan", label: "Số giấy chứng nhận", kind: "text", width: 28, required: true },
  { key: "loaiDat", label: "Loại đất / loại giấy tờ", kind: "text", width: 28 },
];

export type ThuaRow = Record<string, string | number>;
/** Khoá = chỉ số dòng tài sản trong bảng danhSachTaiSan. */
export type ThuaByTaiSan = Record<string, ThuaRow[]>;

export const THUA_STORAGE_KEY = "hsv.thuaTaiSan.v1";
export const TAI_SAN_TABLE = "danhSachTaiSan";
export const MAX_THUA = 10;

export function emptyThua(): ThuaRow {
  return Object.fromEntries(THUA_COLUMNS.map((c) => [c.key, ""]));
}

export function thuaCuaTaiSan(map: ThuaByTaiSan, index: number): ThuaRow[] {
  return map[String(index)] ?? [];
}

/** Dữ liệu mẫu: tài sản 1 có 2 thửa, tài sản 2 và 3 mỗi tài sản 1 giấy tờ. */
export function demoThua(): ThuaByTaiSan {
  return {
    "0": [
      {
        soThua: "45",
        toBanDo: "12",
        dienTich: 120,
        soGiayChungNhan: "CX 123456",
        loaiDat: "Đất ở tại đô thị",
      },
      {
        soThua: "46",
        toBanDo: "12",
        dienTich: 86,
        soGiayChungNhan: "CX 123457",
        loaiDat: "Đất trồng cây lâu năm",
      },
    ],
    "1": [
      {
        soThua: "45",
        toBanDo: "12",
        dienTich: 96,
        soGiayChungNhan: "CX 123456 (hạng mục nhà)",
        loaiDat: "Nhà ở riêng lẻ",
      },
    ],
    "2": [
      {
        soThua: "—",
        toBanDo: "—",
        dienTich: 0,
        soGiayChungNhan: "Đăng ký xe 18C-123.45",
        loaiDat: "Động sản — phương tiện vận tải",
      },
    ],
  };
}

/** Tổng diện tích tất cả các thửa của mọi tài sản. */
export function tongDienTich(map: ThuaByTaiSan): number {
  return Object.values(map)
    .flat()
    .reduce((s, r) => s + toNumber(r["dienTich"]), 0);
}

export function soThuaTong(map: ThuaByTaiSan): number {
  return Object.values(map).reduce((s, rows) => s + rows.length, 0);
}

/** Lỗi ô của bảng thửa (cột bắt buộc trống / diện tích không phải số). */
export interface ThuaIssue {
  key: string;
  label: string;
  message: string;
}

export function validateThua(tables: TableRows, map: ThuaByTaiSan): ThuaIssue[] {
  const assets = tables[TAI_SAN_TABLE] ?? [];
  const issues: ThuaIssue[] = [];
  assets.forEach((asset, i) => {
    const rows = thuaCuaTaiSan(map, i);
    const ten = String(asset["tenTaiSan"] ?? `Tài sản ${i + 1}`);
    // Tài sản chưa khai thửa/giấy tờ (ví dụ động sản mới thêm) KHÔNG chặn xuất:
    // câu mô tả chỉ bỏ qua phần chi tiết. Đã khai thì mọi cột bắt buộc phải đủ.
    if (rows.length === 0) return;
    rows.forEach((row, j) => {
      for (const c of THUA_COLUMNS) {
        const raw = row[c.key];
        const empty = raw === undefined || String(raw).trim() === "";
        if (c.required && empty) {
          issues.push({
            key: `thua[${i}][${j}].${c.key}`,
            label: `${ten} — thửa ${j + 1} · ${c.label}`,
            message: "bắt buộc nhưng đang trống",
          });
          continue;
        }
        if (!empty && c.kind === "number" && !/^\d+([.,]\d+)?$/.test(String(raw).trim())) {
          issues.push({
            key: `thua[${i}][${j}].${c.key}`,
            label: `${ten} — thửa ${j + 1} · ${c.label}`,
            message: "phải là số (ví dụ 120)",
          });
        }
      }
    });
  });
  return issues;
}

function cauMotTaiSan(asset: TableRow, index: number, rows: ThuaRow[]): string {
  const ten = String(asset["tenTaiSan"] ?? "").trim() || `Tài sản ${index + 1}`;
  const diaChi = String(asset["diaChi"] ?? "").trim();
  const giaTri = toNumber(asset["giaTri"]);
  const phanThua = rows.map((r, j) => {
    const bits = [
      `thửa số ${String(r["soThua"] ?? "").trim() || "—"}`,
      `tờ bản đồ ${String(r["toBanDo"] ?? "").trim() || "—"}`,
      `diện tích ${toNumber(r["dienTich"]).toLocaleString("vi-VN")} m²`,
      `giấy chứng nhận số ${String(r["soGiayChungNhan"] ?? "").trim() || "—"}`,
    ];
    const loai = String(r["loaiDat"] ?? "").trim();
    if (loai) bits.push(`loại ${loai}`);
    return `(${j + 1}) ${bits.join(", ")}`;
  });
  const dienTichTs = rows.reduce((s, r) => s + toNumber(r["dienTich"]), 0);
  return [
    `Tài sản ${index + 1}: ${ten}`,
    diaChi ? ` tại ${diaChi}` : "",
    `, gồm ${rows.length} thửa/giấy tờ`,
    dienTichTs > 0 ? ` (tổng diện tích ${dienTichTs.toLocaleString("vi-VN")} m²)` : "",
    phanThua.length > 0 ? `: ${phanThua.join("; ")}` : "",
    `; giá trị định giá ${formatMoney(giaTri)}.`,
  ].join("");
}

/** Ghép câu mô tả tài sản thế chấp cho hợp đồng — nhiều tài sản, nhiều thửa. */
export function ghepCauTheChap(tables: TableRows, map: ThuaByTaiSan): string {
  const assets = tables[TAI_SAN_TABLE] ?? [];
  if (assets.length === 0) return "";
  return assets.map((a, i) => cauMotTaiSan(a, i, thuaCuaTaiSan(map, i))).join(" ");
}

/** Hồ sơ với trường “Mô tả tài sản thế chấp” được ghi đè từ dữ liệu thửa. */
export function applyTaiSanChiTiet(
  hoSo: HoSo,
  tables: TableRows,
  map: ThuaByTaiSan,
): HoSo {
  const cau = ghepCauTheChap(tables, map);
  return cau ? { ...hoSo, moTaTaiSanTheChap: cau } : { ...hoSo };
}
