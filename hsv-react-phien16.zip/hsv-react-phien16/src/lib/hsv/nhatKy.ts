/**
 * PHIÊN 14 (PHẦN 3) — NHẬT KÝ THAO TÁC & HOÀN TÁC TRONG PHIÊN LÀM VIỆC.
 *
 * Rủi ro lớn nhất khi làm nhanh: bấm nhầm "Xoá hồ sơ" hoặc áp mẫu đè lên dữ
 * liệu vừa gõ, mất công cả buổi vì hệ cũ không có Undo. Ở đây mọi thao tác
 * làm ĐỔI danh mục hồ sơ đều ghi một mốc kèm ảnh chụp trạng thái trước đó,
 * cán bộ hoàn tác được từng bước và nhìn thấy mình vừa làm gì.
 *
 * Hệ cũ vẫn CHỈ ĐỌC: nhật ký chỉ nói về dữ liệu phiên làm việc React.
 */
import type { Workspace } from "./hoSoWorkspace";

export const MAX_MOC = 20;

export interface MocNhatKy {
  id: string;
  nhan: string;
  luc: number;
  /** Trạng thái phiên làm việc TRƯỚC khi thao tác diễn ra. */
  truoc: Workspace;
}

let seqMoc = 0;

/** Ghi một mốc nhật ký; mốc cũ nhất bị đẩy ra khi vượt MAX_MOC. */
export function ghiMoc(ds: MocNhatKy[], nhan: string, truoc: Workspace): MocNhatKy[] {
  seqMoc += 1;
  const moc: MocNhatKy = {
    id: `moc-${Date.now().toString(36)}-${seqMoc}`,
    nhan,
    luc: Date.now(),
    truoc: JSON.parse(JSON.stringify(truoc)) as Workspace,
  };
  return [moc, ...ds].slice(0, MAX_MOC);
}

export interface KetQuaHoanTac {
  ds: MocNhatKy[];
  ws: Workspace | null;
  nhan: string;
}

/** Hoàn tác một bước: trả lại trạng thái trước của mốc gần nhất. */
export function hoanTac(ds: MocNhatKy[]): KetQuaHoanTac {
  const moc = ds[0];
  if (!moc) return { ds, ws: null, nhan: "" };
  return { ds: ds.slice(1), ws: moc.truoc, nhan: moc.nhan };
}

export function nhanGio(luc: number): string {
  const d = new Date(luc);
  const hai = (n: number) => String(n).padStart(2, "0");
  return `${hai(d.getHours())}:${hai(d.getMinutes())}:${hai(d.getSeconds())}`;
}

export function tomTatNhatKy(ds: MocNhatKy[]): string {
  if (ds.length === 0) return "Chưa có thao tác nào để hoàn tác.";
  return `${ds.length} thao tác có thể hoàn tác — gần nhất: ${ds[0]!.nhan}.`;
}
