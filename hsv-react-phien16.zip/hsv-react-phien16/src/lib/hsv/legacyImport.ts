/**
 * PHIÊN 12 (PHẦN 1) — NHẬP HỒ SƠ TỪ HỆ CŨ THEO YÊU CẦU.
 *
 * Cán bộ bấm "Nhập từ hệ cũ": app quét dữ liệu hệ cũ trong localStorage
 * (qua adapter CHỈ ĐỌC đã có), chuẩn hoá về FIELD_META và tạo thêm hồ sơ mới
 * trong phiên làm việc React. Không ghi, không xoá, không migrate dữ liệu hệ cũ.
 */
import { FIELD_META, type HoSo } from "./fieldMeta";
import { scanLegacyData, type LegacyRecord } from "./legacyAdapter";
import { initialTableRows } from "./repeatableData";
import { demoThua } from "./taiSanChiTiet";
import { goiYTen, newId, type HoSoItem } from "./hoSoWorkspace";

export interface KetQuaNhap {
  items: HoSoItem[];
  soKhoaQuet: number;
  soKhoaKhop: number;
  warnings: string[];
}

/** Số trường FIELD_META thực sự có dữ liệu trong bản ghi hệ cũ. */
export function soTruongCoDuLieu(hoSo: HoSo): number {
  return FIELD_META.filter((f) => {
    const v = hoSo[f.key];
    return v !== undefined && v !== null && String(v).trim() !== "";
  }).length;
}

export function recordToItem(rec: LegacyRecord): HoSoItem {
  const soTruong = soTruongCoDuLieu(rec.hoSo);
  return {
    id: newId("hecu"),
    ten: goiYTen(rec.hoSo, rec.storageKey),
    nguon: "he-cu",
    ghiChuNguon: `${rec.source} · khoá ${rec.storageKey} · ${soTruong} trường khớp FIELD_META`,
    hoSo: { ...rec.hoSo },
    tables: initialTableRows(),
    thua: demoThua(),
    capNhat: Date.now(),
  };
}

export async function nhapTuHeCu(): Promise<KetQuaNhap> {
  const report = await scanLegacyData();
  return {
    items: report.records.map(recordToItem),
    soKhoaQuet: report.scannedKeys,
    soKhoaKhop: report.matchedKeys,
    warnings: report.warnings,
  };
}

export function tomTatNhap(kq: KetQuaNhap): string {
  if (kq.items.length === 0) {
    return `Không thấy hồ sơ hệ cũ trên máy này (đã quét ${kq.soKhoaQuet} khoá). Hệ cũ giữ nguyên, không bị ghi/xoá.`;
  }
  const tong = kq.items.reduce((s, i) => s + soTruongCoDuLieu(i.hoSo), 0);
  return `Đã nhập ${kq.items.length} hồ sơ từ hệ cũ (${tong} trường khớp FIELD_META) — chỉ đọc, hệ cũ giữ nguyên.`;
}
