/**
 * PHIÊN 16 (PHẦN 4) — GÓI HỒ SƠ DÙNG CHUNG THEO PHÒNG (.hsv.json) CÓ KHOÁ.
 *
 * Tệp bộ hồ sơ phiên 13 chỉ để một người tự lưu/tự nạp. Khi cả phòng cùng gửi
 * tệp cho nhau, rủi ro là hai người sửa cùng một hồ sơ rồi ghi đè mất công
 * nhau. Ở đây mỗi hồ sơ mang một KHOÁ (id + số bản); khi gộp gói:
 *   - bản đến MỚI HƠN  → cập nhật,
 *   - bản đến CŨ HƠN   → bỏ qua (giữ bản đang có),
 *   - CÙNG số bản mà nội dung khác → xung đột: giữ nguyên bản đang có và thêm
 *     một bản sao ghi rõ của ai, để hai người đối chiếu rồi tự chốt.
 *
 * Không cần backend; hệ cũ vẫn CHỈ ĐỌC.
 */
import { newId, type HoSoItem } from "./hoSoWorkspace";

export const GOI_KIND = "hsv.goiPhong";
export const GOI_VERSION = 1;
export const GOI_EXT = ".goi.hsv.json";

export interface MucGoi {
  khoa: string;
  ban: number;
  ten: string;
  nguoiGui: string;
  capNhat: number;
  item: HoSoItem;
}

export interface NoiDungGoi {
  kind: typeof GOI_KIND;
  version: number;
  phong: string;
  nguoiGui: string;
  taoLuc: number;
  mucs: MucGoi[];
}

export function khoaCuaHoSo(item: HoSoItem): string {
  return item.khoa ?? item.id;
}

export function tenTepGoi(phong: string, now = new Date()): string {
  const hai = (n: number) => String(n).padStart(2, "0");
  const slug = phong
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
  return `goi-${slug || "phong"}-${now.getFullYear()}${hai(now.getMonth() + 1)}${hai(
    now.getDate(),
  )}-${hai(now.getHours())}${hai(now.getMinutes())}${GOI_EXT}`;
}

export function taoGoiPhong(
  items: HoSoItem[],
  nguoiGui: string,
  phong: string,
  now = new Date(),
) {
  const mucs: MucGoi[] = items.map((item) => ({
    khoa: khoaCuaHoSo(item),
    ban: item.ban ?? 1,
    ten: item.ten,
    nguoiGui: nguoiGui.trim() || "không rõ",
    capNhat: item.capNhat,
    item: { ...item, khoa: khoaCuaHoSo(item), ban: item.ban ?? 1 },
  }));
  const noiDung: NoiDungGoi = {
    kind: GOI_KIND,
    version: GOI_VERSION,
    phong: phong.trim() || "Phòng KHKD",
    nguoiGui: nguoiGui.trim() || "không rõ",
    taoLuc: now.getTime(),
    mucs,
  };
  const blob = new Blob([JSON.stringify(noiDung, null, 2)], {
    type: "application/json;charset=utf-8",
  });
  return { blob, fileName: tenTepGoi(phong, now), soHoSo: mucs.length };
}

const isObj = (v: unknown): v is Record<string, unknown> =>
  typeof v === "object" && v !== null && !Array.isArray(v);

export interface KetQuaDocGoi {
  mucs: MucGoi[];
  phong: string;
  nguoiGui: string;
  loi: string[];
}

export function docGoiPhong(text: string): KetQuaDocGoi {
  const rong: KetQuaDocGoi = { mucs: [], phong: "", nguoiGui: "", loi: [] };
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    return { ...rong, loi: ["Tệp không phải JSON hợp lệ."] };
  }
  if (!isObj(data) || data["kind"] !== GOI_KIND) {
    return { ...rong, loi: [`Không phải gói hồ sơ dùng chung (thiếu dấu hiệu "${GOI_KIND}").`] };
  }
  if (Number(data["version"]) > GOI_VERSION) {
    return { ...rong, loi: ["Gói tạo bởi phiên bản mới hơn — hãy cập nhật ứng dụng."] };
  }
  const raw = data["mucs"];
  if (!Array.isArray(raw) || raw.length === 0) {
    return { ...rong, loi: ["Gói không chứa hồ sơ nào."] };
  }
  const loi: string[] = [];
  const mucs: MucGoi[] = [];
  raw.forEach((m, i) => {
    if (!isObj(m) || !isObj(m["item"])) {
      loi.push(`Mục ${i + 1}: sai định dạng, đã bỏ qua.`);
      return;
    }
    const item = m["item"] as unknown as HoSoItem;
    if (!item.id || !item.hoSo) {
      loi.push(`Mục ${i + 1}: thiếu dữ liệu hồ sơ, đã bỏ qua.`);
      return;
    }
    mucs.push({
      khoa: String(m["khoa"] ?? item.id),
      ban: Number(m["ban"] ?? 1) || 1,
      ten: String(m["ten"] ?? item.ten ?? "Hồ sơ"),
      nguoiGui: String(m["nguoiGui"] ?? ""),
      capNhat: Number(m["capNhat"] ?? item.capNhat ?? 0),
      item,
    });
  });
  return {
    mucs,
    phong: String(data["phong"] ?? ""),
    nguoiGui: String(data["nguoiGui"] ?? ""),
    loi,
  };
}

export interface KetQuaGop {
  items: HoSoItem[];
  them: number;
  capNhat: number;
  boQua: number;
  xungDot: string[];
}

const noiDungGiong = (a: HoSoItem, b: HoSoItem) =>
  JSON.stringify([a.hoSo, a.tables, a.thua]) === JSON.stringify([b.hoSo, b.tables, b.thua]);

/** Gộp gói vào danh mục đang mở theo khoá — không bao giờ ghi đè âm thầm. */
export function gopGoiPhong(hienTai: HoSoItem[], mucs: MucGoi[]): KetQuaGop {
  const items = [...hienTai];
  const kq: KetQuaGop = { items, them: 0, capNhat: 0, boQua: 0, xungDot: [] };
  for (const muc of mucs) {
    const at = items.findIndex((i) => khoaCuaHoSo(i) === muc.khoa);
    const den: HoSoItem = { ...muc.item, khoa: muc.khoa, ban: muc.ban };
    if (at < 0) {
      items.push(den);
      kq.them += 1;
      continue;
    }
    const dang = items[at]!;
    const banDang = dang.ban ?? 1;
    if (muc.ban > banDang) {
      items[at] = { ...den, id: dang.id };
      kq.capNhat += 1;
      continue;
    }
    if (muc.ban < banDang || noiDungGiong(dang, den)) {
      kq.boQua += 1;
      continue;
    }
    items.push({
      ...den,
      id: newId(),
      khoa: `${muc.khoa}-xd`,
      ten: `${muc.ten} (bản của ${muc.nguoiGui || "người gửi"})`,
      ghiChuNguon: `Xung đột bản ${muc.ban} với hồ sơ “${dang.ten}” — giữ cả hai để đối chiếu`,
    });
    kq.xungDot.push(`“${muc.ten}” cùng bản ${muc.ban} nhưng nội dung khác — đã giữ cả hai bản.`);
  }
  return kq;
}

export function tomTatGop(kq: KetQuaGop): string {
  return `Đã gộp gói: thêm ${kq.them}, cập nhật ${kq.capNhat}, bỏ qua ${kq.boQua}, xung đột ${kq.xungDot.length}.`;
}

/** Tăng số bản khi cán bộ chốt một lần sửa để gửi cho phòng. */
export function tangBan(item: HoSoItem): HoSoItem {
  return { ...item, khoa: khoaCuaHoSo(item), ban: (item.ban ?? 1) + 1 };
}
