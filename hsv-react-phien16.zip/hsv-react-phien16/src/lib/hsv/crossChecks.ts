/**
 * PHIÊN 11 — KIỂM TRA CHÉO NGHIỆP VỤ (không chỉ kiểm tra từng ô rời rạc).
 *
 * Hệ cũ kiểm tra từng trường độc lập nên vẫn lọt các hồ sơ mâu thuẫn:
 * số tiền vay lớn hơn tổng nhu cầu vốn của phương án, hoặc giá trị TSBĐ
 * không đủ tỷ lệ bảo đảm tối thiểu. Ở bản React, các quy tắc chéo được
 * khai báo tập trung tại đây, dùng chung cho giao diện và cửa chặn xuất DOCX.
 */
import type { HoSo } from "./fieldMeta";
import { formatMoney, toNumber } from "./tableMeta";
import type { Issue } from "./validation";

/** Tỷ lệ cho vay tối đa trên giá trị TSBĐ (giá trị TSBĐ ≥ 1/0,7 lần số tiền vay). */
export const TY_LE_CHO_VAY_TOI_DA = 0.7;

export interface CrossRule {
  key: string;
  label: string;
  /** Diễn giải để hiển thị cho cán bộ, luôn nêu rõ căn cứ. */
  describe: (hoSo: HoSo) => string;
  check: (hoSo: HoSo) => string | null;
}

const so = (hoSo: HoSo, key: string) => toNumber(hoSo[key] as string | number | undefined);

export const CROSS_RULES: readonly CrossRule[] = [
  {
    key: "vonVsVay",
    label: "Tổng nhu cầu vốn ≥ Số tiền vay",
    describe: (h) =>
      `Tổng nhu cầu vốn ${formatMoney(so(h, "tongNhuCauVon"))} so với số tiền vay ${formatMoney(
        so(h, "soTienVay"),
      )}.`,
    check: (h) => {
      const von = so(h, "tongNhuCauVon");
      const vay = so(h, "soTienVay");
      if (von <= 0 || vay <= 0) return null;
      return von >= vay
        ? null
        : `số tiền vay ${formatMoney(vay)} vượt tổng nhu cầu vốn của phương án ${formatMoney(von)}`;
    },
  },
  {
    key: "tsbdVsVay",
    label: `Giá trị TSBĐ ≥ số tiền vay / ${TY_LE_CHO_VAY_TOI_DA}`,
    describe: (h) => {
      const ts = so(h, "tongGiaTriTs");
      const vay = so(h, "soTienVay");
      const tyLe = ts > 0 ? (vay / ts) * 100 : 0;
      return `Giá trị TSBĐ ${formatMoney(ts)}, mức vay bằng ${tyLe.toLocaleString("vi-VN", {
        maximumFractionDigits: 1,
      })}% giá trị tài sản (tối đa ${TY_LE_CHO_VAY_TOI_DA * 100}%).`;
    },
    check: (h) => {
      const ts = so(h, "tongGiaTriTs");
      const vay = so(h, "soTienVay");
      if (ts <= 0 || vay <= 0) return null;
      const toiThieu = vay / TY_LE_CHO_VAY_TOI_DA;
      return ts >= toiThieu
        ? null
        : `giá trị TSBĐ ${formatMoney(ts)} thấp hơn mức tối thiểu ${formatMoney(
            Math.round(toiThieu),
          )} (vay tối đa ${TY_LE_CHO_VAY_TOI_DA * 100}% giá trị tài sản)`;
    },
  },
  {
    key: "vonTuCo",
    label: "Vốn tự có + Số tiền vay ≥ Tổng nhu cầu vốn",
    describe: (h) =>
      `Vốn tự có ${formatMoney(so(h, "vonTuCo"))} cộng số tiền vay ${formatMoney(
        so(h, "soTienVay"),
      )} so với tổng nhu cầu vốn ${formatMoney(so(h, "tongNhuCauVon"))}.`,
    check: (h) => {
      const von = so(h, "tongNhuCauVon");
      const tuCo = so(h, "vonTuCo");
      const vay = so(h, "soTienVay");
      if (von <= 0 || vay <= 0) return null;
      return tuCo + vay >= von
        ? null
        : `vốn tự có ${formatMoney(tuCo)} cộng vay ${formatMoney(
            vay,
          )} chưa đủ tổng nhu cầu vốn ${formatMoney(von)}`;
    },
  },
];

export interface CrossResult {
  rule: CrossRule;
  ok: boolean;
  message: string;
  detail: string;
}

export function crossResults(hoSo: HoSo): CrossResult[] {
  return CROSS_RULES.map((rule) => {
    const message = rule.check(hoSo);
    return { rule, ok: message === null, message: message ?? "đạt", detail: rule.describe(hoSo) };
  });
}

/** Lỗi kiểm tra chéo dưới dạng Issue chung — vào cùng cửa chặn xuất DOCX. */
export function crossIssues(hoSo: HoSo): Issue[] {
  return crossResults(hoSo)
    .filter((r) => !r.ok)
    .map((r) => ({
      key: `cross.${r.rule.key}`,
      label: r.rule.label,
      group: "pa-sxkd" as const,
      kind: "repeatable" as const,
      message: r.message,
    }));
}
