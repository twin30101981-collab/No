/**
 * PHIÊN 13 — TIẾN ĐỘ HỒ SƠ.
 *
 * Trưởng phòng nhìn MỘT màn hình biết hồ sơ nào đã đủ trường, hồ sơ nào còn
 * thiếu gì, và hồ sơ nào đã xuất tài liệu. Không có logic mới về nghiệp vụ:
 * dùng đúng cửa chặn xuất (blockingIssues) đang áp cho DOCX/ZIP, nên "đủ" ở
 * bảng tiến độ đồng nghĩa với "xuất được".
 *
 * Hệ cũ vẫn CHỈ ĐỌC — tiến độ tính hoàn toàn trên dữ liệu phiên làm việc.
 */
import { applyDerived } from "./derived";
import { blockingIssues } from "./exportGuard";
import { demoRows } from "./repeatableData";
import { applyTaiSanChiTiet } from "./taiSanChiTiet";
import type { HoSoItem } from "./hoSoWorkspace";

export interface TienDoHoSo {
  id: string;
  ten: string;
  du: boolean;
  soLoi: number;
  /** Tối đa 3 lỗi đầu, hiển thị gọn trên bảng. */
  thieu: string[];
  daXuat?: number | undefined;
  capNhat: number;
}

export function tienDoHoSo(item: HoSoItem): TienDoHoSo {
  const hoSo = applyTaiSanChiTiet(
    applyDerived(item.hoSo, item.tables),
    item.tables,
    item.thua,
  );
  const loi = blockingIssues(hoSo, demoRows, item.tables, item.thua);
  return {
    id: item.id,
    ten: item.ten,
    du: loi.length === 0,
    soLoi: loi.length,
    thieu: loi.slice(0, 3).map((i) => `${i.label}: ${i.message}`),
    daXuat: item.daXuat,
    capNhat: item.capNhat,
  };
}

export function tienDoDanhSach(items: HoSoItem[]): TienDoHoSo[] {
  return items.map(tienDoHoSo);
}

export function tomTatTienDo(ds: TienDoHoSo[]) {
  return {
    tong: ds.length,
    du: ds.filter((t) => t.du).length,
    thieu: ds.filter((t) => !t.du).length,
    daXuat: ds.filter((t) => t.daXuat).length,
  };
}

export function nhanThoiGian(ts?: number): string {
  if (!ts) return "—";
  const d = new Date(ts);
  const hai = (n: number) => String(n).padStart(2, "0");
  return `${hai(d.getDate())}/${hai(d.getMonth() + 1)} ${hai(d.getHours())}:${hai(d.getMinutes())}`;
}
