/**
 * PHIÊN 8 — XUẤT TỆP DOCX THẬT từ mẫu khai báo (thay 83 mẫu base64 ~9,7 MB của hệ cũ).
 * Sinh tệp phía trình duyệt bằng thư viện `docx`; KHÔNG ghi/xoá dữ liệu hệ cũ.
 * Nguyên tắc: chặn xuất khi lớp validate còn lỗi trường BẮT BUỘC.
 *
 * Nửa sau Phiên 8: bảng lặp dòng (danh mục TSBĐ, chi phí vật tư) được in thành
 * BẢNG THẬT trong DOCX (w:tbl) với đủ số dòng + dòng tổng cộng — vá finding 16.7
 * "vòng lặp tài sản" của hệ cũ (trước đây chỉ in được tài sản đầu tiên).
 */
import {
  AlignmentType,
  Document,
  HeadingLevel,
  Packer,
  Paragraph,
  Table,
  TableCell,
  TableRow as DocxTableRow,
  TextRun,
  WidthType,
} from "docx";
import type { HoSo } from "./fieldMeta";
import { renderTemplate, type DocTemplate } from "./docTemplate";
import { blockingIssues } from "./exportGuard";
import { applyDerived } from "./derived";
import { findTable } from "./tableMeta";
import { dongDiaDiemNgay, oNhanKy } from "./kyDuyet";
import {
  TABLE_META,
  formatMoney,
  tableTotal,
  toNumber,
  type TableMeta,
  type TableRow,
  type TableRows,
} from "./tableMeta";

export { blockingIssues, canExport } from "./exportGuard";


const slug = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/gi, "d")
    .replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/^-|-$/g, "");

/** Tên tệp theo hồ sơ: <mã mẫu>_<số hồ sơ>_<tên khách hàng>.docx */
export function docxFileName(template: DocTemplate, hoSo: HoSo): string {
  const soHoSo = hoSo["soHoSo"] ?? "khong-so";
  const ten = slug(String(hoSo["tenKhachHang"] ?? "ho-so"));
  return `${template.id.toUpperCase()}_${soHoSo}_${ten}.docx`;
}

const cell = (text: string, opts: { bold?: boolean; width: number }) =>
  new TableCell({
    width: { size: opts.width, type: WidthType.PERCENTAGE },
    children: [
      new Paragraph({ children: [new TextRun(opts.bold ? { text, bold: true } : { text })] }),
    ],
  });

/** Một bảng lặp dòng ⇒ một bảng OOXML thật (tiêu đề cột + n dòng + tổng cộng). */
export function buildTable(meta: TableMeta, rows: TableRow[]): Table {
  const header = new DocxTableRow({
    tableHeader: true,
    children: meta.columns.map((c) => cell(c.label, { bold: true, width: c.width })),
  });

  const body = rows.map(
    (row) =>
      new DocxTableRow({
        children: meta.columns.map((c) =>
          cell(
            c.kind === "money" ? formatMoney(toNumber(row[c.key])) : String(row[c.key] ?? ""),
            { width: c.width },
          ),
        ),
      }),
  );

  const footer = meta.totalColumn
    ? [
        new DocxTableRow({
          children: meta.columns.map((c, i) =>
            c.key === meta.totalColumn
              ? cell(formatMoney(tableTotal(meta, rows)), { bold: true, width: c.width })
              : cell(i === 0 ? "TỔNG CỘNG" : "", { bold: true, width: c.width }),
          ),
        }),
      ]
    : [];

  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [header, ...body, ...footer],
  });
}

/** Dựng tài liệu DOCX từ mẫu + hồ sơ (đã điền qua FIELD_META) + bảng lặp dòng. */
export function buildDocxDocument(
  template: DocTemplate,
  hoSoGoc: HoSo,
  tables: TableRows = {},
): Document {
  // PHIÊN 10 — tổng và phần "bằng chữ" luôn lấy từ bảng lặp, cán bộ không gõ lại.
  const hoSo = applyDerived(hoSoGoc, tables);
  const rendered = renderTemplate(template, hoSo);
  const children: Array<Paragraph | Table> = [
    new Paragraph({
      heading: HeadingLevel.HEADING_1,
      children: [new TextRun({ text: template.name.toUpperCase(), bold: true })],
    }),
    new Paragraph({
      children: [
        new TextRun({
          text: "Agribank CN Thiên Trường Nam Định — sinh từ FIELD_META (bản React)",
          italics: true,
          size: 20,
        }),
      ],
    }),
  ];

  const printed = new Set<string>();

  /** In một bảng lặp (tiêu đề + bảng thật + ghi chú số dòng). */
  const pushTable = (key: string) => {
    const meta = findTable(key);
    const rows = tables[key] ?? [];
    if (!meta || rows.length === 0 || printed.has(key)) return;
    printed.add(key);
    children.push(
      new Paragraph({
        spacing: { before: 280, after: 100 },
        children: [new TextRun({ text: meta.docxTitle, bold: true })],
      }),
    );
    children.push(buildTable(meta, rows));
    children.push(
      new Paragraph({
        spacing: { before: 80 },
        children: [
          new TextRun({
            text: `(${rows.length} dòng — in đủ mọi dòng, không chỉ dòng đầu tiên)`,
            italics: true,
            size: 18,
          }),
        ],
      }),
    );
  };

  for (const block of rendered.blocks) {
    if (block.heading) {
      children.push(
        new Paragraph({
          spacing: { before: 240, after: 80 },
          children: [new TextRun({ text: block.heading, bold: true })],
        }),
      );
    }
    for (const line of block.lines) {
      // PHIÊN 9 — mẫu tự khai báo vị trí bảng: bảng in ĐÚNG CHỖ, không dồn xuống cuối.
      if (line.tableKey) {
        pushTable(line.tableKey);
        continue;
      }
      children.push(new Paragraph({ children: [new TextRun({ text: line.text })] }));
    }
  }

  // Bảng nào mẫu chưa khai báo vị trí thì vẫn in ở cuối như Phiên 8.
  for (const meta of TABLE_META) pushTable(meta.key);

  // PHIÊN 12B — khối ký/duyệt nội bộ in ở cuối MỌI mẫu, cùng một nguồn dữ liệu.
  children.push(...buildKyDuyetBlock(hoSo));

  return new Document({
    creator: "HSV React (Phiên 8)",
    title: template.name,
    sections: [{ children }],
  });
}

/**
 * PHIÊN 12B — chỗ ký chuẩn: người lập – người kiểm soát – người duyệt,
 * in thành một bảng 3 cột (đúng chỗ ký của văn bản giấy).
 */
export function buildKyDuyetBlock(hoSo: HoSo): Array<Paragraph | Table> {
  const os = oNhanKy(hoSo);
  const width = Math.round(100 / os.length);
  const oParagraphs = (text: string, opts: { bold?: boolean; italics?: boolean; size?: number }) =>
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text, ...opts })],
    });

  const row = new DocxTableRow({
    children: os.map(
      (o) =>
        new TableCell({
          width: { size: width, type: WidthType.PERCENTAGE },
          children: [
            oParagraphs(o.vaiTro, { bold: true }),
            oParagraphs(o.ghiChu, { italics: true, size: 18 }),
            new Paragraph({ text: "" }),
            new Paragraph({ text: "" }),
            oParagraphs(o.ten, { bold: true }),
            ...(o.chucVu ? [oParagraphs(o.chucVu, { size: 18 })] : []),
          ],
        }),
    ),
  });

  return [
    new Paragraph({
      spacing: { before: 400, after: 120 },
      alignment: AlignmentType.RIGHT,
      children: [new TextRun({ text: dongDiaDiemNgay(hoSo), italics: true })],
    }),
    new Table({ width: { size: 100, type: WidthType.PERCENTAGE }, rows: [row] }),
  ];
}


/** Trả về Blob DOCX; ném lỗi nếu hồ sơ còn thiếu trường bắt buộc. */
export async function exportDocxBlob(
  template: DocTemplate,
  hoSoGoc: HoSo,
  rows: Record<string, Array<string | number>> = {},
  tables: TableRows = {},
): Promise<Blob> {
  const hoSo = applyDerived(hoSoGoc, tables);
  const blocking = blockingIssues(hoSo, rows, tables);
  if (blocking.length > 0) {
    throw new Error(
      `Chặn xuất: còn ${blocking.length} lỗi phải sửa (${blocking
        .slice(0, 3)
        .map((i) => i.label)
        .join(", ")}…)`,
    );
  }
  return Packer.toBlob(buildDocxDocument(template, hoSo, tables));
}

/** Tải tệp về máy cán bộ (chỉ chạy ở trình duyệt). */
export function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
