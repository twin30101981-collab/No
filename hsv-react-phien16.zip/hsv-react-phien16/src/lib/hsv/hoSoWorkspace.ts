/**
 * PHIÊN 12 (PHẦN 1) — KHÔNG GIAN LÀM VIỆC NHIỀU HỒ SƠ.
 *
 * Hệ cũ chỉ soạn được MỘT hồ sơ tại một thời điểm: muốn làm hồ sơ khác thì
 * phải xoá trắng dữ liệu đang gõ. Ở đây một phiên làm việc giữ được NHIỀU hồ sơ
 * (mỗi hồ sơ = trường FIELD_META + bảng lặp + thửa/giấy tờ TSBĐ), chọn qua lại,
 * đổi tên, nhân bản, xoá — tất cả nằm trong bộ nhớ PHIÊN của trình duyệt.
 *
 * Vẫn CHỈ ĐỌC với hệ cũ: không ghi, không xoá dữ liệu hệ cũ.
 */
import type { HoSo } from "./fieldMeta";
import type { BuocLuanChuyen, TrangThaiHoSo } from "./luanChuyen";
import type { PhienBanHoSo } from "./lichSuPhienBan";
import { initialHoSo } from "./hoSoDraft";
import { initialTableRows } from "./repeatableData";
import { demoThua, type ThuaByTaiSan } from "./taiSanChiTiet";
import type { TableRows } from "./tableMeta";

export const WORKSPACE_STORAGE_KEY = "hsv.khongGianLamViec.v1";
export const MAX_HO_SO = 20;

export type NguonHoSo = "mau" | "moi" | "nhan-ban" | "he-cu";

export interface HoSoItem {
  id: string;
  ten: string;
  nguon: NguonHoSo;
  ghiChuNguon?: string;
  hoSo: HoSo;
  tables: TableRows;
  thua: ThuaByTaiSan;
  capNhat: number;
  /** PHIÊN 13 — mốc thời gian lần xuất tài liệu gần nhất (DOCX/ZIP). */
  daXuat?: number | undefined;
  /** PHIÊN 16 — chủ sở hữu, trạng thái luân chuyển và lịch sử chuyển. */
  chuSoHuu?: string | undefined;
  trangThai?: TrangThaiHoSo | undefined;
  luanChuyen?: BuocLuanChuyen[] | undefined;
  /** PHIÊN 16 — các mốc lưu nội dung để so sánh hai phiên bản. */
  phienBan?: PhienBanHoSo[] | undefined;
  /** PHIÊN 16 — khoá dùng chung theo phòng + số bản (tránh ghi đè lẫn nhau). */
  khoa?: string | undefined;
  ban?: number | undefined;
}

export interface Workspace {
  activeId: string;
  items: HoSoItem[];
}

export const NGUON_LABEL: Record<NguonHoSo, string> = {
  mau: "Hồ sơ mẫu",
  moi: "Tạo mới",
  "nhan-ban": "Nhân bản",
  "he-cu": "Nhập từ hệ cũ",
};

let seq = 0;
export function newId(prefix = "hs"): string {
  seq += 1;
  return `${prefix}-${Date.now().toString(36)}-${seq}`;
}

/** Tên gợi ý lấy từ chính dữ liệu hồ sơ (tên khách hàng / mã KH). */
export function goiYTen(hoSo: HoSo, fallback: string): string {
  const ten = String(hoSo["tenKhachHang"] ?? "").trim();
  const ma = String(hoSo["maKhachHang"] ?? "").trim();
  if (ten && ma) return `${ten} — ${ma}`;
  return ten || ma || fallback;
}

export function emptyHoSoItem(ten: string, nguon: NguonHoSo = "moi"): HoSoItem {
  return {
    id: newId(),
    ten,
    nguon,
    hoSo: {},
    tables: initialTableRows(),
    thua: demoThua(),
    capNhat: Date.now(),
  };
}

/** Id cố định cho hồ sơ mẫu: SSR và trình duyệt phải sinh cùng một cây HTML. */
export const HO_SO_MAU_ID = "hs-mau-mac-dinh";

export function hoSoMauItem(): HoSoItem {
  const hoSo = initialHoSo();
  return {
    id: HO_SO_MAU_ID,
    ten: goiYTen(hoSo, "Hồ sơ mẫu"),
    nguon: "mau",
    hoSo,
    tables: initialTableRows(),
    thua: demoThua(),
    capNhat: 0,
  };
}

export function initialWorkspace(): Workspace {
  const first = hoSoMauItem();
  return { activeId: first.id, items: [first] };
}

export function activeItem(ws: Workspace): HoSoItem {
  return ws.items.find((i) => i.id === ws.activeId) ?? ws.items[0]!;
}

/** Ghi trạng thái đang soạn vào đúng hồ sơ đang chọn. */
export function capNhatHoSoDangChon(
  ws: Workspace,
  patch: { hoSo?: HoSo; tables?: TableRows; thua?: ThuaByTaiSan },
): Workspace {
  return {
    ...ws,
    items: ws.items.map((i) =>
      i.id === ws.activeId ? { ...i, ...patch, capNhat: Date.now() } : i,
    ),
  };
}

export function chonHoSo(ws: Workspace, id: string): Workspace {
  return ws.items.some((i) => i.id === id) ? { ...ws, activeId: id } : ws;
}

export function themHoSo(ws: Workspace, item?: HoSoItem): Workspace {
  if (ws.items.length >= MAX_HO_SO) return ws;
  const it = item ?? emptyHoSoItem(`Hồ sơ mới ${ws.items.length + 1}`);
  return { activeId: it.id, items: [...ws.items, it] };
}

export function themNhieuHoSo(ws: Workspace, items: HoSoItem[]): Workspace {
  const nhan = items.slice(0, Math.max(0, MAX_HO_SO - ws.items.length));
  if (nhan.length === 0) return ws;
  return { activeId: nhan[0]!.id, items: [...ws.items, ...nhan] };
}

export function nhanBanHoSo(ws: Workspace, id = ws.activeId): Workspace {
  const src = ws.items.find((i) => i.id === id);
  if (!src || ws.items.length >= MAX_HO_SO) return ws;
  const ban: HoSoItem = {
    ...src,
    id: newId(),
    ten: `${src.ten} (bản sao)`,
    nguon: "nhan-ban",
    ghiChuNguon: `Nhân bản từ “${src.ten}”`,
    hoSo: { ...src.hoSo },
    tables: Object.fromEntries(
      Object.entries(src.tables).map(([k, rows]) => [k, rows.map((r) => ({ ...r }))]),
    ),
    thua: Object.fromEntries(
      Object.entries(src.thua).map(([k, rows]) => [k, rows.map((r) => ({ ...r }))]),
    ),
    capNhat: Date.now(),
  };
  const at = ws.items.findIndex((i) => i.id === id);
  const items = [...ws.items];
  items.splice(at + 1, 0, ban);
  return { activeId: ban.id, items };
}

export function doiTenHoSo(ws: Workspace, id: string, ten: string): Workspace {
  const sach = ten.trim();
  if (!sach) return ws;
  return {
    ...ws,
    items: ws.items.map((i) => (i.id === id ? { ...i, ten: sach, capNhat: Date.now() } : i)),
  };
}

/** Không cho xoá hồ sơ cuối cùng — phiên làm việc luôn còn ít nhất một hồ sơ. */
export function xoaHoSo(ws: Workspace, id: string): Workspace {
  if (ws.items.length <= 1) return ws;
  const at = ws.items.findIndex((i) => i.id === id);
  if (at < 0) return ws;
  const items = ws.items.filter((i) => i.id !== id);
  const activeId = ws.activeId === id ? (items[Math.max(0, at - 1)]?.id ?? items[0]!.id) : ws.activeId;
  return { activeId, items };
}

export function readWorkspace(): Workspace | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.sessionStorage.getItem(WORKSPACE_STORAGE_KEY);
    if (!raw) return null;
    const ws = JSON.parse(raw) as Workspace;
    if (!ws?.items?.length) return null;
    return ws;
  } catch {
    return null;
  }
}

export function writeWorkspace(ws: Workspace): void {
  try {
    window.sessionStorage.setItem(WORKSPACE_STORAGE_KEY, JSON.stringify(ws));
  } catch {
    /* bộ nhớ phiên bị chặn — không ảnh hưởng nhập liệu */
  }
}

/** PHIÊN 13 — đánh dấu hồ sơ vừa xuất tài liệu, phục vụ bảng theo dõi tiến độ. */
export function danhDauDaXuat(ws: Workspace, ids: string[], luc = Date.now()): Workspace {
  if (ids.length === 0) return ws;
  return {
    ...ws,
    items: ws.items.map((i) => (ids.includes(i.id) ? { ...i, daXuat: luc } : i)),
  };
}

export type SapXepHoSo = "thu-tu" | "moi-sua" | "ten";

/**
 * PHIÊN 13 — tìm nhanh theo tên hồ sơ / tên khách hàng / mã KH / số hồ sơ,
 * và sắp xếp theo lần sửa gần nhất (mặc định) hoặc theo tên.
 */
export function locHoSo(
  items: HoSoItem[],
  tuKhoa: string,
  sapXep: SapXepHoSo = "thu-tu",
): HoSoItem[] {
  const q = tuKhoa.trim().toLowerCase();
  const khop = (i: HoSoItem) => {
    if (!q) return true;
    const kho = [
      i.ten,
      String(i.hoSo["tenKhachHang"] ?? ""),
      String(i.hoSo["maKhachHang"] ?? ""),
      String(i.hoSo["soHoSo"] ?? ""),
      String(i.hoSo["soHopDongTinDung"] ?? ""),
    ]
      .join(" ")
      .toLowerCase();
    return kho.includes(q);
  };
  const ds = items.filter(khop);
  if (sapXep === "thu-tu") return ds; // giữ nguyên thứ tự trong phiên làm việc
  return [...ds].sort((a, b) =>
    sapXep === "ten" ? a.ten.localeCompare(b.ten, "vi") : b.capNhat - a.capNhat,
  );
}
