/**
 * PHIÊN 10 (PHẦN 1) — TRƯỜNG SUY RA TỪ BẢNG LẶP.
 *
 * Vá tiếp nhóm finding "nhập trùng, lệch số" của đề án: hệ cũ buộc cán bộ gõ lại
 * tổng giá trị tài sản (và phần "bằng chữ") sau khi đã nhập từng tài sản ⇒ chỉ cần
 * sửa một dòng bảng là số tổng trong văn bản lệch ngay.
 *
 * Ở bản React, tổng và phần "bằng chữ" được SUY RA từ đúng bảng lặp theo một khai
 * báo duy nhất bên dưới; cán bộ không gõ lại, mẫu DOCX và trang xem trước dùng
 * chung một nguồn số. Thêm bảng mới chỉ cần thêm một dòng khai báo.
 *
 * Vẫn CHỈ ĐỌC với hệ cũ: không ghi/xoá dữ liệu hệ cũ.
 */
import type { HoSo } from "./fieldMeta";
import { findTable, tableTotal, type TableRows } from "./tableMeta";

export interface DerivedRule {
  /** Bảng lặp là nguồn sự thật của số tổng. */
  tableKey: string;
  /** Trường FIELD_META nhận số tổng (kind = money). */
  totalField: string;
  /** Trường FIELD_META nhận phần "bằng chữ" của số tổng (kind = text). */
  wordsField?: string;
}

/** Một điểm khai báo duy nhất cho mọi trường suy ra từ bảng lặp. */
export const DERIVED_RULES: readonly DerivedRule[] = [
  { tableKey: "danhSachTaiSan", totalField: "tongGiaTriTs", wordsField: "tgttsBangChu" },
  { tableKey: "chiPhiVatTu", totalField: "tongNhuCauVon", wordsField: "tongNhuCauVonBangChu" },
];

const DON_VI = ["", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín"];

/** Đọc 3 chữ số theo cách đọc tiếng Việt. */
function docBaSo(n: number, đayDu: boolean): string {
  const tram = Math.floor(n / 100);
  const chuc = Math.floor((n % 100) / 10);
  const donVi = n % 10;
  const out: string[] = [];
  if (tram > 0 || đayDu) out.push(`${tram === 0 ? "không" : DON_VI[tram]!} trăm`);
  if (chuc > 1) {
    out.push(`${DON_VI[chuc]!} mươi`);
    if (donVi === 1) out.push("mốt");
    else if (donVi === 5) out.push("lăm");
    else if (donVi > 0) out.push(DON_VI[donVi]!);
  } else if (chuc === 1) {
    out.push("mười");
    if (donVi === 5) out.push("lăm");
    else if (donVi > 0) out.push(DON_VI[donVi]!);
  } else {
    if (donVi > 0) {
      if (tram > 0 || đayDu) out.push("lẻ");
      out.push(DON_VI[donVi]!);
    }
  }
  return out.join(" ").trim();
}

const HANG = ["", " nghìn", " triệu", " tỷ"];

/** Số tiền ⇒ chữ tiếng Việt (viết hoa chữ đầu, kết thúc bằng "đồng"). */
export function soThanhChu(value: number): string {
  const n = Math.round(Math.abs(value));
  if (!Number.isFinite(n)) return "";
  if (n === 0) return "Không đồng";
  const nhom: number[] = [];
  let con = n;
  while (con > 0) {
    nhom.push(con % 1000);
    con = Math.floor(con / 1000);
  }
  const phan: string[] = [];
  for (let i = nhom.length - 1; i >= 0; i--) {
    const giaTri = nhom[i]!;
    if (giaTri === 0) continue;
    const donVi = HANG[i % 4] ?? "";
    const tyBoi = Math.floor(i / 4);
    phan.push(`${docBaSo(giaTri, i < nhom.length - 1)}${donVi}${" tỷ".repeat(tyBoi)}`);
  }
  const chu = phan.join(" ").replace(/\s+/g, " ").trim();
  const dau = value < 0 ? "Âm " : "";
  return `${dau}${chu.charAt(0).toUpperCase()}${chu.slice(1)} đồng`;
}

export interface DerivedValue extends DerivedRule {
  tableLabel: string;
  total: number;
  words: string;
  rowCount: number;
}

/** Tính mọi trường suy ra hiện có (dùng cho giao diện giải thích cho cán bộ). */
export function derivedValues(tables: TableRows = {}): DerivedValue[] {
  const out: DerivedValue[] = [];
  for (const rule of DERIVED_RULES) {
    const meta = findTable(rule.tableKey);
    const rows = tables[rule.tableKey];
    if (!meta || !rows || rows.length === 0) continue;
    const total = tableTotal(meta, rows);
    out.push({
      ...rule,
      tableLabel: meta.label,
      total,
      words: soThanhChu(total),
      rowCount: rows.length,
    });
  }
  return out;
}

/**
 * Trả về hồ sơ với các trường tổng / bằng chữ ĐƯỢC GHI ĐÈ từ bảng lặp.
 * Hàm thuần: không sửa đối tượng đầu vào, không ghi dữ liệu hệ cũ.
 */
export function applyDerived(hoSo: HoSo, tables: TableRows = {}): HoSo {
  const out: HoSo = { ...hoSo };
  for (const d of derivedValues(tables)) {
    out[d.totalField] = d.total;
    if (d.wordsField) out[d.wordsField] = d.words;
  }
  return out;
}
