/**
 * PHIÊN 14 (PHẦN 2) — NHẬP HÀNG LOẠT DANH SÁCH KHÁCH HÀNG TỪ CSV/EXCEL.
 *
 * Đợt cho vay theo tổ/nhóm có hàng chục khách hàng chung một phương án: hệ cũ
 * bắt gõ lại từng hồ sơ từ đầu. Ở đây cán bộ dán (hoặc chọn) một bảng CSV/TSV
 * xuất từ Excel — mỗi DÒNG thành MỘT hồ sơ trong phiên làm việc.
 *
 * Nguyên tắc giữ nguyên: dữ liệu nhập vào KHÔNG có đường tắt bỏ qua kiểm tra.
 * Mỗi hồ sơ sinh ra vẫn đi qua đúng FIELD_META + cửa chặn xuất như nhập tay;
 * cột không khớp FIELD_META bị báo rõ thay vì âm thầm bỏ.
 *
 * Hệ cũ vẫn CHỈ ĐỌC.
 */
import { FIELD_META, type HoSo } from "./fieldMeta";
import { goiYTen, newId, type HoSoItem } from "./hoSoWorkspace";
import { initialTableRows } from "./repeatableData";
import { demoThua } from "./taiSanChiTiet";

/** Chuẩn hoá tiêu đề cột: bỏ dấu, bỏ ký tự lạ để so khớp nhãn tiếng Việt. */
function chuanHoa(s: string): string {
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/gi, "d")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}

const BANG_KHOA: Map<string, string> = new Map(
  FIELD_META.flatMap((f) => [
    [chuanHoa(f.key), f.key] as [string, string],
    [chuanHoa(f.label), f.key] as [string, string],
    ...(f.legacyKeys ?? []).map((l) => [chuanHoa(l), f.key] as [string, string]),
  ]),
);

export function khoaTuTieuDe(tieuDe: string): string | null {
  return BANG_KHOA.get(chuanHoa(tieuDe)) ?? null;
}

/** Tự nhận dấu phân cách của tệp xuất từ Excel: `,` `;` hoặc Tab. */
export function doanDauPhanCach(text: string): string {
  const dong = text.split(/\r?\n/).find((d) => d.trim() !== "") ?? "";
  const dem = (c: string) => dong.split(c).length - 1;
  const ungVien: Array<[string, number]> = [
    [",", dem(",")],
    [";", dem(";")],
    ["\t", dem("\t")],
  ];
  ungVien.sort((a, b) => b[1] - a[1]);
  return ungVien[0]![1] > 0 ? ungVien[0]![0] : ",";
}

/** Tách CSV có hỗ trợ ô bọc dấu nháy kép và xuống dòng trong ô. */
export function tachCsv(text: string, sep = doanDauPhanCach(text)): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let inQuote = false;
  const s = text.replace(/^\uFEFF/, "");
  for (let i = 0; i < s.length; i += 1) {
    const c = s[i]!;
    if (inQuote) {
      if (c === '"') {
        if (s[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else inQuote = false;
      } else cell += c;
      continue;
    }
    if (c === '"') {
      inQuote = true;
    } else if (c === sep) {
      row.push(cell);
      cell = "";
    } else if (c === "\n") {
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else if (c !== "\r") {
      cell += c;
    }
  }
  row.push(cell);
  rows.push(row);
  return rows.filter((r) => r.some((v) => v.trim() !== ""));
}

export interface CotNhap {
  tieuDe: string;
  key: string | null;
}

export interface KetQuaNhapHangLoat {
  items: HoSoItem[];
  cot: CotNhap[];
  /** Cột không khớp FIELD_META — báo rõ, không âm thầm bỏ. */
  cotBoQua: string[];
  loi: string[];
  soDong: number;
}

export interface TuyChonNhap {
  /** Hồ sơ nền (mẫu/hồ sơ đang soạn) để kế thừa trường dùng chung. */
  nen?: HoSo;
  /** Tiền tố tên hồ sơ khi dòng không có tên khách hàng. */
  tienTo?: string;
}

/**
 * Đọc bảng CSV/TSV thành danh sách hồ sơ. Mỗi dòng = một hồ sơ, kế thừa hồ sơ
 * nền rồi ghi đè bằng đúng các cột khớp FIELD_META.
 */
export function nhapHangLoat(text: string, tuyChon: TuyChonNhap = {}): KetQuaNhapHangLoat {
  const nen = tuyChon.nen ?? {};
  const tienTo = tuyChon.tienTo ?? "Hồ sơ nhập hàng loạt";
  const rong: KetQuaNhapHangLoat = { items: [], cot: [], cotBoQua: [], loi: [], soDong: 0 };

  if (!text.trim()) return { ...rong, loi: ["Chưa có nội dung bảng để nhập."] };

  const rows = tachCsv(text);
  if (rows.length < 2) {
    return { ...rong, loi: ["Bảng phải có dòng tiêu đề và ít nhất một dòng dữ liệu."] };
  }

  const tieuDe = rows[0]!.map((h) => h.trim());
  const cot: CotNhap[] = tieuDe.map((h) => ({ tieuDe: h, key: khoaTuTieuDe(h) }));
  const cotBoQua = cot.filter((c) => c.key === null && c.tieuDe !== "").map((c) => c.tieuDe);
  if (cot.every((c) => c.key === null)) {
    return {
      ...rong,
      cot,
      cotBoQua,
      loi: [
        "Không có cột nào khớp FIELD_META. Tiêu đề phải là tên trường (ví dụ: Tên khách hàng, Số tiền vay) hoặc mã trường (tenKhachHang, soTienVay).",
      ],
    };
  }

  const loi: string[] = [];
  const items: HoSoItem[] = [];
  rows.slice(1).forEach((r, idx) => {
    const stt = idx + 1;
    const hoSo: HoSo = { ...nen };
    let soODien = 0;
    cot.forEach((c, ci) => {
      if (!c.key) return;
      const v = (r[ci] ?? "").trim();
      if (v === "") return;
      hoSo[c.key] = v;
      soODien += 1;
    });
    if (soODien === 0) {
      loi.push(`Dòng ${stt}: mọi ô đều trống, đã bỏ qua.`);
      return;
    }
    if (!String(hoSo["tenKhachHang"] ?? "").trim()) {
      loi.push(`Dòng ${stt}: thiếu "Tên khách hàng" — hồ sơ vẫn tạo nhưng sẽ bị chặn xuất.`);
    }
    items.push({
      id: newId("csv"),
      ten: goiYTen(hoSo, `${tienTo} ${stt}`),
      nguon: "moi",
      ghiChuNguon: `Nhập hàng loạt từ bảng CSV — dòng ${stt}`,
      hoSo,
      tables: initialTableRows(),
      thua: demoThua(),
      capNhat: Date.now(),
    });
  });

  if (items.length === 0 && loi.length === 0) loi.push("Không tạo được hồ sơ nào từ bảng.");
  return { items, cot, cotBoQua, loi, soDong: rows.length - 1 };
}

export function tomTatNhapHangLoat(kq: KetQuaNhapHangLoat): string {
  if (kq.items.length === 0) return kq.loi[0] ?? "Không nhập được hồ sơ nào.";
  const khop = kq.cot.filter((c) => c.key).length;
  return `Đã tạo ${kq.items.length}/${kq.soDong} hồ sơ từ bảng — khớp ${khop} cột FIELD_META${
    kq.cotBoQua.length ? `, bỏ qua ${kq.cotBoQua.length} cột lạ` : ""
  }.`;
}

/** Bảng mẫu để cán bộ tải về, điền bằng Excel rồi dán/nạp lại. */
export const CSV_MAU = [
  "Tên khách hàng,Mã khách hàng,CMND,Địa chỉ,Số tiền vay",
  "Nguyễn Văn An,KH001,036088001234,Xã Nam Hồng huyện Nam Trực Nam Định,300000000",
  "Trần Thị Bình,KH002,036188005678,Phường Lộc Vượng TP Nam Định,450000000",
  "Phạm Văn Cường,KH003,036088009012,Xã Điền Xá huyện Nam Trực Nam Định,250000000",
].join("\n");
