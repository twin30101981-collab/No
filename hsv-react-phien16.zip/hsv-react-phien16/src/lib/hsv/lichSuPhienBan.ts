/**
 * PHIÊN 16 (PHẦN 2) — LỊCH SỬ PHIÊN BẢN & SO SÁNH HAI PHIÊN BẢN HỒ SƠ.
 *
 * Nhật ký phiên 14 chỉ hoàn tác được thao tác danh mục. Ở đây mỗi hồ sơ giữ
 * được các "mốc lưu" của chính nội dung: ai lưu, lúc nào; chọn hai mốc là
 * thấy ngay trường nào đổi, từ giá trị nào sang giá trị nào.
 *
 * Nhãn trường lấy từ FIELD_META — không hard-code chữ.
 */
import { FIELD_META, formatValue, type HoSo } from "./fieldMeta";

export const MAX_PHIEN_BAN = 12;

export interface PhienBanHoSo {
  id: string;
  nhan: string;
  nguoi: string;
  luc: number;
  hoSo: HoSo;
}

let seqPb = 0;

export function luuPhienBan(
  ds: PhienBanHoSo[],
  hoSo: HoSo,
  nguoi: string,
  nhan: string,
  luc = Date.now(),
): PhienBanHoSo[] {
  seqPb += 1;
  const pb: PhienBanHoSo = {
    id: `pb-${luc.toString(36)}-${seqPb}`,
    nhan: nhan.trim() || `Mốc lưu ${ds.length + 1}`,
    nguoi: nguoi.trim() || "không rõ",
    luc,
    hoSo: { ...hoSo },
  };
  return [pb, ...ds].slice(0, MAX_PHIEN_BAN);
}

export type LoaiKhacBiet = "them" | "sua" | "xoa";

export interface KhacBiet {
  key: string;
  label: string;
  truoc: string;
  sau: string;
  loai: LoaiKhacBiet;
}

const META = new Map(FIELD_META.map((f) => [f.key, f]));

function hienThi(key: string, v: string | number | undefined): string {
  const meta = META.get(key);
  const raw = v === undefined || v === null ? "" : String(v).trim();
  if (!raw) return "";
  return meta ? formatValue(v, meta.kind) : raw;
}

/** So sánh theo đúng trường FIELD_META; trường lạ vẫn liệt kê bằng chính khoá. */
export function soSanhPhienBan(truoc: HoSo, sau: HoSo): KhacBiet[] {
  const keys = new Set([...Object.keys(truoc), ...Object.keys(sau)]);
  const out: KhacBiet[] = [];
  for (const key of keys) {
    const a = hienThi(key, truoc[key]);
    const b = hienThi(key, sau[key]);
    if (a === b) continue;
    out.push({
      key,
      label: META.get(key)?.label ?? key,
      truoc: a,
      sau: b,
      loai: !a ? "them" : !b ? "xoa" : "sua",
    });
  }
  return out.sort((x, y) => x.label.localeCompare(y.label, "vi"));
}

export function tomTatSoSanh(ds: KhacBiet[]): string {
  if (ds.length === 0) return "Hai phiên bản giống hệt nhau — không trường nào đổi.";
  const sua = ds.filter((d) => d.loai === "sua").length;
  const them = ds.filter((d) => d.loai === "them").length;
  const xoa = ds.filter((d) => d.loai === "xoa").length;
  return `${ds.length} trường khác nhau: ${sua} sửa, ${them} thêm, ${xoa} bỏ trống.`;
}

export function nhanPhienBan(pb: PhienBanHoSo): string {
  const d = new Date(pb.luc);
  const hai = (n: number) => String(n).padStart(2, "0");
  return `${pb.nhan} · ${pb.nguoi} · ${hai(d.getHours())}:${hai(d.getMinutes())}:${hai(d.getSeconds())}`;
}
