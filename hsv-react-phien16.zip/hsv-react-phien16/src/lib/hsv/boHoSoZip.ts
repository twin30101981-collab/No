/**
 * PHIÊN 12B — XUẤT TRỌN BỘ HỒ SƠ RA MỘT TỆP ZIP.
 *
 * Hệ cũ bắt cán bộ bấm xuất từng mẫu một, tự đặt tên tệp, tự nhớ đã in đủ chưa —
 * hồ sơ giao đi hay thiếu mẫu, sai tên tệp. Ở đây một lần bấm ra đủ 4 mẫu DOCX
 * của một (hoặc nhiều) hồ sơ, kèm TRANG BÌA MỤC LỤC liệt kê đúng những tệp có
 * trong bộ. Vẫn CHỈ ĐỌC với hệ cũ, và vẫn dùng chung cửa chặn xuất.
 */
import { Document, Packer, Paragraph, TextRun, HeadingLevel } from "docx";
import JSZip from "jszip";
import { TEMPLATES } from "./docTemplate";
import { buildDocxDocument, docxFileName } from "./docxExport";
import { blockingIssues } from "./exportGuard";
import { applyDerived } from "./derived";
import { formatValue, type HoSo } from "./fieldMeta";
import { tomTatKy } from "./kyDuyet";
import { demoRows } from "./repeatableData";
import type { TableRows } from "./tableMeta";

export interface HoSoXuat {
  ten: string;
  hoSo: HoSo;
  tables: TableRows;
}

export interface KetQuaZip {
  blob: Blob;
  fileName: string;
  /** Đường dẫn mọi tệp trong ZIP, theo đúng thứ tự trang bìa liệt kê. */
  entries: string[];
}

export const TEN_TRANG_BIA = "00_TRANG-BIA-MUC-LUC.docx";

const slug = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/gi, "d")
    .replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 48) || "ho-so";

const hai = (n: number) => String(n).padStart(2, "0");

export function tenTepZip(items: HoSoXuat[], now = new Date()): string {
  const ngay = `${now.getFullYear()}${hai(now.getMonth() + 1)}${hai(now.getDate())}`;
  const phan =
    items.length === 1 ? slug(String(items[0]!.hoSo["tenKhachHang"] ?? items[0]!.ten)) : `${items.length}-ho-so`;
  return `BO-HO-SO_${phan}_${ngay}.zip`;
}

/** Thư mục của một hồ sơ trong ZIP (nhiều hồ sơ ⇒ mỗi hồ sơ một thư mục). */
export function thuMucHoSo(items: HoSoXuat[], i: number): string {
  if (items.length === 1) return "";
  return `${hai(i + 1)}_${slug(items[i]!.ten)}/`;
}

/** Trang bìa + mục lục của bộ hồ sơ (một tệp DOCX riêng, đứng đầu ZIP). */
export function buildTrangBia(items: HoSoXuat[], entries: string[], now = new Date()): Document {
  const children: Paragraph[] = [
    new Paragraph({
      heading: HeadingLevel.HEADING_1,
      children: [new TextRun({ text: "BỘ HỒ SƠ TÍN DỤNG — TRANG BÌA & MỤC LỤC", bold: true })],
    }),
    new Paragraph({
      children: [
        new TextRun({
          text: "Agribank CN Thiên Trường Nam Định — Phòng KHKD · sinh từ FIELD_META (bản React)",
          italics: true,
          size: 20,
        }),
      ],
    }),
    new Paragraph({
      spacing: { before: 160 },
      children: [
        new TextRun({
          text: `Ngày xuất bộ hồ sơ: ${hai(now.getDate())}/${hai(now.getMonth() + 1)}/${now.getFullYear()} · Số hồ sơ trong bộ: ${items.length} · Tổng số tệp: ${entries.length + 1}`,
        }),
      ],
    }),
  ];

  items.forEach((it, i) => {
    const hoSo = applyDerived(it.hoSo, it.tables);
    children.push(
      new Paragraph({
        spacing: { before: 280, after: 80 },
        children: [new TextRun({ text: `${hai(i + 1)}. ${it.ten}`, bold: true })],
      }),
      new Paragraph({
        children: [
          new TextRun({
            text: `Khách hàng: ${hoSo["tenKhachHang"] ?? "—"} · Mã KH: ${hoSo["maKhachHang"] ?? "—"} · Số hồ sơ: ${hoSo["soHoSo"] ?? "—"}`,
          }),
        ],
      }),
      new Paragraph({
        children: [
          new TextRun({
            text: `Số tiền vay: ${formatValue(hoSo["soTienVay"], "money")} · HĐTD số ${hoSo["soHopDongTinDung"] ?? "—"} ngày ${hoSo["ngayHopDongTinDung"] ?? "—"}`,
          }),
        ],
      }),
      new Paragraph({ children: [new TextRun({ text: `Ký/duyệt nội bộ — ${tomTatKy(hoSo)}` })] }),
    );
    TEMPLATES.forEach((t, k) => {
      children.push(
        new Paragraph({
          children: [
            new TextRun({
              text: `   ${hai(i + 1)}.${k + 1} ${t.name} — tệp: ${thuMucHoSo(items, i)}${docxFileName(t, hoSo)}`,
            }),
          ],
        }),
      );
    });
  });

  children.push(
    new Paragraph({
      spacing: { before: 320 },
      children: [
        new TextRun({
          text: "Bộ hồ sơ được sinh ngay trên máy cán bộ; dữ liệu hệ cũ được giữ nguyên (chỉ đọc, không ghi/xoá).",
          italics: true,
          size: 18,
        }),
      ],
    }),
  );

  return new Document({
    creator: "HSV React (Phiên 12B)",
    title: "Trang bìa & mục lục bộ hồ sơ",
    sections: [{ children }],
  });
}

/** Dựng ZIP: trang bìa mục lục + 4 mẫu DOCX cho từng hồ sơ được chọn. */
export async function taoBoHoSoZip(
  items: HoSoXuat[],
  rows: Record<string, Array<string | number>> = demoRows,
  now = new Date(),
): Promise<KetQuaZip> {
  if (items.length === 0) throw new Error("Chưa chọn hồ sơ nào để xuất trọn bộ.");

  // Cùng một cửa chặn xuất với nút xuất từng mẫu — không xuất hồ sơ còn lỗi.
  const loi = items
    .map((it) => ({ ten: it.ten, issues: blockingIssues(applyDerived(it.hoSo, it.tables), rows, it.tables) }))
    .filter((x) => x.issues.length > 0);
  if (loi.length > 0) {
    throw new Error(
      `Chặn xuất trọn bộ: ${loi.length} hồ sơ còn lỗi — ${loi
        .map((x) => `${x.ten} (${x.issues.length} lỗi)`)
        .join("; ")}.`,
    );
  }

  const zip = new JSZip();
  const entries: string[] = [];

  for (let i = 0; i < items.length; i += 1) {
    const it = items[i]!;
    const hoSo = applyDerived(it.hoSo, it.tables);
    const thuMuc = thuMucHoSo(items, i);
    for (const t of TEMPLATES) {
      const duongDan = `${thuMuc}${docxFileName(t, hoSo)}`;
      const blob = await Packer.toBlob(buildDocxDocument(t, hoSo, it.tables));
      zip.file(duongDan, await blob.arrayBuffer());
      entries.push(duongDan);
    }
  }

  const bia = await Packer.toBlob(buildTrangBia(items, entries, now));
  zip.file(TEN_TRANG_BIA, await bia.arrayBuffer());

  const blob = await zip.generateAsync({ type: "blob", compression: "DEFLATE" });
  return { blob, fileName: tenTepZip(items, now), entries: [TEN_TRANG_BIA, ...entries] };
}
