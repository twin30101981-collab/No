/**
 * PHIÊN 8 — cửa chặn xuất văn bản, tách riêng khỏi thư viện DOCX để trang xem
 * trước không phải nạp bộ sinh tệp khi chỉ cần kiểm tra điều kiện xuất.
 *
 * PHIÊN 9 — mọi lỗi ô của bảng lặp (cột bắt buộc trống, cột tiền không phải số)
 * cũng tính vào cửa chặn xuất, không chỉ trường phẳng.
 *
 * PHIÊN 11 — thêm lỗi thửa/giấy tờ của từng tài sản và lỗi KIỂM TRA CHÉO nghiệp vụ
 * (tổng nhu cầu vốn ≥ số tiền vay, giá trị TSBĐ ≥ tỷ lệ bảo đảm tối thiểu).
 */
import type { HoSo } from "./fieldMeta";
import type { TableRows } from "./tableMeta";
import { crossIssues } from "./crossChecks";
import { validateThua, type ThuaByTaiSan } from "./taiSanChiTiet";
import { validateHoSo, validateTables, type Issue } from "./validation";

/** Trường bắt buộc đang trống + lỗi ô bảng lặp + lỗi thửa + lỗi chéo ⇒ chặn xuất. */
export function blockingIssues(
  hoSo: HoSo,
  rows: Record<string, Array<string | number>> = {},
  tables: TableRows = {},
  thua: ThuaByTaiSan | null = null,
): Issue[] {
  const thuaIssues: Issue[] = thua
    ? validateThua(tables, thua).map((t) => ({
        key: t.key,
        label: t.label,
        group: "tsbd" as const,
        kind: "repeatable" as const,
        message: t.message,
      }))
    : [];
  return [
    ...validateHoSo(hoSo, rows).filter((i) => i.message.includes("bắt buộc")),
    ...validateTables(tables),
    ...thuaIssues,
    ...crossIssues(hoSo),
  ];
}

export function canExport(
  hoSo: HoSo,
  rows: Record<string, Array<string | number>> = {},
  tables: TableRows = {},
  thua: ThuaByTaiSan | null = null,
) {
  return blockingIssues(hoSo, rows, tables, thua).length === 0;
}
