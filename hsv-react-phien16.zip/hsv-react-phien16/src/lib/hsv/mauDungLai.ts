/**
 * PHIÊN 14 (PHẦN 1) — MẪU DỮ LIỆU DÙNG LẠI.
 *
 * Mỗi hồ sơ đều lặp lại một bộ trường giống hệt nhau: người lập, người kiểm
 * soát, người phê duyệt, chức vụ, nơi ký, lãi suất mặc định của chi nhánh…
 * Hệ cũ bắt gõ lại toàn bộ cho từng hồ sơ. Ở đây cán bộ lưu bộ trường đó thành
 * một "mẫu dùng lại" và áp cho hồ sơ mới chỉ bằng một cú bấm — phần riêng của
 * khách hàng vẫn phải nhập tay và vẫn qua đúng bộ kiểm tra cũ.
 *
 * Hệ cũ vẫn CHỈ ĐỌC: mẫu nằm trong bộ nhớ phiên của trình duyệt.
 */
import { FIELD_META, type HoSo } from "./fieldMeta";
import { newId } from "./hoSoWorkspace";

export const MAU_STORAGE_KEY = "hsv.mauDungLai.v1";
export const MAX_MAU = 10;

/**
 * Bộ trường "dùng chung cho mọi hồ sơ của một cán bộ / một chi nhánh".
 * Cố tình KHÔNG gồm trường riêng của khách hàng (tên, CCCD, số tiền vay…)
 * để không bao giờ chép nhầm dữ liệu khách này sang khách khác.
 */
export const TRUONG_DUNG_CHUNG: readonly string[] = [
  "nguoiLap",
  "chucVuNguoiLap",
  "nguoiKiemSoat",
  "chucVuNguoiKiemSoat",
  "nguoiPheDuyet",
  "chucVuNguoiPheDuyet",
  "noiKyDuyet",
  "laiSuat",
  "laiSuatDieuChinh",
];

const out = (v: unknown) => (v === undefined || v === null ? "" : String(v).trim());

export function nhanTruong(key: string): string {
  return FIELD_META.find((f) => f.key === key)?.label ?? key;
}

/** Các trường dùng chung thực sự có khai báo trong FIELD_META. */
export function truongDungChung(): { key: string; label: string }[] {
  return TRUONG_DUNG_CHUNG.filter((k) => FIELD_META.some((f) => f.key === k)).map((k) => ({
    key: k,
    label: nhanTruong(k),
  }));
}

export interface MauDungLai {
  id: string;
  ten: string;
  taoLuc: number;
  /** Chỉ chứa trường dùng chung có giá trị. */
  giaTri: HoSo;
}

/** Rút bộ trường dùng chung từ hồ sơ đang soạn — bỏ ô trống. */
export function taoMauTuHoSo(ten: string, hoSo: HoSo): MauDungLai {
  const giaTri: HoSo = {};
  for (const { key } of truongDungChung()) {
    const v = hoSo[key];
    if (v !== undefined && String(v).trim() !== "") giaTri[key] = v;
  }
  return { id: newId("mau"), ten: ten.trim() || "Mẫu không tên", taoLuc: Date.now(), giaTri };
}

/**
 * Áp mẫu vào hồ sơ. Mặc định CHỈ điền vào ô đang trống để không ghi đè dữ liệu
 * cán bộ vừa gõ; bật `ghiDe` khi muốn chuẩn hoá lại toàn bộ theo mẫu.
 */
export function apDungMau(hoSo: HoSo, mau: MauDungLai, ghiDe = false): HoSo {
  const out: HoSo = { ...hoSo };
  for (const [k, v] of Object.entries(mau.giaTri)) {
    const dangCo = out[k];
    const trong = dangCo === undefined || String(dangCo).trim() === "";
    if (ghiDe || trong) out[k] = v;
  }
  return out;
}

/** Số ô mẫu sẽ thực sự thay đổi khi áp — dùng để báo lại cho cán bộ. */
export function soOSeDoi(hoSo: HoSo, mau: MauDungLai, ghiDe = false): number {
  let n = 0;
  for (const [k, v] of Object.entries(mau.giaTri)) {
    const dangCo = out(hoSo[k]);
    if (ghiDe ? dangCo !== String(v) : dangCo === "") n += 1;
  }
  return n;
}

export function tomTatMau(mau: MauDungLai): string {
  const so = Object.keys(mau.giaTri).length;
  return so === 0 ? "chưa có trường nào" : `${so} trường dùng chung`;
}

export function themMau(ds: MauDungLai[], mau: MauDungLai): MauDungLai[] {
  const khac = ds.filter((m) => m.ten !== mau.ten);
  return [mau, ...khac].slice(0, MAX_MAU);
}

export function xoaMau(ds: MauDungLai[], id: string): MauDungLai[] {
  return ds.filter((m) => m.id !== id);
}

export function readMau(): MauDungLai[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.sessionStorage.getItem(MAU_STORAGE_KEY);
    const ds = raw ? (JSON.parse(raw) as MauDungLai[]) : [];
    return Array.isArray(ds) ? ds.filter((m) => m && typeof m.id === "string") : [];
  } catch {
    return [];
  }
}

export function writeMau(ds: MauDungLai[]): void {
  try {
    window.sessionStorage.setItem(MAU_STORAGE_KEY, JSON.stringify(ds));
  } catch {
    /* bộ nhớ phiên bị chặn — không ảnh hưởng nhập liệu */
  }
}
