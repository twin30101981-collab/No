/**
 * PHIÊN 16 (PHẦN 1) — CHỦ SỞ HỮU HỒ SƠ & TRẠNG THÁI LUÂN CHUYỂN.
 *
 * Hệ cũ không biết hồ sơ đang nằm ở ai: cán bộ soạn xong hô một tiếng, kiểm
 * soát viên xem trên máy khác, trả lại thì nhắn miệng nên hay mất dấu. Ở đây
 * mỗi hồ sơ có MỘT chủ sở hữu và MỘT trạng thái, mọi lần chuyển đều ghi lại
 * ai chuyển, lúc nào, kèm lý do khi trả lại.
 *
 * Thuần dữ liệu, không phụ thuộc React; hệ cũ vẫn CHỈ ĐỌC.
 */

export type TrangThaiHoSo = "soan" | "trinh" | "duyet" | "tra-lai";

export interface MetaTrangThai {
  nhan: string;
  moTa: string;
  keTiep: readonly TrangThaiHoSo[];
}

export const TRANG_THAI: Record<TrangThaiHoSo, MetaTrangThai> = {
  soan: {
    nhan: "Đang soạn",
    moTa: "Cán bộ tín dụng đang nhập liệu, chưa trình kiểm soát.",
    keTiep: ["trinh"],
  },
  trinh: {
    nhan: "Chờ kiểm soát",
    moTa: "Đã trình, kiểm soát viên duyệt hoặc trả lại kèm ghi chú.",
    keTiep: ["duyet", "tra-lai"],
  },
  "tra-lai": {
    nhan: "Trả lại để sửa",
    moTa: "Kiểm soát viên trả lại; sửa xong trình lại.",
    keTiep: ["trinh"],
  },
  duyet: {
    nhan: "Đã duyệt",
    moTa: "Hồ sơ đã được duyệt, chỉ còn in và trình ký.",
    keTiep: [],
  },
};

export const TRANG_THAI_MAC_DINH: TrangThaiHoSo = "soan";

export interface BuocLuanChuyen {
  id: string;
  tu: TrangThaiHoSo;
  den: TrangThaiHoSo;
  nguoi: string;
  ghiChu: string;
  luc: number;
}

export interface YeuCauChuyen {
  tu: TrangThaiHoSo;
  den: TrangThaiHoSo;
  nguoi: string;
  ghiChu?: string;
  /** Số lỗi chặn xuất của hồ sơ tại thời điểm chuyển. */
  soLoiChan: number;
}

/** Trả về câu lỗi bằng tiếng Việt, hoặc null nếu chuyển được. */
export function kiemTraChuyen(y: YeuCauChuyen): string | null {
  const meta = TRANG_THAI[y.tu];
  if (!meta.keTiep.includes(y.den)) {
    return `Không chuyển được từ “${meta.nhan}” sang “${TRANG_THAI[y.den].nhan}”.`;
  }
  if (!y.nguoi.trim()) return "Phải ghi tên người thực hiện trước khi chuyển.";
  if (y.den === "tra-lai" && !(y.ghiChu ?? "").trim()) {
    return "Trả lại hồ sơ phải kèm lý do để cán bộ biết sửa gì.";
  }
  if ((y.den === "trinh" || y.den === "duyet") && y.soLoiChan > 0) {
    return `Hồ sơ còn ${y.soLoiChan} lỗi chặn — sửa hết mới ${
      y.den === "trinh" ? "trình" : "duyệt"
    } được.`;
  }
  return null;
}

let seqBuoc = 0;

export interface KetQuaChuyen {
  ok: boolean;
  loi?: string;
  trangThai: TrangThaiHoSo;
  lichSu: BuocLuanChuyen[];
  thongBao: string;
}

export function chuyenTrangThai(
  lichSu: BuocLuanChuyen[],
  y: YeuCauChuyen,
  luc = Date.now(),
): KetQuaChuyen {
  const loi = kiemTraChuyen(y);
  if (loi) return { ok: false, loi, trangThai: y.tu, lichSu, thongBao: loi };
  seqBuoc += 1;
  const buoc: BuocLuanChuyen = {
    id: `lc-${luc.toString(36)}-${seqBuoc}`,
    tu: y.tu,
    den: y.den,
    nguoi: y.nguoi.trim(),
    ghiChu: (y.ghiChu ?? "").trim(),
    luc,
  };
  return {
    ok: true,
    trangThai: y.den,
    lichSu: [buoc, ...lichSu].slice(0, 30),
    thongBao: `${buoc.nguoi} chuyển hồ sơ sang “${TRANG_THAI[y.den].nhan}”${
      buoc.ghiChu ? ` — ${buoc.ghiChu}` : ""
    }.`,
  };
}

export function nhanGioPhut(luc: number): string {
  const d = new Date(luc);
  const hai = (n: number) => String(n).padStart(2, "0");
  return `${hai(d.getDate())}/${hai(d.getMonth() + 1)} ${hai(d.getHours())}:${hai(d.getMinutes())}`;
}

export function tomTatLuanChuyen(
  trangThai: TrangThaiHoSo,
  chuSoHuu: string,
  lichSu: BuocLuanChuyen[],
): string {
  const gan = lichSu[0];
  const ai = chuSoHuu.trim() || "chưa giao ai";
  if (!gan) return `${TRANG_THAI[trangThai].nhan} · chủ sở hữu: ${ai}.`;
  return `${TRANG_THAI[trangThai].nhan} · chủ sở hữu: ${ai} · gần nhất ${nhanGioPhut(gan.luc)} do ${gan.nguoi}.`;
}
