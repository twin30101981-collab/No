/**
 * PHIÊN 16 (PHẦN 5) — PHIẾU KIỂM TRA MỘT TRANG TRƯỚC KHI TRÌNH KÝ.
 *
 * Một tờ A4 kẹp cùng bộ hồ sơ giấy: hồ sơ này của ai, đang ở bước nào, còn
 * thiếu trường bắt buộc nào, có lệch số giữa các tài liệu không, ai ký ở đâu.
 * Nội dung lấy đúng từ cửa chặn xuất và các bộ quy tắc đã có — không tính lại,
 * nên phiếu in luôn nói cùng một điều với màn hình.
 */
import { crossResults } from "./crossChecks";
import type { HoSo } from "./fieldMeta";
import { oNhanKy, dongDiaDiemNgay } from "./kyDuyet";
import { loiTaiLieu } from "./kiemTraTaiLieu";
import { TRANG_THAI, type TrangThaiHoSo } from "./luanChuyen";
import type { Issue } from "./validation";

export interface MucPhieu {
  nhan: string;
  dat: boolean;
  chiTiet: string[];
}

export interface PhieuKiemTra {
  tieuDe: string;
  ten: string;
  chuSoHuu: string;
  trangThai: string;
  dongNgay: string;
  mucs: MucPhieu[];
  chuKy: string[];
  dat: boolean;
}

export interface ThamSoPhieu {
  ten: string;
  hoSo: HoSo;
  chuSoHuu: string;
  trangThai: TrangThaiHoSo;
  chanXuat: Issue[];
}

export function dungPhieuKiemTra(t: ThamSoPhieu): PhieuKiemTra {
  const cheo = crossResults(t.hoSo)
    .filter((r) => !r.ok)
    .map((r) => `${r.rule.label}: ${r.message}`);
  const taiLieu = loiTaiLieu(t.hoSo);
  const thieu = t.chanXuat.map((i) => `${i.label}: ${i.message}`);
  const ky = oNhanKy(t.hoSo);
  const thieuKy = ky.filter((o) => o.ten.startsWith("…")).map((o) => `${o.vaiTro}: chưa có tên`);

  const mucs: MucPhieu[] = [
    { nhan: "Trường bắt buộc đã đủ", dat: thieu.length === 0, chiTiet: thieu },
    { nhan: "Kiểm tra chéo trong hồ sơ", dat: cheo.length === 0, chiTiet: cheo },
    { nhan: "Đối chiếu giữa các tài liệu", dat: taiLieu.length === 0, chiTiet: taiLieu },
    { nhan: "Khối ký duyệt đã ghi tên", dat: thieuKy.length === 0, chiTiet: thieuKy },
  ];

  return {
    tieuDe: "PHIẾU KIỂM TRA HỒ SƠ TRƯỚC KHI TRÌNH KÝ",
    ten: t.ten,
    chuSoHuu: t.chuSoHuu.trim() || "chưa giao",
    trangThai: TRANG_THAI[t.trangThai].nhan,
    dongNgay: dongDiaDiemNgay(t.hoSo),
    mucs,
    chuKy: ky.map((o) => `${o.vaiTro}: ${o.ten}${o.chucVu ? ` (${o.chucVu})` : ""}`),
    dat: mucs.every((m) => m.dat),
  };
}

/** Bản văn thuần để tải về / dán vào email nội bộ. */
export function vanBanPhieu(p: PhieuKiemTra): string {
  const dong: string[] = [
    p.tieuDe,
    `Hồ sơ: ${p.ten}`,
    `Chủ sở hữu: ${p.chuSoHuu} · Trạng thái: ${p.trangThai}`,
    p.dongNgay,
    "",
  ];
  p.mucs.forEach((m, i) => {
    dong.push(`${i + 1}. [${m.dat ? "x" : " "}] ${m.nhan}`);
    m.chiTiet.forEach((c) => dong.push(`      - ${c}`));
  });
  dong.push("", "Khối ký:", ...p.chuKy.map((c) => `  ${c}`));
  dong.push("", `Kết luận: ${p.dat ? "ĐỦ ĐIỀU KIỆN TRÌNH KÝ" : "CHƯA ĐỦ — xem các mục còn trống"}`);
  return dong.join("\n");
}
