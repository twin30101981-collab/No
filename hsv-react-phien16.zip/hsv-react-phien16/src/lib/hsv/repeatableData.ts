import { TABLE_META, type TableRows } from "./tableMeta";

/** Dữ liệu mẫu cho bảng lặp dòng 1 cột (trang /pilot — chỉ đọc, Phiên 7). */
export const demoRows: Record<string, Array<string | number>> = {
  chiPhiVatTu: [
    45_000_000, 32_000_000, 18_500_000, 12_000_000, 9_800_000, 7_500_000, 6_200_000,
    5_000_000, 4_300_000, 3_800_000, 2_900_000, 2_100_000, 1_600_000, 1_300_000,
  ],
};

const VAT_TU_TEN = [
  "Giống lúa lai",
  "Phân đạm Urê",
  "Phân lân",
  "Phân kali",
  "Thuốc bảo vệ thực vật",
  "Nhiên liệu máy nông nghiệp",
  "Thuê máy làm đất",
  "Thuê nhân công gieo cấy",
  "Thuê nhân công thu hoạch",
  "Bao bì đóng gói",
  "Vận chuyển nội đồng",
  "Điện bơm tưới",
  "Sửa chữa nhỏ máy móc",
  "Chi phí khác",
];

/**
 * PHIÊN 8 (nửa sau) — dữ liệu mẫu cho bảng lặp NHIỀU CỘT.
 * Danh mục TSBĐ có 3 tài sản để chứng minh việc hợp nhất 3 hệ song song của hệ cũ
 * (trước đây chỉ in được tài sản đầu tiên — finding 16.7).
 */
export const demoTableRows: TableRows = {
  danhSachTaiSan: [
    {
      tenTaiSan: "Quyền sử dụng đất ở tại đô thị",
      giayToSoHuu: "GCN số CX 123456",
      diaChi: "Số 12 Trần Hưng Đạo, TP Nam Định",
      giaTri: 2_400_000_000,
    },
    {
      tenTaiSan: "Nhà ở gắn liền với đất",
      giayToSoHuu: "GCN số CX 123456 (hạng mục nhà)",
      diaChi: "Số 12 Trần Hưng Đạo, TP Nam Định",
      giaTri: 850_000_000,
    },
    {
      tenTaiSan: "Xe tải Hyundai 3,5 tấn",
      giayToSoHuu: "Đăng ký xe 18C-123.45",
      diaChi: "Bãi xe hộ vay, xã Nam Vân",
      giaTri: 420_000_000,
    },
  ],
  chiPhiVatTu: VAT_TU_TEN.map((noiDung, i) => ({
    noiDung,
    donViTinh: i < 4 ? "Tấn" : i < 9 ? "Công" : "Lượt",
    soTien: demoRows["chiPhiVatTu"]![i] ?? 0,
  })),
};

/** Bảo đảm mọi bảng khai báo đều có dữ liệu khởi tạo. */
export function initialTableRows(): TableRows {
  return Object.fromEntries(
    TABLE_META.map((t) => [t.key, (demoTableRows[t.key] ?? []).map((r) => ({ ...r }))]),
  );
}
