/**
 * PHIÊN 8 (nửa sau) — KHAI BÁO BẢNG LẶP DÒNG NHIỀU CỘT.
 *
 * Mục tiêu nghiệp vụ (finding 4.2 của đề án): hệ cũ đang có 3 hệ TSBĐ song song
 * (nhóm trường phẳng "Tài sản số 1..6", bộ trường `.ts.*` chỉ mô tả 1 tài sản, và
 * vòng lặp `tai_san` / `ts_arr` trong mẫu DOCX). Ở bản React, cả 3 được hợp nhất
 * về MỘT khai báo có dòng duy nhất: `danhSachTaiSan`.
 *
 * Đây là khai báo dùng chung cho cả giao diện nhập liệu (component bảng lặp) và
 * bộ sinh DOCX (bảng thật trong tệp) — một điểm sự thật, không chép tay 2 nơi.
 * Vẫn CHỈ ĐỌC với dữ liệu hệ cũ: người dùng nhập trên bản React, không ghi ngược.
 */
import type { FieldKind, FieldMeta } from "./fieldMeta";

export interface TableColumn {
  key: string;
  label: string;
  kind: FieldKind;
  /** Tỉ lệ bề rộng cột khi in ra DOCX (tổng các cột = 100). */
  width: number;
  /** PHIÊN 9 — cột bắt buộc: ô trống sẽ chặn xuất văn bản. */
  required?: boolean;
}

export interface TableMeta {
  key: string;
  label: string;
  group: FieldMeta["group"];
  columns: readonly TableColumn[];
  /** Cột được cộng tổng tự động (nếu có). */
  totalColumn?: string;
  minRows: number;
  maxRows: number;
  /** Các hệ song song của hệ cũ được khai báo này thay thế. */
  legacySources: readonly string[];
  /** Tiêu đề bảng khi in vào tệp DOCX. */
  docxTitle: string;
}

export type TableRow = Record<string, string | number>;
export type TableRows = Record<string, TableRow[]>;

export const TABLE_META: readonly TableMeta[] = [
  {
    key: "danhSachTaiSan",
    label: "Danh mục tài sản bảo đảm (nhiều tài sản)",
    group: "tsbd",
    columns: [
      { key: "tenTaiSan", label: "Tên tài sản", kind: "text", width: 34, required: true },
      { key: "giayToSoHuu", label: "Giấy tờ sở hữu", kind: "text", width: 26 },
      { key: "diaChi", label: "Địa chỉ / vị trí", kind: "text", width: 22 },
      { key: "giaTri", label: "Giá trị định giá", kind: "money", width: 18, required: true },
    ],
    totalColumn: "giaTri",
    minRows: 1,
    maxRows: 20,
    legacySources: [
      'Nhóm trường phẳng "Tài sản số 1..6"',
      "Bộ trường .ts.* (chỉ mô tả 1 tài sản)",
      "Vòng lặp tai_san / ts_arr trong mẫu DOCX",
    ],
    docxTitle: "DANH MỤC TÀI SẢN BẢO ĐẢM",
  },
  {
    key: "chiPhiVatTu",
    label: "Chi tiết chi phí vật tư",
    group: "pa-sxkd",
    columns: [
      { key: "noiDung", label: "Nội dung chi phí", kind: "text", width: 60, required: true },
      { key: "donViTinh", label: "ĐVT", kind: "text", width: 15 },
      { key: "soTien", label: "Số tiền", kind: "money", width: 25, required: true },
    ],
    totalColumn: "soTien",
    minRows: 1,
    maxRows: 30,
    legacySources: ['14 trường phẳng "Chi phí vật tư 1..14 HM/TD"'],
    docxTitle: "BẢNG CHI PHÍ VẬT TƯ PHƯƠNG ÁN SXKD",
  },
];

export function findTable(key: string): TableMeta | undefined {
  return TABLE_META.find((t) => t.key === key);
}

/** Dòng trống đúng theo khai báo cột — dùng khi cán bộ bấm "Thêm dòng". */
export function emptyRow(meta: TableMeta): TableRow {
  return Object.fromEntries(meta.columns.map((c) => [c.key, ""]));
}

export function toNumber(value: string | number | undefined): number {
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  if (!value) return 0;
  const cleaned = String(value).trim().replace(/[\s đ]|VND/gi, "").replace(/\./g, "").replace(/,/g, ".");
  return /^-?\d+(\.\d+)?$/.test(cleaned) ? Number(cleaned) : 0;
}

/** Tổng cột được đánh dấu totalColumn — dùng chung cho UI và DOCX. */
export function tableTotal(meta: TableMeta, rows: TableRow[]): number {
  if (!meta.totalColumn) return 0;
  return rows.reduce((s, r) => s + toNumber(r[meta.totalColumn!]), 0);
}

export const formatMoney = (n: number) => `${n.toLocaleString("vi-VN")} đ`;

/**
 * PHIÊN 9 — khoá lỗi của MỘT Ô trong bảng lặp, dùng chung giữa lớp validate và
 * giao diện nhập liệu (đặt thông báo ngay dưới đúng ô sai).
 */
export function cellIssueKey(tableKey: string, rowIndex: number, columnKey: string): string {
  return `${tableKey}[${rowIndex}].${columnKey}`;
}
