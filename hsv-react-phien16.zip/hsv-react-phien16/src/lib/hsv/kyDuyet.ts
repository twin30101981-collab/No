/**
 * PHIÊN 12B — KÝ/DUYỆT NỘI BỘ (người lập – người kiểm soát – người duyệt).
 *
 * Hệ cũ để cán bộ tự gõ tên/chức vụ người ký vào từng mẫu, nên cùng một hồ sơ
 * mà 4 mẫu hay lệch tên, sai chức vụ, thiếu ngày ký. Ở đây khối ký được khai báo
 * MỘT lần từ FIELD_META và in đúng chỗ ký ở cuối cả 4 mẫu DOCX.
 *
 * Tệp này thuần dữ liệu (không phụ thuộc thư viện DOCX) để trang xem trước dùng
 * lại được mà không phải nạp bộ sinh tệp.
 */
import type { HoSo } from "./fieldMeta";

export interface CotKy {
  /** Tiêu đề cột ký in trong văn bản. */
  vaiTro: string;
  tenKey: string;
  chucVuKey: string;
  ghiChu: string;
}

export const COT_KY: readonly CotKy[] = [
  {
    vaiTro: "NGƯỜI LẬP",
    tenKey: "nguoiLap",
    chucVuKey: "chucVuNguoiLap",
    ghiChu: "(Ký, ghi rõ họ tên)",
  },
  {
    vaiTro: "NGƯỜI KIỂM SOÁT",
    tenKey: "nguoiKiemSoat",
    chucVuKey: "chucVuNguoiKiemSoat",
    ghiChu: "(Ký, ghi rõ họ tên)",
  },
  {
    vaiTro: "NGƯỜI DUYỆT",
    tenKey: "nguoiPheDuyet",
    chucVuKey: "chucVuNguoiPheDuyet",
    ghiChu: "(Ký, đóng dấu)",
  },
];

export interface ONhanKy {
  vaiTro: string;
  ten: string;
  chucVu: string;
  ghiChu: string;
}

const chu = (v: unknown) => String(v ?? "").trim();

/** Ba ô ký lấy thẳng giá trị hồ sơ; thiếu tên thì để dòng chấm cho ký tay. */
export function oNhanKy(hoSo: HoSo): ONhanKy[] {
  return COT_KY.map((c) => ({
    vaiTro: c.vaiTro,
    ten: chu(hoSo[c.tenKey]) || "…………………………",
    chucVu: chu(hoSo[c.chucVuKey]),
    ghiChu: c.ghiChu,
  }));
}

/** Dòng "Nam Định, ngày 20 tháng 08 năm 2026" đặt trên khối ký. */
export function dongDiaDiemNgay(hoSo: HoSo): string {
  const noi = chu(hoSo["noiKyDuyet"]) || "Nam Định";
  const ngay = chu(hoSo["ngayKyDuyet"]);
  const m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(ngay);
  if (!m) return `${noi}, ngày …… tháng …… năm ………`;
  return `${noi}, ngày ${m[1]!.padStart(2, "0")} tháng ${m[2]!.padStart(2, "0")} năm ${m[3]}`;
}

/** Tóm tắt một dòng cho trang bìa mục lục của bộ hồ sơ. */
export function tomTatKy(hoSo: HoSo): string {
  return oNhanKy(hoSo)
    .map((o) => `${o.vaiTro}: ${o.ten}${o.chucVu ? ` (${o.chucVu})` : ""}`)
    .join(" · ");
}
