/**
 * PHIÊN 15 (PHẦN 2) — LỊCH TRẢ NỢ TỰ SINH.
 *
 * Cán bộ đang phải tự tính bảng kỳ trả nợ bằng máy tính tay rồi gõ vào phụ lục
 * hợp đồng — sai một dòng là sai cả bảng. Ở đây bảng kỳ trả nợ sinh thẳng từ
 * số tiền vay / lãi suất / thời hạn / kỳ trả, hai cách thông dụng:
 *  - "goc-deu": gốc chia đều, lãi tính trên dư nợ giảm dần
 *  - "nien-kim": tổng gốc + lãi cố định mỗi kỳ (niên kim)
 */
export type KieuTraNo = "goc-deu" | "nien-kim";

export interface KyTraNo {
  ky: number;
  /** Nhãn kỳ dạng mm/yyyy tính từ ngày giải ngân. */
  moc: string;
  goc: number;
  lai: number;
  tong: number;
  duNoConLai: number;
}

export interface ThamSoLich {
  soTien: number;
  laiSuatNam: number;
  soThang: number;
  kyThang: number;
  kieu: KieuTraNo;
  /** Ngày bắt đầu dạng dd/mm/yyyy; mặc định hôm nay. */
  ngayBatDau?: string;
}

export interface KetQuaLich {
  ky: KyTraNo[];
  tongGoc: number;
  tongLai: number;
  tongPhaiTra: number;
  loi: string[];
}

function parseNgay(s?: string): Date {
  const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec((s ?? "").trim());
  if (!m) return new Date();
  return new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]));
}

function mocSau(base: Date, thang: number): string {
  const d = new Date(base.getFullYear(), base.getMonth() + thang, 1);
  return `${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
}

const lam = (n: number) => Math.round(n);

export function taoLichTraNo(t: ThamSoLich): KetQuaLich {
  const loi: string[] = [];
  const rong: KetQuaLich = { ky: [], tongGoc: 0, tongLai: 0, tongPhaiTra: 0, loi };
  if (!(t.soTien > 0)) loi.push("Số tiền vay phải lớn hơn 0.");
  if (!(t.soThang > 0)) loi.push("Thời hạn vay (tháng) phải lớn hơn 0.");
  if (!(t.kyThang > 0)) loi.push("Kỳ trả nợ (tháng) phải lớn hơn 0.");
  if (t.laiSuatNam < 0) loi.push("Lãi suất không được âm.");
  if (loi.length > 0) return rong;

  const soKy = Math.max(1, Math.ceil(t.soThang / t.kyThang));
  const laiKy = (t.laiSuatNam / 100) * (t.kyThang / 12);
  const base = parseNgay(t.ngayBatDau);
  const ky: KyTraNo[] = [];
  let duNo = t.soTien;

  if (t.kieu === "nien-kim" && laiKy > 0) {
    const a = (t.soTien * laiKy) / (1 - Math.pow(1 + laiKy, -soKy));
    for (let i = 1; i <= soKy; i += 1) {
      const lai = lam(duNo * laiKy);
      let goc = lam(a - lai);
      if (i === soKy) goc = lam(duNo);
      duNo = lam(duNo - goc);
      ky.push({
        ky: i,
        moc: mocSau(base, i * t.kyThang),
        goc,
        lai,
        tong: goc + lai,
        duNoConLai: Math.max(0, duNo),
      });
    }
  } else {
    const gocKy = lam(t.soTien / soKy);
    for (let i = 1; i <= soKy; i += 1) {
      const lai = lam(duNo * laiKy);
      const goc = i === soKy ? lam(duNo) : gocKy;
      duNo = lam(duNo - goc);
      ky.push({
        ky: i,
        moc: mocSau(base, i * t.kyThang),
        goc,
        lai,
        tong: goc + lai,
        duNoConLai: Math.max(0, duNo),
      });
    }
  }

  const tongGoc = ky.reduce((s, k) => s + k.goc, 0);
  const tongLai = ky.reduce((s, k) => s + k.lai, 0);
  return { ky, tongGoc, tongLai, tongPhaiTra: tongGoc + tongLai, loi };
}

export function tienVn(n: number): string {
  return n.toLocaleString("vi-VN");
}

/** Bảng kỳ trả nợ dạng văn bản để chèn vào phụ lục hợp đồng / DOCX. */
export function lichThanhVanBan(kq: KetQuaLich): string {
  const dong = kq.ky.map(
    (k) =>
      `Kỳ ${k.ky} (${k.moc}): gốc ${tienVn(k.goc)} đ + lãi ${tienVn(k.lai)} đ = ${tienVn(k.tong)} đ, dư nợ còn ${tienVn(k.duNoConLai)} đ`,
  );
  dong.push(
    `Tổng cộng: gốc ${tienVn(kq.tongGoc)} đ + lãi ${tienVn(kq.tongLai)} đ = ${tienVn(kq.tongPhaiTra)} đ`,
  );
  return dong.join("\n");
}
