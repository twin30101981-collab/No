/**
 * PHIÊN 16 (PHẦN 3) — KIỂM TRA CHÉO GIỮA CÁC TÀI LIỆU.
 *
 * Phiên 11 kiểm tra chéo trong MỘT hồ sơ. Ở đây kiểm tra giữa CÁC TÀI LIỆU sẽ
 * in ra: hợp đồng tín dụng, hợp đồng thế chấp, giấy nhận nợ và biên bản định
 * giá phải nói cùng một con số, cùng một tên khách, cùng một số hợp đồng.
 * Lệch là chặn — vì đây là loại lỗi khách hàng phát hiện tại quầy.
 *
 * Mọi quy tắc khai báo tập trung tại đây, dùng chung cho giao diện và phiếu in.
 */
import type { HoSo } from "./fieldMeta";
import { formatMoney, toNumber } from "./tableMeta";

export interface QuyTacTaiLieu {
  key: string;
  nhan: string;
  /** Tên các tài liệu cùng in ra dữ kiện này. */
  taiLieu: readonly string[];
  moTa: (h: HoSo) => string;
  check: (h: HoSo) => string | null;
}

const chu = (h: HoSo, k: string) => String(h[k] ?? "").trim();
const so = (h: HoSo, k: string) => toNumber(h[k] as string | number | undefined);
const gonTen = (s: string) => s.replace(/\s+/g, " ").trim().toLocaleUpperCase("vi-VN");

export const QUY_TAC_TAI_LIEU: readonly QuyTacTaiLieu[] = [
  {
    key: "tenKhach",
    nhan: "Tên khách hàng khớp giữa HĐTD và Giấy nhận nợ",
    taiLieu: ["Hợp đồng tín dụng", "Giấy nhận nợ"],
    moTa: (h) =>
      `HĐTD in “${chu(h, "tenKhachHang") || "(trống)"}”, giấy nhận nợ in “${
        chu(h, "tenKhachHangInHoa") || "(trống)"
      }”.`,
    check: (h) => {
      const a = chu(h, "tenKhachHang");
      const b = chu(h, "tenKhachHangInHoa");
      if (!a || !b) return null;
      return gonTen(a) === gonTen(b)
        ? null
        : `tên trên giấy nhận nợ (“${b}”) khác tên trên hợp đồng tín dụng (“${a}”)`;
    },
  },
  {
    key: "soHopDong",
    nhan: "Số & ngày HĐTD có mặt ở cả ba tài liệu",
    taiLieu: ["Hợp đồng tín dụng", "Hợp đồng thế chấp", "Giấy nhận nợ"],
    moTa: (h) =>
      `Số HĐTD “${chu(h, "soHopDongTinDung") || "(trống)"}” ngày “${
        chu(h, "ngayHopDongTinDung") || "(trống)"
      }” được nhắc lại trong HĐ thế chấp và giấy nhận nợ.`,
    check: (h) => {
      const so1 = chu(h, "soHopDongTinDung");
      const ngay = chu(h, "ngayHopDongTinDung");
      if (!so1) return "chưa có số HĐ tín dụng — HĐ thế chấp và giấy nhận nợ sẽ in ô trống";
      if (!ngay) return "chưa có ngày HĐ tín dụng — HĐ thế chấp và giấy nhận nợ sẽ in ô trống";
      return null;
    },
  },
  {
    key: "nhanNoVsVay",
    nhan: "Số tiền nhận nợ ≤ số tiền vay trên HĐTD",
    taiLieu: ["Hợp đồng tín dụng", "Giấy nhận nợ"],
    moTa: (h) =>
      `Giấy nhận nợ ${formatMoney(so(h, "soTienNhanNoNn"))} so với HĐTD ${formatMoney(
        so(h, "soTienVay"),
      )}.`,
    check: (h) => {
      const nn = so(h, "soTienNhanNoNn");
      const vay = so(h, "soTienVay");
      if (nn <= 0 || vay <= 0) return null;
      return nn <= vay
        ? null
        : `giấy nhận nợ ${formatMoney(nn)} lớn hơn số tiền vay ghi trên HĐTD ${formatMoney(vay)}`;
    },
  },
  {
    key: "baoDamVsVay",
    nhan: "Nghĩa vụ bảo đảm (HĐ thế chấp) ≥ số tiền vay",
    taiLieu: ["Hợp đồng thế chấp", "Hợp đồng tín dụng"],
    moTa: (h) =>
      `Nghĩa vụ bảo đảm ${formatMoney(so(h, "nghiaVuBaoDam"))} so với số tiền vay ${formatMoney(
        so(h, "soTienVay"),
      )}.`,
    check: (h) => {
      const nv = so(h, "nghiaVuBaoDam");
      const vay = so(h, "soTienVay");
      if (nv <= 0 || vay <= 0) return null;
      return nv >= vay
        ? null
        : `nghĩa vụ bảo đảm ${formatMoney(nv)} nhỏ hơn số tiền vay ${formatMoney(vay)}`;
    },
  },
  {
    key: "dinhGiaVsTheChap",
    nhan: "Mức nhận bảo đảm (BBĐG) ≤ tổng giá trị tài sản",
    taiLieu: ["Biên bản định giá", "Hợp đồng thế chấp"],
    moTa: (h) =>
      `Mức nhận bảo đảm ${formatMoney(so(h, "nvdbChoKv"))} trên tổng giá trị tài sản ${formatMoney(
        so(h, "tongGiaTriTs"),
      )}.`,
    check: (h) => {
      const nv = so(h, "nvdbChoKv");
      const ts = so(h, "tongGiaTriTs");
      if (nv <= 0 || ts <= 0) return null;
      return nv <= ts
        ? null
        : `biên bản định giá nhận bảo đảm ${formatMoney(nv)} vượt tổng giá trị tài sản ${formatMoney(ts)}`;
    },
  },
  {
    key: "ngayNhanNo",
    nhan: "Ngày nhận nợ không sớm hơn ngày HĐTD",
    taiLieu: ["Giấy nhận nợ", "Hợp đồng tín dụng"],
    moTa: (h) =>
      `Ngày HĐTD ${chu(h, "ngayHopDongTinDung") || "(trống)"}, ngày nhận nợ ${
        chu(h, "ngayNhanNo") || "(trống)"
      }.`,
    check: (h) => {
      const a = ngay(chu(h, "ngayHopDongTinDung"));
      const b = ngay(chu(h, "ngayNhanNo"));
      if (a === null || b === null) return null;
      return b >= a
        ? null
        : `ngày nhận nợ ${chu(h, "ngayNhanNo")} sớm hơn ngày ký HĐTD ${chu(h, "ngayHopDongTinDung")}`;
    },
  },
];

function ngay(v: string): number | null {
  const m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(v.trim());
  if (!m) return null;
  return new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1])).getTime();
}

export interface KetQuaTaiLieu {
  rule: QuyTacTaiLieu;
  loi: string | null;
}

export function kiemTraTaiLieu(hoSo: HoSo): KetQuaTaiLieu[] {
  return QUY_TAC_TAI_LIEU.map((rule) => ({ rule, loi: rule.check(hoSo) }));
}

export function loiTaiLieu(hoSo: HoSo): string[] {
  return kiemTraTaiLieu(hoSo)
    .filter((k) => k.loi)
    .map((k) => `${k.rule.nhan}: ${k.loi}`);
}
