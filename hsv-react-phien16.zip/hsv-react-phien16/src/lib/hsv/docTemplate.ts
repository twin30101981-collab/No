/**
 * PHIÊN 7–8 — mẫu văn bản khai báo bằng nhãn nghiệp vụ (GĐ2).
 * Mẫu được khai báo bằng nhãn nghiệp vụ; nội dung được điền từ FIELD_META,
 * KHÔNG xuất tệp và KHÔNG ghi dữ liệu hệ cũ trong phiên này.
 */
import { FIELD_META, findKeyByLabel, formatValue, type HoSo } from "./fieldMeta";

export interface TemplateBlock {
  heading?: string;
  lines: string[];
}

export interface DocTemplate {
  id: string;
  name: string;
  legacyFile: string;
  blocks: TemplateBlock[];
}

/** Cú pháp chỗ trống: {{Nhãn trường}} — đúng nhãn trong FIELD_META. */
export const TEMPLATES: readonly DocTemplate[] = [
  {
    id: "hdtd",
    name: "Hợp đồng tín dụng (hạn mức)",
    legacyFile: "public/legacy/templates-data.js · mẫu HĐTD",
    blocks: [
      {
        heading: "NGÂN HÀNG NÔNG NGHIỆP VÀ PTNT VIỆT NAM — CN THIÊN TRƯỜNG NAM ĐỊNH",
        lines: [
          "HỢP ĐỒNG TÍN DỤNG số {{Số HĐ tín dụng}} ngày {{Ngày HĐ tín dụng}}",
          "Bên vay: {{Tên khách hàng}} — {{Loại CMND}} số {{CMND}}",
          "Địa chỉ: {{Địa chỉ}} · Điện thoại: {{Số điện thoại}}",
        ],
      },
      {
        heading: "Điều 1. Số tiền và mục đích vay",
        lines: [
          "Số tiền vay: {{Số tiền vay}} (bằng chữ: {{Số tiền vay bằng chữ}})",
          "Mục đích vay: {{Mục đích vay}}",
          "Hạn mức tín dụng được duyệt: {{HMTD duyệt}}",
          "Nhu cầu vốn theo phương án SXKD: {{Tổng nhu cầu vốn}} ({{Tổng nhu cầu vốn bằng chữ}})",
          "Chi tiết chi phí vật tư của phương án:",
          "{{#chiPhiVatTu}}{{/chiPhiVatTu}}",
        ],
      },
      {
        heading: "Điều 2. Bảo đảm tiền vay",
        lines: [
          "Tài sản bảo đảm: {{Tên TSBĐ}}",
          "Tỷ lệ cho vay trên giá trị tài sản: {{Giá trị cho vay / Giá trị TS}}",
        ],
      },
    ],
  },
  {
    id: "hdtc",
    name: "Hợp đồng thế chấp quyền sử dụng đất",
    legacyFile: "public/legacy/templates-data.js · mẫu HĐTC",
    blocks: [
      {
        heading: "HỢP ĐỒNG THẾ CHẤP TÀI SẢN",
        lines: [
          "Số {{Số HĐ thế chấp}} — ký ngày {{Ngày ký HĐTC}} · Loại: {{Loại HĐTC}}",
          "Bên thế chấp: {{Bên thế chấp in hoa}} — {{Loại CMT chủ tài sản}} số {{CMT chủ tài sản}}",
          "Địa chỉ bên thế chấp: {{Địa chỉ chủ tài sản}} (hộ khẩu: {{Địa chỉ hộ khẩu chủ tài sản}})",
        ],
      },
      {
        heading: "Điều 1. Tài sản thế chấp",
        lines: [
          "Tài sản: {{Tên TSĐB}} — giấy chứng nhận số {{Số bìa đỏ}}",
          "Thửa số {{Số thửa}}, địa chỉ: {{Địa chỉ đất}}",
          "Diện tích: {{Diện tích đất}} m2 ({{DTĐ bằng chữ}}) · Loại đất: {{Loại đất}} · Thời hạn: {{Thời hạn sử dụng}}",
          "Giá trị quyền sử dụng đất: {{Giá trị quyền sử dụng đất}} · Giá trị nhà: {{Giá trị nhà làm tròn số}}",
          "Tổng giá trị tài sản: {{Tổng giá trị TS}} ({{TGTTS bằng chữ}})",
          "Mô tả tài sản thế chấp: {{Mô tả tài sản thế chấp}}",
          "Danh mục chi tiết các tài sản thế chấp:",
          "{{#danhSachTaiSan}}{{/danhSachTaiSan}}",
        ],
      },
      {
        heading: "Điều 2. Nghĩa vụ được bảo đảm",
        lines: [
          "Nghĩa vụ bảo đảm: {{Nghĩa vụ bảo đảm}} ({{NVBĐ bằng chữ}})",
          "Bảo đảm cho HĐTD số {{Số HĐ tín dụng}} ngày {{Ngày HĐ tín dụng}} của {{Tên khách hàng}}",
          "Tỷ lệ giá trị cho vay trên giá trị tài sản: {{Giá trị cho vay / Giá trị TS}}",
        ],
      },
    ],
  },
  {
    id: "gnn",
    name: "Giấy nhận nợ (giải ngân)",
    legacyFile: "public/legacy/templates-data.js · mẫu Giấy nhận nợ",
    blocks: [
      {
        heading: "GIẤY NHẬN NỢ",
        lines: [
          "Ngày nhận nợ: {{Ngày nhận nợ}} · Thuộc HĐTD số {{Số HĐ tín dụng}} ngày {{Ngày HĐ tín dụng}}",
          "Bên nhận nợ: {{Tên khách hàng in hoa}} — địa chỉ {{Địa chỉ}}",
        ],
      },
      {
        heading: "1. Số tiền nhận nợ",
        lines: [
          "Số tiền nhận nợ lần này: {{Số tiền nhận nợ NN}} ({{Số tiền nhận nợ NN bằng chữ}})",
          "Dư nợ tại Agribank sau khi nhận nợ: {{Số tiền sau khi NN}} ({{Số tiền sau khi NN bằng chữ}})",
          "Hạn mức tín dụng tối đa: {{Hạn mức tín dụng tối đa}} · Số vòng quay: {{Số vòng quay}}",
          "Nhu cầu vốn của lần giải ngân theo bảng chi phí vật tư: {{Tổng nhu cầu vốn}} ({{Tổng nhu cầu vốn bằng chữ}})",
          "{{#chiPhiVatTu}}{{/chiPhiVatTu}}",
        ],
      },
      {
        heading: "2. Lãi suất và trả nợ",
        lines: [
          "Lãi suất cho vay: {{Lãi suất vay}} · Kỳ hạn trả nợ gốc: {{Kỳ hạn trả nợ gốc}} tháng",
          "Thời hạn trả nợ cuối cùng: {{Thời hạn trả nợ cuối}}",
        ],
      },
      {
        heading: "3. Người thụ hưởng",
        lines: [
          "Người thụ hưởng: {{Người thụ hưởng}} — {{Loại CMND người thụ hưởng}} số {{CMND người thụ hưởng}}",
          "Tài khoản {{Số TK người thụ hưởng}} mở tại {{Mở tại ngân hàng}} · Địa chỉ: {{Địa chỉ người thụ hưởng}}",
          "Phương thức thanh toán: {{Phương thức thanh toán}}",
        ],
      },
    ],
  },
  {
    id: "bbdg",
    name: "Biên bản định giá tài sản bảo đảm",
    legacyFile: "public/legacy/templates-data.js · mẫu BBĐG",
    blocks: [
      {
        heading: "BIÊN BẢN ĐỊNH GIÁ TÀI SẢN BẢO ĐẢM",
        lines: [
          "Số biên bản: {{Số BBĐG}} · Ngày định giá: {{Ngày BBĐG}}",
          "Chủ tài sản: {{Chủ tài sản viết hoa}} — {{Loại CMT chủ tài sản}} số {{CMT chủ tài sản}}",
          "Tài sản định giá: {{Tên TSĐB}} tại {{Địa chỉ đất}}",
        ],
      },
      {
        heading: "1. Định giá quyền sử dụng đất",
        lines: [
          "Diện tích đất: {{Diện tích đất}} m2 · Vị trí theo bảng giá đất: {{Vị trí theo bảng giá đất}}",
          "Giá đất G0: {{Giá đất G0}} · Giá trị đất: {{Giá trị đất}}",
        ],
      },
      {
        heading: "2. Định giá nhà và công trình",
        lines: [
          "Kết cấu: {{Kết cấu nhà}} · Số tầng: {{Số tầng}} · Diện tích xây dựng: {{Diện tích XD}} m2",
          "Giá trị 1 m2 nhà: {{Giá trị m2 nhà}} · Giá trị nhà: {{Giá trị nhà}} (làm tròn {{Giá trị nhà làm tròn số}})",
        ],
      },
      {
        heading: "3. Kết luận",
        lines: [
          "Danh mục tài sản được định giá và kết quả từng tài sản:",
          "{{#danhSachTaiSan}}{{/danhSachTaiSan}}",
          "Tổng giá trị tài sản: {{Tổng giá trị TS}} ({{TGTTS bằng chữ}})",
          "Mức nhận bảo đảm cho khoản vay: {{NVĐB cho KV}} ({{NVĐB cho KV bằng chữ}})",
          "Cán bộ thẩm định: {{Người thẩm định}} · Người duyệt: {{Người duyệt}} ({{Chức vụ người duyệt}})",
        ],
      },
    ],
  },
];

export interface RenderedLine {
  text: string;
  missing: string[];
  /** PHIÊN 9 — dòng khai báo VỊ TRÍ của một bảng lặp trong mẫu. */
  tableKey?: string;
}

/**
 * PHIÊN 9 — cú pháp khai báo vị trí bảng lặp trong mẫu:
 *   {{#danhSachTaiSan}}{{/danhSachTaiSan}}
 * Tên tập hợp chính là khoá trong TABLE_META (một điểm sự thật duy nhất).
 * Nhãn dạng #/ KHÔNG bị tính là chỗ trống nên chỉ số "nhãn chết" không đổi.
 */
export const TABLE_ANCHOR_RE = /^\{\{#([A-Za-z0-9_]+)\}\}\{\{\/\1\}\}$/;

export function tableAnchorOf(line: string): string | undefined {
  return TABLE_ANCHOR_RE.exec(line.trim())?.[1];
}

/**
 * PHIÊN 10 — danh sách bảng lặp mà MỘT mẫu tự khai báo vị trí.
 * Dùng cho giao diện và cho test "mọi mẫu đều khai báo vị trí bảng".
 */
export function templateTableAnchors(template: DocTemplate): string[] {
  return [
    ...new Set(
      template.blocks.flatMap((b) => b.lines.map((l) => tableAnchorOf(l)).filter((k): k is string => !!k)),
    ),
  ];
}

/** Điền một dòng mẫu; nhãn không tìm thấy hoặc trống được liệt kê ở missing. */
export function renderLine(line: string, hoSo: HoSo): RenderedLine {
  const anchor = tableAnchorOf(line);
  if (anchor)
    return { text: `[Vị trí bảng «${anchor}» — bảng thật sẽ được in đúng chỗ này trong tệp DOCX]`, missing: [], tableKey: anchor };
  const missing: string[] = [];
  const text = line.replace(/\{\{([^}]+)\}\}/g, (_m, rawLabel: string) => {
    const label = rawLabel.trim();
    const key = findKeyByLabel(label);
    const meta = FIELD_META.find((f) => f.key === key);
    const value = key ? hoSo[key] : undefined;
    if (!meta || value === undefined || String(value).trim() === "") {
      missing.push(label);
      return `[${label}]`;
    }
    return formatValue(value, meta.kind);
  });
  return { text, missing };
}

export function renderTemplate(template: DocTemplate, hoSo: HoSo) {
  const blocks = template.blocks.map((b) => ({
    heading: b.heading,
    lines: b.lines.map((l) => renderLine(l, hoSo)),
  }));
  const missing = [...new Set(blocks.flatMap((b) => b.lines.flatMap((l) => l.missing)))];
  const placeholders = template.blocks
    .flatMap((b) => b.lines.filter((l) => !tableAnchorOf(l)).flatMap((l) => [...l.matchAll(/\{\{([^}]+)\}\}/g)].map((m) => m[1]!.trim())))
    .length;
  return { blocks, missing, placeholders };
}


/** Mọi nhãn {{...}} xuất hiện trong một mẫu. */
export function templateLabels(t: DocTemplate): string[] {
  return [
    ...new Set(
      t.blocks.flatMap((b) =>
        b.lines
          .filter((l) => !tableAnchorOf(l))
          .flatMap((l) => [...l.matchAll(/\{\{([^}]+)\}\}/g)].map((m) => m[1]!.trim())),
      ),
    ),
  ];
}

/**
 * PHIÊN 8 — chống nhãn "chết": nhãn có trong mẫu nhưng KHÔNG có trong FIELD_META.
 * Test tự động yêu cầu danh sách này luôn rỗng cho toàn bộ mẫu.
 */
export function deadLabels(templates: readonly DocTemplate[] = TEMPLATES) {
  return templates.map((t) => ({
    id: t.id,
    name: t.name,
    labels: templateLabels(t).filter((l) => !findKeyByLabel(l)),
  }));
}

export const TEMPLATE_LABEL_COUNT = TEMPLATES.reduce((s, t) => s + templateLabels(t).length, 0);
