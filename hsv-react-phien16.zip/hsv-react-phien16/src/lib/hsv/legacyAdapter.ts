/**
 * Lớp Adapter GĐ 1 — CHỈ ĐỌC.
 * Đọc dữ liệu hồ sơ do HSV cũ (v25.x) ghi trong localStorage / IndexedDB
 * và chuẩn hoá về FIELD_META. Tuyệt đối không ghi, không xoá, không migrate.
 */
import { FIELD_META, type HoSo } from "./fieldMeta";

export const LEGACY_KEY_PREFIXES = ["hsv:hoso:", "hsv_master_KH", "pa_sxkd_v12", "hsv_a4v2_model"];
export const LEGACY_IDB = { name: "QLTDProDB", stores: ["kv", "snapshots", "meta", "blobs"] };

export interface LegacyRecord {
  storageKey: string;
  source: "localStorage" | "indexedDB";
  bytes: number;
  hoSo: HoSo;
  rawKeys: string[];
}

export interface AdapterReport {
  available: boolean;
  scannedKeys: number;
  matchedKeys: number;
  records: LegacyRecord[];
  idbStores: string[];
  warnings: string[];
}

function pick(raw: Record<string, unknown>): HoSo {
  const out: HoSo = {};
  for (const f of FIELD_META) {
    const candidates = [f.key, ...(f.legacyKeys ?? [])];
    for (const c of candidates) {
      const v = raw[c];
      if (v !== undefined && v !== null && v !== "") {
        out[f.key] = typeof v === "object" ? JSON.stringify(v) : (v as string | number);
        break;
      }
    }
  }
  return out;
}

function flatten(value: unknown, depth = 0): Record<string, unknown> {
  if (!value || typeof value !== "object" || depth > 3) return {};
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
    if (v && typeof v === "object") Object.assign(out, flatten(v, depth + 1));
    else out[k] = v;
  }
  return out;
}

async function readIdbStores(): Promise<{ stores: string[]; warning?: string }> {
  if (typeof indexedDB === "undefined") return { stores: [] };
  try {
    const dbs = (await indexedDB.databases?.()) ?? [];
    return { stores: dbs.map((d) => d.name ?? "?").filter(Boolean) };
  } catch {
    return { stores: [], warning: "Trình duyệt không cho liệt kê IndexedDB (chỉ ảnh hưởng hiển thị)." };
  }
}

/** Quét dữ liệu hệ cũ. An toàn khi không có dữ liệu: trả về báo cáo rỗng. */
export async function scanLegacyData(): Promise<AdapterReport> {
  const warnings: string[] = [];
  const records: LegacyRecord[] = [];
  let scannedKeys = 0;

  if (typeof window !== "undefined" && window.localStorage) {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key) continue;
      scannedKeys++;
      if (!LEGACY_KEY_PREFIXES.some((p) => key.startsWith(p))) continue;
      const raw = localStorage.getItem(key) ?? "";
      let parsed: unknown;
      try {
        parsed = JSON.parse(raw);
      } catch {
        warnings.push(`Khoá ${key} không phải JSON — bỏ qua (không sửa dữ liệu gốc).`);
        continue;
      }
      const flat = flatten(parsed);
      records.push({
        storageKey: key,
        source: "localStorage",
        bytes: raw.length,
        hoSo: pick(flat),
        rawKeys: Object.keys(flat).slice(0, 40),
      });
    }
  }

  const { stores, warning } = await readIdbStores();
  if (warning) warnings.push(warning);

  return {
    available: records.length > 0,
    scannedKeys,
    matchedKeys: records.length,
    records,
    idbStores: stores,
    warnings,
  };
}

/** Hồ sơ mẫu dùng khi máy chưa có dữ liệu hệ cũ (chỉ để trình diễn giao diện). */
export const demoHoSo: HoSo = {
  soHoSo: 1247,
  maKhachHang: "KH-3201205166",
  taiKhoanThanhToan: "3201205166260 mở tại Agribank",
  tenKhachHang: "Nguyễn Văn Trường",
  tenKhachHangInHoa: "NGUYỄN VĂN TRƯỜNG",
  xungHo: "Ông",
  gioiTinh: "Nam",
  loaiCmnd: "CCCD",
  cccd: "036xxxxxxxxx do Cục CS QLHC về TTXH cấp ngày 15/05/2021",
  namSinh: "1979",
  diaChi: "Xã Nam Vân, TP Nam Định",
  diaChiHoKhau: "Xã Nam Vân, TP Nam Định",
  soDienThoai: "091xxxxxxx",
  ngheNghiep: "Kinh doanh vật tư nông nghiệp",
  dangKyKinhDoanhSo: "36A8xxxxxx do UBND TP Nam Định cấp",
  diaChiKinhDoanh: "Chợ Nam Vân, TP Nam Định",
  nguoiThuaKe: "Trần Thị Hoa",
  nguoiThuaKeVietHoa: "TRẦN THỊ HOA",
  xungHoNguoiThuaKe: "Bà",
  quanHeNguoiThuaKe: "Vợ",
  loaiCmtNguoiThuaKe: "CCCD",
  cmtNguoiThuaKe: "036xxxxxxxxx",
  namSinhNguoiThuaKe: "1982",
  diaChiNguoiThuaKe: "Xã Nam Vân, TP Nam Định",
  hoKhauNguoiThuaKe: "Xã Nam Vân, TP Nam Định",
  benVay: "Ông Nguyễn Văn Trường và bà Trần Thị Hoa",
  theLoaiVay: "Hạn mức tín dụng",
  // PHIÊN 11 — hồ sơ mẫu phải NHẤT QUÁN với kiểm tra chéo: số tiền vay ≤ tổng
  // nhu cầu vốn suy ra từ bảng chi phí vật tư (152.000.000 đ).
  soTienVay: 120000000,
  soTienVayBangChu: "Một trăm hai mươi triệu đồng",
  hmtdDuyet: 1000000000,
  hmtdDuyetBangChu: "Một tỷ đồng",
  soHopDongTinDung: "01/2026/HĐTD-HM",
  ngayHopDongTinDung: "20/08/2026",
  soHopDongTinDungCu: "07/2025/HĐTD-HM",
  ngayHopDongTinDungCu: "18/08/2025",
  duNo: 620000000,
  duNoBangChu: "Sáu trăm hai mươi triệu đồng",
  ngayDenHanHmtd: "19/08/2027",
  mucDich: "Bổ sung vốn kinh doanh vật tư nông nghiệp",
  mucDichCuThe: "Mua phân bón, thuốc bảo vệ thực vật phục vụ vụ mùa 2026",
  laiSuat: 8.5,
  laiSuatDieuChinh: 9.2,
  laiSuatTietKiem: 5.6,
  bienDoLaiTienVay: 3.6,
  thoiHan: 36,
  thuNhapNamTruoc: 640000000,
  chamDiem1: "AA - 92 điểm (kỳ 06/2026)",
  chamDiem2: "AA - 90 điểm (kỳ 12/2025)",
  xepHang: "Nhóm 1 - đủ tiêu chuẩn",
  phuongThucThanhToan: "Chuyển khoản vào tài khoản người thụ hưởng",
  thongTinCic1: "Không có nợ xấu trong 24 tháng gần nhất",
  thongTinCic2: "Tổng dư nợ tại các TCTD khác: 0 đồng",

  // --- Phiên 3: dữ liệu mẫu nhóm TSBĐ (81 trường) ---
  maKhachHangChuTaiSan: "KH-3201205166",
  chuTaiSan: "Nguyễn Văn Trường",
  chuTaiSanVietHoa: "NGUYỄN VĂN TRƯỜNG",
  xungHoChuTaiSan: "Ông",
  cmtChuTaiSan: "036xxxxxxxxx",
  loaiCmtChuTaiSan: "CCCD",
  namSinhChuTaiSan: "1979",
  diaChiChuTaiSan: "Xã Nam Vân, TP Nam Định",
  diaChiHoKhauChuTaiSan: "Xã Nam Vân, TP Nam Định",
  nguoiThuaKeChuTaiSan: "Người thừa kế chủ tài sản (mẫu)",
  nguoiThuaKeChuTaiSanVietHoa: "Người thừa kế chủ tài sản viết hoa (mẫu)",
  xungHoThuaKeChuTaiSan: "Xưng hô thừa kế chủ tài sản (mẫu)",
  quanHeThuaKeChuTaiSan: "Quan hệ thừa kế chủ tài sản (mẫu)",
  cmtThuaKeChuTaiSan: "CMT thừa kế chủ tài sản (mẫu)",
  diaChiThuaKeChuTaiSan: "Địa chỉ thừa kế chủ tài sản (mẫu)",
  hoKhauThuaKeChuTaiSan: "Hộ khẩu thừa kế chủ tài sản (mẫu)",
  loaiCmtThuaKeChuTaiSan: "Loại CMT thừa kế chủ tài sản (mẫu)",
  namSinhThuaKeChuTaiSan: "20/08/2026",
  benTheChap: "Bên thế chấp (mẫu)",
  benTheChapInHoa: "Bên thế chấp in hoa (mẫu)",
  tenTsdb: "Tên TSĐB (mẫu)",
  soBiaDo: "CS 06xxxx",
  diaChiDat: "Thửa 121, tờ bản đồ 07, xã Nam Vân, TP Nam Định",
  dacDiemNhaTrenBia: "Đặc điểm nhà trên bìa (mẫu)",
  dienTichDat: 250,
  dtdBangChu: "Hai trăm năm mươi mét vuông",
  soThua: 121,
  loaiDat: "Đất ở tại đô thị",
  datO: 1,
  tenLoaiDatKhac: "Tên loại đất khác (mẫu)",
  dtDatOTaiDoThi: 1,
  suDungRieng: 1,
  suDungChung: 1,
  dienTichSan: 1,
  nguonGoc: "Nhận chuyển nhượng năm 2016",
  thoiHanSuDung: "Lâu dài",
  hanCheVeQuyenSuDungDat: "Hạn chế về quyền sử dụng đất (mẫu)",
  khaiQuatVeLoiThe: "Khái quát về lợi thế (mẫu)",
  dacDiemNha: "Đặc điểm nhà (mẫu)",
  ketCauNha: "Bê tông cốt thép",
  soTang: "2 tầng",
  viTriTheoBangGiaDat: "Vị trí theo bảng giá đất (mẫu)",
  soBbdg: "Số BBĐG (mẫu)",
  ngayBbdg: "Ngày BBĐG (mẫu)",
  dienTichXd: 1,
  dienTichSd: 1,
  giaDatG0: "Giá đất G0 (mẫu)",
  dienTichDat1: 1,
  noiDungDienTichDat1: "Nội dung Diện tích đất 1 (mẫu)",
  giaTriDat1: 1650000000,
  tongGiaTriDat1: 1650000000,
  dienTichDat2: 1,
  noiDungDienTichDat2: "Nội dung Diện tích đất 2 (mẫu)",
  giaTriDat2: 1650000000,
  tongGiaTriDat2: 1650000000,
  dienTichDat3: 1,
  noiDungDienTichDat3: "Nội dung Diện tích đất 3 (mẫu)",
  giaTriDat3: 1650000000,
  tongGiaTriDat3: 1650000000,
  giaTriDat: 1650000000,
  giaTriM2Nha: 1650000000,
  giaTriNha: 1650000000,
  giaTriNhaLamTronSo: 1650000000,
  tongGiaTriTs: 1650000000,
  tgttsBangChu: "TGTTS bằng chữ (mẫu)",
  nvdbChoKv: 1650000000,
  nvdbChoKvBangChu: "NVĐB cho KV bằng chữ (mẫu)",
  nghiaVuBaoDam: 1650000000,
  nvbdBangChu: "NVBĐ bằng chữ (mẫu)",
  gtcvGtts: 1,
  giaTriQuyenSuDungDat: 1650000000,
  giaTriQuyenSuDungDatBangChu: "Giá trị quyền sử dụng đất bằng chữ (mẫu)",
  soHdTheChap: "Số HĐ thế chấp (mẫu)",
  ngayKyHdtc: "20/08/2026",
  soVbSuaDoiBoSung: "Số VB sửa đổi bổ sung (mẫu)",
  soTieuDeVbsdMoi: "Số tiêu đề VBSĐ mới (mẫu)",
  soHdtcCu: "Số HĐTC cũ (mẫu)",
  ngayKyHdtcCu: "Ngày ký HĐTC cũ (mẫu)",
  loaiHdtc: "Loại HĐTC (mẫu)",
  giaTriDbts: 1650000000,
  soLcpHdtc: "Số LCP HĐTC (mẫu)",
  // --- Phiên 4: dữ liệu mẫu nhóm PA SXKD (76 trường) ---
  vongQuay: 12,
  tongNhuCauVon: 1200000000,
  vonTuCo: 1200000000,
  tongNhuCauVonTongThe: 1200000000,
  nhuCauVonBcdxgn: 1200000000,
  nguonThuTuHoatDongKinhDoanhChinh: 1200000000,
  tyLeVonTuCo: 12,
  doanhThuNamTruoc: 1200000000,
  chiPhiNamTruoc: 1200000000,
  loiNhuanNamTruoc: 1200000000,
  hangHoaCacLoai: 1200000000,
  hangHoaCacLoaiBangChu: "Hàng hoá các loại bằng chữ (mẫu)",
  tienMat: 1200000000,
  noPhaiThu: 1200000000,
  noPhaiThuBangChu: "Nợ phải thu bằng chữ (mẫu)",
  noNguoiBan: 1200000000,
  noPhaiTra: 1200000000,
  noPhaiTraBangChu: "Nợ phải trả bằng chữ (mẫu)",
  noKhac1: 1200000000,
  nganHangNk1: "Ngân hàng NK1 (mẫu)",
  noKhac2: 1200000000,
  nganHangNk2: "Ngân hàng NK2 (mẫu)",
  noKhac3: 1200000000,
  nganHangNk3: "Ngân hàng NK3 (mẫu)",
  noKhac: 1200000000,
  noPhaiTra1: 1200000000,
  noPhaiTra1BangChu: "Nợ phải trả 1 bằng chữ (mẫu)",
  noPhaiTraKThamGiaPa: 1200000000,
  noPhaiTraKKhongThamGiaPaBangChu: "Nợ phải trả k không tham gia PA bằng chữ (mẫu)",
  tongCpDuAn: 1200000000,
  cpVatTu: 1200000000,
  soNguoiLaoDongTrucTiep: 12,
  soTien1NhanCong: 1200000000,
  chiPhiNhanCong: 1200000000,
  chiPhiNhanCongCuThe: "Chi phí nhân công cụ thể (mẫu)",
  vonBangSucLaoDong12: 1200000000,
  vonBangTien: 1200000000,
  chiPhiKhac: 1200000000,
  tongDoanhThuTuKinhDoanh: 1200000000,
  loiNhuan: 1200000000,
  soTienLaiVay: 1200000000,
  soTienLaiVayCuThe: "Số tiền lãi vay cụ thể (mẫu)",
  soTienKhauHao: 1200000000,
  thueNopNhaNuoc: 1200000000,
  cpSauKhiTruLaiKhThue: 1200000000,
  nhuCauVon1VongQuay: 12,
  vePhuongDienKyThuat: "Về phương diện kỹ thuật (mẫu)",
  thiTruongDauVao: "Thị trường đầu vào (mẫu)",
  thiTruongDauRa: "Thị trường đầu ra (mẫu)",
  giaiQuyetViecLam: "Giải quyết việc làm (mẫu)",
  taiSanSo1: 1200000000,
  taiSanSo2: 1200000000,
  taiSanSo3: 1200000000,
  taiSanSo4: 1200000000,
  taiSanSo5: 1200000000,
  taiSanSo6: 1200000000,
  taiSanTheChapSauKhiTangThem: 1200000000,
  tongGiaTriTaiSanTheChap: 1200000000,
  taiSanTheChapCu: 1200000000,
  taiSanKhac: 1200000000,
  taiSanKhacCacLoai: 1200000000,
  tongGiaTriTaiSanHienCo: 1200000000,
  chiPhiVatTuDong1: 1200000000,
  chiPhiVatTuDong2: 1200000000,
  chiPhiVatTuDong3: 1200000000,
  chiPhiVatTuDong4: 1200000000,
  chiPhiVatTuDong5: 1200000000,
  chiPhiVatTuDong6: 1200000000,
  chiPhiVatTuDong7: 1200000000,
  chiPhiVatTuDong8: 1200000000,
  chiPhiVatTuDong9: 1200000000,
  chiPhiVatTuDong10: 1200000000,
  chiPhiVatTuDong11: 1200000000,
  chiPhiVatTuDong12: 1200000000,
  chiPhiVatTuDong13: 1200000000,
  chiPhiVatTuDong14: 1200000000,
  // --- Phiên 5: dữ liệu mẫu nhóm Giải ngân (37 trường) ---
  ngayThangNamNhanNo: "Ngày tháng năm nhận nợ (mẫu)",
  ngayNhanNo: "20/08/2026",
  thoiHanTraNoCuoi: "20/08/2026",
  kyHanTraNoGoc: 9,
  tongDoanhThuBcdxgn: 980000000,
  hanMucTinDungToiDa: 980000000,
  hdtd: "HĐTD (mẫu)",
  ngayHdtd: "20/08/2026",
  soVongQuay: 9,
  duNoAgribank: 980000000,
  soTienNhanNoNn: 980000000,
  soTienNhanNoBangChu: "Số tiền nhận nợ bằng chữ (mẫu)",
  nguoiThuHuong: "Người thụ hưởng (mẫu)",
  cccdCanCuoc: "CCCD/Căn cước (mẫu)",
  diaChiNguoiThuHuong: "Địa chỉ người thụ hưởng (mẫu)",
  tkNguoiThuHuong: "TK người thụ hưởng (mẫu)",
  moTaiNganHang: "Mở tại ngân hàng (mẫu)",
  chenhLechThuChiBcdxgn: 980000000,
  tongChiPhiBcdxgn: 980000000,
  tongNcvTheoDungPhuongAn: 980000000,
  sdChoPhuongAnKinhDoanh: 980000000,
  vonDoiUng: 980000000,
  duNoAgribankBangChu: "Dư nợ Agribank bằng chữ (mẫu)",
  chiemTyLe: 9,
  soTienNhanNoNnBangChu: "Số tiền nhận nợ NN bằng chữ (mẫu)",
  soTienSauKhiNn: 980000000,
  soTienSauKhiNnBangChu: "Số tiền sau khi NN bằng chữ (mẫu)",
  laiUocCuaNhanNo: 980000000,
  hangTonKho1: 980000000,
  noPhaiThu1: 980000000,
  noPhaiTra12: 980000000,
  soTienUocCongThemNn: 980000000,
  nguonThuTuHdkdChinh: 980000000,
  loaiCmndNguoiThuHuong: "Loại CMND người thụ hưởng (mẫu)",
  xungHoNguoiThuHuong: "Xưng hô người thụ hưởng (mẫu)",
  cmndNguoiThuHuong: "CMND người thụ hưởng (mẫu)",
  soTkNguoiThuHuong: "Số TK người thụ hưởng (mẫu)",
  // PHIÊN 6
  ngayThangNam: "Ngày tháng năm (mẫu)",
  ngayHoSo: "20/08/2026",
  danhXung: "Danh xưng (mẫu)",
  namSinh2: "Năm sinh (mẫu)",
  tongNhuCauVonBangChu: "Tổng nhu cầu vốn bằng chữ (mẫu)",
  bangChu: "Bằng chữ (mẫu)",
  vonDoiUngBangChu: "Vốn đối ứng bằng chữ (mẫu)",
  tyLeVonDoiUng: 9,
  laiSoTietKiem: "Lãi sổ tiết kiệm (mẫu)",
  hanTraCuoiCung: "Hạn trả cuối cùng (mẫu)",
  ngayGiaoNhan: "Ngày giao/nhận (mẫu)",
  soTk1: "Sổ TK 1 (mẫu)",
  soTk2: "Sổ TK 2 (mẫu)",
  soTk3: "Sổ TK 3 (mẫu)",
  soTk4: "Sổ TK 4 (mẫu)",
  soTk5: "Sổ TK 5 (mẫu)",
  tongSoTk: "Tổng Sổ TK (mẫu)",
  tongTienSoTkBangChu: "Tổng tiền Sổ TK bằng chữ (mẫu)",
  toChucPhatHanh: "Tổ chức phát hành (mẫu)",
  soSeri: "Số seri (mẫu)",
  ngayPhatHanh: "20/08/2026",
  ngayDenHan: "20/08/2026",
  soDu: "Số dư (mẫu)",
  soDuBangChu: "Số dư bằng chữ (mẫu)",
  laiSuat2: "Lãi suất (mẫu)",
  kyHan: "Kỳ hạn (mẫu)",
  tienLai: "Tiền lãi (mẫu)",
  congGocLai: "Cộng gốc + lãi (mẫu)",
  soNgayVay: "Số ngày vay (mẫu)",
  laiVayStk: "Lãi vay STK (mẫu)",
  mucVayToiDa: "Mức vay tối đa (mẫu)",
  ngayGiaoNhan2: "20/08/2026",
  ngayThangNamNn: "20/08/2026",
  ngayBiaHs: "20/08/2026",
  ngayCic: "20/08/2026",
  nguoiQhkhQln: "Người QHKH/QLN (mẫu)",
  nguoiThamDinh: "Người thẩm định (mẫu)",
  nguoiDuyet: "Người duyệt (mẫu)",
  chucVuNguoiDuyet: "Chức vụ người duyệt (mẫu)",
  soUyQuyenTd: "Số ủy quyền TD (mẫu)",
  tenKhachHangVay: "Tên khách hàng vay (mẫu)",
  tenKhachHangVayInHoa: "Tên khách hàng vay in hoa (mẫu)",
  tenKhachHangVayVietHoa: "Tên khách hàng vay viết hoa (mẫu)",
  namVay: "20/08/2026",
  namDenHan: "20/08/2026",
  vonTuCoBangChu: "Vốn tự có bằng chữ (mẫu)",
  soThangDinhKy: "Số tháng định kỳ (mẫu)",
  soKyTraNoGoc: "Số kỳ trả nợ gốc (mẫu)",
  soTienTraGocTraTheoDinhKy: "Số tiền trả gốc trả theo định kỳ (mẫu)",
  ngayTraNoCuoiCung: "20/08/2026",
  nguonThuNhap1: "Nguồn thu nhập 1 (mẫu)",
  soTienThuNhap1: "Số tiền thu nhập 1 (mẫu)",
  nguonThuNhap2: "Nguồn thu nhập 2 (mẫu)",
  soTienThuNhap2: "Số tiền thu nhập 2 (mẫu)",
  nguonThuNhap3: "Nguồn thu nhập 3 (mẫu)",
  soTienThuNhap3: "Số tiền thu nhập 3 (mẫu)",
  tongNguonThuNhap: "Tổng nguồn thu nhập (mẫu)",
  tongNguonThuNhapDinhKy: "Tổng nguồn thu nhập định kỳ (mẫu)",
  tongThuNhapNam: "Tổng thu nhập năm (mẫu)",
  soTienTraGocHangQuy: "Số tiền trả gốc hàng quý (mẫu)",
  soTienGocTraHangThang: "Số tiền gốc trả hàng tháng (mẫu)",
  soTienGocTraDinhKy: "Số tiền gốc trả định kỳ (mẫu)",
  soTienLaiTraHangThang: "Số tiền lãi trả hàng tháng (mẫu)",
  soTienLaiTraTheoDinhKy: "Số tiền lãi trả theo định kỳ (mẫu)",
  gocLaiPhaiTraHangThang: "Gốc lãi phải trả hàng tháng (mẫu)",
  chiPhiSinhHoatHangThang: "Chi phí sinh hoạt hàng tháng (mẫu)",
  chiPhiSinhHoatTheoDinhKy: "Chi phí sinh hoạt theo định kỳ (mẫu)",
  soTienGocLaiPhaiTraTheoDinhKy: "Số tiền gốc lãi phải trả theo định kỳ (mẫu)",
  noNguoiBanBangChu: "Nợ người bán bằng chữ (mẫu)",
  tenTsbd: "Tên TSBĐ (mẫu)",
  giaTriChoVayGiaTriTs: "Giá trị cho vay / Giá trị TS (mẫu)",
  soHdtcChuyenHm: "Số HĐTC (chuyển HM) (mẫu)",
  ngayKyHdtcChuyenHm: "20/08/2026",
  // --- Phiên 12B: ký/duyệt nội bộ (người lập – người kiểm soát – người duyệt) ---
  nguoiLap: "Nguyễn Thị Lan",
  chucVuNguoiLap: "Cán bộ tín dụng",
  nguoiKiemSoat: "Trần Quang Huy",
  chucVuNguoiKiemSoat: "Trưởng phòng KHKD",
  nguoiPheDuyet: "Phạm Văn Sơn",
  chucVuNguoiPheDuyet: "Phó Giám đốc chi nhánh",
  noiKyDuyet: "Nam Định",
  ngayKyDuyet: "20/08/2026",
};
