/**
 * PHIÊN 10 (PHẦN 2 — 10B) — BẢN NHÁP HỒ SƠ NHẬP TAY.
 *
 * Cán bộ nhập trực tiếp hồ sơ trên /xem-truoc thay cho hồ sơ mẫu cứng.
 * Danh sách ô nhập SINH TỪ FIELD_META (không gõ tay từng ô trong giao diện),
 * bản nháp giữ trong bộ nhớ PHIÊN của trình duyệt, và các trường suy ra từ
 * bảng lặp là CHỈ ĐỌC để giữ đúng chủ trương "một nguồn số".
 *
 * Vẫn CHỈ ĐỌC với hệ cũ: không ghi/xoá dữ liệu hệ cũ.
 */
import { DERIVED_RULES } from "./derived";
import { FIELD_META, type FieldMeta, type HoSo } from "./fieldMeta";
import { demoHoSo } from "./legacyAdapter";
import { findTable } from "./tableMeta";

export const HOSO_STORAGE_KEY = "hsv.hoSo.v1";

/** Nhóm trường được sinh thành form nhập liệu ở phiên này. */
/** PHIÊN 11 — mở rộng form sang nhóm Phương án SXKD và Giải ngân. */
export const FORM_GROUPS: readonly FieldMeta["group"][] = [
  "khach-hang",
  "khoan-vay",
  "pa-sxkd",
  "giai-ngan",
  // PHIÊN 12B — nhóm ký/duyệt nội bộ cũng là ô nhập sinh từ FIELD_META.
  "ky-duyet",
];

export const GROUP_LABEL: Record<FieldMeta["group"], string> = {
  "khach-hang": "Khách hàng",
  "khoan-vay": "Khoản vay",
  tsbd: "Tài sản bảo đảm",
  "pa-sxkd": "Phương án SXKD",
  "giai-ngan": "Giải ngân",
  "ky-duyet": "Ký/duyệt nội bộ",
};


/** Trường suy ra từ bảng lặp ⇒ chỉ đọc trên form, kèm ghi chú nguồn. */
export const DERIVED_FIELD_SOURCE: Readonly<Record<string, string>> = Object.fromEntries(
  DERIVED_RULES.flatMap((r) => {
    const label = findTable(r.tableKey)?.label ?? r.tableKey;
    const keys = [r.totalField, ...(r.wordsField ? [r.wordsField] : [])];
    return keys.map((k) => [k, label]);
  }),
);

export function isDerivedField(key: string): boolean {
  return key in DERIVED_FIELD_SOURCE;
}

/** Các ô nhập của form, sinh từ đúng khai báo FIELD_META. */
export function formFields(): FieldMeta[] {
  return FIELD_META.filter((f) => FORM_GROUPS.includes(f.group));
}

/** Các trường suy ra (chỉ đọc) — hiển thị cuối form kèm ghi chú nguồn. */
export function derivedFields(): FieldMeta[] {
  return FIELD_META.filter((f) => isDerivedField(f.key));
}

export function fieldsOfGroup(group: FieldMeta["group"]): FieldMeta[] {
  // Trường suy ra hiển thị riêng ở khối "chỉ đọc" ⇒ không lặp lại trong nhóm.
  return formFields().filter((f) => f.group === group && !isDerivedField(f.key));
}

/** Hồ sơ khởi tạo cho form = hồ sơ mẫu (cán bộ sửa đè lên). */
export function initialHoSo(): HoSo {
  return { ...demoHoSo };
}

/** Hồ sơ kiểm chứng: xoá 3 trường bắt buộc để chứng minh cơ chế chặn xuất. */
export function makeThieuBatBuoc(base: HoSo = demoHoSo): HoSo {
  const out: HoSo = { ...base };
  FIELD_META.filter((f) => f.required)
    .slice(0, 3)
    .forEach((f) => {
      out[f.key] = "";
    });
  return out;
}

export function readHoSoDraft(): HoSo | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.sessionStorage.getItem(HOSO_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as HoSo) : null;
  } catch {
    return null;
  }
}

export function writeHoSoDraft(hoSo: HoSo): void {
  try {
    window.sessionStorage.setItem(HOSO_STORAGE_KEY, JSON.stringify(hoSo));
  } catch {
    /* bộ nhớ phiên bị chặn — không ảnh hưởng nhập liệu */
  }
}

export function clearHoSoDraft(): void {
  try {
    window.sessionStorage.removeItem(HOSO_STORAGE_KEY);
  } catch {
    /* bỏ qua */
  }
}
