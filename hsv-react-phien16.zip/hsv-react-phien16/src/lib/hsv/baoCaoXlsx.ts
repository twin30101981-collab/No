/**
 * PHIÊN 15 (PHẦN 4) — BÁO CÁO PHIÊN LÀM VIỆC RA TỆP XLSX.
 *
 * Trưởng phòng đang phải hỏi miệng "hồ sơ nào xong, hồ sơ nào còn thiếu".
 * Ở đây một lần bấm ra tệp .xlsx mở được bằng Excel: danh mục hồ sơ kèm trạng
 * thái, số trường còn thiếu, đã xuất tài liệu hay chưa, thời điểm sửa gần nhất.
 *
 * Tệp XLSX được dựng thủ công (OOXML + JSZip) — không thêm phụ thuộc nặng.
 */
import JSZip from "jszip";
import { blockingIssues } from "./exportGuard";
import { applyDerived } from "./derived";
import type { HoSoItem } from "./hoSoWorkspace";
import { demoRows } from "./repeatableData";

export interface DongBaoCao {
  stt: number;
  ten: string;
  khachHang: string;
  maKhachHang: string;
  soTienVay: string;
  nguon: string;
  trangThai: string;
  soLoiChan: number;
  daXuat: string;
  capNhat: string;
}

function gio(ts?: number): string {
  if (!ts) return "";
  const d = new Date(ts);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

export function dungBaoCao(items: HoSoItem[]): DongBaoCao[] {
  return items.map((i, idx) => {
    const hoSo = applyDerived(i.hoSo, i.tables);
    const chan = blockingIssues(hoSo, demoRows, i.tables, i.thua);
    return {
      stt: idx + 1,
      ten: i.ten,
      khachHang: String(hoSo["tenKhachHang"] ?? ""),
      maKhachHang: String(hoSo["maKhachHang"] ?? ""),
      soTienVay: String(hoSo["soTienVay"] ?? ""),
      nguon: i.nguon,
      trangThai: chan.length === 0 ? "Đủ trường" : `Thiếu ${chan.length}`,
      soLoiChan: chan.length,
      daXuat: i.daXuat ? gio(i.daXuat) : "Chưa xuất",
      capNhat: gio(i.capNhat),
    };
  });
}

const COT = [
  "STT",
  "Tên hồ sơ",
  "Khách hàng",
  "Mã KH",
  "Số tiền vay",
  "Nguồn",
  "Trạng thái",
  "Số lỗi chặn",
  "Đã xuất",
  "Cập nhật",
];

function esc(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function cell(ref: string, v: string | number): string {
  if (typeof v === "number") return `<c r="${ref}"><v>${v}</v></c>`;
  return `<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${esc(v)}</t></is></c>`;
}

const CHU = "ABCDEFGHIJ".split("");

function sheetXml(rows: DongBaoCao[]): string {
  const dsDong: string[] = [];
  dsDong.push(
    `<row r="1">${COT.map((c, i) => cell(`${CHU[i]}1`, c)).join("")}</row>`,
  );
  rows.forEach((r, ri) => {
    const n = ri + 2;
    const v: Array<string | number> = [
      r.stt,
      r.ten,
      r.khachHang,
      r.maKhachHang,
      r.soTienVay,
      r.nguon,
      r.trangThai,
      r.soLoiChan,
      r.daXuat,
      r.capNhat,
    ];
    dsDong.push(`<row r="${n}">${v.map((x, i) => cell(`${CHU[i]}${n}`, x)).join("")}</row>`);
  });
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${dsDong.join("")}</sheetData></worksheet>`;
}

export interface KetQuaBaoCao {
  blob: Blob;
  fileName: string;
  soDong: number;
  soThieu: number;
}

export async function taoBaoCaoXlsx(items: HoSoItem[]): Promise<KetQuaBaoCao> {
  const rows = dungBaoCao(items);
  const zip = new JSZip();
  zip.file(
    "[Content_Types].xml",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`,
  );
  zip.folder("_rels")!.file(
    ".rels",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`,
  );
  const xl = zip.folder("xl")!;
  xl.file(
    "workbook.xml",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Danh muc ho so" sheetId="1" r:id="rId1"/></sheets></workbook>`,
  );
  xl.folder("_rels")!.file(
    "workbook.xml.rels",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`,
  );
  xl.folder("worksheets")!.file("sheet1.xml", sheetXml(rows));

  const blob = await zip.generateAsync({
    type: "blob",
    mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return {
    blob,
    fileName: `BaoCaoPhien_HSV_${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}.xlsx`,
    soDong: rows.length,
    soThieu: rows.filter((r) => r.soLoiChan > 0).length,
  };
}
