/**
 * PHIÊN 13 — LƯU / NẠP BỘ HỒ SƠ RA TỆP `.hsv.json`.
 *
 * Trước: đổi máy hoặc gửi đồng nghiệp soát hộ thì phải gõ lại từ đầu, vì phiên
 * làm việc chỉ nằm trong bộ nhớ trình duyệt.
 * Nay: xuất cả phiên (hoặc từng hồ sơ) ra một tệp `.hsv.json`, mở ở máy khác là
 * có nguyên trạng — và dữ liệu nạp vào đi qua ĐÚNG bộ kiểm tra như nhập tay
 * (FIELD_META + bảng lặp + thửa/giấy tờ), không có đường tắt bỏ qua validate.
 *
 * Hệ cũ vẫn CHỈ ĐỌC: tệp này là định dạng của app React, không đụng hệ cũ.
 */
import type { HoSo } from "./fieldMeta";
import { initialTableRows } from "./repeatableData";
import { demoThua, type ThuaByTaiSan } from "./taiSanChiTiet";
import type { TableRows } from "./tableMeta";
import { NGUON_LABEL, newId, type HoSoItem, type NguonHoSo } from "./hoSoWorkspace";

export const HSV_FILE_VERSION = 1;
export const HSV_FILE_KIND = "hsv.boHoSo";
export const HSV_FILE_EXT = ".hsv.json";

export interface TepBoHoSo {
  kind: typeof HSV_FILE_KIND;
  version: number;
  taoLuc: string;
  donVi: string;
  items: Array<{
    ten: string;
    nguon: NguonHoSo;
    ghiChuNguon?: string;
    hoSo: HoSo;
    tables: TableRows;
    thua: ThuaByTaiSan;
    capNhat: number;
  }>;
}

/** Tên tệp không dấu, không khoảng trắng — an toàn khi gửi qua email/USB. */
function chuoiSach(s: string): string {
  return (
    s
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/đ/gi, "d")
      .replace(/[^a-zA-Z0-9]+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 48) || "ho-so"
  );
}

export function tenTepBoHoSo(items: Array<{ ten: string }>, now = new Date()): string {
  const d = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}`;
  const nhan = items.length === 1 ? chuoiSach(items[0]!.ten) : `${items.length}-ho-so`;
  return `BO-HO-SO_${nhan || "phien"}_${d}${HSV_FILE_EXT}`;
}

export function taoNoiDungTep(items: HoSoItem[], now = new Date()): TepBoHoSo {
  return {
    kind: HSV_FILE_KIND,
    version: HSV_FILE_VERSION,
    taoLuc: now.toISOString(),
    donVi: "Agribank CN Thiên Trường Nam Định — Phòng KHKD",
    items: items.map((i) => ({
      ten: i.ten,
      nguon: i.nguon,
      ...(i.ghiChuNguon ? { ghiChuNguon: i.ghiChuNguon } : {}),
      hoSo: i.hoSo,
      tables: i.tables,
      thua: i.thua,
      capNhat: i.capNhat,
    })),
  };
}

export function taoTepBoHoSo(items: HoSoItem[], now = new Date()) {
  const noiDung = taoNoiDungTep(items, now);
  const blob = new Blob([JSON.stringify(noiDung, null, 2)], {
    type: "application/json;charset=utf-8",
  });
  return { blob, fileName: tenTepBoHoSo(items, now), soHoSo: items.length };
}

export interface KetQuaNap {
  items: HoSoItem[];
  loi: string[];
}

const isObj = (v: unknown): v is Record<string, unknown> =>
  typeof v === "object" && v !== null && !Array.isArray(v);

function docBang(v: unknown): TableRows {
  if (!isObj(v)) return initialTableRows();
  const out: TableRows = {};
  for (const [k, rows] of Object.entries(v)) {
    if (Array.isArray(rows)) out[k] = rows.filter(isObj) as TableRows[string];
  }
  return Object.keys(out).length ? out : initialTableRows();
}

function docThua(v: unknown): ThuaByTaiSan {
  if (!isObj(v)) return demoThua();
  const out: ThuaByTaiSan = {};
  for (const [k, rows] of Object.entries(v)) {
    if (Array.isArray(rows)) out[k] = rows.filter(isObj) as ThuaByTaiSan[string];
  }
  return out;
}

function docHoSo(v: unknown): HoSo {
  if (!isObj(v)) return {};
  const out: HoSo = {};
  for (const [k, val] of Object.entries(v)) {
    if (typeof val === "string" || typeof val === "number") out[k] = val;
  }
  return out;
}

/** Đọc tệp `.hsv.json` — sai định dạng thì báo lỗi rõ ràng, không nạp nửa vời. */
export function docTepBoHoSo(text: string): KetQuaNap {
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    return { items: [], loi: ["Tệp không phải JSON hợp lệ."] };
  }
  if (!isObj(data) || data["kind"] !== HSV_FILE_KIND) {
    return { items: [], loi: [`Không phải tệp bộ hồ sơ HSV (thiếu dấu hiệu "${HSV_FILE_KIND}").`] };
  }
  if (Number(data["version"]) > HSV_FILE_VERSION) {
    return {
      items: [],
      loi: [`Tệp tạo bởi phiên bản mới hơn (v${String(data["version"])}), hãy cập nhật ứng dụng.`],
    };
  }
  const raw = data["items"];
  if (!Array.isArray(raw) || raw.length === 0) {
    return { items: [], loi: ["Tệp không chứa hồ sơ nào."] };
  }

  const loi: string[] = [];
  const items: HoSoItem[] = [];
  raw.forEach((r, idx) => {
    if (!isObj(r)) {
      loi.push(`Hồ sơ thứ ${idx + 1}: cấu trúc không đọc được, đã bỏ qua.`);
      return;
    }
    const hoSo = docHoSo(r["hoSo"]);
    if (Object.keys(hoSo).length === 0) {
      loi.push(`Hồ sơ thứ ${idx + 1}: không có trường dữ liệu nào, đã bỏ qua.`);
      return;
    }
    const nguon = (r["nguon"] as NguonHoSo) in NGUON_LABEL ? (r["nguon"] as NguonHoSo) : "moi";
    items.push({
      id: newId("nap"),
      ten: String(r["ten"] ?? `Hồ sơ nạp ${idx + 1}`).trim() || `Hồ sơ nạp ${idx + 1}`,
      nguon,
      ghiChuNguon: `Nạp từ tệp ${HSV_FILE_EXT}`,
      hoSo,
      tables: docBang(r["tables"]),
      thua: docThua(r["thua"]),
      capNhat: Date.now(),
    });
  });

  if (items.length === 0 && loi.length === 0) loi.push("Không nạp được hồ sơ nào từ tệp.");
  return { items, loi };
}

export function taiTep(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
