/**
 * FIELD_META duy nhất (declarative) — thay thế 5 bản sao findKeyByLabel()
 * trong app.js. Một khai báo sinh ra: ánh xạ nhãn ↔ field, validate (Zod)
 * và kiểu TypeScript.
 */
import { z } from "zod";

export type FieldKind = "text" | "number" | "money" | "date" | "percent";

export interface FieldMeta {
  key: string;
  label: string;
  kind: FieldKind;
  group: "khach-hang" | "khoan-vay" | "tsbd" | "pa-sxkd" | "giai-ngan" | "ky-duyet";
  required?: boolean;
  legacyKeys?: string[];
}

/**
 * PHIÊN 1 — nhóm "khách-hàng" đã mở rộng đủ trường thật, đối chiếu trực tiếp
 * FIELD_META gốc trong public/legacy/app.js (469 trường / 16 nhóm, xem
 * artifacts/legacy-fields.json sinh bởi scripts/extract-legacy-fields.mjs).
 * legacyKeys giữ đúng tên khoá 3 dòng sản phẩm: HM (hạn mức), TD (tiêu dùng), CC (cầm cố).
 */
export const FIELD_META: readonly FieldMeta[] = [
  // --- Định danh hồ sơ / khách hàng (TT Chung) ---
  { key: "soHoSo", label: "Số hồ sơ", kind: "number", group: "khach-hang", legacyKeys: ["Số hồ sơ HM", "soHoSo"] },
  { key: "maKhachHang", label: "Mã khách hàng", kind: "text", group: "khach-hang", legacyKeys: ["Mã khách hàng TD", "Mã khách hàng HM", "Mã khách hàng CC"] },
  { key: "taiKhoanThanhToan", label: "Tài khoản thanh toán", kind: "text", group: "khach-hang", legacyKeys: ["Tài khoản thanh toán HM"] },
  // --- TT Khách hàng (nhân thân người vay) ---
  { key: "tenKhachHang", label: "Tên khách hàng", kind: "text", group: "khach-hang", required: true, legacyKeys: ["Tên khách hàng vay HM", "Tên khách hàng CC", "ten_kh", "tenKH", "hoTen"] },
  { key: "tenKhachHangInHoa", label: "Tên khách hàng in hoa", kind: "text", group: "khach-hang", legacyKeys: ["Tên khách hàng vay in hoa HM", "Tên khách hàng in hoa CC"] },
  { key: "xungHo", label: "Xưng hô", kind: "text", group: "khach-hang", legacyKeys: ["Xưng hô TD", "Xưng hô HM", "Danh xưng CC"] },
  { key: "gioiTinh", label: "Nam/nữ", kind: "text", group: "khach-hang", legacyKeys: ["Nam/nữ TD", "Nam/nữ HM"] },
  { key: "loaiCmnd", label: "Loại CMND", kind: "text", group: "khach-hang", legacyKeys: ["Loại CMND TD", "Loại CMND HM", "Loại CMND CC"] },
  { key: "cccd", label: "CMND", kind: "text", group: "khach-hang", legacyKeys: ["CMND TD", "CMND HM", "CMND CC", "cmnd", "so_cccd"] },
  { key: "namSinh", label: "Năm sinh người vay", kind: "text", group: "khach-hang", legacyKeys: ["Năm sinh người vay TD", "Năm sinh người vay HM", "Năm sinh CC"] },
  { key: "diaChi", label: "Địa chỉ", kind: "text", group: "khach-hang", legacyKeys: ["Địa chỉ TD", "Địa chỉ HM", "Địa chỉ CC", "dia_chi"] },
  { key: "diaChiHoKhau", label: "Địa chỉ theo hộ khẩu", kind: "text", group: "khach-hang", legacyKeys: ["Địa chỉ theo hộ khẩu HM", "Địa chỉ theo hộ khẩu TD"] },
  { key: "soDienThoai", label: "Số điện thoại", kind: "text", group: "khach-hang", legacyKeys: ["Số điện thoại HM", "Số điện thoại CC"] },
  { key: "ngheNghiep", label: "Nghề nghiệp", kind: "text", group: "khach-hang", legacyKeys: ["Nghề nghiệp TD", "Nghề nghiệp HM"] },
  { key: "dangKyKinhDoanhSo", label: "Đăng ký kinh doanh số", kind: "text", group: "khach-hang", legacyKeys: ["Đăng ký kinh doanh số HM"] },
  { key: "diaChiKinhDoanh", label: "Địa chỉ kinh doanh", kind: "text", group: "khach-hang", legacyKeys: ["Địa chỉ kinh doanh TD", "Địa chỉ kinh doanh HM"] },
  // --- Người thừa kế / đồng trách nhiệm ---
  { key: "nguoiThuaKe", label: "Người thừa kế", kind: "text", group: "khach-hang", legacyKeys: ["Người thừa kế TD", "Người thừa kế HM"] },
  { key: "nguoiThuaKeVietHoa", label: "Người thừa kế viết hoa", kind: "text", group: "khach-hang", legacyKeys: ["Người thừa kế viết hoa TD", "Người thừa kế viết hoa HM"] },
  { key: "xungHoNguoiThuaKe", label: "Xưng hô người thừa kế", kind: "text", group: "khach-hang", legacyKeys: ["Xưng hô người thừa kế TD", "Xưng hô người thừa kế HM"] },
  { key: "quanHeNguoiThuaKe", label: "Quan hệ người thừa kế", kind: "text", group: "khach-hang", legacyKeys: ["Quan hệ người thừa kế TD", "Quan hệ người thừa kế HM"] },
  { key: "loaiCmtNguoiThuaKe", label: "Loại CMT người thừa kế", kind: "text", group: "khach-hang", legacyKeys: ["Loại CMT người thừa kế TD", "Loại CMT người thừa kế HM"] },
  { key: "cmtNguoiThuaKe", label: "CMT người thừa kế", kind: "text", group: "khach-hang", legacyKeys: ["CMT người thừa kế TD", "CMT người thừa kế HM"] },
  { key: "namSinhNguoiThuaKe", label: "Năm sinh người thừa kế", kind: "text", group: "khach-hang", legacyKeys: ["Năm sinh người thừa kế TD", "Năm sinh người thừa kế HM"] },
  { key: "diaChiNguoiThuaKe", label: "Địa chỉ người thừa kế", kind: "text", group: "khach-hang", legacyKeys: ["Địa chỉ người thừa kế TD", "Địa chỉ người thừa kế HM"] },
  { key: "hoKhauNguoiThuaKe", label: "Hộ khẩu người thừa kế", kind: "text", group: "khach-hang", legacyKeys: ["Hộ khẩu người thừa kế TD", "Hộ khẩu người thừa kế HM"] },
  // --- PHIÊN 2 — nhóm "khoản vay": 27 trường HMTD · TT Chung · "TT Hợp đồng vay",
  //     lấy nguyên nhãn/kiểu từ artifacts/legacy-fields.json, legacyKeys gồm biến thể TD/CC ---
  { key: "benVay", label: "Bên vay", kind: "text", group: "khoan-vay", legacyKeys: ["Bên vay HM"] },
  { key: "theLoaiVay", label: "Thể loại vay", kind: "text", group: "khoan-vay", legacyKeys: ["Thể loại vay HM", "Thể loại vay TD"] },
  { key: "soTienVay", label: "Số tiền vay", kind: "money", group: "khoan-vay", required: true, legacyKeys: ["Số tiền vay HM", "Số tiền vay TD", "Số tiền vay CC", "so_tien_vay", "soTien"] },
  { key: "soTienVayBangChu", label: "Số tiền vay bằng chữ", kind: "text", group: "khoan-vay", legacyKeys: ["Số tiền vay bằng chữ HM", "Số tiền vay bằng chữ TD"] },
  { key: "hmtdDuyet", label: "HMTD duyệt", kind: "money", group: "khoan-vay", legacyKeys: ["HMTD duyệt HM"] },
  { key: "hmtdDuyetBangChu", label: "HMTD duyệt bằng chữ", kind: "text", group: "khoan-vay", legacyKeys: ["HMTD duyệt bằng chữ HM"] },
  { key: "soHopDongTinDung", label: "Số HĐ tín dụng", kind: "text", group: "khoan-vay", legacyKeys: ["Số HĐ tín dụng HM", "Số HĐ tín dụng TD", "Số HĐ tín dụng CC"] },
  { key: "ngayHopDongTinDung", label: "Ngày HĐ tín dụng", kind: "date", group: "khoan-vay", legacyKeys: ["Ngày HĐ tín dụng HM", "Ngày HĐ tín dụng TD"] },
  { key: "soHopDongTinDungCu", label: "Số HĐ tín dụng cũ", kind: "text", group: "khoan-vay", legacyKeys: ["Số HĐ tín dụng cũ HM"] },
  { key: "ngayHopDongTinDungCu", label: "Ngày HĐ tín dụng cũ", kind: "date", group: "khoan-vay", legacyKeys: ["Ngày HĐ tín dụng cũ HM"] },
  { key: "duNo", label: "Dư nợ", kind: "money", group: "khoan-vay", legacyKeys: ["Dư nợ HM", "Dư nợ TD"] },
  { key: "duNoBangChu", label: "Dư nợ bằng chữ", kind: "text", group: "khoan-vay", legacyKeys: ["Dư nợ bằng chữ HM", "Dư nợ bằng chữ TD"] },
  { key: "ngayDenHanHmtd", label: "Ngày đến hạn HMTD", kind: "date", group: "khoan-vay", legacyKeys: ["Ngày đến hạn HMTD HM"] },
  { key: "mucDich", label: "Mục đích vay", kind: "text", group: "khoan-vay", legacyKeys: ["Mục đích vay HM", "Mục đích vay CC", "muc_dich"] },
  { key: "mucDichCuThe", label: "Mục đích vay cụ thể", kind: "text", group: "khoan-vay", legacyKeys: ["Mục đích vay cu thể HM"] },
  { key: "laiSuat", label: "Lãi suất vay", kind: "number", group: "khoan-vay", legacyKeys: ["Lãi suất vay HM", "Lãi suất vay TD", "Lãi suất vay CC", "lai_suat"] },
  { key: "laiSuatDieuChinh", label: "Lãi suất điều chỉnh", kind: "number", group: "khoan-vay", legacyKeys: ["Lãi suất điều chỉnh HM"] },
  { key: "laiSuatTietKiem", label: "Lãi suất tiết kiệm", kind: "number", group: "khoan-vay", legacyKeys: ["Lãi suất tiết kiệm HM"] },
  { key: "bienDoLaiTienVay", label: "Biên độ lãi tiền vay", kind: "number", group: "khoan-vay", legacyKeys: ["Biên độ lãi tiền vay HM"] },
  { key: "thoiHan", label: "Thời hạn vay", kind: "number", group: "khoan-vay", legacyKeys: ["Thời hạn vay HM", "Thời hạn vay TD", "Thời hạn vay CC", "thoi_han"] },
  { key: "thuNhapNamTruoc", label: "Thu nhập năm trước", kind: "money", group: "khoan-vay", legacyKeys: ["Thu nhập năm trước HM"] },
  { key: "chamDiem1", label: "Chấm điểm1", kind: "text", group: "khoan-vay", legacyKeys: ["Chấm điểm1 HM"] },
  { key: "chamDiem2", label: "Chấm điểm2", kind: "text", group: "khoan-vay", legacyKeys: ["Chấm điểm2 HM"] },
  { key: "xepHang", label: "Xếp hạng", kind: "text", group: "khoan-vay", legacyKeys: ["Xếp hạng HM"] },
  { key: "phuongThucThanhToan", label: "Phương thức thanh toán", kind: "text", group: "khoan-vay", legacyKeys: ["Phương thức thanh toán HM", "Phương thức thanh toán TD"] },
  { key: "thongTinCic1", label: "Thông tin CIC1", kind: "text", group: "khoan-vay", legacyKeys: ["Thông tin CIC1 HM"] },
  { key: "thongTinCic2", label: "Thông tin CIC2", kind: "text", group: "khoan-vay", legacyKeys: ["Thông tin CIC2 HM"] },
  // --- Nhóm PA SXKD: giữ khung GĐ1, mở rộng ở phiên 4 ---

  // --- PHIÊN 3 — nhóm "tsbd": 81 trường HMTD · TT Tài Sản, lấy nguyên nhãn/kiểu
  //     từ artifacts/legacy-fields.json; legacyKeys gồm biến thể TD/CC khi có ---
  { key: "maKhachHangChuTaiSan", label: "Mã khách hàng chủ tài sản", kind: "text", group: "tsbd", legacyKeys: [".ts.Mã khách hàng chủ tài sản HM", ".ts.Mã khách hàng chủ tài sản TD"] },
  { key: "chuTaiSan", label: "Chủ tài sản", kind: "text", group: "tsbd", legacyKeys: [".ts.Chủ tài sản HM", ".ts.Chủ tài sản TD"] },
  { key: "chuTaiSanVietHoa", label: "Chủ tài sản viết hoa", kind: "text", group: "tsbd", legacyKeys: [".ts.Chủ tài sản viết hoa HM", ".ts.Chủ tài sản viết hoa TD"] },
  { key: "xungHoChuTaiSan", label: "Xưng hô chủ tài sản", kind: "text", group: "tsbd", legacyKeys: [".ts.Xưng hô chủ tài sản HM", ".ts.Xưng hô chủ tài sản TD"] },
  { key: "cmtChuTaiSan", label: "CMT chủ tài sản", kind: "text", group: "tsbd", legacyKeys: [".ts.CMT chủ tài sản HM", ".ts.CMT chủ tài sản TD"] },
  { key: "loaiCmtChuTaiSan", label: "Loại CMT chủ tài sản", kind: "text", group: "tsbd", legacyKeys: [".ts.Loại CMT chủ tài sản HM", ".ts.Loại CMT chủ tài sản TD"] },
  { key: "namSinhChuTaiSan", label: "Năm sinh chủ tài sản", kind: "date", group: "tsbd", legacyKeys: [".ts.Năm sinh chủ tài sản HM", ".ts.Năm sinh chủ tài sản TD"] },
  { key: "diaChiChuTaiSan", label: "Địa chỉ chủ tài sản", kind: "text", group: "tsbd", legacyKeys: [".ts.Địa chỉ chủ tài sản HM", ".ts.Địa chỉ chủ tài sản TD"] },
  { key: "diaChiHoKhauChuTaiSan", label: "Địa chỉ hộ khẩu chủ tài sản", kind: "text", group: "tsbd", legacyKeys: [".ts.Địa chỉ hộ khẩu chủ tài sản HM", ".ts.Địa chỉ hộ khẩu chủ tài sản TD"] },
  { key: "nguoiThuaKeChuTaiSan", label: "Người thừa kế chủ tài sản", kind: "text", group: "tsbd", legacyKeys: [".ts.Người thừa kế chủ tài sản HM", ".ts.Người thừa kế chủ tài sản TD"] },
  { key: "nguoiThuaKeChuTaiSanVietHoa", label: "Người thừa kế chủ tài sản viết hoa", kind: "text", group: "tsbd", legacyKeys: [".ts.Người thừa kế chủ tài sản viết hoa HM", ".ts.Người thừa kế chủ tài sản viết hoa TD"] },
  { key: "xungHoThuaKeChuTaiSan", label: "Xưng hô thừa kế chủ tài sản", kind: "text", group: "tsbd", legacyKeys: [".ts.Xưng hô thừa kế chủ tài sản HM", ".ts.Xưng hô thừa kế chủ tài sản TD"] },
  { key: "quanHeThuaKeChuTaiSan", label: "Quan hệ thừa kế chủ tài sản", kind: "text", group: "tsbd", legacyKeys: [".ts.Quan hệ thừa kế chủ tài sản HM", ".ts.Quan hệ thừa kế chủ tài sản TD"] },
  { key: "cmtThuaKeChuTaiSan", label: "CMT thừa kế chủ tài sản", kind: "text", group: "tsbd", legacyKeys: [".ts.CMT thừa kế chủ tài sản HM", ".ts.CMT thừa kế chủ tài sản TD"] },
  { key: "diaChiThuaKeChuTaiSan", label: "Địa chỉ thừa kế chủ tài sản", kind: "text", group: "tsbd", legacyKeys: [".ts.Địa chỉ thừa kế chủ tài sản HM", ".ts.Địa chỉ thừa kế chủ tài sản TD"] },
  { key: "hoKhauThuaKeChuTaiSan", label: "Hộ khẩu thừa kế chủ tài sản", kind: "text", group: "tsbd", legacyKeys: [".ts.Hộ khẩu thừa kế chủ tài sản HM", ".ts.Hộ khẩu thừa kế chủ tài sản TD"] },
  { key: "loaiCmtThuaKeChuTaiSan", label: "Loại CMT thừa kế chủ tài sản", kind: "text", group: "tsbd", legacyKeys: [".ts.Loại CMT thừa kế chủ tài sản HM", ".ts.Loại CMT thừa kế chủ tài sản TD"] },
  { key: "namSinhThuaKeChuTaiSan", label: "Năm sinh thừa kế chủ tài sản", kind: "date", group: "tsbd", legacyKeys: [".ts.Năm sinh thừa kế chủ tài sản HM", ".ts.Năm sinh thừa kế chủ tài sản TD"] },
  { key: "benTheChap", label: "Bên thế chấp", kind: "text", group: "tsbd", legacyKeys: [".ts.Bên thế chấp HM", ".ts.Bên thế chấp TD"] },
  { key: "benTheChapInHoa", label: "Bên thế chấp in hoa", kind: "text", group: "tsbd", legacyKeys: [".ts.Bên thế chấp in hoa HM", ".ts.Bên thế chấp in hoa TD"] },
  { key: "tenTsdb", label: "Tên TSĐB", kind: "text", group: "tsbd", legacyKeys: [".ts.Tên TSĐB HM"] },
  { key: "soBiaDo", label: "Số bìa đỏ", kind: "text", group: "tsbd", legacyKeys: [".ts.Số bìa đỏ HM", ".ts.Số bìa đỏ TD"] },
  { key: "diaChiDat", label: "Địa chỉ đất", kind: "text", group: "tsbd", legacyKeys: [".ts.Địa chỉ đất HM", ".ts.Địa chỉ đất TD"] },
  { key: "dacDiemNhaTrenBia", label: "Đặc điểm nhà trên bìa", kind: "text", group: "tsbd", legacyKeys: [".ts.Đặc điểm nhà trên bìa HM", ".ts.Đặc điểm nhà trên bìa TD"] },
  { key: "dienTichDat", label: "Diện tích đất", kind: "number", group: "tsbd", legacyKeys: [".ts.Diện tích đất HM", ".ts.Diện tích đất TD"] },
  { key: "dtdBangChu", label: "DTĐ bằng chữ", kind: "text", group: "tsbd", legacyKeys: [".ts.DTĐ bằng chữ HM", ".ts.DTĐ bằng chữ TD"] },
  { key: "soThua", label: "Số thửa", kind: "number", group: "tsbd", legacyKeys: [".ts.Số thửa HM", ".ts.Số thửa TD"] },
  { key: "loaiDat", label: "Loại đất", kind: "text", group: "tsbd", legacyKeys: [".ts.Loại đất HM", ".ts.Loại đất TD"] },
  { key: "datO", label: "Đất ở", kind: "number", group: "tsbd", legacyKeys: [".ts.Đất ở HM", ".ts.Đất ở TD"] },
  { key: "tenLoaiDatKhac", label: "Tên loại đất khác", kind: "text", group: "tsbd", legacyKeys: [".ts.Tên loại đất khác HM", ".ts.Tên loại đất khác TD"] },
  { key: "dtDatOTaiDoThi", label: "DT đất ở tại đô thị", kind: "number", group: "tsbd", legacyKeys: [".ts.DT đất ở tại đô thị HM", ".ts.DT đất ở tại đô thị TD"] },
  { key: "suDungRieng", label: "Sử dụng riêng", kind: "number", group: "tsbd", legacyKeys: [".ts.Sử dụng riêng HM", ".ts.Sử dụng riêng TD"] },
  { key: "suDungChung", label: "Sử dụng chung", kind: "number", group: "tsbd", legacyKeys: [".ts.Sử dụng chung HM", ".ts.Sử dụng chung TD"] },
  { key: "dienTichSan", label: "Diện tích sàn", kind: "number", group: "tsbd", legacyKeys: [".ts.Diện tích sàn HM", ".ts.Diện tích sàn TD"] },
  { key: "nguonGoc", label: "Nguồn gốc", kind: "text", group: "tsbd", legacyKeys: [".ts.Nguồn gốc HM", ".ts.Nguồn gốc TD"] },
  { key: "thoiHanSuDung", label: "Thời hạn sử dụng", kind: "text", group: "tsbd", legacyKeys: [".ts.Thời hạn sử dụng HM", ".ts.Thời hạn sử dụng TD"] },
  { key: "hanCheVeQuyenSuDungDat", label: "Hạn chế về quyền sử dụng đất", kind: "text", group: "tsbd", legacyKeys: [".ts.Hạn chế về quyền sử dụng đất HM", ".ts.Hạn chế về quyền sử dụng đất TD"] },
  { key: "khaiQuatVeLoiThe", label: "Khái quát về lợi thế", kind: "text", group: "tsbd", legacyKeys: [".ts.Khái quát về lợi thế HM", ".ts.Khái quát về lợi thế TD"] },
  { key: "dacDiemNha", label: "Đặc điểm nhà", kind: "text", group: "tsbd", legacyKeys: [".ts.Đặc điểm nhà HM", ".ts.Đặc điểm nhà TD"] },
  { key: "ketCauNha", label: "Kết cấu nhà", kind: "text", group: "tsbd", legacyKeys: [".ts.Kết cấu nhà HM", ".ts.Kết cấu nhà TD"] },
  { key: "soTang", label: "Số tầng", kind: "text", group: "tsbd", legacyKeys: [".ts.Số tầng HM", ".ts.Số tầng TD"] },
  { key: "viTriTheoBangGiaDat", label: "Vị trí theo bảng giá đất", kind: "text", group: "tsbd", legacyKeys: [".ts.Vị trí theo bảng giá đất HM", ".ts.Vị trí theo bảng giá đất TD"] },
  { key: "soBbdg", label: "Số BBĐG", kind: "text", group: "tsbd", legacyKeys: [".ts.Số BBĐG HM", ".ts.Số BBĐG TD"] },
  { key: "ngayBbdg", label: "Ngày BBĐG", kind: "text", group: "tsbd", legacyKeys: [".ts.Ngày BBĐG HM", ".ts.Ngày BBĐG TD"] },
  { key: "dienTichXd", label: "Diện tích XD", kind: "number", group: "tsbd", legacyKeys: [".ts.Diện tích XD HM", ".ts.Diện tích XD TD"] },
  { key: "dienTichSd", label: "Diện tích SD", kind: "number", group: "tsbd", legacyKeys: [".ts.Diện tích SD HM", ".ts.Diện tích SD TD"] },
  { key: "giaDatG0", label: "Giá đất G0", kind: "text", group: "tsbd", legacyKeys: [".ts.Giá đất G0 HM", ".ts.Giá đất G0 TD"] },
  { key: "dienTichDat1", label: "Diện tích đất 1", kind: "number", group: "tsbd", legacyKeys: [".ts.Diện tích đất 1 HM", ".ts.Diện tích đất 1 TD"] },
  { key: "noiDungDienTichDat1", label: "Nội dung Diện tích đất 1", kind: "text", group: "tsbd", legacyKeys: [".ts.Nội dung Diện tích đất 1 HM", ".ts.Nội dung Diện tích đất 1 TD"] },
  { key: "giaTriDat1", label: "Giá trị đất 1", kind: "money", group: "tsbd", legacyKeys: [".ts.Giá trị đất 1 HM", ".ts.Giá trị đất 1 TD"] },
  { key: "tongGiaTriDat1", label: "Tổng Giá trị đất 1", kind: "money", group: "tsbd", legacyKeys: [".ts.Tổng Giá trị đất 1 HM", ".ts.Tổng Giá trị đất 1 TD"] },
  { key: "dienTichDat2", label: "Diện tích đất 2", kind: "number", group: "tsbd", legacyKeys: [".ts.Diện tích đất 2 HM", ".ts.Diện tích đất 2 TD"] },
  { key: "noiDungDienTichDat2", label: "Nội dung Diện tích đất 2", kind: "text", group: "tsbd", legacyKeys: [".ts.Nội dung Diện tích đất 2 HM", ".ts.Nội dung Diện tích đất 2 TD"] },
  { key: "giaTriDat2", label: "Giá trị đất 2", kind: "money", group: "tsbd", legacyKeys: [".ts.Giá trị đất 2 HM", ".ts.Giá trị đất 2 TD"] },
  { key: "tongGiaTriDat2", label: "Tổng Giá trị đất 2", kind: "money", group: "tsbd", legacyKeys: [".ts.Tổng Giá trị đất 2 HM", ".ts.Tổng Giá trị đất 2 TD"] },
  { key: "dienTichDat3", label: "Diện tích đất 3", kind: "number", group: "tsbd", legacyKeys: [".ts.Diện tích đất 3 HM", ".ts.Diện tích đất 3 TD"] },
  { key: "noiDungDienTichDat3", label: "Nội dung Diện tích đất 3", kind: "text", group: "tsbd", legacyKeys: [".ts.Nội dung Diện tích đất 3 HM", ".ts.Nội dung Diện tích đất 3 TD"] },
  { key: "giaTriDat3", label: "Giá trị đất 3", kind: "money", group: "tsbd", legacyKeys: [".ts.Giá trị đất 3 HM", ".ts.Giá trị đất 3 TD"] },
  { key: "tongGiaTriDat3", label: "Tổng Giá trị đất 3", kind: "money", group: "tsbd", legacyKeys: [".ts.Tổng Giá trị đất 3 HM", ".ts.Tổng Giá trị đất 3 TD"] },
  { key: "giaTriDat", label: "Giá trị đất", kind: "money", group: "tsbd", legacyKeys: [".ts.Giá trị đất HM", ".ts.Giá trị đất TD"] },
  { key: "giaTriM2Nha", label: "Giá trị m2 nhà", kind: "money", group: "tsbd", legacyKeys: [".ts.Giá trị m2 nhà HM", ".ts.Giá trị m2 nhà TD"] },
  { key: "giaTriNha", label: "Giá trị nhà", kind: "money", group: "tsbd", legacyKeys: [".ts.Giá trị nhà HM", ".ts.Giá trị nhà TD"] },
  { key: "giaTriNhaLamTronSo", label: "Giá trị nhà làm tròn số", kind: "money", group: "tsbd", legacyKeys: [".ts.Giá trị nhà làm tròn số HM", ".ts.Giá trị nhà làm tròn số TD"] },
  { key: "tongGiaTriTs", label: "Tổng giá trị TS", kind: "money", group: "tsbd", legacyKeys: [".ts.Tổng giá trị TS HM", ".ts.Tổng giá trị TS TD"] },
  { key: "tgttsBangChu", label: "TGTTS bằng chữ", kind: "text", group: "tsbd", legacyKeys: [".ts.TGTTS bằng chữ HM", ".ts.TGTTS bằng chữ TD"] },
  { key: "nvdbChoKv", label: "NVĐB cho KV", kind: "money", group: "tsbd", legacyKeys: [".ts.NVĐB cho KV HM", ".ts.NVĐB cho KV TD"] },
  { key: "nvdbChoKvBangChu", label: "NVĐB cho KV bằng chữ", kind: "text", group: "tsbd", legacyKeys: [".ts.NVĐB cho KV bằng chữ HM", ".ts.NVĐB cho KV bằng chữ TD"] },
  { key: "nghiaVuBaoDam", label: "Nghĩa vụ bảo đảm", kind: "money", group: "tsbd", legacyKeys: [".ts.Nghĩa vụ bảo đảm HM", ".ts.Nghĩa vụ bảo đảm TD"] },
  { key: "nvbdBangChu", label: "NVBĐ bằng chữ", kind: "text", group: "tsbd", legacyKeys: [".ts.NVBĐ bằng chữ HM", ".ts.NVBĐ bằng chữ TD"] },
  { key: "gtcvGtts", label: "GTCV / GTTS", kind: "number", group: "tsbd", legacyKeys: [".ts.GTCV / GTTS HM", ".ts.GTCV / GTTS TD"] },
  { key: "giaTriQuyenSuDungDat", label: "Giá trị quyền sử dụng đất", kind: "money", group: "tsbd", legacyKeys: [".ts.Giá trị quyền sử dụng đất HM", ".ts.Giá trị quyền sử dụng đất TD"] },
  { key: "giaTriQuyenSuDungDatBangChu", label: "Giá trị quyền sử dụng đất bằng chữ", kind: "text", group: "tsbd", legacyKeys: [".ts.Giá trị quyền sử dụng đất bằng chữ HM", ".ts.Giá trị quyền sử dụng đất bằng chữ TD"] },
  { key: "soHdTheChap", label: "Số HĐ thế chấp", kind: "text", group: "tsbd", legacyKeys: [".ts.Số HĐ thế chấp HM", ".ts.Số HĐ thế chấp TD"] },
  { key: "ngayKyHdtc", label: "Ngày ký HĐTC", kind: "date", group: "tsbd", legacyKeys: [".ts.Ngày ký HĐTC HM", ".ts.Ngày ký HĐTC TD"] },
  { key: "soVbSuaDoiBoSung", label: "Số VB sửa đổi bổ sung", kind: "text", group: "tsbd", legacyKeys: [".ts.Số VB sửa đổi bổ sung HM"] },
  { key: "soTieuDeVbsdMoi", label: "Số tiêu đề VBSĐ mới", kind: "text", group: "tsbd", legacyKeys: [".ts.Số tiêu đề VBSĐ mới HM"] },
  { key: "soHdtcCu", label: "Số HĐTC cũ", kind: "text", group: "tsbd", legacyKeys: [".ts.Số HĐTC cũ HM"] },
  { key: "ngayKyHdtcCu", label: "Ngày ký HĐTC cũ", kind: "text", group: "tsbd", legacyKeys: [".ts.Ngày ký HĐTC cũ HM"] },
  { key: "loaiHdtc", label: "Loại HĐTC", kind: "text", group: "tsbd", legacyKeys: [".ts.Loại HĐTC HM", ".ts.Loại HĐTC TD"] },
  { key: "giaTriDbts", label: "Giá trị ĐBTS", kind: "money", group: "tsbd", legacyKeys: [".ts.Giá trị ĐBTS HM", ".ts.Giá trị ĐBTS TD"] },
  { key: "soLcpHdtc", label: "Số LCP HĐTC", kind: "text", group: "tsbd", legacyKeys: [".ts.Số LCP HĐTC HM", ".ts.Số LCP HĐTC TD"] },
  // --- PHIÊN 4 — nhóm "pa-sxkd": 76 trường HMTD (TT Phương Án 62 + Chi tiết Chi phí vật tư 14),
  //     lấy nguyên nhãn/kiểu từ artifacts/legacy-fields.json; legacyKeys gồm biến thể TD ---
  { key: "vongQuay", label: "Vòng quay", kind: "number", group: "pa-sxkd", legacyKeys: ["Vòng quay HM"] },
  { key: "tongNhuCauVon", label: "Tổng nhu cầu vốn", kind: "money", group: "pa-sxkd", legacyKeys: ["Tổng nhu cầu vốn CC", "Tổng nhu cầu vốn HM", "Tổng nhu cầu vốn TD"] },
  { key: "vonTuCo", label: "Vốn tự có", kind: "money", group: "pa-sxkd", legacyKeys: ["Vốn tự có HM", "Vốn tự có TD"] },
  { key: "tongNhuCauVonTongThe", label: "Tổng nhu cầu vốn tổng thể", kind: "money", group: "pa-sxkd", legacyKeys: ["Tổng nhu cầu vốn tổng thể HM"] },
  { key: "nhuCauVonBcdxgn", label: "Nhu cầu vốn BCĐXGN", kind: "money", group: "pa-sxkd", legacyKeys: ["Nhu cầu vốn BCĐXGN HM"] },
  { key: "nguonThuTuHoatDongKinhDoanhChinh", label: "Nguồn thu từ hoạt động kinh doanh chính", kind: "money", group: "pa-sxkd", legacyKeys: ["Nguồn thu từ hoạt động kinh doanh chính HM"] },
  { key: "tyLeVonTuCo", label: "Tỷ lệ vốn tự có", kind: "number", group: "pa-sxkd", legacyKeys: ["Tỷ lệ vốn tự có HM", "Tỷ lệ vốn tự có TD"] },
  { key: "doanhThuNamTruoc", label: "Doanh thu năm trước", kind: "money", group: "pa-sxkd", legacyKeys: ["Doanh thu năm trước HM"] },
  { key: "chiPhiNamTruoc", label: "Chi phí năm trước", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí năm trước HM"] },
  { key: "loiNhuanNamTruoc", label: "Lợi nhuận năm trước", kind: "money", group: "pa-sxkd", legacyKeys: ["Lợi nhuận năm trước HM"] },
  { key: "hangHoaCacLoai", label: "Hàng hóa các loại", kind: "money", group: "pa-sxkd", legacyKeys: ["Hàng hóa các loại HM"] },
  { key: "hangHoaCacLoaiBangChu", label: "Hàng hoá các loại bằng chữ", kind: "text", group: "pa-sxkd", legacyKeys: ["Hàng hoá các loại bằng chữ HM"] },
  { key: "tienMat", label: "Tiền mặt", kind: "money", group: "pa-sxkd", legacyKeys: ["Tiền mặt HM"] },
  { key: "noPhaiThu", label: "Nợ phải thu", kind: "money", group: "pa-sxkd", legacyKeys: ["Nợ phải thu HM"] },
  { key: "noPhaiThuBangChu", label: "Nợ phải thu bằng chữ", kind: "text", group: "pa-sxkd", legacyKeys: ["Nợ phải thu bằng chữ HM"] },
  { key: "noNguoiBan", label: "Nợ người bán", kind: "money", group: "pa-sxkd", legacyKeys: ["Nợ người bán HM", "Nợ người bán TD"] },
  { key: "noPhaiTra", label: "Nợ phải trả", kind: "money", group: "pa-sxkd", legacyKeys: ["Nợ phải trả HM", "Nợ phải trả TD"] },
  { key: "noPhaiTraBangChu", label: "Nợ phải trả bằng chữ", kind: "text", group: "pa-sxkd", legacyKeys: ["Nợ phải trả bằng chữ HM", "Nợ phải trả bằng chữ TD"] },
  { key: "noKhac1", label: "Nợ khác 1", kind: "money", group: "pa-sxkd", legacyKeys: ["Nợ khác 1 HM"] },
  { key: "nganHangNk1", label: "Ngân hàng NK1", kind: "text", group: "pa-sxkd", legacyKeys: ["Ngân hàng NK1 HM"] },
  { key: "noKhac2", label: "Nợ khác 2", kind: "money", group: "pa-sxkd", legacyKeys: ["Nợ khác 2 HM"] },
  { key: "nganHangNk2", label: "Ngân hàng NK2", kind: "text", group: "pa-sxkd", legacyKeys: ["Ngân hàng NK2 HM"] },
  { key: "noKhac3", label: "Nợ khác 3", kind: "money", group: "pa-sxkd", legacyKeys: ["Nợ khác 3 HM"] },
  { key: "nganHangNk3", label: "Ngân hàng NK3", kind: "text", group: "pa-sxkd", legacyKeys: ["Ngân hàng NK3 HM"] },
  { key: "noKhac", label: "Nợ khác", kind: "money", group: "pa-sxkd", legacyKeys: ["Nợ khác HM"] },
  { key: "noPhaiTra1", label: "Nợ phải trả 1", kind: "money", group: "pa-sxkd", legacyKeys: ["Nợ phải trả 1 HM"] },
  { key: "noPhaiTra1BangChu", label: "Nợ phải trả 1 bằng chữ", kind: "text", group: "pa-sxkd", legacyKeys: ["Nợ phải trả 1 bằng chữ HM"] },
  { key: "noPhaiTraKThamGiaPa", label: "Nợ phải trả k tham gia PA", kind: "money", group: "pa-sxkd", legacyKeys: ["Nợ phải trả k tham gia PA HM"] },
  { key: "noPhaiTraKKhongThamGiaPaBangChu", label: "Nợ phải trả k không tham gia PA bằng chữ", kind: "text", group: "pa-sxkd", legacyKeys: ["Nợ phải trả k không tham gia PA bằng chữ HM"] },
  { key: "tongCpDuAn", label: "Tổng CP dự án", kind: "money", group: "pa-sxkd", legacyKeys: ["Tổng CP dự án HM"] },
  { key: "cpVatTu", label: "CP vật tư", kind: "money", group: "pa-sxkd", legacyKeys: ["CP vật tư HM"] },
  { key: "soNguoiLaoDongTrucTiep", label: "Số người lao động trực tiếp", kind: "number", group: "pa-sxkd", legacyKeys: ["Số người lao động trực tiếp HM"] },
  { key: "soTien1NhanCong", label: "Số tiền/ 1 nhân công", kind: "money", group: "pa-sxkd", legacyKeys: ["Số tiền/ 1 nhân công HM"] },
  { key: "chiPhiNhanCong", label: "Chi phí nhân công", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí nhân công HM"] },
  { key: "chiPhiNhanCongCuThe", label: "Chi phí nhân công cụ thể", kind: "text", group: "pa-sxkd", legacyKeys: ["Chi phí nhân công cụ thể HM"] },
  { key: "vonBangSucLaoDong12", label: "Vốn bằng sức lao động/1,2", kind: "money", group: "pa-sxkd", legacyKeys: ["Vốn bằng sức lao động/1,2 HM"] },
  { key: "vonBangTien", label: "Vốn bằng tiền", kind: "money", group: "pa-sxkd", legacyKeys: ["Vốn bằng tiền HM"] },
  { key: "chiPhiKhac", label: "Chi phí khác", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí khác HM"] },
  { key: "tongDoanhThuTuKinhDoanh", label: "Tổng doanh thu từ kinh doanh", kind: "money", group: "pa-sxkd", legacyKeys: ["Tổng doanh thu từ kinh doanh HM"] },
  { key: "loiNhuan", label: "Lợi nhuận", kind: "money", group: "pa-sxkd", legacyKeys: ["Lợi nhuận HM"] },
  { key: "soTienLaiVay", label: "Số tiền lãi vay", kind: "money", group: "pa-sxkd", legacyKeys: ["Số tiền lãi vay HM"] },
  { key: "soTienLaiVayCuThe", label: "Số tiền lãi vay cụ thể", kind: "text", group: "pa-sxkd", legacyKeys: ["Số tiền lãi vay cụ thể HM"] },
  { key: "soTienKhauHao", label: "Số tiền khấu hao", kind: "money", group: "pa-sxkd", legacyKeys: ["Số tiền khấu hao HM"] },
  { key: "thueNopNhaNuoc", label: "Thuế nộp nhà nước", kind: "money", group: "pa-sxkd", legacyKeys: ["Thuế nộp nhà nước HM"] },
  { key: "cpSauKhiTruLaiKhThue", label: "CP sau khi trừ lãi, KH, Thuế", kind: "money", group: "pa-sxkd", legacyKeys: ["CP sau khi trừ lãi, KH, Thuế HM"] },
  { key: "nhuCauVon1VongQuay", label: "Nhu cầu vốn 1 vòng quay", kind: "number", group: "pa-sxkd", legacyKeys: ["Nhu cầu vốn 1 vòng quay HM"] },
  { key: "vePhuongDienKyThuat", label: "Về phương diện kỹ thuật", kind: "text", group: "pa-sxkd", legacyKeys: ["Về phương diện kỹ thuật HM"] },
  { key: "thiTruongDauVao", label: "Thị trường đầu vào", kind: "text", group: "pa-sxkd", legacyKeys: ["Thị trường đầu vào HM"] },
  { key: "thiTruongDauRa", label: "Thị trường đầu ra", kind: "text", group: "pa-sxkd", legacyKeys: ["Thị trường đầu ra HM"] },
  { key: "giaiQuyetViecLam", label: "Giải quyết việc làm", kind: "text", group: "pa-sxkd", legacyKeys: ["Giải quyết việc làm HM"] },
  { key: "taiSanSo1", label: "Tài sản số 1", kind: "money", group: "pa-sxkd", legacyKeys: ["Tài sản số 1 HM"] },
  { key: "taiSanSo2", label: "Tài sản số 2", kind: "money", group: "pa-sxkd", legacyKeys: ["Tài sản số 2 HM"] },
  { key: "taiSanSo3", label: "Tài sản số 3", kind: "money", group: "pa-sxkd", legacyKeys: ["Tài sản số 3 HM"] },
  { key: "taiSanSo4", label: "Tài sản số 4", kind: "money", group: "pa-sxkd", legacyKeys: ["Tài sản số 4 HM"] },
  { key: "taiSanSo5", label: "Tài sản số 5", kind: "money", group: "pa-sxkd", legacyKeys: ["Tài sản số 5 HM"] },
  { key: "taiSanSo6", label: "Tài sản số 6", kind: "money", group: "pa-sxkd", legacyKeys: ["Tài sản số 6 HM"] },
  { key: "taiSanTheChapSauKhiTangThem", label: "Tài sản thế chấp sau khi tăng thêm", kind: "money", group: "pa-sxkd", legacyKeys: ["Tài sản thế chấp sau khi tăng thêm HM"] },
  { key: "tongGiaTriTaiSanTheChap", label: "Tổng giá trị tài sản thế chấp", kind: "money", group: "pa-sxkd", legacyKeys: ["Tổng giá trị tài sản thế chấp HM"] },
  { key: "taiSanTheChapCu", label: "Tài sản thế chấp cũ", kind: "money", group: "pa-sxkd", legacyKeys: ["Tài sản thế chấp cũ HM"] },
  { key: "taiSanKhac", label: "Tài sản khác", kind: "money", group: "pa-sxkd", legacyKeys: ["Tài sản khác HM"] },
  { key: "taiSanKhacCacLoai", label: "Tài sản khác các loại", kind: "money", group: "pa-sxkd", legacyKeys: ["Tài sản khác các loại HM"] },
  { key: "tongGiaTriTaiSanHienCo", label: "Tổng giá trị tài sản hiện có", kind: "money", group: "pa-sxkd", legacyKeys: ["Tổng giá trị tài sản hiện có HM"] },
  { key: "chiPhiVatTuDong1", label: "Chi phí vật tư dòng 1", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí vật tư 1 HM"] },
  { key: "chiPhiVatTuDong2", label: "Chi phí vật tư dòng 2", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí vật tư 2 HM"] },
  { key: "chiPhiVatTuDong3", label: "Chi phí vật tư dòng 3", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí vật tư 3 HM"] },
  { key: "chiPhiVatTuDong4", label: "Chi phí vật tư dòng 4", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí vật tư 4 HM"] },
  { key: "chiPhiVatTuDong5", label: "Chi phí vật tư dòng 5", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí vật tư 5 HM"] },
  { key: "chiPhiVatTuDong6", label: "Chi phí vật tư dòng 6", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí vật tư 6 HM"] },
  { key: "chiPhiVatTuDong7", label: "Chi phí vật tư dòng 7", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí vật tư 7 HM"] },
  { key: "chiPhiVatTuDong8", label: "Chi phí vật tư dòng 8", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí vật tư 8 HM"] },
  { key: "chiPhiVatTuDong9", label: "Chi phí vật tư dòng 9", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí vật tư 9 HM"] },
  { key: "chiPhiVatTuDong10", label: "Chi phí vật tư dòng 10", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí vật tư 10 HM"] },
  { key: "chiPhiVatTuDong11", label: "Chi phí vật tư dòng 11", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí vật tư 11 HM"] },
  { key: "chiPhiVatTuDong12", label: "Chi phí vật tư dòng 12", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí vật tư 12 HM"] },
  { key: "chiPhiVatTuDong13", label: "Chi phí vật tư dòng 13", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí vật tư 13 HM"] },
  { key: "chiPhiVatTuDong14", label: "Chi phí vật tư dòng 14", kind: "money", group: "pa-sxkd", legacyKeys: ["Chi phí vật tư 14 HM"] },
  // --- PHIÊN 5 — nhóm "giai-ngan": 33 trường HMTD · Giải Ngân + 4 trường TIEU_DUNG · Giải Ngân
  //     (2 nhãn trùng được hợp nhất vào khoá HM bằng legacyKeys). TT Xếp hạng (3 trường) đã có từ Phiên 2. ---
  { key: "ngayThangNamNhanNo", label: "Ngày tháng năm nhận nợ", kind: "text", group: "giai-ngan", legacyKeys: ["Ngày tháng năm nhận nợ HM"] },
  { key: "ngayNhanNo", label: "Ngày nhận nợ", kind: "date", group: "giai-ngan", legacyKeys: ["Ngày nhận nợ HM"] },
  { key: "thoiHanTraNoCuoi", label: "Thời hạn trả nợ cuối", kind: "date", group: "giai-ngan", legacyKeys: ["Thời hạn trả nợ cuối HM"] },
  { key: "kyHanTraNoGoc", label: "Kỳ hạn trả nợ gốc", kind: "number", group: "giai-ngan", legacyKeys: ["Kỳ hạn trả nợ gốc HM"] },
  { key: "tongDoanhThuBcdxgn", label: "Tổng doanh thu BCĐXGN", kind: "money", group: "giai-ngan", legacyKeys: ["Tổng doanh thu BCĐXGN HM"] },
  { key: "hanMucTinDungToiDa", label: "Hạn mức tín dụng tối đa", kind: "money", group: "giai-ngan", legacyKeys: ["Hạn mức tín dụng tối đa HM"] },
  { key: "hdtd", label: "HĐTD", kind: "text", group: "giai-ngan", legacyKeys: ["HĐTD HM"] },
  { key: "ngayHdtd", label: "Ngày HĐTD", kind: "date", group: "giai-ngan", legacyKeys: ["Ngày HĐTD CC", "Ngày HĐTD HM"] },
  { key: "soVongQuay", label: "Số vòng quay", kind: "number", group: "giai-ngan", legacyKeys: ["Số vòng quay HM"] },
  { key: "duNoAgribank", label: "Dư nợ Agribank", kind: "money", group: "giai-ngan", legacyKeys: ["Dư nợ Agribank HM"] },
  { key: "soTienNhanNoNn", label: "Số tiền nhận nợ NN", kind: "money", group: "giai-ngan", legacyKeys: ["Số tiền nhận nợ NN HM"] },
  { key: "soTienNhanNoBangChu", label: "Số tiền nhận nợ bằng chữ", kind: "text", group: "giai-ngan", legacyKeys: ["Số tiền nhận nợ bằng chữ HM"] },
  { key: "nguoiThuHuong", label: "Người thụ hưởng", kind: "text", group: "giai-ngan", legacyKeys: ["Người thụ hưởng CC", "Người thụ hưởng HM", "Người thụ hưởng TD"] },
  { key: "cccdCanCuoc", label: "CCCD/Căn cước", kind: "text", group: "giai-ngan", legacyKeys: ["CCCD/Căn cước HM"] },
  { key: "diaChiNguoiThuHuong", label: "Địa chỉ người thụ hưởng", kind: "text", group: "giai-ngan", legacyKeys: ["Địa chỉ người thụ hưởng CC", "Địa chỉ người thụ hưởng HM", "Địa chỉ người thụ hưởng TD"] },
  { key: "tkNguoiThuHuong", label: "TK người thụ hưởng", kind: "text", group: "giai-ngan", legacyKeys: ["TK người thụ hưởng HM"] },
  { key: "moTaiNganHang", label: "Mở tại ngân hàng", kind: "text", group: "giai-ngan", legacyKeys: ["Mở tại ngân hàng HM"] },
  { key: "chenhLechThuChiBcdxgn", label: "Chênh lệch thu chi BCĐXGN", kind: "money", group: "giai-ngan", legacyKeys: ["Chênh lệch thu chi BCĐXGN HM"] },
  { key: "tongChiPhiBcdxgn", label: "Tổng chi phí BCĐXGN", kind: "money", group: "giai-ngan", legacyKeys: ["Tổng chi phí BCĐXGN HM"] },
  { key: "tongNcvTheoDungPhuongAn", label: "Tổng NCV theo đúng phương án", kind: "money", group: "giai-ngan", legacyKeys: ["Tổng NCV theo đúng phương án HM"] },
  { key: "sdChoPhuongAnKinhDoanh", label: "SD cho phương án kinh doanh", kind: "money", group: "giai-ngan", legacyKeys: ["SD cho phương án kinh doanh HM"] },
  { key: "vonDoiUng", label: "Vốn đối ứng", kind: "money", group: "giai-ngan", legacyKeys: ["Vốn đối ứng CC", "Vốn đối ứng HM"] },
  { key: "duNoAgribankBangChu", label: "Dư nợ Agribank bằng chữ", kind: "text", group: "giai-ngan", legacyKeys: ["Dư nợ Agribank bằng chữ HM"] },
  { key: "chiemTyLe", label: "Chiếm tỷ lệ", kind: "number", group: "giai-ngan", legacyKeys: ["Chiếm tỷ lệ HM"] },
  { key: "soTienNhanNoNnBangChu", label: "Số tiền nhận nợ NN bằng chữ", kind: "text", group: "giai-ngan", legacyKeys: ["Số tiền nhận nợ NN bằng chữ HM"] },
  { key: "soTienSauKhiNn", label: "Số tiền sau khi NN", kind: "money", group: "giai-ngan", legacyKeys: ["Số tiền sau khi NN HM"] },
  { key: "soTienSauKhiNnBangChu", label: "Số tiền sau khi NN bằng chữ", kind: "text", group: "giai-ngan", legacyKeys: ["Số tiền sau khi NN bằng chữ HM"] },
  { key: "laiUocCuaNhanNo", label: "Lãi ước của nhận nợ", kind: "money", group: "giai-ngan", legacyKeys: ["Lãi ước của nhận nợ HM"] },
  { key: "hangTonKho1", label: "Hàng tồn kho1", kind: "money", group: "giai-ngan", legacyKeys: ["Hàng tồn kho1 HM"] },
  { key: "noPhaiThu1", label: "Nợ phải thu1", kind: "money", group: "giai-ngan", legacyKeys: ["Nợ phải thu1 HM"] },
  { key: "noPhaiTra12", label: "Nợ phải trả1", kind: "money", group: "giai-ngan", legacyKeys: ["Nợ phải trả1 HM"] },
  { key: "soTienUocCongThemNn", label: "Số tiền ước cộng thêm NN", kind: "money", group: "giai-ngan", legacyKeys: ["Số tiền ước cộng thêm NN HM"] },
  { key: "nguonThuTuHdkdChinh", label: "Nguồn thu từ HĐKD chính", kind: "money", group: "giai-ngan", legacyKeys: ["Nguồn thu từ HĐKD chính HM"] },
  { key: "loaiCmndNguoiThuHuong", label: "Loại CMND người thụ hưởng", kind: "text", group: "giai-ngan", legacyKeys: ["Loại CMND người thụ hưởng TD"] },
  { key: "xungHoNguoiThuHuong", label: "Xưng hô người thụ hưởng", kind: "text", group: "giai-ngan", legacyKeys: ["Xưng hô người thụ hưởng TD"] },
  { key: "cmndNguoiThuHuong", label: "CMND người thụ hưởng", kind: "text", group: "giai-ngan", legacyKeys: ["CMND người thụ hưởng CC", "CMND người thụ hưởng TD"] },
  { key: "soTkNguoiThuHuong", label: "Số TK người thụ hưởng", kind: "text", group: "giai-ngan", legacyKeys: ["Số TK người thụ hưởng CC", "Số TK người thụ hưởng TD"] },
  // --- PHIÊN 6 — phủ nốt CAM_CO (TT Chung-Giải Ngân 37, TT Tài Sản 13) và TIEU_DUNG
  //     (TT Chung 10, TT Hợp Đồng Vay 7, TT Khách hàng 22, TT Phương Án 36, TT Tài Sản 80);
  //     nhãn trùng được hợp nhất vào trường sẵn có qua legacyKeys, chỉ thêm nhãn mới. ---
  { key: "ngayThangNam", label: "Ngày tháng năm", kind: "text", group: "giai-ngan", legacyKeys: ["Ngày tháng năm CC", "Ngày tháng năm TD"] },
  { key: "ngayHoSo", label: "Ngày hồ sơ", kind: "date", group: "giai-ngan", legacyKeys: ["Ngày hồ sơ CC"] },
  { key: "danhXung", label: "Danh xưng", kind: "text", group: "giai-ngan", legacyKeys: ["Danh xưng CC"] },
  { key: "namSinh2", label: "Năm sinh", kind: "text", group: "giai-ngan", legacyKeys: ["Năm sinh CC"] },
  { key: "tongNhuCauVonBangChu", label: "Tổng nhu cầu vốn bằng chữ", kind: "text", group: "giai-ngan", legacyKeys: ["Tổng nhu cầu vốn bằng chữ CC", "Tổng nhu cầu vốn bằng chữ TD"] },
  { key: "bangChu", label: "Bằng chữ", kind: "text", group: "giai-ngan", legacyKeys: ["Bằng chữ CC"] },
  { key: "vonDoiUngBangChu", label: "Vốn đối ứng bằng chữ", kind: "text", group: "giai-ngan", legacyKeys: ["Vốn đối ứng bằng chữ CC"] },
  { key: "tyLeVonDoiUng", label: "Tỷ lệ vốn đối ứng", kind: "percent", group: "giai-ngan", legacyKeys: ["Tỷ lệ vốn đối ứng CC"] },
  { key: "laiSoTietKiem", label: "Lãi sổ tiết kiệm", kind: "text", group: "giai-ngan", legacyKeys: ["Lãi sổ tiết kiệm CC"] },
  { key: "hanTraCuoiCung", label: "Hạn trả cuối cùng", kind: "text", group: "giai-ngan", legacyKeys: ["Hạn trả cuối cùng CC"] },
  { key: "ngayGiaoNhan", label: "Ngày giao/nhận", kind: "text", group: "giai-ngan", legacyKeys: ["Ngày giao/nhận CC"] },
  { key: "soTk1", label: "Sổ TK 1", kind: "text", group: "giai-ngan", legacyKeys: ["Sổ TK 1 CC"] },
  { key: "soTk2", label: "Sổ TK 2", kind: "text", group: "giai-ngan", legacyKeys: ["Sổ TK 2 CC"] },
  { key: "soTk3", label: "Sổ TK 3", kind: "text", group: "giai-ngan", legacyKeys: ["Sổ TK 3 CC"] },
  { key: "soTk4", label: "Sổ TK 4", kind: "text", group: "giai-ngan", legacyKeys: ["Sổ TK 4 CC"] },
  { key: "soTk5", label: "Sổ TK 5", kind: "text", group: "giai-ngan", legacyKeys: ["Sổ TK 5 CC"] },
  { key: "tongSoTk", label: "Tổng Sổ TK", kind: "text", group: "giai-ngan", legacyKeys: ["Tổng Sổ TK CC"] },
  { key: "tongTienSoTkBangChu", label: "Tổng tiền Sổ TK bằng chữ", kind: "text", group: "giai-ngan", legacyKeys: ["Tổng tiền Sổ TK bằng chữ CC"] },
  { key: "toChucPhatHanh", label: "Tổ chức phát hành", kind: "text", group: "tsbd", legacyKeys: [".ts.Tổ chức phát hành CC"] },
  { key: "soSeri", label: "Số seri", kind: "text", group: "tsbd", legacyKeys: [".ts.Số seri CC"] },
  { key: "ngayPhatHanh", label: "Ngày phát hành", kind: "date", group: "tsbd", legacyKeys: [".ts.Ngày phát hành CC"] },
  { key: "ngayDenHan", label: "Ngày đến hạn", kind: "date", group: "tsbd", legacyKeys: [".ts.Ngày đến hạn CC"] },
  { key: "soDu", label: "Số dư", kind: "text", group: "tsbd", legacyKeys: [".ts.Số dư CC"] },
  { key: "soDuBangChu", label: "Số dư bằng chữ", kind: "text", group: "tsbd", legacyKeys: [".ts.Số dư bằng chữ CC"] },
  { key: "laiSuat2", label: "Lãi suất", kind: "text", group: "tsbd", legacyKeys: [".ts.Lãi suất CC"] },
  { key: "kyHan", label: "Kỳ hạn", kind: "text", group: "tsbd", legacyKeys: [".ts.Kỳ hạn CC"] },
  { key: "tienLai", label: "Tiền lãi", kind: "text", group: "tsbd", legacyKeys: [".ts.Tiền lãi CC"] },
  { key: "congGocLai", label: "Cộng gốc + lãi", kind: "text", group: "tsbd", legacyKeys: [".ts.Cộng gốc + lãi CC"] },
  { key: "soNgayVay", label: "Số ngày vay", kind: "text", group: "tsbd", legacyKeys: [".ts.Số ngày vay CC"] },
  { key: "laiVayStk", label: "Lãi vay STK", kind: "text", group: "tsbd", legacyKeys: [".ts.Lãi vay STK CC"] },
  { key: "mucVayToiDa", label: "Mức vay tối đa", kind: "text", group: "tsbd", legacyKeys: [".ts.Mức vay tối đa CC"] },
  { key: "ngayGiaoNhan2", label: "Ngày giao-nhận", kind: "date", group: "khach-hang", legacyKeys: ["Ngày giao-nhận TD"] },
  { key: "ngayThangNamNn", label: "Ngày tháng năm NN", kind: "date", group: "khach-hang", legacyKeys: ["Ngày tháng năm NN TD"] },
  { key: "ngayBiaHs", label: "Ngày bìa HS", kind: "date", group: "khach-hang", legacyKeys: ["Ngày bìa HS TD"] },
  { key: "ngayCic", label: "Ngày CIC", kind: "date", group: "khach-hang", legacyKeys: ["Ngày CIC TD"] },
  { key: "nguoiQhkhQln", label: "Người QHKH/QLN", kind: "text", group: "khach-hang", legacyKeys: ["Người QHKH/QLN TD"] },
  { key: "nguoiThamDinh", label: "Người thẩm định", kind: "text", group: "khach-hang", legacyKeys: ["Người thẩm định TD"] },
  { key: "nguoiDuyet", label: "Người duyệt", kind: "text", group: "khach-hang", legacyKeys: ["Người duyệt TD"] },
  { key: "chucVuNguoiDuyet", label: "Chức vụ người duyệt", kind: "text", group: "khach-hang", legacyKeys: ["Chức vụ người duyệt TD"] },
  { key: "soUyQuyenTd", label: "Số ủy quyền TD", kind: "text", group: "khach-hang", legacyKeys: ["Số ủy quyền TD TD"] },
  { key: "tenKhachHangVay", label: "Tên khách hàng vay", kind: "text", group: "khach-hang", legacyKeys: ["Tên khách hàng vay TD"] },
  { key: "tenKhachHangVayInHoa", label: "Tên khách hàng vay in hoa", kind: "text", group: "khach-hang", legacyKeys: ["Tên khách hàng vay in hoa TD"] },
  { key: "tenKhachHangVayVietHoa", label: "Tên khách hàng vay viết hoa", kind: "text", group: "khach-hang", legacyKeys: ["Tên khách hàng vay viết hoa TD"] },
  { key: "namVay", label: "Năm vay", kind: "date", group: "pa-sxkd", legacyKeys: ["Năm vay TD"] },
  { key: "namDenHan", label: "Năm đến hạn", kind: "date", group: "pa-sxkd", legacyKeys: ["Năm đến hạn TD"] },
  { key: "vonTuCoBangChu", label: "Vốn tự có bằng chữ", kind: "text", group: "pa-sxkd", legacyKeys: ["Vốn tự có bằng chữ TD"] },
  { key: "soThangDinhKy", label: "Số tháng định kỳ", kind: "text", group: "pa-sxkd", legacyKeys: ["Số tháng định kỳ TD"] },
  { key: "soKyTraNoGoc", label: "Số kỳ trả nợ gốc", kind: "text", group: "pa-sxkd", legacyKeys: ["Số kỳ trả nợ gốc TD"] },
  { key: "soTienTraGocTraTheoDinhKy", label: "Số tiền trả gốc trả theo định kỳ", kind: "text", group: "pa-sxkd", legacyKeys: ["Số tiền trả gốc trả theo định kỳ TD"] },
  { key: "ngayTraNoCuoiCung", label: "Ngày trả nợ cuối cùng", kind: "date", group: "pa-sxkd", legacyKeys: ["Ngày trả nợ cuối cùng TD"] },
  { key: "nguonThuNhap1", label: "Nguồn thu nhập 1", kind: "text", group: "pa-sxkd", legacyKeys: ["Nguồn thu nhập 1 TD"] },
  { key: "soTienThuNhap1", label: "Số tiền thu nhập 1", kind: "text", group: "pa-sxkd", legacyKeys: ["Số tiền thu nhập 1 TD"] },
  { key: "nguonThuNhap2", label: "Nguồn thu nhập 2", kind: "text", group: "pa-sxkd", legacyKeys: ["Nguồn thu nhập 2 TD"] },
  { key: "soTienThuNhap2", label: "Số tiền thu nhập 2", kind: "text", group: "pa-sxkd", legacyKeys: ["Số tiền thu nhập 2 TD"] },
  { key: "nguonThuNhap3", label: "Nguồn thu nhập 3", kind: "text", group: "pa-sxkd", legacyKeys: ["Nguồn thu nhập 3 TD"] },
  { key: "soTienThuNhap3", label: "Số tiền thu nhập 3", kind: "text", group: "pa-sxkd", legacyKeys: ["Số tiền thu nhập 3 TD"] },
  { key: "tongNguonThuNhap", label: "Tổng nguồn thu nhập", kind: "text", group: "pa-sxkd", legacyKeys: ["Tổng nguồn thu nhập TD"] },
  { key: "tongNguonThuNhapDinhKy", label: "Tổng nguồn thu nhập định kỳ", kind: "text", group: "pa-sxkd", legacyKeys: ["Tổng nguồn thu nhập định kỳ TD"] },
  { key: "tongThuNhapNam", label: "Tổng thu nhập năm", kind: "text", group: "pa-sxkd", legacyKeys: ["Tổng thu nhập năm TD"] },
  { key: "soTienTraGocHangQuy", label: "Số tiền trả gốc hàng quý", kind: "text", group: "pa-sxkd", legacyKeys: ["Số tiền trả gốc hàng quý TD"] },
  { key: "soTienGocTraHangThang", label: "Số tiền gốc trả hàng tháng", kind: "text", group: "pa-sxkd", legacyKeys: ["Số tiền gốc trả hàng tháng TD"] },
  { key: "soTienGocTraDinhKy", label: "Số tiền gốc trả định kỳ", kind: "text", group: "pa-sxkd", legacyKeys: ["Số tiền gốc trả định kỳ TD"] },
  { key: "soTienLaiTraHangThang", label: "Số tiền lãi trả hàng tháng", kind: "text", group: "pa-sxkd", legacyKeys: ["Số tiền lãi trả hàng tháng TD"] },
  { key: "soTienLaiTraTheoDinhKy", label: "Số tiền lãi trả theo định kỳ", kind: "text", group: "pa-sxkd", legacyKeys: ["Số tiền lãi trả theo định kỳ TD"] },
  { key: "gocLaiPhaiTraHangThang", label: "Gốc lãi phải trả hàng tháng", kind: "text", group: "pa-sxkd", legacyKeys: ["Gốc lãi phải trả hàng tháng TD"] },
  { key: "chiPhiSinhHoatHangThang", label: "Chi phí sinh hoạt hàng tháng", kind: "text", group: "pa-sxkd", legacyKeys: ["Chi phí sinh hoạt hàng tháng TD"] },
  { key: "chiPhiSinhHoatTheoDinhKy", label: "Chi phí sinh hoạt theo định kỳ", kind: "text", group: "pa-sxkd", legacyKeys: ["Chi phí sinh hoạt theo định kỳ TD"] },
  { key: "soTienGocLaiPhaiTraTheoDinhKy", label: "Số tiền gốc lãi phải trả theo định kỳ", kind: "text", group: "pa-sxkd", legacyKeys: ["Số tiền gốc lãi phải trả theo định kỳ TD"] },
  { key: "noNguoiBanBangChu", label: "Nợ người bán bằng chữ", kind: "text", group: "pa-sxkd", legacyKeys: ["Nợ người bán bằng chữ TD"] },
  { key: "tenTsbd", label: "Tên TSBĐ", kind: "text", group: "tsbd", legacyKeys: [".ts.Tên TSBĐ TD"] },
  { key: "giaTriChoVayGiaTriTs", label: "Giá trị cho vay / Giá trị TS", kind: "text", group: "tsbd", legacyKeys: [".ts.Giá trị cho vay / Giá trị TS TD"] },
  { key: "soHdtcChuyenHm", label: "Số HĐTC (chuyển HM)", kind: "text", group: "tsbd", legacyKeys: [".ts.Số HĐTC (chuyển HM) TD"] },
  { key: "ngayKyHdtcChuyenHm", label: "Ngày ký HĐTC (chuyển HM)", kind: "date", group: "tsbd", legacyKeys: [".ts.Ngày ký HĐTC (chuyển HM) TD"] },
  // --- PHIÊN 11 — câu mô tả tài sản thế chấp, GHÉP TỰ ĐỘNG từ danh mục tài sản
  //     và các thửa/giấy tờ của từng tài sản (không gõ tay trong hợp đồng) ---
  { key: "moTaTaiSanTheChap", label: "Mô tả tài sản thế chấp", kind: "text", group: "tsbd" },
  // --- PHIÊN 12B — KÝ/DUYỆT NỘI BỘ: người lập – người kiểm soát – người duyệt.
  //     Hệ cũ để cán bộ gõ tay chữ ký vào từng mẫu nên hay lệch tên/chức vụ giữa
  //     4 mẫu của cùng một hồ sơ; ở đây khai báo MỘT lần và in đúng chỗ ký ở cả 4 mẫu.
  { key: "nguoiLap", label: "Người lập", kind: "text", group: "ky-duyet", required: true, legacyKeys: ["Cán bộ tín dụng HM", "Người lập TD"] },
  { key: "chucVuNguoiLap", label: "Chức vụ người lập", kind: "text", group: "ky-duyet" },
  { key: "nguoiKiemSoat", label: "Người kiểm soát", kind: "text", group: "ky-duyet", required: true, legacyKeys: ["Người kiểm soát HM", "Trưởng phòng KHKD TD"] },
  { key: "chucVuNguoiKiemSoat", label: "Chức vụ người kiểm soát", kind: "text", group: "ky-duyet" },
  { key: "nguoiPheDuyet", label: "Người phê duyệt", kind: "text", group: "ky-duyet", required: true, legacyKeys: ["Người phê duyệt HM", "Giám đốc TD"] },
  { key: "chucVuNguoiPheDuyet", label: "Chức vụ người phê duyệt", kind: "text", group: "ky-duyet" },
  { key: "noiKyDuyet", label: "Nơi ký", kind: "text", group: "ky-duyet" },
  { key: "ngayKyDuyet", label: "Ngày ký duyệt", kind: "date", group: "ky-duyet" },
];

export const GROUP_LABEL: Record<FieldMeta["group"], string> = {
  "khach-hang": "Thông tin khách hàng",
  "khoan-vay": "Khoản vay",
  tsbd: "Tài sản bảo đảm",
  "pa-sxkd": "Phương án SXKD",
  "giai-ngan": "Giải ngân",
  "ky-duyet": "Ký/duyệt nội bộ",
};


/**
 * PHIÊN 7 — bảng LẶP DÒNG khai báo một lần thay cho 14 trường phẳng của hệ cũ
 * ("Chi tiết Chi phí vật tư (14 dòng)" trong artifacts/legacy-fields.json).
 * Đây là pattern duy nhất cho mọi bảng lặp về sau (TSBĐ nhiều tài sản, chi phí…).
 */
export interface RepeatableMeta {
  key: string;
  label: string;
  group: FieldMeta["group"];
  rows: number;
  rowLabel: (i: number) => string;
  kind: FieldKind;
  repeatable: true;
  legacyKeys: (i: number) => string[];
  totalKey?: string;
}

export const REPEATABLE_META: readonly RepeatableMeta[] = [
  {
    key: "chiPhiVatTu",
    label: "Chi tiết Chi phí vật tư (14 dòng)",
    group: "pa-sxkd",
    rows: 14,
    rowLabel: (i) => `Chi phí vật tư dòng ${i + 1}`,
    kind: "money",
    repeatable: true,
    legacyKeys: (i) => [`Chi phí vật tư ${i + 1} HM`, `Chi phí vật tư ${i + 1} TD`],
    totalKey: "cpVatTu",
  },
];

/** Tổng số ô dữ liệu bảng lặp — dùng cho thống kê độ phủ. */
export const REPEATABLE_CELLS = REPEATABLE_META.reduce((s, r) => s + r.rows, 0);

/** Ánh xạ nhãn → key, sinh một lần từ FIELD_META (không chép tay). */
export const labelToKey: Record<string, string> = Object.fromEntries(
  FIELD_META.map((f) => [normalizeLabel(f.label), f.key]),
);

export function normalizeLabel(label: string): string {
  return label.trim().toLowerCase().replace(/\s+/g, " ");
}

/** Thay thế findKeyByLabel() — một điểm sự thật duy nhất. */
export function findKeyByLabel(label: string): string | undefined {
  return labelToKey[normalizeLabel(label)];
}

function fieldSchema(f: FieldMeta) {
  const base =
    f.kind === "money" || f.kind === "number" || f.kind === "percent"
      ? z.number().nonnegative()
      : z.string();
  return f.required ? base : base.optional();
}

export const hoSoSchema = z.object(
  Object.fromEntries(FIELD_META.map((f) => [f.key, fieldSchema(f)])) as Record<
    string,
    z.ZodTypeAny
  >,
);

export type HoSo = Record<string, string | number | undefined>;

/** Định dạng số VNĐ dùng chung cho toàn ứng dụng (một thư viện duy nhất). */
export function formatValue(value: string | number | undefined, kind: FieldKind): string {
  if (value === undefined || value === "" || value === null) return "—";
  if (kind === "money") return `${Number(value).toLocaleString("vi-VN")} đ`;
  if (kind === "percent") return `${Number(value).toLocaleString("vi-VN")} %`;
  if (kind === "number") return Number(value).toLocaleString("vi-VN");
  return String(value);
}