/**
 * PHIÊN 15 (PHẦN 1) — BỘ QUY TẮC NGHIỆP VỤ THEO SẢN PHẨM VAY.
 *
 * Hệ cũ chỉ kiểm tra "có điền hay chưa". Sai hạn mức, sai thời hạn, cho vay
 * vượt tỷ lệ trên tài sản bảo đảm chỉ lộ ra khi hồ sơ đã lên phòng thẩm định
 * — phải soạn lại từ đầu. Ở đây chọn SẢN PHẨM VAY thì bộ kiểm tra tự đổi theo
 * đúng quy định của sản phẩm đó, báo ngay trong lúc gõ.
 *
 * Chỉ tính toán trên dữ liệu phiên React — hệ cũ vẫn CHỈ ĐỌC.
 */
import type { HoSo } from "./fieldMeta";

export type SanPhamId = "ngan-han-sxkd" | "trung-han" | "tieu-dung";

export interface QuyTacSanPham {
  id: SanPhamId;
  ten: string;
  moTa: string;
  /** Hạn mức tối đa một khoản vay (VND). */
  soTienToiDa: number;
  /** Thời hạn vay tối đa (tháng). */
  thangToiDa: number;
  /** Tỷ lệ cho vay tối đa trên giá trị TSBĐ (%). 0 = không yêu cầu TSBĐ. */
  tyLeTsbdToiDa: number;
  /** Kỳ trả nợ gốc cho phép (tháng). */
  kyTraNoThang: number[];
  /** Khoảng lãi suất hợp lệ (%/năm). */
  laiSuatMin: number;
  laiSuatMax: number;
}

export const SAN_PHAM: readonly QuyTacSanPham[] = [
  {
    id: "ngan-han-sxkd",
    ten: "Ngắn hạn sản xuất kinh doanh",
    moTa: "Bổ sung vốn lưu động hộ SXKD, tối đa 12 tháng.",
    soTienToiDa: 3_000_000_000,
    thangToiDa: 12,
    tyLeTsbdToiDa: 75,
    kyTraNoThang: [1, 3, 6],
    laiSuatMin: 4,
    laiSuatMax: 12,
  },
  {
    id: "trung-han",
    ten: "Trung hạn đầu tư",
    moTa: "Đầu tư máy móc, nhà xưởng, phương tiện — tối đa 60 tháng.",
    soTienToiDa: 5_000_000_000,
    thangToiDa: 60,
    tyLeTsbdToiDa: 70,
    kyTraNoThang: [3, 6, 12],
    laiSuatMin: 6,
    laiSuatMax: 14,
  },
  {
    id: "tieu-dung",
    ten: "Tiêu dùng đời sống",
    moTa: "Phục vụ nhu cầu đời sống cá nhân, tối đa 36 tháng.",
    soTienToiDa: 500_000_000,
    thangToiDa: 36,
    tyLeTsbdToiDa: 0,
    kyTraNoThang: [1, 3],
    laiSuatMin: 7,
    laiSuatMax: 16,
  },
];

export function quyTac(id: SanPhamId): QuyTacSanPham {
  return SAN_PHAM.find((s) => s.id === id) ?? SAN_PHAM[0]!;
}

/** Đọc số tiền kiểu Việt: "1.500.000", "1500000", "1,5" → number | null. */
export function soVn(v: unknown): number | null {
  if (typeof v === "number") return Number.isFinite(v) ? v : null;
  const s = String(v ?? "").trim().replace(/\s|đ|VND/gi, "");
  if (!s) return null;
  const cleaned = s.replace(/\./g, "").replace(/,/g, ".");
  if (!/^-?\d+(\.\d+)?$/.test(cleaned)) return null;
  return Number(cleaned);
}

export interface CanhBaoSanPham {
  ma: string;
  muc: "chan" | "canh-bao";
  thongBao: string;
}

export interface ThamSoKhoanVay {
  soTien: number | null;
  soThang: number | null;
  laiSuat: number | null;
  giaTriTsbd: number | null;
  kyTraNo: number | null;
}

export function thamSoTuHoSo(hoSo: HoSo, kyTraNo?: number | null): ThamSoKhoanVay {
  return {
    soTien: soVn(hoSo["soTienVay"] ?? hoSo["hmtdDuyet"]),
    soThang: soVn(hoSo["thoiHan"]),
    laiSuat: soVn(hoSo["laiSuat"]),
    giaTriTsbd: soVn(hoSo["tongGiaTriTaiSanTheChap"] ?? hoSo["tongGiaTriTaiSanHienCo"]),
    kyTraNo: kyTraNo ?? null,
  };
}

const trieu = (n: number) => `${(n / 1_000_000).toLocaleString("vi-VN")} triệu đồng`;

/**
 * Bộ kiểm tra đổi theo sản phẩm. "chan" = không được xuất; "canh-bao" = phải
 * giải trình nhưng vẫn xuất được.
 */
export function kiemTraSanPham(sp: SanPhamId, ts: ThamSoKhoanVay): CanhBaoSanPham[] {
  const q = quyTac(sp);
  const ds: CanhBaoSanPham[] = [];

  if (ts.soTien === null) {
    ds.push({ ma: "so-tien-trong", muc: "chan", thongBao: "Chưa có Số tiền vay hợp lệ." });
  } else if (ts.soTien > q.soTienToiDa) {
    ds.push({
      ma: "vuot-han-muc",
      muc: "chan",
      thongBao: `Số tiền vay ${trieu(ts.soTien)} vượt hạn mức sản phẩm “${q.ten}” (tối đa ${trieu(q.soTienToiDa)}).`,
    });
  } else if (ts.soTien > q.soTienToiDa * 0.8) {
    ds.push({
      ma: "gan-han-muc",
      muc: "canh-bao",
      thongBao: `Số tiền vay đạt trên 80% hạn mức sản phẩm — cần cấp phê duyệt cao hơn.`,
    });
  }

  if (ts.soThang === null) {
    ds.push({ ma: "thoi-han-trong", muc: "canh-bao", thongBao: "Chưa nhập thời hạn vay (tháng)." });
  } else if (ts.soThang > q.thangToiDa) {
    ds.push({
      ma: "vuot-thoi-han",
      muc: "chan",
      thongBao: `Thời hạn ${ts.soThang} tháng vượt mức tối đa ${q.thangToiDa} tháng của sản phẩm “${q.ten}”.`,
    });
  }

  if (ts.laiSuat !== null && (ts.laiSuat < q.laiSuatMin || ts.laiSuat > q.laiSuatMax)) {
    ds.push({
      ma: "lai-suat-ngoai-khung",
      muc: "canh-bao",
      thongBao: `Lãi suất ${ts.laiSuat}%/năm nằm ngoài khung ${q.laiSuatMin}–${q.laiSuatMax}%/năm của sản phẩm.`,
    });
  }

  if (q.tyLeTsbdToiDa > 0) {
    if (!ts.giaTriTsbd) {
      ds.push({
        ma: "thieu-tsbd",
        muc: "chan",
        thongBao: `Sản phẩm “${q.ten}” yêu cầu tài sản bảo đảm — chưa có giá trị TSBĐ.`,
      });
    } else if (ts.soTien !== null) {
      const tyLe = (ts.soTien / ts.giaTriTsbd) * 100;
      if (tyLe > q.tyLeTsbdToiDa) {
        ds.push({
          ma: "vuot-ty-le-tsbd",
          muc: "chan",
          thongBao: `Cho vay ${tyLe.toFixed(1)}% giá trị TSBĐ, vượt mức tối đa ${q.tyLeTsbdToiDa}%.`,
        });
      }
    }
  }

  if (ts.kyTraNo !== null && !q.kyTraNoThang.includes(ts.kyTraNo)) {
    ds.push({
      ma: "ky-tra-no-la",
      muc: "canh-bao",
      thongBao: `Kỳ trả nợ ${ts.kyTraNo} tháng không thuộc kỳ chuẩn (${q.kyTraNoThang.join(", ")} tháng).`,
    });
  }

  return ds;
}

export function tomTatQuyTac(sp: SanPhamId, ds: CanhBaoSanPham[]): string {
  const q = quyTac(sp);
  const chan = ds.filter((d) => d.muc === "chan").length;
  const canh = ds.length - chan;
  if (ds.length === 0) return `Khoản vay đạt toàn bộ quy tắc sản phẩm “${q.ten}”.`;
  return `Sản phẩm “${q.ten}”: ${chan} lỗi chặn, ${canh} cảnh báo cần giải trình.`;
}
