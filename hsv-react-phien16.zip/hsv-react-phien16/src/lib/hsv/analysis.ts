/**
 * Dữ liệu phân tích trích từ "Báo cáo phân tích chuyên sâu & Đề án nâng cấp HSV"
 * (bản v10 – 20/08/2026) và từ đo đếm trực tiếp trên gói mã nguồn
 * HSV_upgrade_2026-08-20_Phien1_35.zip đã nạp vào /legacy.
 */

export type Severity = "cao" | "trung-binh" | "thap";

export interface Metric {
  label: string;
  value: string;
  note: string;
}

export const metrics: Metric[] = [
  { label: "Tổng số tệp", value: "52", note: "42 .js · 5 .css · 1 .html" },
  { label: "app.js", value: "38.256 dòng", note: "~4,2 MB logic nghiệp vụ" },
  { label: "Mẫu DOCX nhúng base64", value: "83 mẫu", note: "templates-data.js ~9,7 MB" },
  { label: "Khối <script> rời rạc", value: "108", note: "nối chuỗi qua các đợt vá" },
  { label: "Biến toàn cục window", value: "234", note: "không có single source of truth" },
  { label: "Lượt gọi localStorage", value: "299", note: "+ 84 lượt IndexedDB" },
];

export interface Finding {
  id: string;
  title: string;
  severity: Severity;
  evidence: string;
  remedy: string;
}

export const findings: Finding[] = [
  {
    id: "4.1",
    title: 'Kiến trúc "vá chồng vá", không refactor định kỳ',
    severity: "cao",
    evidence: "108 khối <script> thêm dần từ v6 → v25.6.4, 1.085 IIFE ẩn danh trong app.js.",
    remedy: "Module hoá React + TypeScript, mỗi màn hình một module có ranh giới rõ ràng.",
  },
  {
    id: "4.2",
    title: "Ba hệ quản lý TSBĐ nhiều tài sản chạy song song",
    severity: "cao",
    evidence: 'Ba hệ độc lập không biết đến nhau, từng gây lỗi dữ liệu "chập chờn" giữa các tài sản.',
    remedy: "Hợp nhất về DUY NHẤT một pattern danh sách lặp (mảng state + component con).",
  },
  {
    id: "4.2b",
    title: "findKeyByLabel() bị chép tay 5 lần",
    severity: "cao",
    evidence: "5 bản sao độc lập trong app.js — sửa một chỗ không lan tới các chỗ còn lại.",
    remedy: "Một FIELD_META khai báo duy nhất sinh ra validate, kiểu TS và ánh xạ nhãn ↔ field.",
  },
  {
    id: "4.3",
    title: 'Không có "nguồn sự thật duy nhất" cho trạng thái',
    severity: "cao",
    evidence: "299 localStorage + 84 IndexedDB, migration thủ công v9 → v12.",
    remedy: "Một store cho mỗi hồ sơ, IndexedDB qua lớp adapter tường minh.",
  },
  {
    id: "4.4",
    title: "Tải trang nặng do template base64 trong JS",
    severity: "trung-binh",
    evidence: "9,7 MB base64 phải nạp nền để không chặn hiển thị.",
    remedy: "Tách template thành tệp tĩnh, nạp theo yêu cầu + cache IndexedDB (GĐ 4).",
  },
  {
    id: "4.5",
    title: 'Phụ thuộc CDN ngoài, mâu thuẫn tuyên bố "offline"',
    severity: "trung-binh",
    evidence: "cdnjs (xlsx.full 0.18.5) và jsDelivr (@supabase/supabase-js) nạp lúc chạy.",
    remedy: "Đưa toàn bộ phụ thuộc về npm, bundle nội bộ, tree-shake đúng chuẩn (GĐ 3).",
  },
  {
    id: "4.6",
    title: "Không có kiểm thử tự động và an toàn kiểu dữ liệu",
    severity: "cao",
    evidence: "Không hệ thống build, không type-check; nhóm lỗi đọc sai kiểu số liệu VN tái diễn.",
    remedy: "TypeScript + Vitest (unit) + Playwright (E2E) làm lưới an toàn trước mọi thay đổi.",
  },
  {
    id: "4.7",
    title: 'Nợ kỹ thuật giao diện — "vá triệu chứng"',
    severity: "thap",
    evidence: 'Chip "đã lưu" được dời vị trí position:fixed giữa v25.6.3 và v25.6.4 thay vì sửa z-index.',
    remedy: "Hệ thống layout/z-index theo token thiết kế, không dùng position:fixed để né lỗi.",
  },
];

export type PhaseStatus = "hoan-thanh" | "dang-lam" | "ke-hoach";

export interface Phase {
  code: string;
  duration: string;
  title: string;
  items: string[];
  deliverable: string;
  status: PhaseStatus;
}

export const phases: Phase[] = [
  {
    code: "GĐ 0",
    duration: "2 tuần",
    title: 'Thiết lập "lưới an toàn" trước khi đổi bất kỳ dòng mã nào',
    items: [
      "Kịch bản Playwright ghi lại hành vi hiện tại của các luồng nghiệp vụ cốt lõi",
      'Chốt FIELD_META + danh sách công thức làm "đặc tả sự thật"',
    ],
    deliverable: "Bộ kiểm thử hồi quy tự động dùng làm tiêu chí nghiệm thu",
    status: "hoan-thanh",
  },
  {
    code: "GĐ 1",
    duration: "3-4 tuần",
    title: "Dựng khung React/TypeScript/Vite chạy song song hệ cũ",
    items: [
      "Ứng dụng React trên route riêng, cùng domain với HSV cũ",
      "Adapter đọc hồ sơ từ localStorage/IndexedDB — KHÔNG ghi đè dữ liệu cũ",
      "Chuyển thử một màn hình ít rủi ro để kiểm chứng quy trình",
    ],
    deliverable: "Ứng dụng React đọc được hồ sơ thật (read-only pilot)",
    status: "dang-lam",
  },
  {
    code: "GĐ 2",
    duration: "6-8 tuần",
    title: "Chuyển đổi lõi nghiệp vụ HMTD/Hồ sơ vay",
    items: [
      "FIELD_META → Zod schema, form chính, engine tính công thức",
      "Hợp nhất duy nhất một hệ quản lý TSBĐ nhiều tài sản",
      "Chạy song song hai hệ thật với feature flag theo người dùng",
    ],
    deliverable: "Module hồ sơ vay đối chiếu số liệu 1:1 với bản cũ",
    status: "ke-hoach",
  },
  {
    code: "GĐ 3",
    duration: "4-6 tuần",
    title: "Chuyển PA SXKD thành module React tích hợp",
    items: [
      "Bỏ iframe sandboxed và 3 kênh đồng bộ postMessage",
      "Chuyển xuất DOCX/XLSX sang thư viện npm chính thức",
    ],
    deliverable: "PA SXKD và xuất văn bản hoạt động không cần iframe/CDN ngoài",
    status: "ke-hoach",
  },
  {
    code: "GĐ 4",
    duration: "3-4 tuần",
    title: "Tối ưu tải template và migration toàn bộ người dùng",
    items: [
      "83 mẫu DOCX: base64-trong-JS → tệp tĩnh nạp theo yêu cầu + cache",
      "Kiểm thử tải trên máy cấu hình thấp",
    ],
    deliverable: "Giảm mạnh thời gian tải; hệ cũ chuyển sang chỉ đọc dự phòng",
    status: "ke-hoach",
  },
  {
    code: "GĐ 5",
    duration: "2 tuần",
    title: "Quan sát ổn định (stabilization)",
    items: ["Giữ hệ cũ ở chế độ chỉ đọc, có thể khôi phục, tối thiểu 1 chu kỳ nghiệp vụ"],
    deliverable: "Nghiệm thu chính thức, archive mã nguồn cũ",
    status: "ke-hoach",
  },
];

export const principles = [
  {
    title: "Không đại tu một lần",
    body: "Mô hình strangler-fig: React chạy song song hệ cũ, thay thế dần từng màn hình.",
  },
  {
    title: "Bảo toàn dữ liệu tuyệt đối",
    body: "Hồ sơ trong localStorage/IndexedDB được đọc nguyên vẹn qua adapter, chỉ đọc ở GĐ 1.",
  },
  {
    title: 'Không có "cửa sổ mất chức năng"',
    body: "Màn hình cũ vẫn hoạt động nếu module React chưa sẵn sàng — bật/tắt bằng feature flag.",
  },
  {
    title: "Luôn có lối thoát",
    body: "Tắt feature flag để quay lại module cũ trong vài giây, không cần triển khai lại.",
  },
];