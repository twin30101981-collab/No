/**
 * PHIÊN 12 (PHẦN 1) — thanh quản lý nhiều hồ sơ trong một phiên làm việc.
 * PHIÊN 13 — thêm: ô tìm nhanh + sắp xếp, bảng theo dõi tiến độ từng hồ sơ,
 * và lưu/nạp cả bộ hồ sơ ra tệp `.hsv.json`.
 * Giao diện thuần trình bày: mọi phép biến đổi nằm ở lib/hsv/*.
 */
import { useRef } from "react";
import { NGUON_LABEL, locHoSo, type SapXepHoSo, type Workspace } from "@/lib/hsv/hoSoWorkspace";
import { nhanThoiGian, tienDoDanhSach, tomTatTienDo } from "@/lib/hsv/tienDo";

interface Props {
  ws: Workspace;
  dangNhap: boolean;
  thongBao: string;
  onChon: (id: string) => void;
  onThem: () => void;
  onNhanBan: () => void;
  onXoa: () => void;
  onDoiTen: (ten: string) => void;
  onNhapHeCu: () => void;
  /** PHIÊN 12B — danh sách id hồ sơ được đánh dấu để xuất trọn bộ ZIP. */
  chonXuat: string[];
  onToggleXuat: (id: string) => void;
  /** PHIÊN 13 */
  tuKhoa: string;
  onTuKhoa: (v: string) => void;
  sapXep: SapXepHoSo;
  onSapXep: (v: SapXepHoSo) => void;
  onLuuTep: () => void;
  onNapTep: (file: File) => void;
  thongBaoTep: string;
  loiTep: string[];
}

export function DanhSachHoSo({
  ws,
  dangNhap,
  thongBao,
  onChon,
  onThem,
  onNhanBan,
  onXoa,
  onDoiTen,
  onNhapHeCu,
  chonXuat,
  onToggleXuat,
  tuKhoa,
  onTuKhoa,
  sapXep,
  onSapXep,
  onLuuTep,
  onNapTep,
  thongBaoTep,
  loiTep,
}: Props) {
  const active = ws.items.find((i) => i.id === ws.activeId) ?? ws.items[0]!;
  const hienThi = locHoSo(ws.items, tuKhoa, sapXep);
  const tienDo = tienDoDanhSach(hienThi);
  const tomTat = tomTatTienDo(tienDoDanhSach(ws.items));
  const inputTep = useRef<HTMLInputElement>(null);

  return (
    <section className="card-elevated px-5 py-4" data-testid="khoi-danh-sach-ho-so">
      <h2 className="text-base font-bold text-foreground">
        Hồ sơ trong phiên làm việc ({ws.items.length})
      </h2>
      <p className="mt-1 max-w-3xl text-xs text-muted-foreground">
        Hệ cũ chỉ soạn được một hồ sơ tại một thời điểm. Ở đây cán bộ giữ nhiều khách hàng/khoản vay
        cùng lúc: tìm nhanh theo tên/mã KH/số hồ sơ, theo dõi hồ sơ nào đã đủ trường, lưu cả bộ ra
        tệp để chuyển máy — hệ cũ vẫn <strong>chỉ đọc</strong>.
      </p>

      {/* PHIÊN 13 — tìm nhanh + sắp xếp + lưu/nạp tệp bộ hồ sơ. */}
      <div className="mt-3 grid gap-2 sm:grid-cols-[minmax(0,1fr)_auto_auto_auto]">
        <input
          value={tuKhoa}
          onChange={(e) => onTuKhoa(e.target.value)}
          placeholder="Tìm theo tên hồ sơ, tên khách hàng, mã KH, số hồ sơ…"
          aria-label="Tìm hồ sơ"
          data-testid="o-tim-ho-so"
          className="rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground"
        />
        <select
          value={sapXep}
          onChange={(e) => onSapXep(e.target.value as SapXepHoSo)}
          aria-label="Sắp xếp hồ sơ"
          data-testid="sap-xep-ho-so"
          className="rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground"
        >
          <option value="thu-tu">Thứ tự trong phiên</option>
          <option value="moi-sua">Mới sửa gần nhất</option>
          <option value="ten">Theo tên A→Z</option>
        </select>
        <button
          type="button"
          onClick={onLuuTep}
          data-testid="luu-tep-bo-ho-so"
          className="rounded-md border border-border px-3 py-2 text-sm"
        >
          Lưu bộ hồ sơ ra tệp
        </button>
        <button
          type="button"
          onClick={() => inputTep.current?.click()}
          data-testid="mo-nap-tep"
          className="rounded-md border border-border px-3 py-2 text-sm"
        >
          Nạp từ tệp .hsv.json
        </button>
        <input
          ref={inputTep}
          type="file"
          accept=".json,.hsv.json,application/json"
          hidden
          data-testid="input-nap-tep"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onNapTep(f);
            e.target.value = "";
          }}
        />
      </div>

      {thongBaoTep && (
        <p className="mt-2 text-sm font-medium text-foreground" data-testid="ket-qua-tep-bo-ho-so">
          {thongBaoTep}
        </p>
      )}
      {loiTep.length > 0 && (
        <ul className="mt-1 text-sm font-medium text-destructive" data-testid="loi-tep-bo-ho-so">
          {loiTep.map((l) => (
            <li key={l}>{l}</li>
          ))}
        </ul>
      )}

      <ul className="mt-3 flex flex-wrap gap-2" data-testid="danh-sach-ho-so">
        {hienThi.map((i) => (
          <li key={i.id} className="flex items-center gap-2 rounded-md border border-border px-2">
            {/* PHIÊN 12B — đánh dấu hồ sơ để xuất trọn bộ nhiều hồ sơ trong một ZIP. */}
            <input
              type="checkbox"
              checked={chonXuat.includes(i.id)}
              onChange={() => onToggleXuat(i.id)}
              aria-label={`Chọn xuất trọn bộ: ${i.ten}`}
              data-testid={`chon-xuat-${i.id}`}
              className="size-4"
            />
            <button
              type="button"
              onClick={() => onChon(i.id)}
              data-testid={`the-ho-so-${i.id}`}
              data-ten={i.ten}
              data-on={i.id === ws.activeId}
              className="rounded-md px-2 py-2 text-left text-sm transition-colors data-[on=true]:bg-primary data-[on=true]:text-primary-foreground"
            >
              <span className="block font-semibold">{i.ten}</span>
              <span className="block text-xs opacity-75">{NGUON_LABEL[i.nguon]}</span>
            </button>
          </li>
        ))}
      </ul>
      {hienThi.length === 0 && (
        <p className="mt-3 text-sm text-muted-foreground" data-testid="khong-tim-thay">
          Không có hồ sơ nào khớp “{tuKhoa}”.
        </p>
      )}

      {/* PHIÊN 13 — bảng theo dõi tiến độ: một màn hình biết hồ sơ nào chưa xong. */}
      <div className="mt-4 overflow-x-auto">
        <p className="text-xs text-muted-foreground" data-testid="tom-tat-tien-do">
          Tiến độ phiên: {tomTat.du}/{tomTat.tong} hồ sơ đủ trường · {tomTat.thieu} còn thiếu ·{" "}
          {tomTat.daXuat} đã xuất tài liệu.
        </p>
        <table className="mt-2 w-full min-w-[640px] border-collapse text-sm" data-testid="bang-tien-do">
          <thead>
            <tr className="text-left text-xs text-muted-foreground">
              <th className="border-b border-border py-2 pr-3">Hồ sơ</th>
              <th className="border-b border-border py-2 pr-3">Trạng thái</th>
              <th className="border-b border-border py-2 pr-3">Còn thiếu</th>
              <th className="border-b border-border py-2 pr-3">Đã xuất</th>
              <th className="border-b border-border py-2">Sửa lúc</th>
            </tr>
          </thead>
          <tbody>
            {tienDo.map((t) => (
              <tr key={t.id} data-testid={`dong-tien-do-${t.id}`} data-du={t.du}>
                <td className="border-b border-border py-2 pr-3 font-medium text-foreground">
                  {t.ten}
                </td>
                <td className="whitespace-nowrap border-b border-border py-2 pr-3">
                  <span
                    data-testid={`trang-thai-${t.id}`}
                    data-du={t.du}
                    className="inline-block whitespace-nowrap rounded-full px-2 py-0.5 text-xs font-semibold data-[du=false]:bg-destructive data-[du=false]:text-destructive-foreground data-[du=true]:bg-primary data-[du=true]:text-primary-foreground"
                  >
                    {t.du ? "Đủ trường" : `Thiếu ${t.soLoi}`}
                  </span>
                </td>
                <td className="border-b border-border py-2 pr-3 text-xs text-muted-foreground">
                  {t.du ? "—" : t.thieu.join("; ")}
                </td>
                <td
                  className="border-b border-border py-2 pr-3 text-xs text-muted-foreground"
                  data-testid={`da-xuat-${t.id}`}
                >
                  {nhanThoiGian(t.daXuat)}
                </td>
                <td className="border-b border-border py-2 text-xs text-muted-foreground">
                  {nhanThoiGian(t.capNhat)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end">
        <label className="block text-xs font-medium text-muted-foreground">
          Tên hồ sơ đang soạn
          <input
            value={active.ten}
            onChange={(e) => onDoiTen(e.target.value)}
            data-testid="o-doi-ten-ho-so"
            className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground"
          />
        </label>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={onThem}
            data-testid="them-ho-so"
            className="rounded-md border border-border px-3 py-2 text-sm"
          >
            Thêm hồ sơ
          </button>
          <button
            type="button"
            onClick={onNhanBan}
            data-testid="nhan-ban-ho-so"
            className="rounded-md border border-border px-3 py-2 text-sm"
          >
            Nhân bản
          </button>
          <button
            type="button"
            onClick={onXoa}
            disabled={ws.items.length <= 1}
            data-testid="xoa-ho-so"
            className="rounded-md border border-border px-3 py-2 text-sm disabled:cursor-not-allowed disabled:opacity-50"
          >
            Xoá hồ sơ
          </button>
          <button
            type="button"
            onClick={onNhapHeCu}
            disabled={dangNhap}
            data-testid="nhap-tu-he-cu"
            className="rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50"
          >
            {dangNhap ? "Đang quét hệ cũ…" : "Nhập từ hệ cũ"}
          </button>
        </div>
      </div>

      {active.ghiChuNguon && (
        <p className="mt-3 text-xs text-muted-foreground" data-testid="nguon-ho-so">
          Nguồn: {active.ghiChuNguon}
        </p>
      )}
      {thongBao && (
        <p className="mt-2 text-sm font-medium text-foreground" data-testid="ket-qua-nhap-he-cu">
          {thongBao}
        </p>
      )}
    </section>
  );
}
