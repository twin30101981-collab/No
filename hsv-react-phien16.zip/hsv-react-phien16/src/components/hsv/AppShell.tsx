import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";

const nav = [
  { to: "/", label: "Phân tích" },
  { to: "/lo-trinh", label: "Lộ trình" },
  { to: "/pilot", label: "Pilot React" },
  { to: "/kiem-tra", label: "Kiểm tra dữ liệu" },
  { to: "/xem-truoc", label: "Xem trước mẫu" },
  { to: "/he-cu", label: "Hệ cũ (v25.6)" },
];

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      <header className="brand-surface sticky top-0 z-40">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
          <Link to="/" className="flex items-center gap-3">
            <span className="grid size-9 place-items-center rounded-md bg-accent font-display text-sm font-extrabold text-accent-foreground">
              HSV
            </span>
            <span className="leading-tight">
              <span className="block font-display text-sm font-bold">Đề án nâng cấp HSV → React</span>
              <span className="block text-xs opacity-80">Agribank CN Thiên Trường Nam Định · KHKD</span>
            </span>
          </Link>
          <nav className="-mx-1 flex overflow-x-auto">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                activeOptions={{ exact: item.to === "/" }}
                className="mx-1 shrink-0 rounded-md px-3 py-1.5 text-sm font-medium opacity-80 transition-colors hover:bg-primary-foreground/15 data-[status=active]:bg-primary-foreground/20 data-[status=active]:opacity-100"
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-8">{children}</main>
      <footer className="border-t border-border py-6 text-center text-xs text-muted-foreground">
        Bản báo cáo phân tích v10 · 20/08/2026 · nguyên tắc strangler-fig, chỉ đọc ở GĐ 1
      </footer>
    </div>
  );
}