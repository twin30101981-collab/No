/**
 * PHIÊN 11 — GIAO DIỆN THỬA/GIẤY TỜ CỦA TỪNG TÀI SẢN BẢO ĐẢM.
 * Cột lấy từ khai báo THUA_COLUMNS; câu ghép trong hợp đồng thế chấp
 * sinh thẳng từ dữ liệu nhập ở đây, cán bộ không gõ lại trong văn bản.
 */
import {
  MAX_THUA,
  TAI_SAN_TABLE,
  THUA_COLUMNS,
  emptyThua,
  thuaCuaTaiSan,
  type ThuaByTaiSan,
  type ThuaIssue,
} from "@/lib/hsv/taiSanChiTiet";
import { formatMoney, toNumber, type TableRows } from "@/lib/hsv/tableMeta";

interface Props {
  tables: TableRows;
  thua: ThuaByTaiSan;
  issues: ThuaIssue[];
  onChange: (assetIndex: number, rows: ReturnType<typeof emptyThua>[]) => void;
}

export function TaiSanChiTiet({ tables, thua, issues, onChange }: Props) {
  const assets = tables[TAI_SAN_TABLE] ?? [];
  const byKey = new Map(issues.map((i) => [i.key, i]));

  return (
    <section className="card-elevated overflow-hidden" data-testid="khoi-thua-tai-san">
      <div className="border-b border-border bg-secondary/60 px-5 py-3">
        <h2 className="text-sm font-bold text-foreground">
          Tài sản bảo đảm nâng cao — mỗi tài sản nhiều thửa / giấy tờ
        </h2>
        <p className="mt-0.5 text-xs text-muted-foreground">
          Hệ cũ chỉ mô tả được một thửa cho một tài sản. Ở đây mỗi tài sản có danh sách thửa riêng,
          và câu mô tả trong hợp đồng thế chấp được ghép tự động từ chính dữ liệu này.
        </p>
      </div>

      <div className="space-y-5 px-5 py-4">
        {assets.map((asset, i) => {
          const rows = thuaCuaTaiSan(thua, i);
          const loiTaiSan = byKey.get(`thua[${i}]`);
          return (
            <div key={i} className="rounded-md border border-border" data-testid={`tai-san-${i}`}>
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-3 py-2">
                <p className="text-sm font-semibold text-foreground">
                  Tài sản {i + 1}: {String(asset["tenTaiSan"] ?? "(chưa đặt tên)")}{" "}
                  <span className="font-normal text-muted-foreground">
                    · {formatMoney(toNumber(asset["giaTri"]))}
                  </span>
                </p>
                <div className="flex items-center gap-2">
                  <span
                    className="text-xs text-muted-foreground"
                    data-testid={`so-thua-${i}`}
                  >
                    {rows.length} thửa/giấy tờ
                  </span>
                  <button
                    type="button"
                    data-testid={`them-thua-${i}`}
                    disabled={rows.length >= MAX_THUA}
                    onClick={() => onChange(i, [...rows, emptyThua()])}
                    className="rounded-md border border-border px-2 py-1 text-xs disabled:opacity-50"
                  >
                    Thêm thửa
                  </button>
                </div>
              </div>

              {loiTaiSan && (
                <p
                  className="px-3 py-2 text-xs font-medium text-destructive"
                  data-testid={`loi-thua-${i}`}
                >
                  {loiTaiSan.label}: {loiTaiSan.message}
                </p>
              )}

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-secondary/40 text-left text-xs text-muted-foreground">
                      {THUA_COLUMNS.map((c) => (
                        <th key={c.key} className="px-2 py-1.5 font-medium">
                          {c.label}
                          {c.required && <span className="text-destructive"> *</span>}
                        </th>
                      ))}
                      <th className="px-2 py-1.5" />
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((row, j) => (
                      <tr key={j} className="border-t border-border align-top">
                        {THUA_COLUMNS.map((c) => {
                          const issue = byKey.get(`thua[${i}][${j}].${c.key}`);
                          return (
                            <td key={c.key} className="px-2 py-1.5">
                              <input
                                value={String(row[c.key] ?? "")}
                                aria-label={`${c.label} — tài sản ${i + 1} thửa ${j + 1}`}
                                aria-invalid={issue ? true : undefined}
                                data-testid={`o-thua-${i}-${j}-${c.key}`}
                                onChange={(e) => {
                                  const next = rows.map((r, k) =>
                                    k === j ? { ...r, [c.key]: e.target.value } : r,
                                  );
                                  onChange(i, next);
                                }}
                                className="w-full rounded-md border border-input bg-background px-2 py-1 text-sm outline-none focus:border-ring aria-[invalid=true]:border-destructive"
                              />
                              {issue && (
                                <p
                                  className="mt-1 text-[11px] font-medium text-destructive"
                                  data-testid={`loi-thua-${i}-${j}-${c.key}`}
                                >
                                  {issue.message}
                                </p>
                              )}
                            </td>
                          );
                        })}
                        <td className="px-2 py-1.5">
                          <button
                            type="button"
                            data-testid={`xoa-thua-${i}-${j}`}
                            onClick={() => onChange(i, rows.filter((_, k) => k !== j))}
                            className="rounded-md border border-border px-2 py-1 text-xs"
                          >
                            Xoá
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
