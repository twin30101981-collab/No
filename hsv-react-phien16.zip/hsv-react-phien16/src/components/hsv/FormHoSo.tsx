/**
 * PHIÊN 10 (PHẦN 2 — 10B) — FORM NHẬP HỒ SƠ SINH TỪ FIELD_META.
 * Một component duy nhất: nhãn, kiểu ô, trường bắt buộc và thông báo lỗi đều
 * lấy từ khai báo; thêm trường mới trong FIELD_META là form tự có ô nhập.
 */
import type { FieldMeta, HoSo } from "@/lib/hsv/fieldMeta";
import type { Issue } from "@/lib/hsv/validation";
import {
  DERIVED_FIELD_SOURCE,
  GROUP_LABEL,
  derivedFields,
  fieldsOfGroup,
  isDerivedField,
} from "@/lib/hsv/hoSoDraft";

interface Props {
  groups: readonly FieldMeta["group"][];
  hoSo: HoSo;
  issues: Issue[];
  onChange: (key: string, value: string) => void;
}

export function FormHoSo({ groups, hoSo, issues, onChange }: Props) {
  const byKey = new Map(issues.map((i) => [i.key, i]));

  const renderField = (f: FieldMeta) => {
    const issue = byKey.get(f.key);
    const derived = isDerivedField(f.key);
    return (
      <div key={f.key}>
        <label
          htmlFor={`hoso-${f.key}`}
          className="block text-xs font-medium text-muted-foreground"
        >
          {f.label}
          {f.required && <span className="text-destructive"> *</span>}
          {derived && <span className="text-muted-foreground"> (tự tính)</span>}
        </label>
        <input
          id={`hoso-${f.key}`}
          value={String(hoSo[f.key] ?? "")}
          onChange={(e) => onChange(f.key, e.target.value)}
          readOnly={derived}
          aria-readonly={derived || undefined}
          aria-invalid={issue ? true : undefined}
          inputMode={
            f.kind === "money" || f.kind === "number" || f.kind === "percent" ? "numeric" : "text"
          }
          data-testid={`o-hoso-${f.key}`}
          className="mt-1 w-full rounded-md border border-input bg-background px-2 py-1.5 text-sm text-foreground outline-none focus:border-ring read-only:bg-secondary/60 read-only:text-muted-foreground aria-[invalid=true]:border-destructive aria-[invalid=true]:ring-1 aria-[invalid=true]:ring-destructive"
        />
        {derived && (
          <p className="mt-1 text-[11px] text-muted-foreground" data-testid={`nguon-hoso-${f.key}`}>
            Tự tính từ bảng «{DERIVED_FIELD_SOURCE[f.key]}» — không sửa tay.
          </p>
        )}
        {issue && (
          <p
            className="mt-1 text-xs font-medium text-destructive"
            data-testid={`loi-hoso-${f.key}`}
          >
            {f.label}: {issue.message}
          </p>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {groups.map((group) => {
        const fields = fieldsOfGroup(group);
        const soLoi = fields.filter((f) => byKey.has(f.key)).length;
        return (
          <section key={group} className="card-elevated overflow-hidden" data-form-group={group}>
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border bg-secondary/60 px-5 py-3">
              <div>
                <h2 className="text-sm font-bold text-foreground">
                  Hồ sơ — nhóm {GROUP_LABEL[group]}
                </h2>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  {fields.length} ô nhập sinh từ FIELD_META
                </p>
              </div>
              {soLoi > 0 && (
                <span
                  className="text-xs font-semibold text-destructive"
                  data-testid={`so-loi-hoso-${group}`}
                >
                  {soLoi} lỗi
                </span>
              )}
            </div>

            <div className="grid gap-4 px-5 py-4 sm:grid-cols-2 lg:grid-cols-3">
              {fields.map(renderField)}
            </div>
          </section>
        );
      })}

      <section className="card-elevated overflow-hidden" data-form-group="suy-ra">
        <div className="border-b border-border bg-secondary/60 px-5 py-3">
          <h2 className="text-sm font-bold text-foreground">
            Trường suy ra từ bảng lặp — chỉ đọc
          </h2>
          <p className="mt-0.5 text-xs text-muted-foreground">
            Cán bộ không gõ lại các số tổng và phần “bằng chữ”: giá trị chảy thẳng từ bảng lặp bên
            dưới nên văn bản không bao giờ lệch số.
          </p>
        </div>
        <div className="grid gap-4 px-5 py-4 sm:grid-cols-2 lg:grid-cols-4">
          {derivedFields().map(renderField)}
        </div>
      </section>
    </div>
  );
}
