/**
 * PHIÊN 15 — “Đúng ngay từ đầu”:
 *  (1) quy tắc nghiệp vụ theo sản phẩm vay, (2) lịch trả nợ tự sinh,
 *  (3) lưới kiểm tra CSV trước khi tạo hồ sơ, (4) báo cáo phiên ra XLSX.
 * Thuần trình bày: mọi phép tính nằm ở lib/hsv/*.
 */
import { useMemo, useState } from "react";
import {
  SAN_PHAM,
  kiemTraSanPham,
  quyTac,
  thamSoTuHoSo,
  tomTatQuyTac,
  soVn,
  type SanPhamId,
} from "@/lib/hsv/quyTacSanPham";
import { taoLichTraNo, tienVn, type KieuTraNo } from "@/lib/hsv/lichTraNo";
import {
  datO,
  dungLuoi,
  loiLuoi,
  luoiThanhCsv,
  thongKeLuoi,
  tomTatLuoi,
  xoaDong,
  type LuoiCsv,
} from "@/lib/hsv/luoiCsv";
import type { HoSo } from "@/lib/hsv/fieldMeta";

interface Props {
  hoSo: HoSo;
  csv: string;
  onTaoTuLuoi: (csv: string) => void;
  onXuatBaoCao: () => void;
  thongBaoBaoCao: string;
  dangXuatBaoCao: boolean;
}

export function CongCuPhien15({
  hoSo,
  csv,
  onTaoTuLuoi,
  onXuatBaoCao,
  thongBaoBaoCao,
  dangXuatBaoCao,
}: Props) {
  const [sanPham, setSanPham] = useState<SanPhamId>("ngan-han-sxkd");
  const [kyThang, setKyThang] = useState(3);
  const [kieu, setKieu] = useState<KieuTraNo>("goc-deu");
  const [soThang, setSoThang] = useState(12);
  const [luoi, setLuoi] = useState<LuoiCsv | null>(null);

  const q = quyTac(sanPham);
  const ts = useMemo(() => {
    const goc = thamSoTuHoSo(hoSo, kyThang);
    return { ...goc, soThang: goc.soThang ?? soThang };
  }, [hoSo, kyThang, soThang]);
  const canhBao = useMemo(() => kiemTraSanPham(sanPham, ts), [sanPham, ts]);

  const lich = useMemo(
    () =>
      taoLichTraNo({
        soTien: ts.soTien ?? 0,
        laiSuatNam: ts.laiSuat ?? 0,
        soThang: ts.soThang ?? 0,
        kyThang,
        kieu,
        ngayBatDau: String(hoSo["ngayHopDongTinDung"] ?? ""),
      }),
    [ts, kyThang, kieu, hoSo],
  );

  const loiO = useMemo(() => (luoi ? loiLuoi(luoi) : new Map<string, string>()), [luoi]);
  const tk = useMemo(
    () => (luoi ? thongKeLuoi(luoi, loiO) : null),
    [luoi, loiO],
  );

  return (
    <section className="card-elevated px-5 py-4" data-testid="khoi-cong-cu-phien15">
      <h2 className="text-base font-bold text-foreground">
        Đúng ngay từ đầu: quy tắc sản phẩm · lịch trả nợ · lưới kiểm tra CSV · báo cáo phiên
      </h2>
      <p className="mt-1 max-w-3xl text-xs text-muted-foreground">
        Sai hạn mức, sai thời hạn hay sai bảng kỳ trả nợ chỉ lộ ra khi hồ sơ đã lên thẩm định.
        Phiên 15 đưa các quy định của <strong>từng sản phẩm vay</strong> vào ngay lúc gõ, tự sinh
        bảng kỳ trả nợ, bắt lỗi bảng Excel <strong>trước khi</strong> tạo hồ sơ và xuất báo cáo
        danh mục cho lãnh đạo phòng. Hệ cũ vẫn <strong>chỉ đọc</strong>.
      </p>

      {/* (1) QUY TẮC SẢN PHẨM */}
      <div className="mt-4 rounded-md border border-border p-3" data-testid="khoi-quy-tac">
        <h3 className="text-sm font-bold text-foreground">1 · Quy tắc nghiệp vụ theo sản phẩm vay</h3>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <label className="text-xs text-muted-foreground" htmlFor="chon-san-pham">
            Sản phẩm vay
          </label>
          <select
            id="chon-san-pham"
            value={sanPham}
            onChange={(e) => setSanPham(e.target.value as SanPhamId)}
            data-testid="chon-san-pham"
            className="rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground"
          >
            {SAN_PHAM.map((s) => (
              <option key={s.id} value={s.id}>
                {s.ten}
              </option>
            ))}
          </select>
          <span className="text-xs text-muted-foreground" data-testid="mo-ta-san-pham">
            {q.moTa} Hạn mức {tienVn(q.soTienToiDa)} đ · tối đa {q.thangToiDa} tháng ·
            {q.tyLeTsbdToiDa > 0 ? ` ≤ ${q.tyLeTsbdToiDa}% giá trị TSBĐ` : " không bắt buộc TSBĐ"} ·
            lãi suất {q.laiSuatMin}–{q.laiSuatMax}%/năm.
          </span>
        </div>
        <p className="mt-2 text-sm font-medium text-foreground" data-testid="tom-tat-quy-tac">
          {tomTatQuyTac(sanPham, canhBao)}
        </p>
        {canhBao.length > 0 && (
          <ul className="mt-1 flex flex-col gap-1 text-sm" data-testid="danh-sach-canh-bao">
            {canhBao.map((c) => (
              <li
                key={c.ma}
                data-testid={`canh-bao-${c.ma}`}
                className={
                  c.muc === "chan" ? "font-medium text-destructive" : "text-muted-foreground"
                }
              >
                {c.muc === "chan" ? "Chặn: " : "Cảnh báo: "}
                {c.thongBao}
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* (2) LỊCH TRẢ NỢ */}
      <div className="mt-4 rounded-md border border-border p-3" data-testid="khoi-lich-tra-no">
        <h3 className="text-sm font-bold text-foreground">2 · Lịch trả nợ tự sinh</h3>
        <div className="mt-2 flex flex-wrap items-end gap-3">
          <label className="flex flex-col text-xs text-muted-foreground">
            Thời hạn (tháng)
            <input
              type="number"
              min={1}
              value={soThang}
              onChange={(e) => setSoThang(Number(e.target.value) || 0)}
              data-testid="o-so-thang"
              className="mt-1 w-28 rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground"
            />
          </label>
          <label className="flex flex-col text-xs text-muted-foreground">
            Kỳ trả nợ (tháng)
            <input
              type="number"
              min={1}
              value={kyThang}
              onChange={(e) => setKyThang(Number(e.target.value) || 1)}
              data-testid="o-ky-thang"
              className="mt-1 w-28 rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground"
            />
          </label>
          <label className="flex flex-col text-xs text-muted-foreground">
            Cách trả
            <select
              value={kieu}
              onChange={(e) => setKieu(e.target.value as KieuTraNo)}
              data-testid="chon-kieu-tra"
              className="mt-1 rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground"
            >
              <option value="goc-deu">Gốc đều, lãi giảm dần</option>
              <option value="nien-kim">Niên kim (tổng cố định mỗi kỳ)</option>
            </select>
          </label>
          <span className="text-xs text-muted-foreground" data-testid="nguon-lich">
            Số tiền vay {ts.soTien !== null ? `${tienVn(ts.soTien)} đ` : "chưa có"} · lãi suất{" "}
            {ts.laiSuat ?? 0}%/năm (lấy từ hồ sơ đang soạn).
          </span>
        </div>

        {lich.loi.length > 0 ? (
          <p className="mt-2 text-sm font-medium text-destructive" data-testid="loi-lich">
            {lich.loi.join(" ")}
          </p>
        ) : (
          <>
            <p className="mt-2 text-sm font-medium text-foreground" data-testid="tom-tat-lich">
              {lich.ky.length} kỳ trả nợ — tổng gốc {tienVn(lich.tongGoc)} đ, tổng lãi{" "}
              {tienVn(lich.tongLai)} đ, tổng phải trả {tienVn(lich.tongPhaiTra)} đ.
            </p>
            <div className="mt-2 max-h-64 overflow-auto rounded-md border border-border">
              <table className="w-full text-xs" data-testid="bang-lich-tra-no">
                <thead className="bg-secondary text-secondary-foreground">
                  <tr>
                    <th className="px-2 py-1 text-left">Kỳ</th>
                    <th className="px-2 py-1 text-left">Mốc</th>
                    <th className="px-2 py-1 text-right">Gốc</th>
                    <th className="px-2 py-1 text-right">Lãi</th>
                    <th className="px-2 py-1 text-right">Tổng</th>
                    <th className="px-2 py-1 text-right">Dư nợ còn</th>
                  </tr>
                </thead>
                <tbody>
                  {lich.ky.map((k) => (
                    <tr key={k.ky} data-testid={`ky-${k.ky}`} className="border-t border-border">
                      <td className="px-2 py-1">{k.ky}</td>
                      <td className="px-2 py-1">{k.moc}</td>
                      <td className="px-2 py-1 text-right font-mono">{tienVn(k.goc)}</td>
                      <td className="px-2 py-1 text-right font-mono">{tienVn(k.lai)}</td>
                      <td className="px-2 py-1 text-right font-mono">{tienVn(k.tong)}</td>
                      <td className="px-2 py-1 text-right font-mono">{tienVn(k.duNoConLai)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      {/* (3) LƯỚI KIỂM TRA CSV */}
      <div className="mt-4 rounded-md border border-border p-3" data-testid="khoi-luoi-csv">
        <h3 className="text-sm font-bold text-foreground">
          3 · Kiểm tra bảng CSV trước khi tạo hồ sơ
        </h3>
        <p className="mt-1 text-xs text-muted-foreground">
          Lấy nội dung đang có ở ô nhập hàng loạt (mục 2 của phiên 14) dựng thành lưới. Ô sai kiểu
          hoặc thiếu trường bắt buộc bị tô đỏ, sửa ngay tại chỗ; chỉ khi hết ô đỏ mới tạo hồ sơ.
        </p>
        <div className="mt-2 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setLuoi(dungLuoi(csv))}
            data-testid="xem-truoc-luoi"
            className="rounded-md border border-border px-3 py-2 text-sm"
          >
            Xem trước bảng dưới dạng lưới
          </button>
          <button
            type="button"
            disabled={!luoi || !tk || tk.soOSai > 0 || luoi.dong.length === 0}
            onClick={() => {
              if (!luoi) return;
              onTaoTuLuoi(luoiThanhCsv(luoi));
              setLuoi(null);
            }}
            data-testid="tao-ho-so-tu-luoi"
            className="rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50"
          >
            Tạo hồ sơ từ lưới đã sửa
          </button>
        </div>

        {luoi && (
          <div className="mt-2">
            <p className="text-sm font-medium text-foreground" data-testid="tom-tat-luoi">
              {luoi.loi.length > 0 ? luoi.loi.join(" ") : tomTatLuoi(tk!, luoi.dong.length)}
            </p>
            {tk && tk.cotLa.length > 0 && (
              <p className="text-xs text-muted-foreground" data-testid="cot-la">
                Cột không khớp FIELD_META (sẽ bỏ qua): {tk.cotLa.join(", ")}
              </p>
            )}
            {luoi.dong.length > 0 && (
              <div className="mt-2 overflow-auto rounded-md border border-border">
                <table className="w-full text-xs" data-testid="luoi-csv">
                  <thead className="bg-secondary text-secondary-foreground">
                    <tr>
                      <th className="px-2 py-1 text-left">#</th>
                      {luoi.cot.map((c, ci) => (
                        <th key={`${c.tieuDe}-${ci}`} className="px-2 py-1 text-left">
                          {c.tieuDe}
                          <span className="block font-normal text-[10px] text-muted-foreground">
                            {c.key ?? "không khớp"}
                          </span>
                        </th>
                      ))}
                      <th className="px-2 py-1" />
                    </tr>
                  </thead>
                  <tbody>
                    {luoi.dong.map((r, ri) => (
                      <tr key={ri} className="border-t border-border">
                        <td className="px-2 py-1 text-muted-foreground">{ri + 1}</td>
                        {r.map((v, ci) => {
                          const e = loiO.get(`${ri}:${ci}`);
                          return (
                            <td key={ci} className="px-1 py-1">
                              <input
                                value={v}
                                title={e ?? ""}
                                aria-invalid={e ? true : undefined}
                                onChange={(ev) => setLuoi(datO(luoi, ri, ci, ev.target.value))}
                                data-testid={`o-luoi-${ri}-${ci}`}
                                data-sai={e ? "1" : undefined}
                                className={`w-40 rounded-md border px-2 py-1 text-xs ${
                                  e
                                    ? "border-destructive bg-destructive/10 text-destructive"
                                    : "border-border bg-background text-foreground"
                                }`}
                              />
                            </td>
                          );
                        })}
                        <td className="px-2 py-1">
                          <button
                            type="button"
                            onClick={() => setLuoi(xoaDong(luoi, ri))}
                            data-testid={`xoa-dong-luoi-${ri}`}
                            className="rounded-md border border-border px-2 py-1 text-xs"
                          >
                            Bỏ dòng
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            {loiO.size > 0 && (
              <ul className="mt-1 text-xs font-medium text-destructive" data-testid="loi-luoi">
                {[...loiO.entries()].slice(0, 5).map(([k, v]) => (
                  <li key={k}>
                    Dòng {Number(k.split(":")[0]) + 1}: {v}
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </div>

      {/* (4) BÁO CÁO XLSX */}
      <div className="mt-4 rounded-md border border-border p-3" data-testid="khoi-bao-cao">
        <h3 className="text-sm font-bold text-foreground">4 · Báo cáo phiên làm việc (XLSX)</h3>
        <p className="mt-1 text-xs text-muted-foreground">
          Xuất một tệp Excel tổng hợp toàn bộ danh mục hồ sơ trong phiên: trạng thái đủ/thiếu
          trường, số lỗi chặn, đã xuất tài liệu hay chưa, thời điểm sửa gần nhất — gửi lãnh đạo
          phòng không phải hỏi từng người.
        </p>
        <button
          type="button"
          onClick={onXuatBaoCao}
          disabled={dangXuatBaoCao}
          data-testid="xuat-bao-cao-xlsx"
          className="mt-2 rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60"
        >
          {dangXuatBaoCao ? "Đang tạo báo cáo…" : "Xuất báo cáo XLSX"}
        </button>
        {thongBaoBaoCao && (
          <p className="mt-2 text-sm font-medium text-foreground" data-testid="ket-qua-bao-cao">
            {thongBaoBaoCao}
          </p>
        )}
      </div>
    </section>
  );
}

/** Dùng lại ở test đơn giản: số tiền hiển thị được. */
export const _soVn = soVn;
