/**
 * PHIÊN 14 — khối công cụ giảm thao tác tay:
 *  (1) mẫu dữ liệu dùng lại, (2) nhập hàng loạt từ CSV/Excel,
 *  (3) nhật ký thao tác + hoàn tác.
 * Giao diện thuần trình bày: mọi phép biến đổi nằm ở lib/hsv/*.
 */
import { useRef, useState } from "react";
import {
  tomTatMau,
  truongDungChung,
  type MauDungLai,
} from "@/lib/hsv/mauDungLai";
import { CSV_MAU } from "@/lib/hsv/nhapHangLoat";
import { nhanGio, tomTatNhatKy, type MocNhatKy } from "@/lib/hsv/nhatKy";

interface Props {
  // (1) Mẫu dùng lại
  mauDs: MauDungLai[];
  onLuuMau: (ten: string) => void;
  onApMau: (id: string, ghiDe: boolean) => void;
  onXoaMau: (id: string) => void;
  thongBaoMau: string;
  // (2) Nhập hàng loạt
  csv: string;
  onCsv: (v: string) => void;
  onNhapCsv: () => void;
  onTepCsv: (file: File) => void;
  thongBaoCsv: string;
  loiCsv: string[];
  // (3) Nhật ký
  nhatKy: MocNhatKy[];
  onHoanTac: () => void;
  thongBaoHoanTac: string;
}

export function CongCuPhien14({
  mauDs,
  onLuuMau,
  onApMau,
  onXoaMau,
  thongBaoMau,
  csv,
  onCsv,
  onNhapCsv,
  onTepCsv,
  thongBaoCsv,
  loiCsv,
  nhatKy,
  onHoanTac,
  thongBaoHoanTac,
}: Props) {
  const [tenMau, setTenMau] = useState("Mẫu chi nhánh Thiên Trường");
  const [ghiDe, setGhiDe] = useState(false);
  const inputCsv = useRef<HTMLInputElement>(null);
  const truong = truongDungChung();

  return (
    <section className="card-elevated px-5 py-4" data-testid="khoi-cong-cu-phien14">
      <h2 className="text-base font-bold text-foreground">
        Giảm gõ lại: mẫu dùng lại · nhập hàng loạt · hoàn tác
      </h2>
      <p className="mt-1 max-w-3xl text-xs text-muted-foreground">
        Ba việc lặp đi lặp lại nhiều nhất trong ngày được rút gọn: bộ trường chung của chi nhánh
        lưu một lần dùng mãi, danh sách khách hàng từ Excel biến thành nhiều hồ sơ trong một lần
        dán, và mọi thao tác làm đổi danh mục hồ sơ đều <strong>hoàn tác được</strong>. Dữ liệu
        sinh ra vẫn qua đúng cửa kiểm tra như nhập tay; hệ cũ vẫn <strong>chỉ đọc</strong>.
      </p>

      {/* (1) MẪU DÙNG LẠI */}
      <div className="mt-4 rounded-md border border-border p-3" data-testid="khoi-mau-dung-lai">
        <h3 className="text-sm font-bold text-foreground">1 · Mẫu dữ liệu dùng lại</h3>
        <p className="mt-1 text-xs text-muted-foreground">
          Lưu {truong.length} trường dùng chung ({truong.map((t) => t.label).join(", ")}) từ hồ sơ
          đang soạn. Trường riêng của khách hàng không bao giờ được chép sang.
        </p>
        <div className="mt-2 grid gap-2 sm:grid-cols-[minmax(0,1fr)_auto_auto]">
          <input
            value={tenMau}
            onChange={(e) => setTenMau(e.target.value)}
            aria-label="Tên mẫu dùng lại"
            data-testid="o-ten-mau"
            className="rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground"
          />
          <button
            type="button"
            onClick={() => onLuuMau(tenMau)}
            data-testid="luu-mau-dung-lai"
            className="rounded-md border border-border px-3 py-2 text-sm"
          >
            Lưu mẫu từ hồ sơ đang soạn
          </button>
          <label className="flex items-center gap-2 text-xs text-muted-foreground">
            <input
              type="checkbox"
              checked={ghiDe}
              onChange={(e) => setGhiDe(e.target.checked)}
              data-testid="mau-ghi-de"
              className="size-4"
            />
            Ghi đè ô đã có
          </label>
        </div>

        {mauDs.length === 0 ? (
          <p className="mt-2 text-xs text-muted-foreground" data-testid="chua-co-mau">
            Chưa lưu mẫu nào trong phiên này.
          </p>
        ) : (
          <ul className="mt-2 flex flex-col gap-2" data-testid="danh-sach-mau">
            {mauDs.map((m) => (
              <li
                key={m.id}
                data-testid={`mau-${m.id}`}
                className="flex flex-wrap items-center gap-2 rounded-md border border-border px-3 py-2 text-sm"
              >
                <span className="font-semibold text-foreground">{m.ten}</span>
                <span className="text-xs text-muted-foreground">{tomTatMau(m)}</span>
                <button
                  type="button"
                  onClick={() => onApMau(m.id, ghiDe)}
                  data-testid={`ap-mau-${m.id}`}
                  className="ml-auto rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground"
                >
                  Áp vào hồ sơ đang soạn
                </button>
                <button
                  type="button"
                  onClick={() => onXoaMau(m.id)}
                  data-testid={`xoa-mau-${m.id}`}
                  className="rounded-md border border-border px-3 py-1.5 text-xs"
                >
                  Xoá
                </button>
              </li>
            ))}
          </ul>
        )}
        {thongBaoMau && (
          <p className="mt-2 text-sm font-medium text-foreground" data-testid="ket-qua-mau">
            {thongBaoMau}
          </p>
        )}
      </div>

      {/* (2) NHẬP HÀNG LOẠT */}
      <div className="mt-4 rounded-md border border-border p-3" data-testid="khoi-nhap-hang-loat">
        <h3 className="text-sm font-bold text-foreground">
          2 · Nhập hàng loạt danh sách khách hàng (CSV/Excel)
        </h3>
        <p className="mt-1 text-xs text-muted-foreground">
          Dán bảng từ Excel (hoặc chọn tệp .csv). Dòng đầu là tiêu đề — đặt đúng tên trường như
          “Tên khách hàng”, “Số tiền vay”. Mỗi dòng thành một hồ sơ, kế thừa trường dùng chung của
          hồ sơ đang soạn.
        </p>
        <textarea
          value={csv}
          onChange={(e) => onCsv(e.target.value)}
          rows={5}
          aria-label="Bảng CSV danh sách khách hàng"
          data-testid="o-csv"
          placeholder={CSV_MAU}
          className="mt-2 w-full rounded-md border border-border bg-background px-3 py-2 font-mono text-xs text-foreground"
        />
        <div className="mt-2 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={onNhapCsv}
            data-testid="nhap-hang-loat"
            className="rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground"
          >
            Tạo hồ sơ từ bảng
          </button>
          <button
            type="button"
            onClick={() => onCsv(CSV_MAU)}
            data-testid="dien-csv-mau"
            className="rounded-md border border-border px-3 py-2 text-sm"
          >
            Điền bảng mẫu 3 khách hàng
          </button>
          <button
            type="button"
            onClick={() => inputCsv.current?.click()}
            data-testid="mo-tep-csv"
            className="rounded-md border border-border px-3 py-2 text-sm"
          >
            Chọn tệp .csv
          </button>
          <input
            ref={inputCsv}
            type="file"
            accept=".csv,.tsv,.txt,text/csv"
            hidden
            data-testid="input-tep-csv"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onTepCsv(f);
              e.target.value = "";
            }}
          />
        </div>
        {thongBaoCsv && (
          <p className="mt-2 text-sm font-medium text-foreground" data-testid="ket-qua-csv">
            {thongBaoCsv}
          </p>
        )}
        {loiCsv.length > 0 && (
          <ul className="mt-1 text-sm font-medium text-destructive" data-testid="loi-csv">
            {loiCsv.map((l) => (
              <li key={l}>{l}</li>
            ))}
          </ul>
        )}
      </div>

      {/* (3) NHẬT KÝ + HOÀN TÁC */}
      <div className="mt-4 rounded-md border border-border p-3" data-testid="khoi-nhat-ky">
        <h3 className="text-sm font-bold text-foreground">3 · Nhật ký thao tác &amp; hoàn tác</h3>
        <div className="mt-2 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onHoanTac}
            disabled={nhatKy.length === 0}
            data-testid="hoan-tac"
            className="rounded-md border border-border px-3 py-2 text-sm font-semibold disabled:cursor-not-allowed disabled:opacity-50"
          >
            Hoàn tác thao tác gần nhất
          </button>
          <span className="text-xs text-muted-foreground" data-testid="tom-tat-nhat-ky">
            {tomTatNhatKy(nhatKy)}
          </span>
        </div>
        <ol className="mt-2 flex flex-col gap-1 text-xs" data-testid="danh-sach-nhat-ky">
          {nhatKy.map((m) => (
            <li key={m.id} data-testid={`moc-${m.id}`} className="text-muted-foreground">
              <span className="font-mono">{nhanGio(m.luc)}</span> — {m.nhan}
            </li>
          ))}
        </ol>
        {thongBaoHoanTac && (
          <p className="mt-2 text-sm font-medium text-foreground" data-testid="ket-qua-hoan-tac">
            {thongBaoHoanTac}
          </p>
        )}
      </div>
    </section>
  );
}
