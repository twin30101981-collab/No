/**
 * PHIÊN 8 (nửa sau) — COMPONENT BẢNG LẶP DÒNG DÙNG CHUNG (nhập liệu).
 * Sinh hoàn toàn từ khai báo TableMeta: cột, kiểu ô, tổng tự động, thêm/xoá dòng.
 * Không có logic riêng cho từng bảng ⇒ dùng lại cho TSBĐ, chi phí vật tư, …
 */
import {
  cellIssueKey,
  emptyRow,
  formatMoney,
  tableTotal,
  type TableMeta,
  type TableRow,
} from "@/lib/hsv/tableMeta";
import type { Issue } from "@/lib/hsv/validation";

interface Props {
  meta: TableMeta;
  rows: TableRow[];
  onChange: (rows: TableRow[]) => void;
  /** PHIÊN 9 — lỗi theo từng ô, hiện ngay dưới ô nhập sai. */
  issues?: Issue[];
}

export function BangLapDong({ meta, rows, onChange, issues = [] }: Props) {
  const total = tableTotal(meta, rows);
  const byCell = new Map(issues.map((i) => [i.key, i]));
  const soLoi = issues.length;

  const setCell = (index: number, key: string, value: string) => {
    onChange(rows.map((r, i) => (i === index ? { ...r, [key]: value } : r)));
  };
  const addRow = () => {
    if (rows.length >= meta.maxRows) return;
    onChange([...rows, emptyRow(meta)]);
  };
  const removeRow = (index: number) => {
    if (rows.length <= meta.minRows) return;
    onChange(rows.filter((_, i) => i !== index));
  };

  return (
    <section className="card-elevated overflow-hidden" data-table={meta.key}>
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border bg-secondary/60 px-5 py-3">
        <div>
          <h2 className="text-sm font-bold text-foreground">{meta.label}</h2>
          <p className="mt-0.5 text-xs text-muted-foreground">
            Hợp nhất từ: {meta.legacySources.join(" · ")}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground" data-testid={`so-dong-${meta.key}`}>
            {rows.length} dòng
          </span>
          {soLoi > 0 && (
            <span
              className="text-xs font-semibold text-destructive"
              data-testid={`so-loi-${meta.key}`}
            >
              {soLoi} lỗi
            </span>
          )}
          <button
            type="button"
            onClick={addRow}
            data-testid={`them-dong-${meta.key}`}
            className="rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground disabled:opacity-50"
            disabled={rows.length >= meta.maxRows}
          >
            Thêm dòng
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="border-b border-border text-left text-xs text-muted-foreground">
              <th className="px-3 py-2 font-medium">#</th>
              {meta.columns.map((c) => (
                <th key={c.key} className="px-3 py-2 font-medium">
                  {c.label}
                </th>
              ))}
              <th className="px-3 py-2 font-medium">Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, i) => (
              <tr key={i} className="border-b border-border/70">
                <td className="px-3 py-2 text-xs text-muted-foreground">{i + 1}</td>
                {meta.columns.map((c) => {
                  const issue = byCell.get(cellIssueKey(meta.key, i, c.key));
                  return (
                    <td key={c.key} className="px-3 py-2 align-top">
                      <input
                        value={String(row[c.key] ?? "")}
                        onChange={(e) => setCell(i, c.key, e.target.value)}
                        inputMode={c.kind === "money" || c.kind === "number" ? "numeric" : "text"}
                        aria-label={`${c.label} dòng ${i + 1}`}
                        aria-invalid={issue ? true : undefined}
                        data-testid={`o-${meta.key}-${i}-${c.key}`}
                        className="w-full rounded-md border border-input bg-background px-2 py-1.5 text-sm text-foreground outline-none focus:border-ring aria-[invalid=true]:border-destructive aria-[invalid=true]:ring-1 aria-[invalid=true]:ring-destructive"
                      />
                      {issue && (
                        <p
                          className="mt-1 text-xs font-medium text-destructive"
                          data-testid={`loi-${meta.key}-${i}-${c.key}`}
                        >
                          {c.label}: {issue.message}
                        </p>
                      )}
                    </td>
                  );
                })}
                <td className="px-3 py-2">
                  <button
                    type="button"
                    onClick={() => removeRow(i)}
                    disabled={rows.length <= meta.minRows}
                    data-testid={`xoa-dong-${meta.key}-${i}`}
                    className="rounded-md border border-border px-2 py-1 text-xs text-destructive disabled:opacity-40"
                  >
                    Xoá
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
          {meta.totalColumn && (
            <tfoot>
              <tr className="bg-secondary/40">
                <td className="px-3 py-2 text-xs font-semibold text-foreground" colSpan={meta.columns.length}>
                  Tổng cộng ({meta.columns.find((c) => c.key === meta.totalColumn)?.label})
                </td>
                <td
                  className="px-3 py-2 text-sm font-extrabold text-primary"
                  colSpan={2}
                  data-testid={`tong-bang-${meta.key}`}
                >
                  {formatMoney(total)}
                </td>
              </tr>
            </tfoot>
          )}
        </table>
      </div>
    </section>
  );
}
