/**
 * PHIÊN 16 — “Nhiều người cùng làm & lưu vết”:
 *  (1) chủ sở hữu + trạng thái luân chuyển, (2) so sánh hai phiên bản hồ sơ,
 *  (3) kiểm tra chéo giữa các tài liệu, (4) gói hồ sơ dùng chung theo phòng có
 *  khoá tránh ghi đè, (5) phiếu kiểm tra một trang trước khi trình ký.
 * Thuần trình bày: mọi quy tắc nằm ở lib/hsv/*.
 */
import { useMemo, useRef, useState } from "react";
import type { HoSo } from "@/lib/hsv/fieldMeta";
import {
  TRANG_THAI,
  nhanGioPhut,
  type BuocLuanChuyen,
  type TrangThaiHoSo,
} from "@/lib/hsv/luanChuyen";
import {
  nhanPhienBan,
  soSanhPhienBan,
  tomTatSoSanh,
  type PhienBanHoSo,
} from "@/lib/hsv/lichSuPhienBan";
import { kiemTraTaiLieu } from "@/lib/hsv/kiemTraTaiLieu";
import { dungPhieuKiemTra, vanBanPhieu } from "@/lib/hsv/phieuKiemTra";
import type { Issue } from "@/lib/hsv/validation";

interface Props {
  ten: string;
  hoSo: HoSo;
  chanXuat: Issue[];
  chuSoHuu: string;
  trangThai: TrangThaiHoSo;
  lichSu: BuocLuanChuyen[];
  phienBan: PhienBanHoSo[];
  ban: number;
  thongBaoLuanChuyen: string;
  thongBaoGoi: string;
  loiGoi: string[];
  onDatChuSoHuu: (ten: string) => void;
  onChuyen: (den: TrangThaiHoSo, nguoi: string, ghiChu: string) => void;
  onLuuPhienBan: (nhan: string, nguoi: string) => void;
  onXuatGoi: (phong: string, nguoi: string) => void;
  onNapGoi: (file: File) => void;
  onChotBan: () => void;
  onTaiPhieu: (noiDung: string, tenTep: string) => void;
}

export function CongCuPhien16({
  ten,
  hoSo,
  chanXuat,
  chuSoHuu,
  trangThai,
  lichSu,
  phienBan,
  ban,
  thongBaoLuanChuyen,
  thongBaoGoi,
  loiGoi,
  onDatChuSoHuu,
  onChuyen,
  onLuuPhienBan,
  onXuatGoi,
  onNapGoi,
  onChotBan,
  onTaiPhieu,
}: Props) {
  const [nguoi, setNguoi] = useState("");
  const [ghiChu, setGhiChu] = useState("");
  const [nhanMoc, setNhanMoc] = useState("");
  const [phong, setPhong] = useState("Phòng KHKD");
  const [pbA, setPbA] = useState("");
  const [pbB, setPbB] = useState("");
  const tepRef = useRef<HTMLInputElement>(null);

  const a = phienBan.find((p) => p.id === pbA) ?? phienBan[1] ?? phienBan[0];
  const b = phienBan.find((p) => p.id === pbB) ?? phienBan[0];
  const khac = useMemo(
    () => (a && b && a.id !== b.id ? soSanhPhienBan(a.hoSo, b.hoSo) : []),
    [a, b],
  );
  const coCap = Boolean(a && b && a.id !== b.id);

  const taiLieu = useMemo(() => kiemTraTaiLieu(hoSo), [hoSo]);
  const soLoiTaiLieu = taiLieu.filter((t) => t.loi).length;

  const phieu = useMemo(
    () => dungPhieuKiemTra({ ten, hoSo, chuSoHuu, trangThai, chanXuat }),
    [ten, hoSo, chuSoHuu, trangThai, chanXuat],
  );

  const meta = TRANG_THAI[trangThai];
  const chuyenDuoc = (den: TrangThaiHoSo) => meta.keTiep.includes(den);

  return (
    <section className="card-elevated mt-6 px-5 py-4" data-testid="khoi-cong-cu-phien16">
      <h2 className="font-display text-base font-bold text-foreground">
        Phiên 16 — Nhiều người cùng làm &amp; lưu vết
      </h2>
      <p className="mt-1 text-xs text-muted-foreground">
        Giao hồ sơ cho người phụ trách, trình – duyệt – trả lại có ghi chú, so sánh hai phiên bản,
        đối chiếu số liệu giữa các tài liệu, gửi gói dùng chung cho phòng và in phiếu kiểm tra một
        trang. Hệ cũ vẫn CHỈ ĐỌC.
      </p>

      {/* (1) Chủ sở hữu & luân chuyển */}
      <div className="mt-4 rounded-lg border border-border p-4" data-testid="khoi-luan-chuyen">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="text-sm font-semibold text-foreground">1. Chủ sở hữu &amp; luân chuyển</h3>
          <span
            className="rounded-full border border-border px-2 py-0.5 text-xs font-medium text-foreground"
            data-testid="trang-thai-ho-so"
          >
            {meta.nhan}
          </span>
          <span className="text-xs text-muted-foreground" data-testid="so-ban-ho-so">
            bản {ban}
          </span>
        </div>
        <p className="mt-1 text-xs text-muted-foreground" data-testid="mo-ta-trang-thai">
          {meta.moTa}
        </p>

        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          <label className="text-xs text-muted-foreground">
            Chủ sở hữu hồ sơ
            <input
              data-testid="o-chu-so-huu"
              value={chuSoHuu}
              onChange={(e) => onDatChuSoHuu(e.target.value)}
              placeholder="VD: Nguyễn Văn A — CBTD"
              className="mt-1 w-full rounded-md border border-border px-2 py-1.5 text-sm text-foreground"
            />
          </label>
          <label className="text-xs text-muted-foreground">
            Người thực hiện thao tác
            <input
              data-testid="o-nguoi-thuc-hien"
              value={nguoi}
              onChange={(e) => setNguoi(e.target.value)}
              placeholder="VD: Trần Thị B — KSV"
              className="mt-1 w-full rounded-md border border-border px-2 py-1.5 text-sm text-foreground"
            />
          </label>
          <label className="text-xs text-muted-foreground">
            Ghi chú / lý do trả lại
            <input
              data-testid="o-ghi-chu-luan-chuyen"
              value={ghiChu}
              onChange={(e) => setGhiChu(e.target.value)}
              placeholder="Bắt buộc khi trả lại"
              className="mt-1 w-full rounded-md border border-border px-2 py-1.5 text-sm text-foreground"
            />
          </label>
        </div>

        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            data-testid="nut-trinh"
            disabled={!chuyenDuoc("trinh")}
            onClick={() => onChuyen("trinh", nguoi, ghiChu)}
            className="rounded-md border border-border px-3 py-1.5 text-sm disabled:opacity-40"
          >
            Trình kiểm soát
          </button>
          <button
            type="button"
            data-testid="nut-duyet"
            disabled={!chuyenDuoc("duyet")}
            onClick={() => onChuyen("duyet", nguoi, ghiChu)}
            className="rounded-md border border-border px-3 py-1.5 text-sm disabled:opacity-40"
          >
            Duyệt
          </button>
          <button
            type="button"
            data-testid="nut-tra-lai"
            disabled={!chuyenDuoc("tra-lai")}
            onClick={() => onChuyen("tra-lai", nguoi, ghiChu)}
            className="rounded-md border border-border px-3 py-1.5 text-sm disabled:opacity-40"
          >
            Trả lại để sửa
          </button>
        </div>

        {thongBaoLuanChuyen && (
          <p className="mt-2 text-sm font-medium text-foreground" data-testid="thong-bao-luan-chuyen">
            {thongBaoLuanChuyen}
          </p>
        )}

        <ul className="mt-3 space-y-1 text-xs text-foreground" data-testid="lich-su-luan-chuyen">
          {lichSu.length === 0 && (
            <li className="text-muted-foreground">Chưa có lần chuyển nào trong phiên làm việc.</li>
          )}
          {lichSu.map((b2) => (
            <li key={b2.id} data-testid="dong-luan-chuyen">
              {nhanGioPhut(b2.luc)} · {b2.nguoi}: {TRANG_THAI[b2.tu].nhan} → {TRANG_THAI[b2.den].nhan}
              {b2.ghiChu ? ` — ${b2.ghiChu}` : ""}
            </li>
          ))}
        </ul>
      </div>

      {/* (2) So sánh hai phiên bản */}
      <div className="mt-4 rounded-lg border border-border p-4" data-testid="khoi-phien-ban">
        <h3 className="text-sm font-semibold text-foreground">2. So sánh hai phiên bản hồ sơ</h3>
        <div className="mt-2 flex flex-wrap items-end gap-2">
          <label className="text-xs text-muted-foreground">
            Tên mốc lưu
            <input
              data-testid="o-nhan-phien-ban"
              value={nhanMoc}
              onChange={(e) => setNhanMoc(e.target.value)}
              placeholder="VD: Trước khi sửa theo ý kiến KSV"
              className="mt-1 w-56 rounded-md border border-border px-2 py-1.5 text-sm text-foreground"
            />
          </label>
          <button
            type="button"
            data-testid="nut-luu-phien-ban"
            onClick={() => {
              onLuuPhienBan(nhanMoc, nguoi || chuSoHuu);
              setNhanMoc("");
            }}
            className="rounded-md border border-border px-3 py-1.5 text-sm"
          >
            Lưu mốc phiên bản
          </button>
          <span className="text-xs text-muted-foreground" data-testid="so-phien-ban">
            {phienBan.length} mốc đã lưu
          </span>
        </div>

        <div className="mt-3 flex flex-wrap gap-2">
          <select
            data-testid="chon-phien-ban-a"
            value={a?.id ?? ""}
            onChange={(e) => setPbA(e.target.value)}
            className="rounded-md border border-border px-2 py-1.5 text-sm text-foreground"
          >
            {phienBan.map((p) => (
              <option key={p.id} value={p.id}>
                {nhanPhienBan(p)}
              </option>
            ))}
          </select>
          <select
            data-testid="chon-phien-ban-b"
            value={b?.id ?? ""}
            onChange={(e) => setPbB(e.target.value)}
            className="rounded-md border border-border px-2 py-1.5 text-sm text-foreground"
          >
            {phienBan.map((p) => (
              <option key={p.id} value={p.id}>
                {nhanPhienBan(p)}
              </option>
            ))}
          </select>
        </div>

        <p className="mt-2 text-sm text-foreground" data-testid="tom-tat-so-sanh">
          {coCap ? tomTatSoSanh(khac) : "Cần ít nhất hai mốc lưu khác nhau để so sánh."}
        </p>

        {coCap && khac.length > 0 && (
          <table className="mt-2 w-full text-left text-xs" data-testid="bang-so-sanh">
            <thead className="text-muted-foreground">
              <tr>
                <th className="py-1">Trường</th>
                <th className="py-1">Trước</th>
                <th className="py-1">Sau</th>
              </tr>
            </thead>
            <tbody>
              {khac.map((k) => (
                <tr key={k.key} className="border-t border-border" data-testid={`khac-${k.key}`}>
                  <td className="py-1 pr-2 font-medium text-foreground">{k.label}</td>
                  <td className="py-1 pr-2 text-muted-foreground">{k.truoc || "(trống)"}</td>
                  <td className="py-1 text-foreground">{k.sau || "(trống)"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* (3) Kiểm tra chéo giữa các tài liệu */}
      <div className="mt-4 rounded-lg border border-border p-4" data-testid="khoi-kiem-tra-tai-lieu">
        <h3 className="text-sm font-semibold text-foreground">
          3. Đối chiếu giữa các tài liệu —{" "}
          <span data-testid="so-loi-tai-lieu">{soLoiTaiLieu}</span> điểm lệch
        </h3>
        <ul className="mt-2 space-y-2">
          {taiLieu.map((k) => (
            <li key={k.rule.key} data-testid={`tai-lieu-${k.rule.key}`} className="text-xs">
              <span className="font-medium text-foreground">{k.rule.nhan}</span>{" "}
              <span className="text-muted-foreground">({k.rule.taiLieu.join(" · ")})</span>
              <p className="text-muted-foreground">{k.rule.moTa(hoSo)}</p>
              {k.loi && (
                <p
                  className="font-medium text-destructive"
                  data-testid={`tai-lieu-loi-${k.rule.key}`}
                >
                  Lệch: {k.loi}
                </p>
              )}
            </li>
          ))}
        </ul>
      </div>

      {/* (4) Gói dùng chung theo phòng */}
      <div className="mt-4 rounded-lg border border-border p-4" data-testid="khoi-goi-phong">
        <h3 className="text-sm font-semibold text-foreground">4. Danh mục dùng chung theo phòng</h3>
        <div className="mt-2 flex flex-wrap items-end gap-2">
          <label className="text-xs text-muted-foreground">
            Tên phòng
            <input
              data-testid="o-ten-phong"
              value={phong}
              onChange={(e) => setPhong(e.target.value)}
              className="mt-1 w-48 rounded-md border border-border px-2 py-1.5 text-sm text-foreground"
            />
          </label>
          <button
            type="button"
            data-testid="nut-chot-ban"
            onClick={onChotBan}
            className="rounded-md border border-border px-3 py-1.5 text-sm"
          >
            Chốt bản để gửi (tăng số bản)
          </button>
          <button
            type="button"
            data-testid="nut-xuat-goi"
            onClick={() => onXuatGoi(phong, nguoi || chuSoHuu)}
            className="rounded-md border border-border px-3 py-1.5 text-sm"
          >
            Xuất gói dùng chung
          </button>
          <button
            type="button"
            data-testid="nut-mo-nap-goi"
            onClick={() => tepRef.current?.click()}
            className="rounded-md border border-border px-3 py-1.5 text-sm"
          >
            Nạp gói của đồng nghiệp
          </button>
          <input
            ref={tepRef}
            type="file"
            accept=".json"
            data-testid="o-nap-goi"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onNapGoi(f);
              e.target.value = "";
            }}
          />
        </div>
        {thongBaoGoi && (
          <p className="mt-2 text-sm font-medium text-foreground" data-testid="thong-bao-goi">
            {thongBaoGoi}
          </p>
        )}
        {loiGoi.length > 0 && (
          <ul className="mt-1 space-y-0.5 text-xs text-destructive" data-testid="loi-goi">
            {loiGoi.map((l, i) => (
              <li key={i}>{l}</li>
            ))}
          </ul>
        )}
      </div>

      {/* (5) Phiếu kiểm tra một trang */}
      <div className="mt-4 rounded-lg border border-border p-4" data-testid="khoi-phieu-kiem-tra">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="text-sm font-semibold text-foreground">5. Phiếu kiểm tra một trang</h3>
          <button
            type="button"
            data-testid="nut-tai-phieu"
            onClick={() =>
              onTaiPhieu(vanBanPhieu(phieu), `phieu-kiem-tra-${ten.replace(/\s+/g, "-")}.txt`)
            }
            className="rounded-md border border-border px-3 py-1.5 text-sm"
          >
            Tải phiếu (.txt)
          </button>
        </div>
        <div className="mt-2 rounded-md border border-border p-3">
          <p className="font-display text-sm font-bold text-foreground">{phieu.tieuDe}</p>
          <p className="text-xs text-muted-foreground">
            {phieu.ten} · chủ sở hữu: {phieu.chuSoHuu} · {phieu.trangThai}
          </p>
          <p className="text-xs text-muted-foreground">{phieu.dongNgay}</p>
          <ul className="mt-2 space-y-1 text-xs">
            {phieu.mucs.map((m) => (
              <li key={m.nhan} data-testid={`phieu-muc-${m.dat ? "dat" : "chua"}`}>
                <span className="font-medium text-foreground">
                  [{m.dat ? "x" : " "}] {m.nhan}
                </span>
                {m.chiTiet.slice(0, 4).map((c, i) => (
                  <p key={i} className="text-destructive">
                    – {c}
                  </p>
                ))}
              </li>
            ))}
          </ul>
          <p
            className="mt-2 text-sm font-semibold text-foreground"
            data-testid="phieu-ket-luan"
          >
            {phieu.dat ? "ĐỦ ĐIỀU KIỆN TRÌNH KÝ" : "CHƯA ĐỦ — xem các mục còn trống"}
          </p>
        </div>
      </div>
    </section>
  );
}
