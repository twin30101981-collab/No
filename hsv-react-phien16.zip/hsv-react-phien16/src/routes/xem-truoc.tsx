import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { AppShell } from "@/components/hsv/AppShell";
import {
  TEMPLATES,
  deadLabels,
  renderTemplate,
  templateLabels,
  templateTableAnchors,
} from "@/lib/hsv/docTemplate";
import { applyDerived, derivedValues } from "@/lib/hsv/derived";
import { demoRows, initialTableRows } from "@/lib/hsv/repeatableData";
import { TABLE_META, formatMoney, type TableRows } from "@/lib/hsv/tableMeta";
import { BangLapDong } from "@/components/hsv/BangLapDong";
import { type HoSo } from "@/lib/hsv/fieldMeta";
import { FormHoSo } from "@/components/hsv/FormHoSo";
import {
  FORM_GROUPS,
  clearHoSoDraft,
  formFields,
  initialHoSo,
  isDerivedField,
  makeThieuBatBuoc,
  readHoSoDraft,
  writeHoSoDraft,
} from "@/lib/hsv/hoSoDraft";
import { blockingIssues } from "@/lib/hsv/exportGuard";
import { TaiSanChiTiet } from "@/components/hsv/TaiSanChiTiet";
import {
  THUA_STORAGE_KEY,
  applyTaiSanChiTiet,
  demoThua,
  soThuaTong,
  tongDienTich,
  validateThua,
  type ThuaByTaiSan,
} from "@/lib/hsv/taiSanChiTiet";
import { crossResults } from "@/lib/hsv/crossChecks";
import { validateHoSo, validateTables } from "@/lib/hsv/validation";
import { DanhSachHoSo } from "@/components/hsv/DanhSachHoSo";
import {
  activeItem,
  capNhatHoSoDangChon,
  chonHoSo,
  doiTenHoSo,
  emptyHoSoItem,
  initialWorkspace,
  danhDauDaXuat,
  nhanBanHoSo,
  readWorkspace,
  themHoSo,
  themNhieuHoSo,
  writeWorkspace,
  xoaHoSo,
  type SapXepHoSo,
  type HoSoItem,
  type Workspace,
} from "@/lib/hsv/hoSoWorkspace";
import { docTepBoHoSo, taoTepBoHoSo, taiTep } from "@/lib/hsv/hoSoFile";
// PHIÊN 14 — mẫu dùng lại, nhập hàng loạt CSV, nhật ký + hoàn tác.
import { CongCuPhien14 } from "@/components/hsv/CongCuPhien14";
// PHIÊN 15 — quy tắc sản phẩm, lịch trả nợ, lưới kiểm tra CSV, báo cáo XLSX.
import { CongCuPhien15 } from "@/components/hsv/CongCuPhien15";
// PHIÊN 16 — chủ sở hữu & luân chuyển, so sánh phiên bản, đối chiếu tài liệu,
// gói dùng chung theo phòng, phiếu kiểm tra một trang.
import { CongCuPhien16 } from "@/components/hsv/CongCuPhien16";
import {
  TRANG_THAI_MAC_DINH,
  chuyenTrangThai,
  type TrangThaiHoSo,
} from "@/lib/hsv/luanChuyen";
import { luuPhienBan } from "@/lib/hsv/lichSuPhienBan";
import { docGoiPhong, gopGoiPhong, taoGoiPhong, tangBan, tomTatGop } from "@/lib/hsv/goiPhong";
import {
  TRUONG_DUNG_CHUNG,
  apDungMau,
  readMau,
  soOSeDoi,
  taoMauTuHoSo,
  themMau,
  writeMau,
  xoaMau as xoaMauKhoi,
  type MauDungLai,
} from "@/lib/hsv/mauDungLai";
import { nhapHangLoat, tomTatNhapHangLoat } from "@/lib/hsv/nhapHangLoat";
import { ghiMoc, hoanTac as hoanTacNhatKy, type MocNhatKy } from "@/lib/hsv/nhatKy";
import { nhapTuHeCu, tomTatNhap } from "@/lib/hsv/legacyImport";
import { dongDiaDiemNgay, oNhanKy } from "@/lib/hsv/kyDuyet";

/** PHIÊN 9 — bản nháp bảng lặp giữ trong bộ nhớ PHIÊN của trình duyệt. */
const STORAGE_KEY = "hsv.bangLap.v1";

function readStored(): TableRows | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.sessionStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as TableRows) : null;
  } catch {
    return null;
  }
}

const title = "Soạn hồ sơ & xuất mẫu văn bản DOCX (GĐ2)";
const description =
  "Phiên 15 — đúng ngay từ đầu: bộ quy tắc nghiệp vụ đổi theo sản phẩm vay (hạn mức, thời hạn, tỷ lệ trên TSBĐ, kỳ trả nợ), lịch trả nợ tự sinh cho phụ lục hợp đồng, lưới kiểm tra bảng CSV trước khi tạo hồ sơ và báo cáo danh mục hồ sơ ra tệp XLSX. Kế thừa phiên 14 (mẫu dùng lại, nhập hàng loạt, hoàn tác); mọi dữ liệu vẫn đi qua đúng FIELD_META và cửa chặn xuất; adapter hệ cũ vẫn CHỈ ĐỌC.";

export const Route = createFileRoute("/xem-truoc")({
  head: () => ({
    meta: [
      { title: `${title} | HSV` },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: XemTruoc,
});

function XemTruoc() {
  const [id, setId] = useState(TEMPLATES[0]!.id);
  const [hoSoNhap, setHoSoNhap] = useState<HoSo>(() => initialHoSo());
  const [status, setStatus] = useState<string>("");
  const [busy, setBusy] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [tables, setTables] = useState<TableRows>(() => initialTableRows());
  // PHIÊN 11 — thửa/giấy tờ của từng tài sản bảo đảm.
  const [thua, setThua] = useState<ThuaByTaiSan>(() => demoThua());
  // PHIÊN 12 (phần 1) — nhiều hồ sơ trong một phiên làm việc.
  const [ws, setWs] = useState<Workspace>(() => initialWorkspace());
  const [dangNhapHeCu, setDangNhapHeCu] = useState(false);
  const [thongBaoHoSo, setThongBaoHoSo] = useState("");
  // PHIÊN 12B — hồ sơ được đánh dấu để xuất trọn bộ trong một tệp ZIP.
  const [chonXuat, setChonXuat] = useState<string[]>([]);
  const [busyZip, setBusyZip] = useState(false);
  const [ketQuaZip, setKetQuaZip] = useState("");
  // PHIÊN 13 — tìm nhanh, sắp xếp, lưu/nạp tệp bộ hồ sơ.
  const [tuKhoa, setTuKhoa] = useState("");
  const [sapXep, setSapXep] = useState<SapXepHoSo>("thu-tu");
  const [thongBaoTep, setThongBaoTep] = useState("");
  const [loiTep, setLoiTep] = useState<string[]>([]);
  // PHIÊN 14 — mẫu dùng lại / nhập hàng loạt CSV / nhật ký + hoàn tác.
  const [mauDs, setMauDs] = useState<MauDungLai[]>([]);
  const [thongBaoMau, setThongBaoMau] = useState("");
  const [csv, setCsv] = useState("");
  const [thongBaoCsv, setThongBaoCsv] = useState("");
  const [loiCsv, setLoiCsv] = useState<string[]>([]);
  const [nhatKy, setNhatKy] = useState<MocNhatKy[]>([]);
  const [thongBaoHoanTac, setThongBaoHoanTac] = useState("");
  // PHIÊN 15 — báo cáo phiên làm việc ra XLSX.
  const [thongBaoBaoCao, setThongBaoBaoCao] = useState("");
  const [busyBaoCao, setBusyBaoCao] = useState(false);
  // Phục hồi SAU hydrate để không lệch SSR.
  useEffect(() => {
    setMauDs(readMau());
    const wsStored = readWorkspace();
    if (wsStored) {
      setWs(wsStored);
      const it = activeItem(wsStored);
      setHoSoNhap(it.hoSo);
      setTables(it.tables);
      setThua(it.thua);
      setHydrated(true);
      return;
    }
    const stored = readStored();
    if (stored) setTables(stored);
    const draft = readHoSoDraft();
    if (draft) setHoSoNhap(draft);
    try {
      const rawThua = window.sessionStorage.getItem(THUA_STORAGE_KEY);
      if (rawThua) setThua(JSON.parse(rawThua) as ThuaByTaiSan);
    } catch {
      /* bỏ qua */
    }
    setHydrated(true);
  }, []);
  useEffect(() => {
    if (!hydrated) return;
    try {
      window.sessionStorage.setItem(STORAGE_KEY, JSON.stringify(tables));
    } catch {
      /* bộ nhớ phiên bị chặn — không ảnh hưởng nhập liệu */
    }
  }, [tables, hydrated]);
  useEffect(() => {
    if (!hydrated) return;
    writeHoSoDraft(hoSoNhap);
  }, [hoSoNhap, hydrated]);
  useEffect(() => {
    if (!hydrated) return;
    try {
      window.sessionStorage.setItem(THUA_STORAGE_KEY, JSON.stringify(thua));
    } catch {
      /* bỏ qua */
    }
  }, [thua, hydrated]);
  // Trạng thái đang soạn luôn được ghi vào đúng hồ sơ đang chọn.
  useEffect(() => {
    if (!hydrated) return;
    setWs((prev) => {
      const next = capNhatHoSoDangChon(prev, { hoSo: hoSoNhap, tables, thua });
      writeWorkspace(next);
      return next;
    });
  }, [hoSoNhap, tables, thua, hydrated]);

  /** Lưu hồ sơ đang soạn rồi chuyển sang hồ sơ khác trong danh sách. */
  const apDungWorkspace = (next: Workspace) => {
    const it = activeItem(next);
    setWs(next);
    writeWorkspace(next);
    setHoSoNhap(it.hoSo);
    setTables(it.tables);
    setThua(it.thua);
    setStatus("");
  };
  const luuHienTai = () => capNhatHoSoDangChon(ws, { hoSo: hoSoNhap, tables, thua });
  /**
   * PHIÊN 14 — ghi mốc nhật ký TRƯỚC mỗi thao tác làm đổi danh mục hồ sơ,
   * để cán bộ hoàn tác được khi bấm nhầm.
   */
  const ghiNhatKy = (nhan: string, truoc: Workspace = luuHienTai()) => {
    setNhatKy((prev) => ghiMoc(prev, nhan, truoc));
    setThongBaoHoanTac("");
  };
  const chon = (idHoSo: string) => apDungWorkspace(chonHoSo(luuHienTai(), idHoSo));
  const themMoi = () => {
    ghiNhatKy("Thêm hồ sơ mới");
    apDungWorkspace(themHoSo(luuHienTai(), emptyHoSoItem(`Hồ sơ mới ${ws.items.length + 1}`)));
  };
  const nhanBan = () => {
    ghiNhatKy(`Nhân bản hồ sơ “${activeItem(ws).ten}”`);
    apDungWorkspace(nhanBanHoSo(luuHienTai()));
  };
  const xoa = () => {
    ghiNhatKy(`Xoá hồ sơ “${activeItem(ws).ten}”`);
    apDungWorkspace(xoaHoSo(luuHienTai(), ws.activeId));
  };
  const doiTen = (ten: string) => {
    const next = doiTenHoSo(luuHienTai(), ws.activeId, ten);
    setWs(next);
    writeWorkspace(next);
  };
  const nhapHeCu = async () => {
    setDangNhapHeCu(true);
    try {
      const kq = await nhapTuHeCu();
      setThongBaoHoSo(tomTatNhap(kq));
      if (kq.items.length > 0) {
        ghiNhatKy(`Nhập ${kq.items.length} hồ sơ từ hệ cũ`);
        apDungWorkspace(themNhieuHoSo(luuHienTai(), kq.items));
      }
    } catch (e) {
      setThongBaoHoSo(e instanceof Error ? e.message : "Không đọc được dữ liệu hệ cũ.");
    } finally {
      setDangNhapHeCu(false);
    }
  };

  /** PHIÊN 13 — lưu cả phiên làm việc ra tệp `.hsv.json`. */
  const luuTepBoHoSo = () => {
    const wsHienTai = luuHienTai();
    setWs(wsHienTai);
    writeWorkspace(wsHienTai);
    const { blob, fileName, soHoSo } = taoTepBoHoSo(wsHienTai.items);
    taiTep(blob, fileName);
    setLoiTep([]);
    setThongBaoTep(
      `Đã lưu ${fileName} — ${soHoSo} hồ sơ, ${Math.max(1, Math.round(blob.size / 1024))} KB.`,
    );
  };

  /** PHIÊN 13 — nạp tệp: dữ liệu vào thẳng bộ kiểm tra như nhập tay. */
  const napTepBoHoSo = async (file: File) => {
    try {
      const kq = docTepBoHoSo(await file.text());
      setLoiTep(kq.loi);
      if (kq.items.length === 0) {
        setThongBaoTep(`Không nạp được hồ sơ nào từ ${file.name}.`);
        return;
      }
      ghiNhatKy(`Nạp ${kq.items.length} hồ sơ từ tệp ${file.name}`);
      apDungWorkspace(themNhieuHoSo(luuHienTai(), kq.items));
      setThongBaoTep(
        `Đã nạp ${kq.items.length} hồ sơ từ ${file.name}${kq.loi.length ? ` (bỏ qua ${kq.loi.length} mục lỗi)` : ""}.`,
      );
    } catch (e) {
      setLoiTep([e instanceof Error ? e.message : "Không đọc được tệp."]);
      setThongBaoTep("");
    }
  };

  /** PHIÊN 14 (1) — lưu bộ trường dùng chung của hồ sơ đang soạn thành mẫu. */
  const luuMau = (ten: string) => {
    const mau = taoMauTuHoSo(ten, hoSoNhap);
    if (Object.keys(mau.giaTri).length === 0) {
      setThongBaoMau("Hồ sơ đang soạn chưa có trường dùng chung nào để lưu.");
      return;
    }
    const ds = themMau(mauDs, mau);
    setMauDs(ds);
    writeMau(ds);
    setThongBaoMau(`Đã lưu mẫu “${mau.ten}” — ${Object.keys(mau.giaTri).length} trường dùng chung.`);
  };

  /** PHIÊN 14 (1) — áp mẫu vào hồ sơ đang soạn (mặc định chỉ điền ô trống). */
  const apMau = (idMau: string, ghiDe: boolean) => {
    const mau = mauDs.find((m) => m.id === idMau);
    if (!mau) return;
    const doi = soOSeDoi(hoSoNhap, mau, ghiDe);
    if (doi === 0) {
      setThongBaoMau(`Mẫu “${mau.ten}” không làm đổi ô nào (các ô đã có dữ liệu).`);
      return;
    }
    ghiNhatKy(`Áp mẫu “${mau.ten}” vào hồ sơ đang soạn`);
    setHoSoNhap((prev) => apDungMau(prev, mau, ghiDe));
    setThongBaoMau(
      `Đã áp mẫu “${mau.ten}” — điền ${doi} ô${ghiDe ? " (ghi đè ô đã có)" : " còn trống"}.`,
    );
  };

  const xoaMau = (idMau: string) => {
    const ds = xoaMauKhoi(mauDs, idMau);
    setMauDs(ds);
    writeMau(ds);
    setThongBaoMau("Đã xoá mẫu khỏi phiên làm việc.");
  };

  /** PHIÊN 14 (2) — mỗi dòng CSV thành một hồ sơ, kế thừa trường dùng chung. */
  const nhapCsv = (noiDung = csv) => {
    const kq = nhapHangLoat(noiDung, {
      nen: Object.fromEntries(
        Object.entries(hoSoNhap).filter(([k]) => TRUONG_DUNG_CHUNG.includes(k)),
      ),
    });
    setLoiCsv(kq.loi);
    setThongBaoCsv(tomTatNhapHangLoat(kq));
    if (kq.items.length === 0) return;
    ghiNhatKy(`Nhập hàng loạt ${kq.items.length} hồ sơ từ bảng CSV`);
    apDungWorkspace(themNhieuHoSo(luuHienTai(), kq.items));
  };

  const nhapTepCsv = async (file: File) => {
    try {
      const noiDung = await file.text();
      setCsv(noiDung);
      nhapCsv(noiDung);
    } catch (e) {
      setLoiCsv([e instanceof Error ? e.message : "Không đọc được tệp CSV."]);
    }
  };

  /** PHIÊN 14 (3) — hoàn tác thao tác gần nhất. */
  const hoanTacThaoTac = () => {
    const kq = hoanTacNhatKy(nhatKy);
    if (!kq.ws) return;
    setNhatKy(kq.ds);
    apDungWorkspace(kq.ws);
    setThongBaoHoanTac(`Đã hoàn tác: ${kq.nhan}.`);
  };

  /** PHIÊN 15 (4) — xuất báo cáo danh mục hồ sơ của phiên ra tệp XLSX. */
  const xuatBaoCao = async () => {
    setBusyBaoCao(true);
    setThongBaoBaoCao("");
    try {
      const wsHienTai = luuHienTai();
      const { taoBaoCaoXlsx } = await import("@/lib/hsv/baoCaoXlsx");
      const kq = await taoBaoCaoXlsx(wsHienTai.items);
      taiTep(kq.blob, kq.fileName);
      setThongBaoBaoCao(
        `Đã xuất ${kq.fileName} — ${kq.soDong} hồ sơ, ${kq.soThieu} hồ sơ còn thiếu trường bắt buộc.`,
      );
    } catch (e) {
      setThongBaoBaoCao(e instanceof Error ? e.message : "Không xuất được báo cáo.");
    } finally {
      setBusyBaoCao(false);
    }
  };


  const toggleXuat = (idHoSo: string) =>
    setChonXuat((prev) =>
      prev.includes(idHoSo) ? prev.filter((x) => x !== idHoSo) : [...prev, idHoSo],
    );

  const setField = (key: string, value: string) => {
    if (isDerivedField(key)) return; // trường suy ra: chỉ đọc
    setHoSoNhap((prev) => ({ ...prev, [key]: value }));
  };
  const resetHoSo = () => {
    clearHoSoDraft();
    setHoSoNhap(initialHoSo());
    setStatus("");
  };
  const boTruongBatBuoc = () => setHoSoNhap((prev) => makeThieuBatBuoc(prev));

  const resetTables = () => {
    try {
      window.sessionStorage.removeItem(STORAGE_KEY);
    } catch {
      /* bỏ qua */
    }
    setTables(initialTableRows());
    try {
      window.sessionStorage.removeItem(THUA_STORAGE_KEY);
    } catch {
      /* bỏ qua */
    }
    setThua(demoThua());
    setStatus("");
  };

  const template = TEMPLATES.find((t) => t.id === id) ?? TEMPLATES[0]!;
  const hoSoGoc = hoSoNhap;
  // PHIÊN 10 — tổng và "bằng chữ" suy ra từ bảng lặp, không để cán bộ gõ lại.
  const suyRa = useMemo(() => derivedValues(tables), [tables]);
  const hoSo = useMemo(
    () => applyTaiSanChiTiet(applyDerived(hoSoGoc, tables), tables, thua),
    [hoSoGoc, tables, thua],
  );
  const thuaIssues = useMemo(() => validateThua(tables, thua), [tables, thua]);
  const kiemTraCheo = useMemo(() => crossResults(hoSo), [hoSo]);
  const rendered = useMemo(() => renderTemplate(template, hoSo), [template, hoSo]);
  const anchors = useMemo(() => templateTableAnchors(template), [template]);
  const tableIssues = useMemo(() => validateTables(tables), [tables]);
  const formKeys = useMemo(() => new Set(formFields().map((f) => f.key)), []);
  const fieldIssues = useMemo(
    () => validateHoSo(hoSo).filter((i) => formKeys.has(i.key) || isDerivedField(i.key)),
    [hoSo, formKeys],
  );
  const blocking = useMemo(
    () => blockingIssues(hoSo, demoRows, tables, thua),
    [hoSo, tables, thua],
  );
  const dead = useMemo(() => deadLabels().filter((d) => d.labels.length > 0), []);

  /* ---------- PHIÊN 16 — cộng tác & lưu vết ---------- */
  const itemHienTai = activeItem(ws);
  const [thongBaoLuanChuyen, setThongBaoLuanChuyen] = useState("");
  const [thongBaoGoi, setThongBaoGoi] = useState("");
  const [loiGoi, setLoiGoi] = useState<string[]>([]);

  /** Ghi thẳng vào hồ sơ đang chọn rồi lưu bộ nhớ phiên. */
  const capNhatItemHienTai = (sua: (it: HoSoItem) => HoSoItem) => {
    const goc = luuHienTai();
    const next: Workspace = {
      ...goc,
      items: goc.items.map((it) => (it.id === goc.activeId ? sua(it) : it)),
    };
    setWs(next);
    writeWorkspace(next);
  };

  const datChuSoHuu = (ten: string) => capNhatItemHienTai((it) => ({ ...it, chuSoHuu: ten }));

  const chuyenHoSo = (den: TrangThaiHoSo, nguoi: string, ghiChu: string) => {
    const it = activeItem(luuHienTai());
    const kq = chuyenTrangThai(it.luanChuyen ?? [], {
      tu: it.trangThai ?? TRANG_THAI_MAC_DINH,
      den,
      nguoi,
      ghiChu,
      soLoiChan: blocking.length,
    });
    setThongBaoLuanChuyen(kq.thongBao);
    if (!kq.ok) return;
    capNhatItemHienTai((cur) => ({ ...cur, trangThai: kq.trangThai, luanChuyen: kq.lichSu }));
  };

  const luuMocPhienBan = (nhan: string, nguoi: string) =>
    capNhatItemHienTai((it) => ({
      ...it,
      phienBan: luuPhienBan(it.phienBan ?? [], hoSoNhap, nguoi, nhan),
    }));

  const chotBanGui = () => {
    capNhatItemHienTai((it) => tangBan(it));
    setThongBaoGoi("Đã chốt bản mới — gói xuất sau sẽ mang số bản cao hơn.");
    setLoiGoi([]);
  };

  const xuatGoiPhong = (phong: string, nguoi: string) => {
    const wsNow = luuHienTai();
    const { blob, fileName, soHoSo } = taoGoiPhong(wsNow.items, nguoi, phong);
    taiTep(blob, fileName);
    setLoiGoi([]);
    setThongBaoGoi(`Đã xuất ${fileName} — ${soHoSo} hồ sơ gửi ${phong}.`);
  };

  const napGoiPhong = async (file: File) => {
    try {
      const doc = docGoiPhong(await file.text());
      if (doc.mucs.length === 0) {
        setLoiGoi(doc.loi);
        setThongBaoGoi(`Không nạp được hồ sơ nào từ ${file.name}.`);
        return;
      }
      const goc = luuHienTai();
      const kq = gopGoiPhong(goc.items, doc.mucs);
      ghiNhatKy(`Gộp gói phòng từ ${file.name}`, goc);
      apDungWorkspace({ ...goc, items: kq.items });
      setLoiGoi([...doc.loi, ...kq.xungDot]);
      setThongBaoGoi(tomTatGop(kq));
    } catch (e) {
      setLoiGoi([e instanceof Error ? e.message : "Không đọc được tệp gói."]);
      setThongBaoGoi("");
    }
  };

  const taiPhieuKiemTra = (noiDung: string, tenTep: string) =>
    taiTep(new Blob([noiDung], { type: "text/plain;charset=utf-8" }), tenTep);

  const labelCount = templateLabels(template).length;
  const soDongBang = TABLE_META.reduce((s, t) => s + (tables[t.key]?.length ?? 0), 0);

  /** PHIÊN 12B — một lần bấm ra đủ 4 mẫu DOCX + trang bìa mục lục trong một ZIP. */
  async function onExportZip(nhieu: boolean) {
    setBusyZip(true);
    setKetQuaZip("");
    try {
      const wsHienTai = capNhatHoSoDangChon(ws, { hoSo: hoSoNhap, tables, thua });
      const chon = nhieu
        ? wsHienTai.items.filter((i) => chonXuat.includes(i.id))
        : wsHienTai.items.filter((i) => i.id === wsHienTai.activeId);
      if (chon.length === 0) {
        setKetQuaZip("Chưa đánh dấu hồ sơ nào để xuất trọn bộ.");
        return;
      }
      const { taoBoHoSoZip } = await import("@/lib/hsv/boHoSoZip");
      const { downloadBlob } = await import("@/lib/hsv/docxExport");
      const items = chon.map((i) => ({
        ten: i.ten,
        hoSo: applyTaiSanChiTiet(applyDerived(i.hoSo, i.tables), i.tables, i.thua),
        tables: i.tables,
      }));
      const kq = await taoBoHoSoZip(items, demoRows);
      downloadBlob(kq.blob, kq.fileName);
      const daXuat = danhDauDaXuat(wsHienTai, chon.map((i) => i.id));
      setWs(daXuat);
      writeWorkspace(daXuat);
      setKetQuaZip(
        `Đã xuất ${kq.fileName} — ${chon.length} hồ sơ × ${TEMPLATES.length} mẫu, tổng ${kq.entries.length} tệp (gồm trang bìa mục lục), ${Math.round(kq.blob.size / 1024)} KB.`,
      );
    } catch (e) {
      setKetQuaZip(e instanceof Error ? e.message : "Không xuất được bộ hồ sơ.");
    } finally {
      setBusyZip(false);
    }
  }

  async function onExport() {
    setBusy(true);
    setStatus("");
    try {
      const { exportDocxBlob, docxFileName, downloadBlob } = await import("@/lib/hsv/docxExport");
      const blob = await exportDocxBlob(template, hoSo, demoRows, tables);
      const name = docxFileName(template, hoSo);
      downloadBlob(blob, name);
      setWs((prev) => {
        const next = danhDauDaXuat(prev, [prev.activeId]);
        writeWorkspace(next);
        return next;
      });
      setStatus(
        `Đã xuất tệp ${name} (${Math.round(blob.size / 1024)} KB) — kèm ${soDongBang} dòng bảng lặp.`,
      );
    } catch (e) {
      setStatus(e instanceof Error ? e.message : "Không xuất được tệp.");
    } finally {
      setBusy(false);
    }
  }


  return (
    <AppShell>
      {hydrated && <span data-testid="san-sang" hidden />}
      <h1 className="text-2xl font-extrabold text-foreground sm:text-3xl">{title}</h1>
      <p className="mt-3 max-w-3xl text-sm text-muted-foreground">{description}</p>

      <div className="mt-6">
        <DanhSachHoSo
          ws={ws}
          dangNhap={dangNhapHeCu}
          thongBao={thongBaoHoSo}
          onChon={chon}
          onThem={themMoi}
          onNhanBan={nhanBan}
          onXoa={xoa}
          onDoiTen={doiTen}
          onNhapHeCu={nhapHeCu}
          chonXuat={chonXuat}
          onToggleXuat={toggleXuat}
          tuKhoa={tuKhoa}
          onTuKhoa={setTuKhoa}
          sapXep={sapXep}
          onSapXep={setSapXep}
          onLuuTep={luuTepBoHoSo}
          onNapTep={napTepBoHoSo}
          thongBaoTep={thongBaoTep}
          loiTep={loiTep}
        />
      </div>

      <div className="mt-6">
        <CongCuPhien14
          mauDs={mauDs}
          onLuuMau={luuMau}
          onApMau={apMau}
          onXoaMau={xoaMau}
          thongBaoMau={thongBaoMau}
          csv={csv}
          onCsv={setCsv}
          onNhapCsv={() => nhapCsv()}
          onTepCsv={nhapTepCsv}
          thongBaoCsv={thongBaoCsv}
          loiCsv={loiCsv}
          nhatKy={nhatKy}
          onHoanTac={hoanTacThaoTac}
          thongBaoHoanTac={thongBaoHoanTac}
        />
      </div>

      <div className="mt-6">
        <CongCuPhien15
          hoSo={hoSo}
          csv={csv}
          onTaoTuLuoi={(noiDung) => {
            setCsv(noiDung);
            nhapCsv(noiDung);
          }}
          onXuatBaoCao={xuatBaoCao}
          thongBaoBaoCao={thongBaoBaoCao}
          dangXuatBaoCao={busyBaoCao}
        />
      </div>

      <div className="mt-6">
        <CongCuPhien16
          ten={itemHienTai.ten}
          hoSo={hoSo}
          chanXuat={blocking}
          chuSoHuu={itemHienTai.chuSoHuu ?? ""}
          trangThai={itemHienTai.trangThai ?? TRANG_THAI_MAC_DINH}
          lichSu={itemHienTai.luanChuyen ?? []}
          phienBan={itemHienTai.phienBan ?? []}
          ban={itemHienTai.ban ?? 1}
          thongBaoLuanChuyen={thongBaoLuanChuyen}
          thongBaoGoi={thongBaoGoi}
          loiGoi={loiGoi}
          onDatChuSoHuu={datChuSoHuu}
          onChuyen={chuyenHoSo}
          onLuuPhienBan={luuMocPhienBan}
          onXuatGoi={xuatGoiPhong}
          onNapGoi={napGoiPhong}
          onChotBan={chotBanGui}
          onTaiPhieu={taiPhieuKiemTra}
        />
      </div>






      <div className="mt-6 grid gap-3 sm:grid-cols-4">
        <div className="card-elevated p-4">
          <p className="text-xs text-muted-foreground">Mẫu đang xem trước</p>
          <p className="font-display text-sm font-extrabold text-primary">{template.name}</p>
        </div>
        <div className="card-elevated p-4">
          <p className="text-xs text-muted-foreground">Chỗ trống được điền</p>
          <p className="font-display text-2xl font-extrabold text-primary" data-testid="so-cho-trong">
            {rendered.placeholders - rendered.missing.length}/{rendered.placeholders}
          </p>
        </div>
        <div className="card-elevated p-4">
          <p className="text-xs text-muted-foreground">Nhãn "chết" (không có trong FIELD_META)</p>
          <p className="font-display text-2xl font-extrabold text-primary" data-testid="nhan-chet">
            {dead.length === 0 ? `0/${labelCount}` : dead.length}
          </p>
        </div>
        <div className="card-elevated p-4">
          <p className="text-xs text-muted-foreground">Số mẫu đã khai báo</p>
          <p className="font-display text-2xl font-extrabold text-primary" data-testid="so-mau">
            {TEMPLATES.length}
          </p>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap gap-2">
        {TEMPLATES.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setId(t.id)}
            data-on={t.id === id}
            data-testid={`mau-${t.id}`}
            className="rounded-md border border-border px-3 py-1.5 text-sm data-[on=true]:bg-primary data-[on=true]:text-primary-foreground"
          >
            {t.name}
          </button>
        ))}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={resetHoSo}
          data-testid="hoso-day-du"
          className="rounded-md border border-border px-3 py-1.5 text-sm"
        >
          Đặt lại hồ sơ (về hồ sơ mẫu)
        </button>
        <button
          type="button"
          onClick={boTruongBatBuoc}
          data-testid="hoso-thieu"
          className="rounded-md border border-border px-3 py-1.5 text-sm"
        >
          Bỏ trống trường bắt buộc (kiểm chứng)
        </button>
        <button
          type="button"
          onClick={resetTables}
          data-testid="dat-lai-bang"
          className="rounded-md border border-border px-3 py-1.5 text-sm"
        >
          Đặt lại bảng lặp
        </button>
        <button
          type="button"
          onClick={onExport}
          disabled={busy || blocking.length > 0}
          data-testid="xuat-docx"
          className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50"
        >
          {busy ? "Đang xuất…" : "Xuất tệp DOCX"}
        </button>
        <button
          type="button"
          onClick={() => onExportZip(false)}
          disabled={busyZip || blocking.length > 0}
          data-testid="xuat-zip-tron-bo"
          className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50"
        >
          {busyZip ? "Đang đóng gói…" : `Xuất trọn bộ ${TEMPLATES.length} mẫu (ZIP)`}
        </button>
        <button
          type="button"
          onClick={() => onExportZip(true)}
          disabled={busyZip || chonXuat.length === 0}
          data-testid="xuat-zip-nhieu-ho-so"
          className="rounded-md border border-border px-4 py-2 text-sm font-semibold disabled:cursor-not-allowed disabled:opacity-50"
        >
          Xuất trọn bộ cho {chonXuat.length} hồ sơ đã đánh dấu
        </button>
      </div>

      {blocking.length > 0 && (
        <p className="mt-3 text-sm font-medium text-destructive" data-testid="chan-xuat">
          Chặn xuất: còn {blocking.length} lỗi phải sửa
          {tableIssues.length > 0 ? ` (${tableIssues.length} lỗi trong bảng lặp)` : ""} —{" "}
          {blocking.map((i) => `${i.label}: ${i.message}`).join("; ")}.
        </p>
      )}

      {ketQuaZip && (
        <p className="mt-3 text-sm font-medium text-foreground" data-testid="ket-qua-zip">
          {ketQuaZip}
        </p>
      )}

      {status && (
        <p className="mt-3 text-sm font-medium text-foreground" data-testid="ket-qua-xuat">
          {status}
        </p>
      )}

      <section className="card-elevated mt-6 px-5 py-4" data-testid="khoi-suy-ra">
        <h2 className="text-base font-bold text-foreground">
          Số tổng và phần “bằng chữ” tự chảy từ bảng lặp
        </h2>
        <p className="mt-1 max-w-3xl text-xs text-muted-foreground">
          Cán bộ không gõ lại tổng: mỗi lần sửa một dòng bảng, số tổng và phần chữ trong văn bản đổi
          theo ngay — vá nhóm lỗi “nhập trùng, lệch số” của đề án. Mẫu đang xem khai báo vị trí bảng:{" "}
          <strong data-testid="vi-tri-bang-mau">
            {anchors.length > 0 ? anchors.join(", ") : "chưa khai báo"}
          </strong>
          .
        </p>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          {suyRa.map((d) => (
            <div key={d.tableKey} className="rounded-md border border-border px-4 py-3">
              <p className="text-xs text-muted-foreground">
                {d.tableLabel} — {d.rowCount} dòng ⇒ {d.totalField}
              </p>
              <p
                className="font-display text-lg font-extrabold text-primary"
                data-testid={`suy-ra-tong-${d.tableKey}`}
              >
                {formatMoney(d.total)}
              </p>
              <p className="text-xs text-foreground" data-testid={`suy-ra-chu-${d.tableKey}`}>
                {d.words}
              </p>
            </div>
          ))}
        </div>
      </section>

      <h2 className="mt-8 text-lg font-bold text-foreground" data-testid="tieu-de-form">
        Nhập hồ sơ — form sinh từ FIELD_META
      </h2>
      <p className="mt-1 max-w-3xl text-xs text-muted-foreground">
        Mỗi trường khai báo trong <code>FIELD_META</code> là một ô nhập: nhãn, kiểu ô và dấu bắt
        buộc đều lấy từ khai báo, không chép tay trong giao diện. Lỗi hiện ngay dưới ô sai và dùng
        chung một cửa chặn xuất với bảng lặp. Bản nháp lưu trong bộ nhớ phiên{" "}
        <code>hsv.hoSo.v1</code> — tải lại trang vẫn còn.
      </p>
      <div className="mt-4">
        <FormHoSo groups={FORM_GROUPS} hoSo={hoSo} issues={fieldIssues} onChange={setField} />
      </div>

      <section className="card-elevated mt-8 px-5 py-4" data-testid="khoi-kiem-tra-cheo">
        <h2 className="text-base font-bold text-foreground">Kiểm tra chéo nghiệp vụ</h2>
        <p className="mt-1 max-w-3xl text-xs text-muted-foreground">
          Không chỉ soi từng ô rời rạc: các quy tắc dưới đây đối chiếu số liệu giữa phương án, khoản
          vay và tài sản bảo đảm. Quy tắc không đạt sẽ chặn xuất DOCX như mọi lỗi khác.
        </p>
        <ul className="mt-3 space-y-2">
          {kiemTraCheo.map((r) => (
            <li
              key={r.rule.key}
              data-testid={`cheo-${r.rule.key}`}
              data-dat={r.ok}
              className="rounded-md border border-border px-4 py-2.5 text-sm data-[dat=false]:border-destructive"
            >
              <p className="font-semibold text-foreground">
                {r.ok ? "Đạt" : "Không đạt"} — {r.rule.label}
              </p>
              <p className="mt-0.5 text-xs text-muted-foreground">{r.detail}</p>
              {!r.ok && (
                <p
                  className="mt-0.5 text-xs font-medium text-destructive"
                  data-testid={`cheo-loi-${r.rule.key}`}
                >
                  {r.message}
                </p>
              )}
            </li>
          ))}
        </ul>
      </section>

      <div className="mt-8">
        <TaiSanChiTiet
          tables={tables}
          thua={thua}
          issues={thuaIssues}
          onChange={(i, rows) => setThua((prev) => ({ ...prev, [String(i)]: rows }))}
        />
        <p className="mt-3 text-xs text-muted-foreground" data-testid="tong-hop-thua">
          Tổng cộng {soThuaTong(thua)} thửa/giấy tờ · tổng diện tích{" "}
          {tongDienTich(thua).toLocaleString("vi-VN")} m². Câu ghép cho hợp đồng thế chấp:
        </p>
        <p
          className="mt-1 rounded-md border border-border px-4 py-3 text-xs leading-relaxed text-foreground"
          data-testid="cau-the-chap"
        >
          {String(hoSo["moTaTaiSanTheChap"] ?? "")}
        </p>
      </div>

      <h2 className="mt-8 text-lg font-bold text-foreground">
        Bảng lặp dòng — nhập liệu và in thành bảng thật trong DOCX
      </h2>
      <p className="mt-1 max-w-3xl text-xs text-muted-foreground">
        Một component duy nhất sinh từ khai báo <code>TABLE_META</code>: thêm/xoá dòng, tự tính
        tổng, <strong>validate theo cột</strong> (cột bắt buộc, cột tiền phải là số) và{" "}
        <strong>giữ nguyên dữ liệu khi tải lại trang</strong> trong phiên làm việc. Danh mục TSBĐ hợp nhất 3 hệ song song của hệ cũ nên mọi tài sản đều được in ra, không
        chỉ tài sản đầu tiên.
      </p>
      <div className="mt-4 space-y-6">
        {TABLE_META.map((meta) => (
          <BangLapDong
            key={meta.key}
            meta={meta}
            rows={tables[meta.key] ?? []}
            issues={tableIssues.filter((i) => i.key.startsWith(`${meta.key}[`))}
            onChange={(rows) => setTables((prev) => ({ ...prev, [meta.key]: rows }))}
          />
        ))}
      </div>



      <section className="card-elevated mt-8 px-5 py-4" data-testid="khoi-ky-duyet">
        <h2 className="text-base font-bold text-foreground">
          Ký/duyệt nội bộ — in đúng chỗ ký ở cả {TEMPLATES.length} mẫu
        </h2>
        <p className="mt-1 max-w-3xl text-xs text-muted-foreground">
          Hệ cũ để cán bộ gõ tay tên người ký vào từng mẫu nên hay lệch tên, sai chức vụ, thiếu ngày
          ký. Ở đây khối ký khai báo một lần trong <code>FIELD_META</code> (nhóm “Ký/duyệt nội bộ”)
          và được in ở cuối cả 4 mẫu DOCX.
        </p>
        <p className="mt-2 text-xs text-foreground" data-testid="dong-dia-diem-ngay">
          {dongDiaDiemNgay(hoSo)}
        </p>
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          {oNhanKy(hoSo).map((o) => (
            <div
              key={o.vaiTro}
              data-testid={`o-ky-${o.vaiTro}`}
              className="rounded-md border border-border px-4 py-3 text-center"
            >
              <p className="text-xs font-bold uppercase text-foreground">{o.vaiTro}</p>
              <p className="text-[11px] italic text-muted-foreground">{o.ghiChu}</p>
              <p className="mt-6 text-sm font-semibold text-foreground">{o.ten}</p>
              <p className="text-xs text-muted-foreground">{o.chucVu}</p>
            </div>
          ))}
        </div>
      </section>

      <article
        className="card-elevated mt-6 space-y-5 px-6 py-6 text-sm leading-relaxed"
        data-testid="xem-truoc-mau"
      >
        {rendered.blocks.map((b, bi) => (
          <section key={bi} className="space-y-1.5">
            {b.heading && (
              <h2 className="text-center text-sm font-bold uppercase text-foreground sm:text-left">
                {b.heading}
              </h2>
            )}
            {b.lines.map((l, li) => (
              <p key={li} className="text-foreground" data-testid="dong-mau">
                {l.text}
              </p>
            ))}
          </section>
        ))}
      </article>

      {rendered.missing.length > 0 && (
        <p className="mt-4 text-xs text-muted-foreground" data-testid="thieu-truong">
          Còn thiếu dữ liệu cho: {rendered.missing.join(", ")} — hiển thị dạng [Nhãn] để cán bộ biết
          chỗ cần bổ sung.
        </p>
      )}

      <p className="mt-6 text-xs text-muted-foreground">
        Tệp DOCX được sinh ngay trên máy cán bộ từ một khai báo mẫu duy nhất; hệ cũ vẫn giữ nguyên,
        không ghi/xoá dữ liệu.
      </p>
    </AppShell>
  );
}
