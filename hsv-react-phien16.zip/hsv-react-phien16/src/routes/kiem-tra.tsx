import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/hsv/AppShell";
import { FIELD_META, GROUP_LABEL, REPEATABLE_CELLS } from "@/lib/hsv/fieldMeta";
import { demoHoSo } from "@/lib/hsv/legacyAdapter";
import { demoRows } from "@/lib/hsv/repeatableData";
import { makeInvalidSample, validateHoSo } from "@/lib/hsv/validation";

const title = "Kiểm tra dữ liệu — lớp validate sinh từ FIELD_META";
const description =
  "Phiên 7: một khai báo FIELD_META sinh ra Zod schema cho toàn bộ trường HMTD, bắt lỗi bắt buộc, sai kiểu, sai định dạng tiền và ngày trước khi sinh văn bản.";

export const Route = createFileRoute("/kiem-tra")({
  head: () => ({
    meta: [
      { title: `${title} | HSV` },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: KiemTra,
});

const invalid = makeInvalidSample();

function KiemTra() {
  const [mode, setMode] = useState<"hop-le" | "sai-kieu">("hop-le");

  const { issues, rowsCount } = useMemo(() => {
    if (mode === "sai-kieu")
      return { issues: validateHoSo(invalid.hoSo, invalid.rows), rowsCount: 4 };
    return { issues: validateHoSo(demoHoSo, demoRows), rowsCount: demoRows["chiPhiVatTu"]!.length };
  }, [mode]);

  return (
    <AppShell>
      <h1 className="text-2xl font-extrabold text-foreground sm:text-3xl">{title}</h1>
      <p className="mt-3 max-w-3xl text-sm text-muted-foreground">{description}</p>

      <div className="mt-6 grid gap-3 sm:grid-cols-3">
        <div className="card-elevated p-4">
          <p className="text-xs text-muted-foreground">Trường được validate</p>
          <p className="font-display text-2xl font-extrabold text-primary" data-testid="so-truong">
            {FIELD_META.length}
          </p>
        </div>
        <div className="card-elevated p-4">
          <p className="text-xs text-muted-foreground">Ô bảng lặp dòng</p>
          <p className="font-display text-2xl font-extrabold text-primary">{REPEATABLE_CELLS}</p>
        </div>
        <div className="card-elevated p-4">
          <p className="text-xs text-muted-foreground">Lỗi phát hiện ({rowsCount} dòng bảng)</p>
          <p className="font-display text-2xl font-extrabold text-primary" data-testid="so-loi">
            {issues.length}
          </p>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        <button
          type="button"
          data-testid="btn-hop-le"
          onClick={() => setMode("hop-le")}
          className="rounded-md border border-border px-3 py-1.5 text-sm font-medium data-[on=true]:bg-primary data-[on=true]:text-primary-foreground"
          data-on={mode === "hop-le"}
        >
          Hồ sơ mẫu (hợp lệ)
        </button>
        <button
          type="button"
          data-testid="btn-sai-kieu"
          onClick={() => setMode("sai-kieu")}
          className="rounded-md border border-border px-3 py-1.5 text-sm font-medium data-[on=true]:bg-destructive data-[on=true]:text-destructive-foreground"
          data-on={mode === "sai-kieu"}
        >
          Hồ sơ sai kiểu (kiểm chứng)
        </button>
      </div>

      <section className="card-elevated mt-6 overflow-hidden" data-testid="ket-qua">
        <h2 className="border-b border-border bg-secondary/60 px-5 py-3 text-sm font-bold text-foreground">
          {issues.length === 0 ? "Không phát hiện lỗi — hồ sơ đạt chuẩn khai báo" : `Danh sách ${issues.length} lỗi`}
        </h2>
        {issues.length === 0 ? (
          <p className="px-5 py-4 text-sm text-muted-foreground" data-testid="khong-loi">
            Toàn bộ {FIELD_META.length} trường và {REPEATABLE_CELLS} ô bảng lặp thoả điều kiện bắt
            buộc, kiểu dữ liệu và định dạng.
          </p>
        ) : (
          <ul className="divide-y divide-border">
            {issues.map((it) => (
              <li key={it.key} className="flex flex-wrap gap-2 px-5 py-3 text-sm" data-testid="dong-loi">
                <span className="w-64 shrink-0 font-medium text-foreground">{it.label}</span>
                <span className="w-40 shrink-0 text-xs text-muted-foreground">
                  {GROUP_LABEL[it.group]}
                </span>
                <span className="text-destructive">{it.message}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <p className="mt-6 text-xs text-muted-foreground">
        Lưu ý nguyên tắc: lớp validate chỉ đọc và báo lỗi — không tự sửa, không ghi đè dữ liệu hệ
        cũ.
      </p>
    </AppShell>
  );
}
