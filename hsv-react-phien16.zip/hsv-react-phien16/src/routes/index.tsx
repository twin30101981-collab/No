import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/hsv/AppShell";
import { findings, metrics, principles, type Severity } from "@/lib/hsv/analysis";

const title = "Phân tích chuyên sâu hệ thống HSV & đề án chuyển đổi React";
const description =
  "Kết quả kiểm toán kỹ thuật gói mã nguồn HSV v25.6.4: 52 tệp, app.js 38.256 dòng, 8 nhóm tồn tại và lộ trình chuyển đổi React 6 giai đoạn theo mô hình strangler-fig.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: `${title} | HSV` },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: Index,
});

const severityStyle: Record<Severity, string> = {
  cao: "bg-destructive/10 text-destructive",
  "trung-binh": "bg-warning/15 text-warning-foreground",
  thap: "bg-muted text-muted-foreground",
};
const severityLabel: Record<Severity, string> = {
  cao: "Ưu tiên cao",
  "trung-binh": "Trung bình",
  thap: "Thấp",
};

function Index() {
  return (
    <AppShell>
      <section className="card-elevated p-6 sm:p-8">
        <p className="text-xs font-semibold tracking-widest text-primary uppercase">
          Báo cáo kiểm toán kỹ thuật · 20/08/2026
        </p>
        <h1 className="mt-3 text-3xl font-extrabold text-foreground sm:text-4xl">{title}</h1>
        <p className="mt-4 max-w-3xl text-sm leading-relaxed text-muted-foreground">
          Hệ thống HSV đang hoạt động tốt về nghiệp vụ nhưng đã chạm trần kỹ thuật của mô hình “vá
          chồng vá” trên nền HTML/JS thuần. Khuyến nghị chuyển đổi sang React + TypeScript theo lộ
          trình song song (strangler-fig), không viết lại toàn bộ.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link
            to="/pilot"
            className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
          >
            Xem pilot React (chỉ đọc)
          </Link>
          <Link
            to="/he-cu"
            className="rounded-md border border-border px-4 py-2 text-sm font-semibold text-foreground transition-colors hover:bg-secondary"
          >
            Mở hệ cũ v25.6 song song
          </Link>
        </div>
      </section>

      <section className="mt-8">
        <h2 className="text-lg font-bold text-foreground">Quy mô mã nguồn đo được</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {metrics.map((m) => (
            <div key={m.label} className="card-elevated p-4">
              <p className="text-xs font-medium text-muted-foreground">{m.label}</p>
              <p className="mt-1 font-display text-2xl font-extrabold text-primary">{m.value}</p>
              <p className="mt-1 text-xs text-muted-foreground">{m.note}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-10">
        <h2 className="text-lg font-bold text-foreground">Tồn tại · hạn chế và hướng xử lý</h2>
        <div className="mt-4 space-y-3">
          {findings.map((f) => (
            <article key={f.id} className="card-elevated p-5">
              <div className="flex flex-wrap items-center gap-3">
                <span className="rounded bg-secondary px-2 py-0.5 font-mono text-xs text-secondary-foreground">
                  {f.id}
                </span>
                <h3 className="text-base font-semibold text-foreground">{f.title}</h3>
                <span
                  className={`ml-auto rounded-full px-2.5 py-0.5 text-xs font-semibold ${severityStyle[f.severity]}`}
                >
                  {severityLabel[f.severity]}
                </span>
              </div>
              <p className="mt-3 text-sm text-muted-foreground">
                <span className="font-semibold text-foreground">Bằng chứng: </span>
                {f.evidence}
              </p>
              <p className="mt-1.5 text-sm text-muted-foreground">
                <span className="font-semibold text-foreground">Hướng xử lý: </span>
                {f.remedy}
              </p>
            </article>
          ))}
        </div>
      </section>

      <section className="mt-10">
        <h2 className="text-lg font-bold text-foreground">Bốn nguyên tắc chỉ đạo</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {principles.map((p, i) => (
            <div key={p.title} className="card-elevated p-5">
              <p className="font-display text-3xl font-extrabold text-accent">{i + 1}</p>
              <h3 className="mt-1 text-base font-semibold text-foreground">{p.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{p.body}</p>
            </div>
          ))}
        </div>
      </section>
    </AppShell>
  );
}
