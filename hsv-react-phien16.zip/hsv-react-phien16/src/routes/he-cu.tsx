import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/hsv/AppShell";

const title = "Hệ HSV cũ v25.6 chạy song song (strangler-fig)";
const description =
  "Bản HSV HTML/JS hiện hành được phục vụ nguyên trạng tại /legacy để cán bộ tín dụng không có cửa sổ mất chức năng trong suốt quá trình chuyển đổi.";

export const Route = createFileRoute("/he-cu")({
  head: () => ({
    meta: [
      { title: `${title} | HSV` },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: HeCu,
});

function HeCu() {
  return (
    <AppShell>
      <h1 className="text-2xl font-extrabold text-foreground sm:text-3xl">{title}</h1>
      <p className="mt-3 max-w-3xl text-sm text-muted-foreground">
        Gói mã nguồn v25.5.10 (tích hợp v25.6.4) được phục vụ nguyên trạng, không sửa một dòng nào.
        Đây là đường quay lui tức thời của mọi giai đoạn.
      </p>
      <div className="mt-6 flex flex-wrap gap-3">
        <a
          href="/legacy/index.html"
          target="_blank"
          rel="noreferrer"
          className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
        >
          Mở hệ cũ ở tab mới
        </a>
      </div>
      <div className="card-elevated mt-6 overflow-hidden">
        <iframe
          src="/legacy/index.html"
          title="Hệ thống HSV v25.6 (bản hiện hành)"
          className="h-[70vh] w-full border-0 bg-card"
        />
      </div>
    </AppShell>
  );
}