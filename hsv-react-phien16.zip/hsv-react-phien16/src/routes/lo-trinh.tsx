import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/hsv/AppShell";
import { phases, type PhaseStatus } from "@/lib/hsv/analysis";

const title = "Lộ trình chuyển đổi React 6 giai đoạn cho hệ thống HSV";
const description =
  "GĐ 0 lưới an toàn Playwright, GĐ 1 khung React đọc hồ sơ thật, GĐ 2 lõi hồ sơ vay, GĐ 3 PA SXKD, GĐ 4 tối ưu template DOCX, GĐ 5 quan sát ổn định.";

export const Route = createFileRoute("/lo-trinh")({
  head: () => ({
    meta: [
      { title: `${title} | HSV` },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: LoTrinh,
});

const statusStyle: Record<PhaseStatus, string> = {
  "hoan-thanh": "bg-success/15 text-success",
  "dang-lam": "bg-accent/25 text-accent-foreground",
  "ke-hoach": "bg-muted text-muted-foreground",
};
const statusLabel: Record<PhaseStatus, string> = {
  "hoan-thanh": "Đã thực thi",
  "dang-lam": "Đang thực thi",
  "ke-hoach": "Theo kế hoạch",
};

function LoTrinh() {
  return (
    <AppShell>
      <h1 className="text-2xl font-extrabold text-foreground sm:text-3xl">{title}</h1>
      <p className="mt-3 max-w-3xl text-sm text-muted-foreground">
        Tổng thời gian ước tính 20–26 tuần (4,5–6 tháng) theo nhịp bán thời gian. Mọi giai đoạn đều
        có đường quay lui tức thời bằng feature flag.
      </p>

      <ol className="mt-8 space-y-4">
        {phases.map((p) => (
          <li key={p.code} className="card-elevated p-5">
            <div className="flex flex-wrap items-center gap-3">
              <span className="rounded-md bg-primary px-2.5 py-1 font-display text-sm font-bold text-primary-foreground">
                {p.code}
              </span>
              <span className="text-xs text-muted-foreground">{p.duration}</span>
              <span
                className={`ml-auto rounded-full px-2.5 py-0.5 text-xs font-semibold ${statusStyle[p.status]}`}
              >
                {statusLabel[p.status]}
              </span>
            </div>
            <h2 className="mt-3 text-base font-semibold text-foreground">{p.title}</h2>
            <ul className="mt-3 space-y-1.5">
              {p.items.map((it) => (
                <li key={it} className="flex gap-2 text-sm text-muted-foreground">
                  <span className="mt-2 size-1.5 shrink-0 rounded-full bg-accent" />
                  {it}
                </li>
              ))}
            </ul>
            <p className="mt-3 border-t border-border pt-3 text-sm">
              <span className="font-semibold text-foreground">Kết quả bàn giao: </span>
              <span className="text-muted-foreground">{p.deliverable}</span>
            </p>
          </li>
        ))}
      </ol>
    </AppShell>
  );
}