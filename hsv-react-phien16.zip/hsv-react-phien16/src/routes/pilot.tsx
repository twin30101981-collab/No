import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/hsv/AppShell";
import {
  FIELD_META,
  GROUP_LABEL,
  REPEATABLE_META,
  formatValue,
  findKeyByLabel,
} from "@/lib/hsv/fieldMeta";
import { scanLegacyData, demoHoSo, LEGACY_KEY_PREFIXES } from "@/lib/hsv/legacyAdapter";
import { demoRows } from "@/lib/hsv/repeatableData";
import { sumRows } from "@/lib/hsv/validation";

const title = "Pilot React chỉ đọc — đọc hồ sơ thật từ hệ HSV cũ";
const description =
  "Giai đoạn 1: adapter đọc localStorage/IndexedDB của HSV v25.6 và chuẩn hoá theo FIELD_META duy nhất, không ghi đè bất kỳ dữ liệu nào của người dùng.";

export const Route = createFileRoute("/pilot")({
  head: () => ({
    meta: [
      { title: `${title} | HSV` },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: Pilot,
});

function Pilot() {
  const { data, isLoading } = useQuery({
    queryKey: ["legacy-scan"],
    queryFn: scanLegacyData,
    staleTime: 30_000,
  });

  const record = data?.records[0];
  const hoSo = record?.hoSo ?? demoHoSo;
  const groups = Object.keys(GROUP_LABEL) as Array<keyof typeof GROUP_LABEL>;

  return (
    <AppShell>
      <h1 className="text-2xl font-extrabold text-foreground sm:text-3xl">{title}</h1>
      <p className="mt-3 max-w-3xl text-sm text-muted-foreground">
        Adapter quét các khoá {LEGACY_KEY_PREFIXES.map((k) => `“${k}”`).join(", ")} trong trình duyệt
        của bạn. Chế độ chỉ đọc: không có lệnh ghi, xoá hay migrate dữ liệu hệ cũ.
      </p>

      <div className="mt-6 grid gap-3 sm:grid-cols-3">
        <div className="card-elevated p-4">
          <p className="text-xs text-muted-foreground">Khoá đã quét</p>
          <p className="font-display text-2xl font-extrabold text-primary">
            {isLoading ? "…" : (data?.scannedKeys ?? 0)}
          </p>
        </div>
        <div className="card-elevated p-4">
          <p className="text-xs text-muted-foreground">Hồ sơ hệ cũ nhận dạng được</p>
          <p className="font-display text-2xl font-extrabold text-primary">
            {isLoading ? "…" : (data?.matchedKeys ?? 0)}
          </p>
        </div>
        <div className="card-elevated p-4">
          <p className="text-xs text-muted-foreground">Trường trong FIELD_META (chỉ đọc)</p>
          <p className="font-display text-2xl font-extrabold text-primary">
            {FIELD_META.length}
            <span className="ml-2 text-sm font-semibold text-muted-foreground">/ 469 hệ cũ</span>
          </p>
        </div>
      </div>

      {!isLoading && !data?.available && (
        <p className="mt-4 rounded-md border border-border bg-secondary p-4 text-sm text-secondary-foreground">
          Trình duyệt này chưa có dữ liệu HSV cũ nên đang hiển thị hồ sơ mẫu để đối chiếu giao diện.
          Khi mở app trên máy cán bộ đã dùng hệ cũ, adapter sẽ nạp hồ sơ thật.
        </p>
      )}

      <div className="mt-8 space-y-6">
        {groups.map((g) => (
          <section key={g} data-group={g} className="card-elevated overflow-hidden">
            <h2 className="border-b border-border bg-secondary/60 px-5 py-3 text-sm font-bold text-foreground">
              {GROUP_LABEL[g]}
            </h2>
            <dl className="divide-y divide-border">
              {FIELD_META.filter((f) => f.group === g).map((f) => (
                <div key={f.key} className="flex flex-wrap gap-2 px-5 py-3 text-sm">
                  <dt className="w-56 shrink-0 text-muted-foreground">
                    {f.label}
                    <span className="ml-2 font-mono text-[11px] text-accent-foreground/60">
                      {findKeyByLabel(f.label)}
                    </span>
                  </dt>
                  <dd className="font-medium text-foreground">{formatValue(hoSo[f.key], f.kind)}</dd>
                </div>
              ))}
            </dl>
          </section>
        ))}
      </div>

      <div className="mt-8 space-y-6">
        {REPEATABLE_META.map((r) => (
          <section key={r.key} data-repeatable={r.key} className="card-elevated overflow-hidden">
            <h2 className="border-b border-border bg-secondary/60 px-5 py-3 text-sm font-bold text-foreground">
              {r.label} — bảng lặp dòng khai báo một lần (Phiên 7)
            </h2>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs text-muted-foreground">
                  <th className="px-5 py-2 font-medium">Dòng</th>
                  <th className="px-5 py-2 font-medium">Khoá hệ cũ</th>
                  <th className="px-5 py-2 text-right font-medium">Số tiền</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {Array.from({ length: r.rows }, (_, i) => (
                  <tr key={i}>
                    <td className="px-5 py-2 text-muted-foreground">{r.rowLabel(i)}</td>
                    <td className="px-5 py-2 font-mono text-[11px] text-accent-foreground/60">
                      {r.legacyKeys(i)[0]}
                    </td>
                    <td className="px-5 py-2 text-right font-medium text-foreground">
                      {formatValue(demoRows[r.key]?.[i], r.kind)}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t border-border bg-secondary/40">
                  <td className="px-5 py-2 text-sm font-bold text-foreground" colSpan={2}>
                    Tổng cộng
                  </td>
                  <td
                    className="px-5 py-2 text-right font-bold text-primary"
                    data-testid={`tong-${r.key}`}
                  >
                    {formatValue(sumRows(demoRows[r.key] ?? []), "money")}
                  </td>
                </tr>
              </tfoot>
            </table>
          </section>
        ))}
      </div>

      {data?.warnings.length ? (
        <ul className="mt-6 space-y-1 text-xs text-muted-foreground">
          {data.warnings.map((w) => (
            <li key={w}>• {w}</li>
          ))}
        </ul>
      ) : null}
    </AppShell>
  );
}