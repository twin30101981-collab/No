# BÀN GIAO PHIÊN 15 — "Đúng ngay từ đầu"

Đề án nâng cấp HSV → React · Agribank CN Thiên Trường Nam Định · Phòng KHKD

## 1. Phiên 15 đã làm gì

Phiên 14 giải quyết "gõ ít lại" (mẫu dùng lại, nhập hàng loạt, hoàn tác). Phiên 15 giải quyết
**"đúng ngay từ đầu"**: máy chặn sai ngay lúc nhập, tự sinh phần việc tính tay, và cho lãnh đạo
phòng một báo cáo Excel không phải hỏi từng người.

| # | Tính năng | Người dùng được gì |
|---|-----------|--------------------|
| 1 | Quy tắc theo sản phẩm vay | Chọn Ngắn hạn SXKD / Trung hạn / Tiêu dùng, bộ kiểm tra tự đổi: trần hạn mức, trần thời hạn, tỷ lệ cho vay trên TSBĐ, khung lãi suất. Sai là cảnh báo ngay dưới ô nhập. |
| 2 | Lịch trả nợ tự sinh | Nhập số tiền – thời hạn – lãi suất – kỳ trả, máy dựng bảng gốc/lãi/tổng/dư nợ theo **Gốc đều** hoặc **Niên kim**; tổng gốc luôn khớp số tiền vay, kỳ cuối dư nợ về 0. Dán được vào phụ lục hợp đồng. |
| 3 | Lưới kiểm tra bảng CSV | Dán bảng từ Excel → xem trước dạng lưới, ô sai kiểu hoặc thiếu trường bắt buộc **tô đỏ**, sửa tại chỗ; nút tạo hồ sơ chỉ mở khi lưới sạch. Cột lạ được liệt kê rõ là sẽ bỏ qua. |
| 4 | Báo cáo phiên làm việc (.xlsx) | Một cú bấm ra tệp Excel: danh mục hồ sơ, đủ/thiếu trường, số lỗi chặn, đã xuất tài liệu chưa, thời điểm sửa gần nhất. |
| 5 | Hệ cũ vẫn CHỈ ĐỌC | Mọi tính năng trên chạy hoàn toàn ở lớp React; trang `/he-cu` (v25.6) giữ nguyên trạng, không ghi ngược. |

## 2. Mã nguồn bổ sung

| Tệp | Vai trò |
|-----|---------|
| `src/lib/hsv/quyTacSanPham.ts` | Khai báo 3 sản phẩm vay + hàm `kiemTraSanPham`, `thamSoTuHoSo` (đọc `soTienVay`, `thoiHan`, `laiSuat`, `tongGiaTriTaiSanTheChap`). |
| `src/lib/hsv/lichTraNo.ts` | Sinh lịch trả nợ `goc-deu` / `nien-kim`, xuất text cho phụ lục. |
| `src/lib/hsv/luoiCsv.ts` | Dựng lưới từ CSV, validate từng ô theo `FIELD_META`, ghép ngược ra CSV sau khi sửa. |
| `src/lib/hsv/baoCaoXlsx.ts` | Dựng tệp OOXML `.xlsx` bằng JSZip (không thêm thư viện nặng). |
| `src/components/hsv/CongCuPhien15.tsx` | Khối giao diện 4 mục, gắn vào trang `/xem-truoc`. |
| `tests/e2e/phien15.spec.ts` | 6 kịch bản Playwright kèm ảnh minh chứng. |

Nguyên tắc giữ nguyên từ các phiên trước: mọi trường đi qua `FIELD_META`, không hard-code nhãn;
hệ cũ chỉ đọc; không phụ thuộc backend.

## 3. Kết quả kiểm chứng Playwright

Chạy toàn bộ bộ kiểm thử (không chỉ phiên 15):

```
56 passed (2.7m)   — 0 failed, 0 lỗi console, 0 pageerror
```

Riêng phiên 15 — 6/6 đạt:

1. `quy tắc sản phẩm vay: đổi sản phẩm thì bộ kiểm tra đổi theo` ✓
2. `quy tắc TSBĐ: vượt tỷ lệ cho vay trên tài sản bị chặn, hạ số tiền thì sạch` ✓
3. `lịch trả nợ tự sinh: gốc đều và niên kim, tổng gốc đúng bằng số tiền vay` ✓
4. `lưới kiểm tra CSV: ô sai tô đỏ chặn tạo hồ sơ, sửa xong mới tạo` ✓
5. `báo cáo phiên: tải về tệp XLSX danh mục hồ sơ` ✓
6. `hệ cũ vẫn chỉ đọc sau các thao tác phiên 15` ✓

Ảnh minh chứng (thư mục `anh-phien15/`):

- `phien15-quy-tac-tieu-dung.png`, `phien15-quy-tac-doi-theo-san-pham.png`
- `phien15-tsbd-vuot-ty-le.png`, `phien15-tsbd-dat-quy-tac.png`
- `phien15-lich-goc-deu.png`, `phien15-lich-nien-kim.png`
- `phien15-luoi-o-sai.png`, `phien15-luoi-da-sua-tao-ho-so.png`
- `phien15-bao-cao-xlsx.png`
- `phien15-he-cu-nguyen-ven.png`

Lệnh chạy lại:

```bash
bun install
bun run dev            # http://localhost:8080
E2E_CHROMIUM=/bin/chromium bunx playwright test
```

## 4. Hướng dẫn dùng nhanh (cán bộ tín dụng)

1. Vào **Xem trước mẫu** → điền hồ sơ như thường lệ.
2. Mục **Quy tắc sản phẩm**: chọn đúng sản phẩm vay; đọc cảnh báo đỏ trước khi trình.
3. Mục **Lịch trả nợ**: nhập kỳ trả (tháng) và chọn kiểu trả → sao chép bảng vào phụ lục.
4. Nhiều hồ sơ: dán bảng Excel vào ô CSV → **Xem trước bảng dưới dạng lưới** → sửa ô đỏ → **Tạo hồ sơ từ lưới đã sửa**.
5. Cuối buổi: **Xuất báo cáo XLSX** gửi lãnh đạo phòng.

## 5. Nội dung Phiên 16 đề xuất

Chủ đề: **"Nhiều người cùng làm & lưu vết"**.

1. **Hồ sơ có chủ sở hữu và trạng thái luân chuyển** — cán bộ soạn → kiểm soát viên duyệt → trả lại kèm ghi chú, thể hiện ngay trên bảng tiến độ.
2. **So sánh hai phiên bản hồ sơ** — hiện rõ trường nào đổi, ai đổi, lúc nào (mở rộng nhật ký phiên 14 thành lịch sử có mốc thời gian).
3. **Bộ kiểm tra chéo giữa các tài liệu** — số tiền/thời hạn/tên khách trong HĐTD, hợp đồng bảo đảm và giấy nhận nợ phải khớp nhau, lệch là chặn.
4. **Danh mục hồ sơ dùng chung theo phòng** — xuất/nhập gói `.hsv.json` nhiều hồ sơ kèm khoá tránh ghi đè lẫn nhau.
5. **Bản in kiểm tra một trang** — checklist trước khi trình ký, in ra kẹp cùng bộ hồ sơ giấy.

Điều kiện kỹ thuật: vẫn không cần backend; nếu muốn dùng chung thật sự giữa nhiều máy thì phiên 16 là thời điểm hợp lý để bật Lovable Cloud (đăng nhập + lưu hồ sơ tập trung) — cần quyết định của phòng trước khi làm.
