/* QLTDPRO Service Worker (P42) — vận hành ngoại tuyến cho bản đơn tệp */
const V='qltdpro-p02-v24.17.38';
const ASSETS=['./QLTDPRO_v24.17.38.html','./manifest.json','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install',e=>{
  e.waitUntil(caches.open(V).then(c=>c.addAll(ASSETS).catch(()=>{})).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',e=>{
  e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==V).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(e.request.method!=='GET'||u.origin!==self.location.origin)return;
  if(/\.docx$/i.test(u.pathname))return; /* tệp mẫu luôn tải trực tiếp */
  e.respondWith(
    caches.match(e.request,{ignoreSearch:true}).then(hit=>hit||fetch(e.request).then(r=>{
      if(r&&r.ok){const cp=r.clone();caches.open(V).then(c=>c.put(e.request,cp));}
      return r;
    }).catch(()=>caches.match('./QLTDPRO_v24.17.38.html')))
  );
});
