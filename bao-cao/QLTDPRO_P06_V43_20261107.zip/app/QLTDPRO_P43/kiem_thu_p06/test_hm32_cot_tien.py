# -*- coding: utf-8 -*-
# v24.17.43 · V3 — (1) cột tiền (Dư nợ / HMTD / Dư nợ đầu năm-hiện tại-Giảm) nằm trong màn hình đầu tiên ở 1280/1366/1920 px;
# (2) ô đậm nhất ma trận Loại vay × Nhóm nợ khác màu thanh tiêu đề; (3) Xu hướng kỳ: kỳ mới nhất ở hàng đầu; (4) TSBĐ chưa có sao kê: lời nhắn rõ;
# (5) bố cục đã lưu cũ được đổi thứ tự cột một lần (giữ độ rộng). Dữ liệu thử ẩn danh (3 mốc msit80 sinh từ kiem_thu_p03/tao_mis80_thu.py).
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p06/test_hm32_cot_tien.py [app/QLTDPRO_v24.17.43.html]
import asyncio, functools, http.server, threading, sys, tempfile, subprocess, json, re
from pathlib import Path
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.43.html'
PORT = 8878; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:500]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
TMP = Path(tempfile.mkdtemp()) / 'm'
subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(TMP)], check=True, stdout=subprocess.DEVNULL)
F = sorted(TMP.iterdir(), key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
PAGES = {'tat-ca-du-no': ['Dư nợ'], 'ngan-han-thau-chi': ['Dư nợ'], 'trung-dai-han': ['Dư nợ'], 'cho-vay-doanh-nghiep': ['Dư nợ'], 'no-den-han': ['Dư nợ'], 'lai-dong': ['Dư nợ'], 'chuyen-han-muc': ['HMTD', 'Dư nợ']}
HEAD = "[...document.querySelectorAll('[data-testid=dt-th]')].map(h=>[h.textContent.replace(/[▲▼]\\d*/g,'').trim(),Math.round(h.getBoundingClientRect().right),Math.round(h.getBoundingClientRect().left)])"
async def main():
    async with async_playwright() as pw:
        br = await pw.chromium.launch()
        for vw, vh in ((1366, 768), (1280, 720), (1920, 1080)):
            ctx = await br.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN'); await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
            pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:160]))
            await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
            await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in F]); await pg.wait_for_timeout(3500)
            await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
            y = pg.locator('[data-testid="confirm-yes"]')
            if await y.count(): await y.click()
            await pg.wait_for_timeout(9000)
            bad = []
            for p, labs in PAGES.items():
                await pg.goto(URL + '#/' + p, wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
                hs = await pg.evaluate(HEAD)
                for lab in labs:
                    h = next((x for x in hs if x[0] == lab), None)
                    if not h or h[1] > vw - 8: bad.append((p, lab, h))
            ok(f'{vw}px C1 cột tiền nằm trọn trong màn hình đầu tiên ở {len(PAGES)} trang', not bad, bad)
            if vw == 1366:
                await pg.goto(URL + '#/tong-quan', wait_until='domcontentloaded'); await pg.wait_for_selector('[data-testid=gd7-matrix]', timeout=20000)
                col = await pg.evaluate("""()=>{const th=document.querySelector('[data-testid=gd7-matrix] thead th'),tds=[...document.querySelectorAll('[data-testid=gd7-matrix] tbody td[data-gd7d]')];const rgb=e=>getComputedStyle(e).backgroundColor;const lum=c=>{const m=c.match(/\\d+/g).map(Number);return .2126*m[0]+.7152*m[1]+.0722*m[2]};let best=null;tds.forEach(t=>{const b=rgb(t);if(/rgba\\(0, 0, 0, 0\\)|transparent/.test(b))return;if(!best||lum(b)<lum(best))best=b});return [rgb(th),best]}""")
                ok(f'C2 ô đậm nhất ma trận ({col[1]}) khác màu thanh tiêu đề ({col[0]})', col[0] != col[1], col)
                await pg.goto(URL + '#/xu-huong-ky', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
                ky = await pg.evaluate("[...document.querySelectorAll('[data-testid=tr-table] tbody tr')].map(r=>r.children[0].textContent.trim())")
                d = lambda s: s[6:10] + s[3:5] + s[:2]
                ok(f'C3 Xu hướng kỳ: kỳ mới nhất ở hàng đầu ({ky[:3]})', len(ky) >= 2 and ky == sorted(ky, key=d, reverse=True), ky)
                await pg.goto(URL + '#/tai-san-bao-dam', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
                tx = await pg.inner_text('[data-testid=empty]')
                ok('C4 TSBĐ chưa có sao kê: lời nhắn nói rõ msit80 không chứa TSBĐ', 'msit80' in tx and 'KHÔNG chứa' in tx and 'Sao ke tai san bao dam' in tx, tx[:120])
            ok(f'{vw}px E1 0 pageerror', not errs, errs[:2]); await ctx.close()
        # C5 bố cục đã lưu cũ (không có l31) → đổi thứ tự cột một lần, giữ độ rộng
        ctx = await br.new_context(viewport={'width': 1366, 'height': 768}, locale='vi-VN'); await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
        pg = await ctx.new_page(); await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
        await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in F]); await pg.wait_for_timeout(3500)
        await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
        y = pg.locator('[data-testid="confirm-yes"]')
        if await y.count(): await y.click()
        await pg.wait_for_timeout(9000)
        old = {'gd7': '24.6.1', 'l21': 1, 'order': ['tenkh', 'cbtd', 'ngaytra', 'conlai', 'ngaygn', 'makh', 'hdtd', 'loai', 'nhom', 'hmtd', 'duno'], 'widths': {'tenkh': 333}, 'sort': [{'id': 'cbtd', 'desc': False}]}
        await pg.evaluate("v=>localStorage.setItem('qltd2_tbl_tat-ca-du-no',JSON.stringify(v))", old)
        await pg.goto(URL + '#/tat-ca-du-no', wait_until='domcontentloaded'); await pg.wait_for_timeout(3000)
        hs = await pg.evaluate(HEAD); dn = next((x for x in hs if x[0] == 'Dư nợ'), None); tk = next((x for x in hs if x[0].startswith('Tên khách')), None)
        ok(f'C5 bố cục đã lưu cũ (Dư nợ ở cuối): đổi thứ tự một lần — Dư nợ vào màn hình đầu ({dn}), giữ độ rộng cột đã chỉnh ({tk})', dn and dn[1] <= 1358 and tk and abs((tk[1] - tk[2]) - 333) <= 3, (dn, tk))
        old2 = {'gd7': '24.6.1', 'l21': 1, 'l31': 1, 'order': ['tenkh', 'cbtd', 'ngaytra', 'conlai', 'ngaygn', 'makh', 'hdtd', 'loai', 'nhom', 'hmtd', 'duno'], 'sort': [{'id': 'cbtd', 'desc': False}]}
        await pg.evaluate("v=>localStorage.setItem('qltd2_tbl_tat-ca-du-no',JSON.stringify(v))", old2)
        await pg.goto(URL + '#/tat-ca-du-no', wait_until='domcontentloaded'); await pg.reload(wait_until='domcontentloaded'); await pg.wait_for_timeout(3000)
        hs = await pg.evaluate(HEAD); dn2 = next((x for x in hs if x[0] == 'Dư nợ'), None)
        ok(f'C6 người dùng đã tự xếp cột sau khi cập nhật (có cờ l31): giữ nguyên thứ tự của họ ({dn2})', dn2 and dn2[1] > 1358, dn2)
        await ctx.close(); await br.close()
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
