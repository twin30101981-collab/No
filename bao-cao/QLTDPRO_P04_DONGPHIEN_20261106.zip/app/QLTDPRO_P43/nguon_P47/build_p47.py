# P47 · v24.17.3 — Sửa chữ mờ/không thấy ở chế độ Tương phản cao
SRC='app/QLTDPRO_v24.17.2.html'; DST='app/QLTDPRO_v24.17.3.html'
s=open(SRC,encoding='utf-8').read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n,('anchor count',c,n,old[:70]); s=s.replace(old,new)

# 1) lum(): tính cả độ trong suốt (alpha) — nền rgba(xanh đậm, 0.1) là nền SÁNG, không phải thanh tối
rep(r"function lum(c){var m=c.match(/[\d.]+/g)||[255,255,255];var r=+m[0],g=+m[1],b=+m[2];return .2126*r+.7152*g+.0722*b}",
    r"function lum(c){var m=c.match(/[\d.]+/g)||[255,255,255];var a=m.length>3?+m[3]:1;var r=255+(+m[0]-255)*a,g=255+(+m[1]-255)*a,b=255+(+m[2]-255)*a;return .2126*r+.7152*g+.0722*b}")

# 2) hcGuard(): đánh dấu phần tử đã gắn chữ trắng; gỡ khi nền không còn tối hoặc khi tắt chế độ tương phản cao
a=s.index('function hcGuard(){'); b=s.index('/* ================= 4) điều hướng bàn phím cho bảng dài',a)
assert s.count('function hcGuard(){')==1
new_fn=r"""function hcGuard(){
  var hc=document.documentElement.className.indexOf('gd7-hc')>=0;
  if(!hc){
    var old=document.querySelectorAll('[data-gd11-hcw]');
    for(var k=0;k<old.length;k++){try{old[k].style.removeProperty('color');old[k].removeAttribute('data-gd11-hcw')}catch(_){}}
    return;
  }
  var els=document.querySelectorAll('[data-testid="topbar"],[data-testid="main"],[data-testid="sidebar"],.gd7-drawer,[role="dialog"],[role="alertdialog"]');
  for(var i=0;i<els.length;i++){
    var all=[els[i]].concat([].slice.call(els[i].querySelectorAll('*')));
    for(var j=0;j<all.length;j++){
      var e=all[j],st;
      try{st=getComputedStyle(e)}catch(_){continue}
      var bg=st.backgroundColor,dark=!!bg&&bg!=='rgba(0, 0, 0, 0)'&&lum(bg)<80,mk=e.getAttribute('data-gd11-hcw');
      if(!dark){if(mk){try{e.style.removeProperty('color');e.removeAttribute('data-gd11-hcw')}catch(_){}}continue}
      if(mk)continue;
      if(e.style&&e.style.color&&lum(e.style.color)>=128)continue;
      var p=e,c=null;
      while(p){var pc;try{pc=getComputedStyle(p).color}catch(_){break}if(pc&&pc!=='rgba(0, 0, 0, 0)'){c=pc;break}p=p.parentElement}
      if(c&&lum(c)<80&&(e.textContent||'').trim()){try{e.style.color='#fff';e.setAttribute('data-gd11-hcw','1')}catch(_){}}
    }
  }
}

"""
s=s[:a]+new_fn+s[b:]

# 3) CSS: tiêu đề bảng trong chế độ tương phản cao luôn chữ sáng (không bị .text-muted-foreground !important đè)
rep("html.gd7-hc{ --gd7-head-bg:#14304F }",
    """html.gd7-hc{ --gd7-head-bg:#14304F }
/* Tiêu đề bảng: chữ sáng thắng .text-muted-foreground của chế độ tương phản cao (trước đây chữ xám đậm trên nền navy → mờ) */
html.gd7-hc [data-testid="main"] table thead th,html.gd7-hc [data-testid="main"] table thead th *,
html.gd7-hc table.gd7-t thead th,html.gd7-hc table.gd7-t thead th *,
html.gd7-hc [data-testid="dt-head"] > div:first-child > [data-testid="dt-th"],html.gd7-hc [data-testid="dt-head"] > div:first-child > [data-testid="dt-th"] *{color:var(--gd7-head-fg) !important}""")

rep('24.17.2','24.17.3',s.count('24.17.2'))
open(DST,'w',encoding='utf-8').write(s)
for f in ('app/sw.js','app/manifest.json'):
    t=open(f,encoding='utf-8').read().replace('24.17.2','24.17.3').replace('p46-','p47-')
    open(f,'w',encoding='utf-8').write(t)
print('OK',DST)
