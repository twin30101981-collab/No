# -*- coding: utf-8 -*-
# Kiểm thử P52 v24.17.8 — MỌI trang hiển thị mã KH dạng 3201-xxxxxxxxx (một hàm chung window.QLTD_maKH)
# Chạy: python3 kiem_thu_p52/test_ma_kh_moi_trang.py [tên_tệp_html]   (mặc định QLTDPRO_v24.17.8.html; cổng 8852)
# Dữ liệu thử tự sinh từ app/kiem_thu_p40/xlsx: đổi mọi mã KH thành 13 số bắt đầu 3201.
import asyncio, functools, http.server, threading, re, sys, tempfile
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE=Path(__file__).resolve().parent; ROOT=HERE.parent
HTML=sys.argv[1] if len(sys.argv)>1 else 'QLTDPRO_v24.17.8.html'
PORT=8852; BASE=f'http://127.0.0.1:{PORT}/{HTML}'
SRC=ROOT/'app'/'kiem_thu_p40'/'xlsx'; TMP=Path(tempfile.mkdtemp())
res=[]
def ok(n,c,info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ')+n+('' if c else ' — '+str(info)[:600]),flush=True)
def make():
    m={}
    def code(o):
        o=str(o).strip()
        if o not in m: m[o]='3201%09d'%(100000000+len(m)*7919%899999999)
        return m[o]
    for f in ('msit80_30-09-2026.xlsx','msit80_31-10-2026.xlsx'):
        wb=openpyxl.load_workbook(SRC/f); ws=wb.worksheets[0]
        for r in ws.iter_rows(min_row=2): r[0].value=code(r[0].value); r[0].number_format='@'
        wb.save(TMP/f)
    wb=openpyxl.load_workbook(SRC/'18_08_2026-TS.xlsx'); ws=wb.worksheets[0]; hdr=[c.value for c in ws[1]]
    ix=[i for i,h in enumerate(hdr) if h in('clcustno','plgcustno')]
    for r in ws.iter_rows(min_row=2):
        for i in ix:
            if r[i].value not in (None,''): r[i].value=code(r[i].value); r[i].number_format='@'
    wb.save(TMP/'18_08_2026-TS.xlsx'); return m
M=make(); FILES=[str(TMP/f) for f in ('msit80_30-09-2026.xlsx','msit80_31-10-2026.xlsx','18_08_2026-TS.xlsx')]
KH1=next(iter(M.values())); KH1D=KH1[:4]+'-'+KH1[4:]
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a,**k): pass
httpd=http.server.ThreadingHTTPServer(('127.0.0.1',PORT),functools.partial(Q,directory=str(ROOT/'app')))
threading.Thread(target=httpd.serve_forever,daemon=True).start()
JS="""(root)=>{const out=[];const re=/(?<![\\da-fA-F-])\\d{13}(?![\\da-fA-F])/g; /* P04: bỏ 13 số nằm trong chuỗi hex (mã băm SHA-256 ở title) — trước đây gây R2 chập chờn */
 const add=(k,t)=>{if(/^1[6-9]\\d{11}$/.test(t.trim()))return;const m=t.match(re);if(m)out.push(k+' '+m[0]+' :: '+t.replace(/\\s+/g,' ').slice(0,90));};
 (root?document.querySelector(root):document.body).querySelectorAll('*').forEach(el=>{ if(el.closest('script,style'))return;
   const t=Array.from(el.childNodes).filter(n=>n.nodeType===3).map(n=>n.textContent).join(' ');if(t)add('text',t);
   if(typeof el.value==='string'&&el.type!=='file'&&!/^(datetime|date)/.test(el.type||''))add('value',el.value);
   ['title','aria-label','placeholder'].forEach(a=>{const v=el.getAttribute&&el.getAttribute(a);if(v)add(a,v);});
 });return out;}"""
async def main():
    html=(ROOT/'app'/HTML).read_text(encoding='utf-8')
    ok('S1 có khối makh-js + hàm chung khoá cứng (defineProperty)', 'id="makh-js"' in html and 'defineProperty(window,"QLTD_maKH"' in html)
    ok('S2 quy tắc 13 số→4-9 chỉ còn MỘT bản (không còn bản sao rời)', len(re.findall(r'slice\(0,\s*4\)\s*\+\s*["\']-["\']',html))==1, len(re.findall(r'slice\(0,\s*4\)\s*\+\s*["\']-["\']',html)))
    async with async_playwright() as p:
        b=await p.chromium.launch(); ctx=await b.new_context(viewport={'width':1400,'height':1000},locale='vi-VN')
        await ctx.grant_permissions(['clipboard-read','clipboard-write'],origin=f'http://127.0.0.1:{PORT}')
        await ctx.add_init_script("""try{localStorage.setItem('gd9_tplok','0');
          localStorage.setItem('qltd2_hsvx_links_v1',JSON.stringify({hx_t:'%s|'}));
          localStorage.setItem('qltd2_hsvx_v1',JSON.stringify({hx_t:{id:'hx_t',ten:'Hồ sơ thử',product:'HMTD',v:{}}}));}catch(e){}"""%KH1)
        pg=await ctx.new_page(); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('console',lambda m:m.type=='error' and errs.append(m.text))
        await pg.goto(BASE+'#/nhap',wait_until='domcontentloaded'); await pg.wait_for_timeout(2000)
        await pg.set_input_files('[data-testid="file-input"]',FILES); await pg.wait_for_timeout(5000)
        await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
        y=pg.locator('[data-testid="confirm-yes"]')
        if await y.count(): await y.click()
        await pg.wait_for_timeout(5000)
        hrefs=await pg.evaluate("Array.from(new Set(Array.from(document.querySelectorAll('a[href^=\"#/\"]')).map(a=>a.getAttribute('href'))))")
        bare=[]; dashed=0
        async def scan(lbl):
            nonlocal dashed
            bare.extend(f'[{lbl}] {x}' for x in await pg.evaluate(JS,None))
            dashed+=await pg.evaluate("(document.body.innerText.match(/\\b3201-\\d{9}\\b/g)||[]).length")
        for h in hrefs:
            await pg.goto(BASE+h); await pg.wait_for_timeout(1700); await scan(h)
            tabs=pg.locator('[role=tab], [data-testid$="-tab"]'); n=await tabs.count()
            for i in range(min(n,25)):
                try: await tabs.nth(i).click(timeout=1500); await pg.wait_for_timeout(400); await scan(h+'#tab'+str(i))
                except Exception: pass
        ok(f'R1 quét {len(hrefs)} trang + các tab: có mã dạng 3201-xxxxxxxxx hiển thị (dữ liệu có thật)', dashed>200, dashed)
        ok('R2 KHÔNG còn mã 13 số liền (text/value/title/aria/placeholder) ở bất kỳ trang/tab nào', not bare, bare[:6])
        # Ô Mã KH có huy hiệu HSVV (Jb): trước đây in thô + mất nút copy
        await pg.goto(BASE+'#/tat-ca-du-no'); await pg.wait_for_timeout(2500)
        bd=pg.locator('[data-testid="qltd-hsvv-badge"]')
        ok('R3 có ô Mã KH kèm huy hiệu 📄 HSVV (KH đã liên kết hồ sơ)', await bd.count()>=1, await bd.count())
        if await bd.count():
            cell=bd.first.locator('xpath=ancestor::div[1]'); txt=(await cell.inner_text()).strip()
            ok('R4 ô huy hiệu hiển thị 3201-xxxxxxxxx', KH1D in txt and KH1 not in txt, txt)
            cp=cell.locator('[data-testid="dt-copy"]')
            ok('R5 ô huy hiệu vẫn chạm-để-copy', await cp.count()==1, await cp.count())
            if await cp.count():
                await cp.click(); await pg.wait_for_timeout(400); clip=await pg.evaluate('navigator.clipboard.readText()')
                ok('R6 copy ra đúng dạng 3201-xxxxxxxxx', clip==KH1D, clip)
        # Máy tính lãi
        await pg.goto(BASE+'#/lai-dong'); await pg.wait_for_timeout(2200)
        await pg.click('[data-testid="gd14-calc"]'); await pg.wait_for_timeout(500)
        async def hits(q):
            await pg.fill('[data-testid="gd14-calc-search"]',q); await pg.wait_for_timeout(350)
            return await pg.locator('[data-testid="gd14-calc-hit"]').all_inner_texts()
        h=await hits(KH1)
        ok('M1 tìm bằng mã thô 13 số vẫn ra KH, danh sách hiện 3201-xxxxxxxxx', len(h)>=1 and KH1D in h[0] and KH1 not in h[0], h[:1])
        h=await hits(KH1D)
        ok('M2 gõ đúng dạng 3201-xxxxxxxxx cũng tìm ra', len(h)>=1 and KH1D in h[0], h[:1])
        await pg.locator('[data-testid="gd14-calc-hit"]').first.click(); await pg.wait_for_timeout(400)
        sel=await pg.locator('[data-testid="gd14-calc-selected"]').inner_text()
        ok('M3 thẻ KH đã chọn: mã dạng 3201-xxxxxxxxx', KH1D in sel and KH1 not in sel, sel[:200])
        await pg.click('[data-testid="gd14-calc-copy"]'); await pg.wait_for_timeout(400)
        clip=await pg.evaluate('navigator.clipboard.readText()')
        ok('M4 "Copy kết quả" ghi mã dạng 3201-xxxxxxxxx', f'({KH1D})' in clip and KH1 not in clip, clip[:160])
        mb=await pg.evaluate(JS,'[data-testid="gd14-calc-overlay"]')
        ok('M5 toàn bộ modal Máy tính lãi không còn mã 13 số liền', not mb, mb[:3])
        ok('E1 không lỗi JS/console', not errs, errs[:3])
        await b.close()
    httpd.shutdown(); print(f'\nTỔNG: {sum(res)}/{len(res)}  ({HTML})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
