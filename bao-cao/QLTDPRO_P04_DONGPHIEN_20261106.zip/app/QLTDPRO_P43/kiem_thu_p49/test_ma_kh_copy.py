# -*- coding: utf-8 -*-
# Kiểm thử P49 v24.17.7 — trang Khách hàng mới, tab Chi tiết: mã KH chạm-để-copy như các trang khác
# Chạy: python3 kiem_thu_p49/test_ma_kh_copy.py   (cổng 8849; dùng tệp mẫu kiem_thu_p49/xlsx)
import asyncio, functools, http.server, threading
from pathlib import Path
from playwright.async_api import async_playwright
HERE=Path(__file__).resolve().parent; ROOT=HERE.parent
PORT=8849; URL=f'http://127.0.0.1:{PORT}/QLTDPRO_v24.17.8.html'
X=HERE/'xlsx'
FILES=[str(X/'msit80_30-09-2026.xlsx'),str(X/'msit80_31-10-2026.xlsx'),str(X/'18_08_2026-TS.xlsx')]
res=[]
def ok(n,c,info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ')+n+('' if c else ' — '+str(info)[:500]),flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a,**k): pass
httpd=http.server.ThreadingHTTPServer(('127.0.0.1',PORT),functools.partial(Q,directory=str(ROOT/'app')))
threading.Thread(target=httpd.serve_forever,daemon=True).start()
async def run(p,tag,vw,vh):
    print(f'\n== {tag} {vw}x{vh} ==',flush=True)
    b=await p.chromium.launch(); ctx=await b.new_context(viewport={'width':vw,'height':vh},locale='vi-VN')
    await ctx.grant_permissions(['clipboard-read','clipboard-write'],origin=f'http://127.0.0.1:{PORT}')
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg=await ctx.new_page(); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('console',lambda m:m.type=='error' and errs.append(m.text))
    T=tag+' '
    try:
        await pg.goto(URL+'#/khach-hang-moi',wait_until='domcontentloaded'); await pg.wait_for_timeout(1800)
        await pg.set_input_files('input[type=file][multiple]',FILES); await pg.wait_for_timeout(5000)
        await pg.click('[data-testid="khm-go"]'); await pg.wait_for_timeout(2500)
        await pg.get_by_text('Chi tiết',exact=True).first.click(); await pg.wait_for_timeout(600)
        await pg.get_by_role('button',name='KH vay mới').first.click(); await pg.wait_for_timeout(600)
        n=await pg.locator('[data-testid="khm-t-chitiet"] [data-testid="dt-copy"]').count()
        rows=await pg.locator('[data-testid="khm-t-chitiet"] tbody tr').count()
        ok(T+'B1 bảng Chi tiết "KH vay mới" có dòng và mỗi dòng có ô mã KH copy được', rows>0 and n==rows, (rows,n))
        c=pg.locator('[data-testid="khm-t-chitiet"] [data-testid="dt-copy"]').first
        code=(await c.inner_text()).strip()
        ok(T+'B2 ô mã KH nhận dạng là nút chạm-để-copy (role=button, title "Chạm để copy Mã KH")', await c.get_attribute('role')=='button' and 'Mã KH' in (await c.get_attribute('title') or ''), code)
        await c.scroll_into_view_if_needed(); await pg.screenshot(path=str(HERE/f'{tag}_01_chi_tiet.png'))
        await c.click(); await pg.wait_for_timeout(500)
        clip=await pg.evaluate('navigator.clipboard.readText()')
        ok(T+'B3 bấm → bộ nhớ tạm chứa đúng mã KH (không kèm chữ "mới")', clip==code and code!='' and 'mới' not in clip, (clip,code))
        ok(T+'B3b mã hiển thị + copy dạng 3201-xxxxxxxxx (13 số → 4 số - 9 số)', __import__('re').fullmatch(r'\d{4}-\d{9}',code) is not None and __import__('re').fullmatch(r'\d{4}-\d{9}',clip) is not None, (code,clip))
        ok(T+'B4 hiện thông báo "Đã copy Mã KH"', await pg.get_by_text('Đã copy Mã KH').count()>=1)
        sel=await pg.evaluate("document.querySelectorAll('[data-testid=\"khm-t-chitiet\"] tbody tr').length")
        ok(T+'B5 bấm copy không làm đổi tick/hàng (số dòng giữ nguyên)', sel==rows)
        ok(T+'B6 nhãn "mới" vẫn hiện ở mọi dòng, cạnh mã', await pg.locator('[data-testid="khm-t-chitiet"] tbody tr small span:has-text("mới")').count()==rows)
        hdr=await pg.locator('[data-testid="khm-t-chitiet"] thead th').all_inner_texts()
        ok(T+'B8 cột "Mã KH" riêng, đứng ngay sau "Khách hàng"', hdr.index('Mã KH')==hdr.index('Khách hàng')+1, hdr)
        c0=await pg.locator('[data-testid="khm-t-chitiet"] tbody tr').first.locator('td').all_inner_texts()
        nm=[x for x in c0 if 'Trần' in x][0]
        ok(T+'B9 ô tên khách không còn chứa mã (chỉ tên + nhãn)', not any(ch.isdigit() for ch in nm.replace('mới','')), nm)
        ok(T+'B7 không lỗi JS/console', not errs, errs[:3])
    except Exception as e:
        ok(T+'LỖI chạy',False,repr(e)); await pg.screenshot(path=str(HERE/f'{tag}_loi.png'))
    await b.close()
async def main():
    async with async_playwright() as p:
        await run(p,'mobile',390,844); await run(p,'desktop',1280,1100)
    print(f'\nTỔNG: {sum(res)}/{len(res)}'); httpd.shutdown()
    raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
