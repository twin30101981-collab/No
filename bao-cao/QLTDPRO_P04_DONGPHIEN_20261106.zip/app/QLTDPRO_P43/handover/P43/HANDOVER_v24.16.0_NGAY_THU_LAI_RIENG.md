# QLTDPRO P43 · v24.16.0 — Ngày thu lãi RIÊNG từng khoản (bàn giao 04/11/2026)

Nguồn vá = `app/QLTDPRO_v24.15.0.html` → dựng `app/QLTDPRO_v24.16.0.html` bằng `nguon_P43/build_p43.py`.
Kế thừa luật P39–P42: chỉ vá chuỗi chính xác đếm đúng số lần; **lõi `nguon_P41/qltd_lai.cjs` giữ nguyên từng byte**
(bản dựng kiểm sha256); không mạng, không đổi CSP, không đổi 4 CSDL. `nguon_P43/gd14_ui.js` = `nguon_P42_mtl/gd14_ui.js` + 13 điểm vá (đếm đúng số lần).

## 1 · Thay đổi trong modal "Máy tính lãi" (tab Tra cứu KH)
- **Cột mới "NGÀY THU LÃI"** (đặt trước SỐ NGÀY): ô ngày riêng cho từng khoản. **Để trống = theo ô "Chốt lãi đến ngày" chung** (nhãn mờ ghi ngày chung). Khoản có ngày riêng tô cam + nhãn "riêng" + nút ↺ bỏ ngày riêng.
- **Thanh công cụ trên bảng**: chọn một ngày → "Áp cho khoản đã tick" · "Xoá ngày riêng".
- Đổi ngày chung → chỉ khoản chưa có ngày riêng đổi theo. Khoản có ngày riêng giữ nguyên.
- Dòng thông tin dưới thanh tổng (chỉ hiện khi có ngày riêng): "N ngày thu khác nhau · x/y khoản đã tick dùng ngày riêng".
- **Copy kết quả**: mỗi dòng có "mốc … → thu đến dd/mm/yyyy"; thêm dòng "Có N khoản chốt ngày riêng".
- Tab "Tính tay" không đổi. Lõi `QLTDLai.tinhLaiKhoan(row, {chot})` vốn nhận ngày chốt theo từng lần gọi → không đổi công thức.

## 2 · Rào an toàn
1. Không chọn ngày riêng ⇒ kết quả giống hệt v24.15.0.
2. Ngày riêng < "đã thu lãi đến": ô ngày có `min` chặn; nếu vẫn lọt, lõi báo "không tính được", khoản **không cộng vào tổng** + hộp cảnh báo.
3. "Áp hàng loạt" **bỏ qua** khoản mà ngày thu trước mốc của khoản đó và báo số khoản bị bỏ qua.
4. Ngày trống/sai định dạng ⇒ quay về ngày chung (không bao giờ ra 0 âm thầm).
5. Quá hạn vẫn tách theo ngày đến hạn từng khoản (r[7]) với chính ngày thu của khoản đó (LS × 1,5, tròn từng phần).
6. Reset bảng / chọn khách hàng khác / mở lại modal ⇒ xoá ngày riêng. Không lưu giữa các lần mở (tránh dính ngày cũ).

## 3 · Kiểm chứng (nhật ký `kiem_thu_p43/ket_qua/`)
| Bộ | Kết quả |
|---|---|
| `python3 kiem_thu_p43/test_ngay_rieng.py` — Playwright mobile 390×844 + desktop 1280×1800, so với phép tính độc lập Python (Fraction, tròn nửa-lên): mặc định · ngày riêng · đổi ngày chung · ca quá hạn · ngày trước mốc · ↺ · áp hàng loạt · bỏ qua · Copy · Reset · đổi KH · tab Tính tay · console | **38/38** (19 ca × 2), sai lệch **0 đ** |
| `node kiem_thu_p41/test_lai_unit.test.cjs` (lõi) | **18/18** |
| `node kiem_thu_p42_mtl/test_lai_mtl.test.cjs` (lõi — bổ sung) | **11/11** |
| `test_may_tinh_lai_v24160.py` (bộ Máy tính lãi P42 chạy lại trên v24.16.0) | **80/80** |
| `hoi_quy_regress_v24160.py` (hồi quy P42, mốc CSP = v24.15.0) | **86/86** |
| Dựng 2 lần | md5 trùng `8f5d7afb06c81d2d9bb566fcbc0f2269` |
| Lõi `qltd_lai.cjs` | sha256 `55908dc6…a1db85a1a0` không đổi |
Ảnh: `kiem_thu_p43/anh/{mobile,desktop}_01_ngay_rieng.png`, `_02_cuoi.png`.

## 4 · Ghi chú / còn mở
1. Ca console bỏ qua cảnh báo "404 Failed to load resource": app tải mẫu `templates/…/Bảng kê mua hàng.docx` (không nằm trong gói); **v24.15.0 cũng bị y hệt**, không do P43.
2. Gói P42 không kèm `QLTDPRO_v24.14.0.html` nên bộ hồi quy dùng v24.15.0 làm mốc so CSP (CSP 14→15 đã xác nhận không đổi; 15→16 không đổi).
3. Lãi vẫn tính trên dư nợ đến ngày thu; trả gốc không giảm lãi kỳ này (như P42). Lãi chậm trả 10% chỉ có ở công cụ "Tính lãi tất toán".
4. Tồn đọng P42 vẫn còn: chạy đủ 42/42 gd14 trên máy có Chrome thường; xác nhận định dạng ngày tệp IPCAS thật; đối chiếu ≥ 20 khoản thật với chứng từ.
5. Chưa kiểm trên trình duyệt thật của máy chi nhánh — nên thử 1 khách hàng có nhiều giấy nhận nợ và đối chiếu IPCAS trước khi dùng chính thức.

## 5 · Dùng / dựng / hoàn tác
- Dùng: chép `app/QLTDPRO_v24.16.0.html` + `sw.js` + `manifest.json` đè bản cũ (dữ liệu giữ nguyên; làm mới trang để Service Worker nhận cache `qltdpro-p43-v24.16.0`).
- Dựng lại: `python3 nguon_P43/build_p43.py`. Toàn vẹn: `sha256sum -c handover/P43/MANIFEST_v24.16.0.sha256` (chạy ở thư mục gốc gói).
- Hoàn tác: dùng lại `app/QLTDPRO_v24.15.0.html` + `sw.js`/`manifest.json` (chỉnh lại trỏ về 24.15.0).
