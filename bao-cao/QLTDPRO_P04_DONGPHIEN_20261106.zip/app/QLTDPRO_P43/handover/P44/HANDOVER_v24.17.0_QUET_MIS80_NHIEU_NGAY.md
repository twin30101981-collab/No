# QLTDPRO P44 · v24.17.0 — Khách hàng mới: quét mọi bản MIS80 giữa 2 mốc (04/11/2026)

Nguồn vá = `app/QLTDPRO_v24.16.0.html` → dựng `app/QLTDPRO_v24.17.0.html` bằng `nguon_P44/build_p44.py` (chỉ vá chuỗi chính xác, đếm đúng số lần; không đổi CSP, không đổi 4 CSDL).

## Thay đổi
1. **Nạp từ Lưu trữ** (trang Khách hàng mới): ngoài mốc đầu/cuối, app đọc thêm **mọi bản MIS80 đã lưu từ ngày đầu kỳ đến ngày cuối kỳ** (mỗi ngày lấy bản lưu mới nhất), gộp theo khóa `brcd|apprseq|dsbsseq`, chỉ giữ món có ngày giải ngân sau mốc đầu. Thông báo: "Đã quét N bản MIS80 giữa 2 mốc."
2. **Báo cáo**: món có ở ngày giữa kỳ nhưng vắng ở mốc cuối được thêm vào bảng Giải ngân với dư nợ cuối = 0, gắn nhãn **"đã tất toán"** (rê/bấm hiện "thấy lần cuối dd/mm/yyyy"). Món này tính vào Món/Tiền giải ngân, KH vay mới và cầm cố như món thường.
3. **Cầm cố của món đã tất toán**: vẫn tra theo TSBĐ hiện hành + TSBĐ đầu kỳ. Không thấy TSBĐ → nhãn **"cầm cố?"** (chưa xác định, cần rà tay), không kết luận "không cầm cố".
4. KH mới vẫn = KH không có dư nợ ở mốc đầu kỳ (không đổi).

## An toàn
- Dữ liệu quét thêm chỉ dùng khi 2 tệp đầu/cuối đang nạp đúng là cặp vừa nạp từ Lưu trữ (so số dòng). Nạp tay tệp khác ⇒ chạy như v24.16.0.
- Không có bản lưu giữa kỳ ⇒ kết quả giống hệt v24.16.0.

## Còn mở / chưa làm
- Chưa kiểm trên trình duyệt: cần thử 1 kỳ thật (có món giải ngân rồi tất toán trong kỳ) và đối chiếu MIS80 từng ngày.
- Tải Excel chưa thêm cột "đã tất toán" (dòng tất toán vẫn có trong file, dư nợ = 0).
- Món giải ngân và tất toán trong cùng 1 ngày không có bản lưu nào bắt được.
- Chưa thêm kho lịch sử TSBĐ (chờ đồng ý).

## Dùng / hoàn tác
Chép `app/QLTDPRO_v24.17.0.html` + `sw.js` + `manifest.json` đè bản cũ, làm mới trang. Hoàn tác: dùng lại `app/QLTDPRO_v24.16.0.html` + chỉnh sw/manifest về 24.16.0.
