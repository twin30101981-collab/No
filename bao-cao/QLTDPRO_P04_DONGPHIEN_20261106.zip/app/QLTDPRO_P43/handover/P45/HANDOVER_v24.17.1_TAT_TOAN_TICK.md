# QLTDPRO P45 · v24.17.1 — Món tất toán trong kỳ: chỉ tính Giải ngân, tick để chuyển sang KH vay mới (04/11/2026)

Nguồn vá = `app/QLTDPRO_v24.17.0.html` → `app/QLTDPRO_v24.17.1.html` bằng `nguon_P45/build_p45.py` (vá chuỗi chính xác, đếm đúng số lần; không đổi CSP, không đổi 4 CSDL). **Thay phần "tính vào KH vay mới/cầm cố" của P44.**

- Món giải ngân rồi tất toán ngay trong kỳ (nhãn "đã tất toán") **mặc định chỉ tính vào Giải ngân**; không vào KH vay mới, không vào cầm cố, không vào danh sách KH cũ vay cầm cố.
- Tab **Chi tiết** có nút mới **"Tất toán trong kỳ"**: cột tick "Chuyển KH vay mới". Tick ⇒ món tính vào KH vay mới (và cầm cố nếu mã KH có TSBĐ; không có ⇒ nhãn "cầm cố?"). Bỏ tick ⇒ trả về chỉ Giải ngân. Mỗi lần tick báo cáo tự tính lại, giữ nguyên tab và bộ lọc.
- Lựa chọn tick lưu trên máy (localStorage `qltdpro_khm_tick_v1`, khóa `brcd|apprseq|dsbsseq`), còn khi mở lại app.
- Tải Excel phản ánh theo tick.

## Còn mở
Chưa kiểm trên trình duyệt; cần thử 1 kỳ thật. Chưa thêm kho lịch sử TSBĐ. Excel chưa có cột "đã tất toán".
Hoàn tác: dùng lại `app/QLTDPRO_v24.17.0.html` hoặc v24.16.0 + sw/manifest tương ứng.
