# QLTDPRO P50 · v24.17.6 — Khách hàng mới: "Mã KH" thành cột riêng (04/11/2026)

Nguồn vá = `app/QLTDPRO_v24.17.5.html` → `app/QLTDPRO_v24.17.6.html` bằng `nguon_P49/build_p50.py` (vá 4 vị trí, đếm đúng số lần; không đổi CSDL/CSP/lõi lãi).

## Thay đổi (bảng Chi tiết, 4 chế độ Giải ngân · KH vay mới · Cầm cố · Tất toán)
- Cột mới **"Mã KH"** đứng ngay sau cột "Khách hàng"; mã vẫn bấm-để-copy (ô `cC` như các trang khác).
- Ô "Khách hàng" chỉ còn **tên** (+ nhãn mới / cầm cố / đã tất toán ở dòng nhỏ) nên dễ đọc hơn.
- Dòng "Không có món vay phù hợp" giãn đủ 10 cột (colSpan 9 → 10).

## Kiểm chứng
`python3 kiem_thu_p49/test_ma_kh_copy.py` → **18/18** (mobile + desktop): cột Mã KH ngay sau Khách hàng, ô tên không còn chứa mã, copy đúng mã + thông báo, nhãn "mới" còn, 0 lỗi console.

## Còn mở
Mục 3 (thiết kế lại giao diện Máy tính lãi) chưa làm. Chưa thử trên dữ liệu IPCAS thật.
Hoàn tác: dùng lại `app/QLTDPRO_v24.17.5.html` + `sw.js`/`manifest.json` (đổi 24.17.6 → 24.17.5).
