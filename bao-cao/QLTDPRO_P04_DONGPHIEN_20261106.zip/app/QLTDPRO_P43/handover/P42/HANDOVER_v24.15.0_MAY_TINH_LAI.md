# QLTDPRO P42 · v24.15.0 — Máy tính lãi (bàn giao 03/11/2026)

Thực thi `PHAN_TICH_MAY_TINH_LAI_P42.md` (kèm trong thư mục này). Nguồn vá = `app/QLTDPRO_v24.14.0.html`
→ dựng `app/QLTDPRO_v24.15.0.html` bằng `nguon_P42_mtl/build_p42_mtl.py`. Kế thừa luật P39–P42: chỉ vá
chuỗi chính xác đếm đúng số lần; nghiệp vụ/trình bày mới nằm ở lớp **gd14**; lõi `nguon_P41/qltd_lai.cjs`
**giữ nguyên từng byte** (bản dựng kiểm sha256 trước khi nối); không mạng, không đổi CSP, không đổi 4 CSDL.

## 1 · Thay đổi

| Hạng mục | Nội dung |
|---|---|
| `nguon_P42_mtl/gd14_ui.js` | = `nguon_P42/gd14_ui.js` + khối **Máy tính lãi** (`GD14.openCalc`, `closeCalc`, `calc`); P42 cũ không đổi dòng nào (chỉ đổi nhãn `PHIEN_BAN` → `P42-GD14 1.1.0`) |
| Điểm vá HTML | 2 nhãn phiên bản (24.14.0 → 24.15.0) + 1 nút `gd14-calc` “🔢 Máy tính lãi” trên thanh công cụ trang **Lãi đọng** và **Nợ đến hạn** (đã kiểm: ngoài khối gd14 chỉ khác đúng 3 điểm này) |
| `sw.js` / `manifest.json` | cache `qltdpro-p42-v24.15.0`, trỏ `QLTDPRO_v24.15.0.html` |
| Công cụ “Tính lãi tất toán” (P41) | giữ nguyên, vẫn ở chỗ cũ |

### Modal “Máy Tính Lãi — Cơ Sở 365 Ngày” (theo mockup)
- Băng công thức TT 14/2017/TT-NHNN Điều 4; **2 tab**: Tra cứu KH từ hệ thống / Tính tay (nhập tự do).
- Ô **Chốt lãi đến ngày** + nút **Hôm nay** (mặc định = ngày chốt đang dùng ở trang Lãi đọng).
- Tìm KH theo tên (không dấu cũng được), mã đơn vị, số HĐTD hoặc số khế ước GN → thẻ **Tổng dư nợ** +
  “N khoản vay còn dư nợ”.
- Bảng 14 cột cuộn ngang, **cột tick + TÊN KH ghim**, tiêu đề cột ghi nguồn trường IPCAS
  (`apprseq`, `lstintchrgprd`, `dsbsdt`, `dsbsmatdt · r[7]`, `dsbsbal`, `sprd`); dòng nhỏ dưới ngày đến hạn
  là đáo hạn HĐTD (`apprmatdt`, chỉ tham khảo).
- Thanh **4 ô tổng**: Số khoản đã tick · Tổng trả gốc · Tổng lãi phải thu · Tổng thu (gốc + lãi).
- **Copy kết quả** (bộ nhớ tạm, có dự phòng) · **Reset bảng** · Đóng / Esc / ×. Mobile: toàn màn hình.

### Bảy lỗi V2 đã xử lý
| Mã | Xử lý trong v24.15.0 | Ca kiểm |
|---|---|---|
| L1 | Lãi quá hạn = LS hợp đồng × 1,5 (lõi: cơ bản + phạt 50%); cột ghi “LS × 1,5”; không còn 4,25% | M15, M16, MTL7 |
| L2 | Mọi số lấy từ `QLTDLai.tinhLaiKhoan` — tròn từng thành phần, tổng = cộng số đã tròn | M5–M7, MTL2–3 |
| L3 | Một nguồn tính duy nhất; không chép công thức sang giao diện (P42 vốn không có công thức QH song song) | rà mã |
| L4 | Quá hạn xét theo `r[7]` dsbsmatdt (đến hạn khoản GN), không theo `r[24]` apprmatdt | M15b, MTL8 |
| L5 | Khoản lỗi: dòng xám “Không tính được — lý do”, ghim “⛔ Không tính được” ở cột tên; **không cộng** vào tổng + hộp thông báo | M17, M17b, M19b, MTL9–11 |
| L6 | “Khoản còn dư nợ” và Tổng dư nợ chỉ tính dư nợ > 0; dòng ≤ 0 mặc định không tick | M21, M21b |
| L7 | Trả gốc > dư nợ khoản → chặn bằng dư nợ + cảnh báo đỏ; Tổng thu = trả gốc + lãi | M10–M10c |

## 2 · Kiểm chứng (nhật ký trong `kiem_thu_p42_mtl/ket_qua/`)

| Bộ | Kết quả |
|---|---|
| Phép tính độc lập Python (`du_lieu_mtl.py`, phân số chính xác, tròn nửa-lên) | mockup **18.532.601 đ** · ca quá hạn **3.495.890 đ** |
| `node kiem_thu_p41/test_lai_unit.test.cjs` (lõi P41) | **18/18** |
| `node kiem_thu_p42_mtl/test_lai_mtl.test.cjs` (lõi — ca bổ sung: mockup, quá hạn, chốt trước mốc, dư nợ 0, thiếu LS, làm tròn) | **11/11** |
| `python3 kiem_thu_p42_mtl/test_may_tinh_lai.py` — Playwright **mobile 390×844** + **desktop 1280×1800**: nhập tệp IPCAS thật qua trang Nhập → mở modal → đọc từng ô DOM, so với Python ở 4 ngày chốt (03/11/2026, 10/11/2026, 20/04/2027 có 9 khoản quá hạn, Hôm nay); tick/bỏ tick; trả gốc vượt dư nợ; cuộn ngang + cột ghim; Copy; Reset; ca quá hạn; ca lỗi; tính tay; đóng; lỗi console | **80/80** (40 ca × 2 cỡ màn hình), sai lệch **0 đ**, **0** lỗi console/runtime |
| `kiem_thu_p42_mtl/hoi_quy_regress_v24150.py` (bộ hồi quy P42 chạy lại trên v24.15.0) | **86/86** |
| `kiem_thu_p42_mtl/hoi_quy_gd14_v24150.py` (bộ gd14 P42 42 ca chạy lại trên v24.15.0) | **32/32 ca chạy được đạt**; 10 ca (D6–D10, B7–B11) **bỏ qua** — xem §3.1 |
| Dựng 2 lần | md5 trùng `92109ec0bc2d402d7ae4bd6b65e67129` |
| Lõi `qltd_lai.cjs` | sha256 `55908dc6…a1db85a1a0` = MANIFEST P42; nhúng nguyên văn trong HTML (đã so byte) |
| CSP | không đổi so với v24.14.0 |

Ảnh bằng chứng: `kiem_thu_p42_mtl/anh/{mobile,desktop}_01…12_*.png` (mở modal, tìm kiếm, bảng VXT,
thanh tổng, cuộn ngang, trả gốc vượt dư nợ, sau reset, chốt 20/04/2027 quá hạn, ca quá hạn 3.495.890,
chú giải thành phần, khoản không tính được, tính tay) + `hoi_quy_keo_tha_zip.png`.

## 3 · Ghi chú / còn mở
1. **10 ca gd14 không chạy được trong container kiểm thử**: sau khi lưu handle thư mục OPFS vào IndexedDB,
   tải lại trang làm **sập cả trình duyệt Chromium** của môi trường này (tái hiện được bằng trang HTML
   trống, không dùng mã app; bản gốc v24.14.0 cũng sập đúng bước này). Các ca đó chỉ kiểm phần thư mục
   IPCAS — mã phần này **không đổi** so với P42. Cần chạy lại `python3 kiem_thu_p42/test_gd14_p42.py`
   (hoặc bản `_v24150`) trên máy có Chrome thường để xác nhận 42/42.
2. **Định dạng ngày của bộ nhập (có sẵn, không sửa)**: ngày `a/b/yyyy` mà cả a, b ≤ 12 được đọc theo
   **MM/DD/YYYY** (quy ước tệp msit80 IPCAS). Dữ liệu kiểm thử vì vậy ghi ngày kiểu MM/DD/YYYY. Nếu tệp
   IPCAS thật xuất DD/MM/YYYY thì mọi ngày ≤ 12 sẽ bị đảo — nên đối chiếu 1 tệp thật (liên quan GĐ4).
3. Bộ nhập loại dòng dư nợ 0 khỏi dữ liệu, nên L6 được kiểm thêm bằng gọi `GD14.openCalc` trực tiếp.
4. 27 cột dữ liệu không có mã khách hàng (custno): KH được nhóm theo **tên + brcd**; thẻ ghi “Mã đơn vị
   (brcd)” thay cho “Mã KH” của mockup.
5. Trả gốc không làm giảm lãi kỳ này (lãi tính trên dư nợ đến ngày chốt) — giống V2; lãi chậm trả 10%
   vẫn chỉ có trong công cụ “Tính lãi tất toán”.
6. Nút mở modal đặt ở trang Lãi đọng và Nợ đến hạn; chưa thêm ở Tổng quan (có thể gọi `GD14.openCalc(rows)`).

## 4 · Dùng / dựng / hoàn tác
- Dùng: chép `app/QLTDPRO_v24.15.0.html` + `sw.js` + `manifest.json` đè bản cũ (dữ liệu giữ nguyên).
- Dựng lại: `python3 nguon_P42_mtl/build_p42_mtl.py`. Toàn vẹn: `cd app && sha256sum -c ../handover/P42/MANIFEST_v24.15.0.sha256`.
  (`MANIFEST.sha256` của P42 gốc sẽ báo khác ở `sw.js`/`manifest.json` — hai tệp này đã chuyển sang 24.15.0; tệp
  `kiem_thu_p42_mtl/msit80_03-11-2026.xlsx` được sinh lại mỗi lần chạy kiểm nên không nằm trong MANIFEST.)
- Hoàn tác: dùng lại `app/QLTDPRO_v24.14.0.html` + `sw.js`/`manifest.json` của gói P42 gốc.
