# PROMPT PHIÊN SAU — P42 (v24.14.0, 03/11/2026)
Kế thừa luật P39/P40/P41/P42: chỉ vá chuỗi chính xác đếm đúng số lần (`nguon_P42/build_p42.py`,
nguồn = `app/QLTDPRO_v24.13.0.html` → nâng nguồn lên 24.14.0 khi có P43); trình bày/nghiệp vụ
mới → lớp **gd14** (`nguon_P42/gd14_ui.js`, lõi tính lãi `nguon_P41/qltd_lai.cjs` giữ nguyên);
không mạng, không đổi CSP, không đổi lược 4 CSDL (`QLTDProDB`, `TWIN_Archive_v1`, `QLTDProTSBD`,
`QLTDKhachHangMoi`); handle thư mục + tuỳ chọn quét ở CSDL riêng `QLTDProFolder_v1`; giữ testid
hiện có (mới P42: `gd14-folder-sub`, `gd14-folder-sublbl`, cột `nguon`).
Bộ kiểm: `node kiem_thu_p41/test_lai_unit.test.cjs` (18/18) · `python3 kiem_thu_p42/test_gd14_p42.py`
(42/42, cổng 8825) · hồi quy `python3 kiem_thu_p42/test_p42_regress.py` (86/86, cổng 8824; cần
fixtures `app/kiem_thu_p40/zip/` + `kiem_thu_p42/zip/`).
Backlog: (1) chạy lại `test_p39` 125/125 — cần file bộ kiểm (thiếu từ P41); (2) đối soát lãi với
intamt (Q7 — chờ chủ dự án); (3) thử quyền thư mục tắt/mở trình duyệt trên máy chi nhánh + file://
hay https (Q5); (4) đối chiếu ≥ 20 khoản thật với chứng từ (GĐ4); (5) RAR thật — cần duyệt
'wasm-unsafe-eval' trong CSP; (6) zip mẫu từ WinRAR / Windows Explorer — cần máy Windows
(7-Zip, Info-ZIP, bzip2, zip64 đã kiểm ở P42); (7) các mục backlog P39/P40 còn lại — mục "cột
Nguồn trong bảng kế hoạch" ĐÃ xong ở P42.

## Bổ sung sau v24.15.0 (Máy tính lãi)
Nguồn vá phiên sau = `app/QLTDPRO_v24.15.0.html`; glue gd14 hiện hành = `nguon_P42_mtl/gd14_ui.js` (`PHIEN_BAN`
`P42-GD14 1.1.0`, testid mới `gd14-calc*`). Bộ kiểm: `node kiem_thu_p42_mtl/test_lai_mtl.test.cjs` (11/11) ·
`python3 kiem_thu_p42_mtl/test_may_tinh_lai.py` (80/80, cổng 8826) · hồi quy `kiem_thu_p42_mtl/hoi_quy_regress_v24150.py`
(86/86, cổng 8827) · `kiem_thu_p42_mtl/hoi_quy_gd14_v24150.py` (42 ca, cổng 8828; `QLTD_SKIP_RELOAD=1` khi Chromium
môi trường sập lúc tải lại có handle thư mục). Backlog thêm: (a) chạy đủ 42/42 gd14 trên máy có Chrome thường;
(b) xác nhận định dạng ngày tệp IPCAS thật (bộ nhập đọc a/b/yyyy mơ hồ theo MM/DD); (c) nút Máy tính lãi ở Tổng quan
nếu cần; (d) mã KH (custno) nếu IPCAS có cột — hiện nhóm KH theo tên + brcd.

## Bổ sung sau v24.16.0 (P43 — Ngày thu lãi riêng)
Nguồn vá phiên sau = `app/QLTDPRO_v24.16.0.html`; glue gd14 hiện hành = `nguon_P43/gd14_ui.js` (`PHIEN_BAN` `P43-GD14 1.2.0`, testid mới `gd14-calc-ngay`, `-ngay-lbl`, `-ngay-clr`, `-ngay-info`, `gd14-calc-bulk*`). Bộ kiểm: `kiem_thu_p43/test_ngay_rieng.py` (38/38, cổng 8829) · `test_may_tinh_lai_v24160.py` (80/80, cổng 8836) · `hoi_quy_regress_v24160.py` (86/86, cổng 8837). Chi tiết: `handover/P43/HANDOVER_v24.16.0_NGAY_THU_LAI_RIENG.md`.
