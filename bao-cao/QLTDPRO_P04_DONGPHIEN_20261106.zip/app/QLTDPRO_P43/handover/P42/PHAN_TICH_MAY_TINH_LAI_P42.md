# Phân tích Máy tính lãi QLTD V2 → Đề xuất tích hợp P42

**Phiên bản tham chiếu:** P42 v24.15.0\
**Ngày chốt nghiệp vụ:** 03/11/2026\
**Trạng thái:** Đã chốt quy tắc nghiệp vụ; tài liệu đặc tả thực thi và
kiểm thử

------------------------------------------------------------------------

## 1. Quyết định đã chốt

  -----------------------------------------------------------------------
  Hạng mục                            Quyết định
  ----------------------------------- -----------------------------------
  Lãi suất quá hạn                    **150% lãi suất cho vay trong hạn**
                                      (lãi suất hợp đồng × 1,5)

  Cơ sở xác định quá hạn              **Ngày đến hạn của từng khoản giải
                                      ngân**

  Lõi tính lãi                        Giữ nguyên `qltd_lai.cjs`; không
                                      sửa lõi

  Lớp tích hợp                        `gd14`

  Quy tắc làm tròn                    Làm tròn từng khoản/thành phần theo
                                      lõi trước khi cộng tổng

  Giao diện                           Bám sát mockup đã cung cấp

  Kiểm chứng                          Playwright trên mobile và desktop;
                                      so sánh với phép tính độc lập

  Tiêu chí sai số                     **0 đồng** trên mọi ca đối chiếu
                                      được xác định
  -----------------------------------------------------------------------

## 2. Kết quả kiểm chứng mockup

Khách hàng: **Vũ Xuân Tuấn**\
Ngày chốt: **03/11/2026**\
Ngày "đã thu lãi đến": **22/10/2026**\
Số ngày tính lãi: **12 ngày**\
Cả 10 khoản trong hạn.

        Dư nợ (đ)   Lãi suất   Lãi 12 ngày (đã làm tròn từng khoản)
  --------------- ---------- --------------------------------------
    1.000.000.000       8,8%                              2.893.151
      500.000.000       8,8%                              1.446.575
      500.000.000       8,8%                              1.446.575
      500.000.000       8,8%                              1.446.575
      650.000.000       8,8%                              1.880.548
      700.000.000       9,5%                              2.186.301
      700.000.000       8,8%                              2.025.205
      700.000.000       8,8%                              2.025.205
      550.000.000       8,8%                              1.591.233
      550.000.000       8,8%                              1.591.233
         **Tổng**                                    **18.532.601**

### Đối chiếu

-   Tính độc lập bằng Python, cộng các số đã làm tròn từng khoản:
    **18.532.601 đ**.
-   Lõi `qltd_lai.cjs` (P41) chạy cùng dữ liệu: **18.532.601 đ**.
-   Bộ kiểm lõi hiện có: **18/18 đạt**.
-   Nếu cộng số chưa làm tròn rồi mới làm tròn tổng: **18.532.603 đ**,
    lệch **2 đ** so với chứng từ.
-   **Kết luận:** giữ nguyên quy tắc làm tròn từng khoản rồi cộng.

## 3. Bảy lỗi của V2 cần xử lý

Các lỗi dưới đây chỉ bộc lộ rõ khi phát sinh khoản quá hạn; bộ mockup 10
khoản trong hạn không đủ để phát hiện.

  -------------------------------------------------------------------------------
  Mã                Hiện trạng V2      Rủi ro            Hướng xử lý P42
  ----------------- ------------------ ----------------- ------------------------
  L1                Lãi quá hạn dùng   Không phản ánh    Dùng lãi suất trong hạn
                    **4,25%/năm cố     lãi suất hợp đồng × **1,5**
                    định**                               

  L2                Phần lãi quá hạn   Tổng có thể ra số Làm tròn từng thành phần
                    không được làm     lẻ, lệch chứng từ theo lõi
                    tròn nhất quán                       

  L3                Hai công thức quá  Hai màn hình có   Chỉ dùng một nguồn tính:
                    hạn song song      thể cho kết quả   `QLTDLai.tinhLaiKhoan`
                    (`tinhLaiQuaHan` × khác nhau         
                    1,5 và bảng 4,25%)                   

  L4                Xét ngày đáo hạn   Khoản giải ngân   Xét theo `r[7]` -- ngày
                    theo `r[24]`       đáo hạn trước     đến hạn khoản giải ngân
                    (`apprmatdt` --    HĐTD bị coi là    
                    HĐTD)              trong hạn         

  L5                Ngày chốt trước    Người dùng không  Hiển thị "Không tính
                    mốc tính thì khoản biết vì sao không được" cùng lý do; không
                    bị bỏ qua im lặng  tính lãi          cộng khoản lỗi vào tổng

  L6                Nhãn "N khoản vay  Số lượng khoản    Chỉ đếm khoản có dư nợ
                    còn dư nợ" đếm cả  còn dư nợ sai     \> 0
                    khoản dư nợ bằng 0                   

  L7                Trường trả gốc cho Có thể tạo số     Chặn giá trị \> dư nợ;
                    nhập vượt dư nợ    liệu thu gốc      cảnh báo; tổng thu = trả
                                       không hợp lệ      gốc + lãi
  -------------------------------------------------------------------------------

## 4. Ca quá hạn đối chiếu bắt buộc

**Đầu vào:** dư nợ 1.000.000.000 đ; lãi suất trong hạn 8,8%/năm; ngày đã
thu lãi đến 22/10/2026; ngày đến hạn khoản giải ngân 29/10/2026; ngày
chốt 03/11/2026.

  Thành phần                        V2   P42 theo quy tắc đã chốt
  --------------- -------------------- --------------------------
  Lãi trong hạn            1.687.671 đ                1.687.671 đ
  Lãi quá hạn             582.191,78 đ    1.205.479 đ + 602.740 đ
  Tổng              **2.269.862,78 đ**            **3.495.890 đ**

**Chênh lệch:** khoảng **1,23 triệu đồng/khoản**.\
Ca này phải được đưa vào test hồi quy và kiểm tra hiển thị chi tiết cách
phân tách thời gian trong hạn/quá hạn.

## 5. Phương án tích hợp

### 5.1 Nguyên tắc kiến trúc

-   Giữ nguyên `qltd_lai.cjs` **từng byte**.
-   Mọi thay đổi UI/luồng tương tác nằm ở lớp `gd14`.
-   Tất cả số liệu lãi trên giao diện lấy từ cùng một hàm lõi
    `QLTDLai.tinhLaiKhoan`.
-   Loại bỏ công thức tính quá hạn song song và mức 4,25% cố định.
-   Không tự tính lại lãi trong component giao diện, không sao chép công
    thức nghiệp vụ sang frontend.
-   Các tổng hiển thị phải được tổng hợp từ kết quả đã làm tròn của từng
    khoản, theo quy tắc lõi.

### 5.2 Modal "Máy tính lãi"

Triển khai modal theo mockup:

1.  Tab **Tra cứu khách hàng**.
2.  Tab **Tính tay**.
3.  Trường **Ngày chốt** và nút **Hôm nay**.
4.  Thẻ **Tổng dư nợ**.
5.  Bảng 10 cột, hỗ trợ cuộn ngang.
6.  Cột đầu tiên ghim (sticky) khi cuộn ngang.
7.  Thanh tổng gồm **4 ô tổng hợp**.
8.  Nút **Copy kết quả**.
9.  Nút **Reset**.

### 5.3 Hiển thị nghiệp vụ

-   Cột lãi quá hạn hiển thị **"LS × 1,5"**, không hiển thị "4,25%/năm".
-   Dòng có quá hạn được tô đỏ; có chú giải `chiTiet` giải thích thành
    phần tính.
-   Khoản lỗi/thiếu dữ liệu hiển thị màu xám: **"Không tính được -- \[lý
    do cụ thể\]"**.
-   Khoản không tính được không được âm thầm cộng vào tổng; phải có
    thông báo rõ.
-   Đếm "khoản còn dư nợ" chỉ bao gồm khoản có dư nợ \> 0.
-   Trường **Số tiền trả gốc** không được vượt dư nợ khoản; có
    validation và cảnh báo.
-   **Tổng thu = Trả gốc + Lãi**.
-   Tiêu đề cột ghi rõ nguồn trường IPCAS theo mockup, gồm `dsbsdt`,
    `lstintchrgprd`, `apprmatdt` và `r[7]` khi tương ứng.

## 6. Kế hoạch kiểm thử

### 6.1 Kiểm thử lõi tính lãi

-   Chạy lại bộ kiểm lõi hiện có: **18/18**.
-   Bổ sung ca mockup 10 khoản trong hạn: kỳ vọng **18.532.601 đ**.
-   Bổ sung ca quá hạn: kỳ vọng **3.495.890 đ**.
-   Bổ sung ca ngày chốt trước mốc dữ liệu: phải hiển thị trạng thái và
    lý do, không bỏ qua im lặng.
-   Kiểm tra làm tròn từng khoản rồi cộng tổng.
-   Kiểm tra khoản dư nợ bằng 0 không được tính vào số khoản còn dư nợ.

### 6.2 Playwright -- kích thước và luồng

  Viewport   Kích thước
  ---------- -------------
  Mobile     390 × 844
  Desktop    1280 × 1800

Các bước tự động:

1.  Mở modal máy tính lãi.
2.  Chọn/tra cứu khách hàng.
3.  Đọc giá trị từng ô từ DOM.
4.  So sánh từng ô với phép tính độc lập bằng Python.
5.  Kiểm tra tick/bỏ tick các khoản.
6.  Nhập trả gốc và xác minh giới hạn không vượt dư nợ.
7.  Đổi ngày chốt, kiểm tra cập nhật số liệu.
8.  Kiểm tra cuộn ngang và cột đầu ghim.
9.  Kiểm tra Copy kết quả và Reset.
10. Chụp ảnh bằng chứng tại từng bước quan trọng.
11. Thu thập console error và lỗi runtime.

### 6.3 Hồi quy P42

-   Bộ hồi quy: **42/42**.
-   Bộ kiểm bổ sung: **86/86**.
-   Dựng lại 2 lần và so sánh **MD5** để xác minh tính tái lập.
-   Xác nhận không thay đổi `qltd_lai.cjs`.
-   Xác nhận các chức năng hiện hữu của P42 không bị ảnh hưởng.

## 7. Tiêu chí nghiệm thu

-   [ ] Số liệu mockup khớp: **18.532.601 đ**.
-   [ ] Ca quá hạn khớp: **3.495.890 đ**.
-   [ ] Tất cả ô số được đối chiếu độc lập, sai lệch **0 đ**.
-   [ ] Không còn lãi quá hạn cố định 4,25%.
-   [ ] Không còn công thức quá hạn song song.
-   [ ] Ngày quá hạn căn cứ từng khoản giải ngân (`r[7]`).
-   [ ] Khoản không đủ dữ liệu có lý do rõ ràng.
-   [ ] Đếm dư nợ chính xác.
-   [ ] Không cho trả gốc vượt dư nợ.
-   [ ] Playwright mobile và desktop đạt.
-   [ ] Không lỗi console.
-   [ ] Bộ hồi quy 42/42 và 86/86 đạt.
-   [ ] Hai lần dựng có MD5 trùng.
-   [ ] Lõi `qltd_lai.cjs` không thay đổi.

## 8. Phạm vi và điều kiện thực thi

Tài liệu này ghi nhận quyết định nghiệp vụ và kế hoạch kỹ thuật đã thống
nhất. Việc sửa mã, chạy Playwright, chụp ảnh, xác minh console, đối
chiếu MD5 và bàn giao cần được thực hiện trực tiếp trong môi trường dự
án P42 có mã nguồn và quyền truy cập phù hợp.

**Không tuyên bố đã triển khai hoặc đã chạy kiểm thử** khi chưa thực thi
trên repository thực tế.
