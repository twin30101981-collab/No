# QLTDPRO P42 — nhật ký bàn giao 03/11/2026

## Yêu cầu
Thực thi phần backlog của P41 khả thi ngay được (theo PROMPT_PHIEN_SAU P41), kế thừa đúng luật
P39/P40/P41: chỉ vá chuỗi chính xác đếm đúng số lần, nghiệp vụ/trình bày mới nằm lớp **gd14**,
không mạng, không đổi CSP, không đổi 4 CSDL (`QLTDProDB`, `TWIN_Archive_v1`, `QLTDProTSBD`,
`QLTDKhachHangMoi`); handle thư mục vẫn ở CSDL riêng `QLTDProFolder_v1`.

## Thiết kế
### 1 · Quét thư mục con tuỳ chọn (Q4 — backlog P41)
- Mặc định giữ nguyên **mức 1**. Thẻ thư mục thêm ô **"Bao gồm thư mục con"** (`gd14-folder-sub`),
  lưu cùng CSDL `QLTDProFolder_v1` (khoá `sub`) — không chạm CSDL cũ.
- Khi bật: quét đệ quy, sâu tối đa 5 mức, **bỏ thư mục ẩn** (tên bắt đầu bằng `.`); tệp ẩn,
  `~$*`, đuôi lạ, tệp vừa sửa <30 giây vẫn được lọc như cũ.
- Khoá "đã đề xuất" đổi thành **đường_dẫn_tương_đối|tên|kích_thước|lastModified**; tệp ở mức 1 có
  đường_dẫn rỗng nên khoá GIỐNG HỆT P41 → không có tệp nào bị đề xuất lại khi nâng cấp.
- Hai tệp trùng tên ở thư mục khác nhau là hai khoá khác nhau — không chặn lẫn nhau.

### 2 · Cột "Nguồn" trong bảng kế hoạch (backlog P39/P40)
- Thêm cột "Nguồn" (sau "Kích thước", trước "Ghi chú") ở cả dòng chờ nhập và dòng đã nhập,
  testid `nguon`; nội dung do `window.GD14.nguon(file)` trả:
  - tệp lấy từ thư mục IPCAS → **"Thư mục IPCAS"** (thêm `› <thư mục con>` nếu nằm sâu);
  - tệp lấy ra từ ZIP → chuỗi zip gốc của khối gd13 (**"ZIP: ten.zip"**); ZIP lấy từ thư mục →
    **"Thư mục IPCAS › ZIP: ten.zip"**;
  - còn lại → **"Chọn tệp / Kéo thả"**.
- gd13 được vá 3 chuỗi **chỉ thêm metadata** (`ctx.topSrc` truyền nhãn thư mục vào các tệp giải
  nén ra): hành vi giải nén, lọc, giới hạn, thông báo giữ nguyên từng byte.

### 3 · Phiên bản
- Nguồn vá = `app/QLTDPRO_v24.13.0.html` (P41) → dựng `QLTDPRO_v24.14.0.html` bằng
  `nguon_P42/build_p42.py`; `sw.js` → cache `qltdpro-p42-v24.14.0`; `manifest.json` trỏ bản mới.

## Kiểm chứng
| Bộ | Kết quả |
|---|---|
| `node kiem_thu_p41/test_lai_unit.test.cjs` (module `qltd_lai.cjs` giữ nguyên từng byte) | 18/18 |
| `kiem_thu_p42/test_gd14_p42.py` (cổng 8825): 26 ca P41 chạy lại trên v24.14.0 + 8 ca cột Nguồn (chọn tay/zip/zip lồng/thư mục/zip trong thư mục/dòng đã nhập) + 11 ca thư mục con (mặc định mức 1, bật quét con, bỏ thư mục ẩn, giữ tuỳ chọn sau tải lại, "Đưa lại tất cả tệp" với cây thư mục, tệp mới trong thư mục con) | 42/42 |
| `kiem_thu_p42/test_p42_regress.py` (cổng 8824): toàn bộ ca hồi quy P40/P41 chạy lại + zip tạo bằng **7-Zip** + **Info-ZIP** + zip **bzip2** (âm: báo rõ "kiểu nén 12 chưa hỗ trợ", không sập) + zip **zip64** (đọc được) | 86/86 |
| Dựng lại bằng `build_p42.py` 2 lần | tái lập từng byte (md5 `679b928dea2762319aa0eb39a4afc449`) |

- Điểm neo vá: nhãn phiên bản (2), tiêu đề cột (1), ô `nguon` (2: chờ nhập + đã nhập), gd13
  `topSrc` (3) — mỗi chuỗi đếm đúng 1 lần; khối gd14 thay toàn khối theo marker
  `<script id="gd14-js">` (đếm đúng 1).

## Hạn chế đã biết / còn mở
- **test_p39 (125/125)** vẫn chưa chạy được — file bộ kiểm không có trong bàn giao; cần chủ dự án cung cấp.
- **Q7** (đối soát lãi với `intamt`): chờ chủ dự án xác nhận ngữ nghĩa cột.
- **Q5 / GĐ4**: thử quyền thư mục tắt–mở trình duyệt trên máy chi nhánh (file:// với https) và
  đối chiếu ≥ 20 khoản thật — cần máy và dữ liệu thật.
- **RAR thật** (đọc được .rar): cần duyệt thêm `'wasm-unsafe-eval'` trong CSP — chưa xin.
- **ZIP từ WinRAR / Windows Explorer**: cần máy Windows tạo mẫu; 7-Zip + Info-ZIP đã kiểm.
- Quét đệ quy dừng ở sâu 5 mức; tệp đang chép dở (~30 giây) bỏ qua tới lần quét sau.
- Đổi tuỳ chọn thư mục con KHÔNG tự quét lại — bấm "Quét ngay" (trạng thái có nhắc).

## Hoàn tác
Chép `app/QLTDPRO_v24.13.0.html` + `sw.js`/`manifest.json` của P41 đè lên (bản P41 trong ZIP
bàn giao P41-WIP1; `baseline/QLTDPRO_v24.13.0.html` kèm theo gói này).
