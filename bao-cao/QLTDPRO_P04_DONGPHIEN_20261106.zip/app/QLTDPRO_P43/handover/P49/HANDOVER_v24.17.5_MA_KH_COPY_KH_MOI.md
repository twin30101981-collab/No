# QLTDPRO P49 · v24.17.5 — Trang Khách hàng mới: mã KH copy được (04/11/2026)

Thực thi **mục 1** ("Cột mã khách hàng cho trang khách hàng mới có thể copy như các trang khác").
Nguồn vá = `app/QLTDPRO_v24.17.4.html` → `app/QLTDPRO_v24.17.5.html` bằng `nguon_P49/build_p49.py` (vá 1 vị trí, đếm đúng số lần; không đổi CSDL/CSP/lõi lãi).

## Nguyên nhân
Các trang bảng dữ liệu (Nợ đến hạn, Lãi đọng, Giải ngân…) có cột "Mã KH" dùng ô `cC` (chạm để copy). Trang Khách hàng mới, tab **Chi tiết**, là bảng viết riêng: mã KH (brcd) chỉ in chữ nhỏ dưới tên khách nên không bấm copy được.

## Sửa
Mã KH dưới tên khách trong bảng Chi tiết (cả 4 chế độ: Giải ngân · KH vay mới · Cầm cố · Tất toán trong kỳ) dùng đúng ô `cC` của các trang khác: chữ xanh gạch chấm, bấm → chép mã vào bộ nhớ tạm + thông báo "📋 Đã copy Mã KH: …", không kích hoạt thao tác khác của dòng. Nhãn "mới / cầm cố / đã tất toán" vẫn nằm cạnh mã. Không thêm cột mới (giữ bố cục bảng); nếu muốn tách thành cột "Mã KH" riêng, báo để làm.

## Kiểm chứng
`python3 kiem_thu_p49/test_ma_kh_copy.py` → **14/14** (mobile 390×844 + desktop 1280×1100): mỗi dòng có ô copy, role/title đúng, bấm → clipboard = đúng mã (không lẫn "mới"), có thông báo, số dòng không đổi, nhãn "mới" còn, 0 lỗi console. Tệp mẫu `kiem_thu_p49/xlsx/` (dd/mm/yyyy). Bộ kiểm P48 (địa chỉ) chạy lại trên v24.17.5: 22/22.

## Còn mở
- Mục 3 (thiết kế lại giao diện Máy tính lãi) chưa làm.
- Chưa thử trên dữ liệu IPCAS thật của chi nhánh.
Hoàn tác: dùng lại `app/QLTDPRO_v24.17.4.html` + `sw.js`/`manifest.json` (đổi 24.17.5 → 24.17.4).
