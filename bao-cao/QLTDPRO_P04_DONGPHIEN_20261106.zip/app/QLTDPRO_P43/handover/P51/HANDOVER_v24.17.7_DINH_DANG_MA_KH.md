# QLTDPRO P51 · v24.17.7 — Mã KH dạng 3201-xxxxxxxxx ở trang Khách hàng mới (04/11/2026)

Nguồn vá = `app/QLTDPRO_v24.17.6.html` → `app/QLTDPRO_v24.17.7.html` bằng `nguon_P49/build_p51.py` (vá 1 vị trí).
Cột "Mã KH" (bảng Chi tiết) hiển thị và **copy** theo cùng quy tắc `on()/maFmt` của các trang khác: đúng 13 chữ số → 4 số đầu + "-" + 9 số cuối (vd 3201456207541 → 3201-456207541); mã khác độ dài giữ nguyên.
Kiểm: `python3 kiem_thu_p49/test_ma_kh_copy.py` → 20/20 (mobile + desktop), gồm ca B3b kiểm định dạng cả ô hiển thị lẫn nội dung clipboard.
Hoàn tác: dùng lại `app/QLTDPRO_v24.17.6.html` + sw/manifest (đổi 24.17.7 → 24.17.6). Mục 3 (giao diện Máy tính lãi) vẫn chưa làm.
