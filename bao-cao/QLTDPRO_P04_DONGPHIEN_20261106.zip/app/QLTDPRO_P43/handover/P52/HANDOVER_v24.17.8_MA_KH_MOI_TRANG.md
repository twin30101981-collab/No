# QLTDPRO P52 · v24.17.8 — Rà soát toàn bộ: mã KH luôn hiển thị 3201-xxxxxxxxx (04/11/2026)

Nguồn vá = `app/QLTDPRO_v24.17.7.html` → `app/QLTDPRO_v24.17.8.html` bằng `nguon_P49/build_p52.py` (20 neo, mỗi neo đếm đúng số lần; không đổi CSDL/CSP/lõi lãi).

## Gốc rễ
Quy tắc "13 số → 4-9" tồn tại thành **4 bản sao** (`maFmt` ở gd7, `on` và `za` ở bộ chính, khối nội tuyến ở trang KH mới) và nhiều chỗ in mã thô nên mỗi lần sửa một nơi lại lệch nơi khác.
Nay chỉ còn **một hàm**: `window.QLTD_maKH` (khối `<script id="makh-js">` nạp trước mọi khối; khoá cứng bằng defineProperty). `maFmt`, `on`, `za`, trang KH mới, Máy tính lãi, Hồ sơ vay đều gọi hàm này. Muốn đổi quy tắc chỉ sửa 1 chỗ.

## Các chỗ trước đây hiện mã thô (đã sửa)
1. **Ô "Mã KH" có huy hiệu 📄 HSVV** (hàm `Jb`, dùng ở mọi bảng DataTable: Tất cả dư nợ, Ngắn hạn/Trung dài hạn, Nợ đến hạn, Lãi đọng, Chuyển hạn mức…): in mã thô và **mất nút copy** → nay dạng 3201-xxxxxxxxx + chạm-để-copy như ô thường.
2. **Máy tính lãi**: danh sách tìm KH, thẻ KH đã chọn ("Mã đơn vị (brcd)"), danh sách công cụ, nội dung **Copy kết quả** (dòng "Khách hàng: tên (mã)"). Tìm kiếm khớp cả mã thô lẫn dạng có gạch.
3. **TSBĐ — Lịch sử**: bảng "Đã rút/giải chấp" và "Đổi trạng thái" in mã thô.
4. **Danh sách nhóm nợ chuyển** (component `im`): in mã thô.
5. **Hồ sơ vay vốn**: dòng tóm tắt "Mã KH".

## Chủ ý KHÔNG đổi
- Ô nhập tay (form thêm KH, ô Mã khách hàng của hồ sơ HSVV): người dùng gõ gì giữ nguyên.
- Mã lưu trong dữ liệu/IndexedDB và khoá so khớp: vẫn là chuỗi thô (chỉ đổi lúc hiển thị/copy).
- Mã không đúng 13 chữ số (vd 14 số) giữ nguyên, không cắt.
- Excel báo cáo dựng riêng (báo cáo KH mới, xuất TSBĐ): vẫn mã thô để đối chiếu IPCAS; Excel xuất từ bảng DataTable vốn đã dạng gạch.

## Kiểm chứng
`python3 kiem_thu_p52/test_ma_kh_moi_trang.py` → **14/14** (bản 24.17.7 trượt R2, R4, R5, M1–M4). Quét 23 trang + tab với dữ liệu 3.800 dòng, KH đã liên kết hồ sơ: 0 mã 13 số liền.
Hồi quy: `kiem_thu_p49/test_ma_kh_copy.py` 20/20 · `kiem_thu_p48/test_dia_chi_mtl.py` 22/22 (chạy trên 24.17.8).
Chưa chạy trên dữ liệu IPCAS thật; TSBĐ-Lịch sử và nhóm nợ chuyển được kiểm bằng neo + hàm chung, chưa dựng kịch bản UI.
Hoàn tác: dùng lại `app/QLTDPRO_v24.17.7.html` + sw/manifest (đổi 24.17.8 → 24.17.7).
