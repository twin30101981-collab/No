# QLTDPRO P48 · v24.17.4 — Máy tính lãi: địa chỉ khi tra cứu khách hàng (04/11/2026)

Thực thi **mục 2** trong đề xuất bổ sung ("Thêm địa chỉ khi tìm khách hàng để tìm cho nhanh và chính xác").
Nguồn vá = `app/QLTDPRO_v24.17.3.html` → `app/QLTDPRO_v24.17.4.html` bằng `nguon_P48/build_p48.py`
(vá chuỗi chính xác, đếm đúng số lần; **không đổi lõi tính lãi, CSDL, CSP**; chỉ sửa khối Máy tính lãi GD14).

## Dữ liệu
Địa chỉ = `r[14]` của bản ghi 27 cột (= `addr1` + `, ` + `commmn` — bộ nhập msit80 đã ghép sẵn). Mỗi KH (tên + brcd) lấy địa chỉ đầu tiên không rỗng.

## Thay đổi
1. **Danh sách kết quả tìm**: mỗi dòng 2 tầng — *Tên · mã* (đậm) + `📍 địa chỉ` (xám, tự xuống dòng trên điện thoại); KH không có địa chỉ ghi "(chưa có địa chỉ)". Vùng danh sách cao 280px (trước 200px). Quá 50 KH → báo "Còn N khách hàng nữa — gõ thêm…".
2. **Tìm theo địa chỉ**: chuỗi tìm = tên + mã + số HĐTD + địa chỉ, không phân biệt dấu. Tách theo từ: **mọi từ phải có mặt** (vd `chinh cua bac` → đúng 1 người trong 3 người trùng tên "Nguyễn Thị Chinh").
3. **Thứ tự xếp**: khớp tên liền cụm → khớp tên/mã/HĐTD → khớp có dùng địa chỉ (để "Phường" không lấn "Hương" khi gõ `huong`).
4. **Thẻ KH đã chọn** (khung xanh navy) có dòng `📍 địa chỉ`; **Copy kết quả** có dòng `Địa chỉ: …`.
5. Nhãn/gợi ý ô tìm: "Tìm khách hàng (tên, mã, số HĐTD, địa chỉ)".

## Kiểm chứng
- `python3 kiem_thu_p48/test_dia_chi_mtl.py` → **22/22** (mobile 390×844 + desktop 1280×1100): hiện địa chỉ, 3 KH trùng tên phân biệt bằng địa chỉ, tìm tên+địa chỉ không dấu, chỉ địa chỉ, cụm liền "lan huong" như cũ, tìm HĐTD như cũ, thẻ KH, copy, 0 lỗi console. Ảnh bằng chứng: `kiem_thu_p48/*.png`.
- Hồi quy Máy tính lãi P43 (bản chạy trên v24.17.4): **80/80**, 0 đ sai lệch (mockup 18.532.601 đ, ca quá hạn 3.495.890 đ). Lõi `node kiem_thu_p42_mtl/test_lai_mtl.test.cjs` **11/11**.
- `build_p48.py` tái lập được từ v24.17.3 (khôi phục sw.js/manifest.json bản 24.17.3 trước khi chạy lại).

## Còn mở (chưa làm — đúng phạm vi "mục 2")
- Mục 1: cột mã KH trên trang *Khách hàng mới* cho phép copy như các trang khác.
- Mục 3: thiết kế lại giao diện Máy tính lãi (dễ theo dõi hơn).
- Chưa kiểm trên dữ liệu IPCAS thật: nếu cột `addr1` thật quá dài/ trống nhiều, báo để chỉnh (vd chỉ hiện xã/huyện).
- Mở một KH cũ trong tệp đã nhập từ trước P42 mà bản ghi không có r[14] → hiện "(chưa có địa chỉ)"; nhập lại tệp msit80 để có địa chỉ.

Hoàn tác: dùng lại `app/QLTDPRO_v24.17.3.html` + `sw.js`/`manifest.json` tương ứng (đổi 24.17.4 → 24.17.3).
