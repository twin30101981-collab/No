# QLTDPRO P46 · v24.17.2 — Kho lịch sử TSBĐ (04/11/2026)

Nguồn vá = `app/QLTDPRO_v24.17.1.html` → `app/QLTDPRO_v24.17.2.html` bằng `nguon_P46/build_p46.py` (vá chuỗi chính xác, đếm đúng số lần; không đổi CSP).

## Kho lịch sử
- Mỗi lần lưu sao kê TSBĐ hiện hành (hàm `gb`), app ghi thêm 1 bản vào kho `kv` sẵn có của CSDL `QLTDProTSBD`, khóa `hist_YYYY-MM-DD` (ngày nạp; nạp lại trong ngày thì ghi đè). **Không đổi phiên bản hay cấu trúc CSDL** (vẫn 4 CSDL).
- Chỉ giữ dòng **chứng chỉ tiền gửi** (loại TSBĐ dùng xác định cầm cố) với 12 trường gọn; tối đa 90 ngày gần nhất. Lỗi khi ghi lịch sử không làm hỏng việc nạp TSBĐ.
- **Lịch sử bắt đầu tích lũy từ lần nạp TSBĐ đầu tiên sau khi dùng bản này**; không khôi phục được các ngày trước đó.

## Dùng khi lập báo cáo
- "Nạp vào các ô nguồn" đọc thêm các bản lịch sử có ngày từ ngày đầu kỳ; thông báo "Tra cầm cố thêm N bản lịch sử TSBĐ".
- Chỉ áp cho **món đã tất toán trong kỳ** (khi tick chuyển KH vay mới): có CCTG ở TSBĐ hiện hành/đầu kỳ **hoặc** ở lịch sử ⇒ tính cầm cố; không có ở đâu ⇒ nhãn "cầm cố?". Món thường giữ nguyên cách tra cũ.

## Còn mở
Chưa kiểm trên trình duyệt; thử: nạp TSBĐ ở Tài sản, kiểm khóa `hist_*` trong IndexedDB `QLTDProTSBD` → kv, rồi lập báo cáo kỳ có món tất toán. Excel chưa có cột "đã tất toán".
Hoàn tác: dùng lại `app/QLTDPRO_v24.17.1.html` (các khóa `hist_*` để lại vô hại).
