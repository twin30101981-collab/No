# QLTDPRO P47 · v24.17.3 — Sửa chữ mờ/không thấy (chế độ Tương phản cao) (04/11/2026)

Nguồn vá = `app/QLTDPRO_v24.17.2.html` → `app/QLTDPRO_v24.17.3.html` bằng `nguon_P47/build_p47.py` (vá chuỗi chính xác, đếm đúng số lần; không đổi CSP, không đổi CSDL).

## Nguyên nhân (đọc từ mã, theo ảnh chụp)
1. `hcGuard()` (bảo hiểm tương phản cao) coi nền là "thanh tối" khi độ sáng RGB < 80 nhưng **bỏ qua độ trong suốt**. Nền trong suốt nhẹ như `bg-info/10` (chip "2243 tài sản bảo đảm · 95 KH chưa có TSBĐ") thực chất là nền sáng, nhưng bị gắn **chữ trắng** ⇒ chữ trắng trên nền sáng ⇒ mờ. Chữ trắng gắn bằng style nội tuyến nên còn dính cả khi tắt Tương phản cao.
2. Chế độ Tương phản cao đặt `.text-muted-foreground{color:#1E2A3A !important}` (độ ưu tiên cao hơn luật tiêu đề bảng) ⇒ ô tiêu đề bảng (class đó) thành chữ xám đậm trên nền navy ⇒ không thấy chữ.

## Sửa
- `lum()` tính theo độ trong suốt (trộn với nền trắng).
- `hcGuard()` đánh dấu `data-gd11-hcw` phần tử đã gắn chữ trắng; **gỡ** khi nền không còn tối hoặc khi tắt Tương phản cao.
- CSS: trong Tương phản cao, tiêu đề bảng (`main table thead th`, `table.gd7-t`, `dt-th`) và phần tử con luôn dùng chữ sáng `--gd7-head-fg`.

## Còn mở
Chưa kiểm trên trình duyệt: mở Tổng quan, bật rồi tắt "Tương phản cao", xem chip TSBĐ, tiêu đề và số trong bảng "Theo nhóm nợ". Ảnh chụp chỉ thấy một phần màn hình; nếu còn chỗ mờ ở trang khác, chụp thêm để vá tiếp.
Hoàn tác: dùng lại `app/QLTDPRO_v24.17.2.html` + sw/manifest tương ứng.
