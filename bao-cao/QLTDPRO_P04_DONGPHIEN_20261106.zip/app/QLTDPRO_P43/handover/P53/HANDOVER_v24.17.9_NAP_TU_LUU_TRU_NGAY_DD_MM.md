# QLTDPRO P53 · v24.17.9 — Sửa gốc rễ: "Nạp từ Lưu trữ" làm thiếu doanh số giải ngân (ngày dd/mm bị đảo)

Nguồn vá = `app/QLTDPRO_v24.17.8.html` → dựng `app/QLTDPRO_v24.17.9.html` bằng `nguon_P53/build_p53.py` (vá chuỗi chính xác, đếm đúng số lần; không đổi CSP, không đổi 4 CSDL).

## Triệu chứng
Trang Khách hàng mới → "Nạp từ Lưu trữ" → Lập báo cáo: các món giải ngân có **ngày ≤ 12** (vd 05/10, 03/11 của Hội Sở) **không vào cột Giải ngân** dù đã có trong dư nợ cuối kỳ; "Thu nợ" ra số âm vô lý. Món có ngày > 12 vẫn đúng.

## Gốc rễ (đã tái hiện trên app thật)
1. "Nạp từ Lưu trữ" ghi dư nợ ra **CSV trung gian** (đuôi `.xls`) rồi đưa qua đường chọn tệp của trang.
2. Trang đọc tệp bằng thao tác worker `head` (`Zh` → `r.head`) gọi `XLSX.read(...)` **không có `raw:true`**. SheetJS khi đọc CSV kiểu này **tự đoán kiểu ô theo lịch Mỹ**: `05/10/2026` → 10/05, `03/11/2026` → 11/03 (cả `dsbsmatdt`, `plgdt`). Ngày có thành phần > 12 không đoán được nên vẫn là chuỗi ⇒ đúng. Vì vậy chỉ ngày ≤ 12 bị đảo → rơi khỏi kỳ báo cáo.
3. Hệ quả phụ cùng gốc: mã dạng số (vd `dsbsseq` = `001`) bị ép thành số (mất số 0 đầu) ⇒ khóa `brcd|apprseq|dsbsseq` lệch với bản quét giữa kỳ ⇒ sinh dòng "đã tất toán" ảo, tổng Giải ngân bị nhân.
4. Đường **Nhập dữ liệu** dùng `ipcasRows` (có `raw:true`) nên không bị — chỉ trang Khách hàng mới (hàm `em`) lệch.

## Cách sửa (3 điểm vá, tối thiểu)
- `r.head`: thêm `raw:!!s.txt` vào `XLSX.read` (cờ `txt` mới; mặc định tắt ⇒ mọi nơi khác không đổi).
- `Zh`: thêm tham số thứ 5 `x` → chuyển thành `txt`.
- `em` (trang Khách hàng mới): gọi `Zh(t,2e6,!0,null,!0)` ⇒ đọc văn bản thô, giữ nguyên chuỗi ngày/mã.
Tệp `.xlsx` / `.xls` nhị phân: `raw` không tác động ⇒ kết quả không đổi (đã đối chứng).

## Kiểm chứng
- `python3 kiem_thu_p53/test_khm_luu_tru.py` (Chromium, dữ liệu Lưu trữ giả lập: GN 05/10, 12/10, 15/10, 03/11, đáo hạn 03/05/2027, có TSBĐ cầm cố):
  - v24.17.8: **FAIL** — Doanh số 100 tr / 1 món (đúng phải 1,1 tỷ / 4 món); với `dsbsseq` dạng `001`: 5 món (1,2 tỷ) có dòng "đã tất toán" ảo.
  - v24.17.9: **10/10 PASS** cả `SEQ=num` và `SEQ=pad`; Thu nợ = 0 đ khớp chênh lệch dư nợ.
- Đối chứng nạp tay `.xlsx` và `.xls` (BIFF8) với cùng dữ liệu: v24.17.8 và v24.17.9 cho kết quả **giống hệt** (3 món / 900 tr).
- Chưa chạy lại các bộ kiểm P40–P52 cũ (chúng trỏ tới các bản html cũ); phạm vi vá chỉ nằm ở đường đọc của trang Khách hàng mới.

## Lưu ý
- Tệp CSV/HTML tự nhập tay vào trang Khách hàng mới giờ giữ nguyên chuỗi (số có dấu phẩy ngăn nghìn vẫn được `num()` xử lý). Nếu gặp tệp nguồn dạng chữ có số thập phân kiểu dấu phẩy, cần rà lại.
- Báo cáo đã lập bằng bản cũ cần **lập lại** (nạp lại từ Lưu trữ → Lập báo cáo) mới ra số đúng.

## Dùng / hoàn tác
Chép `app/QLTDPRO_v24.17.9.html` + `sw.js` + `manifest.json` đè bản cũ, làm mới trang (service worker đổi phiên bản `qltdpro-p53-v24.17.9`). Hoàn tác: dùng lại `app/QLTDPRO_v24.17.8.html` + chỉnh sw/manifest về 24.17.8.
