# P03 · HM-11b — V3 (Playwright Chromium): Nhập dữ liệu 3 mốc msit80 THỬ → Khách hàng mới → Nạp từ Lưu trữ → Đối soát:
# bảng Phòng → Cán bộ (gd15 + QLTD_DSTN) phải = công cụ doi_chieu_mis80 (Python độc lập) trên cùng mốc, 0 đồng.
# Dùng (từ app/QLTDPRO_P43/; cần pandas, openpyxl, xlrd, node):
#   python3 kiem_thu_p03/test_hm11b_dstn.py [app/QLTDPRO_v24.17.12.html]
# Chạy trên tệp THẬT (chỉ ở thư mục tạm, KHÔNG lưu log/ảnh vào repo/ZIP):
#   MIS_DIR=<thư mục dd.mm.yyyy.xls(x)> TS_FILE=<sao kê TSBĐ> EVD=<thư mục tạm> python3 kiem_thu_p03/test_hm11b_dstn.py <app>
import asyncio, functools, http.server, threading, sys, json, re, subprocess, tempfile, shutil, os
from pathlib import Path
from playwright.async_api import async_playwright
ROOT = Path(__file__).resolve().parent.parent
APP = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / 'app' / 'QLTDPRO_v24.17.12.html'
EVD = Path(os.environ.get('EVD', tempfile.mkdtemp(prefix='hm11b_ev_')))
EVD.mkdir(parents=True, exist_ok=True)
PORT = 8862
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
httpd = http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(APP.parent)))
threading.Thread(target=httpd.serve_forever, daemon=True).start()
URL = f'http://127.0.0.1:{PORT}/{APP.name}'
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:600]))

# ---- dữ liệu thử + kết quả công cụ đối chiếu (Python độc lập + lõi Node) ----
TMP = Path(tempfile.mkdtemp(prefix='hm11b_'))
DL = TMP / 'mis'; PY = sys.executable
MIS_DIR = os.environ.get('MIS_DIR')
if MIS_DIR:
    DL.mkdir(parents=True)
    for f in Path(MIS_DIR).iterdir():
        if f.is_file() and re.match(r'\d\d\.\d\d\.\d{4}\.(xlsx|XLS)$', f.name): shutil.copy(f, DL / f.name)
else:
    subprocess.run([PY, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(DL)], check=True)
subprocess.run([PY, '-I', str(ROOT / 'kiem_thu_p02/doc_mis80.py'), str(DL), str(TMP / 'm.pkl')], check=True, stdout=subprocess.DEVNULL)
dc = subprocess.run([PY, '-I', str(ROOT / 'kiem_thu_p02/doi_chieu_mis80.py'), str(TMP / 'm.pkl'), str(ROOT / 'nguon_P02/qltd_dstn.cjs'), str(TMP / 'dc')], check=True, capture_output=True, text=True).stdout
ok('C0 công cụ doi_chieu: Python độc lập = lõi (kỳ cuối, chuỗi mốc, 2 mốc)', len(re.findall(r'lệch 0 \| Cán bộ lệch 0/\d+ · Phòng lệch 0/\d+', dc)) == 3, re.findall(r'Khế ước:.*', dc))
import pandas as pd
def mong_doi(ten):
    x = pd.read_excel(next((TMP / 'dc').glob(ten)), sheet_name=None)
    P = {r['Phòng']: r for _, r in x['Phòng'].iterrows()}
    C = {(r['Phòng'], r['Cán bộ']): r for _, r in x['Cán bộ'].iterrows()}
    return P, C
MAP = [('dauKy', 'Dư nợ đầu kỳ'), ('gn', 'Doanh số GN'), ('gnMon', 'Số món GN'), ('thu', 'Thu nợ gốc'), ('dieuChinh', 'Điều chỉnh'), ('cuoiKy', 'Dư nợ cuối kỳ'), ('kiemTra', 'Kiểm tra (=0)')]
MAPC = MAP + [('soKhe', 'Số khế ước'), ('soTatToan', 'Số tất toán')]

async def trang(p, vp, mobile=False):
    b = await p.chromium.launch()
    c = await b.new_context(viewport=vp, locale='vi-VN', is_mobile=mobile, has_touch=mobile)
    await c.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await c.new_page(); pg.errs = []
    pg.on('pageerror', lambda e: pg.errs.append('pageerror: ' + str(e)))
    pg.on('console', lambda m: m.type == 'error' and pg.errs.append('console.error: ' + m.text))
    pg.on('requestfailed', lambda r: pg.errs.append('requestfailed: ' + r.url))
    return b, pg
async def nhap(pg, files):
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in files]); await pg.wait_for_timeout(3000)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(3000 + 1500 * len(files))
async def doi_soat(pg, dau, cuoi):
    await pg.goto(URL + '#/khach-hang-moi', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    for sel, d in (('khm-arch-dau', dau), ('khm-arch-cuoi', cuoi)):
        s = pg.locator(f'[data-testid="{sel}"]'); lab = [t for t in await s.locator('option').all_inner_texts() if d in t][0]
        await s.select_option(label=lab)
    await pg.locator('[data-testid="khm-arch-load"]').click(); await pg.wait_for_timeout(2500)
    await pg.locator('[data-testid="khm-go"]').click()
    try: await pg.wait_for_selector('[data-testid="khm-tab-doisoat-btn"]', timeout=30000)
    except Exception:
        e = pg.locator('[data-testid="khm-error"]'); print('KHM-ERROR:', await e.inner_text() if await e.count() else '', await pg.locator('[data-testid="khm-arch-msg"]').inner_text()); raise
    await pg.locator('[data-testid="khm-tab-doisoat-btn"]').first.click()
    await pg.wait_for_selector('[data-testid="khm-dstn-t"]', timeout=30000); await pg.wait_for_timeout(500)
async def doc_bang(pg):
    return await pg.evaluate("""()=>{const g=tr=>{const o={};tr.querySelectorAll('td[data-k]').forEach(td=>o[td.dataset.k]=+td.dataset.v);return o};
      return {phong:[...document.querySelectorAll('[data-testid="khm-dstn-phong"]')].map(tr=>Object.assign({phong:tr.dataset.phong},g(tr))),
              cb:[...document.querySelectorAll('[data-testid="khm-dstn-cb"]')].map(tr=>Object.assign({phong:tr.dataset.phong,cb:tr.dataset.cb},g(tr))),
              tong:g(document.querySelector('[data-testid="khm-dstn-tong"]')),
              moc:(document.querySelector('[data-testid="khm-dstn-moc"]')||{}).textContent||'',
              cb_text:(document.querySelector('[data-testid="khm-dstn-canhbao"]')||{}).textContent||'',
              old_hidden:(document.querySelector('[data-testid="khm-t-doisoat"]')||{closest:()=>null}).closest('.overflow-auto')?.hidden}}""")
def so(ten, B, P, C):
    lech = []
    t = P['TOÀN CHI NHÁNH']
    for k, h in MAP:
        if round(B['tong'].get(k, 0)) != round(t[h]): lech.append(('tổng', k, B['tong'].get(k), t[h]))
    for r in B['phong']:
        e = P.get(r['phong'])
        if e is None: lech.append(('thiếu phòng', r['phong'])); continue
        for k, h in MAP:
            if round(r[k]) != round(e[h]): lech.append((r['phong'], k, r[k], e[h]))
    for r in B['cb']:
        e = C.get((r['phong'], r['cb']))
        if e is None: lech.append(('thiếu cb', r['phong'], r['cb'])); continue
        for k, h in MAPC:
            if round(r[k]) != round(e[h]): lech.append((r['phong'], r['cb'], k, r[k], e[h]))
    ok(f'{ten}: số phòng = công cụ ({len(P)-1})', len(B['phong']) == len(P) - 1, (len(B['phong']), list(P)))
    ok(f'{ten}: số cán bộ = công cụ ({len(C)})', len(B['cb']) == len(C), (len(B['cb']), len(C)))
    ok(f'{ten}: mọi số tổng/phòng/cán bộ khớp công cụ 0 đồng', not lech, lech[:8])
    ok(f'{ten}: Kiểm tra = 0 mọi dòng', all(r['kiemTra'] == 0 for r in B['phong'] + B['cb']) and B['tong']['kiemTra'] == 0)

TS = Path(os.environ.get('TS_FILE') or ROOT / 'app/kiem_thu_p40/xlsx/18_08_2026-TS.xlsx')
VN = lambda f: f.name[:10].replace('.', '/')
ISO = lambda f: f.name[6:10] + '-' + f.name[3:5] + '-' + f.name[:2]
async def main():
    F = sorted([f for f in DL.iterdir() if re.match(r'\d\d\.\d\d\.\d{4}\.(xlsx|XLS)$', f.name)], key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
    async with async_playwright() as p:
        # ---- A: 3 mốc (30/09, 15/10, 31/10), desktop ----
        b, pg = await trang(p, {'width': 1366, 'height': 900})
        await nhap(pg, F + [TS])
        n = len(await pg.evaluate("window.__gd11Api.arcList()"))  # tệp TSBĐ không tạo mốc dư nợ
        ok(f'A1 Nhập dữ liệu tạo {len(F)} mốc Lưu trữ', n == len(F), n)
        await doi_soat(pg, VN(F[0]), VN(F[-1]))
        if os.environ.get('DUMP'):  # gỡ lỗi: giữ khế ước app + đầu ra công cụ
            Path(os.environ['DUMP']).mkdir(parents=True, exist_ok=True)
            json.dump(await pg.evaluate("window.__khmDstn.khe"), open(Path(os.environ['DUMP']) / 'app_khe.json', 'w'), ensure_ascii=False)
            shutil.copytree(TMP / 'dc', Path(os.environ['DUMP']) / 'dc', dirs_exist_ok=True)
        B = await doc_bang(pg); P, C = mong_doi(f'DOI_SOAT_DSTN_CHUOI_{len(F)}MOC_*.xlsx')
        ok(f'A2 nối đủ {len(F)} mốc (cả mốc giữa kỳ)', f'{len(F)} mốc' in B['moc'] and all(VN(f) in B['moc'] for f in F), B['moc'])
        so(f'A3 chuỗi {len(F)} mốc', B, P, C)
        ok('A4 không cảnh báo thiếu mốc', 'Chỉ có 2 mốc' not in B['cb_text'] and 'thiếu mốc' not in B['cb_text'], B['cb_text'])
        ok('A5 bảng cũ "Thu nợ suy ra" bị thay (ẩn)', B['old_hidden'] is True, B['old_hidden'])
        await pg.locator('[data-testid="khm-dstn-old"]').click(); await pg.wait_for_timeout(300)
        vis = await pg.locator('[data-testid="khm-t-doisoat"]').is_visible()
        ok('A6 nút "Xem bảng cũ" hiện lại bảng cũ', vis)
        p1 = pg.locator('[data-testid="khm-dstn-phong"]').first; ph = await p1.get_attribute('data-phong')
        await p1.locator('button').click(); await pg.wait_for_timeout(200)
        hid = await pg.evaluate(f"[...document.querySelectorAll('[data-testid=\"khm-dstn-cb\"][data-phong=\"{ph}\"]')].every(t=>t.hidden)")
        ok('A7 thu gọn cán bộ theo phòng', hid)
        await p1.locator('button').click()
        tk = await pg.evaluate("window.__khmDstn&&window.__khmDstn.khe.length")
        ok('A8 window.__khmDstn có chi tiết khế ước cho HM-12', tk and tk > 3000, tk)
        await pg.screenshot(path=str(EVD / 'hm11b_desktop_3moc.png'), full_page=False)
        await pg.locator('[data-testid="khm-dstn"]').screenshot(path=str(EVD / 'hm11b_bang_desktop.png'))
        # React: số cũ trang KH mới vẫn còn
        await pg.locator('[data-testid="khm-tab-tongquan-btn"]').first.click(); await pg.wait_for_timeout(500)
        kpi = await pg.locator('[data-testid="khm-kpi"]').count()
        ok('A9 KPI trang Khách hàng mới vẫn hiển thị', kpi > 0, kpi)
        ok('A10 không pageerror/console.error/request lỗi', not pg.errs, pg.errs)
        await b.close()
        # ---- B: 2 mốc (30/09, 31/10), điện thoại 390x844 ----
        b, pg = await trang(p, {'width': 390, 'height': 844}, mobile=True)
        await nhap(pg, [F[0], F[-1], TS])
        await doi_soat(pg, VN(F[0]), VN(F[-1]))
        B = await doc_bang(pg)
        # công cụ chỉ ghi Excel cho chuỗi + kỳ cuối; bản 2 mốc đầu–cuối lấy từ JSON đầu ra của cùng công cụ (đã khớp Python ở C0)
        R2 = json.load(open(TMP / 'dc' / 'dau_cuoi_2moc_ra.json', encoding='utf-8'))
        P = {'TOÀN CHI NHÁNH': {h: R2['tong'][k] for k, h in MAP}}
        for r in R2['phong']: P[r['phong']] = {h: r[k] for k, h in MAP}
        C = {(r['phong'], r['cbTen']): {h: r[k] for k, h in MAPC} for r in R2['canBo']}
        so('B1 chỉ 2 mốc (điện thoại)', B, P, C)
        ok('B2 cảnh báo thiếu mốc giữa kỳ', 'Chỉ có 2 mốc' in B['cb_text'], B['cb_text'])
        ov = await pg.evaluate("document.documentElement.scrollWidth-window.innerWidth")
        ok('B3 điện thoại: trang không tràn ngang', ov <= 1, ov)
        sc = await pg.evaluate("(()=>{const w=document.querySelector('.gd15-wrap');return [w.scrollWidth>w.clientWidth,getComputedStyle(w).overflowX]})()")
        ok('B4 điện thoại: bảng cuộn ngang trong khung riêng', sc[0] and sc[1] == 'auto', sc)
        await pg.locator('[data-testid="khm-dstn"]').screenshot(path=str(EVD / 'hm11b_bang_dien_thoai.png'))
        ok('B5 không pageerror/console.error/request lỗi', not pg.errs, pg.errs)
        await b.close()
        # ---- D: chọn tay tệp (không qua Lưu trữ) → thông báo, giữ bảng cũ ----
        b, pg = await trang(p, {'width': 1366, 'height': 900})
        await pg.goto(URL + '#/khach-hang-moi', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
        await pg.set_input_files('input[data-testid="khm-multi"]', [str(F[0]), str(F[-1]), str(TS)]); await pg.wait_for_timeout(2500)
        await pg.locator('input[data-testid="khm-from"]').fill(ISO(F[0])); await pg.locator('input[data-testid="khm-to"]').fill(ISO(F[-1]))
        await pg.locator('[data-testid="khm-go"]').click(); await pg.wait_for_timeout(3000)
        await pg.locator('[data-testid="khm-tab-doisoat-btn"]').first.click(); await pg.wait_for_timeout(1500)
        msg = await pg.locator('[data-testid="khm-dstn-msg"]').inner_text() if await pg.locator('[data-testid="khm-dstn-msg"]').count() else ''
        ok('D1 tệp chọn tay: báo cần mốc Lưu trữ', 'Lưu trữ' in msg, msg)
        ok('D2 tệp chọn tay: bảng cũ vẫn hiện', await pg.locator('[data-testid="khm-t-doisoat"]').is_visible())
        ok('D3 không pageerror/console.error/request lỗi', not pg.errs, pg.errs)
        await b.close()
    shutil.rmtree(TMP, ignore_errors=True)
    print(f'\n{sum(res)}/{len(res)} PASS · ảnh: {EVD}'); sys.exit(0 if all(res) else 1)
asyncio.run(main())
