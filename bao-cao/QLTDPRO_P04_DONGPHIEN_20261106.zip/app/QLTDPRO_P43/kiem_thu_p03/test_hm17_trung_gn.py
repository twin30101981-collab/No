# P03 · HM-17 — V3: trang Khách hàng mới không được lặp một khế ước giải ngân (đổi HĐTD giữa các mốc).
# Dùng (từ app/QLTDPRO_P43/): python3 kiem_thu_p03/test_hm17_trung_gn.py [app/QLTDPRO_v24.17.13.html]
# Tệp THẬT (chỉ thư mục tạm): MIS_DIR=<dd.mm.yyyy.xls(x)> TS_FILE=<sao kê TSBĐ> python3 kiem_thu_p03/test_hm17_trung_gn.py <app>
import asyncio, functools, http.server, threading, sys, re, os, tempfile, shutil, subprocess, collections
from pathlib import Path
from playwright.async_api import async_playwright
import pandas as pd
ROOT = Path(__file__).resolve().parent.parent
APP = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / 'app' / 'QLTDPRO_v24.17.13.html'
PORT = 8864
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
httpd = http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(APP.parent)))
threading.Thread(target=httpd.serve_forever, daemon=True).start()
URL = f'http://127.0.0.1:{PORT}/{APP.name}'
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:500]))
TMP = Path(tempfile.mkdtemp(prefix='hm17_')); DL = TMP / 'mis'; DL.mkdir()
PAT = r'\d\d\.\d\d\.\d{4}\.(xlsx|XLS)$'
if os.environ.get('MIS_DIR'):
    for f in Path(os.environ['MIS_DIR']).iterdir():
        if f.is_file() and re.match(PAT, f.name): shutil.copy(f, DL / f.name)
else:
    subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(DL)], check=True, stdout=subprocess.DEVNULL)
TS = Path(os.environ.get('TS_FILE') or ROOT / 'app/kiem_thu_p40/xlsx/18_08_2026-TS.xlsx')
F = sorted([f for f in DL.iterdir() if re.match(PAT, f.name)], key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
ISO = lambda f: f.name[6:10] + '-' + f.name[3:5] + '-' + f.name[:2]
VN = lambda f: f.name[:10].replace('.', '/')
# Kỳ báo cáo = (mốc đầu, mốc cuối]. Mong đợi: số khế ước DUY NHẤT có ngày GN trong kỳ, dư nợ > 0 ở ít nhất một mốc (Lưu trữ chỉ giữ dòng dư nợ > 0).
D0, D1 = ISO(F[0]), ISO(F[-1])
from datetime import date, timedelta
FROM = (date.fromisoformat(D0) + timedelta(days=1)).isoformat()
seqs = set(); seq_hd = collections.defaultdict(set)
for f in F:
    x = pd.read_excel(f, dtype=str)
    x = x[pd.to_numeric(x['dsbsbal'].str.replace(',', ''), errors='coerce').fillna(0) > 0]
    def iso(v):
        v = str(v).strip(); m = re.match(r'(\d{4})-(\d\d)-(\d\d)', v) or None
        if m: return v[:10]
        m = re.match(r'(\d{1,2})/(\d{1,2})/(\d{4})', v)
        return f'{m[3]}-{int(m[2]):02d}-{int(m[1]):02d}' if m else ''
    dt = x['dsbsdt'].map(iso)
    x = x[(dt >= FROM) & (dt <= D1)]
    for s_, h in zip(x['dsbsseq'].astype(str), x['apprseq'].astype(str)): seqs.add(s_.strip()); seq_hd[s_.strip()].add(h)
DOI_HD = sum(1 for v in seq_hd.values() if len(v) > 1)
print(f'Mong đợi: {len(seqs)} khế ước GN duy nhất; {DOI_HD} khế ước đổi HĐTD giữa các mốc')

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(); c = await b.new_context(viewport={'width': 1366, 'height': 900}, locale='vi-VN')
        await c.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
        pg = await c.new_page(); errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
        await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in F + [TS]]); await pg.wait_for_timeout(3000)
        await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
        y = pg.locator('[data-testid="confirm-yes"]')
        if await y.count(): await y.click()
        await pg.wait_for_timeout(3000 + 1500 * len(F))
        await pg.goto(URL + '#/khach-hang-moi', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
        for sel, d in (('khm-arch-dau', VN(F[0])), ('khm-arch-cuoi', VN(F[-1]))):
            s = pg.locator(f'[data-testid="{sel}"]'); lab = [t for t in await s.locator('option').all_inner_texts() if d in t][0]
            await s.select_option(label=lab)
        await pg.locator('[data-testid="khm-arch-load"]').click(); await pg.wait_for_timeout(3000)
        await pg.locator('[data-testid="khm-go"]').click()
        await pg.wait_for_selector('[data-testid="khm-tab-chitiet-btn"]', timeout=60000)
        await pg.locator('[data-testid="khm-tab-chitiet-btn"]').first.click(); await pg.wait_for_timeout(1500)
        ks = []
        for _ in range(500):  # đọc MỌI trang (100 dòng/trang)
            t = await pg.evaluate("""()=>{const T=document.querySelector('[data-testid="khm-t-chitiet"]');const h=[...T.querySelectorAll('thead th')].map(x=>x.textContent.trim());
                return {h, rows:[...T.querySelectorAll('tbody tr')].map(tr=>[...tr.children].map(td=>td.textContent.trim()))}}""")
            ci = t['h'].index('Khế ước')
            ks += [r[ci] for r in t['rows'] if len(r) > ci and r[ci]]
            nx = pg.locator('[data-testid="khm-tab-chitiet"] button[aria-label="Trang sau"]')
            if not await nx.count() or await nx.first.is_disabled(): break
            await nx.first.click(); await pg.wait_for_timeout(150)
        dup = [k for k, n in collections.Counter(ks).items() if n > 1]
        print(f'Chi tiết: {len(ks)} dòng, {len(set(ks))} khế ước, {len(dup)} khế ước lặp')
        ok('T0 dữ liệu có khế ước đổi HĐTD giữa các mốc (điều kiện tái hiện)', DOI_HD > 0, DOI_HD)
        ok('T1 Chi tiết: không khế ước nào lặp', not dup, dup[:5])
        ok('T2 Chi tiết: số dòng = số khế ước GN duy nhất mong đợi', len(ks) == len(seqs), (len(ks), len(seqs), sorted(set(ks) ^ seqs)[:6]))
        await pg.locator('[data-testid="khm-tab-tongquan-btn"]').first.click(); await pg.wait_for_timeout(600)
        kp = [re.sub(r'\s+', ' ', x) for x in await pg.locator('[data-testid="khm-kpi"]').all_inner_texts()]
        print('KPI:', kp[:3])
        gd16 = await pg.evaluate("!!document.querySelector('[data-testid=khm-kpi][data-hm18=gn]')")
        if gd16:  # từ v24.17.16 (HM-18, Q11): KPI theo lõi QLTD_DSTN trên mọi mốc — "món mới" = số khế ước GN mới DUY NHẤT của lõi (khóa dsbsseq)
            L = await pg.evaluate("(()=>{const R=window.__khmDstn;const s=R.khe.filter(z=>z.gnMon>0).map(z=>z.dsbsseq);return {mon:R.tong.gnMon,n:s.length,u:new Set(s).size}})()")
            m = re.search(r'([\d.]+) món mới', ' '.join(kp))
            ok('T3 KPI số món GN mới = số khế ước GN mới duy nhất (lõi, không lặp do đổi HĐTD)', m and int(m.group(1).replace('.', '')) == L['mon'] == L['u'] == L['n'] and L['mon'] >= len(seqs), (m and m.group(1), L, len(seqs), kp[:1]))
        else:
            m = re.search(r'([\d.]+) món', ' '.join(kp))
            ok('T3 KPI số món GN = số khế ước duy nhất', m and int(m.group(1).replace('.', '')) == len(seqs), (m and m.group(1), len(seqs), kp[:3]))
        ok('T4 không pageerror', not errs, errs)
        await b.close()
    shutil.rmtree(TMP, ignore_errors=True)
    print(f'\n{sum(res)}/{len(res)} PASS'); sys.exit(0 if all(res) else 1)
asyncio.run(main())
