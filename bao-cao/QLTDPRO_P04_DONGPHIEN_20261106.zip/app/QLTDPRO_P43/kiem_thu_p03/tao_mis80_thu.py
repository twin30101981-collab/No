# P03 · HM-11b: sinh chuỗi mốc msit80 THỬ (ẩn danh, tất định) từ app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx.
# Có đủ tình huống: trả bớt, tất toán, đổi HĐTD (giữ dsbsseq), đổi cán bộ, dư nợ tăng không GN, GN thêm,
# GN mới ở mốc giữa rồi tất toán trước cuối kỳ, xuất hiện lại, chuyển đến (ngày GN trước kỳ), khách hết dư nợ.
# Tên tệp dd.mm.yyyy.xlsx (như tệp thật) — dùng chung cho app (Nhập dữ liệu) và công cụ doi_chieu_mis80.
# Dùng: python3 -I kiem_thu_p03/tao_mis80_thu.py <tệp gốc .xlsx> <thư mục ra>
import sys, random, copy
from pathlib import Path
import openpyxl, datetime, re
SRC, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
rnd = random.Random(20261105)
wb = openpyxl.load_workbook(SRC); ws = wb.active
H0 = [c.value for c in ws[1]]
HDR = H0[:1] + ['custseq'] + H0[1:14] + ['ofcno'] + H0[14:]
rows = []
kh, cbm = {}, {}
for v in ws.iter_rows(min_row=2, values_only=True):
    r = dict(zip(H0, v))
    if r['custnm'] not in kh: kh[r['custnm']] = '3201%09d' % (len(kh) + 1)
    if r['ofcnm'] not in cbm: cbm[r['ofcnm']] = 'CB%03d' % (len(cbm) + 1)
    r['brcd'] = kh[r['custnm']]; r['custseq'] = '3201'; r['ofcno'] = cbm[r['ofcnm']]
    r['dsbsamt'] = int(r['dsbsamt'] or 0); r['dsbsbal'] = int(r['dsbsbal'] or 0); r['rpmtamt'] = 0
    if r['dsbsbal'] > r['dsbsamt']: r['dsbsamt'] = r['dsbsbal']
    rows.append(r)
CB = sorted(cbm.items()); PH = sorted({r['trctnm'] for r in rows})
def ngay(d, m, y=2026): return '%02d/%02d/%04d' % (d, m, y)
def k1000(x): return int(x) // 1000 * 1000
seq = [900000]
def moi(dmin, dmax, m, khach=None):
    seq[0] += 1; b = rnd.choice(rows) if khach is None else khach
    amt = k1000(rnd.randint(50, 900) * 1e6); r = copy.deepcopy(b)
    r.update(dsbsseq='DS%06d' % seq[0], apprseq='HD%06d' % seq[0], dsbsdt=ngay(rnd.randint(dmin, dmax), m), dsbsamt=amt, dsbsbal=amt - k1000(rnd.random() * amt * 0.1))
    return r
def buoc(prev, dmin, dmax, m, n_moi, tag):
    cur = []; log = {}
    for r in prev:
        x = rnd.random(); r = copy.deepcopy(r)
        if x < 0.05: log.setdefault('tat_toan', 0); log['tat_toan'] += 1; continue
        if x < 0.35: r['dsbsbal'] = k1000(r['dsbsbal'] * rnd.uniform(0.5, 0.98))
        elif x < 0.38: r['apprseq'] = 'HDN' + r['apprseq'][2:] + tag; log['doi_hdtd'] = log.get('doi_hdtd', 0) + 1
        elif x < 0.42:
            c = rnd.choice(CB); r['ofcnm'], r['ofcno'] = c; log['doi_cb'] = log.get('doi_cb', 0) + 1
        elif x < 0.43: r['dsbsbal'] += 7_000_000; log['tang_khong_gn'] = log.get('tang_khong_gn', 0) + 1
        elif x < 0.44: r['dsbsamt'] += 100_000_000; r['dsbsbal'] += 100_000_000; log['gn_them'] = log.get('gn_them', 0) + 1
        cur.append(r)
    for _ in range(n_moi): cur.append(moi(dmin, dmax, m))
    log['gn_moi'] = n_moi
    return cur, log
M0 = rows
# khách hết dư nợ ở cuối kỳ: lấy 3 khách, mọi khế ước tất toán ở M2
M1, l1 = buoc(M0, 1, 15, 10, 60, 'A')
M2, l2 = buoc(M1, 16, 31, 10, 50, 'B')
gn_m1 = [r for r in M1 if r['dsbsseq'].startswith('DS9') and r['dsbsdt'] <= ngay(15, 10)]
bo = {r['dsbsseq'] for r in gn_m1[:15]}  # GN ở mốc giữa rồi tất toán trước cuối kỳ
M2 = [r for r in M2 if r['dsbsseq'] not in bo]
het = sorted({r['brcd'] for r in M2})[:3]; M2 = [r for r in M2 if r['brcd'] not in het]
lai = [copy.deepcopy(r) for r in M0 if r['dsbsseq'] not in {x['dsbsseq'] for x in M1}][:5]  # xuất hiện lại
M2 += lai
# HM-16: khế ước DƯ NỢ 0 vẫn liệt kê trong tệp (GN rồi trả hết trong tháng) — như tệp msit80 thật (13–15 dòng/tệp)
def zero(dmin, dmax, m):
    r = moi(dmin, dmax, m); r['dsbsbal'] = 0; return r
M1 += [zero(1, 15, 10) for _ in range(8)]
z2 = [zero(16, 31, 10) for _ in range(6)]
da0 = [dict(copy.deepcopy(r), dsbsbal=0) for r in M1 if r['dsbsseq'].startswith('DS9') and r['dsbsbal'] > 0][15:19]  # tất toán nhưng còn dòng dư nợ 0
M2 = [r for r in M2 if r['dsbsseq'] not in {x['dsbsseq'] for x in da0}] + z2 + da0
den = moi(1, 28, 8); den['dsbsdt'] = ngay(rnd.randint(1, 28), 8); M2.append(den)  # chuyển đến, ngày GN trước kỳ
info = dict(m1=l1, m2=l2, gn_roi_tat_toan=len(bo), khach_het_du_no=len(het), xuat_hien_lai=len(lai), chuyen_den=1, du_no_0=dict(m1=8, m2=len(z2) + len(da0)))
def dcell(v):  # ngày ghi thành Ô NGÀY như tệp msit80 thật
    m = re.fullmatch(r'(\d\d)/(\d\d)/(\d{4})', str(v)) if isinstance(v, str) else None
    return datetime.datetime(int(m[3]), int(m[2]), int(m[1])) if m else v
def ghi(rs, ten):
    w = openpyxl.Workbook(); s = w.active; s.title = 'Sheet1'; s.append(HDR)
    for r in rs: s.append([dcell(r.get(h)) for h in HDR])
    w.save(OUT / ten)
ghi(M0, '30.09.2026.xlsx'); ghi(M1, '15.10.2026.xlsx'); ghi(M2, '31.10.2026.xlsx')
print('OK', len(M0), len(M1), len(M2), info)
