# -*- coding: utf-8 -*-
# HM-19 + HM-13 · V3 — Máy tính lãi & Lãi đọng: một lối vào, bảng Gọn, tổng thấy ngay, thẻ điện thoại, bảng phân rã, 3 tổng Lãi đọng.
# Dữ liệu thử ẩn danh tự sinh (msit80_03-11-2026.xlsx tạm), nạp qua #/nhap như người dùng. Số kỳ vọng tính ĐỘC LẬP (Fraction).
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p04/test_hm19_mtl.py [app/QLTDPRO_v24.17.19.html]
import asyncio, functools, http.server, threading, re, sys, tempfile, os
from datetime import date
from fractions import Fraction as F
from math import floor
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.19.html'
PORT = 8843; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence'; SHOT = (EV / 'hm19' / 'anh') if EV.exists() else HERE / 'anh_hm19'; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:400]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()

CHOT = '2026-11-03'
def d(s): return date.fromisoformat(s)
def rnd(x): return int(floor(x + F(1, 2)))
def lai(duno, ls, moc, quahan_tu):
    n = (d(CHOT) - d(moc)).days; th = min(n, max(0, (d(quahan_tu) - d(moc)).days)); qh = n - th; k = F(duno) * F(str(ls)) / 100 / 365
    return (rnd(k * th) if th else 0) + (rnd(k * qh) if qh else 0) + (rnd(k * F(1, 2) * qh) if qh else 0), th, qh
KH = 'Khách Mười Chín'
# (tên, dsbsseq, dư nợ, LS, ngày GN, đến hạn, đã thu lãi đến, lntpcd, nxtrpmtschddt, intamt, quá hạn từ (độc lập))
LO = [(KH, 'K1', 800_000_000, 8.5, '2026-03-01', '2027-03-01', '2026-09-30', '211', '', 5_000_000, '2027-03-01'),
      (KH, 'K2', 300_000_000, 9, '2026-01-15', '2026-10-15', '2026-09-15', '211', '', 2_000_000, '2026-10-15'),
      (KH, 'K3', 1_200_000_000, 7.8, '2025-01-01', '2029-01-01', '2026-09-20', '212', '2026-10-20', 7_000_000, '2026-10-20'),
      (KH, 'K4', 150_000_000, 10, '2026-02-28', '2027-02-28', '2026-08-31', '211', '', 1_500_000, '2027-02-28'),
      ('Khách Phụ', 'K5', 500_000_000, 8, '2026-04-01', '2027-04-01', '2026-09-30', '211', '', 3_000_000, '2027-04-01')]
EXP = {x[1]: lai(x[2], x[3], x[6], x[10]) for x in LO}
def us(s): return s[5:7] + '/' + s[8:10] + '/' + s[:4] if s else None
def tao_xlsx(p):
    wb = openpyxl.Workbook(); ws = wb.active
    ws.append(['brcd', 'custnm', 'apprseq', 'apprdt', 'apprmatdt', 'appramt', 'dsbsseq', 'dsbsdt', 'dsbsmatdt', 'sprd', 'dsbsamt', 'rpmtamt', 'intamt', 'dsbsbal',
               'ofcnm', 'lntpcd', 'addr1', 'commmn', 'fndprpstpcd', 'trctnm', 'aqccdfin', 'lstintchrgprd', 'nxtrpmtschddt', 'lstrpmtdt'])
    for i, x in enumerate(LO):
        ws.append(['3201', x[0], 'HD19-%d' % i, us(x[4]), us(x[5]), x[2], x[1], us(x[4]), us(x[5]), str(x[3]), x[2], 0, x[9], x[2],
                   'CÁN BỘ THỬ', x[7], '9 Phố Thử, Hà Nội', None, 'TD001', 'PGD Thử', 'Nhóm 1', us(x[6]), us(x[8]), None])
    wb.save(p)
def num(s): v = re.sub(r'[^\d]', '', s or ''); return int(v) if v else 0

async def run(pw, name, vw, vh, fix):
    b = await pw.chromium.launch(); ctx = await b.new_context(viewport={'width': vw, 'height': vh})
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    T = lambda s: f'{name}: {s}'
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [fix]); await pg.wait_for_timeout(2500)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(4500)
    await pg.goto(URL + '#/lai-dong', wait_until='domcontentloaded'); await pg.wait_for_timeout(2000)
    await pg.fill('[data-testid="gd14-chot"]', CHOT); await pg.wait_for_timeout(800)
    ok(T('L1 một lối vào: có "Máy tính lãi", không còn nút "Tính lãi tất toán"'), await pg.locator('[data-testid="gd14-calc"]').count() == 1 and await pg.locator('[data-testid="gd14-tool"]').count() == 0)
    n = pg.locator('[data-testid="gd14-ld-note"]')
    ok(T('L2 có ghi chú nguồn 3 tổng'), await n.count() == 1)
    if await n.count():
        M = num(await pg.locator('[data-testid="tong"]').inner_text()); Tt = num(await pg.locator('[data-testid="gd14-tong-duthu"]').inner_text())
        txt = await n.inner_text()
        eM = sum(x[9] for x in LO); eT = sum(v[0] for v in EXP.values())
        ok(T('L3 Σ lãi = Σ intamt IPCAS (Python) — ' + str(eM)), M == eM, M)
        ok(T('L4 Σ lãi dự thu = Σ lãi tính độc lập đến 03/11 — ' + str(eT)), Tt == eT, (Tt, eT))
        ok(T('L5 ghi chú nêu chênh = dự thu − Σ lãi'), ('{:,}'.format(eT - eM).replace(',', '.')) in txt, txt[-120:])
    await pg.screenshot(path=str(SHOT / f'{name}_01_lai_dong.png'))
    await pg.click('[data-testid="gd14-calc"]'); await pg.wait_for_timeout(400)
    await pg.fill('[data-testid=gd14-calc-chot]', CHOT); await pg.wait_for_timeout(200)
    await pg.fill('[data-testid=gd14-calc-search]', 'Muoi Chin'); await pg.wait_for_timeout(300)
    ku = pg.locator('[data-testid=gd14-calc-hit-ku]').first
    ok(T('C1 danh sách tìm ghi số khế ước + ngày đến hạn'), await ku.count() == 1 and 'K2 (đến hạn 15/10/2026)' in await ku.inner_text(), await ku.inner_text() if await ku.count() else '')
    await pg.locator('[data-testid=gd14-calc-hit]').first.click(); await pg.wait_for_timeout(800)
    ok(T('C2 chọn xong danh sách thu gọn'), await pg.locator('[data-testid=gd14-calc-results]').count() == 0)
    vis_th = await pg.evaluate("[...document.querySelectorAll('[data-testid=gd14-calc-table] thead th')].filter(t=>getComputedStyle(t).display!=='none'&&t.getBoundingClientRect().width>1).length")
    if vw >= 600:
        ok(T('C3 bảng Gọn ≤ 9 cột'), 0 < vis_th <= 9, vis_th)
        sc = await pg.evaluate("(()=>{const w=document.querySelector('[data-testid=gd14-calc-scroll]');return [w.scrollWidth,w.clientWidth]})()")
        ok(T('C4 không cuộn ngang bảng ở 1366'), sc[0] <= sc[1] + 1, sc)
    bx = await pg.locator('[data-testid=gd14-calc-tonglai]').bounding_box()
    ok(T('C5 thấy TỔNG LÃI ngay, không cuộn'), bx and bx['y'] >= 0 and bx['y'] + bx['height'] <= vh, bx)
    tl = num(await pg.locator('[data-testid=gd14-calc-tonglai]').inner_text())
    eK = sum(EXP[k][0] for k in ('K1', 'K2', 'K3', 'K4'))
    ok(T('C6 Tổng lãi = Σ độc lập 4 khoản ' + str(eK)), tl == eK, tl)
    pr = pg.locator('[data-testid=gd14-calc-phanra]')
    ok(T('C7 có bảng phân rã'), await pr.count() == 1)
    if await pr.count():
        if await pr.get_attribute('open') is None: await pr.locator('summary').click()
        tongs = [num(t) for t in await pr.locator('[data-testid=gd14-calc-phanra-tong]').all_inner_texts()]
        ok(T('C8 phân rã: tổng từng khoản khớp độc lập'), sorted(tongs) == sorted(EXP[k][0] for k in ('K1', 'K2', 'K3', 'K4')), tongs)
        ptxt = await pr.inner_text()
        k2 = EXP['K2']; k3 = EXP['K3']
        ok(T('C9 K2 quá hạn từ 15/10/2026 → 03/11/2026, %d ngày; K3 Q12 từ 20/10/2026' % k2[2]),
           re.search(r'Quá hạn \(LS × 1,5\)\s+15/10/2026\s+03/11/2026\s+%d' % k2[2], ptxt) is not None and re.search(r'Quá hạn \(LS × 1,5\)\s+20/10/2026\s+03/11/2026\s+%d' % k3[2], ptxt) is not None
           and 'Không áp dụng — ngắn hạn/thấu chi (Q12)' in ptxt, ptxt[:600])
        ok(T('C10 ngày trong phân rã dạng dd/mm/yyyy (không ISO)'), re.search(r'\d{4}-\d{2}-\d{2}', ptxt) is None)
    await pg.screenshot(path=str(SHOT / f'{name}_02_may_tinh.png'))
    if vw < 600:
        disp = await pg.evaluate("getComputedStyle(document.querySelector('[data-testid=gd14-calc-row]')).display")
        ok(T('M1 điện thoại: mỗi khoản là một thẻ'), disp == 'block', disp)
        small = await pg.evaluate("[...document.querySelectorAll('[data-testid=gd14-calc-overlay] button,[data-testid=gd14-calc-overlay] input:not([type=checkbox]),[data-testid=gd14-calc-overlay] select')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&r.height<40}).map(e=>(e.getAttribute('data-testid')||e.tagName)+':'+Math.round(e.getBoundingClientRect().height))")
        ok(T('M2 điện thoại: 0 nút/ô < 40 px'), not small, small)
        sw = await pg.evaluate('[document.documentElement.scrollWidth, innerWidth]')
        ok(T('M3 không tràn ngang'), sw[0] <= sw[1], sw)
    else:
        await pg.click('[data-testid=gd14-calc-cols]'); await pg.wait_for_timeout(200)
        full = await pg.evaluate("[...document.querySelectorAll('[data-testid=gd14-calc-table] thead th')].filter(t=>getComputedStyle(t).display!=='none'&&t.getBoundingClientRect().width>1).length")
        tl2 = num(await pg.locator('[data-testid=gd14-calc-tonglai]').inner_text())
        ok(T('C11 nút Đầy đủ cột: 16 cột, số không đổi'), full == 16 and tl2 == tl, (full, tl2))
        await pg.click('[data-testid=gd14-calc-cols]'); await pg.wait_for_timeout(200)
    await pg.click('[data-testid=gd14-calc-copy]'); cp = await pg.evaluate('GD14.calc.lastCopy') or ''
    ok(T('C12 Copy kết quả có tổng lãi'), ('Tổng lãi phải thu: ' + '{:,}'.format(eK).replace(',', '.')) in cp, cp[-200:])
    ok(T('E1 0 pageerror'), not errs, errs)
    await b.close()

async def main():
    tmp = tempfile.mkdtemp(); fix = os.path.join(tmp, 'msit80_03-11-2026.xlsx'); tao_xlsx(fix)
    async with async_playwright() as pw:
        await run(pw, 'desktop', 1366, 768, fix); await run(pw, 'mobile', 390, 844, fix)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
