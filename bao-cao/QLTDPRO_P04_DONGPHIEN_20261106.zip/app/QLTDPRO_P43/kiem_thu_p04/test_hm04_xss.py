# -*- coding: utf-8 -*-
# HM-04 · V3 — đầu vào không tin cậy: chuỗi HTML/script trong tệp msit80 (tên, địa chỉ, cán bộ, phòng, HĐTD, GN, mục đích, ghi chú)
# phải hiển thị như văn bản ở mọi trang. Phát hiện: (1) mã chạy thật → window.__xss; (2) phần tử bị chèn → thuộc tính on* chứa
# "__xss" hoặc phần tử có data-xss. Dữ liệu thử ẩn danh tự sinh.
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p04/test_hm04_xss.py [app/QLTDPRO_v24.17.24.html]
import asyncio, functools, http.server, threading, sys, json, tempfile, os, re
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.23.html'
PORT = 8851; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm04'
if not EV.parent.exists(): EV = HERE / 'hm04'
EV.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:700]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()

def P(tag):  # bộ chuỗi tấn công cho một trường
    return [f'<img src=x onerror="(window.__xss=window.__xss||[]).push(\'{tag}1\')">',
            f'<svg onload="(window.__xss=window.__xss||[]).push(\'{tag}2\')"></svg>',
            f'</td></tr><b data-xss="{tag}3">x</b>',
            f'" onmouseover="(window.__xss=window.__xss||[]).push(\'{tag}4\')" x="',
            f"' onfocus='(window.__xss=window.__xss||[]).push(\"{tag}5\")' autofocus='"]
FIELDS = {'custnm': 'N', 'addr1': 'A', 'ofcnm': 'C', 'trctnm': 'T', 'apprseq': 'H', 'dsbsseq': 'G', 'fndprpstpcd': 'M', 'commmn': 'K'}
HD = ['brcd', 'custnm', 'apprseq', 'apprdt', 'apprmatdt', 'appramt', 'dsbsseq', 'dsbsdt', 'dsbsmatdt', 'sprd', 'dsbsamt', 'rpmtamt', 'intamt', 'dsbsbal',
      'ofcnm', 'lntpcd', 'addr1', 'commmn', 'fndprpstpcd', 'trctnm', 'aqccdfin', 'lstintchrgprd', 'nxtrpmtschddt', 'lstrpmtdt']
def tao(p):
    wb = openpyxl.Workbook(); ws = wb.active; ws.append(HD); i = 0
    for v in range(5):
        for f, tag in FIELDS.items():
            i += 1
            r = {'brcd': '3201', 'custnm': f'Khách Thử {i}', 'apprseq': f'HD4-{i}', 'apprdt': '01/05/2026', 'apprmatdt': '01/05/2027', 'appramt': 100_000_000,
                 'dsbsseq': f'GN4-{i}', 'dsbsdt': '01/05/2026', 'dsbsmatdt': '10/20/2026' if i % 3 == 0 else '05/01/2027', 'sprd': '8.5', 'dsbsamt': 100_000_000,
                 'rpmtamt': 0, 'intamt': 500_000 * (i % 4), 'dsbsbal': 100_000_000 + i, 'ofcnm': 'CÁN BỘ THỬ', 'lntpcd': '211' if i % 2 else '212',
                 'addr1': f'{i} Phố Thử', 'commmn': '', 'fndprpstpcd': 'TD001', 'trctnm': 'PGD Thử', 'aqccdfin': 'Nhóm 1' if i % 5 else 'Nhóm 3',
                 'lstintchrgprd': '08/31/2026', 'nxtrpmtschddt': '11/20/2026', 'lstrpmtdt': None}
            r[f] = P(tag)[v] + (f' {i}' if f in ('custnm', 'apprseq', 'dsbsseq') else '')
            ws.append([r[h] for h in HD])
    wb.save(p)

SCAN = r"""()=>{const bad=new Set();document.querySelectorAll('*').forEach(e=>{for(const a of e.attributes){if(/^on/i.test(a.name)&&/__xss/.test(a.value))bad.add(e.tagName.toLowerCase()+'['+a.name+']@'+(e.closest('[data-testid]')||{getAttribute:()=>''}).getAttribute('data-testid'))}
  if(e.hasAttribute('data-xss'))bad.add('data-xss='+e.getAttribute('data-xss')+'@'+(e.parentElement&&e.parentElement.closest('[data-testid],[id],[class]')?(e.parentElement.closest('[data-testid]')||e.parentElement).getAttribute('data-testid')||e.parentElement.className:''))});
  return {bad:[...bad],ran:window.__xss||[]}}"""

async def run(pw):
    br = await pw.chromium.launch(); fix = os.path.join(tempfile.mkdtemp(), 'msit80_03-11-2026.xlsx'); tao(fix)
    ctx = await br.new_context(viewport={'width': 1366, 'height': 900})
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; dlg = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:160])); pg.on('dialog', lambda d: (dlg.append(d.message), asyncio.ensure_future(d.dismiss())))
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [fix]); await pg.wait_for_timeout(2500)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(6000)
    rs = [x for x in await pg.evaluate("[...new Set([...document.querySelectorAll('a[href^=\"#/\"]')].map(a=>a.getAttribute('href')))]") if x and len(x) > 2]
    seen = {}; ndong = 0; hien = {}
    async def ghi(where):
        r = await pg.evaluate(SCAN)
        for b in r['bad']: seen.setdefault(b, where)
        for x in r['ran']: seen.setdefault('CHẠY:' + x, where)
    for r in rs:
        await pg.goto(URL + r, wait_until='domcontentloaded'); await pg.wait_for_timeout(1100); await ghi(r)
        nx = await pg.evaluate("((document.querySelector('main')||document.body).innerText.match(/__xss|data-xss/g)||[]).length")
        if nx: hien[r] = nx
        row = pg.locator('[data-testid=dt-row]').first
        if await row.count():
            ndong += 1
            try:
                await row.hover(); await row.click(timeout=3000); await pg.wait_for_timeout(700); await ghi(r + ' (bấm dòng)')
                await pg.keyboard.press('Escape'); await pg.wait_for_timeout(200)
            except Exception: pass
        nm = pg.locator('.gd7-name').first
        if await nm.count():
            try: await nm.click(timeout=3000); await pg.wait_for_timeout(700); await ghi(r + ' (thẻ cán bộ / drill)'); await pg.keyboard.press('Escape')
            except Exception: pass
    # gd7: khung chi tiết / thẻ cán bộ / hồ sơ KH (chuỗi HTML ghép từ dữ liệu)
    nbam = 0
    for r in ['#/tong-quan', '#/canh-bao-som', '#/khach-hang-360', '#/tat-ca-du-no', '#/doi-soat-so-lieu', '#/tra-no-xuat-ts']:
        await pg.goto(URL + r, wait_until='domcontentloaded'); await pg.wait_for_timeout(1200)
        for sel in ['[data-kpi]', '[data-gd7d]', 'td.gd7-name', '[data-prof]', '[data-p]', '.gd7-drawer tr[data-row]', '.gd7-drawer td.gd7-name']:
            loc = pg.locator(sel)
            for k in range(min(await loc.count(), 3)):
                try:
                    await loc.nth(k).click(timeout=1500); await pg.wait_for_timeout(500); nbam += 1; await ghi(f'{r} (bấm {sel} #{k})')
                    inner = pg.locator('.gd7-drawer td.gd7-name, .gd7-drawer [data-prof], .gd7-drawer tr[data-row]')
                    if await inner.count():
                        await inner.first.click(timeout=1500); await pg.wait_for_timeout(500); nbam += 1; await ghi(f'{r} (khung lồng từ {sel})')
                except Exception: pass
                await pg.keyboard.press('Escape'); await pg.wait_for_timeout(150)
    ok(f'X4 đã bấm {nbam} điểm mở khung chi tiết / thẻ cán bộ của gd7', nbam >= 5, nbam)
    # Máy tính lãi: tìm + chọn khách có tên chứa chuỗi tấn công
    await pg.goto(URL + '#/lai-dong', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    if await pg.locator('[data-testid=gd14-calc]').count():
        await pg.click('[data-testid=gd14-calc]'); await pg.wait_for_timeout(400)
        await pg.fill('[data-testid=gd14-calc-search]', 'xss'); await pg.wait_for_timeout(400); await ghi('Máy tính lãi (danh sách tìm)')
        hits = pg.locator('[data-testid=gd14-calc-hit]')
        for k in range(min(await hits.count(), 6)):
            await pg.fill('[data-testid=gd14-calc-search]', 'xss'); await pg.wait_for_timeout(300)
            h2 = pg.locator('[data-testid=gd14-calc-hit]')
            if await h2.count() > k:
                await h2.nth(k).click(); await pg.wait_for_timeout(700); await ghi('Máy tính lãi (khách %d)' % k)
                await pg.click('[data-testid=gd14-calc-copy]'); await pg.wait_for_timeout(200)
        await pg.click('[data-testid=gd14-calc-x]')
    # di chuột qua mọi ô có chứa dấu hiệu (kích hoạt onmouseover nếu bị chèn)
    await pg.goto(URL + '#/tat-ca-du-no', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    cells = pg.locator('[data-testid=dt-row] > div')
    for k in range(min(await cells.count(), 60)):
        try: await cells.nth(k).hover(timeout=500)
        except Exception: pass
    await ghi('Tất cả dư nợ (rê chuột)')
    json.dump(dict(diem=seen, trang=rs, hien_chu=hien, dialog=dlg, pageerror=errs), open(EV / f'ket_qua_{Path(APP).stem}.json', 'w'), ensure_ascii=False, indent=1)
    ok(f'X0 đi qua {len(rs)} trang; {len(hien)} trang hiển thị chuỗi tấn công dưới dạng chữ: ' + ', '.join(f'{k}({v})' for k, v in hien.items()), len(rs) >= 15 and len(hien) >= 6, hien)
    ran = sorted(k for k in seen if k.startswith('CHẠY:'))
    ok('X1 không đoạn mã nào trong dữ liệu được CHẠY', not ran and not dlg, {k: seen[k] for k in ran})
    inj = sorted(k for k in seen if not k.startswith('CHẠY:'))
    ok('X2 không phần tử/thuộc tính nào bị chèn từ dữ liệu (DOM)', not inj, {k: seen[k] for k in inj})
    ok('X3 0 pageerror', not errs, errs[:5])
    await br.close()

async def main():
    async with async_playwright() as pw: await run(pw)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
