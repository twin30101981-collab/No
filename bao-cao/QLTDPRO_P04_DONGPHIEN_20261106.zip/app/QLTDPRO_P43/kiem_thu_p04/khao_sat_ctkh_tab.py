import asyncio,sys,json,subprocess,tempfile,functools,http.server,threading
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path('/home/claude/work/app/QLTDPRO_P43');APP=ROOT/'app/QLTDPRO_v24.17.15.html';OUT=Path('/tmp/claude-0/ks')
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a):pass
h=http.server.ThreadingHTTPServer(('127.0.0.1',8867),functools.partial(Q,directory=str(APP.parent)));threading.Thread(target=h.serve_forever,daemon=True).start()
URL='http://127.0.0.1:8867/'+APP.name
TMP=Path(tempfile.mkdtemp());DL=TMP/'m'
subprocess.run([sys.executable,'-I',str(ROOT/'kiem_thu_p03/tao_mis80_thu.py'),str(ROOT/'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'),str(DL)],check=True,stdout=subprocess.DEVNULL)
F=sorted(DL.iterdir(),key=lambda f:f.name[6:10]+f.name[3:5]+f.name[:2])
async def main():
  kq={}
  async with async_playwright() as p:
    for ten,vp,mob in (('desktop',{'width':1366,'height':768},False),('dt390',{'width':390,'height':844},True)):
      b=await p.chromium.launch();c=await b.new_context(viewport=vp,locale='vi-VN',is_mobile=mob,has_touch=mob);pg=await c.new_page()
      await pg.goto(URL+'#/nhap');await pg.wait_for_timeout(1500)
      await pg.set_input_files('[data-testid="file-input"]',[str(f) for f in F]);await pg.wait_for_timeout(3000)
      await pg.locator('[data-testid="chay"]').click();await pg.wait_for_timeout(800)
      y=pg.locator('[data-testid="confirm-yes"]')
      if await y.count():await y.click()
      await pg.wait_for_timeout(8000)
      await pg.goto(URL+'#/chi-tieu-ke-hoach');await pg.wait_for_timeout(2500)
      tabs=await pg.evaluate("[...document.querySelectorAll('main button')].filter(b=>/^(THEO|BÁO CÁO|TỔNG QUAN)/i.test(b.textContent.trim())&&b.offsetParent).map(b=>b.textContent.trim())")
      for i,t in enumerate(tabs):
        await pg.locator('main button',has_text=t).first.click();await pg.wait_for_timeout(1500)
        kq[ten+'|'+t]=await pg.evaluate("""()=>[...document.querySelectorAll('main table')].filter(t=>t.offsetParent).map(t=>({cot:(t.querySelector('thead tr:last-child')||t.querySelector('tr')).children.length,
          hang_td:t.querySelectorAll('thead tr').length,dong:t.querySelectorAll('tbody tr').length,rong:t.scrollWidth,khung:t.parentElement.clientWidth,
          stickyCot1:getComputedStyle(t.querySelector('tbody td')||t).position,stickyHead:getComputedStyle(t.querySelector('th')||t).position,
          td:[...(t.querySelector('thead tr:last-child')||t.querySelector('tr')).children].map(x=>x.textContent.trim()).join('|').slice(0,300)}))""")
        await pg.screenshot(path=str(OUT/f'ctkh_{ten}_tab{i}.png'))
      await b.close()
  json.dump(kq,open(OUT/'do_dac_ctkh.json','w'),ensure_ascii=False,indent=1)
  for k,v in kq.items():print(k,v)
asyncio.run(main())
