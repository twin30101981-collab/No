# Trích bảng giá đất nhúng trong app (hằng oS của bundle: phường → [STT, tên đường, từ, đến, VT1..VT4 × cao/thấp/TB, nghìn đ/m²])
# ra Excel để đối soát với bảng giá đất 2026. Chỉ đọc.  Chạy: python3 kiem_thu_p04/trich_bang_gia_dat.py app/QLTDPRO_v24.17.19.html ra.xlsx
import sys, json
import openpyxl
src, out = sys.argv[1], sys.argv[2]
s = open(src, encoding='utf-8').read()
i = s.index('const oS={') + len('const oS=')
d, q, esc = 0, False, False
for j in range(i, len(s)):
    c = s[j]
    if q:
        if esc: esc = False
        elif c == '\\': esc = True
        elif c == '"': q = False
        continue
    if c == '"': q = True
    elif c in '{[': d += 1
    elif c in '}]':
        d -= 1
        if d == 0: break
data = json.loads(s[i:j + 1])
wb = openpyxl.Workbook(); ws = wb.active; ws.title = 'Bang_gia_app'
hd = ['Phường', 'STT', 'Tên đường', 'Từ', 'Đến'] + [f'VT{v} {t}' for v in range(1, 5) for t in ('cao nhất', 'thấp nhất', 'trung bình')]
ws.append(hd)
n = 0
for ph, rows in data.items():
    for r in rows:
        ws.append([ph] + r[:4] + [float(x) for x in r[4:16]]); n += 1
ws.freeze_panes = 'C2'
ws2 = wb.create_sheet('Tong_hop'); ws2.append(['Phường', 'Số dòng'])
for ph, rows in data.items(): ws2.append([ph, len(rows)])
ws2.append(['TỔNG', n]); ws2.append(['Đơn vị', 'nghìn đồng/m² (như app)']); ws2.append(['Nguồn', src])
wb.save(out); print('Phường:', len(data), '· dòng:', n, '→', out)
