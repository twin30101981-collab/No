# -*- coding: utf-8 -*-
# HM-23 + HM-24 · V3 — Tài sản bảo đảm: mốc TS tự lưu theo ngày tệp (Q16), tab "TS chưa có HĐTD", tab "Đầu kỳ & 2 mốc".
# Dữ liệu thử ẩn danh: dư nợ 3 mốc (tao_mis80_thu) + 2 tệp sao kê TS (30/09, 31/10/2026) sinh từ chính dư nợ; đáp án Python độc lập.
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p04/test_hm23_ts_moc.py [app/QLTDPRO_v24.17.26.html]
import asyncio, functools, http.server, threading, sys, tempfile, subprocess, re
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.26.html'
PORT = 8859; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm23'
if not EV.parent.exists(): EV = HERE / 'hm23'
(EV / 'anh').mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:600]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
TMP = Path(tempfile.mkdtemp()) / 'm'
subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(TMP)], check=True, stdout=subprocess.DEVNULL)
FILES = sorted(TMP.iterdir(), key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
_wb = openpyxl.load_workbook(FILES[-1]); _ws = _wb.active; _h = [c.value for c in _ws[1]]   # thêm 1 khách vay mới ở 31/10 (dữ liệu thử)
_r = [c.value for c in _ws[2]]; _r[_h.index('brcd')] = 'VAYMOI0000003'; _r[_h.index('custnm')] = 'Khách vay mới Ba'; _r[_h.index('dsbsseq')] = 'LCL3201VAYMOI3'; _r[_h.index('dsbsbal')] = 500_000_000
_ws.append(_r); _wb.save(FILES[-1])
def khach(f):
    ws = openpyxl.load_workbook(f, read_only=True).active; rows = list(ws.iter_rows(values_only=True)); h = rows[0]
    b, d = h.index('brcd'), h.index('dsbsbal'); co = {}
    for r in rows[1:]: co.setdefault(str(r[b]).strip(), 0); co[str(r[b]).strip()] += (r[d] or 0)
    return co
K30, K31 = khach(FILES[0]), khach(FILES[-1])
ca_hai = [k for k in K31 if k in K30 and K31[k] > 0][:5]
moi31 = [k for k in K31 if k not in K30 and K31[k] > 0][:1]   # = VAYMOI0000003
assert len(ca_hai) == 5 and moi31, (len(ca_hai), moi31)
CB = {1: ('CÁN BỘ MỘT', 'Hội Sở'), 2: ('CÁN BỘ HAI', 'PGD Số 2')}
def ts(so, kh, ten, c):
    return {'clno': so, 'clcustno': kh, 'clcustnm': ten, 'cltpcd': 'Đất ở', 'cldtltpcd': 'Thổ cư', 'clqtysz': '100', 'clunittpcd': 'm2', 'clloc': so + ' Phố Thử',
            'clamt': 1_000_000_000, 'plgno': 'LCA' + so, 'plgdt': '01/09/2026', 'plgtpcd': 'TC', 'exprdt': '01/09/2028', 'avblamtrt': '70', 'plgamt': 700_000_000,
            'plgcustno': kh, 'plgcustnm': ten, 'clccycd': 'VND', 'clholdcd': 'N', 'ntydt': '01/09/2026', 'rem': '', 'lnofcnm': CB[c][0], 'trctcd': CB[c][1], 'name_2': 'GCN' + so}
E = [ts(f'E{i}', ca_hai[i - 1], f'KH cũ {i}', 1 if i <= 2 else 2) for i in range(1, 6)]
N1, N2 = ts('N1', 'MOI0000000001', 'Khách mới Một', 1), ts('N2', 'MOI0000000002', 'Khách mới Hai', 2)
N3 = ts('N3', moi31[0], 'Khách vay mới Ba', 1)               # chưa có dư nợ ở 30/09, có khế ước ở 31/10
N4 = ts('N4', 'MOI0000000004', 'Khách mới Bốn', 2)             # chỉ ở mốc 30/09 (giải chấp)
N5, N6 = ts('N5', 'MOI0000000005', 'Khách mới Năm', 1), ts('N6', 'MOI0000000006', 'Khách mới Sáu', 2)
TS_A = E[:4] + [N1, N2, N3, N4]; TS_B = E[:4] + [N1, N2, N3, N5, N6, E[4]]
def ghi(rows, ten):
    p = Path(tempfile.mkdtemp()) / ten; wb = openpyxl.Workbook(); w = wb.active; h = list(rows[0].keys()); w.append(h)
    for r in rows: w.append([r[k] for k in h])
    wb.save(p); return p
FA, FB = ghi(TS_A, '30_09_2026-TS.xlsx'), ghi(TS_B, '31_10_2026-TS.xlsx')
# ---- đáp án độc lập: "chưa có HĐTD" = mã KH không có dòng nào (kể cả dư nợ 0) trong dư nợ ≤ ngày mốc
def kct(rows, K): return {r['clno'] for r in rows if r['plgcustno'] not in K}
KA, KB = kct(TS_A, K30), kct(TS_B, K31)
cbOf = {r['clno']: r['lnofcnm'] for r in TS_A + TS_B}
inA, inB = {r['clno'] for r in TS_A}, {r['clno'] for r in TS_B}
def theo_cb(S, c): return len([x for x in S if cbOf[x] == c])
EXP23 = {CB[c][0]: dict(n=theo_cb(KB, CB[c][0]), moi=theo_cb(KB - KA, CB[c][0]), daco=theo_cb({x for x in KA if x in inB and x not in KB}, CB[c][0]), mat=theo_cb({x for x in KA if x not in inB}, CB[c][0])) for c in CB}
EXP24 = {CB[c][0]: dict(kct=(theo_cb(KA, CB[c][0]), theo_cb(KB, CB[c][0])), n=(theo_cb(inA, CB[c][0]), theo_cb(inB, CB[c][0])),
                        them=theo_cb(inB - inA, CB[c][0]), mat=theo_cb(inA - inB, CB[c][0]), doi=theo_cb({x for x in inA & inB if (x in KA) != (x in KB)}, CB[c][0])) for c in CB}
def num(s): t = (s or '').strip(); v = re.sub(r'[^\d]', '', t); return (-1 if t.startswith('-') else 1) * int(v) if v else None

async def nap(pg, files):
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in files]); await pg.wait_for_timeout(3500)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(9000)
async def bang(pg, tid):
    return await pg.evaluate("""(t)=>{const o={};document.querySelectorAll('[data-testid='+t+'] tbody tr[data-cb]').forEach(r=>{o[r.getAttribute('data-cb')]=[...r.children].map(c=>c.textContent.trim())});return o}""", tid)
async def tab(pg, k):
    await pg.click(f'[data-testid=ts-tab-{k}]'); await pg.wait_for_timeout(2500)

async def run(pw, name, vw, vh):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN', accept_downloads=True)
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    T = lambda s: f'{name}: {s}'
    await nap(pg, FILES + [FA]); await nap(pg, [FB])
    keys = await pg.evaluate("""new Promise(r=>{const q=indexedDB.open('QLTDProTSBD',1);q.onsuccess=()=>{const k=q.result.transaction('kv').objectStore('kv').getAllKeys();k.onsuccess=()=>r(k.result.map(String))}})""")
    ok(T('M1 mỗi lần nhập tệp TSBĐ tự lưu mốc theo ngày tệp: moc_2026-09-30, moc_2026-10-31'), 'moc_2026-09-30' in keys and 'moc_2026-10-31' in keys, keys)
    await pg.goto(URL + '#/tai-san-bao-dam', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    # ---- HM-23
    await tab(pg, 'kct')
    t = await bang(pg, 'gd23-kct-t'); sai = []
    for c, e in EXP23.items():
        v = t.get(c)
        if not v: sai.append((c, 'không thấy')); continue
        g = dict(n=num(v[1]), moi=num(v[3]) or 0, daco=num(v[4]) or 0, mat=num(v[5]) or 0)
        if g != e: sai.append((c, g, e))
    ok(T('K1 tab TS chưa có HĐTD (mốc 31/10 so 30/09): theo cán bộ — chưa có HĐTD / mới / đã có HĐTD / không còn = Python'), not sai, (sai, t))
    if t.get('CÁN BỘ MỘT'):
        await pg.locator('[data-testid=gd23-kct-t] tr[data-cb="CÁN BỘ MỘT"] [data-k=moi] button').click(); await pg.wait_for_timeout(500)
        ds = await pg.evaluate("[...document.querySelectorAll('[data-testid=gd23-ct-t] tbody tr')].map(r=>r.getAttribute('data-sots'))")
        ok(T('K2 bấm số "Mới" của CÁN BỘ MỘT → danh sách đúng tài sản (N5)'), sorted(ds) == sorted(x for x in KB - KA if cbOf[x] == 'CÁN BỘ MỘT'), ds)
        await pg.locator('[data-testid=gd23-kct-t] tr[data-cb="CÁN BỘ MỘT"] [data-k=daco] button').click(); await pg.wait_for_timeout(500)
        ds = await pg.evaluate("[...document.querySelectorAll('[data-testid=gd23-ct-t] tbody tr')].map(r=>r.getAttribute('data-sots'))")
        ok(T('K3 bấm "Đã có HĐTD" → N3 (khách vay mới ở 31/10)'), ds == ['N3'], ds)
        nd = await pg.evaluate("(document.querySelector('[data-testid=gd23-ct-t] tbody td[data-lb=\"Ngày thế chấp\"]')||{}).textContent")
        ok(T('K3b ngày thế chấp hiển thị dd/mm/yyyy'), nd == '01/09/2026', nd)
        if vw >= 1000:
            async with pg.expect_download(timeout=15000) as dl: await pg.click('[data-testid=gd23-xlsx]')
            d = await dl.value; ok(T('K4 Xuất Excel danh sách'), d.suggested_filename.endswith('.xlsx'), d.suggested_filename)
    await pg.screenshot(path=str(EV / 'anh' / f'{name}_kct.png'))
    # ---- HM-24
    await tab(pg, 'dk')
    hd = await pg.evaluate("[...document.querySelectorAll('[data-testid=gd23-dk-t] thead th')].map(x=>x.textContent)")
    ok(T('D0 nhãn: Đầu năm (chưa có mốc), Đầu quý + Đầu tháng (mốc 30/09/2026), Ngày BC (mốc 31/10/2026)'),
       'chưa có mốc' in hd[1] and '30/09/2026' in hd[2] and '30/09/2026' in hd[3] and '31/10/2026' in hd[4], hd)
    for cs in ('kct', 'n'):
        await pg.select_option('[data-testid=gd23-dk-cs]', cs); await pg.wait_for_timeout(1500)
        t = await bang(pg, 'gd23-dk-t'); sai = []
        for c, e in EXP24.items():
            v = t.get(c); a, b = e[cs]
            if not v or num(v[3]) != a or num(v[4]) != b or num(v[5]) != b - a or v[1] != '—': sai.append((c, v, (a, b)))
        ok(T(f'D1 Đầu kỳ chỉ số "{cs}": Đầu tháng = mốc 30/09, Ngày BC = 31/10, +/- = Python, Đầu năm "—"'), not sai, sai)
    t = await bang(pg, 'gd23-2moc-t'); sai = []
    for c, e in EXP24.items():
        v = t.get(c)
        if not v or [num(x) for x in v[1:6]] != [e['n'][0], e['n'][1], e['them'], e['mat'], e['doi']]: sai.append((c, v, e))
    ok(T('D2 So 2 mốc (A 30/09, B 31/10): Số TS A/B, Thêm, Mất, Đổi trạng thái HĐTD = Python'), not sai, sai)
    await pg.screenshot(path=str(EV / 'anh' / f'{name}_dk.png'))
    if vw >= 1000:
        # mốc bấm tay vẫn dùng được trong so 2 mốc
        await tab(pg, 'snap'); await pg.click('[data-testid=ts-snap-save]'); await pg.wait_for_timeout(1500)
        await tab(pg, 'dk')
        op = await pg.evaluate("[...document.querySelectorAll('[data-testid=gd23-2moc-b] option')].map(o=>[o.value,o.textContent])")
        tay = [o for o in op if o[0].startswith('t:')]
        ok(T('T1 mốc bấm tay xuất hiện trong "So 2 mốc"'), len(tay) == 1, op)
        if tay:
            await pg.select_option('[data-testid=gd23-2moc-b]', tay[0][0]); await pg.wait_for_timeout(1500)
            t = await bang(pg, 'gd23-2moc-t')
            ok(T('T2 so A 30/09 với mốc tay (lưu sau khi nhập 31/10): Số TS B, Thêm, Mất như mốc 31/10'), all(t.get(c) and [num(x) for x in t[c][2:5]] == [e['n'][1], e['them'], e['mat']] for c, e in EXP24.items()), t)
        # bản cài cũ: chưa có mốc → tạo từ dữ liệu hiện hành
        await pg.evaluate("""new Promise(r=>{const q=indexedDB.open('QLTDProTSBD',1);q.onsuccess=()=>{const tx=q.result.transaction('kv','readwrite');const s=tx.objectStore('kv');['moc_2026-09-30','moc_2026-10-31'].forEach(k=>s.delete(k));tx.oncomplete=()=>r(1)}})""")
        await pg.reload(wait_until='domcontentloaded'); await pg.wait_for_timeout(2500); await tab(pg, 'kct')
        keys = await pg.evaluate("""new Promise(r=>{const q=indexedDB.open('QLTDProTSBD',1);q.onsuccess=()=>{const k=q.result.transaction('kv').objectStore('kv').getAllKeys();k.onsuccess=()=>r(k.result.map(String))}})""")
        ok(T('B1 chưa có mốc (bản cài cũ) → mở tab tự tạo mốc từ dữ liệu hiện hành (moc_2026-10-31)'), 'moc_2026-10-31' in keys and 'moc_2026-09-30' not in keys, keys)
    else:
        sw = await pg.evaluate('[document.documentElement.scrollWidth, innerWidth]')
        ok(T('M2 điện thoại: không tràn ngang trang'), sw[0] <= sw[1], sw)
    ok(T('E1 0 pageerror'), not errs, errs[:3])
    await br.close()

async def main():
    async with async_playwright() as pw:
        await run(pw, 'desktop', 1366, 900); await run(pw, 'mobile', 390, 844)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
