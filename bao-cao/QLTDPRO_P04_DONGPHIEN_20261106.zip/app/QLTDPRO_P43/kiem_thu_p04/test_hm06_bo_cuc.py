# -*- coding: utf-8 -*-
# HM-06 · V3 — bố cục bảng rộng: 6 trang × 1366/390/360. Đo DOM: tràn ngang cấp tài liệu, phần tử lòi khỏi màn hình mà
# KHÔNG nằm trong khung cuộn riêng, nút thao tác bị che. Ảnh: evidence/hm06/anh/<bản>/<trang>_<khổ>.png
# Dữ liệu thử ẩn danh 3 mốc. Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p04/test_hm06_bo_cuc.py [app/QLTDPRO_v24.17.25.html]
import asyncio, functools, http.server, threading, sys, tempfile, subprocess, json
from pathlib import Path
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.24.html'
PORT = 8855; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm06'
if not EV.parent.exists(): EV = HERE / 'hm06'
SHOT = EV / 'anh' / Path(APP).stem; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:500]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
TMP = Path(tempfile.mkdtemp()) / 'm'
subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(TMP)], check=True, stdout=subprocess.DEVNULL)
FILES = sorted(TMP.iterdir(), key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
import openpyxl  # tệp thứ 4 (01/11/2026): 8 dòng đầu có tên KH / địa chỉ / cán bộ dài liền không dấu cách (thử vỡ bố cục)
_wb = openpyxl.load_workbook(FILES[-1]); _ws = _wb.active; _h = [c.value for c in _ws[1]]
for _i, _row in enumerate(_ws.iter_rows(min_row=2, max_row=9)):
    _row[_h.index('custnm')].value = 'CÔNGTYTNHHTHƯƠNGMẠIDỊCHVỤXÂYDỰNGVẬNTẢI' * 4 + str(_i)
    _row[_h.index('addr1')].value = 'SốNhà123NgõĐườngPhườngQuậnThànhPhố' * 5
    if _i < 2: _row[_h.index('ofcnm')].value = 'NGUYỄNTHỊCÁNBỘTÊNRẤTDÀI' * 3
_long = TMP / '01.11.2026.xlsx'; _wb.save(_long); FILES = FILES + [_long]
ROUTES = ['#/gia-dat', '#/bao-cao-ipcas', '#/doi-soat-so-lieu', '#/giai-ngan', '#/ho-so-vay-hop-nhat', '#/luu-tru']
VPS = [('1366', 1366, 768), ('390', 390, 844), ('360', 360, 780)]
DO = r"""()=>{const W=innerWidth,de=document.documentElement;
  const scrollAnc=e=>{for(let p=e.parentElement;p&&p!==document.body;p=p.parentElement){const s=getComputedStyle(p);if(/(auto|scroll|hidden|clip)/.test(s.overflowX)&&p.clientWidth<p.scrollWidth+1)return p}return null};
  const vis=e=>{const r=e.getBoundingClientRect();if(r.width<1||r.height<1)return false;const s=getComputedStyle(e);return s.visibility!=='hidden'&&s.display!=='none'};
  const root=document.querySelector('main')||document.body; const loose=[];
  root.querySelectorAll('*').forEach(e=>{if(!vis(e))return;const r=e.getBoundingClientRect();if(r.right>W+1&&r.left<W&&!scrollAnc(e)){const p=e.parentElement;const pr=p?p.getBoundingClientRect():null;
      if(!pr||pr.right<=W+1||scrollAnc(p)) loose.push((e.getAttribute('data-testid')||e.tagName.toLowerCase()+'.'+String(e.className).slice(0,40))+':'+Math.round(r.right))}});
  const btn=[...root.querySelectorAll('button,select,input:not([type=hidden]),a[href]')].filter(vis);let che=[];
  btn.forEach(b=>{const r=b.getBoundingClientRect();const x=r.left+r.width/2,y=r.top+r.height/2;if(x<0||x>W||y<0||y>innerHeight)return;const t=document.elementFromPoint(x,y);
    const cover=t2=>t2&&t2!==b&&!b.contains(t2)&&!t2.contains(b)&&!(t2.closest&&t2.closest('label')&&t2.closest('label').contains(b));
    let tt=t; if(cover(tt)){let f=tt;let fixed=false;for(;f&&f!==document.body;f=f.parentElement){const ps=getComputedStyle(f).position;if(ps==='fixed'||ps==='sticky'){fixed=true;break}}
      if(fixed){b.scrollIntoView({block:'center'});const r2=b.getBoundingClientRect();tt=document.elementFromPoint(r2.left+r2.width/2,r2.top+r2.height/2)}}
    if(cover(tt))che.push((b.getAttribute('data-testid')||b.textContent.trim().slice(0,20)||b.tagName)+' ← '+(tt.getAttribute('data-testid')||tt.tagName.toLowerCase()+'.'+String(tt.className).slice(0,30)))});
  const tables=[...root.querySelectorAll('table')].filter(vis).map(t=>{const sa=scrollAnc(t);return {w:Math.round(t.getBoundingClientRect().width),khung:sa?sa.clientWidth:null}});
  return {docTran:de.scrollWidth-W, loose:[...new Set(loose)].slice(0,12), nLoose:new Set(loose).size, che:che.slice(0,8), nChe:che.length, bang:tables.length, bangRong:tables.filter(t=>t.w>W).length, bangRongCoKhung:tables.filter(t=>t.w>W&&t.khung!==null).length}}"""

async def run(pw):
    br = await pw.chromium.launch(); out = {}
    for tag, w, h in VPS:
        ctx = await br.new_context(viewport={'width': w, 'height': h}, locale='vi-VN', is_mobile=w < 600, has_touch=w < 600)
        await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
        pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:160]))
        await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
        await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in FILES]); await pg.wait_for_timeout(3000)
        await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
        y = pg.locator('[data-testid="confirm-yes"]')
        if await y.count(): await y.click()
        await pg.wait_for_timeout(8000)
        for r in ROUTES:
            await pg.goto(URL + r, wait_until='domcontentloaded'); await pg.wait_for_timeout(1800)
            if r == '#/giai-ngan':
                ch = pg.locator('main button', has_text=__import__('re').compile(r'^Tất cả$'))
                if await ch.count(): await ch.first.click(); await pg.wait_for_timeout(1200)
            m = await pg.evaluate(DO); m['chuDai'] = await pg.evaluate("((document.querySelector('main')||document.body).innerText.match(/CÔNGTYTNHH|SốNhà123|NGUYỄNTHỊCÁNBỘ/g)||[]).length"); out[f'{r}|{tag}'] = m
            await pg.screenshot(path=str(SHOT / f"{r.strip('#/')}_{tag}.png"), full_page=False)
            ok(f'{tag} {r}: không tràn ngang tài liệu ({m["docTran"]} px), 0 phần tử lòi ngoài khung cuộn, 0 nút bị che; {m["bang"]} bảng ({m["bangRong"]} rộng hơn màn hình, {m["bangRongCoKhung"]} có khung cuộn; chữ dài hiện {m["chuDai"]} lần)',
               m['docTran'] <= 0 and m['nLoose'] == 0 and m['nChe'] == 0 and m['bangRong'] == m['bangRongCoKhung'], m)
        ok(f'{tag} 0 pageerror', not errs, errs[:3])
        await ctx.close()
    json.dump(out, open(EV / f'do_dac_{Path(APP).stem}.json', 'w'), ensure_ascii=False, indent=1)
    await br.close()

async def main():
    async with async_playwright() as pw: await run(pw)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
