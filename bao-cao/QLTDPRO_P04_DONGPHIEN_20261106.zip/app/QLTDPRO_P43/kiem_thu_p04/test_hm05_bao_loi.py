# -*- coding: utf-8 -*-
# HM-05 · V3 — lỗi ở luồng nghiệp vụ không bị nuốt âm thầm: giả lập lỗi thật trên app, kiểm có thông báo + app vẫn chạy.
# Dữ liệu thử ẩn danh 3 mốc (kiem_thu_p03/tao_mis80_thu.py). Chạy từ app/QLTDPRO_P43/:
#   python3 kiem_thu_p04/test_hm05_bao_loi.py [app/QLTDPRO_v24.17.24.html]
import asyncio, functools, http.server, threading, sys, tempfile, subprocess, re
from pathlib import Path
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.24.html'
PORT = 8853; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:400]), flush=True)
def skip(n, why): print('SKIP ' + n + ' — ' + why, flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
TMP = Path(tempfile.mkdtemp()) / 'm'
subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(TMP)], check=True, stdout=subprocess.DEVNULL)
FILES = sorted(TMP.iterdir(), key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
TOAST = "(document.getElementById('gd9-toasts')||{}).innerText||''"

async def run(pw):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': 1366, 'height': 800})
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in FILES]); await pg.wait_for_timeout(3000)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(8000)
    await pg.goto(URL + '#/khach-hang-moi', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    # H1 — mốc giữa kỳ đọc lỗi
    co = await pg.evaluate("!!(window.__gd11Api&&window.__gd11Api.loadMidSnaps)")
    ok('H1a loadMidSnaps có trong __gd11Api (chỉ đọc)', co)
    if co:
        r0 = await pg.evaluate("""(async()=>{const A=window.__gd11Api,all=A.arcList(),by=d=>all.find(m=>m.dayKey===d);
            const r=await A.loadMidSnaps(by('30/09/2026'),by('31/10/2026'),all);return [r.rows.length,r.days,r.loi]})()""")
        t0 = await pg.evaluate(TOAST)
        ok('H1b bình thường: đọc đủ mốc giữa kỳ, không báo lỗi', r0[1] >= 1 and r0[2] == [] and 'Không đọc được' not in t0, (r0, t0))
        r1 = await pg.evaluate("""(async()=>{const A=window.__gd11Api,all=A.arcList(),by=d=>all.find(m=>m.dayKey===d),mid=by('15/10/2026');
            const key='rpt_'+mid.timestamp,o=IDBObjectStore.prototype.get;
            IDBObjectStore.prototype.get=function(k){if(String(k)===key)throw new Error('giả lập lỗi đọc IndexedDB');return o.call(this,k)};
            try{const r=await A.loadMidSnaps(by('30/09/2026'),by('31/10/2026'),all);return [r.rows.length,r.days,r.loi]}finally{IDBObjectStore.prototype.get=o}})()""")
        await pg.wait_for_timeout(300); t1 = await pg.evaluate(TOAST)
        ok('H1c mốc 15/10 đọc lỗi → trả về danh sách lỗi + thông báo "Không đọc được mốc Lưu trữ 15/10/2026"', r1[2] == ['2026-10-15'] and 'Không đọc được mốc Lưu trữ 15/10/2026' in t1, (r1, t1))
    # H2 — Máy tính lãi đọc Lưu trữ lỗi
    await pg.evaluate("document.querySelectorAll('#gd9-toasts > *').forEach(x=>x.remove())")
    await pg.goto(URL + '#/lai-dong', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.evaluate("(()=>{window.__gd11Api.loadArcRows=()=>Promise.reject(new Error('giả lập Lưu trữ lỗi'))})()")
    await pg.click('[data-testid=gd14-calc]'); await pg.wait_for_timeout(400)
    await pg.fill('[data-testid=gd14-calc-search]', 'a'); await pg.wait_for_timeout(200)
    await pg.fill('[data-testid=gd14-calc-search]', await pg.evaluate("(window.GD14.calc.rows[0]||[])[1]||'Khách'")); await pg.wait_for_timeout(400)
    await pg.locator('[data-testid=gd14-calc-hit]').first.click(); await pg.wait_for_timeout(1200)
    t2 = await pg.evaluate(TOAST); tl = await pg.locator('[data-testid=gd14-calc-tonglai]').inner_text()
    ok('H2 Lưu trữ lỗi → thông báo "Không đọc được N mốc Lưu trữ … lãi theo đoạn", máy tính vẫn ra tổng lãi', re.search(r'Không đọc được \d+ mốc Lưu trữ', t2) and 'lãi theo đoạn' in t2 and re.search(r'\d', tl), (t2, tl))
    await pg.click('[data-testid=gd14-calc-x]')
    # H3 — khung Phương án SXKD: lưu lỗi
    await pg.goto(URL + '#/ho-so-vay-hop-nhat', wait_until='domcontentloaded'); await pg.wait_for_timeout(2000)
    fr = None
    for t in ['Phương án', 'PHƯƠNG ÁN', 'PA SXKD']:
        b = pg.locator('main button, main [role=tab], main a', has_text=t)
        if await b.count():
            try: await b.first.click(timeout=2000); await pg.wait_for_timeout(1500)
            except Exception: pass
        if await pg.locator('main iframe').count(): fr = pg.locator('main iframe').first; break
    if fr is None: skip('H3 khung Phương án SXKD', 'không mở được khung PA (iframe) từ trang Hồ sơ vay với dữ liệu thử — vá đã có, kiểm tĩnh')
    else:
        await pg.evaluate("""(()=>{const f=document.querySelector('main iframe');const w=f.contentWindow;w.saveData=function(){throw new Error('giả lập lưu lỗi')}})()""")
        await pg.evaluate("""(()=>{const d=document.querySelector('main iframe').contentDocument;const i=d.querySelector('input');if(i){i.value=i.value+'1';i.dispatchEvent(new Event('input',{bubbles:true}))}})()""")
        await pg.wait_for_timeout(1500); t3 = await pg.evaluate(TOAST)
        ok('H3 Phương án SXKD tự lưu lỗi → thông báo "Không tự lưu được phương án"', 'Không tự lưu được phương án SXKD' in t3, t3)
    ok('E1 0 pageerror', not errs, errs[:4])
    await br.close()

async def main():
    async with async_playwright() as pw: await run(pw)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
