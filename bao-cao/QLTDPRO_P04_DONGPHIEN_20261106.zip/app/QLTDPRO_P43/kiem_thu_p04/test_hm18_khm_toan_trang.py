# P04 · HM-18 — V3 (Playwright Chromium): trang Khách hàng mới TOÀN TRANG.
# Số liệu: thẻ KPI (Doanh số cho vay, Thu nợ, Dư nợ đầu/cuối), bảng Tổng hợp (GN theo phòng/cán bộ), biểu đồ phòng = bảng Đối soát
#   = công cụ Python độc lập doi_chieu_mis80 (0 đồng); KPI bấm → chi tiết; tệp chọn tay → nhãn "suy ra".
# Giao diện: 5 tab × 1366/390: không tràn ngang, chữ ≥ 11px, nút ≥ 28px (điện thoại ≥ 40px); ảnh toàn trang (cuộn khung chính).
# Dùng (từ app/QLTDPRO_P43/):  python3 kiem_thu_p04/test_hm18_khm_toan_trang.py [app/QLTDPRO_v24.17.16.html]
# Dữ liệu THẬT (chỉ thư mục tạm): MIS_DIR=<dd.mm.yyyy.xls(x)> TS_FILE=<TSBĐ> EVD=<tạm> python3 kiem_thu_p04/test_hm18_khm_toan_trang.py <app>
import asyncio, functools, http.server, threading, sys, json, re, subprocess, tempfile, shutil, os
from pathlib import Path
from playwright.async_api import async_playwright
ROOT = Path(__file__).resolve().parent.parent
APP = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / 'app' / 'QLTDPRO_v24.17.16.html'
EVD = Path(os.environ.get('EVD', tempfile.mkdtemp(prefix='hm18_ev_'))); EVD.mkdir(parents=True, exist_ok=True)
PORT = 8869
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
httpd = http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(APP.parent)))
threading.Thread(target=httpd.serve_forever, daemon=True).start()
URL = f'http://127.0.0.1:{PORT}/{APP.name}'
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:700]))
TMP = Path(tempfile.mkdtemp(prefix='hm18_')); DL = TMP / 'mis'; PY = sys.executable
if os.environ.get('MIS_DIR'):
    DL.mkdir(parents=True)
    for f in Path(os.environ['MIS_DIR']).iterdir():
        if f.is_file() and re.match(r'\d\d\.\d\d\.\d{4}\.(xlsx|XLS)$', f.name): shutil.copy(f, DL / f.name)
else:
    subprocess.run([PY, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(DL)], check=True, stdout=subprocess.DEVNULL)
subprocess.run([PY, '-I', str(ROOT / 'kiem_thu_p02/doc_mis80.py'), str(DL), str(TMP / 'm.pkl')], check=True, stdout=subprocess.DEVNULL)
subprocess.run([PY, '-I', str(ROOT / 'kiem_thu_p02/doi_chieu_mis80.py'), str(TMP / 'm.pkl'), str(ROOT / 'nguon_P02/qltd_dstn.cjs'), str(TMP / 'dc')], check=True, capture_output=True)
KJ = json.load(open(TMP / 'dc' / 'chuoi_moc_ra.json', encoding='utf-8'))   # công cụ: đã khớp Python độc lập từng khế ước (HM-11a/HM-12 C0)
TT = {k: round(sum(z[k] for z in KJ['khe'])) for k in ('dauKy', 'gn', 'thu', 'cuoiKy')}
up = lambda s: str(s or '').strip().upper()
GNP = {}; GNC = {}
for z in KJ['khe']:
    GNP[up(z['phong'])] = GNP.get(up(z['phong']), 0) + z['gn']; kk = (up(z['phong']), up(z['cbTen'] or z['cbMa'])); GNC[kk] = GNC.get(kk, 0) + z['gn']
F = sorted([f for f in DL.iterdir() if re.match(r'\d\d\.\d\d\.\d{4}\.(xlsx|XLS)$', f.name)], key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
TS = Path(os.environ.get('TS_FILE') or ROOT / 'app/kiem_thu_p40/xlsx/18_08_2026-TS.xlsx')
VN = lambda f: f.name[:10].replace('.', '/')
ISO = lambda f: f.name[6:10] + '-' + f.name[3:5] + '-' + f.name[:2]
TABS = ['tongquan', 'tonghop', 'chitiet', 'tsbd', 'doisoat']
DO = """(nho)=>{const root=document.querySelector('main')||document.body,vw=innerWidth;const vis=e=>e.offsetParent&&e.getBoundingClientRect().width>0;
 const chu=[...root.querySelectorAll('*')].filter(e=>vis(e)&&[...e.childNodes].some(n=>n.nodeType==3&&n.textContent.trim())&&parseFloat(getComputedStyle(e).fontSize)<11).map(e=>e.tagName+'.'+String(e.className).slice(0,40)+':'+e.textContent.trim().slice(0,15));
 const nut=[...root.querySelectorAll('button,select,input:not([type=checkbox]):not([type=radio]):not([type=file])')].filter(e=>vis(e)&&e.getBoundingClientRect().height<nho).map(e=>(e.dataset.testid||e.tagName+'.'+String(e.className).slice(0,30))+' h='+Math.round(e.getBoundingClientRect().height));
 return {tran:document.documentElement.scrollWidth-vw,chu:chu,nut:nut}}"""
async def anh_toan_trang(pg, ten):
    """Cuộn khung cuộn chính của trang (không phải cửa sổ) và chụp từng đoạn → ảnh toàn trang theo đoạn."""
    hm = await pg.evaluate("(()=>{document.querySelectorAll('[data-ks18]').forEach(e=>e.removeAttribute('data-ks18'));const c=[...document.querySelectorAll('main,main *,body *')].filter(e=>e.scrollHeight>e.clientHeight+20&&/auto|scroll/.test(getComputedStyle(e).overflowY)&&e.clientHeight>300);const m=c.sort((a,b)=>b.clientHeight*b.clientWidth-a.clientHeight*a.clientWidth)[0]||document.scrollingElement;m.setAttribute('data-ks18','1');m.scrollTop=0;return [m.scrollHeight,m.clientHeight]})()")
    n = 0
    for i in range(0, 8):
        await pg.evaluate(f"(()=>{{const m=document.querySelector('[data-ks18]')||document.scrollingElement;m.scrollTop={i}*m.clientHeight*0.92}})()"); await pg.wait_for_timeout(250)
        await pg.screenshot(path=str(EVD / f'{ten}_{i}.png')); n += 1
        if (i + 1) * hm[1] * 0.92 >= hm[0] - hm[1]: break
    await pg.evaluate("(()=>{const m=document.querySelector('[data-ks18]');if(m)m.scrollTop=0})()")
    return n
async def trang(p, vp, mobile=False):
    b = await p.chromium.launch(); c = await b.new_context(viewport=vp, locale='vi-VN', is_mobile=mobile, has_touch=mobile)
    await c.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await c.new_page(); pg.errs = []
    pg.on('pageerror', lambda e: pg.errs.append('pageerror: ' + str(e)))
    pg.on('console', lambda m: m.type == 'error' and pg.errs.append('console.error: ' + m.text))
    return b, pg
async def nhap(pg, files):
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in files]); await pg.wait_for_timeout(3000)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(3000 + 1500 * len(files))
async def lap(pg):
    await pg.goto(URL + '#/khach-hang-moi', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    for sel, d in (('khm-arch-dau', VN(F[0])), ('khm-arch-cuoi', VN(F[-1]))):
        s = pg.locator(f'[data-testid="{sel}"]'); lab = [t for t in await s.locator('option').all_inner_texts() if d in t][0]; await s.select_option(label=lab)
    await pg.locator('[data-testid="khm-arch-load"]').click(); await pg.wait_for_timeout(2500)
    await pg.locator('[data-testid="khm-go"]').click(); await pg.wait_for_selector('[data-testid="khm-tab-doisoat-btn"]', timeout=30000)
    await pg.wait_for_timeout(2500)
KPI = "Object.fromEntries([...document.querySelectorAll('[data-testid=khm-kpi]')].map(c=>[c.children[0].textContent.trim(),{v:c.children[1].textContent,s:c.children[2].textContent,dv:c.dataset.v,k:c.dataset.hm18}]))"
num = lambda t: int(re.sub(r'[^\d]', '', t) or 0)
async def main():
    async with async_playwright() as p:
        for ten, vp, mob, nho in (('desktop', {'width': 1366, 'height': 768}, False, 28), ('dt390', {'width': 390, 'height': 844}, True, 40)):
            b, pg = await trang(p, vp, mob)
            await nhap(pg, F + [TS]); await lap(pg)
            K = await pg.evaluate(KPI)
            if ten == 'desktop':
                ok('A1 KPI Doanh số cho vay = công cụ (GN món mới + GN thêm, Q11), 0 đồng', num(K['Doanh số cho vay']['v']) == TT['gn'], (K['Doanh số cho vay'], TT['gn']))
                ok('A2 KPI Thu nợ = công cụ (giảm dư nợ gốc từng khế ước), 0 đồng', num(K['Thu nợ (kỳ này)']['v']) == TT['thu'], (K['Thu nợ (kỳ này)'], TT['thu']))
                ok('A3 KPI Dư nợ đầu/cuối = công cụ', num(K['Dư nợ đầu kỳ']['v']) == TT['dauKy'] and num(K['Dư nợ cuối kỳ']['v']) == TT['cuoiKy'], (K, TT))
                ok('A4 KPI ghi rõ cách tính (món mới + GN thêm; theo khế ước)', 'GN thêm' in K['Doanh số cho vay']['s'] and 'khế ước' in K['Thu nợ (kỳ này)']['s'], K)
                # biểu đồ phòng
                bars = await pg.evaluate("[...document.querySelectorAll('[data-testid=khm-bars] > div')].filter(r=>r.children.length>=3).map(r=>[r.children[0].textContent.trim(),+r.dataset.gn,r.children[1].children[0].style.width])")
                ok('A5 biểu đồ GN theo phòng = công cụ từng phòng', bars and all(round(v) == round(GNP.get(up(n), 0)) for n, v, _ in bars), (bars, GNP))
                bt = await pg.evaluate("[...document.querySelectorAll('[data-testid=khm-bars] > div')].filter(r=>r.children.length>=3).map(r=>r.children[2].textContent)")
                ok('A5b nhãn số biểu đồ đúng dạng "x,xx · y" (không lặp dấu)', bt and all(re.fullmatch(r'[\d.]+,\d\d · \d+', t.strip()) for t in bt), bt)
                # Tổng hợp
                await pg.locator('[data-testid="khm-tab-tonghop-btn"]').first.click(); await pg.wait_for_timeout(900)
                TH = await pg.evaluate("[...document.querySelectorAll('[data-testid=khm-t-tonghop] tr[data-kind]')].map(r=>[r.dataset.kind,r.querySelector('td').textContent.trim(),+r.dataset.gn,r.querySelectorAll('td')[2].textContent])")
                lech, ph = [], ''
                for kind, lab, gn, _ in TH:
                    if kind == 'phong': ph = up(re.sub(r'^\s*[IVXLC]+\.\s*', '', lab)); e = GNP.get(ph, 0)
                    elif kind == 'cb': e = GNC.get((ph, up(re.sub(r'^\s*\d+\.\s*', '', lab))), 0)
                    else: e = TT['gn']
                    if round(gn) != round(e): lech.append((kind, lab, gn, e))
                ok(f'A6 Tổng hợp: GN mọi dòng phòng/cán bộ/tổng ({len(TH)} dòng) = công cụ 0 đồng', TH and not lech, lech[:5])
                thieu = await pg.locator('[data-testid="khm-gd16-tonghop"]').get_attribute('data-thieu')
                scb = sum(gn for k, _, gn, _ in TH if k == 'cb')
                ok('A7 Tổng hợp: Σ cán bộ = tổng (hoặc có cảnh báo cán bộ thiếu dòng)', round(scb) == TT['gn'] or thieu != '0', (scb, TT['gn'], thieu))
                for u, f in (('trieu', lambda v: f'{round(v / 1e6):,}'.replace(',', '.')), ('ty', lambda v: f'{v / 1e9:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.'))):
                    await pg.locator(f'[data-testid="khm-unit-{u}"]').first.click(); await pg.wait_for_timeout(500)
                    t = await pg.evaluate("document.querySelector('[data-testid=khm-t-tonghop] tr[data-kind=tong]').querySelectorAll('td')[2].textContent")
                    ok(f'A8 đơn vị {u}: ô tổng GN hiển thị đúng ({f(TT["gn"])})', t == f(TT['gn']), t)
                await pg.locator('[data-testid="khm-unit-dong"]').first.click()
                # Chi tiết: ghi chú nguồn
                await pg.locator('[data-testid="khm-tab-chitiet-btn"]').first.click(); await pg.wait_for_timeout(700)
                nt = await pg.locator('[data-testid="khm-gd16-chitiet"]').inner_text()
                ok('A9 tab Chi tiết nêu nguồn danh sách + doanh số theo khế ước', 'GN thêm' in nt and f'{TT["gn"]:,}'.replace(',', '.') in nt, nt)
                # KPI bấm → Đối soát + chi tiết
                await pg.locator('[data-testid="khm-tab-tongquan-btn"]').first.click(); await pg.wait_for_timeout(500)
                await pg.locator('[data-testid="khm-kpi"][data-hm18="thu"]').click()
                await pg.wait_for_selector('[data-testid="khm-dstn-ct"][data-k="thu"][data-sc="tong"]', timeout=20000)
                kt = pg.locator('[data-testid="khm-dstn-ct-kt"]')
                ok('A10 bấm KPI Thu nợ → tab Đối soát mở chi tiết, Σ khế ước = KPI', int(await kt.get_attribute('data-tong')) == TT['thu'], await kt.inner_text())
                T = await pg.evaluate("Object.fromEntries([...document.querySelectorAll('[data-testid=khm-dstn-tong] td[data-k]')].map(t=>[t.dataset.k,+t.dataset.v]))")
                ok('A11 KPI = dòng Tổng cộng bảng Đối soát (GN, thu, đầu, cuối)', all(T[k] == TT[k] for k in TT), (T, TT))
                await pg.locator('[data-testid="khm-dstn-ct-dong"]').click()
            # đo DOM + ảnh toàn trang từng tab
            lo = {}
            for i, t in enumerate(TABS):
                await pg.locator(f'[data-testid="khm-tab-{t}-btn"]').first.click(); await pg.wait_for_timeout(1500 if t == 'doisoat' else 700)
                d = await pg.evaluate(DO, nho); lo[t] = d
                await anh_toan_trang(pg, f'hm18_{ten}_{i+1}_{t}')
            ok(f'B1 {ten}: 5 tab không tràn ngang trang', all(lo[t]['tran'] <= 1 for t in TABS), {t: lo[t]['tran'] for t in TABS})
            ok(f'B2 {ten}: 0 chữ < 11px ở 5 tab', all(not lo[t]['chu'] for t in TABS), {t: lo[t]['chu'][:4] for t in TABS if lo[t]['chu']})
            ok(f'B3 {ten}: 0 nút/ô chọn < {nho}px ở 5 tab', all(not lo[t]['nut'] for t in TABS), {t: lo[t]['nut'][:6] for t in TABS if lo[t]['nut']})
            ok(f'B4 {ten}: 0 pageerror/console.error', not pg.errs, pg.errs[:3])
            await b.close()
        # ---- C: tệp chọn tay → giữ số bundle, ghi nhãn "suy ra" ----
        b, pg = await trang(p, {'width': 1366, 'height': 768})
        await pg.goto(URL + '#/khach-hang-moi', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
        await pg.set_input_files('input[data-testid="khm-multi"]', [str(F[0]), str(F[-1]), str(TS)]); await pg.wait_for_timeout(2500)
        await pg.locator('input[data-testid="khm-from"]').fill(ISO(F[0])); await pg.locator('input[data-testid="khm-to"]').fill(ISO(F[-1]))
        await pg.locator('[data-testid="khm-go"]').click(); await pg.wait_for_timeout(3500)
        K = await pg.evaluate(KPI)
        ok('C1 tệp chọn tay: KPI Thu nợ ghi "suy ra", không gắn số lõi', 'suy ra' in K['Thu nợ (kỳ này)']['s'] and not K['Thu nợ (kỳ này)']['k'], K['Thu nợ (kỳ này)'])
        ok('C2 không pageerror', not pg.errs, pg.errs[:3])
        await b.close()
    shutil.rmtree(TMP, ignore_errors=True)
    print(f'\n{sum(res)}/{len(res)} PASS · ảnh: {EVD}'); sys.exit(0 if all(res) else 1)
asyncio.run(main())
