# HM-14 · kiểm lõi QLTDLai.hm14 (nguon_P04/qltd_lai_hm14.cjs) — Python tính ĐỘC LẬP (Fraction, tròn nửa-lên)
# so với Node chạy lõi. Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p04/test_hm14_loi.py
import json, subprocess, sys, os, random
from fractions import Fraction as Fr
from datetime import date, timedelta
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)

def d(s): y, m, dd = map(int, s.split('-')); return date(y, m, dd)
def rnd(x): return int((x + Fr(1, 2)).__floor__())
def lai(duno, ls, n, he=1): return rnd(Fr(duno) * Fr(str(ls)) / 100 * he * n / 365)
def doan_py(duno, ls, tu, den, mat):
    """một đoạn: trong hạn [tu, min(mat,den)), quá hạn [max(mat,tu), den) — LS cơ bản + phạt 50%"""
    tu, den = d(tu), d(den); n = (den - tu).days
    if mat is None: th = n
    else:
        m = d(mat); th = 0 if m <= tu else min(n, (m - tu).days)
    qh = n - th
    return dict(laiTH=lai(duno, ls, th) if th else 0, laiQHCB=lai(duno, ls, qh) if qh else 0,
                laiQHPhat=lai(duno, ls, qh, Fr(1, 2)) if qh else 0, soNgayTH=th, soNgayQH=qh)
def tong(parts):
    o = dict(laiTH=0, laiQHCB=0, laiQHPhat=0, soNgayTH=0, soNgayQH=0)
    for p in parts:
        for k in o: o[k] += p[k]
    o['tong'] = o['laiTH'] + o['laiQHCB'] + o['laiQHPhat']; return o

def row(duno, ls, moc, gn, mat, loai='Vay ngắn hạn (TK 211)', nxt='', intamt=0, lst=''):
    r = [''] * 27
    r[0] = '3201'; r[1] = 'KH thử'; r[2] = 'HD1'; r[6] = gn; r[7] = mat; r[8] = str(ls); r[10] = intamt
    r[11] = duno; r[13] = loai; r[20] = 'GN1'; r[23] = moc; r[25] = nxt; r[26] = lst
    return r

cases = []
def add(ten, fn, args, kv): cases.append(dict(ten=ten, fn=fn, args=args, kv=kv))

# A. Đồng nhất: ngắn hạn, không đoạn → tinhLaiTheoDoan == tinhLaiKhoan (200 khoản ngẫu nhiên, có quá hạn)
random.seed(14)
for i in range(200):
    gn = date(2025, 1, 1) + timedelta(days=random.randint(0, 500)); moc = gn + timedelta(days=random.randint(0, 120))
    mat = gn + timedelta(days=random.randint(60, 400)); chot = moc + timedelta(days=random.randint(0, 300))
    loai = random.choice(['Vay ngắn hạn (TK 211)', 'Thấu chi trên TK khách hàng', 'Vay ngắn hạn (TK 211)'])
    r = row(random.randint(1, 3000) * 1000000, random.choice([6.5, 7.2, 8.1, 8.8, 9.5, '8,5']), moc.isoformat(), gn.isoformat(), mat.isoformat(), loai)
    add('A%03d' % i, 'dongnhat', [r, {'chot': chot.isoformat()}], None)

# B. Q12 trung hạn: đã thu lãi đến 22/10/2026, kỳ trả lãi (nxtrpmtschddt) 22/11/2026 chưa trả, chốt 03/02/2027, gốc đến hạn 2028
r = row(1000000000, 8.8, '2026-10-22', '2025-10-22', '2028-10-22', 'Vay trung hạn (TK 212)', '2026-11-22')
kv = tong([doan_py(1000000000, 8.8, '2026-10-22', '2027-02-03', '2026-11-22')]); kv['q12'] = '2026-11-22'
add('B1 trung hạn Q12 theo nxtrpmtschddt', 'q12', [r, {'chot': '2027-02-03'}], kv)
# B2 cùng dữ liệu nhưng NGẮN hạn → không Q12, toàn trong hạn
r2 = list(r); r2[13] = 'Vay ngắn hạn (TK 211)'; r2[7] = '2027-06-30'
kv = tong([doan_py(1000000000, 8.8, '2026-10-22', '2027-02-03', '2027-06-30')]); kv['q12'] = None
add('B2 ngắn hạn: không lãi chậm trả, không Q12', 'q12', [r2, {'chot': '2027-02-03'}], kv)
# B3 dài hạn, chưa tới kỳ trả lãi → như cũ
r3 = list(r); r3[13] = 'Vay dài hạn (TK 213)'
kv = tong([doan_py(1000000000, 8.8, '2026-10-22', '2026-11-20', '2028-10-22')]); kv['q12'] = None
add('B3 dài hạn chưa tới kỳ', 'q12', [r3, {'chot': '2026-11-20'}], kv)
# B4 trung hạn không có lịch, người dùng chọn kỳ 3 tháng: 31/01/2026 + 1 tháng = 28/02/2026 (cuối tháng)
r4 = row(500000000, 9.5, '2026-01-31', '2025-01-31', '2029-01-31', 'Vay trung hạn (TK 212)')
kv = tong([doan_py(500000000, 9.5, '2026-01-31', '2026-04-15', '2026-02-28')]); kv['q12'] = '2026-02-28'
add('B4 kỳ 1 tháng, cuối tháng', 'q12', [r4, {'chot': '2026-04-15', 'kyLaiThang': 1}], kv)
# B5 trung hạn không lịch, không chọn kỳ → không áp Q12
kv = tong([doan_py(500000000, 9.5, '2026-01-31', '2026-04-15', '2029-01-31')]); kv['q12'] = None
add('B5 không lịch, không kỳ', 'q12', [r4, {'chot': '2026-04-15'}], kv)
# B6 kỳ trả lãi sau ngày đến hạn gốc → giữ quá hạn theo r[7]
r6 = row(200000000, 8.1, '2026-03-01', '2024-03-01', '2026-03-20', 'Vay trung hạn (TK 212)', '2026-04-01')
kv = tong([doan_py(200000000, 8.1, '2026-03-01', '2026-05-01', '2026-03-20')]); kv['q12'] = None
add('B6 kỳ lãi sau đến hạn gốc', 'q12', [r6, {'chot': '2026-05-01'}], kv)
# B7 phân loại theo thời hạn khi loại vay trống: 3 năm → trung hạn
r7 = row(300000000, 7.2, '2026-06-10', '2025-06-10', '2028-06-10', '', '2026-07-10')
kv = tong([doan_py(300000000, 7.2, '2026-06-10', '2026-08-01', '2026-07-10')]); kv['q12'] = '2026-07-10'
add('B7 loại vay trống → thời hạn 3 năm', 'q12', [r7, {'chot': '2026-08-01'}], kv)

# C. Lãi theo đoạn: dư nợ 1 tỷ từ 01/09, trả còn 600 tr ngày 15/09, còn 250 tr ngày 25/09, chốt 30/09 (trong hạn)
rc = row(250000000, 8.8, '2026-09-01', '2026-01-05', '2027-01-05')
doan = [{'tu': '2026-09-01', 'duno': 1000000000}, {'tu': '2026-09-15', 'duno': 600000000}, {'tu': '2026-09-25', 'duno': 250000000}]
kv = tong([doan_py(1000000000, 8.8, '2026-09-01', '2026-09-15', '2027-01-05'), doan_py(600000000, 8.8, '2026-09-15', '2026-09-25', '2027-01-05'),
           doan_py(250000000, 8.8, '2026-09-25', '2026-09-30', '2027-01-05')]); kv['soDoan'] = 3
add('C1 3 đoạn trong hạn', 'doan', [rc, {'chot': '2026-09-30'}, doan], kv)
# C2 đoạn cắt qua ngày đến hạn 20/09 (quá hạn từ 20/09)
rc2 = list(rc); rc2[7] = '2026-09-20'
kv = tong([doan_py(1000000000, 8.8, '2026-09-01', '2026-09-15', '2026-09-20'), doan_py(600000000, 8.8, '2026-09-15', '2026-09-25', '2026-09-20'),
           doan_py(250000000, 8.8, '2026-09-25', '2026-09-30', '2026-09-20')]); kv['soDoan'] = 3
add('C2 đoạn qua ngày đến hạn', 'doan', [rc2, {'chot': '2026-09-30'}, doan], kv)
# C3 trả hết rồi giải ngân lại? → đoạn dư nợ 0 không tính
doan3 = [{'tu': '2026-09-01', 'duno': 400000000}, {'tu': '2026-09-10', 'duno': 0}, {'tu': '2026-09-20', 'duno': 250000000}]
kv = tong([doan_py(400000000, 8.8, '2026-09-01', '2026-09-10', '2027-01-05'), doan_py(250000000, 8.8, '2026-09-20', '2026-09-30', '2027-01-05')]); kv['soDoan'] = 3
add('C3 đoạn dư nợ 0', 'doan', [rc, {'chot': '2026-09-30'}, doan3], kv)
# C4 một đoạn cùng dư nợ hiện tại → y hệt tinhLaiKhoan
add('C4 một đoạn = cũ', 'dongnhat_doan', [rc, {'chot': '2026-09-30'}, [{'tu': '2026-09-01', 'duno': 250000000}]], None)
# C5 trung hạn: đoạn + Q12 (kỳ lãi 01/10 theo lịch, chốt 20/10): kỳ xác định 1 lần theo mốc gốc
rc5 = row(250000000, 8.8, '2026-09-01', '2025-09-01', '2028-09-01', 'Vay trung hạn (TK 212)', '2026-10-01')
kv = tong([doan_py(1000000000, 8.8, '2026-09-01', '2026-09-15', '2026-10-01'), doan_py(600000000, 8.8, '2026-09-15', '2026-09-25', '2026-10-01'),
           doan_py(250000000, 8.8, '2026-09-25', '2026-10-20', '2026-10-01')]); kv['soDoan'] = 3
add('C5 đoạn + Q12', 'doan', [rc5, {'chot': '2026-10-20'}, doan], kv)
# C6 trung hạn, kỳ 1 tháng do người dùng chọn — kỳ KHÔNG dời theo đầu đoạn
kv = tong([doan_py(1000000000, 8.8, '2026-09-01', '2026-09-15', '2026-10-01'), doan_py(600000000, 8.8, '2026-09-15', '2026-09-25', '2026-10-01'),
           doan_py(250000000, 8.8, '2026-09-25', '2026-10-20', '2026-10-01')]); kv['soDoan'] = 3
rc6 = list(rc5); rc6[25] = ''
add('C6 đoạn + kỳ 1 tháng', 'doan', [rc6, {'chot': '2026-10-20', 'kyLaiThang': 1}, doan], kv)

# D. lichSuDuNo từ mốc Lưu trữ
snaps = [{'ngay': '2026-08-31', 'duno': 1000000000, 'lst': ''}, {'ngay': '2026-09-30', 'duno': 600000000, 'lst': '2026-09-15'},
         {'ngay': '2026-10-31', 'duno': 600000000, 'lst': '2026-09-15'}]
add('D1 có lstrpmtdt', 'lichsu', [snaps, '2026-09-01', '2026-11-05', {'ngay': '2026-11-03', 'duno': 250000000, 'lst': '2026-11-02'}],
    [{'tu': '2026-09-01', 'duno': 1000000000}, {'tu': '2026-09-15', 'duno': 600000000}, {'tu': '2026-11-02', 'duno': 250000000}])
snaps2 = [{'ngay': '2026-08-31', 'duno': 1000000000, 'lst': ''}, {'ngay': '2026-09-30', 'duno': 600000000, 'lst': ''}]
add('D2 không ngày trả → ngày mốc (ước tính)', 'lichsu', [snaps2, '2026-09-01', '2026-10-20', None],
    [{'tu': '2026-09-01', 'duno': 1000000000}, {'tu': '2026-09-30', 'duno': 600000000}])
add('D3 không đổi dư nợ → 1 đoạn', 'lichsu', [[{'ngay': '2026-08-31', 'duno': 5e8, 'lst': ''}, {'ngay': '2026-09-30', 'duno': 5e8, 'lst': ''}], '2026-09-01', '2026-10-20', None],
    [{'tu': '2026-09-01', 'duno': 500000000}])
add('D4 không có mốc nào', 'lichsu', [[], '2026-09-01', '2026-10-20', None], [])

# E. Đối chiếu IPCAS
re1 = row(1000000000, 8.8, '2026-10-22', '2026-05-06', '2027-10-04', intamt=lai(1000000000, 8.8, 12))
add('E1 khớp 0 đồng', 'ipcas', [re1, {'chot': '2026-11-03'}], {'coSo': True, 'chenh': 0})
re2 = list(re1); re2[10] = 0
add('E2 intamt = 0', 'ipcas', [re2, {'chot': '2026-11-03'}], {'coSo': False})
re3 = list(re1); re3[10] = lai(1000000000, 8.8, 11)
add('E3 lệch 1 ngày', 'ipcas', [re3, {'chot': '2026-11-03'}], {'coSo': True, 'chenh': lai(1000000000, 8.8, 12) - lai(1000000000, 8.8, 11), 'chua': '1 ngày'})

# F. Cảnh báo ngày chốt
add('F1 chốt trước ngày dữ liệu', 'chot', ['2026-10-30', '2026-11-03'], {'n': 1, 'chua': 'TRƯỚC'})
add('F2 chốt cách 60 ngày', 'chot', ['2027-01-02', '2026-11-03'], {'n': 1, 'chua': '60 ngày'})
add('F3 bình thường', 'chot', ['2026-11-20', '2026-11-03'], {'n': 0})
add('F4 chưa có ngày dữ liệu', 'chot', ['2026-11-20', None], {'n': 1, 'chua': 'Chưa xác định'})

# G. Trả lời 05/11: Q15b (không mặc định, cảnh báo thiếu lịch), Q7 (thử mốc đến hạn)
rg = row(1000000000, 8.8, '2026-10-22', '2025-10-22', '2028-10-22', 'Vay trung hạn (TK 212)', '2026-11-22', intamt=lai(1000000000, 8.8, 31))
add('G1 Q7: intamt = lãi đến ngày đến hạn kỳ → khớp ứng viên', 'ipcas_uv', [rg, {'chot': '2026-11-03'}, '2026-11-22'], {'khop': '2026-11-22', 'chenh': lai(1000000000, 8.8, 12) - lai(1000000000, 8.8, 31)})
rg2 = list(rg); rg2[10] = 123
add('G2 Q7: không ứng viên nào khớp → khop null', 'ipcas_uv', [rg2, {'chot': '2026-11-03'}, '2026-11-22'], {'khop': None})
rh = row(500000000, 9.5, '2026-01-31', '2025-01-31', '2029-01-31', 'Vay trung hạn (TK 212)')
add('G3 Q15b: trung hạn thiếu lịch → cảnh báo, không áp Q12', 'canhbao', [rh, {'chot': '2026-04-15'}], {'chua': 'thiếu lịch trả nợ', 'q12': None})
add('G4 Q15b: chọn kỳ tay → không cảnh báo thiếu lịch', 'canhbao', [rh, {'chot': '2026-04-15', 'kyLaiThang': 1}], {'khong': 'thiếu lịch trả nợ', 'q12': '2026-02-28'})
rn = row(500000000, 9.5, '2026-01-31', '2026-01-31', '2026-12-31')
add('G5 ngắn hạn: không cảnh báo thiếu lịch', 'canhbao', [rn, {'chot': '2026-04-15'}], {'khong': 'thiếu lịch', 'q12': None})

JS = r'''
const L = require(process.argv[1]); const H = require(process.argv[2]);
const cases = JSON.parse(require('fs').readFileSync(0, 'utf8'));
const P = t => Date.parse(t + 'T00:00:00Z');
const pick = k => k && k.ok ? {laiTH:k.laiTH,laiQHCB:k.laiQHCB,laiQHPhat:k.laiQHPhat,soNgayTH:k.soNgayTH,soNgayQH:k.soNgayQH,tong:k.tong} : {ok:false, lyDo:k&&k.lyDo};
const out = cases.map(c => { const a = c.args; let v;
  if (c.fn === 'dongnhat') v = {cu: pick(L.tinhLaiKhoan(a[0], a[1])), moi: pick(H.tinhLaiTheoDoan(a[0], a[1])), q: pick(H.tinhLaiQ12(a[0], a[1]))};
  else if (c.fn === 'dongnhat_doan') v = {cu: pick(L.tinhLaiKhoan(a[0], a[1])), moi: pick(H.tinhLaiTheoDoan(a[0], Object.assign({}, a[1], {doan: a[2].map(x => ({tu: P(x.tu), duno: x.duno}))})))};
  else if (c.fn === 'q12') { const k = H.tinhLaiQ12(a[0], a[1]); v = Object.assign(pick(k), {q12: k.q12 ? k.q12.ngay : null}); }
  else if (c.fn === 'doan') { const k = H.tinhLaiTheoDoan(a[0], Object.assign({}, a[1], {doan: a[2].map(x => ({tu: P(x.tu), duno: x.duno}))})); v = Object.assign(pick(k), {soDoan: k.doan ? k.doan.length : 0}); }
  else if (c.fn === 'lichsu') { const x = H.lichSuDuNo(a[0], P(a[1]), P(a[2]), a[3]); v = x.doan.map(z => ({tu: new Date(z.tu).toISOString().slice(0, 10), duno: z.duno})); }
  else if (c.fn === 'ipcas') { const kd = H.tinhLaiTheoDoan(a[0], a[1]); v = H.doiChieuIPCAS(a[0], kd); }
  else if (c.fn === 'chot') v = H.canhBaoNgayChot(a[0], a[1]);
  else if (c.fn === 'ipcas_uv') { const kd = H.tinhLaiTheoDoan(a[0], a[1]); const uv = [{nhan: 'ngày đến hạn kỳ', ngay: a[2], k: H.tinhLaiTheoDoan(a[0], Object.assign({}, a[1], {chot: a[2]}))}]; const x = H.doiChieuIPCAS(a[0], kd, uv); v = {khop: x.khop ? x.khop.ngay : null, chenh: x.chenh, lyDo: x.lyDo}; }
  else if (c.fn === 'canhbao') { const k = H.tinhLaiQ12(a[0], a[1]); v = {cb: k.canhBao.join(' | '), q12: k.q12 ? k.q12.ngay : null}; }
  return v; });
process.stdout.write(JSON.stringify(out));
'''
p = subprocess.run(['node', '-e', JS, os.path.join(ROOT, 'nguon_P41/qltd_lai.cjs'), os.path.join(ROOT, 'nguon_P04/qltd_lai_hm14.cjs')],
                   input=json.dumps(cases), capture_output=True, text=True)
if p.returncode: print(p.stderr); sys.exit(2)
res = json.loads(p.stdout); ok = fail = 0
for c, v in zip(cases, res):
    f, kv = c['fn'], c['kv']
    if f in ('dongnhat', 'dongnhat_doan'): good = v['cu'] == v['moi'] and (f == 'dongnhat_doan' or v['cu'] == v['q'])
    elif f in ('q12', 'doan'): good = all(v.get(k) == kv[k] for k in kv)
    elif f == 'lichsu': good = v == kv
    elif f == 'ipcas': good = v['coSo'] == kv['coSo'] and ('chenh' not in kv or v['chenh'] == kv['chenh']) and ('chua' not in kv or kv['chua'] in v['lyDo'])
    elif f == 'ipcas_uv': good = v['khop'] == kv['khop'] and ('chenh' not in kv or v['chenh'] == kv['chenh'])
    elif f == 'canhbao': good = v['q12'] == kv['q12'] and ('chua' not in kv or kv['chua'] in v['cb']) and ('khong' not in kv or kv['khong'] not in v['cb'])
    elif f == 'chot': good = len(v) == kv['n'] and ('chua' not in kv or kv['chua'] in ' '.join(v))
    if good: ok += 1; print('PASS', c['ten'])
    else: fail += 1; print('FAIL', c['ten'], json.dumps(v, ensure_ascii=False)[:400], '\n   kỳ vọng', json.dumps(kv, ensure_ascii=False)[:300])
nA = sum(1 for c in cases if c['fn'] == 'dongnhat')
print('Đồng nhất tinhLaiKhoan (A, %d khoản ngẫu nhiên) + %d ca Q12/đoạn/lịch sử/IPCAS/ngày chốt' % (nA, len(cases) - nA))
print('KẾT QUẢ: %d PASS · %d FAIL' % (ok, fail)); sys.exit(1 if fail else 0)
