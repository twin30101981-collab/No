# P04 · HM-12 — V3 (Playwright Chromium): trang Khách hàng mới → tab Đối soát → bấm từng ô số (Tổng / Phòng / Cán bộ)
# → bảng chi tiết khế ước: tổng chi tiết = ô đã bấm (0 đồng); danh sách khế ước = công cụ Python độc lập doi_chieu_mis80;
# lọc Phòng/Cán bộ; xuất Excel 4 sheet + Excel chi tiết (cột Kiểm tra = 0); desktop 1366 + điện thoại 390, 0 pageerror.
# Dùng (từ app/QLTDPRO_P43/; cần pandas, openpyxl, xlrd, node):
#   python3 kiem_thu_p04/test_hm12_chi_tiet.py [app/QLTDPRO_v24.17.15.html]
# Dữ liệu THẬT (chỉ thư mục tạm, KHÔNG lưu log/ảnh/Excel vào repo/ZIP):
#   MIS_DIR=<thư mục dd.mm.yyyy.xls(x)> TS_FILE=<sao kê TSBĐ> EVD=<thư mục tạm> python3 kiem_thu_p04/test_hm12_chi_tiet.py <app>
import asyncio, functools, http.server, threading, sys, json, re, subprocess, tempfile, shutil, os
from pathlib import Path
from playwright.async_api import async_playwright
import pandas as pd
ROOT = Path(__file__).resolve().parent.parent
APP = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / 'app' / 'QLTDPRO_v24.17.15.html'
EVD = Path(os.environ.get('EVD', tempfile.mkdtemp(prefix='hm12_ev_'))); EVD.mkdir(parents=True, exist_ok=True)
PORT = 8864
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
httpd = http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(APP.parent)))
threading.Thread(target=httpd.serve_forever, daemon=True).start()
URL = f'http://127.0.0.1:{PORT}/{APP.name}'
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:700]))

TMP = Path(tempfile.mkdtemp(prefix='hm12_')); DL = TMP / 'mis'; PY = sys.executable
MIS_DIR = os.environ.get('MIS_DIR')
if MIS_DIR:
    DL.mkdir(parents=True)
    for f in Path(MIS_DIR).iterdir():
        if f.is_file() and re.match(r'\d\d\.\d\d\.\d{4}\.(xlsx|XLS)$', f.name): shutil.copy(f, DL / f.name)
else:
    subprocess.run([PY, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(DL)], check=True)
subprocess.run([PY, '-I', str(ROOT / 'kiem_thu_p02/doc_mis80.py'), str(DL), str(TMP / 'm.pkl')], check=True, stdout=subprocess.DEVNULL)
dc = subprocess.run([PY, '-I', str(ROOT / 'kiem_thu_p02/doi_chieu_mis80.py'), str(TMP / 'm.pkl'), str(ROOT / 'nguon_P02/qltd_dstn.cjs'), str(TMP / 'dc')], check=True, capture_output=True, text=True).stdout
ok('C0 công cụ doi_chieu: Python độc lập = lõi 1.1.0 (kỳ cuối, chuỗi mốc, 2 mốc)', len(re.findall(r'lệch 0 \| Cán bộ lệch 0/\d+ · Phòng lệch 0/\d+', dc)) == 3, re.findall(r'Khế ước:.*', dc))
F = sorted([f for f in DL.iterdir() if re.match(r'\d\d\.\d\d\.\d{4}\.(xlsx|XLS)$', f.name)], key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
X = pd.read_excel(next((TMP / 'dc').glob(f'DOI_SOAT_DSTN_CHUOI_{len(F)}MOC_*.xlsx')), sheet_name=None, dtype={'Mã CB': str, 'Số khế ước': str, 'Mã KH': str})
# Chuẩn đối chiếu chi tiết: đầu ra JSON ĐẦY ĐỦ khế ước của công cụ (C0 đã khớp Python độc lập từng khế ước).
# Sheet "Chi tiết khế ước" của công cụ chỉ giữ khế ước có biến động → không dùng để so ô Dư nợ đầu/cuối.
# Lưu trữ không lưu ofcno → mã CB trong app = tên cán bộ (như HM-11b) → so theo (Phòng, tên cán bộ).
KJ = json.load(open(TMP / 'dc' / 'chuoi_moc_ra.json', encoding='utf-8'))['khe']
TS = Path(os.environ.get('TS_FILE') or ROOT / 'app/kiem_thu_p40/xlsx/18_08_2026-TS.xlsx')
VN = lambda f: f.name[:10].replace('.', '/')
COT_TOOL = {'dauKy': 'Dư nợ đầu kỳ', 'gn': 'Doanh số GN', 'gnMon': 'Số món GN', 'thu': 'Thu nợ gốc', 'dieuChinh': 'Điều chỉnh', 'cuoiKy': 'Dư nợ cuối kỳ'}

async def trang(p, vp, mobile=False):
    b = await p.chromium.launch()
    c = await b.new_context(viewport=vp, locale='vi-VN', is_mobile=mobile, has_touch=mobile, accept_downloads=True)
    await c.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await c.new_page(); pg.errs = []
    pg.on('pageerror', lambda e: pg.errs.append('pageerror: ' + str(e)))
    pg.on('console', lambda m: m.type == 'error' and pg.errs.append('console.error: ' + m.text))
    pg.on('requestfailed', lambda r: (not r.url.startswith('blob:')) and pg.errs.append('requestfailed: ' + r.url))
    return b, pg
async def nhap(pg, files):
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in files]); await pg.wait_for_timeout(3000)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(3000 + 1500 * len(files))
async def doi_soat(pg, dau, cuoi):
    await pg.goto(URL + '#/khach-hang-moi', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    for sel, d in (('khm-arch-dau', dau), ('khm-arch-cuoi', cuoi)):
        s = pg.locator(f'[data-testid="{sel}"]'); lab = [t for t in await s.locator('option').all_inner_texts() if d in t][0]
        await s.select_option(label=lab)
    await pg.locator('[data-testid="khm-arch-load"]').click(); await pg.wait_for_timeout(2500)
    await pg.locator('[data-testid="khm-go"]').click()
    await pg.wait_for_selector('[data-testid="khm-tab-doisoat-btn"]', timeout=30000)
    await pg.locator('[data-testid="khm-tab-doisoat-btn"]').first.click()
    await pg.wait_for_selector('[data-testid="khm-dstn-t"]', timeout=60000); await pg.wait_for_timeout(500)

# bấm MỌI ô bấm được qua sự kiện click thật (dispatchEvent → bộ xử lý của bảng), đọc dòng kiểm của bảng chi tiết
QUET = """()=>{const out=[];const tds=[...document.querySelectorAll('[data-testid="khm-dstn-t"] td.gd15-ck')];
  for(const td of tds){td.dispatchEvent(new MouseEvent('click',{bubbles:true}));const kt=document.querySelector('[data-testid="khm-dstn-ct-kt"]');
    const tr=td.parentNode;out.push({sc:tr.dataset.sc,phong:tr.dataset.phong||'',cbma:tr.dataset.cbma||'',cb:tr.dataset.cb||'',k:td.dataset.k,o:+td.dataset.v,
      tong:kt?+kt.dataset.tong:null,n:kt?+kt.dataset.n:null,ftong:+(document.querySelector('[data-testid="khm-dstn-ct-tong"]')||{dataset:{v:NaN}}).dataset.v})}
  return {out:out,nClick:tds.length}}"""
DS_CT = """()=>{const t=document.querySelector('[data-testid="khm-dstn-ct-t"]');const H=[...t.querySelectorAll('thead th')].map(x=>x.textContent);
  return [...t.querySelectorAll('tbody tr')].map(tr=>{const c=[...tr.children].map(x=>x.textContent);const o={};H.forEach((h,i)=>o[h]=c[i]);o.v=+tr.dataset.v;return o})}"""
async def mo_het(pg):
    while await pg.locator('[data-testid="khm-dstn-ct-them"]').is_visible(): await pg.locator('[data-testid="khm-dstn-ct-them"]').click()
async def bam_o(pg, sc, k, phong=None, cbma=None):
    q = f'[data-testid="khm-dstn-t"] tr[data-sc="{sc}"]' + (f'[data-phong="{phong}"]' if phong is not None else '') + (f'[data-cbma="{cbma}"]' if cbma is not None else '')
    await pg.locator(q + f' td[data-k="{k}"]').first.click(); await pg.wait_for_selector('[data-testid="khm-dstn-ct"]')

async def main():
    async with async_playwright() as p:
        b, pg = await trang(p, {'width': 1366, 'height': 900})
        await nhap(pg, F + [TS])
        await doi_soat(pg, VN(F[0]), VN(F[-1]))
        R = await pg.evaluate("({tong:window.__khmDstn.tong,n:window.__khmDstn.khe.length,lst:window.__khmDstn.khe.filter(z=>z.lstrpmtdt).length,cuoi:window.__khmDstn.khe.filter(z=>z.cuoiKy>0).length,nguon:(window.__khmDstn.nguon||[]).length,ver:window.GD15.PHIEN_BAN})")
        ok(f'A1 gd15 ≥ 1.2.0, {len(F)} mốc nguồn ghi nhận', re.match(r'P04-GD15 1\.[2-9]', R['ver'] or '') and R['nguon'] == len(F), R)
        kt3 = pg.locator('[data-testid="khm-dstn-kt3"]')
        n3 = await kt3.count()
        ok('A2 Tổng cán bộ = tổng phòng = tổng chi nhánh (mọi cột)', n3 and await kt3.get_attribute('data-lech') == '0', (await kt3.inner_text()) if n3 else 'không có dòng kiểm 3 cấp')
        Q1 = await pg.evaluate(QUET); o = Q1['out']
        if not Q1['nClick']:
            ok('A3 có ô số bấm được (bản trước HM-12 không có)', False, 'không có td.gd15-ck')
            await b.close(); shutil.rmtree(TMP, ignore_errors=True); print(f'\n{sum(res)}/{len(res)} PASS'); sys.exit(1)
        lech = [x for x in o if x['tong'] is None or round(x['tong']) != round(x['o']) or round(x['ftong']) != round(x['o'])]
        ok(f'A3 bấm {Q1["nClick"]} ô (tổng/phòng/cán bộ × 8 cột): tổng chi tiết = ô đã bấm, 0 đồng', Q1['nClick'] > 50 and not lech, lech[:5])
        ok('A4 có đủ 3 cấp và các cột GN/thu/đầu/cuối/số món/số KƯ/tất toán', {x['sc'] for x in o} == {'tong', 'phong', 'cb'} and {'gn', 'thu', 'dauKy', 'cuoiKy', 'gnMon', 'soKhe'} <= {x['k'] for x in o}, sorted({(x['sc'], x['k']) for x in o})[:30])
        # A5: đối chiếu độc lập — danh sách khế ước của ô cán bộ (thu, gn) = sheet Chi tiết khế ước của công cụ Python
        bad = []; n_ss = 0
        cbs = [x for x in o if x['sc'] == 'cb' and x['k'] in ('thu', 'gn', 'cuoiKy')]
        for x in cbs[:60]:
            await pg.evaluate(f"""()=>{{const td=document.querySelector('[data-testid="khm-dstn-t"] tr[data-sc="cb"][data-phong="{x['phong']}"][data-cbma="{x['cbma']}"] td[data-k="{x['k']}"]');td.dispatchEvent(new MouseEvent('click',{{bubbles:true}}))}}""")
            await mo_het(pg)
            rows = await pg.evaluate(DS_CT)
            app = {r['Số khế ước']: r['v'] for r in rows}
            tool = {z['dsbsseq']: round(z[x['k']]) for z in KJ if z['phong'] == x['phong'] and z['cbTen'] == x['cb'] and z[x['k']] != 0}
            n_ss += 1
            if app != tool: bad.append((x['phong'], x['cbma'], x['k'], len(app), len(tool), sorted(set(app) ^ set(tool))[:4]))
        ok(f'A5 {n_ss} ô cán bộ (thu/GN/cuối): danh sách khế ước + số tiền = công cụ Python độc lập', n_ss > 10 and not bad, bad[:4])
        # A6: bấm thật bằng chuột ô Thu nợ tổng; mọi dòng có cách đo + nguồn; chỉ hiện 300 rồi "Hiện thêm"
        await bam_o(pg, 'tong', 'thu')
        n0 = await pg.locator('[data-testid="khm-dstn-ct-row"]').count(); nt = int(await pg.locator('[data-testid="khm-dstn-ct-kt"]').get_attribute('data-n'))
        ok('A6 bảng chi tiết lớn hiện từng 300 dòng, có nút Hiện thêm', n0 == min(300, nt) and (nt <= 300 or await pg.locator('[data-testid="khm-dstn-ct-them"]').is_visible()), (n0, nt))
        await mo_het(pg); rows = await pg.evaluate(DS_CT)
        ok('A7 sau Hiện thêm: Σ dòng = ô Thu nợ tổng', len(rows) == nt and round(sum(r['v'] for r in rows)) == round(R['tong']['thu']), (len(rows), nt, sum(r['v'] for r in rows), R['tong']['thu']))
        ok('A8 mọi dòng ghi cách đo (theo cặp mốc) và nguồn mốc Lưu trữ', all(r['Cách đo (theo cặp mốc)'] and 'Lưu trữ: mốc' in r['Nguồn'] and '→' in r['Cách đo (theo cặp mốc)'] for r in rows), [r for r in rows if not r['Cách đo (theo cặp mốc)']][:2])
        ok('A9 ngày trả gần nhất (lstrpmtdt) có ở khế ước còn dư nợ', R['lst'] >= R['cuoi'] * 0.9, R)
        await pg.screenshot(path=str(EVD / 'hm12_desktop_chi_tiet.png'))
        # A10: bàn phím (Enter) trên ô cán bộ
        await pg.locator('[data-testid="khm-dstn-ct-dong"]').click()
        cell = pg.locator('[data-testid="khm-dstn-t"] tr[data-sc="cb"] td[data-k="gn"].gd15-ck').first
        await cell.focus(); await pg.keyboard.press('Enter'); await pg.wait_for_timeout(200)
        ok('A10 Enter trên ô số mở bảng chi tiết', await pg.locator('[data-testid="khm-dstn-ct"][data-k="gn"][data-sc="cb"]').count() == 1)
        # A11: lọc phòng / cán bộ
        ph = (await pg.locator('[data-testid="khm-dstn-phong"]').nth(1).get_attribute('data-phong'))
        await pg.locator('[data-testid="khm-dstn-loc-phong"]').select_option(ph)
        vis = await pg.evaluate("[...document.querySelectorAll('[data-testid=\"khm-dstn-phong\"],[data-testid=\"khm-dstn-cb\"]')].filter(t=>!t.hidden).map(t=>t.dataset.phong)")
        ok('A11 lọc phòng: chỉ còn dòng của phòng đã chọn', vis and all(v == ph for v in vis), (ph, set(vis)))
        opts = await pg.locator('[data-testid="khm-dstn-loc-cb"] option').evaluate_all("o=>o.map(x=>x.value)")
        await pg.locator('[data-testid="khm-dstn-loc-cb"]').select_option(opts[1])
        vis2 = await pg.evaluate("[...document.querySelectorAll('[data-testid=\"khm-dstn-cb\"]')].filter(t=>!t.hidden).map(t=>t.dataset.phong+'\\u0001'+t.dataset.cbma)")
        ok('A12 lọc cán bộ: còn đúng 1 dòng cán bộ', vis2 == [opts[1]], (opts[1], vis2))
        await pg.locator('[data-testid="khm-dstn-loc-phong"]').select_option('')
        # A13: Excel đối soát 4 sheet
        async with pg.expect_download() as di: await pg.locator('[data-testid="khm-dstn-xlsx"]').click()
        d = await di.value; fx = TMP / d.suggested_filename; await d.save_as(fx)
        W = pd.read_excel(fx, sheet_name=None, dtype={'Mã CB': str, 'Số khế ước': str})
        ok('A13 Excel mở được, đủ 4 sheet', list(W) == ['Phòng', 'Cán bộ', 'Chi tiết khế ước', 'Ghi chú'], list(W))
        P_app = W['Phòng'].set_index('Phòng'); P_tool = X['Phòng'].set_index('Phòng')
        cols = ['Dư nợ đầu kỳ', 'Doanh số GN', 'Số món GN', 'Thu nợ gốc', 'Điều chỉnh', 'Dư nợ cuối kỳ', 'Kiểm tra (=0)']
        lp = [(i, c, P_app.loc[i, c], P_tool.loc[i, c]) for i in P_tool.index for c in cols if i not in P_app.index or round(P_app.loc[i, c]) != round(P_tool.loc[i, c])]
        ok('A14 sheet Phòng = công cụ Python 0 đồng', not lp and len(P_app) == len(P_tool), lp[:5])
        C_app = W['Cán bộ'].fillna({'Cán bộ': ''}).set_index(['Phòng', 'Cán bộ']); C_tool = X['Cán bộ'].fillna({'Cán bộ': ''}).set_index(['Phòng', 'Cán bộ'])
        lc = [(i, c) for i in C_tool.index for c in cols if i not in C_app.index or round(C_app.loc[i, c]) != round(C_tool.loc[i, c])]
        ok(f'A15 sheet Cán bộ = công cụ Python 0 đồng ({len(C_tool)} cán bộ)', not lc and len(C_app) == len(C_tool), lc[:5])
        K = W['Chi tiết khế ước']; body = K.iloc[:-1]; tot = K.iloc[-1]
        ok(f'A16 sheet Chi tiết: {R["n"]} khế ước, cột Kiểm tra = 0 mọi dòng + dòng tổng', len(body) == R['n'] and (body['Kiểm tra (=0)'].round() == 0).all() and round(tot['Kiểm tra (=0)']) == 0, (len(body), R['n']))
        ok('A17 sheet Chi tiết: Σ cột = tổng chi nhánh (đầu/GN/thu/ĐC/cuối)', all(round(body[COT_TOOL[k]].sum()) == round(R['tong'][k]) == round(tot[COT_TOOL[k]]) for k in ('dauKy', 'gn', 'thu', 'dieuChinh', 'cuoiKy')))
        st = set(map(str, body['Số khế ước'])); stt = {z['dsbsseq'] for z in KJ}
        ok('A18 sheet Chi tiết: cùng tập khế ước với công cụ Python', st == stt, (len(st), len(stt), sorted(st ^ stt)[:4]))
        g = ' '.join(map(str, W['Ghi chú'].iloc[:, 0]))
        ok('A19 sheet Ghi chú nêu kỳ, mốc nguồn, quy tắc Q4–Q6', all(t in g for t in ('Kỳ:', 'mốc Lưu trữ', 'Q5', 'Q6', 'lstrpmtdt')), g[:300])
        # A20: Excel chi tiết của ô đang mở (cán bộ, GN)
        x = next(z for z in o if z['sc'] == 'cb' and z['k'] == 'thu' and z['n'] > 2)
        await bam_o(pg, 'cb', 'thu', x['phong'], x['cbma'])
        async with pg.expect_download() as di: await pg.locator('[data-testid="khm-dstn-ct-xlsx"]').click()
        d = await di.value; fy = TMP / d.suggested_filename; await d.save_as(fy)
        Y = pd.read_excel(fy, sheet_name=None, dtype={'Số khế ước': str}); y = Y['Chi tiết']
        ok('A20 Excel chi tiết: Σ "Giá trị ô" = ô đã bấm, số dòng = bảng, Kiểm tra = 0', list(Y) == ['Chi tiết', 'Ghi chú'] and len(y) - 1 == x['n'] and round(y.iloc[-1]['Giá trị ô (Thu nợ)']) == round(x['o']) == round(y.iloc[:-1]['Giá trị ô (Thu nợ)'].sum()) and (y['Kiểm tra (=0)'].round() == 0).all(), (len(y), x))
        ov = await pg.evaluate("document.documentElement.scrollWidth-window.innerWidth")
        ok('A21 desktop 1366: trang không tràn ngang', ov <= 1, ov)
        ok('A22 không pageerror/console.error/request lỗi', not pg.errs, pg.errs)
        await b.close()
        # ---- B: điện thoại 390 ----
        b, pg = await trang(p, {'width': 390, 'height': 844}, mobile=True)
        await nhap(pg, F + [TS]); await doi_soat(pg, VN(F[0]), VN(F[-1]))
        await pg.locator('[data-testid="khm-dstn-t"] tr[data-sc="tong"] td[data-k="gn"]').tap(); await pg.wait_for_selector('[data-testid="khm-dstn-ct"]')
        kt = pg.locator('[data-testid="khm-dstn-ct-kt"]')
        ok('B1 điện thoại: chạm ô GN tổng → chi tiết, tổng = ô', await kt.get_attribute('data-tong') == await kt.get_attribute('data-o'), await kt.inner_text())
        ov = await pg.evaluate("document.documentElement.scrollWidth-window.innerWidth")
        ok('B2 điện thoại: trang không tràn ngang khi mở chi tiết', ov <= 1, ov)
        sc = await pg.evaluate("(()=>{const w=document.querySelector('.gd15-ct-wrap');const r=document.querySelector('[data-testid=\"khm-dstn-ct\"]').getBoundingClientRect();return [w.scrollWidth>w.clientWidth,getComputedStyle(w).overflowX,r.right<=innerWidth+1]})()")
        ok('B3 điện thoại: bảng chi tiết cuộn ngang trong khung, khung nằm trong màn hình', sc[0] and sc[1] == 'auto' and sc[2], sc)
        bw = await pg.evaluate("[...document.querySelectorAll('[data-testid=\"khm-dstn-loc\"] select,[data-testid=\"khm-dstn-loc\"] button,[data-testid=\"khm-dstn-ct\"] .gd15-ct-h button')].map(e=>{const r=e.getBoundingClientRect();return [r.right<=innerWidth+1,r.height>=28]})")
        ok('B4 điện thoại: nút/ô chọn trong màn hình, cao ≥ 28px', bw and all(a and h for a, h in bw), bw)
        await pg.locator('[data-testid="khm-dstn"]').screenshot(path=str(EVD / 'hm12_dien_thoai.png'))
        ok('B5 không pageerror/console.error/request lỗi', not pg.errs, pg.errs)
        await b.close()
    shutil.rmtree(TMP, ignore_errors=True)
    print(f'\n{sum(res)}/{len(res)} PASS · ảnh: {EVD}'); sys.exit(0 if all(res) else 1)
asyncio.run(main())
