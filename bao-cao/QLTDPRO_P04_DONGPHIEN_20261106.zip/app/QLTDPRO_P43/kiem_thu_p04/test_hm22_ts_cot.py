# -*- coding: utf-8 -*-
# HM-22 · V3 — Trang Tài sản bảo đảm: cột Số HĐ thế chấp (plgno), Số giải ngân (khế ước còn dư nợ, ghép msit80), Địa chỉ TS.
# Dữ liệu thử ẩn danh: 3 mốc msit80 (tao_mis80_thu) + tệp TSBĐ sinh từ tệp 31/10 (đáp án tính độc lập bằng Python).
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p04/test_hm22_ts_cot.py [app/QLTDPRO_v24.17.25.html]
import asyncio, functools, http.server, threading, sys, tempfile, subprocess, collections, re
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.25.html'
PORT = 8857; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm22'
if not EV.parent.exists(): EV = HERE / 'hm22'
(EV / 'anh').mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:500]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
TMP = Path(tempfile.mkdtemp()) / 'm'
subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(TMP)], check=True, stdout=subprocess.DEVNULL)
FILES = sorted(TMP.iterdir(), key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
ws = openpyxl.load_workbook(FILES[-1], read_only=True).active; rows = list(ws.iter_rows(values_only=True)); H = rows[0]
ib, iseq, ibal, inm = H.index('brcd'), H.index('dsbsseq'), H.index('dsbsbal'), H.index('custnm')
gn = collections.defaultdict(list); ten = {}
for r in rows[1:]:
    if (r[ibal] or 0) > 0 and r[iseq]: gn[str(r[ib]).strip()].append(str(r[iseq]).strip()); ten[str(r[ib]).strip()] = r[inm]
nhieu = [k for k, v in gn.items() if len(v) >= 2][:6]; mot = [k for k, v in gn.items() if len(v) == 1][:1]
TSH = ['clno', 'clcustno', 'clcustnm', 'cltpcd', 'cldtltpcd', 'clqtysz', 'clunittpcd', 'clloc', 'clamt', 'plgno', 'plgdt', 'plgtpcd', 'exprdt', 'avblamtrt', 'plgamt', 'plgcustno', 'plgcustnm', 'clccycd', 'clholdcd', 'ntydt', 'rem', 'lnofcnm', 'trctcd', 'name_2']
CASE = {}  # số TS → (kiểu ghép, danh sách GN kỳ vọng, số HĐTC, địa chỉ)
def tsrow(i, kh, chu, kieu, exp):
    so = f'TSX{i:02d}'; hd = f'LCA3201{20260000 + i}'; dc = f'{i} Ngõ Thử {i}, Phường Thử'
    CASE[so] = (kieu, sorted(exp), hd, dc)
    return [so, chu, 'Chủ TS ' + str(i), 'Đất ở', 'Thổ cư', '100', 'm2', dc, 1_000_000_000 + i, hd, '01/03/2026', 'TC', '01/03/2028', '70', 700_000_000, kh, ten.get(kh, f'Khách mới {i}'), 'VND', 'N', '01/03/2026', '', 'CÁN BỘ THỬ', 'Hội Sở', f'GCN{i:03d}']
TS = [tsrow(i + 1, k, k, 'ma', gn[k]) for i, k in enumerate(nhieu)]
TS.append(tsrow(20, 'KHACH-KHONG-CO-0001', mot[0], 'chu', gn[mot[0]]))       # mã KH lạ, mã chủ TS khớp → ghép theo chủ
TS += [tsrow(30 + j, f'3201NEW{j:06d}', f'3201NEW{j:06d}', 'kct', []) for j in range(3)]  # khách chưa có trong dư nợ
TSF = Path(tempfile.mkdtemp()) / '31_10_2026-TS.xlsx'
wb = openpyxl.Workbook(); w = wb.active; w.append(TSH); [w.append(r) for r in TS]; wb.save(TSF)

async def run(pw):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': 1366, 'height': 900}, locale='vi-VN')
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in FILES] + [str(TSF)]); await pg.wait_for_timeout(3500)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(9000)
    await pg.goto(URL + '#/tai-san-bao-dam', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    hd = await pg.evaluate("[...document.querySelectorAll('[data-testid=page-tai-san-bao-dam] [role=columnheader], [data-testid=page-tai-san-bao-dam] .sticky.top-0 > div.flex:first-child > div')].map(x=>x.textContent.trim())")
    txt = ' | '.join(hd)
    ok('T1 cột mặc định có Số HĐ thế chấp, Số giải ngân, Địa chỉ TS', all(k in txt for k in ['Số HĐ thế chấp', 'Số giải ngân', 'Địa chỉ TS']), txt[:400])
    got = await pg.evaluate("""()=>{const o={};document.querySelectorAll('[data-testid=page-tai-san-bao-dam] [data-testid=dt-row]').forEach(r=>{const g=c=>{const x=r.querySelector('[data-c='+c+']');return x?x.textContent.trim():null};
        const so=g('sots')||'';o[g('hdtc')||so]=[g('sogn'),g('hdtc'),g('dc'),g('tt')]});return o}""")
    sai = []
    for so, (kieu, exp, hdtc, dc) in CASE.items():
        v = got.get(hdtc)
        if not v: sai.append((so, 'không thấy dòng')); continue
        g = sorted(x.strip() for x in (v[0] or '').split(',') if x.strip())
        if g != exp or v[1] != hdtc or v[2] != dc: sai.append((so, kieu, g, exp, v))
    ok(f'T2 {len(CASE)} tài sản: Số giải ngân = khế ước còn dư nợ của KH (Python, theo mã KH / mã chủ TS / không có), Số HĐ thế chấp, Địa chỉ TS đúng', not sai, sai[:3])
    ok('T3 tài sản của khách chưa có trong dư nợ: Số giải ngân trống, trạng thái "Không có hồ sơ trong DATA"', all((got.get(CASE[s][2]) or [None, None, None, ''])[3] == 'Không có hồ sơ trong DATA' for s in CASE if CASE[s][0] == 'kct'))
    thu_tu = await pg.evaluate("[...document.querySelector('[data-testid=page-tai-san-bao-dam] [data-testid=dt-row]').children].filter(c=>c.getBoundingClientRect().width>2).map(c=>c.getAttribute('data-c'))")
    print('THỨ TỰ CỘT:', thu_tu)
    ok('T1b thứ tự: Số HĐ thế chấp, Số giải ngân, Địa chỉ TS nằm ngay sau Mã KH', thu_tu[thu_tu.index('ma') + 1:thu_tu.index('ma') + 4] == ['hdtc', 'sogn', 'dc'] if 'ma' in thu_tu else False, thu_tu)
    await pg.screenshot(path=str(EV / 'anh' / 'desktop_ts.png'))
    if await pg.locator('[data-testid=page-tai-san-bao-dam] [data-testid=dt-den-gon]').count():
        await pg.click('[data-testid=page-tai-san-bao-dam] [data-testid=dt-den-gon]'); await pg.wait_for_timeout(500)
    k = await pg.evaluate("Object.keys(localStorage).find(k=>/tbl_tai-san-bao-dam$/.test(k))")
    if k:
        await pg.evaluate("k=>{const v=JSON.parse(localStorage.getItem(k));delete v.l22;v.hidden=v.hidden.concat(['hdtc','sogn','dc']);localStorage.setItem(k,JSON.stringify(v))}", k)
        await pg.reload(wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
        c2 = await pg.evaluate("!!document.querySelector('[data-testid=page-tai-san-bao-dam] [data-testid=dt-row] [data-c=sogn]')&&document.querySelector('[data-testid=page-tai-san-bao-dam] [data-testid=dt-row] [data-c=sogn]').getBoundingClientRect().width>2")
        ok('T4 bố cục cũ đã lưu (không cờ l22) → hiện cột mới một lần', c2)
    else: ok('T4 tìm khóa bố cục bảng TS', False, 'không thấy')
    ok('E1 0 pageerror', not errs, errs[:3])
    await br.close()

async def main():
    async with async_playwright() as pw: await run(pw)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
