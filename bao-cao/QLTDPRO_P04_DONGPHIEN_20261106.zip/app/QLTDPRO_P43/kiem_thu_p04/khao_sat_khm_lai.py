# P04 · Khảo sát điểm nghẽn (CHỈ ĐỌC, không sửa app) — trang Khách hàng mới (mọi tab) + Máy tính lãi (#/lai-dong, hộp công cụ).
# Chụp ảnh TOÀN TRANG desktop 1366 + điện thoại 390, đo: tràn ngang, số cột bảng, bảng rộng hơn khung, nút < 28/40px, chữ < 11px,
# pageerror. Dữ liệu thử ẩn danh (tao_mis80_thu.py). Dùng: python3 kiem_thu_p04/khao_sat_khm_lai.py <app.html> <thư mục ảnh>
import asyncio, functools, http.server, threading, sys, json, re, subprocess, tempfile
from pathlib import Path
from playwright.async_api import async_playwright
ROOT = Path(__file__).resolve().parent.parent
APP = Path(sys.argv[1]).resolve(); OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
PORT = 8866
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
httpd = http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(APP.parent)))
threading.Thread(target=httpd.serve_forever, daemon=True).start()
URL = f'http://127.0.0.1:{PORT}/{APP.name}'
TMP = Path(tempfile.mkdtemp(prefix='ks_')); DL = TMP / 'mis'
subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(DL)], check=True, stdout=subprocess.DEVNULL)
F = sorted(DL.iterdir(), key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2]); TS = ROOT / 'app/kiem_thu_p40/xlsx/18_08_2026-TS.xlsx'
DO = """(sel)=>{const root=document.querySelector(sel)||document.body;const vw=innerWidth;
 const tb=[...root.querySelectorAll('table')].filter(t=>t.offsetParent).map(t=>{const p=t.parentElement;return{id:t.dataset.testid||t.className.slice(0,30),cot:t.querySelector('tr')?t.querySelector('tr').children.length:0,
   dong:t.querySelectorAll('tbody tr').length,rong:Math.round(t.scrollWidth),khung:Math.round(p.clientWidth),cuon:getComputedStyle(p).overflowX}});
 const nho=[...root.querySelectorAll('button,select,input,a[role=button]')].filter(e=>e.offsetParent).filter(e=>{const r=e.getBoundingClientRect();return r.height>0&&r.height<(vw<500?40:28)}).length;
 const chu=[...root.querySelectorAll('td,th,span,div,label,button')].filter(e=>e.offsetParent&&e.childNodes.length&&[...e.childNodes].some(n=>n.nodeType==3&&n.textContent.trim())&&parseFloat(getComputedStyle(e).fontSize)<11).length;
 const tran=[...root.querySelectorAll('*')].filter(e=>e.offsetParent&&e.getBoundingClientRect().right>vw+1&&!e.closest('[style*=overflow],.overflow-auto,.overflow-x-auto,.gd15-wrap')).length;
 return{tranTrang:document.documentElement.scrollWidth-vw,caoTrang:document.documentElement.scrollHeight,bang:tb,nutNho:nho,chuNho:chu,phanTuVuotKhung:tran,
   soNut:root.querySelectorAll('button').length,soO:root.querySelectorAll('input,select').length}}"""
async def main():
    kq = {}
    async with async_playwright() as p:
        for ten, vp, mob in (('desktop', {'width': 1366, 'height': 768}, False), ('dt390', {'width': 390, 'height': 844}, True)):
            b = await p.chromium.launch(); c = await b.new_context(viewport=vp, locale='vi-VN', is_mobile=mob, has_touch=mob)
            await c.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
            pg = await c.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
            await pg.goto(URL + '#/nhap'); await pg.wait_for_timeout(1500)
            await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in F] + [str(TS)]); await pg.wait_for_timeout(3000)
            await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
            y = pg.locator('[data-testid="confirm-yes"]')
            if await y.count(): await y.click()
            await pg.wait_for_timeout(9000)
            # ---- Khách hàng mới ----
            await pg.goto(URL + '#/khach-hang-moi'); await pg.wait_for_timeout(2500)
            kq[ten + '_khm_truoc'] = await pg.evaluate(DO, 'main'); await pg.screenshot(path=str(OUT / f'khm_{ten}_0_chua_lap.png'), full_page=True)
            for sel, d in (('khm-arch-dau', F[0].name[:10].replace('.', '/')), ('khm-arch-cuoi', F[-1].name[:10].replace('.', '/'))):
                s = pg.locator(f'[data-testid="{sel}"]'); lab = [t for t in await s.locator('option').all_inner_texts() if d in t][0]; await s.select_option(label=lab)
            await pg.locator('[data-testid="khm-arch-load"]').click(); await pg.wait_for_timeout(2500)
            await pg.locator('[data-testid="khm-go"]').click(); await pg.wait_for_selector('[data-testid="khm-tab-doisoat-btn"]', timeout=30000)
            tabs = await pg.evaluate("[...document.querySelectorAll('[data-testid$=\"-btn\"][data-testid^=\"khm-tab-\"]')].filter(e=>e.offsetParent).map(e=>[e.dataset.testid,e.textContent.trim()])")
            kq[ten + '_khm_tabs'] = tabs
            for i, (tid, lab) in enumerate(tabs):
                await pg.locator(f'[data-testid="{tid}"]').first.click(); await pg.wait_for_timeout(2500 if 'doisoat' in tid else 900)
                kq[f'{ten}_khm_{tid}'] = await pg.evaluate(DO, 'main')
                await pg.screenshot(path=str(OUT / f'khm_{ten}_{i+1}_{tid.replace("khm-tab-","").replace("-btn","")}.png'), full_page=True)
            # ---- Chỉ tiêu kế hoạch (cuộn khung chính để chụp hết) ----
            await pg.goto(URL + '#/chi-tieu-ke-hoach'); await pg.wait_for_timeout(3000)
            kq[ten + '_ctkh'] = await pg.evaluate(DO, 'main')
            kq[ten + '_ctkh_tieude'] = await pg.evaluate("[...document.querySelectorAll('main table')].filter(t=>t.offsetParent).map(t=>[...(t.querySelector('thead tr:last-child')||t.querySelector('tr')).children].map(x=>x.textContent.trim()).join(' | ').slice(0,400))")
            await pg.screenshot(path=str(OUT / f'ctkh_{ten}_0.png'))
            hmain = await pg.evaluate("(()=>{const m=[...document.querySelectorAll('main,main *')].find(e=>e.scrollHeight>e.clientHeight+20&&/auto|scroll/.test(getComputedStyle(e).overflowY))||document.scrollingElement;m.setAttribute('data-ks','1');return [m.scrollHeight,m.clientHeight]})()")
            for i in range(1, min(6, hmain[0] // max(1, hmain[1]) + 2)):
                await pg.evaluate(f"(()=>{{const m=document.querySelector('[data-ks]');m.scrollTop={i}*m.clientHeight*0.9}})()"); await pg.wait_for_timeout(300)
                await pg.screenshot(path=str(OUT / f'ctkh_{ten}_{i}.png'))
            kq[ten + '_ctkh_cuon'] = hmain
            # ---- Máy tính lãi ----
            await pg.goto(URL + '#/lai-dong'); await pg.wait_for_timeout(3000)
            kq[ten + '_laidong'] = await pg.evaluate(DO, 'main'); await pg.screenshot(path=str(OUT / f'lai_{ten}_0_trang.png'), full_page=True)
            await pg.click('[data-testid="gd14-tool"]'); await pg.wait_for_timeout(800)
            kq[ten + '_tool_mo'] = await pg.evaluate(DO, '[data-testid="gd14-tool-overlay"]'); await pg.screenshot(path=str(OUT / f'lai_{ten}_1_cong_cu.png'), full_page=False)
            await pg.locator('[data-testid="gd14-tool-row"]').first.click(); await pg.wait_for_timeout(800)
            kq[ten + '_tool_kq'] = await pg.evaluate(DO, '[data-testid="gd14-tool-overlay"]')
            kq[ten + '_tool_text'] = (await pg.locator('[data-testid="gd14-tool-overlay"]').inner_text())[:1500]
            await pg.screenshot(path=str(OUT / f'lai_{ten}_2_ket_qua.png'), full_page=False)
            await pg.locator('[data-testid="gd14-tool-overlay"]').screenshot(path=str(OUT / f'lai_{ten}_3_hop_toan_bo.png'))
            kq[ten + '_errs'] = errs; await b.close()
    json.dump(kq, open(OUT / 'do_dac.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1); print('OK', OUT)
asyncio.run(main())
