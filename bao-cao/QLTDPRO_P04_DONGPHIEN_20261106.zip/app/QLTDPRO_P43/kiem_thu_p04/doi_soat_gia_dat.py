# Đối soát bảng giá đất trong app (hằng oS) với Phụ lục 02 — Bảng giá đất ở 8 phường TP Nam Định cũ
# (kèm Báo cáo tư vấn 275/2026/0019/VFI-BCCN.39.A ngày 16/03/2026). Chỉ đọc. Đơn vị: nghìn đồng/m².
# Chạy: python3 kiem_thu_p04/doi_soat_gia_dat.py <app.html> <PL02.docx> <ra.xlsx>
import sys, json, re, unicodedata, difflib
import docx, openpyxl
from openpyxl.styles import PatternFill, Font
APP, PL, OUT = sys.argv[1:4]
COT = [f'VT{v} {t}' for v in range(1, 5) for t in ('cao nhất', 'thấp nhất', 'trung bình')]

def app_rows(path):
    s = open(path, encoding='utf-8').read()
    i = s.index('const oS={') + len('const oS='); d = 0; q = esc = False
    for j in range(i, len(s)):
        c = s[j]
        if q:
            if esc: esc = False
            elif c == '\\': esc = True
            elif c == '"': q = False
            continue
        if c == '"': q = True
        elif c in '{[': d += 1
        elif c in '}]':
            d -= 1
            if d == 0: break
    return {ph: [[str(r[0]), r[1], r[2], r[3]] + [float(x) for x in r[4:16]] for r in rows] for ph, rows in json.loads(s[i:j + 1]).items()}

def so(t):
    t = t.strip().replace(' ', '')
    if not t or t in ('-', '–'): return 0.0
    t = t.replace('.', '').replace(',', '.')
    try: return float(t)
    except ValueError: return None

def pl_rows(path):
    d = docx.Document(path); body = d.element.body; out = {}; ph = None; ti = 0
    for el in body.iterchildren():
        tag = el.tag.split('}')[1]
        if tag == 'p':
            txt = ''.join(x.text or '' for x in el.iter() if x.tag.endswith('}t')).strip()
            m = re.match(r'^(Phường|Xã)\s+[^\s].{1,30}$', txt)
            if m and 'ĐƠN VỊ' not in txt.upper(): ph = txt
        elif tag == 'tbl':
            t = d.tables[ti]; ti += 1; rows = []
            for r in t.rows:
                c = [x.text.strip().replace('\n', ' ') for x in r.cells]
                if len(c) < 16 or not re.match(r'^\d+[a-zA-Z]?$', c[0]): continue
                nums = [so(x) for x in c[4:16]]
                rows.append([c[0], c[1], c[2], c[3]] + nums)
            out[ph or f'Bảng {ti}'] = rows
    return out

def chuan(s):
    s = unicodedata.normalize('NFC', str(s)).lower()
    s = re.sub(r'[\s\.,;:\-–()"“”]+', ' ', s).strip()
    return s
def khoa(r): return chuan(r[1]) + ' | ' + chuan(r[2]) + ' | ' + chuan(r[3])
def phkey(p): return chuan(p).replace('trương thi', 'trường thi')

A = app_rows(APP); P = pl_rows(PL)
pm = {phkey(p): p for p in P}
wb = openpyxl.Workbook(); th = wb.active; th.title = 'Tong_hop'
th.append(['Phường', 'Dòng app', 'Dòng PL02', 'Khớp hoàn toàn', 'Lệch giá', 'Lệch chữ (tên/đoạn)', 'Chỉ có trong app', 'Chỉ có trong PL02', 'Ô giá lệch'])
wl = wb.create_sheet('Lech_gia'); wl.append(['Phường', 'STT app', 'Tên đường', 'Từ', 'Đến', 'Cột', 'App', 'PL02', 'Chênh (PL02 − app)'])
wc = wb.create_sheet('Lech_chu'); wc.append(['Phường', 'STT', 'Trường', 'App', 'PL02'])
wa = wb.create_sheet('Chi_trong_app'); wa.append(['Phường', 'STT', 'Tên đường', 'Từ', 'Đến'] + COT)
wp = wb.create_sheet('Chi_trong_PL02'); wp.append(['Phân loại', 'Phường', 'STT', 'Tên đường', 'Từ', 'Đến'] + COT)
def loai(r):
    v = r[4:16]
    if any(x is None for x in v): return 'Chưa có giá (ghi "chưa hoàn thiện")'
    if all(x == 0 for x in v): return 'Dòng tiêu đề nhóm — giá ở các dòng con'
    return 'CÓ GIÁ — app thiếu'
wn = wb.create_sheet('Loi_so_PL02'); wn.append(['Phường', 'STT', 'Tên đường', 'Từ', 'Đến', 'Cột', 'Giá trị', 'Ghi chú'])
tong = dict(app=0, pl=0, khop=0, lechgia=0, lechchu=0, chiA=0, chiP=0, o=0)
for ph, ar in A.items():
    pr = P.get(pm.get(phkey(ph)), None)
    if pr is None:
        th.append([ph, len(ar), 0, 0, 0, 0, len(ar), 0, 0]); tong['app'] += len(ar); tong['chiA'] += len(ar)
        for r in ar: wa.append([ph] + r)
        continue
    # kiểm nội bộ PL02: TB = (cao + thấp)/2, cao ≥ thấp
    for r in pr:
        for v in range(4):
            hi, lo, tb = r[4 + 3 * v:7 + 3 * v]
            if None in (hi, lo, tb): wn.append([ph] + r[:4] + [f'VT{v+1}', '', 'ô không đọc được số'])
            elif hi < lo: wn.append([ph] + r[:4] + [f'VT{v+1}', f'{hi}/{lo}', 'cao nhất < thấp nhất'])
            elif abs((hi + lo) / 2 - tb) > 0.5: wn.append([ph] + r[:4] + [f'VT{v+1}', f'{hi}/{lo}/{tb}', 'trung bình ≠ (cao + thấp)/2'])
    sm = difflib.SequenceMatcher(None, [khoa(r) for r in ar], [khoa(r) for r in pr], autojunk=False)
    c = dict(khop=0, lechgia=0, lechchu=0, chiA=0, chiP=0, o=0)
    def cap(i, j, chu):
        a, p = ar[i], pr[j]; lech = [(k, a[4 + k], p[4 + k]) for k in range(12) if p[4 + k] is None or abs(a[4 + k] - p[4 + k]) > 1e-9]
        if chu:
            c['lechchu'] += 1
            for f, x, y in (('Tên đường', a[1], p[1]), ('Từ', a[2], p[2]), ('Đến', a[3], p[3])):
                if chuan(x) != chuan(y): wc.append([ph, a[0], f, x, y])
        if lech:
            c['lechgia'] += 1; c['o'] += len(lech)
            for k, x, y in lech: wl.append([ph, a[0], a[1], a[2], a[3], COT[k], x, y, None if y is None else y - x])
        elif not chu: c['khop'] += 1
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == 'equal':
            for k in range(i2 - i1): cap(i1 + k, j1 + k, False)
        elif op == 'replace' and (i2 - i1) == (j2 - j1):
            for k in range(i2 - i1): cap(i1 + k, j1 + k, True)
        else:
            for i in range(i1, i2): c['chiA'] += 1; wa.append([ph] + ar[i])
            for j in range(j1, j2): c['chiP'] += 1; wp.append([loai(pr[j]), ph] + pr[j]); tong.setdefault(loai(pr[j]), 0); tong[loai(pr[j])] += 1
    th.append([ph, len(ar), len(pr), c['khop'], c['lechgia'], c['lechchu'], c['chiA'], c['chiP'], c['o']])
    tong['app'] += len(ar); tong['pl'] += len(pr)
    for k in ('khop', 'lechgia', 'lechchu', 'chiA', 'chiP', 'o'): tong[k] += c[k]
for p in P:
    if phkey(p) not in {phkey(x) for x in A}:
        th.append([p, 0, len(P[p]), 0, 0, 0, 0, len(P[p]), 0]); tong['pl'] += len(P[p]); tong['chiP'] += len(P[p])
        for r in P[p]: wp.append([loai(r), p] + r)
th.append(['TỔNG', tong['app'], tong['pl'], tong['khop'], tong['lechgia'], tong['lechchu'], tong['chiA'], tong['chiP'], tong['o']])
th.append([]); th.append(['Nguồn app', APP]); th.append(['Nguồn PL02', PL]); th.append(['Đơn vị', 'nghìn đồng/m²'])
th.append(['Cách ghép', 'theo từng phường; khóa = tên đường | từ | đến (chuẩn hoá chữ thường, bỏ dấu câu); giữ thứ tự dòng (difflib); dòng cùng vị trí nhưng khác chữ → "Lệch chữ"'])
for ws in wb.worksheets:
    for cell in ws[1]: cell.font = Font(bold=True); cell.fill = PatternFill('solid', fgColor='DDEBF7')
    ws.freeze_panes = 'A2'
wb.save(OUT)
print(json.dumps(tong, ensure_ascii=False)); print('Phường PL02:', list(P.keys()))
print('Lỗi số nội bộ PL02:', wn.max_row - 1)
