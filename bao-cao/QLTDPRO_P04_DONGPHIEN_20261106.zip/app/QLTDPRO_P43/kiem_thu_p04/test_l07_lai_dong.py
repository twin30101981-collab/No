# -*- coding: utf-8 -*-
# L-07 · V3 — bảng trang Lãi đọng: 8 cột vừa 1366, lọc gom 1 nút, nút/ô ≥ 28/40 px, phân cấp theo ngày chậm lãi; + dòng giá đất 212.
# Dữ liệu thử ẩn danh tự sinh, nạp qua #/nhap. Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p04/test_l07_lai_dong.py [app/QLTDPRO_v24.17.20.html]
import asyncio, functools, http.server, threading, re, sys, tempfile, os, json
from datetime import date
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.20.html'
PORT = 8845; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence'; SHOT = (EV / 'l07' / 'anh') if EV.exists() else HERE / 'anh_l07'; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:400]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()

DL = date(2026, 11, 3)
# (tên, seq, dư nợ, đến hạn gốc, đã thu lãi đến, intamt)
LO = [('Khách Bảy A', 'A1', 300_000_000, '2027-05-01', '2026-10-14', 1_100_000),   # chậm 20 ngày → mức 1
      ('Khách Bảy B', 'B1', 500_000_000, '2027-05-01', '2026-09-04', 4_400_000),   # 60 ngày → mức 2
      ('Khách Bảy C', 'C1', 700_000_000, '2027-05-01', '2026-07-06', 12_000_000),  # 120 ngày → mức 3
      ('Khách Bảy D', 'D1', 200_000_000, '2026-10-15', '2026-09-15', 1_900_000)]   # gốc quá hạn (gd7 đỏ), 49 ngày → mức 2
def lv(s): n = (DL - date.fromisoformat(s)).days; return 0 if n <= 0 else 1 if n <= 30 else 2 if n <= 90 else 3
def us(s): return s[5:7] + '/' + s[8:10] + '/' + s[:4]
def vn(s): return s[8:10] + '/' + s[5:7] + '/' + s[:4]
def tao(p):
    wb = openpyxl.Workbook(); ws = wb.active
    ws.append(['brcd', 'custnm', 'apprseq', 'apprdt', 'apprmatdt', 'appramt', 'dsbsseq', 'dsbsdt', 'dsbsmatdt', 'sprd', 'dsbsamt', 'rpmtamt', 'intamt', 'dsbsbal',
               'ofcnm', 'lntpcd', 'addr1', 'commmn', 'fndprpstpcd', 'trctnm', 'aqccdfin', 'lstintchrgprd', 'nxtrpmtschddt', 'lstrpmtdt'])
    for i, x in enumerate(LO):
        ws.append(['3201', x[0], 'HD7-%d' % i, '01/05/2026', us(x[3]), x[2], x[1], '01/05/2026', us(x[3]), '8.5', x[2], 0, x[5], x[2],
                   'CÁN BỘ THỬ', '211', '7 Phố Thử', None, 'TD001', 'PGD Thử', 'Nhóm 1', us(x[4]), None, None])
    wb.save(p)
def num(s): v = re.sub(r'[^\d]', '', s or ''); return int(v) if v else 0
SMALL = """(lim)=>{const pg=document.querySelector('[data-testid=page-lai-dong]');return [...pg.querySelectorAll('button,select,input:not([type=checkbox])')]
  .filter(e=>!e.closest('[data-testid=dt-row]')&&!e.classList.contains('gd7-native')).filter(e=>{const r=e.getBoundingClientRect();return r.width>2&&r.height>2&&r.height<lim})
  .map(e=>(e.getAttribute('data-testid')||e.textContent||e.tagName).slice(0,16)+':'+Math.round(e.getBoundingClientRect().height))}"""

async def run(pw, name, vw, vh, fix):
    b = await pw.chromium.launch(); ctx = await b.new_context(viewport={'width': vw, 'height': vh})
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    T = lambda s: f'{name}: {s}'
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [fix]); await pg.wait_for_timeout(2500)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(4500)
    await pg.goto(URL + '#/lai-dong', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    rows = pg.locator('[data-testid=page-lai-dong] [data-testid=dt-row]')
    ok(T('T0 có 4 khoản lãi đọng'), await rows.count() == 4, await rows.count())
    cols = await rows.first.evaluate("r=>[...r.children].filter(c=>c.getBoundingClientRect().width>2).map(c=>c.getAttribute('data-c'))")
    ok(T('T1 mặc định 8 cột'), len(cols) == 8 and set(cols) == {'tenkh', 'cbtd', 'lai_den', 'cham', 'lai', 'lai_duthu', 'duno', 'thu'}, cols)
    if vw >= 1000:
        sc = await pg.evaluate("(()=>{let e=document.querySelector('[data-testid=page-lai-dong] [data-testid=dt-row]');while(e&&!/overflow-auto/.test(e.className))e=e.parentElement;return e?[e.scrollWidth,e.clientWidth]:null})()")
        ok(T('T2 không cuộn ngang ở 1366'), sc and sc[0] <= sc[1] + 1, sc)
    vis = "[...document.querySelectorAll('[data-testid=page-lai-dong] [data-testid=dt-filter]')].filter(e=>e.getBoundingClientRect().height>0).length"
    ok(T('T3 hàng lọc từng cột ẩn mặc định'), await pg.evaluate(vis) == 0)
    btn = pg.locator('[data-testid=gd19-loc-btn]')
    ok(T('T4 có nút "Lọc theo cột"'), await btn.count() == 1)
    await btn.click(); await pg.wait_for_timeout(200)
    ok(T('T5 bấm → hiện ô lọc của các cột đang xem'), await pg.evaluate(vis) == len(cols), await pg.evaluate(vis))
    f0 = pg.locator('[data-testid=page-lai-dong] [data-testid=dt-filter]').first
    await f0.fill('Bảy C'); await pg.wait_for_timeout(400)
    ok(T('T6 lọc hoạt động + nút ghi số bộ lọc (1)'), await rows.count() == 1 and '(1)' in await btn.inner_text(), (await rows.count(), await btn.inner_text()))
    await btn.click(); await pg.wait_for_timeout(200)
    ok(T('T7 đang có bộ lọc thì hàng lọc vẫn hiện (không giấu bộ lọc đang chạy)'), await pg.evaluate(vis) > 0)
    await f0.fill(''); await pg.wait_for_timeout(300); await btn.click(); await pg.wait_for_timeout(200)
    st = await btn.get_attribute('aria-pressed')
    if st == 'true': await btn.click(); await pg.wait_for_timeout(200)
    ok(T('T8 bỏ lọc + bấm lại → ẩn, đủ 4 dòng'), await pg.evaluate(vis) == 0 and await rows.count() == 4)
    got = await rows.evaluate_all("rs=>rs.map(r=>[r.querySelector('[data-c=lai_den]').innerText.trim(), (r.className.match(/gd19-l(\\d)/)||[])[1], r.className.includes('gd7-row-red'), getComputedStyle(r.querySelector('[data-c=tenkh]')).color])")
    exp = {vn(x[4]): str(lv(x[4])) for x in LO}
    ok(T('T9 phân cấp theo ngày chậm lãi (1–30 / 31–90 / > 90)'), all(exp.get(g[0]) == g[1] for g in got) and len(got) == 4, (got, exp))
    red = [g for g in got if g[2]]; norm = [g for g in got if not g[2]]
    ok(T('T10 dòng gốc quá hạn (gd7 đỏ) không còn tô chữ đỏ cả dòng'), red and norm and red[0][3] == norm[0][3], got)
    M = num(await pg.locator('[data-testid=page-lai-dong] [data-testid=tong]').inner_text())
    ok(T('T11 Σ lãi không đổi = Σ intamt'), M == sum(x[5] for x in LO), M)
    lim = 40 if vw < 600 else 28
    sm = await pg.evaluate(SMALL, lim)
    ok(T(f'T12 0 nút/ô < {lim} px ngoài dòng dữ liệu'), not sm, sm)
    await pg.screenshot(path=str(SHOT / f'{name}_01_lai_dong.png'))
    await pg.click('[data-testid=page-lai-dong] [data-testid=dt-cot-btn]'); await pg.wait_for_timeout(300)
    ok(T('T13 cột ẩn vẫn chọn được ở "Cột ▾" (Mã KH, Kỳ lãi kế tiếp)'), 'Kỳ lãi kế tiếp' in await pg.inner_text('body') and 'Mã KH' in await pg.inner_text('body'))
    await pg.keyboard.press('Escape')
    if vw >= 1000:  # bố cục cũ đã lưu (13 cột, không cờ l07) → áp bộ mặc định mới một lần
        k = await pg.evaluate("Object.keys(localStorage).find(k=>/tbl_lai-dong$/.test(k))")
        if k:
            await pg.evaluate("k=>{const v=JSON.parse(localStorage.getItem(k));delete v.l07;v.hidden=[];localStorage.setItem(k,JSON.stringify(v))}", k)
            await pg.reload(wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
            c2 = await rows.first.evaluate("r=>[...r.children].filter(c=>c.getBoundingClientRect().width>2).length")
            ok(T('T14 bố cục cũ đã lưu → chuyển sang 8 cột một lần'), c2 == 8, c2)
        else: ok(T('T14 tìm khóa bố cục đã lưu'), False, 'không thấy khóa tbl_lai-dong')
    ok(T('E1 0 pageerror'), not errs, errs)
    await b.close()

def gia_dat():
    s = open(ROOT / APP, encoding='utf-8').read()
    m = re.search(r'\["212","Đường Vũ Xuân Thiều","Đường Vũ Xuân Thiều","Cuối đường",([^\]]*)\]', s)
    v = [float(x) for x in m.group(1).split(',')]
    ok('G1 giá đất Vũ Xuân Thiều: TB VT1 55.000, TB VT2 33.000 (= (cao + thấp)/2)', v[2] == 55000 and v[5] == 33000 and v[2] == (v[0] + v[1]) / 2 and v[5] == (v[3] + v[4]) / 2, v)
    i = s.index('const oS={') + 9; j = s.index(']]}', i) + 3
    d = json.loads(s[i:j]); bad = []
    for ph, rs in d.items():
        for r in rs:
            for k in range(4):
                hi, lo, tb = r[4 + 3 * k:7 + 3 * k]
                if hi or lo:
                    if abs((hi + lo) / 2 - tb) > 0.5: bad.append((ph, r[0], r[1], k + 1))
    ok('G2 toàn bảng giá đất app: mọi TB = (cao + thấp)/2 (985 dòng)', not bad and sum(len(x) for x in d.values()) == 985, bad[:5])

async def main():
    gia_dat()
    tmp = tempfile.mkdtemp(); fix = os.path.join(tmp, 'msit80_03-11-2026.xlsx'); tao(fix)
    async with async_playwright() as pw:
        await run(pw, 'desktop', 1366, 768, fix); await run(pw, 'mobile', 390, 844, fix)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
