# -*- coding: utf-8 -*-
# Kiểm thử P43 v24.16.0 — NGÀY THU LÃI RIÊNG từng khoản (Playwright Chromium; mobile 390×844 + desktop 1280×1800).
# Mọi số lãi kỳ vọng tính ĐỘC LẬP bằng Python (Fraction, tròn nửa-lên), không dùng mã JS của app.
# Chạy: python3 kiem_thu_p43/test_ngay_rieng.py   (cổng 8829; ảnh → kiem_thu_p43/anh/)
import asyncio, functools, http.server, threading, re
from datetime import date
from fractions import Fraction as F
from math import floor
from pathlib import Path
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
PORT = 8829; URL = f'http://127.0.0.1:{PORT}/QLTDPRO_v24.16.0.html'; SHOT = HERE / 'anh'
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:500]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / 'app'))).serve_forever, daemon=True).start()

def d(s): return date.fromisoformat(s)
def rnd(x): return int(floor(x + F(1, 2)))
def lai(duno, ls, moc, mat, chot):  # độc lập: TH + (cơ bản QH) + (phạt 50% QH), tròn từng phần
    n = (d(chot) - d(moc)).days
    if n < 0: return None
    th = n if d(mat) > d(moc) and False else (min(n, (d(mat) - d(moc)).days) if d(mat) > d(moc) else 0)
    qh = n - th; k = F(duno) * F(ls) / 100 / 365
    return rnd(k * th) + rnd(k * qh) + rnd(k * F(1, 2) * qh)
def row(ten, seq, gn, duno, ls, gn_dt, den, moc):
    r = [''] * 27
    r[0] = '3201'; r[1] = ten; r[2] = seq; r[6] = gn_dt; r[7] = den; r[8] = ls; r[11] = duno; r[13] = 'Vay ngắn hạn'; r[20] = gn; r[23] = moc; r[24] = '2027-12-31'
    return r
LOANS = {  # duno: (ls, moc, mat)
    1_000_000_000: ('8.8', '2026-10-22', '2027-04-22'),   # A
    500_000_000:   ('9.5', '2026-10-22', '2027-04-22'),   # B
    217_441_521:   ('8.8', '2026-10-22', '2026-11-10'),   # C (đến hạn 10/11 → có quá hạn nếu chốt sau)
}
ROWS = [row('Vũ Xuân Tuấn', 'HD1', 'GN-A', 1_000_000_000, '8.8', '2026-10-22', '2027-04-22', '2026-10-22'),
        row('Vũ Xuân Tuấn', 'HD1', 'GN-B', 500_000_000, '9.5', '2026-10-22', '2027-04-22', '2026-10-22'),
        row('Vũ Xuân Tuấn', 'HD2', 'GN-C', 217_441_521, '8.8', '2026-09-01', '2026-11-10', '2026-10-22'),
        row('Nguyễn Văn Bình', 'HD9', 'GN-D', 300_000_000, '8.0', '2026-10-01', '2027-04-01', '2026-10-01')]
def exp(duno, chot):
    ls, moc, mat = LOANS[duno]; return lai(duno, ls, moc, mat, chot)
def num(s): return int(re.sub(r'[^\d]', '', s) or 0)

async def run(pw, name, vw, vh):
    b = await pw.chromium.launch(); pg = await b.new_page(viewport={'width': vw, 'height': vh})
    errs = []; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'Failed to load resource' not in m.text else None)
    await pg.goto(URL, wait_until='domcontentloaded'); await pg.wait_for_timeout(3000)
    T = lambda s: f'{name}: {s}'
    async def open_(chot='2026-11-03'):
        await pg.evaluate('([r,c]) => GD14.openCalc(r, {chot:c})', [ROWS, chot]); await pg.wait_for_timeout(300)
        await pg.fill('[data-testid=gd14-calc-search]', 'Tuan'); await pg.locator('[data-testid=gd14-calc-hit]').first.click()
    async def rows():  # {duno: {tong, ok, lbl, own}}
        out = {}; rs = pg.locator('[data-testid=gd14-calc-row]')
        for i in range(await rs.count()):
            r = rs.nth(i); dn = num(await r.locator('[data-testid=gd14-calc-duno]').inner_text())
            okf = await r.get_attribute('data-ok'); t = r.locator('[data-testid=gd14-calc-tong]')
            out[dn] = dict(i=i, ok=okf == '1', tong=num(await t.inner_text()) if await t.count() else None,
                           own=(await r.locator('[data-testid=gd14-calc-ngay-lbl]').inner_text()).strip() == 'riêng')
        return out
    async def tonglai(): return num(await pg.locator('[data-testid=gd14-calc-tonglai]').inner_text())
    async def setown(duno, v):
        i = (await rows())[duno]['i']; await pg.locator('[data-testid=gd14-calc-ngay]').nth(i).fill(v)
    A, B, C = 1_000_000_000, 500_000_000, 217_441_521
    await open_()
    r = await rows(); g = '2026-11-03'
    ok(T('1 mặc định: mọi khoản theo ngày chung, không "riêng", tổng khớp Python'), all(r[k]['tong'] == exp(k, g) and not r[k]['own'] for k in r) and await tonglai() == sum(exp(k, g) for k in r), (r, await tonglai()))
    ok(T('1b không hiện dòng thông tin ngày riêng'), await pg.locator('[data-testid=gd14-calc-ngay-info]').count() == 0)
    await setown(B, '2026-11-20'); r = await rows()
    ok(T('2 B ngày riêng 20/11: B khớp Python, A và C giữ ngày chung'), r[B]['tong'] == exp(B, '2026-11-20') and r[A]['tong'] == exp(A, g) and r[C]['tong'] == exp(C, g) and r[B]['own'] and not r[A]['own'], r)
    ok(T('2b tổng lãi = cộng từng khoản (3 ngày hỗn hợp)'), await tonglai() == exp(A, g) + exp(B, '2026-11-20') + exp(C, g))
    info = await pg.locator('[data-testid=gd14-calc-ngay-info]').inner_text()
    ok(T('2c thông tin: 2 ngày thu khác nhau · 1/3 khoản riêng'), '2 ngày thu khác nhau' in info and '1/3' in info, info)
    await pg.screenshot(path=str(SHOT / f'{name}_01_ngay_rieng.png'))
    await pg.fill('[data-testid=gd14-calc-chot]', '2026-11-10'); r = await rows()
    ok(T('3 đổi ngày chung → A, C đổi theo (C vừa đến hạn); B giữ ngày riêng'), r[A]['tong'] == exp(A, '2026-11-10') and r[C]['tong'] == exp(C, '2026-11-10') and r[B]['tong'] == exp(B, '2026-11-20'), r)
    await setown(C, '2026-11-30'); r = await rows()
    ok(T('3b C ngày riêng 30/11 sau hạn 10/11: tách trong hạn + quá hạn (LS×1,5) khớp Python'), r[C]['tong'] == exp(C, '2026-11-30') and exp(C, '2026-11-30') > exp(C, '2026-11-10') + 1000, (r[C], exp(C, '2026-11-30')))
    await setown(B, '2026-10-01'); r = await rows()
    ok(T('4 ngày riêng trước ngày đã thu lãi đến → khoản lỗi, KHÔNG cộng vào tổng, có cảnh báo'), not r[B]['ok'] and await tonglai() == exp(A, '2026-11-10') + exp(C, '2026-11-30') and await pg.locator('[data-testid=gd14-calc-loi-note]').count() == 1, r)
    await pg.locator('[data-testid=gd14-calc-ngay-clr]').first.click(); r = await rows()
    ok(T('5 nút ↺ bỏ ngày riêng → khoản theo lại ngày chung'), True if any(not v['own'] for v in r.values()) else False)
    await pg.click('[data-testid=gd14-calc-bulk-clear]'); r = await rows()
    ok(T('5b "Xoá ngày riêng" → tất cả theo ngày chung 10/11, tổng khớp'), all(not v['own'] for v in r.values()) and await tonglai() == sum(exp(k, '2026-11-10') for k in r), r)
    await pg.locator('[data-testid=gd14-calc-tick]').nth((await rows())[B]['i']).uncheck()
    await pg.fill('[data-testid=gd14-calc-bulk-date]', '2026-12-01'); await pg.click('[data-testid=gd14-calc-bulk-apply]'); r = await rows()
    ok(T('6 áp hàng loạt 01/12 cho khoản đã tick (A, C); B không tick giữ nguyên'), r[A]['own'] and r[C]['own'] and not r[B]['own'] and r[A]['tong'] == exp(A, '2026-12-01') and r[C]['tong'] == exp(C, '2026-12-01'), r)
    ok(T('6b tổng chỉ gồm khoản đã tick'), await tonglai() == exp(A, '2026-12-01') + exp(C, '2026-12-01'))
    await pg.click('[data-testid=gd14-calc-copy]'); cp = await pg.evaluate('GD14.calc.lastCopy')
    ok(T('7 Copy: có "thu đến 01/12/2026" từng dòng + dòng "Có 2 khoản chốt ngày riêng"'), cp.count('thu đến 01/12/2026') == 2 and 'Có 2 khoản chốt ngày riêng' in cp, cp)
    await pg.click('[data-testid=gd14-calc-bulk-clear]'); await pg.fill('[data-testid=gd14-calc-bulk-date]', '2026-10-10'); await pg.click('[data-testid=gd14-calc-bulk-apply]')
    toast = await pg.locator('[data-testid=gd14-calc-toast]').inner_text(); r = await rows()
    ok(T('8 áp ngày trước mốc → bỏ qua khoản không hợp lệ, không khoản nào bị đặt'), 'bỏ qua 2' in toast and all(not v['own'] for v in r.values()), toast)
    await pg.fill('[data-testid=gd14-calc-bulk-date]', '2026-12-05'); await pg.click('[data-testid=gd14-calc-bulk-apply]')
    await pg.click('[data-testid=gd14-calc-reset]'); r = await rows()
    ok(T('9 Reset bảng: xoá ngày riêng, tick lại mặc định'), all(not v['own'] for v in r.values()) and await pg.locator('[data-testid=gd14-calc-sotick]').inner_text() == '3')
    await setown(A, '2026-11-25')
    await pg.fill('[data-testid=gd14-calc-search]', 'Binh'); await pg.locator('[data-testid=gd14-calc-hit]').first.click()
    ok(T('10 đổi sang khách hàng khác: không mang ngày riêng sang'), await pg.locator('[data-testid=gd14-calc-ngay-lbl]').count() == 1 and (await pg.locator('[data-testid=gd14-calc-ngay-lbl]').inner_text()).strip() != 'riêng')
    await pg.fill('[data-testid=gd14-calc-search]', 'Tuan'); await pg.locator('[data-testid=gd14-calc-hit]').first.click(); r = await rows()
    ok(T('10b quay lại KH cũ: ngày riêng cũ đã xoá'), all(not v['own'] for v in r.values()))
    await pg.click('[data-testid=gd14-calc-tab-tay]'); ok(T('11 tab Tính tay không bị ảnh hưởng (có ô chốt chung)'), await pg.locator('[data-testid=gd14-calc-chot]').count() == 1)
    ok(T('12 không lỗi console/runtime'), not errs, errs)
    await pg.click('[data-testid=gd14-calc-tab-kh]'); await pg.fill('[data-testid=gd14-calc-search]', 'Tuan'); await pg.locator('[data-testid=gd14-calc-hit]').first.click(); await setown(B, '2026-11-20')
    await pg.locator('[data-testid=gd14-calc-bulk]').scroll_into_view_if_needed(); await pg.screenshot(path=str(SHOT / f'{name}_02_cuoi.png'))
    await b.close()
async def main():
    async with async_playwright() as pw:
        await run(pw, 'mobile', 390, 844); await run(pw, 'desktop', 1280, 1800)
    print(f'\nTỔNG: {sum(res)}/{len(res)} đạt'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
