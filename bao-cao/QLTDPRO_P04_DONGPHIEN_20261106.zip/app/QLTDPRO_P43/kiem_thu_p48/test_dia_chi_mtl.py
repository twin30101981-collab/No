# -*- coding: utf-8 -*-
# Kiểm thử P48 v24.17.4 — Máy tính lãi: địa chỉ khi tra cứu khách hàng (Playwright Chromium, mobile + desktop)
# Chạy: python3 kiem_thu_p48/test_dia_chi_mtl.py   (cổng 8848)
import asyncio, functools, http.server, threading
from pathlib import Path
from playwright.async_api import async_playwright
HERE=Path(__file__).resolve().parent; ROOT=HERE.parent
PORT=8848; URL=f'http://127.0.0.1:{PORT}/QLTDPRO_v24.17.4.html'
FIX=HERE/'msit80_03-11-2026.xlsx'
HEAD=['brcd','custnm','apprseq','apprdt','apprmatdt','appramt','dsbsseq','dsbsdt','dsbsmatdt','sprd','dsbsamt','rpmtamt','intamt','dsbsbal','ofcnm','lntpcd','addr1','commmn','fndprpstpcd','trctnm','aqccdfin','lstintchrgprd','nxtrpmtschddt','lstrpmtdt']
# (brcd, tên, HĐTD, địa chỉ addr1, commmn)
KH=[('3201149926246','Nguyễn Thị Hương','3201LAV1','Xóm 3, Xã Nam Hồng','Nam Trực, Nam Định'),
    ('3201224421103','Nguyễn Thị Lan Hương','3201LAV2','Số 5 Trần Hưng Đạo','TP Nam Định'),
    ('3201296287569','Trần Thị Lan Hương','3201LAV3','Thôn Đông, Xã Hồng Quang','Nam Trực, Nam Định'),
    ('3201000000001','Nguyễn Thị Chinh','3201LAV4','Xã Trực Thanh','Trực Ninh, Nam Định'),
    ('3201000000002','Nguyễn Thị Chinh','3201LAV5','Phường Cửa Bắc','TP Nam Định'),
    ('3201000000003','Nguyễn Thị Chinh','3201LAV6','','')]
def write():
    from openpyxl import Workbook
    wb=Workbook(); ws=wb.active; ws.title='Sheet1'; ws.append(HEAD)
    for i,(b,t,h,a,c) in enumerate(KH):
        ws.append([b,t,h,'05/06/2026','04/10/2027',1000000000,f'LD{i:04d}','05/06/2026','04/10/2027','8.8',1000000000,0,0,1000000000,'CB','211',a,c or None,'TD001','PGD','Nhóm 1','10/22/2026',None,None])
    wb.save(FIX)
write()
res=[]
def ok(n,c,info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ')+n+('' if c else ' — '+str(info)[:500]),flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a,**k): pass
httpd=http.server.ThreadingHTTPServer(('127.0.0.1',PORT),functools.partial(Q,directory=str(ROOT/'app')))
threading.Thread(target=httpd.serve_forever,daemon=True).start()
async def hits(pg,q):
    await pg.fill('[data-testid="gd14-calc-search"]',q); await pg.wait_for_timeout(250)
    return await pg.locator('[data-testid="gd14-calc-hit"]').all_inner_texts()
async def run(p,tag,vw,vh):
    print(f'\n== {tag} {vw}x{vh} ==',flush=True)
    b=await p.chromium.launch(); ctx=await b.new_context(viewport={'width':vw,'height':vh},locale='vi-VN')
    await ctx.grant_permissions(['clipboard-read','clipboard-write'],origin=f'http://127.0.0.1:{PORT}')
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg=await ctx.new_page(); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('console',lambda m:m.type=='error' and errs.append(m.text))
    T=tag+' '
    try:
        await pg.goto(URL+'#/nhap',wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
        await pg.set_input_files('[data-testid="file-input"]',[str(FIX)]); await pg.wait_for_timeout(2500)
        await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
        y=pg.locator('[data-testid="confirm-yes"]')
        if await y.count(): await y.click()
        await pg.wait_for_timeout(4500)
        await pg.goto(URL+'#/lai-dong',wait_until='domcontentloaded'); await pg.wait_for_timeout(2000)
        await pg.click('[data-testid="gd14-calc"]'); await pg.wait_for_timeout(400)
        ok(T+'A0 nhãn + ô tìm nhắc "địa chỉ"', 'địa chỉ' in (await pg.locator('[data-testid="gd14-calc-overlay"]').inner_text()).lower() and 'địa chỉ' in (await pg.locator('[data-testid="gd14-calc-search"]').get_attribute('placeholder')))
        h=await hits(pg,'hương')
        ok(T+'A1 "hương": 3 KH khớp tên xếp trước (KH chỉ khớp "Phường" ở địa chỉ xếp sau), mỗi dòng có 📍 + địa chỉ ghép commmn', len(h)==4 and all('Hương' in x.split('\n')[0] for x in h[:3]) and 'Chinh' in h[3] and all('📍' in x for x in h) and any('Xóm 3, Xã Nam Hồng, Nam Trực, Nam Định' in x for x in h), h)
        await pg.screenshot(path=str(HERE/f'{tag}_01_tim_huong.png'))
        h=await hits(pg,'chinh')
        ok(T+'A2 3 KH trùng tên "Nguyễn Thị Chinh" phân biệt được bằng địa chỉ', len(h)==3 and sum('Trực Thanh' in x for x in h)==1 and sum('Cửa Bắc' in x for x in h)==1 and sum('chưa có địa chỉ' in x for x in h)==1, h)
        h=await hits(pg,'chinh cua bac')
        ok(T+'A3 tìm "chinh cua bac" (tên + địa chỉ, không dấu) → đúng 1 KH', len(h)==1 and 'Cửa Bắc' in h[0], h)
        h=await hits(pg,'nam truc')
        ok(T+'A4 tìm chỉ theo địa chỉ "nam truc" → 3 KH có đủ 2 từ (Nam Trực ×2 + Trực Ninh, Nam Định)', len(h)==3 and sum('Nam Trực, Nam Định' in x for x in h)==2, h)
        h=await hits(pg,'lan huong')
        ok(T+'A5 "lan huong" (liền cụm) vẫn ra 2 KH như trước', len(h)==2, h)
        h=await hits(pg,'LAV2')
        ok(T+'A6 tìm theo số HĐTD vẫn đúng', len(h)==1 and 'Nguyễn Thị Lan Hương' in h[0], h)
        h=await hits(pg,'zzzz')
        ok(T+'A7 không khớp → báo không có KH', len(h)==0 and 'Không có khách hàng nào khớp' in await pg.locator('[data-testid="gd14-calc-results"]').inner_text())
        await hits(pg,'cua bac')
        await pg.locator('[data-testid="gd14-calc-hit"]').first.click(); await pg.wait_for_timeout(300)
        dc=await pg.locator('[data-testid="gd14-calc-diachi"]').inner_text()
        ok(T+'A8 thẻ KH đã chọn hiện địa chỉ', 'Phường Cửa Bắc, TP Nam Định' in dc, dc)
        await pg.screenshot(path=str(HERE/f'{tag}_02_the_kh.png'))
        await pg.click('[data-testid="gd14-calc-copy"]'); await pg.wait_for_timeout(300)
        clip=await pg.evaluate('navigator.clipboard.readText()')
        ok(T+'A9 bản copy có dòng "Địa chỉ: …"', 'Địa chỉ: Phường Cửa Bắc, TP Nam Định' in clip and 'Tổng lãi phải thu:' in clip, clip[:300])
        ok(T+'A10 không lỗi JS/console', not errs, errs[:3])
    except Exception as e:
        ok(T+'LỖI chạy',False,repr(e))
    await b.close()
async def main():
    async with async_playwright() as p:
        await run(p,'mobile',390,844); await run(p,'desktop',1280,1100)
    print(f'\nTỔNG: {sum(res)}/{len(res)}'); httpd.shutdown()
    raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
