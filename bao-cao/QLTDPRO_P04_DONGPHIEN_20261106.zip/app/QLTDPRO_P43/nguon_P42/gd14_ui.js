/*
 * GD14 — glue giao diện P42 (kế thừa P41; bổ theo backlog đề án 03/11/2026).
 * Phụ thuộc window.QLTDLai (được nối trước nó trong cùng khối gd14-js, nguồn qltd_lai.cjs).
 * Nguyên tắc: chỉ ĐỌC dữ liệu; không mạng; không đổi CSP; không chạm 4 CSDL cũ.
 * Handle thư mục lưu CSDL RIÊNG QLTDProFolder_v1 (chủ dự án đã chấp nhận — Q6).
 *
 * Mới so với P41:
 *  1. Quét thư mục con TUỲ CHỌN (Q4): mặc định mức 1; ô "Bao gồm thư mục con" lưu cùng CSDL
 *     riêng; khi bật quét đệ quy (sâu tối đa 5 mức, bỏ thư mục ẩn), khoá tệp tính theo ĐƯỜNG
 *     DẪN tương đối nên không trùng tệp cùng tên ở thư mục khác; tệp mức 1 giữ khoá y như P41
 *     nên danh sách đã đề xuất không bị đề xuất lại.
 *  2. Cột "Nguồn" của bảng kế hoạch: tệp lấy từ thư mục được gắn nhãn (gd14src), tệp lấy từ
 *     trong ZIP giữ nguyên chuỗi gd13src của khối gd13 — GD14.nguon(file) trả nhãn hiển thị.
 */
(function () {
  "use strict";
  if (!window.QLTDLai) return;
  var L = window.QLTDLai;

  /* ================= M1 glue · ngày chốt + cột lãi dự thu ================= */

  var CHOT_KEY = "gd14_chot";
  function chotGet() {
    try { var v = localStorage.getItem(CHOT_KEY); if (v && L.parseDate(v) != null) return v; } catch (e) {}
    return iso(L.todayUTC());
  }
  function chotSet(v) {
    try { if (v && L.parseDate(v) != null) localStorage.setItem(CHOT_KEY, v); } catch (e) {}
  }
  function iso(t) { return new Date(t).toISOString().slice(0, 10); }

  // Tổng lãi dự thu đến ngày chốt của 1 khoản (tổng đã tròn; không tính được → null)
  function duThu(row) {
    return L.tinhLaiKhoan(row, { chot: chotGet() });
  }
  function duThuNum(row) {
    var k = duThu(row);
    return k && k.ok ? k.tong : null;
  }

  /* ================= Công cụ "Tính lãi tất toán" (overlay DOM riêng, ngoài React) ================= */

  var toolRows = null, toolEl = null;

  function el(tag, attrs, kids) {
    var e = document.createElement(tag);
    attrs = attrs || {};
    Object.keys(attrs).forEach(function (k) {
      if (k === "text") e.textContent = attrs[k];
      else if (k === "cls") e.className = attrs[k];
      else if (k === "children") return;
      else if (k.slice(0, 2) === "on") e.addEventListener(k.slice(2), attrs[k]);
      else if (attrs[k] != null) e.setAttribute(k, attrs[k]);
    });
    (kids || []).forEach(function (c) { if (c) e.appendChild(c); });
    return e;
  }
  function esc(s) { var d = el("div"); d.textContent = s == null ? "" : String(s); return d.innerHTML; }

  function renderResult(box, row, chot, heSo, chamTra) {
    box.innerHTML = "";
    var k = L.tinhLaiKhoan(row, { chot: chot, heSoQH: heSo });
    var line = function (t, strong) {
      return el("div", { text: t, cls: strong ? "font-semibold" : "text-muted-foreground" });
    };
    if (!k || !k.ok) {
      box.appendChild(el("div", { cls: "rounded-md border border-warn/50 bg-warn/15 px-3 py-2 text-sm text-warn-foreground", text: "Không tính được: " + (k && k.lyDo ? k.lyDo : "lỗi không rõ") }));
      return;
    }
    var card = el("div", { cls: "rounded-md border bg-card p-3 text-sm", "data-testid": "gd14-tool-result" });
    card.appendChild(line("Từ " + k.moc + " (" + k.mocNguon + ") đến " + k.chot + " · dư nợ " + L.fmt(k.duno) + " đ · lãi suất " + L.fmtDec(k.ls) + "%/năm"));
    card.appendChild(el("div", { cls: "my-2 border-t" }));
    card.appendChild(line("Lãi trong hạn: " + k.soNgayTH + " ngày = " + L.fmt(k.laiTH) + " đ", true));
    card.appendChild(line("Lãi quá hạn (cơ bản): " + k.soNgayQH + " ngày = " + L.fmt(k.laiQHCB) + " đ", true));
    card.appendChild(line("Phạt lãi quá hạn (" + L.fmtDec((k.heSoQH - 1) * 100) + "%): " + L.fmt(k.laiQHPhat) + " đ", true));
    card.appendChild(line("TỔNG LÃI: " + L.fmt(k.tong) + " đ", true));
    if (chamTra && k.soNgayQH > 0) {
      var p = L.tinhLaiChamTra(k.duno, k.soNgayQH, 10);
      if (p.ok) {
        card.appendChild(el("div", { cls: "my-2 border-t" }));
        card.appendChild(line(p.chiTiet + " (tách riêng, không tính vào tổng lãi trên)", true));
      }
    }
    k.canhBao.forEach(function (c) {
      card.appendChild(el("div", { cls: "text-warn-foreground", text: "⚠ " + c }));
    });
    card.appendChild(el("div", { cls: "my-2 border-t" }));
    k.chiTiet.forEach(function (c) { card.appendChild(line(c)); });
    box.appendChild(card);
  }

  function renderTool() {
    if (!toolEl || !toolRows) return;
    var q = (toolEl.querySelector("[data-testid=gd14-tool-search]").value || "").trim().toLowerCase();
    var list = toolEl.querySelector("[data-testid=gd14-tool-list]");
    list.innerHTML = "";
    var n = 0;
    for (var i = 0; i < toolRows.length && n < 60; i++) {
      var r = toolRows[i];
      var ten = String(r[1] || ""), ma = String(r[0] || "");
      if (q && ten.toLowerCase().indexOf(q) < 0 && ma.toLowerCase().indexOf(q) < 0) continue;
      n++;
      list.appendChild(el("button", {
        cls: "flex w-full items-center justify-between gap-2 rounded border px-2 py-1.5 text-left text-sm hover:bg-accent",
        "data-testid": "gd14-tool-row",
        onclick: (function (rr) { return function () { renderPick(rr); }; })(r)
      }, [
        el("span", { text: (ten + " · " + ma).slice(0, 60) }),
        el("span", { text: "DN " + L.fmt(Number(r[11]) || 0) + " · LS " + L.fmtDec(Number(String(r[8]).replace(",", ".")) || 0) + "%", cls: "shrink-0 text-xs text-muted-foreground" })
      ]));
    }
    if (!n) list.appendChild(el("p", { cls: "px-2 py-3 text-sm text-muted-foreground", text: "Không có khoản nào khớp từ khoá." }));
    var rs = toolEl.querySelector("[data-testid=gd14-tool-resultbox]");
    rs.innerHTML = "";
    rs.appendChild(el("p", { cls: "px-1 py-2 text-sm text-muted-foreground", text: "Chọn một khoản vay để xem phân rã lãi." }));
  }

  var toolState = { date: null, heSo: "1,5", cham: false };

  function renderPick(row) {
    var rs = toolEl.querySelector("[data-testid=gd14-tool-resultbox]");
    rs.innerHTML = "";
    var dateInput = el("input", {
      type: "date", "data-testid": "gd14-tool-date", cls: "rounded border px-1", value: toolState.date || chotGet(),
      onchange: function (e) { toolState.date = e.target.value; renderPick(row); }
    });
    var heSoInput = el("input", {
      type: "text", "data-testid": "gd14-tool-heso", value: toolState.heSo, cls: "w-14 rounded border px-1",
      onchange: function (e) { toolState.heSo = e.target.value || "1,5"; renderPick(row); }
    });
    var chamInput = el("input", { type: "checkbox", "data-testid": "gd14-tool-chamtra" });
    chamInput.checked = toolState.cham;
    chamInput.addEventListener("change", function () { toolState.cham = chamInput.checked; renderPick(row); });
    var head = el("div", { cls: "flex flex-wrap items-center gap-2 py-2 text-sm" }, [
      el("b", { text: String(row[1] || "") + " · " + String(row[0] || "") }),
      el("label", { cls: "flex items-center gap-1" }, [el("span", { text: "Tất toán đến" }), dateInput]),
      el("label", { cls: "flex items-center gap-1 text-xs" }, [el("span", { text: "Hệ số QH" }), heSoInput]),
      el("label", { cls: "flex items-center gap-1 text-xs" }, [chamInput, el("span", { text: "Cộng lãi chậm trả 10%/năm (tách riêng)" })])
    ]);
    rs.appendChild(head);
    var box = el("div");
    rs.appendChild(box);
    renderResult(box, row, toolState.date || chotGet(), Number(String(toolState.heSo).replace(",", ".")) || 1.5, toolState.cham);
  }

  function closeTool() {
    if (toolEl) { toolEl.remove(); toolEl = null; }
  }

  function openAllot(rows) {
    closeTool();
    toolRows = rows || [];
    toolEl = el("div", { cls: "fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4", "data-testid": "gd14-tool-overlay" });
    var panel = el("div", { role: "dialog", "aria-modal": "true", cls: "flex max-h-[90vh] w-[640px] max-w-full flex-col gap-3 overflow-auto rounded-lg border bg-background p-4 shadow-2xl" });
    var top = el("div", { cls: "flex items-center justify-between" }, [
      el("b", { text: "🧮 Tính lãi tất toán — QLTDPRO P42 (chỉ đọc, không ghi dữ liệu)" }),
      el("button", { cls: "rounded px-2 text-muted-foreground hover:bg-accent", text: "×", "aria-label": "Đóng", "data-testid": "gd14-tool-close", onclick: closeTool })
    ]);
    var search = el("input", {
      type: "search", "data-testid": "gd14-tool-search", placeholder: "Tìm theo tên khách hàng hoặc mã KH…",
      cls: "w-full rounded border px-2 py-1.5 text-sm", oninput: renderTool
    });
    var list = el("div", { cls: "max-h-56 overflow-auto rounded border bg-card", "data-testid": "gd14-tool-list" });
    var rs = el("div", { cls: "rounded border bg-card px-2 py-1", "data-testid": "gd14-tool-resultbox" });
    panel.appendChild(top); panel.appendChild(search); panel.appendChild(list); panel.appendChild(rs);
    toolEl.appendChild(panel);
    toolEl.addEventListener("click", function (e) { if (e.target === toolEl) closeTool(); });
    document.addEventListener("keydown", function escListener(e) {
      if (e.key === "Escape") { closeTool(); document.removeEventListener("keydown", escListener); }
    });
    document.body.appendChild(toolEl);
    renderTool();
  }

  /* ================= M2 · Nguồn thư mục IPCAS ================= */

  var DB_NAME = "QLTDProFolder_v1", DB_STORE = "kv";
  function dbOpen() {
    return new Promise(function (res, rej) {
      var rq = indexedDB.open(DB_NAME, 1);
      rq.onupgradeneeded = function () { rq.result.createObjectStore(DB_STORE); };
      rq.onsuccess = function () { res(rq.result); };
      rq.onerror = function () { rej(rq.error); };
    });
  }
  function dbGet(k) {
    return dbOpen().then(function (db) {
      return new Promise(function (res, rej) {
        var tx = db.transaction(DB_STORE, "readonly"), rq = tx.objectStore(DB_STORE).get(k);
        rq.onsuccess = function () { res(rq.result); }; rq.onerror = function () { rej(rq.error); };
      });
    });
  }
  function dbSet(k, v) {
    return dbOpen().then(function (db) {
      return new Promise(function (res, rej) {
        var tx = db.transaction(DB_STORE, "readwrite"), rq = tx.objectStore(DB_STORE).put(v, k);
        rq.onsuccess = function () { res(); }; rq.onerror = function () { rej(rq.error); };
      });
    });
  }

  var F = {
    POLL_MS: 10 * 60 * 1000,        // chu kỳ quét quyền/quét tệp (mặc định 10 phút — Q-giới hạn đề án)
    STABLE_MS: 30 * 1000,           // tệp vừa sửa trong 30s → bỏ qua, lần quét sau
    MAX_DEPTH: 5,                   // sâu tối đa khi bật "Bao gồm thư mục con" (mức 1 của thư mục đã chọn = 0)
    extOK: /\.(xlsx|xlsm|xls|csv|zip)$/i,
    busy: false, lastScan: "", lastNote: "", mode: "hoi", sub: false,
    seen: [] // [{key,n,at}] — đã đề xuất/nhập; key = đường_dẫn_tương_đối + tên + kích thước + lastModified
  };

  function logEvent(text) {
    F.lastNote = text;
    if (F.card) F.card.querySelector("[data-testid=gd14-folder-status]").textContent = text;
    var d = new Date().toISOString();
    F.log = (F.log || []).concat([{ at: d, text: text }]).slice(-30);
    dbSet("log", F.log).catch(function () {});
  }

  function permState(handle) {
    return handle && handle.queryPermission ? handle.queryPermission({ mode: "read" }) : Promise.resolve("unavailable");
  }

  function pickFolder() {
    if (!window.showDirectoryPicker) return;
    window.showDirectoryPicker({ mode: "read" }).then(function (h) {
      F.handle = h;
      return dbSet("handle", h).then(function () {
        logEvent("Đã chọn thư mục: " + (h.name || "(không rõ tên)"));
        return scan(true);
      });
    }).catch(function (e) { if (e && e.name !== "AbortError") logEvent("Không chọn được thư mục: " + (e.message || e.name)); });
  }

  function regrant() {
    if (!F.handle || !F.handle.requestPermission) { logEvent("Chưa có thư mục nào được lưu."); return; }
    F.handle.requestPermission({ mode: "read" }).then(function (s) {
      if (s === "granted") { logEvent("Đã cấp lại quyền — quét lại thư mục."); scan(true); }
      else logEvent("Quyền chưa được cấp (" + s + ").");
    }).catch(function (e) { logEvent("Cấp quyền thất bại: " + (e.message || e.name)); });
  }

  function forget() {
    F.handle = null; F.seen = []; F.lastNote = "";
    return Promise.all([dbSet("handle", null), dbSet("seen", [])]).then(function () {
      logEvent("Chưa chọn thư mục. Chọn một lần là đủ — app ghi nhớ và tự nhận tệp mới.");
      renderCard();
    });
  }

  // Nhãn "Nguồn" cho cột mới của bảng kế hoạch (tệp File đã qua gd13 giữ chuỗi zip gốc)
  function nguon(f) {
    if (f && f.gd14src) return f.gd14src + (f.gd13src ? " › ZIP: " + f.gd13src : "");
    if (f && f.gd13src) return "ZIP: " + f.gd13src;
    return "Chọn tệp / Kéo thả";
  }

  function dispatchFiles(files) {
    var input = document.querySelector('[data-testid="file-input"]');
    if (!input) { logEvent("Không tìm thấy ô nhập tệp — hãy mở trang Nhập IPCAS."); return; }
    var dt = new DataTransfer();
    files.forEach(function (f) { try { dt.items.add(f); } catch (e) {} });
    input.files = dt.files;
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function autoImport() {
    var blocked = document.querySelector('[data-testid="import-blocked"]');
    if (blocked) { logEvent("Bỏ qua tự nhập: app chỉ xem hoặc còn thay đổi chưa lưu."); return; }
    var run = document.querySelector('[data-testid="chay"]');
    if (!run || run.disabled) { logEvent("Tự nhập: không có tệp mới để nhập."); return; }
    run.click();
    var tries = 0;
    var timer = setInterval(function () {
      var yes = document.querySelector('[data-testid="confirm-yes"]');
      if (yes) { clearInterval(timer); yes.click(); logEvent("Đã tự nhập theo chế độ Tự nhập."); return; }
      if (++tries > 15) { clearInterval(timer); logEvent("Tự nhập: không thấy bước xác nhận — dừng."); }
    }, 200);
  }

  /* Thu thập tệp trong thư mục (mức 1; khi F.sub bật thì đệ quy theo đường dẫn tương đối) */
  function collect(dir, rel, depth, out) {
    var it = dir.values();
    function step() {
      return it.next().then(function (r) {
        if (r.done) return;
        var h = r.value, name = h.name, relName = (rel ? rel + "/" : "") + name;
        if (h.kind === "directory") {
          if (F.sub && depth < F.MAX_DEPTH && !/^\./.test(name)) {
            return collect(h, relName, depth + 1, out).then(step);
          }
          return step();
        }
        if (!F.extOK.test(name) || /^\W*~\$/.test(name) || /^\./.test(name)) return step();
        return h.getFile().then(function (file) {
          if (out.now - file.lastModified < F.STABLE_MS) { out.skipped++; return; }
          var key = relName + "|" + file.size + "|" + file.lastModified;
          for (var i = 0; i < F.seen.length; i++) if (F.seen[i].key === key) return;
          // cảnh báo tệp mang ngày tương lai trong tên (dd.mm / dd-mm / dd_mm yyyy)
          var m = /(\d{1,2})[.\-_\/](\d{1,2})[.\-_\/](\d{4})/.exec(name);
          if (m) {
            var d = new Date(+m[3], +m[2] - 1, +m[1]);
            if (d.getTime() > out.now + 86400000) out.warns.push(relName + " (ngày " + m[1] + "/" + m[2] + "/" + m[3] + " ở tương lai)");
          }
          F.seen.push({ key: key, n: relName, at: new Date().toISOString() });
          file.gd14src = "Thư mục IPCAS" + (rel ? " › " + rel : "");
          out.found.push(file);
        }).catch(function () { out.warns.push(relName + " (đọc lỗi — thử lại lần quét sau)"); }).then(step);
      });
    }
    return step();
  }

  function scan(manual) {
    if (F.busy) return Promise.resolve();
    if (!F.handle) { if (manual) logEvent("Chưa chọn thư mục."); return Promise.resolve(); }
    F.busy = true;
    return permState(F.handle).then(function (s) {
      if (s !== "granted") {
        logEvent(s === "prompt" ? "Cần cấp lại quyền — bấm “Cập quyền”." : "Thư mục không đọc được (bị xoá/đổi tên hoặc quyền bị thu hồi).");
        renderCard(); F.busy = false; return;
      }
      var out = { found: [], warns: [], skipped: 0, now: Date.now() };
      var sigLen = F.seen.length;
      return collect(F.handle, "", 0, out).then(function () {
        F.lastScan = new Date().toLocaleTimeString("vi-VN");
        if (F.seen.length !== sigLen || out.found.length) return dbSet("seen", F.seen.slice(-500));
      }).then(function () {
        if (out.found.length) {
          logEvent("Quét " + F.lastScan + ": đề xuất " + out.found.length + " tệp mới" + (out.skipped ? ", " + out.skipped + " tệp đang chép dở (bỏ qua)" : "") + (out.warns.length ? " · ⚠ " + out.warns.join("; ") : ""));
          dispatchFiles(out.found);
          if (F.mode === "tu") setTimeout(autoImport, 1200);
        } else if (manual) {
          logEvent("Quét " + F.lastScan + ": không có tệp mới" + (out.skipped ? " (" + out.skipped + " tệp đang chép dở)" : "") + (out.warns.length ? " · ⚠ " + out.warns.join("; ") : ""));
        }
        renderCard();
        F.busy = false;
      });
    }).catch(function (e) {
      logEvent("Quét lỗi: " + (e.message || e.name));
      renderCard(); F.busy = false;
    });
  }

  /* ---- thẻ giao diện gắn vào trang Nhập (DOM riêng, ngoài React) ---- */

  function renderCard() {
    if (!F.card) return;
    var has = !!F.handle, sup = !!window.showDirectoryPicker;
    F.card.innerHTML = "";
    var box = el("div", { cls: "rounded-lg border bg-card p-3 text-sm", "data-testid": "gd14-folder" });
    var head = el("div", { cls: "flex flex-wrap items-center gap-2" }, [
      el("h2", { cls: "mr-auto text-sm font-bold", text: "📁 Nguồn thư mục IPCAS (P42 — chỉ đọc)" })
    ]);
    box.appendChild(head);
    if (!sup) {
      box.appendChild(el("p", { cls: "text-muted-foreground", text: "Trình duyệt này không hỗ trợ chọn thư mục (cần Chrome/Edge máy tính). Dùng Kéo thả hoặc tệp ZIP ở ô phía trên." }));
      return;
    }
    var b1 = el("button", { cls: "rounded-md border bg-secondary px-3 py-1.5 text-sm font-semibold hover:bg-accent", "data-testid": "gd14-folder-pick", text: has ? "Đổi thư mục…" : "Chọn thư mục…", onclick: pickFolder });
    head.appendChild(b1);
    if (has) {
      head.appendChild(el("button", { cls: "rounded-md border px-3 py-1.5 text-sm hover:bg-accent", "data-testid": "gd14-folder-scan", text: "Quét ngay", onclick: function () { scan(true); } }));
      head.appendChild(el("button", { cls: "rounded-md border px-3 py-1.5 text-sm hover:bg-accent", "data-testid": "gd14-folder-repropose", text: "Đưa lại tất cả tệp", title: "Xoá danh sách đã đề xuất rồi quét lại — mọi tệp trong thư mục được đưa lại vào bảng kế hoạch", onclick: function () { F.seen = []; dbSet("seen", []).then(function () { scan(true); }); } }));
      head.appendChild(el("button", { cls: "rounded-md border px-3 py-1.5 text-sm hover:bg-accent", "data-testid": "gd14-folder-regrant", text: "Cập quyền", onclick: regrant }));
      head.appendChild(el("button", { cls: "rounded-md border px-3 py-1.5 text-sm text-destructive hover:bg-accent", "data-testid": "gd14-folder-forget", text: "Bỏ thư mục", onclick: forget }));
    }
    var mode = el("label", { cls: "flex items-center gap-1 text-xs", "data-testid": "gd14-folder-mode" }, [
      (function () {
        var cb = el("input", { type: "checkbox", "data-testid": "gd14-folder-auto" });
        cb.checked = F.mode === "tu";
        cb.addEventListener("change", function () {
          F.mode = cb.checked ? "tu" : "hoi";
          dbSet("mode", F.mode).catch(function () {});
          logEvent(cb.checked ? "Đã bật Tự nhập — tệp mới sẽ nhập ngay (vẫn chặn khi chỉ xem / còn thay đổi chưa lưu)." : "Đã về chế độ Hỏi — tệp mới chỉ vào bảng kế hoạch chờ bấm Nhập.");
        });
        return cb;
      })(),
      el("span", { text: "Tự nhập (mặc định: Hỏi — tệp mới chỉ vào bảng kế hoạch chờ bấm Nhập)" })
    ]);
    box.appendChild(mode);
    var sub = el("label", { cls: "flex items-center gap-1 text-xs", "data-testid": "gd14-folder-sublbl" }, [
      (function () {
        var cb = el("input", { type: "checkbox", "data-testid": "gd14-folder-sub" });
        cb.checked = !!F.sub;
        cb.addEventListener("change", function () {
          F.sub = cb.checked;
          dbSet("sub", F.sub).catch(function () {});
          logEvent(F.sub ? "Đã bật quét cả thư mục con — bấm “Quét ngay” để quét lại." : "Đã tắt quét thư mục con — chỉ quét mức 1.");
        });
        return cb;
      })(),
      el("span", { text: "Bao gồm thư mục con (mặc định: chỉ quét mức 1)" })
    ]);
    box.appendChild(sub);
    var st = el("p", { cls: "text-muted-foreground", "data-testid": "gd14-folder-status", text: F.lastNote || (has ? "Sẵn sàng — bấm “Quét ngay” hoặc chờ quét định kỳ 10 phút." : "Chưa chọn thư mục. Chọn một lần là đủ — app ghi nhớ và tự nhận tệp mới.") });
    box.appendChild(st);
    if (has && (F.log || []).length) {
      var lgBtn = el("button", { cls: "text-xs text-muted-foreground underline decoration-dotted", "data-testid": "gd14-folder-logbtn", text: "▸ Nhật ký thư mục", onclick: function () {
        var open = lgBox.style.display !== "none";
        lgBox.style.display = open ? "none" : "block";
        lgBtn.textContent = open ? "▸ Nhật ký thư mục" : "▾ Nhật ký thư mục";
      } });
      var lgBox = el("div", { cls: "mt-1 max-h-40 overflow-auto rounded border bg-secondary/40 p-2 text-xs text-muted-foreground", "data-testid": "gd14-folder-log", style: "display:none" });
      (F.log || []).slice().reverse().forEach(function (e2) {
        lgBox.appendChild(el("div", { text: (e2.at || "").replace("T", " ").slice(0, 19) + " · " + e2.text }));
      });
      box.appendChild(lgBtn); box.appendChild(lgBox);
    }
    F.card.appendChild(box);
  }

  function ensureCard() {
    var page = document.querySelector('[data-testid="page-nhap"]');
    if (!page) { if (F.card && !document.contains(F.card)) F.card = null; return; }
    if (F.card && document.contains(F.card)) return;
    F.card = el("div", { "data-testid": "gd14-folder-slot" });
    page.appendChild(F.card);
    renderCard();
  }

  function init() {
    Promise.all([dbGet("handle"), dbGet("seen"), dbGet("mode"), dbGet("log"), dbGet("sub")]).then(function (r) {
      F.handle = r[0] || null; F.seen = r[1] || []; F.mode = r[2] || "hoi"; F.log = r[3] || []; F.sub = !!r[4];
      ensureCard();
      renderCard();
      if (F.handle) setTimeout(function () { scan(true); }, 4000);
    }).catch(function () { ensureCard(); renderCard(); });

    new MutationObserver(function () { ensureCard(); }).observe(document.body, { childList: true, subtree: true });
    document.addEventListener("visibilitychange", function () {
      if (!document.hidden && F.handle) scan(false);
    });
    window.addEventListener("focus", function () { if (F.handle) scan(false); });
    setInterval(function () { if (!document.hidden && F.handle) scan(false); }, F.POLL_MS);
  }

  window.GD14 = {
    chotGet: chotGet, chotSet: chotSet,
    duThu: duThu, duThuNum: duThuNum,
    fmt: L.fmt, openAllot: openAllot, closeTool: closeTool,
    folder: F, scan: scan, nguon: nguon,
    PHIEN_BAN: "P42-GD14 1.0.0"
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
