#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gói P42: dựng QLTDPRO_v24.14.0.html từ P41 (v24.13.0) — backlog:
(1) quét thư mục con tuỳ chọn (Q4); (2) cột "Nguồn" của bảng kế hoạch; (3) nhãn nguồn tệp
truyền qua khối gd13 khi tệp trong ZIP lấy từ thư mục (chỉ thêm metadata, không đổi hành vi).
Quy tắc: chỉ vá theo chuỗi chính xác đếm đúng số lần; nghiệp vụ mới nằm trong khối gd14;
không đổi CSP, không đổi 4 CSDL IndexedDB (handle thư mục ở CSDL riêng QLTDProFolder_v1), không thêm mạng."""
import io, sys, os

ROOT = os.path.dirname(os.path.abspath(__file__)); APP = os.path.join(ROOT, '..', 'app')
SRC = os.path.join(APP, 'QLTDPRO_v24.13.0.html'); DST = os.path.join(APP, 'QLTDPRO_v24.14.0.html')
def read(p):
    with io.open(p, encoding='utf-8') as f: return f.read()
def write(p, s):
    with io.open(p, 'w', encoding='utf-8', newline='') as f: f.write(s)
def rep(h, old, new, expect=1):
    n = h.count(old)
    if n != expect: sys.exit('ANCHOR FAIL: expect %d, got %d: %r' % (expect, n, old[:90]))
    return h.replace(old, new)

def main():
    h = read(SRC)
    # nhãn phiên bản
    h = rep(h, 'children:["v","24.13.0"," · ","2026-11-03"]', 'children:["v","24.14.0"," · ","2026-11-03"]')
    h = rep(h, 'Wk("24.13.0",r)', 'Wk("24.14.0",r)')
    # cột "Nguồn" — tiêu đề bảng kế hoạch (sau "Kích thước", trước "Ghi chú")
    h = rep(h, 'children:"Kích thước"}),o.jsx("th",{className:"px-3 py-2",children:"Ghi chú"})',
               'children:"Kích thước"}),o.jsx("th",{className:"px-3 py-2",children:"Nguồn"}),o.jsx("th",{className:"px-3 py-2",children:"Ghi chú"})')
    # cột "Nguồn" — dòng chờ nhập (re = mục kế hoạch, re.file = File gốc)
    h = rep(h, 'o.jsx("td",{className:"px-3 py-2 whitespace-nowrap",children:le.hub.fmtBytes(U.size)}),',
               'o.jsx("td",{className:"px-3 py-2 whitespace-nowrap",children:le.hub.fmtBytes(U.size)}),'
               'o.jsx("td",{className:"px-3 py-2 text-xs text-muted-foreground","data-testid":"nguon",children:window.GD14?window.GD14.nguon(re.file):""}),')
    # cột "Nguồn" — dòng đã nhập
    h = rep(h, 'o.jsx("td",{className:"px-3 py-2 whitespace-nowrap",children:le.hub.fmtBytes(U.file.size)}),',
               'o.jsx("td",{className:"px-3 py-2 whitespace-nowrap",children:le.hub.fmtBytes(U.file.size)}),'
               'o.jsx("td",{className:"px-3 py-2 text-xs text-muted-foreground","data-testid":"nguon",children:window.GD14?window.GD14.nguon(U.file):""}),')
    # gd13 · truyền nhãn nguồn: ZIP lấy từ thư mục IPCAS ghi nhãn thư mục vào các tệp được giải nén
    # (chỉ thêm metadata topSrc — hành vi giải nén, lọc, giới hạn giữ nguyên)
    h = rep(h, "ctx = { out: [], notes: [], rar: [], count: 0, bytes: 0, names: {} }",
               "ctx = { out: [], notes: [], rar: [], count: 0, bytes: 0, names: {}, topSrc: '' }")
    h = rep(h, "if (!isZipName) { plain.push(f); continue; }",
               "if (f.gd14src && !ctx.topSrc) ctx.topSrc = f.gd14src;\n        if (!isZipName) { plain.push(f); continue; }")
    h = rep(h, "var f = new File([data], uniq(base, ctx), { lastModified: Date.now() }); f.gd13src = label; ctx.out.push(f);",
               "var f = new File([data], uniq(base, ctx), { lastModified: Date.now() }); f.gd13src = label; if (ctx.topSrc) f.gd14src = ctx.topSrc; ctx.out.push(f);")
    # khối gd14 = QLTDLai (thuần, giữ nguyên) + GD14 (glue giao diện + nguồn thư mục P42), thay toàn khối
    js = read(os.path.join(ROOT, '..', 'nguon_P41', 'qltd_lai.cjs')) + '\n' + read(os.path.join(ROOT, 'gd14_ui.js'))
    if '</script' in js.lower(): sys.exit('gd14 chứa </script')
    for bad in ('fetch(', 'XMLHttpRequest', 'WebAssembly', 'eval(', 'new Function'):
        if bad in js: sys.exit('gd14 chứa ' + bad)
    start = h.find('<script id="gd14-js">')
    if start < 0 or h.count('<script id="gd14-js">') != 1: sys.exit('MARKER FAIL gd14-js mở')
    end = h.find('</script>', start)
    if end < 0: sys.exit('MARKER FAIL gd14-js đóng')
    h = h[:start] + '<script id="gd14-js">\n' + js + '\n' + h[end:]
    write(DST, h)
    sw = read(os.path.join(APP, 'sw.js'))
    sw = sw.replace('qltdpro-p41-v24.13.0', 'qltdpro-p42-v24.14.0').replace('QLTDPRO_v24.13.0.html', 'QLTDPRO_v24.14.0.html').replace('Service Worker (P41)', 'Service Worker (P42)')
    write(os.path.join(APP, 'sw.js'), sw)
    mf = read(os.path.join(APP, 'manifest.json')); write(os.path.join(APP, 'manifest.json'), mf.replace('QLTDPRO_v24.13.0.html', 'QLTDPRO_v24.14.0.html'))
    print('build OK: %s (%d bytes, +%.1f KB)' % (os.path.basename(DST), os.path.getsize(DST), (os.path.getsize(DST) - os.path.getsize(SRC)) / 1024.0))
if __name__ == '__main__': main()
