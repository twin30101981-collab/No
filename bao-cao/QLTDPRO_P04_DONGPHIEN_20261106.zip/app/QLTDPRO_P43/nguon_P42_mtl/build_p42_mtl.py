#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""P42 · Máy tính lãi: dựng QLTDPRO_v24.15.0.html từ v24.14.0 (P42).
Quy tắc kế thừa P39–P42: chỉ vá theo chuỗi chính xác đếm đúng số lần; nghiệp vụ mới nằm trong khối gd14;
lõi nguon_P41/qltd_lai.cjs nối nguyên văn (kiểm sha256); không đổi CSP, không đổi 4 CSDL, không thêm mạng.
Tái lập từng byte: đầu ra chỉ phụ thuộc v24.14.0 + qltd_lai.cjs + gd14_ui.js (không ghi thời điểm dựng)."""
import hashlib, io, os, sys

ROOT = os.path.dirname(os.path.abspath(__file__)); APP = os.path.join(ROOT, '..', 'app')
SRC = os.path.join(APP, 'QLTDPRO_v24.14.0.html'); DST = os.path.join(APP, 'QLTDPRO_v24.15.0.html')
LOI = os.path.join(ROOT, '..', 'nguon_P41', 'qltd_lai.cjs')
LOI_SHA256 = '55908dc63a2d209465f60f1e19f689dfe3001dee7d466acfc6d828a1db85a1a0'  # = MANIFEST P42

def read(p):
    with io.open(p, encoding='utf-8') as f: return f.read()
def write(p, s):
    with io.open(p, 'w', encoding='utf-8', newline='') as f: f.write(s)
def rep(h, old, new, expect=1):
    n = h.count(old)
    if n != expect: sys.exit('ANCHOR FAIL: expect %d, got %d: %r' % (expect, n, old[:90]))
    return h.replace(old, new)

def main():
    with open(LOI, 'rb') as f:
        if hashlib.sha256(f.read()).hexdigest() != LOI_SHA256: sys.exit('LÕI qltd_lai.cjs ĐÃ BỊ ĐỔI — dừng')
    h = read(SRC)
    # nhãn phiên bản
    h = rep(h, 'children:["v","24.14.0"," · ","2026-11-03"]', 'children:["v","24.15.0"," · ","2026-11-03"]')
    h = rep(h, 'Wk("24.14.0",r)', 'Wk("24.15.0",r)')
    # nút "Máy tính lãi" ở thanh công cụ trang Lãi đọng + Nợ đến hạn (chỉ đọc → không khoá khi chỉ xem)
    h = rep(h, 'I=o.jsxs(o.Fragment,{children:[...(!r?[o.jsx("button",{"data-testid":"gd14-tool"',
               'I=o.jsxs(o.Fragment,{children:[o.jsx("button",{"data-testid":"gd14-calc",className:"rounded-md border bg-secondary px-3 py-1.5 text-sm font-semibold hover:bg-accent",'
               'onClick:()=>window.GD14.openCalc(n),children:"\\ud83d\\udd22 M\\u00e1y t\\u00ednh l\\u00e3i"}),'
               '...(!r?[o.jsx("button",{"data-testid":"gd14-tool"')
    # khối gd14 = QLTDLai (nguyên văn) + GD14 (glue + Máy tính lãi), thay toàn khối theo marker
    js = read(LOI) + '\n' + read(os.path.join(ROOT, 'gd14_ui.js'))
    if '</script' in js.lower(): sys.exit('gd14 chứa </script')
    for bad in ('fetch(', 'XMLHttpRequest', 'WebAssembly', 'eval(', 'new Function'):
        if bad in js: sys.exit('gd14 chứa ' + bad)
    if h.count('<script id="gd14-js">') != 1: sys.exit('MARKER FAIL gd14-js mở')
    start = h.find('<script id="gd14-js">'); end = h.find('</script>', start)
    if end < 0: sys.exit('MARKER FAIL gd14-js đóng')
    h = h[:start] + '<script id="gd14-js">\n' + js + '\n' + h[end:]
    write(DST, h)
    # sw.js / manifest.json: dựng từ nội dung P42 (24.14.0) để chạy lại nhiều lần vẫn cho cùng kết quả
    sw = read(os.path.join(APP, 'sw.js'))
    sw = sw.replace('qltdpro-p42-v24.14.0', 'qltdpro-p42-v24.15.0').replace('QLTDPRO_v24.14.0.html', 'QLTDPRO_v24.15.0.html')
    write(os.path.join(APP, 'sw.js'), sw)
    mf = read(os.path.join(APP, 'manifest.json'))
    write(os.path.join(APP, 'manifest.json'), mf.replace('QLTDPRO_v24.14.0.html', 'QLTDPRO_v24.15.0.html'))
    with open(DST, 'rb') as f: md5 = hashlib.md5(f.read()).hexdigest()
    print('build OK: %s (%d bytes, +%.1f KB) md5 %s' % (os.path.basename(DST), os.path.getsize(DST), (os.path.getsize(DST) - os.path.getsize(SRC)) / 1024.0, md5))

if __name__ == '__main__': main()
