# P45 · v24.17.1 — món giải ngân + tất toán trong kỳ: chỉ tính Giải ngân; mục "Tất toán trong kỳ" để tick chuyển sang KH vay mới
SRC='app/QLTDPRO_v24.17.0.html'; DST='app/QLTDPRO_v24.17.1.html'
s=open(SRC,encoding='utf-8').read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n,('anchor count',c,n,old[:70]); s=s.replace(old,new)

# 1) kho tick (localStorage) + hàm bật/tắt -> dựng lại báo cáo, giữ nguyên tab/bộ lọc
rep("function nonEmptyN(rows){","""var KHM_TICK_KEY='qltdpro_khm_tick_v1';
window.__khmTick=new Set();try{JSON.parse(localStorage.getItem(KHM_TICK_KEY)||'[]').forEach(function(k){window.__khmTick.add(k)})}catch(_){}
window.__khmToggleTick=function(L){
  var k=String(L.brcd).trim()+'|'+String(L.apprseq)+'|'+String(L.dsbsseq),t=window.__khmTick;
  if(t.has(k))t.delete(k);else t.add(k);
  try{localStorage.setItem(KHM_TICK_KEY,JSON.stringify(Array.from(t)))}catch(_){}
  if(window.__khmRebuild)window.__khmRebuild();
};
function nonEmptyN(rows){""")

# 2) component: hàm dựng lại báo cáo không đổi tab/bộ lọc
rep("j=async()=>{const ee=Ee.validateSources(e,n,a);",
    "__rb=window.__khmRebuild=()=>{const oe=e;if(!(oe.dau&&oe.cuoi&&oe.tsbdCuoi))return;l(Ee.buildReport({dau:oe.dau.rows,cuoi:oe.cuoi.rows,tsbdCuoi:oe.tsbdCuoi.rows,tsbdDau:oe.tsbdDau?oe.tsbdDau.rows:null,from:n,to:a}))},j=async()=>{const ee=Ee.validateSources(e,n,a);")

# 3) buildReport: món tất toán trong kỳ mặc định KHÔNG phải vay mới/cầm cố; chỉ khi đã tick
rep("ne=!K.has(re),se={","ne=W.__tt?!!(window.__khmTick&&window.__khmTick.has(__xk(W))):!K.has(re),se={")
rep("!ne&&O.has(re)&&J.push(se)","!ne&&!W.__tt&&O.has(re)&&J.push(se)")

# 4) Chi tiết: nút "Tất toán trong kỳ" + cột tick + dòng hướng dẫn
rep('(b.kind==="all"||(b.kind==="moi"?C.khMoi:C.camCo))','(b.kind==="all"||(b.kind==="tt"?C.tatToan:(b.kind==="moi"?C.khMoi:C.camCo)))')
rep('["cc","Cầm cố"]].map(','["cc","Cầm cố"],["tt","Tất toán trong kỳ"]].map(')
rep('o.jsx("tr",{children:["Khách hàng","Ngày GN","Số tiền","Dư nợ","LS","Đáo hạn","CBTD","Phòng","Khế ước"].map(',
    'o.jsx("tr",{children:(b.kind==="tt"?["Chuyển KH vay mới"]:[]).concat(["Khách hàng","Ngày GN","Số tiền","Dư nợ","LS","Đáo hạn","CBTD","Phòng","Khế ước"]).map(')
rep('.map((L,Q)=>o.jsxs("tr",{children:[o.jsxs("td",{className:"border px-2 py-1",children:[o.jsx("div",{children:L.custnm}),',
    '.map((L,Q)=>o.jsxs("tr",{children:[b.kind==="tt"&&o.jsx("td",{className:"border px-2 py-1 text-center",children:o.jsx("input",{type:"checkbox",checked:!!L.khMoi,onChange:()=>window.__khmToggleTick(L),"data-testid":"khm-tick"})}),o.jsxs("td",{className:"border px-2 py-1",children:[o.jsx("div",{children:L.custnm}),')
rep('o.jsx("div",{className:"max-h-[60vh] overflow-auto",children:o.jsxs("table",{className:"w-full border-collapse text-xs","data-testid":"khm-t-chitiet"',
    'b.kind==="tt"&&o.jsx("div",{className:"text-xs text-muted-foreground",children:"Món giải ngân và tất toán ngay trong kỳ chỉ tính vào Giải ngân. Tick để chuyển món sang KH vay mới (và cầm cố nếu có TSBĐ); bỏ tick để trả về."}),o.jsx("div",{className:"max-h-[60vh] overflow-auto",children:o.jsxs("table",{className:"w-full border-collapse text-xs","data-testid":"khm-t-chitiet"')

rep('24.17.0','24.17.1',s.count('24.17.0'))
open(DST,'w',encoding='utf-8').write(s)
for f in ('app/sw.js','app/manifest.json'):
    t=open(f,encoding='utf-8').read().replace('24.17.0','24.17.1').replace('p44-','p45-')
    open(f,'w',encoding='utf-8').write(t)
print('OK',DST)
