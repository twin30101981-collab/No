/*
 * Bộ kiểm đơn vị QLTDLai — vector mục 6.1 của đề án (chứng từ thật + ca biên).
 * Chạy: bun qltdpro/kiem_thu_p41/test_lai_unit.test.cjs  (hoặc node)
 */
const assert = require("node:assert");
const QLTDLai = require("../nguon_P41/qltd_lai.cjs");

let passed = 0, failed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log("PASS  " + name); }
  catch (e) { failed++; console.log("FAIL  " + name + " — " + e.message); }
}
const D = QLTDLai.parseDate;

/* ── Ca 1 · Chứng từ Agribank 17/04/2026 (Nguyễn Thị Vân Anh): 500.000.000 đ, 8%/năm, 15/04 → 17/04/2026 = 2 ngày; 219.178 đ ── */
test("Ca1 chứng từ Vân Anh 500tr 8% 2 ngày = 219.178 đ", () => {
  const r = { 6: "2026-04-15", 7: "2026-04-17", 8: 8, 11: 500000000, 23: "", 24: "2027-04-15" };
  const k = QLTDLai.tinhLaiKhoan(r, { chot: "2026-04-17" });
  assert.equal(k.ok, true);
  assert.equal(k.soNgayTH, 2);
  assert.equal(k.soNgayQH, 0);
  assert.equal(k.laiTH, 219178);
  assert.equal(k.tong, 219178);
});

/* ── Ca 2 · Chứng từ 980 triệu, LS 8,5%, 5 ngày quá hạn: TH 1.141.096 + phạt 570.548 = đoạn QH 1.711.644 đ ── */
test("Ca2 chứng từ 980tr 8,5% 5 ngày quá hạn = 1.141.096 + 570.548", () => {
  const r = { 6: "2026-09-01", 7: "2026-10-06", 8: "8,5", 11: 980000000, 23: "2026-10-01", 24: "2027-10-06" };
  const k = QLTDLai.tinhLaiKhoan(r, { chot: "2026-10-11" });
  assert.equal(k.ok, true);
  assert.equal(k.soNgayTH, 5);
  assert.equal(k.laiTH, 1141096);
  assert.equal(k.soNgayQH, 5);
  assert.equal(k.laiQHCB, 1141096);
  assert.equal(k.laiQHPhat, 570548);
  assert.equal(k.laiQH, 1711644); // tổng đoạn quá hạn theo quy tắc A
  assert.equal(k.tong, 2852740);
});

/* ── Ca 3 · Ngày giải ngân = ngày trả → 0 ngày; 0 đ ── */
test("Ca3 cùng ngày = 0 ngày 0 đ", () => {
  const r = { 6: "2026-04-10", 7: "2026-05-10", 8: 9, 11: 1000000, 23: "2026-04-10" };
  const k = QLTDLai.tinhLaiKhoan(r, { chot: "2026-04-10" });
  assert.equal(k.ok, true);
  assert.equal(k.soNgayTH, 0);
  assert.equal(k.tong, 0);
});

/* ── Ca 4 · Ngày chốt có giờ: 01/10 → 03/11/2026 chốt 00:00 và 15:00 cùng 33 ngày ── */
test("Ca4 chốt có giờ vẫn 33 ngày (chuẩn hoá Date.UTC)", () => {
  const r = { 6: "2026-10-01", 7: "2026-12-31", 8: 8, 11: 1000000, 23: "" };
  const a = QLTDLai.tinhLaiKhoan(r, { chot: "2026-11-03" });
  const b = QLTDLai.tinhLaiKhoan(r, { chot: new Date(2026, 10, 3, 15, 0) });
  const c = QLTDLai.tinhLaiKhoan(r, { chot: new Date(2026, 10, 3, 0, 0) });
  assert.equal(a.soNgayTH, 33);
  assert.equal(b.soNgayTH, 33);
  assert.equal(c.soNgayTH, 33);
  assert.equal(a.tong, b.tong);
  assert.equal(b.tong, c.tong);
});

/* ── Ca 5 · Năm nhuận: 1 tỷ, 8%, 366 ngày = 80.219.178 đ (chốt quy ước /365) ── */
test("Ca5 năm nhuận 366 ngày vẫn chia 365 = 80.219.178 đ", () => {
  const r = { 6: "2024-01-01", 7: "2026-01-01", 8: 8, 11: 1000000000, 23: "" };
  const k = QLTDLai.tinhLaiKhoan(r, { chot: "2025-01-01" });
  assert.equal(k.soNgayTH, 366);
  assert.equal(k.laiTH, 80219178);
});

/* ── Ca 6 · LS dạng chữ "8,5" và số 8.5 cùng kết quả ── */
test("Ca6 LS dạng chữ '8,5' = 8.5", () => {
  const base = { 6: "2026-09-01", 7: "2026-10-06", 11: 980000000, 23: "2026-10-01" };
  const a = QLTDLai.tinhLaiKhoan({ ...base, 8: "8,5" }, { chot: "2026-10-11" });
  const b = QLTDLai.tinhLaiKhoan({ ...base, 8: 8.5 }, { chot: "2026-10-11" });
  const c = QLTDLai.tinhLaiKhoan({ ...base, 8: "8,5%" }, { chot: "2026-10-11" });
  assert.equal(a.tong, b.tong);
  assert.equal(a.tong, c.tong);
  assert.equal(a.tong, 2852740);
});

/* ── Ca 7 · Thiếu dữ liệu → không tính được, có lý do, không âm thầm ra 0 ── */
test("Ca7a LS rỗng → không tính được", () => {
  const k = QLTDLai.tinhLaiKhoan({ 6: "2026-04-15", 8: "", 11: 500000000, 23: "" }, { chot: "2026-04-17" });
  assert.equal(k.ok, false);
  assert.ok(k.lyDo);
  assert.equal(k.tong, undefined);
});
test("Ca7b LS = 0 → không tính được", () => {
  const k = QLTDLai.tinhLaiKhoan({ 6: "2026-04-15", 8: 0, 11: 500000000 }, { chot: "2026-04-17" });
  assert.equal(k.ok, false);
});
test("Ca7c dư nợ ≤ 0 → không tính được", () => {
  const k = QLTDLai.tinhLaiKhoan({ 6: "2026-04-15", 8: 8, 11: -5 }, { chot: "2026-04-17" });
  assert.equal(k.ok, false);
});
test("Ca7d ngày chốt trước mốc → không tính được", () => {
  const k = QLTDLai.tinhLaiKhoan({ 6: "2026-04-15", 8: 8, 11: 1000000 }, { chot: "2026-04-10" });
  assert.equal(k.ok, false);
});
test("Ca7e thiếu cả r[23] lẫn r[6] → không tính được", () => {
  const k = QLTDLai.tinhLaiKhoan({ 8: 8, 11: 1000000 }, { chot: "2026-04-17" });
  assert.equal(k.ok, false);
});

/* ── Ca 8 · Cảnh báo LS ngoài 0–50% vẫn tính nhưng có cảnh báo ── */
test("Ca8 LS 60% → tính được nhưng cảnh báo", () => {
  const k = QLTDLai.tinhLaiKhoan({ 6: "2026-04-15", 7: "2026-04-17", 8: 60, 11: 100000000 }, { chot: "2026-04-17" });
  assert.equal(k.ok, true);
  assert.ok(k.canhBao.some(c => /50%/.test(c)));
});

/* ── Ca 9 · Q2: quá hạn theo r[7] (khoản giải ngân), KHÔNG theo r[24] ── */
test("Ca9 quá hạn theo r[7], r[24] sớm hơn không ảnh hưởng", () => {
  // r[7] = 01/03/2026, chốt 11/03/2026 → 10 ngày QH; r[24] = 01/01/2026 phải bị bỏ qua
  const r = { 6: "2026-02-01", 7: "2026-03-01", 8: 12, 11: 365000000, 23: "2026-03-01", 24: "2026-01-01" };
  const k = QLTDLai.tinhLaiKhoan(r, { chot: "2026-03-11" });
  assert.equal(k.soNgayTH, 0);
  assert.equal(k.soNgayQH, 10);
  assert.equal(k.laiQH, Math.round(365000000 * 0.12 * 1.5 * 10 / 365));
});

/* ── Ca 10 · Mốc ưu tiên r[23], r[23] hỏng thì về r[6] kèm cảnh báo ── */
test("Ca10 r[23] ưu tiên; r[23] lỗi đọc → dùng r[6] + cảnh báo", () => {
  const a = QLTDLai.tinhLaiKhoan({ 6: "2026-01-01", 7: "2026-12-31", 8: 8, 11: 365000000, 23: "2026-03-01" }, { chot: "2026-03-11" });
  assert.equal(a.soNgayTH, 10); // từ 01/03 theo r[23], không phải 69 ngày từ 01/01
  const b = QLTDLai.tinhLaiKhoan({ 6: "2026-01-01", 7: "2026-12-31", 8: 8, 11: 365000000, 23: "không rõ" }, { chot: "2026-01-11" });
  assert.equal(b.soNgayTH, 10); // về r[6]
  assert.ok(b.canhBao.some(c => /đã thu lãi đến/.test(c)));
});

/* ── Ca 11 · Hệ số quá hạn là tham số (1,5 mặc định; đổi hệ số đổi kết quả) ── */
test("Ca11 hệ số 1,5 mặc định; 2,0 ra khác", () => {
  const r = { 6: "2026-03-01", 7: "2026-03-01", 8: 12, 11: 365000000, 23: "2026-03-01" };
  const a = QLTDLai.tinhLaiKhoan(r, { chot: "2026-03-11" });
  const b = QLTDLai.tinhLaiKhoan(r, { chot: "2026-03-11", heSoQH: 2 });
  assert.equal(a.laiQHPhat, Math.round(365000000 * 0.12 * 0.5 * 10 / 365));
  assert.equal(b.laiQHPhat, Math.round(365000000 * 0.12 * 1 * 10 / 365));
  assert.notEqual(a.laiQH, b.laiQH);
});

/* ── Ca 12 · Làm tròn từng thành phần, tổng = cộng số đã tròn; chuỗi công thức để đối chiếu ── */
test("Ca12 chiTiet có chuỗi công thức khớp số", () => {
  const r = { 6: "2026-09-01", 7: "2026-10-06", 8: "8,5", 11: 980000000, 23: "2026-10-01" };
  const k = QLTDLai.tinhLaiKhoan(r, { chot: "2026-10-11" });
  assert.ok(k.chiTiet.some(s => s.includes("= 1.141.096 đ")));
  assert.ok(k.chiTiet.some(s => s.includes("= 570.548 đ")));
});

/* ── Ca 13 · Lãi chậm trả tách riêng, mặc định tắt trong kết quả chính ── */
test("Ca13 lãi chậm trả tách riêng, không lẫn vào tong", () => {
  const p = QLTDLai.tinhLaiChamTra(100000000, 30, 10);
  assert.equal(p.ok, true);
  assert.equal(p.tien, Math.round(100000000 * 0.1 * 30 / 365)); // 821.918
  const r = { 6: "2026-04-15", 7: "2026-04-17", 8: 8, 11: 500000000 };
  const k = QLTDLai.tinhLaiKhoan(r, { chot: "2026-04-17" });
  assert.ok(!("chamTra" in k)); // mặc định không tính chậm trả
});

/* ── Ca 14 · dd/mm/yyyy đọc được như dữ liệu hiển thị ── */
test("Ca14 ngày dạng dd/mm/yyyy đọc được", () => {
  const r = { 6: "15/04/2026", 7: "17/04/2026", 8: 8, 11: 500000000 };
  const k = QLTDLai.tinhLaiKhoan(r, { chot: "17/04/2026" });
  assert.equal(k.laiTH, 219178);
});

console.log("\n" + passed + "/" + (passed + failed) + " ca đạt");
if (failed > 0) { console.log("CẦN VÁ: " + failed + " ca chưa đạt"); process.exit(1); }
