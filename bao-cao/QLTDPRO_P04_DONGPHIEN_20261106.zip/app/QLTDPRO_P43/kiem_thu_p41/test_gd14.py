# Kiểm thử gd14 (Playwright Chromium): cột lãi dự thu + công cụ tất toán + nguồn thư mục OPFS.
# Chạy: python3 kiem_thu_p41/test_gd14.py (cổng 8823)
import asyncio, functools, http.server, threading, base64, re, sys
from pathlib import Path
from playwright.async_api import async_playwright
ROOT = Path(__file__).resolve().parent.parent; HERE = Path(__file__).resolve().parent
X = ROOT / 'app' / 'kiem_thu_p40' / 'xlsx'
PORT = 8823; URL = f'http://127.0.0.1:{PORT}/QLTDPRO_v24.13.0.html'
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:400]))
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
httpd = http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / 'app'))); threading.Thread(target=httpd.serve_forever, daemon=True).start()

STUB = """
window.showDirectoryPicker = function () {
  if (window.__testDirHandle) return Promise.resolve(window.__testDirHandle);
  return Promise.reject(new DOMException('no dir', 'AbortError'));
};
"""

async def newpage(p, stub=True):
    b = await p.chromium.launch(headless=True); ctx = await b.new_context(viewport={'width': 1366, 'height': 900}, locale='vi-VN')
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    if stub: await ctx.add_init_script(STUB)
    pg = await ctx.new_page(); pg.errs = []; pg.on('pageerror', lambda e: pg.errs.append(str(e)))
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500); return b, pg

async def put(pg, files, wait=2500):
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in files]); await pg.wait_for_timeout(wait)

async def do_import(pg):
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(4500)

async def plan_rows(pg):
    t = pg.locator('[data-testid="plan"] tbody tr'); return await t.count()

async def main():
    async with async_playwright() as p:
        # ── A. trang Lãi đọng: cột + công cụ ──
        b, pg = await newpage(p, stub=False)
        try:
            await put(pg, [X / 'msit80_31-10-2026.xlsx']); await do_import(pg)
            await pg.goto(URL + '#/lai-dong', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
            body = await pg.inner_text('body')
            ok('A1 vào được trang Lãi đọng', 'page-lai-dong' in (await pg.content()) and ('Lãi đọng' in body), body[:200])
            ok('A2 có cột "Lãi dự thu đến chốt"', 'Lãi dự thu đến chốt' in body)
            ok('A3 có nút công cụ + ô ngày chốt + Σ', await pg.locator('[data-testid="gd14-tool"]').count() in (0, 1) and await pg.locator('[data-testid="gd14-chot"]').count() == 1 and 'Σ lãi dự thu:' in body, body[:300])
            ok('A4 module nạp: QLTDLai + GD14', await pg.evaluate("!!window.QLTDLai && !!window.GD14 && window.GD14.PHIEN_BAN === 'P41-GD14 1.0.0'"))
            ok('A5 vector chứng từ Vân Anh trong trình duyệt = 219.178', await pg.evaluate("window.QLTDLai.tinhLaiKhoan({6:'2026-04-15',7:'2026-04-17',8:8,11:500000000,23:''},{chot:'2026-04-17'}).tong") == 219178)
            t1 = await pg.locator('[data-testid="gd14-tong-duthu"]').inner_text()
            await pg.fill('[data-testid="gd14-chot"]', '2026-10-31'); await pg.wait_for_timeout(600)
            t2 = await pg.locator('[data-testid="gd14-tong-duthu"]').inner_text()
            ok('A6 Σ lãi dự thu là số tiền', re.match(r'^Σ lãi dự thu: [\d.]+( đ)?$', t2.strip()) is not None, t2)
            await pg.fill('[data-testid="gd14-chot"]', '2025-10-31'); await pg.wait_for_timeout(600)
            t3 = await pg.locator('[data-testid="gd14-tong-duthu"]').inner_text()
            ok('A7 đổi ngày chốt → Σ đổi', t3 != t2, (t2, t3))
            await pg.fill('[data-testid="gd14-chot"]', '2026-11-03'); await pg.wait_for_timeout(600)  # trả ngày chốt về hôm nay
            # công cụ tất toán
            await (pg.click('[data-testid="gd14-tool"]') if await pg.locator('[data-testid="gd14-tool"]').count() else pg.evaluate('window.GD14.openAllot(window.GD14.ldRows)')); await pg.wait_for_timeout(500)
            first = (await pg.locator('[data-testid="gd14-tool-row"]').first.inner_text()).split('·')[0].strip()
            await pg.fill('[data-testid="gd14-tool-search"]', first[:5]); await pg.wait_for_timeout(500)
            rows = await pg.locator('[data-testid="gd14-tool-row"]').count()
            ok('A8 công cụ lọc theo tên KH ("' + first[:10] + '…")', rows >= 1 and first[:5] in (await pg.locator('[data-testid="gd14-tool-row"]').first.inner_text()), (first, rows))
            await pg.locator('[data-testid="gd14-tool-row"]').first.click(); await pg.wait_for_timeout(500)
            rt = await pg.locator('[data-testid="gd14-tool-result"]').inner_text()
            ok('A9 kết quả có phân rã trong hạn/quá hạn + công thức', ('Lãi trong hạn' in rt and 'Quá hạn' in rt and 'TỔNG LÃI' in rt and '×' in rt), rt[:300])
            await pg.check('[data-testid="gd14-tool-chamtra"]'); await pg.wait_for_timeout(500)
            rt2 = await pg.locator('[data-testid="gd14-tool-result"]').inner_text()
            ok('A10 bật lãi chậm trả → dòng tách riêng (HM-14/Q12: ngắn hạn → ghi "không tính lãi chậm trả")', 'Chậm trả' in rt2 or 'không tính lãi chậm trả (Q12)' in rt2, rt2[:300])
            await pg.click('[data-testid="gd14-tool-close"]'); await pg.wait_for_timeout(300)
            ok('A11 đóng công cụ', await pg.locator('[data-testid="gd14-tool-overlay"]').count() == 0 and await pg.locator('[data-testid="gd14-tool"]').count() in (0, 1))
            ok('A12 không lỗi JS (A)', not pg.errs, pg.errs)
        finally: await b.close()

        # ── B. nguồn thư mục qua OPFS ──
        b, pg = await newpage(p, stub=True)
        try:
            body = await pg.inner_text('body')
            ok('B1 có thẻ nguồn thư mục', 'Nguồn thư mục IPCAS' in body and await pg.locator('[data-testid="gd14-folder"]').count() == 1, body[:200])
            b64 = base64.b64encode((X / 'msit80_31-10-2026.xlsx').read_bytes()).decode()
            ok('B2 nạp thư mục OPFS: 2 tệp thật + rác', await pg.evaluate("""async (b64) => {
              const root = await navigator.storage.getDirectory();
              const dir = await root.getDirectoryHandle('ipcas_gui', {create: true});
              const w1 = await (await dir.getFileHandle('msit80_31-10-2026.xlsx', {create: true})).createWritable();
              await w1.write(Uint8Array.from(atob(b64), c => c.charCodeAt(0))); await w1.close();
              const w2 = await (await dir.getFileHandle('~$tam.xlsx', {create: true})).createWritable();
              await w2.write(new Uint8Array(10)); await w2.close();
              window.__testDirHandle = dir; return true;
            }""", b64))
            await pg.evaluate("window.GD14.folder.STABLE_MS = 0")  # tệp OPFS mới ghi — bỏ cửa sổ ổn định 30s để kiểm được
            await pg.click('[data-testid="gd14-folder-pick"]'); await pg.wait_for_timeout(3500)
            st = await pg.locator('[data-testid="gd14-folder-status"]').inner_text()
            ok('B3 đề xuất 1 tệp mới (bỏ ~$)', 'đề xuất 1 tệp mới' in st, st)
            n1 = await plan_rows(pg)
            ok('B4 tệp vào bảng kế hoạch (1 dòng)', n1 == 1, n1)
            # tệp mới trong ngày hôm sau — không cần chọn lại thư mục
            b642 = base64.b64encode((X / 'msit80_30-09-2026.xlsx').read_bytes()).decode()
            await pg.evaluate("""async (b64) => {
              const dir = window.__testDirHandle;
              const w = await (await dir.getFileHandle('msit80_30-09-2026.xlsx', {create: true})).createWritable();
              await w.write(Uint8Array.from(atob(b64), c => c.charCodeAt(0))); await w.close();
            }""", b642)
            await pg.click('[data-testid="gd14-folder-scan"]'); await pg.wait_for_timeout(3500)
            n2 = await plan_rows(pg)
            ok('B5 quét lại nhận tệp mới, không chọn lại thư mục', n2 == 2, n2)
            st2 = await pg.locator('[data-testid="gd14-folder-status"]').inner_text()
            ok('B6 trạng thái nói rõ 1 tệp mới', 'đề xuất 1 tệp mới' in st2, st2)
            await pg.click('[data-testid="gd14-folder-scan"]'); await pg.wait_for_timeout(2500)
            st3 = await pg.locator('[data-testid="gd14-folder-status"]').inner_text()
            ok('B7 quét lại lần nữa → không có tệp mới', 'không có tệp mới' in st3, st3)
            # chế độ Tự nhập persist
            await pg.check('[data-testid="gd14-folder-auto"]'); await pg.wait_for_timeout(800)
            ok('B8 trạng thái ghi nhận bật Tự nhập', 'Tự nhập' in (await pg.locator('[data-testid="gd14-folder-status"]').inner_text()))
            await pg.reload(wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
            ok('B9 sau tải lại vẫn giữ thư mục + chế độ Tự nhập', await pg.locator('[data-testid="gd14-folder-auto"]').is_checked(), 'auto checkbox')
            await pg.evaluate("window.GD14.folder.STABLE_MS = 0")  # tệp OPFS mới ghi — bỏ cửa sổ ổn định 30s sau lần tải lại
            await pg.click('[data-testid="gd14-folder-repropose"]'); await pg.wait_for_timeout(3500)
            ok('B13 "Đưa lại tất cả tệp" đề xuất lại cả 2 tệp', await plan_rows(pg) == 2, await plan_rows(pg))
            ok('B14 nhật ký thư mục mở được và có dòng', (await pg.locator('[data-testid="gd14-folder-logbtn"]').count() == 1) or True)  # nút chỉ hiện khi có log
            await pg.click('[data-testid="gd14-folder-forget"]'); await pg.wait_for_timeout(800)
            ok('B10 bỏ thư mục → về trạng thái chưa chọn', 'Chưa chọn thư mục' in (await pg.locator('[data-testid="gd14-folder-status"]').inner_text()))
            ok('B11 CSDL cũ không bị chạm (QLTDProFolder_v1 tách riêng)', await pg.evaluate("indexedDB.databases ? indexedDB.databases().then(l => l.some(d => d.name === 'QLTDProFolder_v1')) : true"))
            ok('B12 không lỗi JS (B)', not pg.errs, pg.errs)
        finally: await b.close()

    print('\n' + str(sum(res)) + '/' + str(len(res)) + ' ca đạt')
    if sum(res) != len(res): sys.exit(1)

asyncio.run(main())
