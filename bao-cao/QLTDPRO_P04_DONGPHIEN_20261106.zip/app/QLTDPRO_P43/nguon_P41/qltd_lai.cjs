/*
 * QLTDLai — module tính lãi thuần cho QLTDPRO (lớp gd14, GĐ1 của đề án 03/11/2026).
 * Thuần túy: không DOM, không ghi dữ liệu, không mạng.
 * Quy tắc đã chốt (GĐ0): 365 ngày/năm kể cả năm nhuận; số ngày = chốt − mốc (nguyên ngày,
 * Date.UTC; mốc tính, ngày chốt không tính); mốc = r[23] (đã thu lãi đến) nếu có, không thì r[6]
 * (ngày giải ngân); lãi suất = r[8] (sprd) chuẩn hoá, KHÔNG cộng pnintrt; quá hạn: MỘT hàm
 * duy nhất, đoạn sau đáo hạn tính LS × hệ số (mặc định 1,5 — quy tắc A, tham số có ghi nguồn);
 * ngày đáo hạn xác định quá hạn = r[7] (khoản giải ngân, Q2); làm tròn Math.round từng thành
 * phần của từng khoản, tổng = cộng các số đã tròn; thiếu dữ liệu → "không tính được" kèm lý do.
 * Lãi chậm trả 10%/năm tách riêng, mặc định tắt (chỉ dùng trong công cụ tất toán).
 */
(function (root) {
  "use strict";

  var MS_DAY = 86400000;
  var SO_NGAY_NAM = 365; // quy ước Thông tư 14/2017/TT-NHNN theo chú thích bản cũ — KHÔNG đổi ngầm

  /* ---------- helpers ---------- */

  // "8,5" | "8.5" | "8,5%" | 8.5 → 8.5 ; không đọc được → null
  function normalizeRate(v) {
    if (typeof v === "number") return isFinite(v) ? v : null;
    if (typeof v !== "string") return null;
    var s = v.trim().replace(/\s|%|‰/g, "").replace(/,/g, ".");
    if (!s) return null;
    var n = Number(s);
    return isFinite(n) ? n : null;
  }

  // Chấp nhận "YYYY-MM-DD", "DD/MM/YYYY", "DD-MM-YYYY", "DD.MM.YYYY", Date → UTC nửa đêm; lỗi → null
  function parseDate(v) {
    if (v == null || v === "") return null;
    if (v instanceof Date) {
      return isNaN(v.getTime()) ? null : Date.UTC(v.getFullYear(), v.getMonth(), v.getDate());
    }
    if (typeof v === "number") return null; // số ngày Excel không dùng ở đây
    var s = String(v).trim();
    var m = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(s);
    if (m) return mk(+m[1], +m[2], +m[3]);
    m = /^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})/.exec(s);
    if (m) return mk(+m[3], +m[2], +m[1]); // dd/mm/yyyy
    return null;
  }
  function mk(y, mo, d) {
    if (!(y >= 1900 && y <= 2999 && mo >= 1 && mo <= 12 && d >= 1 && d <= 31)) return null;
    var t = Date.UTC(y, mo - 1, d);
    var c = new Date(t);
    return c.getUTCFullYear() === y && c.getUTCMonth() === mo - 1 && c.getUTCDate() === d ? t : null;
  }
  function todayUTC() {
    var n = new Date();
    return Date.UTC(n.getFullYear(), n.getMonth(), n.getDate());
  }
  function dayDiff(fromUTC, toUTC) {
    return Math.round((toUTC - fromUTC) / MS_DAY); // cả hai đã là UTC nửa đêm
  }

  // 1234567 → "1.234.567" (định dạng Việt, không phụ thuộc locale)
  function fmt(n) {
    var neg = n < 0, s = String(Math.abs(Math.round(n)));
    return (neg ? "-" : "") + s.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  }
  function fmtDec(n) {
    var s = String(n);
    return s.replace(".", ","); // lãi suất hiển thị kiểu 8,1
  }

  /* ---------- lõi tính lãi ---------- */

  /**
   * Tính lãi 1 khoản vay trên bản ghi 27 cột.
   * @param {Array} r  bản ghi: r[6] ngày giải ngân, r[7] đáo hạn khoản vay, r[8] lãi suất (sprd),
   *                   r[11] dư nợ, r[23] đã thu lãi đến, r[24] đáo hạn HĐTD (không dùng khi Q2=r[7])
   * @param {Object} opts { chot: ngày chốt (mặc định hôm nay), heSoQH: hệ số lãi quá hạn (mặc định 1,5) }
   * @returns {ok:true, soNgayTH, laiTH, soNgayQH, laiQHCB, laiQHPhat, laiQH, tong, chiTiet[], canhBao[], ...}
   *          hoặc {ok:false, lyDo, canhBao[]} khi không tính được.
   */
  function tinhLaiKhoan(r, opts) {
    opts = opts || {};
    var canhBao = [];
    var heSo = Number(opts.heSoQH != null ? opts.heSoQH : 1.5);
    if (!(isFinite(heSo) && heSo >= 1)) {
      canhBao.push("Hệ số lãi quá hạn không hợp lệ — dùng mặc định 1,5.");
      heSo = 1.5;
    }

    var duno = Number(r && r[11]);
    if (!isFinite(duno) || duno <= 0) {
      return { ok: false, lyDo: "Dư nợ không đọc được (≤ 0).", canhBao: canhBao };
    }

    var ls = normalizeRate(r && r[8]);
    if (ls == null) return { ok: false, lyDo: "Lãi suất không đọc được.", canhBao: canhBao };
    if (ls <= 0) return { ok: false, lyDo: "Lãi suất bằng 0 — không tính.", canhBao: canhBao };
    if (ls > 50) canhBao.push("Lãi suất " + fmtDec(ls) + "% vượt ngoài 0–50% — kiểm tra lại dữ liệu.");

    // Mốc bắt đầu: r[23] nếu có và đọc được, không thì r[6]
    var moc23 = parseDate(r && r[23]);
    var moc6 = parseDate(r && r[6]);
    var moc, mocNguon;
    if (moc23 != null) { moc = moc23; mocNguon = "đã thu lãi đến"; }
    else if (moc6 != null) { moc = moc6; mocNguon = "ngày giải ngân"; }
    else return { ok: false, lyDo: "Thiếu mốc tính lãi (không có ngày đã thu lãi đến lẫn ngày giải ngân).", canhBao: canhBao };
    if (r && r[23] != null && r[23] !== "" && moc23 == null) {
      canhBao.push("Ngày 'đã thu lãi đến' không đọc được — dùng " + mocNguon + " làm mốc.");
    }

    var chot = parseDate(opts.chot) != null ? parseDate(opts.chot) : todayUTC();
    if (chot < moc) return { ok: false, lyDo: "Ngày chốt (" + opts.chot + ") trước mốc tính lãi.", canhBao: canhBao };

    var soNgay = Math.max(0, dayDiff(moc, chot));

    // Ngày đáo hạn xác định quá hạn: r[7] — đáo hạn khoản giải ngân (Q2)
    var mat = parseDate(r && r[7]);
    var soNgayTH, soNgayQH;
    if (mat == null) {
      soNgayTH = soNgay; soNgayQH = 0;
      canhBao.push("Thiếu ngày đáo hạn khoản vay — coi như chưa quá hạn.");
    } else if (mat <= moc) {
      soNgayTH = 0; soNgayQH = soNgay;
      canhBao.push("Ngày đáo hạn trước mốc tính lãi — toàn bộ số ngày tính đoạn quá hạn, kiểm tra dữ liệu.");
    } else {
      soNgayTH = Math.max(0, Math.min(soNgay, dayDiff(moc, mat)));
      soNgayQH = soNgay - soNgayTH;
    }

    var laiTH = 0, laiQHCB = 0, laiQHPhat = 0, chiTiet = [];
    var dunoF = fmt(duno), lsF = fmtDec(ls) + "%";
    if (soNgayTH > 0) {
      laiTH = Math.round(duno * (ls / 100) * soNgayTH / SO_NGAY_NAM);
      chiTiet.push("Trong hạn: " + dunoF + " × " + lsF + " × " + soNgayTH + "/" + SO_NGAY_NAM + " = " + fmt(laiTH) + " đ");
    }
    if (soNgayQH > 0) {
      laiQHCB = Math.round(duno * (ls / 100) * soNgayQH / SO_NGAY_NAM);
      chiTiet.push("Quá hạn (cơ bản): " + dunoF + " × " + lsF + " × " + soNgayQH + "/" + SO_NGAY_NAM + " = " + fmt(laiQHCB) + " đ");
      laiQHPhat = Math.round(duno * (ls / 100) * (heSo - 1) * soNgayQH / SO_NGAY_NAM);
      chiTiet.push("Phạt lãi quá hạn (" + fmtDec((heSo - 1) * 100) + "%): " + dunoF + " × " + lsF + " × " + fmtDec((heSo - 1)) + " × " + soNgayQH + "/" + SO_NGAY_NAM + " = " + fmt(laiQHPhat) + " đ");
    }
    var laiQH = laiQHCB + laiQHPhat;
    var tong = laiTH + laiQH; // tổng = cộng các thành phần ĐÃ tròn

    return {
      ok: true,
      soNgayTH: soNgayTH, laiTH: laiTH,
      soNgayQH: soNgayQH, laiQH: laiQH, laiQHCB: laiQHCB, laiQHPhat: laiQHPhat,
      tong: tong,
      chiTiet: chiTiet, canhBao: canhBao,
      moc: new Date(moc).toISOString().slice(0, 10), mocNguon: mocNguon,
      chot: new Date(chot).toISOString().slice(0, 10),
      duno: duno, ls: ls, heSoQH: heSo
    };
  }

  /**
   * Lãi chậm trả (tham số 10%/năm, đề án: tách riêng, mặc định TẮT — chỉ dùng trong công cụ tất toán).
   */
  function tinhLaiChamTra(duno, soNgay, tyLeNam) {
    var t = Number(tyLeNam != null ? tyLeNam : 10);
    if (!isFinite(t) || t <= 0) return { ok: false, lyDo: "Tỷ lệ lãi chậm trả không hợp lệ." };
    if (!isFinite(duno) || duno <= 0) return { ok: false, lyDo: "Dư nợ không đọc được." };
    var n = Math.max(0, Math.round(Number(soNgay) || 0));
    if (n === 0) return { ok: true, soNgay: 0, tien: 0, chiTiet: "" };
    var tien = Math.round(duno * (t / 100) * n / SO_NGAY_NAM);
    return {
      ok: true, soNgay: n, tien: tien,
      chiTiet: "Chậm trả: " + fmt(duno) + " × " + fmtDec(t) + "% × " + n + "/" + SO_NGAY_NAM + " = " + fmt(tien) + " đ"
    };
  }

  var api = {
    normalizeRate: normalizeRate,
    parseDate: parseDate,
    dayDiff: dayDiff,
    todayUTC: todayUTC,
    tinhLaiKhoan: tinhLaiKhoan,
    tinhLaiChamTra: tinhLaiChamTra,
    fmt: fmt,
    fmtDec: fmtDec,
    PHIEN_BAN: "P41-GD1-M1 1.0.0"
  };

  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.QLTDLai = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
