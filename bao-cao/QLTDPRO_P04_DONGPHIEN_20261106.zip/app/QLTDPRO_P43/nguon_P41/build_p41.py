#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gói P41: dựng QLTDPRO_v24.13.0.html từ P40 (v24.12.0) — tính lãi (M1) + nguồn thư mục IPCAS (M2).
Quy tắc: chỉ vá theo chuỗi chính xác đếm đúng số lần; nghiệp vụ mới nằm trong khối JS gd14 (sau gd13);
không đổi CSP, không đổi 4 CSDL IndexedDB (handle thư mục lưu CSDL riêng QLTDProFolder_v1), không thêm mạng."""
import io, sys, os

ROOT = os.path.dirname(os.path.abspath(__file__)); APP = os.path.join(ROOT, '..', 'app')
SRC = os.path.join(APP, 'QLTDPRO_v24.12.0.html'); DST = os.path.join(APP, 'QLTDPRO_v24.13.0.html')
def read(p):
    with io.open(p, encoding='utf-8') as f: return f.read()
def write(p, s):
    with io.open(p, 'w', encoding='utf-8', newline='') as f: f.write(s)
def rep(h, old, new, expect=1):
    n = h.count(old)
    if n != expect: sys.exit('ANCHOR FAIL: expect %d, got %d: %r' % (expect, n, old[:90]))
    return h.replace(old, new)

TOOLBAR_ADD = ('...(!r?[o.jsx("button",{"data-testid":"gd14-tool",className:"rounded-md border bg-secondary px-3 py-1.5 text-sm '
 'font-semibold hover:bg-accent",disabled:T,onClick:()=>window.GD14.openAllot(n),children:"\\ud83e\\uddee T\\u00ednh l\\u00e3i t\\u1ea5t to\\u00e1n"}),'
 'o.jsxs("label",{className:"flex items-center gap-1",children:["Ch\\u1ed1t l\\u00e3i \\u0111\\u1ebfn ",'
 'o.jsx("input",{type:"date","data-testid":"gd14-chot",className:"rounded border px-1",value:gd14c,'
 'onChange:F=>{window.GD14.chotSet(F.target.value),gd14s(F.target.value)}})]}),'
 'o.jsxs("span",{"data-testid":"gd14-tong-duthu",className:"font-semibold",'
 'children:["\\u03a3 l\\u00e3i d\\u1ef1 thu: ",window.GD14.fmt(gd14T)]})]:[]),')

def main():
    h = read(SRC)
    # nhãn phiên bản
    h = rep(h, 'children:["v","24.12.0"," · ","2026-11-03"]', 'children:["v","24.13.0"," · ","2026-11-03"]')
    h = rep(h, 'Wk("24.12.0",r)', 'Wk("24.13.0",r)')
    # GĐ2 · M1: trạng thái ngày chốt trong trang Lãi đọng (Fp) — đặt khởi tạo ĐỒNG BỘ trước lần render bảng đầu
    h = rep(h, ',[d,u]=D.useState(null),g=le.dataDate.effective?le.dataDate.effective():new Date,gd7e=',
               ',[d,u]=D.useState(null),[gd14c,gd14s]=D.useState(()=>{const c=window.GD14.chotGet();window.GD14.chotSet(c);return c}),'
               'g=le.dataDate.effective?le.dataDate.effective():new Date,gd7e=')
    # GĐ2 · M1: tổng dự thu + nút công cụ + ô chọn ngày chốt trên thanh công cụ (chỉ trang Lãi đọng, không hiện ở Nợ đến hạn)
    h = rep(h, 'const M=b.reduce((F,A)=>F+(Number(r?A.row[11]:A.row[10])||0),0),I=o.jsxs(o.Fragment,{children:[o.jsxs("label",{className:"flex items-center gap-1",children:[r?"Ngày đến hạn từ":"Đã thu lãi đến từ"," "',
               'const M=b.reduce((F,A)=>F+(Number(r?A.row[11]:A.row[10])||0),0),gd14T=b.reduce((F,A)=>F+(window.GD14.duThuNum(A.row)||0),0),'
               'I=o.jsxs(o.Fragment,{children:[' + TOOLBAR_ADD + 'o.jsxs("label",{className:"flex items-center gap-1",children:[r?"Ngày đến hạn từ":"Đã thu lãi đến từ"," "')
    # GĐ2 · M1: cột "Lãi dự thu đến chốt" (tính lúc hiển thị từ bản ghi đã có — không ghi kho)
    h = rep(h, '{id:"cham",label:"Số ngày chậm lãi",kind:"num",width:100,get:e=>window.GD7.lateDays(e.row[23]),cls:e=>window.GD7.lateCls(e.row[23])},',
               '{id:"cham",label:"Số ngày chậm lãi",kind:"num",width:100,get:e=>window.GD7.lateDays(e.row[23]),cls:e=>window.GD7.lateCls(e.row[23])},'
               '{id:"lai_duthu",label:"Lãi dự thu đến chốt",kind:"num",width:140,get:e=>window.GD14.duThuNum(e.row),sum:!0},')
    # GĐ2 · M1: hiện cột mới theo mặc định của trang Lãi đọng (lead + show)
    h = rep(h, "lead: ['tenkh','cbtd','lai_den','kylai','cham','thu','tt','makh','hdtd','loai','duno','lai'], pin:['tenkh','cbtd','lai_den'], sort:[{id:'lai_den',desc:false}], show:['tenkh','cbtd','lai_den','kylai','cham','thu','tt','makh','hdtd','loai','duno','lai'] }",
               "lead: ['tenkh','cbtd','lai_duthu','lai_den','kylai','cham','thu','tt','makh','hdtd','loai','duno','lai'], pin:['tenkh','cbtd','lai_duthu'], sort:[{id:'lai_den',desc:false}], show:['tenkh','cbtd','lai_duthu','lai_den','kylai','cham','thu','tt','makh','hdtd','loai','duno','lai'] }")
    # khối gd14 = QLTDLai (thuần) + GD14 (glue giao diện + nguồn thư mục), chèn NGAY SAU khối gd13
    js = read(os.path.join(ROOT, 'qltd_lai.cjs')) + '\n' + read(os.path.join(ROOT, 'gd14_ui.js'))
    if '</script' in js.lower(): sys.exit('gd14 chứa </script')
    for bad in ('fetch(', 'XMLHttpRequest', 'WebAssembly', 'eval(', 'new Function'):
        if bad in js: sys.exit('gd14 chứa ' + bad)
    i = h.find('id="gd13-js"'); j = h.find('</script>', i)
    if i < 0 or j < 0: sys.exit('MARKER FAIL gd13-js')
    k = j + len('</script>')
    h = h[:k] + '\n<script id="gd14-js">\n' + js + '\n</script>\n' + h[k:]
    write(DST, h)
    sw = read(os.path.join(APP, 'sw.js'))
    sw = sw.replace('qltdpro-p40-v24.12.0', 'qltdpro-p41-v24.13.0').replace('QLTDPRO_v24.12.0.html', 'QLTDPRO_v24.13.0.html').replace('Service Worker (P40)', 'Service Worker (P41)')
    write(os.path.join(APP, 'sw.js'), sw)
    mf = read(os.path.join(APP, 'manifest.json')); write(os.path.join(APP, 'manifest.json'), mf.replace('QLTDPRO_v24.12.0.html', 'QLTDPRO_v24.13.0.html'))
    print('build OK: %s (%d bytes, +%.1f KB)' % (os.path.basename(DST), os.path.getsize(DST), (os.path.getsize(DST) - os.path.getsize(SRC)) / 1024.0))
if __name__ == '__main__': main()
