# QLTDPRO P42 · v24.15.0 — Máy tính lãi (03/11/2026)
App mới: **app/QLTDPRO_v24.15.0.html** (dựng từ 24.14.0 bằng `nguon_P42_mtl/build_p42_mtl.py`). Trang Lãi đọng /
Nợ đến hạn có nút **🔢 Máy tính lãi**: modal "Máy Tính Lãi — Cơ Sở 365 Ngày" (tra cứu KH / tính tay, bảng khoản
vay ghim cột tên, 4 ô tổng, Copy, Reset). Lãi quá hạn = **LS × 1,5** theo **ngày đến hạn từng khoản GN (r[7])**,
tròn từng khoản rồi cộng; lõi `qltd_lai.cjs` không đổi. Kiểm chứng: mockup **18.532.601 đ**, ca quá hạn
**3.495.890 đ**; Playwright mobile + desktop **80/80** (0 đ sai lệch, 0 lỗi console); lõi 18/18 + 11/11;
hồi quy 86/86; gd14 32/32 (10 ca bỏ qua do Chromium môi trường kiểm sập khi tải lại — xem bàn giao).
Chi tiết: `handover/P42/HANDOVER_v24.15.0_MAY_TINH_LAI.md`.
Kiểm tại chỗ: `node kiem_thu_p42_mtl/test_lai_mtl.test.cjs` · `python3 kiem_thu_p42_mtl/test_may_tinh_lai.py`
· `python3 kiem_thu_p42_mtl/hoi_quy_regress_v24150.py` · `python3 kiem_thu_p42_mtl/hoi_quy_gd14_v24150.py`.

---

# QLTDPRO P42 — gói bàn giao 03/11/2026
App: **QLTDPRO_v24.14.0.html** (đơn tệp, thay đè bản 24.13.0, dữ liệu giữ nguyên).
Nội dung phiên (backlog P41): **(1) quét thư mục con tuỳ chọn** — mặc định mức 1, ô "Bao gồm thư
mục con" (sâu ≤5, bỏ thư mục ẩn, tệp trùng tên ở thư mục khác không chặn lẫn nhau); **(2) cột
"Nguồn"** trong bảng kế hoạch trang Nhập — Thư mục IPCAS / ZIP: ten.zip / ZIP lấy từ thư mục /
Chọn tệp, Kéo thả; **(3) kiểm thêm ZIP từ công cụ khác** — 7-Zip, Info-ZIP, bzip2 (âm: báo rõ),
zip64 (đọc được).
Kiểm chứng: **đơn vị lãi 18/18** · **giao diện + thư mục 42/42** (gồm 26 ca P41 chạy lại) ·
**hồi quy 86/86** (gồm toàn bộ ca P40/P41 chạy lại) · `build_p42.py` tái lập từng byte.
(test_p39 125/125 vẫn chờ file bộ kiểm từ chủ dự án.)
Dùng: chép `app/QLTDPRO_v24.14.0.html` (+ `manifest.json`, `sw.js`) vào vị trí bản cũ. Trang Nhập:
thẻ "Nguồn thư mục IPCAS" có thêm ô "Bao gồm thư mục con"; bảng kế hoạch có cột "Nguồn".
Kiểm tại chỗ: `python3 kiem_thu_p42/test_gd14_p42.py` và `python3 kiem_thu_p42/test_p42_regress.py`
(cần Python + Playwright Chromium). Đơn vị: `node kiem_thu_p41/test_lai_unit.test.cjs`.
Dựng lại: `python3 nguon_P42/build_p42.py`. Toàn vẹn: `cd app && sha256sum -c ../handover/P42/MANIFEST.sha256`.
`tham_chieu_anh_thuc_te/` — ảnh màn hình bản cũ (hsvv_pro) dùng đối chiếu thiết kế thẻ thư mục.

---

# QLTDPRO P48 · v24.17.4 — Địa chỉ trong tra cứu khách hàng của Máy tính lãi (04/11/2026)
App: **app/QLTDPRO_v24.17.4.html** (dựng từ 24.17.3 bằng `nguon_P48/build_p48.py`). Danh sách tìm KH hiện `📍 địa chỉ`,
tìm được theo địa chỉ (mọi từ khoá phải có, không dấu), thẻ KH + Copy có địa chỉ. Kiểm: `python3 kiem_thu_p48/test_dia_chi_mtl.py` 22/22;
hồi quy Máy tính lãi 80/80; lõi 11/11. Chi tiết: `handover/P48/HANDOVER_v24.17.4_DIA_CHI_MAY_TINH_LAI.md`.

---

# QLTDPRO P49 · v24.17.5 — Mã KH copy được ở trang Khách hàng mới (04/11/2026)
App: **app/QLTDPRO_v24.17.5.html** (dựng từ 24.17.4 bằng `nguon_P49/build_p49.py`). Bảng Chi tiết: mã KH dưới tên khách dùng ô chạm-để-copy như các trang khác.
Kiểm: `python3 kiem_thu_p49/test_ma_kh_copy.py` 14/14. Chi tiết: `handover/P49/HANDOVER_v24.17.5_MA_KH_COPY_KH_MOI.md`.

---

# QLTDPRO P50 · v24.17.6 — Cột "Mã KH" riêng ở trang Khách hàng mới (04/11/2026)
App: **app/QLTDPRO_v24.17.6.html** (dựng từ 24.17.5 bằng `nguon_P49/build_p50.py`). Kiểm: `python3 kiem_thu_p49/test_ma_kh_copy.py` 18/18. Chi tiết: `handover/P50/`.

---

# QLTDPRO P51 · v24.17.7 — Mã KH dạng 3201-xxxxxxxxx ở trang Khách hàng mới (04/11/2026)
App: **app/QLTDPRO_v24.17.7.html** (từ 24.17.6 bằng `nguon_P49/build_p51.py`). Kiểm: `kiem_thu_p49/test_ma_kh_copy.py` 20/20. Chi tiết: `handover/P51/`.

---

# QLTDPRO P52 · v24.17.8 — Mã KH dạng 3201-xxxxxxxxx ở MỌI trang, một hàm chung (04/11/2026)
App: **app/QLTDPRO_v24.17.8.html** (từ 24.17.7 bằng `nguon_P49/build_p52.py`). Hàm duy nhất `window.QLTD_maKH`. Kiểm: `python3 kiem_thu_p52/test_ma_kh_moi_trang.py` 14/14. Chi tiết: `handover/P52/`.

---

# QLTDPRO P53 · v24.17.9 — Sửa gốc rễ "Nạp từ Lưu trữ" thiếu doanh số giải ngân (04/11/2026)
App: **app/QLTDPRO_v24.17.9.html** (từ 24.17.8 bằng `nguon_P53/build_p53.py`). Gốc rễ: CSV trung gian bị SheetJS đoán ngày kiểu Mỹ (ngày ≤ 12 bị đảo dd/mm) vì đường đọc của trang Khách hàng mới thiếu `raw:true`. Kiểm: `python3 kiem_thu_p53/test_khm_luu_tru.py` 10/10 (bản 24.17.8 FAIL). Chi tiết: `handover/P53/`.

---

# QLTDPRO P02 (skill) · v24.17.10 — Sao kê TSBĐ dạng văn bản không còn đảo ngày dd/mm (04/11/2026)
App: **app/QLTDPRO_v24.17.10.html** (từ 24.17.9 bằng `nguon_P02/build_p02_hm02.py`, 1 điểm vá: `raw:!0` ở thao tác worker `aoa`). Nạp TSBĐ là CSV/.xls văn bản: ngày ≤ 12 và mã số 0 đầu giữ nguyên như tệp .xlsx.
Kiểm: `python3 kiem_thu_p02/test_hm02_duong_doc.py app/QLTDPRO_v24.17.10.html` 12/12 (v24.17.9: 11/12). Hồi quy chung: `python3 kiem_thu_chung/chay_hoi_quy.py --app app/QLTDPRO_v24.17.10.html` → 766 PASS · 0 FAIL.
Dùng: chép `app/QLTDPRO_v24.17.10.html` + `sw.js` + `manifest.json` đè bản cũ. TSBĐ đã nạp bằng tệp văn bản trước bản này cần **nạp lại**. Hoàn tác: dùng lại v24.17.9 + `sw.js`/`manifest.json` trong ZIP HM-01.

---

# QLTDPRO P02 (skill) · v24.17.11 — Tệp sao kê TSBĐ đuôi .csv được nhận đúng loại (04/11/2026)
App: **app/QLTDPRO_v24.17.11.html** (từ 24.17.10 bằng `nguon_P02/build_p02_hm15.py`, 1 điểm vá: bước dò tiêu đề chạy cả với .csv). Trước đây .csv TSBĐ có tên không chứa "tài sản/TSBĐ" bị nhập như dư nợ.
Kiểm: `python3 kiem_thu_p02/test_hm15_csv_loai.py app/QLTDPRO_v24.17.11.html` 12/12 (v24.17.10: 8/12). Hồi quy chung → PASS 778 · FAIL 0.
Dùng: chép `app/QLTDPRO_v24.17.11.html` + `sw.js` + `manifest.json`. Hoàn tác: ZIP HM-02 (v24.17.10).

---

# QLTDPRO P02 (skill) · HM-11a — Lõi doanh số giải ngân + thu nợ theo cán bộ/phòng (05/11/2026)
Lõi: **nguon_P02/qltd_dstn.cjs** (QLTD_DSTN 1.0.1; chưa gắn vào app — HM-11b). Kiểm: `node kiem_thu_p02/test_hm11_dstn.test.cjs` 21/21.
Đối soát từ tệp msit80 (mỗi tệp một mốc, tên dd.mm.yyyy.xls/xlsx): `python3 -I kiem_thu_p02/doc_mis80.py <thư mục> tam.pkl` rồi
`python3 -I kiem_thu_p02/doi_chieu_mis80.py tam.pkl nguon_P02/qltd_dstn.cjs <thư mục ra>` → Excel theo Phòng / Cán bộ / Khế ước, kèm đối chiếu Python độc lập.
