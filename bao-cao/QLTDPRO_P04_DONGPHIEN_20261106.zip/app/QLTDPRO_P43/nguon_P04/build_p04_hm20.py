# P04 · HM-20 · v24.17.21 — Chỉ tiêu kế hoạch.
#  Q14: "Đầu kỳ" = số dư cuối kỳ trước → nhãn mốc ghi đúng kỳ + ngày số dư (30/09 = Đầu Q4; 31/10 = Đầu T11);
#       cột "Δ so Đầu tháng" so với số dư cuối tháng TRƯỚC (trước: tìm mốc cuối tháng hiện tại, thường chưa có).
#  Q13: dòng Tổng phòng / tab Theo phòng gom dư nợ theo phòng ghi trên khế ước (trctnm r[17]); trống → danh mục cán bộ.
#  gd20 1.0.0: nhóm chỉ tiêu, chỉ Live/%HT, Δ so mốc, ẩn chỉ tiêu toàn 0, cột tên dính, thẻ điện thoại (chỉ trình bày).
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P04/build_p04_hm20.py
import hashlib
SRC = 'app/QLTDPRO_v24.17.20.html'; DST = 'app/QLTDPRO_v24.17.21.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:80]); s = s.replace(old, new)
# Q14 — nhãn
rep('for(let i=1;i<=4;i++)a({id:`q${e}_${i}`,label:`Đầu Q${i}/${e}`,kind:"quarter",year:e,quarter:i});',
    'for(let i=1;i<=4;i++)a({id:`q${e}_${i}`,label:i<4?`Đầu Q${i+1}/${e} (số dư ${["31/03","30/06","30/09"][i-1]}/${e})`:`Cuối Q4/${e}`,kind:"quarter",year:e,quarter:i});')
rep('for(let i=1;i<=12;i++)a({id:`m${e}_${i}`,label:`Đầu T${String(i).padStart(2,"0")}/${e}`,kind:"month",year:e,month:i});',
    'for(let i=1;i<=12;i++)a({id:`m${e}_${i}`,label:i<12?`Đầu T${String(i+1).padStart(2,"0")}/${e} (số dư ${new Date(e,i,0).getDate()}/${String(i).padStart(2,"0")}/${e})`:`Cuối T12/${e}`,kind:"month",year:e,month:i});')
rep('short:`Đầu Q${d} (quý trước)`', 'short:`Đầu Q${i} (số dư cuối Q${d})`', 2)
rep('short:`Đầu Q4/${e-1} (quý trước)`', 'short:`Đầu Q1/${e} (số dư cuối Q4/${e-1})`')
rep('c&&s.push({...c,short:`Đầu Q${i} (quý này)`});', 'c&&s.push({...c,short:`Cuối Q${i} (số dư cuối quý này)`});')
rep('const h=r.filter(d=>d.kind==="month"&&d.year===e&&d.month===a&&d.hasData)[0];return h&&s.push({...h,short:"Đầu tháng"}),s}',
    'const h=a>1?r.filter(d=>d.kind==="month"&&d.year===e&&d.month===a-1&&d.hasData)[0]:null;return h&&s.push({...h,short:`Đầu T${String(a).padStart(2,"0")} (số dư cuối T${String(a-1).padStart(2,"0")})`}),s}')
# Q13 — gom phòng theo khế ước
rep('return{R:e,canon:t,phongOfCbtd:a=>{if(!a)return null;const i=t(a);for(const s of n)if(s.names.has(i))return s.key;return null}}}',
    'return{R:e,canon:t,phongOfCbtd:a=>{if(!a)return null;const i=t(a);for(const s of n)if(s.names.has(i))return s.key;return null},phongOfRow:c=>{const p=gr(c&&c[17]);if(p){for(const f of fn)if(gr(f.pb)===p)return f.key}const a=String(c&&c[12]||"").trim();if(!a)return null;const i=t(a);for(const s of n)if(s.names.has(i))return s.key;return null}}}')
rep('r.kind==="phong"&&r.id&&n.phongOfCbtd(h)!==r.id', 'r.kind==="phong"&&r.id&&(n.phongOfRow?n.phongOfRow(c):n.phongOfCbtd(h))!==r.id')
JS = open('nguon_P04/gd20.js', encoding='utf-8').read(); assert '</script' not in JS.lower()
CSS = '''<style id="gd20-css">
.gd20-bar{display:flex;flex-direction:column;gap:6px;margin:6px 0;padding:8px 10px;border:1px solid #C9D8EA;border-radius:8px;background:#EEF4FB;font-size:12.5px}
.gd20-row{display:flex;flex-wrap:wrap;gap:6px 10px;align-items:center}
.gd20-chip{border:1px solid #1F4E79;border-radius:999px;background:#fff;color:#1F4E79;font-weight:700;font-size:12px;padding:4px 12px;min-height:30px;cursor:pointer}
.gd20-chip.on{background:#1F4E79;color:#fff}
.gd20-ck{display:inline-flex;align-items:center;gap:4px;min-height:30px}.gd20-ck input{width:18px;height:18px}
.gd20-note{font-size:11.5px;color:#475569}
table.gd20-t .gd20-x{width:0!important;min-width:0!important;max-width:0!important;padding:0!important;border:0!important;overflow:hidden}
table.gd20-t .gd20-x,table.gd20-t .gd20-x *{font-size:0!important;line-height:0!important}
table.gd20-t tbody td:first-child,table.gd20-t thead tr:first-child th:first-child{position:sticky;left:0;z-index:3;background:hsl(var(--card,0 0% 100%));box-shadow:2px 0 0 #cbd5e1}
table.gd20-t thead tr:first-child th:first-child{z-index:5;background:hsl(var(--secondary,214 32% 91%))}
table.gd20-t tbody tr.gd20-r td:first-child{min-width:150px;max-width:210px;white-space:normal}
@media (max-width:600px){
.gd20-chip,.gd20-ck{min-height:40px}
table.gd20-t,table.gd20-t tbody{display:block;width:100%!important;min-width:0!important}
table.gd20-t thead{display:block;height:0;overflow:hidden}
table.gd20-t tbody tr{display:block;border:1px solid #cbd5e1;border-radius:10px;margin:0 0 8px;background:#fff}
table.gd20-t tbody tr td{display:flex;justify-content:space-between;gap:8px;border:0!important;border-bottom:1px solid #eef2f7!important;text-align:right;position:static!important;box-shadow:none!important;max-width:none!important;white-space:normal}
table.gd20-t tbody tr.gd20-r td:first-child{font-weight:800;background:#EEF4FB}
table.gd20-t tbody tr td::before{content:attr(data-lb);font-weight:600;color:#475569;font-size:11px;text-align:left;flex:0 0 55%}
table.gd20-t tbody tr td.gd20-x{display:block;height:0}
table.gd20-t tbody tr td.gd20-x::before{content:none}
}
</style>
'''
assert s.count('<style id="gd19-l07-css">') == 1
s = s.replace('<style id="gd19-l07-css">', CSS + '<style id="gd19-l07-css">')
s = s.replace('<script id="gd19-l07-js">', '<script id="gd20-js">\n' + JS + '\n</script>\n<script id="gd19-l07-js">', 1)
c = s.count('"24.17.20"'); assert c == 2, c
s = s.replace('"24.17.20"', '"24.17.21"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.20' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.20', '24.17.21'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
