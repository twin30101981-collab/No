/* gd20 1.1.0 — HM-20 (P04): bảng Chỉ tiêu kế hoạch (Theo CBTD / Theo phòng / Theo loại vay) dễ theo dõi.
 * CHỈ trình bày: không đổi số, không đổi cấu trúc React (không sửa colSpan); cột ẩn = thu về 0 px (lớp gd20-x)
 * để nội dung ô giữ nguyên. Chọn nhóm chỉ tiêu, chỉ Live/%HT, bật Δ so mốc, ẩn chỉ tiêu toàn 0; cột tên dính; thẻ trên điện thoại. */
(function () {
  "use strict";
  var KEY = "gd20_ctkh";
  var NHOM = [
    { id: "duno", ten: "Dư nợ", ct: ["Tổng dư nợ", "DN Ngắn hạn", "DN Trung hạn", "DN Dài hạn", "DN Thấu chi", "DN Doanh nghiệp"] },
    { id: "von", ten: "Nguồn vốn", ct: ["Nguồn vốn"] },
    { id: "khthe", ten: "KH & thẻ", ct: ["SL KH", "Thẻ ghi nợ", "Thẻ Lộc Việt"] },
    { id: "dv", ten: "Dịch vụ", ct: ["DT Dịch vụ", "DT ABIC"] },
    { id: "all", ten: "Tất cả", ct: null }
  ];
  function load() { var d = { nhom: "duno", live: false, delta: false, an0: true }; try { var v = JSON.parse(localStorage.getItem(KEY) || "null"); if (v) for (var k in d) if (v[k] != null) d[k] = v[k]; } catch (e) {} return d; }
  var ST = load();
  function save() { try { localStorage.setItem(KEY, JSON.stringify(ST)); } catch (e) {} }
  function E(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  function cells(tr) { return tr ? Array.prototype.slice.call(tr.children) : []; }
  function soO(td) { var t = (td && td.textContent || "").replace(/[^\d,-]/g, ""); return t === "" || /^[-0,]*$/.test(t); }

  function apply(tb) {
    var th = tb.tHead; if (!th || th.rows.length < 3) return;
    var r1 = cells(th.rows[0]), r2 = cells(th.rows[1]), r3 = cells(th.rows[2]);
    var N = r2.filter(function (c) { return c.colSpan === 3; }).length; if (!N) return;
    var R = Math.max(0, r1.length - 2);
    var ten = r2.slice(0, N).map(function (c) { return c.textContent.trim(); });
    var mocTen = r1.slice(2).map(function (c) { return c.textContent.replace(/^Δ so\s*/, "").trim(); });
    var body = tb.tBodies[0] ? Array.prototype.slice.call(tb.tBodies[0].rows) : [];
    var data = body.filter(function (tr) { return tr.children.length === 1 + 3 * N + R * N; });
    var g = NHOM.filter(function (x) { return x.id === ST.nhom; })[0] || NHOM[0];
    var zero = ten.map(function (_, j) { return data.length > 0 && data.every(function (tr) { var c = tr.children; return soO(c[1 + 3 * j]) && soO(c[2 + 3 * j]); }); });
    var vis = ten.map(function (t, j) { return (!g.ct || g.ct.indexOf(t) >= 0) && !(ST.an0 && zero[j]); });
    var nVis = vis.filter(Boolean).length;
    var showMain = function (t) { var j = Math.floor(t / 3), p = t % 3; return vis[j] && !(ST.live && p === 0); };
    var showD = function (u) { return ST.delta && vis[u % N]; };
    var set = function (el, on, lb) { if (!el) return; el.classList.toggle("gd20-x", !on); if (lb != null && !el.hasAttribute("data-lb")) el.setAttribute("data-lb", lb); };
    var part = ["KH", "Live", "%HT"];
    set(r1[1], nVis > 0);
    r1.slice(2).forEach(function (c) { set(c, ST.delta && nVis > 0); });
    r2.forEach(function (c, t) { if (t < N) set(c, vis[t]); else set(c, showD(t - N)); });
    r3.forEach(function (c, t) { if (t < 3 * N) set(c, showMain(t)); else set(c, showD(t - 3 * N)); });
    data.forEach(function (tr) {
      var c = tr.children;
      for (var t = 0; t < 3 * N; t++) set(c[1 + t], showMain(t), ten[Math.floor(t / 3)] + " · " + part[t % 3]);
      for (var u = 0; u < R * N; u++) set(c[1 + 3 * N + u], showD(u), "Δ " + ten[u % N] + " so " + (mocTen[Math.floor(u / N)] || ""));
      if (c[0] && !c[0].hasAttribute("data-lb")) c[0].setAttribute("data-lb", "");
      tr.classList.add("gd20-r");
    });
    tb.classList.add("gd20-t");
    tb.setAttribute("data-gd20", [ST.nhom, ST.live ? 1 : 0, ST.delta ? 1 : 0, ST.an0 ? 1 : 0, nVis, zero.filter(Boolean).length].join("|"));
    bar(tb, ten, zero, R, mocTen);
  }

  function bar(tb, ten, zero, R, mocTen) {
    var host = tb.parentElement; while (host && host.parentElement && !/overflow/.test(getComputedStyle(host).overflowX + getComputedStyle(host).overflow)) host = host.parentElement;
    var wrap = host && host.parentElement ? host : tb.parentElement;
    var id = tb.getAttribute("data-testid");
    var b = wrap.parentElement.querySelector('[data-gd20-bar="' + id + '"]');
    var sig = JSON.stringify([ST, zero, R]);
    if (b && b.getAttribute("data-sig") === sig) return;
    if (!b) { b = E("div", "gd20-bar"); b.setAttribute("data-gd20-bar", id); b.setAttribute("data-testid", "gd20-bar"); wrap.parentElement.insertBefore(b, wrap); }
    b.setAttribute("data-sig", sig); b.innerHTML = "";
    var row = E("div", "gd20-row");
    row.appendChild(E("b", null, "Nhóm chỉ tiêu:"));
    NHOM.forEach(function (n) {
      var x = E("button", "gd20-chip" + (ST.nhom === n.id ? " on" : ""), n.ten); x.type = "button";
      x.setAttribute("data-testid", "gd20-nhom-" + n.id); x.setAttribute("aria-pressed", String(ST.nhom === n.id));
      x.addEventListener("click", function () { ST.nhom = n.id; save(); all(); });
      row.appendChild(x);
    });
    b.appendChild(row);
    var row2 = E("div", "gd20-row");
    [["live", "Chỉ Live / %HT (ẩn cột KH)"], ["delta", "Δ so mốc" + (R ? " (" + mocTen.join("; ") + ")" : " (chưa có mốc)")], ["an0", "Ẩn chỉ tiêu toàn 0"]].forEach(function (o) {
      var l = E("label", "gd20-ck"), c = E("input"); c.type = "checkbox"; c.checked = !!ST[o[0]]; c.setAttribute("data-testid", "gd20-" + o[0]);
      c.addEventListener("change", function () { ST[o[0]] = c.checked; save(); all(); });
      l.appendChild(c); l.appendChild(document.createTextNode(" " + o[1])); row2.appendChild(l);
    });
    var nz = zero.filter(Boolean).length;
    if (ST.an0 && nz) row2.appendChild(E("span", "gd20-note", "Đang ẩn " + nz + " chỉ tiêu toàn 0: " + ten.filter(function (_, j) { return zero[j]; }).join(", ")));
    b.appendChild(row2);
    if (id === "ct-grid-cbtd" || id === "ct-grid-phong")
      b.appendChild(E("div", "gd20-note", "ⓘ Cán bộ xếp theo phòng GIỐNG tab Báo cáo ngày (danh mục cán bộ); dư nợ mỗi cán bộ = các khế ước có tên cán bộ đó (ofcnm); dòng \"Tổng <phòng>\" = cộng các cán bộ của phòng."));
  }

  function all() { Array.prototype.forEach.call(document.querySelectorAll('table[data-testid^="ct-grid-"]'), function (t) { try { apply(t); } catch (e) {} }); }
  function go() {
    var q = false;
    new MutationObserver(function () { if (q) return; q = true; requestAnimationFrame(function () { q = false; all(); }); })
      .observe(document.body, { childList: true, subtree: true, characterData: true });
    all();
  }
  window.__gd20 = { all: all, st: function () { return ST; }, PHIEN_BAN: "1.1.0" };
  if (document.body) go(); else document.addEventListener("DOMContentLoaded", go);
})();
