# P04 · HM-20b · v24.17.22 — người dùng 05/11: Chỉ tiêu kế hoạch xếp cán bộ theo phòng GIỐNG Báo cáo ngày.
#  Dòng Tổng phòng / tab Theo phòng / Δ theo phòng: trở lại gom theo phòng của cán bộ trong danh mục (phongOfCbtd) — như
#  Báo cáo ngày (P3: phòng = Σ cán bộ thuộc phòng theo danh mục). Thay cách gom theo trctnm của v24.17.21 (Q13 cũ).
#  Nhãn mốc Q14 và lớp gd20 giữ nguyên (gd20 1.1.0: chỉ đổi ghi chú).
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P04/build_p04_hm20b.py
import hashlib, re
SRC = 'app/QLTDPRO_v24.17.21.html'; DST = 'app/QLTDPRO_v24.17.22.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:80]); s = s.replace(old, new)
rep('r.kind==="phong"&&r.id&&(n.phongOfRow?n.phongOfRow(c):n.phongOfCbtd(h))!==r.id', 'r.kind==="phong"&&r.id&&n.phongOfCbtd(h)!==r.id')
m = re.search(r'<script id="gd20-js">\n(.*?)\n</script>', s, re.S); assert m
s = s[:m.start(1)] + open('nguon_P04/gd20.js', encoding='utf-8').read() + s[m.end(1):]
c = s.count('"24.17.21"'); assert c == 2, c
s = s.replace('"24.17.21"', '"24.17.22"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.21' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.21', '24.17.22'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
