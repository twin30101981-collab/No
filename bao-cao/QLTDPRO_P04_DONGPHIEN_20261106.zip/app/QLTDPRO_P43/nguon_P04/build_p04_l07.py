# P04 · L-07 (HM-19 phần bảng trang Lãi đọng) + sửa 1 dòng giá đất · v24.17.20
#  1. Bộ cột mặc định trang Lãi đọng 8 cột vừa 1366 (Tên KH, CBTD, Đã thu lãi đến, Số ngày chậm lãi, Lãi đọng IPCAS,
#     Lãi dự thu, Dư nợ, Đã thu); 5 cột còn lại ở "Cột ▾". Áp một lần cho bố cục đã lưu trước đó (cờ l07), bảng khác không đổi.
#  2. Hàng lọc từng cột ẩn mặc định, gom vào nút "🔍 Lọc theo cột (n)"; tự hiện khi đang có bộ lọc.
#  3. Nút/ô trang Lãi đọng ≥ 28 px (điện thoại ≥ 40 px).
#  4. Phân cấp dòng theo số ngày chậm lãi (so ngày dữ liệu): 1–30 vàng, 31–90 cam, > 90 đỏ (vạch trái + đậm);
#     bỏ tô chữ đỏ cả dòng của gd7 trên trang này (nền cảnh báo gốc quá hạn / nhóm ≥ 3 giữ nguyên).
#  5. Giá đất: Phường Nam Định STT 212 Đường Vũ Xuân Thiều — TB VT1 28.000 → 55.000, VT2 16.800 → 33.000
#     (= (cao + thấp)/2; lỗi gõ ở PL02 báo cáo tư vấn 275/2026, xem evidence/gia_dat/BAO_CAO.md).
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P04/build_p04_l07.py
import hashlib
SRC = 'app/QLTDPRO_v24.17.19.html'; DST = 'app/QLTDPRO_v24.17.20.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:80]); s = s.replace(old, new)
rep("  'lai-dong':         { lead: ['tenkh','cbtd','lai_duthu','lai_den','kylai','cham','thu','tt','makh','hdtd','loai','duno','lai'], pin:['tenkh','cbtd','lai_duthu'], sort:[{id:'lai_den',desc:false}], show:['tenkh','cbtd','lai_duthu','lai_den','kylai','cham','thu','tt','makh','hdtd','loai','duno','lai'] },",
    "  'lai-dong':         { lead: ['tenkh','cbtd','lai_den','cham','lai','lai_duthu','duno','thu','kylai','tt','makh','hdtd','loai'], pin:['tenkh'], sort:[{id:'lai_den',desc:false}], show:['tenkh','cbtd','lai_den','cham','lai','lai_duthu','duno','thu'] },")
rep("  if (c.show) def.hidden = ids.filter(function(x){ return c.show.indexOf(x) < 0; });",
    "  if (c.show) def.hidden = ids.filter(function(x){ return c.show.indexOf(x) < 0; });\n  if (id === 'lai-dong') def.l07 = 1;")
rep("var ok = saved && typeof saved === 'object' && saved.gd7 === REV ? saved : null;",
    "var ok = saved && typeof saved === 'object' && saved.gd7 === REV ? saved : null;\n  if (ok && id === 'lai-dong' && !ok.l07) ok = null; /* L-07: bộ cột mặc định mới áp một lần */")
rep('rowClass:F=>F.dathu?"opacity-60":F===d?"[&>div]:bg-info/10":"",',
    'rowClass:F=>(F.dathu?"opacity-60":F===d?"[&>div]:bg-info/10":"")+(r?"":" gd19-l"+(x=>x==null?0:x>90?3:x>30?2:x>0?1:0)(window.GD7.lateDays(F.row[23]))),')
rep('["212","Đường Vũ Xuân Thiều","Đường Vũ Xuân Thiều","Cuối đường",6e4,5e4,28e3,36e3,3e4,16800,',
    '["212","Đường Vũ Xuân Thiều","Đường Vũ Xuân Thiều","Cuối đường",6e4,5e4,55e3,36e3,3e4,33e3,')
JS = r'''<script id="gd19-l07-js">
/* L-07: nút "Lọc theo cột" trang Lãi đọng — chỉ bật/tắt hiển thị hàng lọc của bảng (không đổi dữ liệu, không đổi bộ lọc) */
(function () {
  function sync() {
    var pg = document.querySelector('[data-testid="page-lai-dong"]'); if (!pg) return;
    var cot = pg.querySelector('[data-testid="dt-cot-btn"]'); if (!cot) return;
    var n = Array.prototype.filter.call(pg.querySelectorAll('[data-testid="dt-filter"]'), function (x) { return x.value; }).length;
    var b = pg.querySelector('[data-testid="gd19-loc-btn"]');
    if (!b) {
      b = document.createElement('button'); b.type = 'button'; b.setAttribute('data-testid', 'gd19-loc-btn');
      b.className = cot.className;
      b.addEventListener('click', function () { var p = document.querySelector('[data-testid="page-lai-dong"]'); if (p) { p.setAttribute('data-loc', p.getAttribute('data-loc') === '1' ? '0' : '1'); sync(); } });
      cot.parentNode.insertBefore(b, cot);
    }
    var on = pg.getAttribute('data-loc') === '1' || n > 0;
    var t = (on ? '▾ ' : '🔍 ') + 'Lọc theo cột' + (n ? ' (' + n + ')' : '');
    if (b.textContent !== t) b.textContent = t;
    if (b.getAttribute('aria-pressed') !== String(on)) b.setAttribute('aria-pressed', String(on));
    if (n > 0 && pg.getAttribute('data-loc') !== '1') pg.setAttribute('data-loc', '1');
  }
  function go() {
    var q = false;
    new MutationObserver(function () { if (q) return; q = true; requestAnimationFrame(function () { q = false; try { sync(); } catch (e) {} }); })
      .observe(document.body, { childList: true, subtree: true });
    document.addEventListener('input', function (e) { if (e.target && e.target.getAttribute && e.target.getAttribute('data-testid') === 'dt-filter') sync(); }, true);
  }
  if (document.body) go(); else document.addEventListener('DOMContentLoaded', go);
})();
</script>
'''
CSS = '''<style id="gd19-l07-css">
[data-testid="page-lai-dong"]:not([data-loc="1"]) .sticky.top-0 > div.flex:has([data-testid="dt-filter"]){display:none}
[data-testid="page-lai-dong"] button,[data-testid="page-lai-dong"] select,[data-testid="page-lai-dong"] input:not([type=checkbox]):not(.gd7-native),[data-testid="page-lai-dong"] .gd7-date button{min-height:28px}
[data-testid="page-lai-dong"] [data-testid="dt-row"] button,[data-testid="page-lai-dong"] [data-testid="dt-row"] select{min-height:0}
[data-testid="page-lai-dong"] [data-testid="gd19-loc-btn"][aria-pressed="true"]{background:#1F4E79;color:#fff}
[data-testid="page-lai-dong"] [data-testid="dt-row"].gd7-row-red > div[data-c]:not(.gd7-d-over):not(.gd7-d-7):not(.gd7-d-15):not(.gd7-d-30):not(.gd7-bad),
[data-testid="page-lai-dong"] [data-testid="dt-row"].gd7-row-red > div[data-c]:not(.gd7-d-over):not(.gd7-d-7):not(.gd7-d-15):not(.gd7-d-30):not(.gd7-bad) *{color:hsl(var(--foreground,215 45% 14%)) !important}
[data-testid="page-lai-dong"] [data-testid="dt-row"].gd19-l1 > div:first-child{box-shadow:inset 4px 0 0 #E8B931}
[data-testid="page-lai-dong"] [data-testid="dt-row"].gd19-l2 > div:first-child{box-shadow:inset 4px 0 0 #E8762C}
[data-testid="page-lai-dong"] [data-testid="dt-row"].gd19-l3 > div:first-child{box-shadow:inset 4px 0 0 #B42318}
[data-testid="page-lai-dong"] [data-testid="dt-row"].gd19-l3 > div[data-c="tenkh"]{font-weight:700}
@media (max-width:600px){[data-testid="page-lai-dong"] button,[data-testid="page-lai-dong"] select,[data-testid="page-lai-dong"] input:not([type=checkbox]):not(.gd7-native),[data-testid="page-lai-dong"] .gd7-date button,[data-testid="page-lai-dong"] .gd7-date input{min-height:40px}
[data-testid="page-lai-dong"] [data-testid="dt-row"] button,[data-testid="page-lai-dong"] [data-testid="dt-row"] select{min-height:0}}
</style>
'''
assert s.count('<style id="gd14-hm19-css">') == 1
s = s.replace('<style id="gd14-hm19-css">', CSS + '<style id="gd14-hm19-css">')
assert s.count('<script id="gd14-js">') == 1
s = s.replace('<script id="gd14-js">', JS + '<script id="gd14-js">')
c = s.count('"24.17.19"'); assert c == 2, c
s = s.replace('"24.17.19"', '"24.17.20"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.19' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.19', '24.17.20'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
