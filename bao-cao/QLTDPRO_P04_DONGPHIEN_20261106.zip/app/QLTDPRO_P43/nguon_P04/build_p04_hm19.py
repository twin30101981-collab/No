# P04 · HM-19 + HM-13 · v24.17.19 — Máy tính lãi & Lãi đọng: một lối vào, bảng Gọn ≤ 9 cột (nút Đầy đủ), tổng dính đầu,
# thẻ trên điện thoại, danh sách tìm có số khế ước + ngày đến hạn, bảng phân rã lãi, ghi chú nguồn 3 tổng trang Lãi đọng.
# Chỉ đổi trình bày (số lấy từ QLTDLai.hm14 như v24.17.18). Lõi qltd_lai.cjs giữ byte.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P04/build_p04_hm19.py
import re, hashlib
SRC = 'app/QLTDPRO_v24.17.18.html'; DST = 'app/QLTDPRO_v24.17.19.html'
s = open(SRC, encoding='utf-8').read()
core = open('nguon_P41/qltd_lai.cjs', encoding='utf-8').read().rstrip('\n')
frag = open('nguon_P04/gd14_hm19.js', encoding='utf-8').read(); assert '</script' not in frag.lower()
def reps(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('bundle anchor', c, n, old[:90]); s = s.replace(old, new)
# 1. Bundle: bỏ nút "Tính lãi tất toán" (một lối vào); lưu dòng cho API cũ GD14.openAllot (bộ kiểm cũ)
BTN = 'o.jsx("button",{"data-testid":"gd14-tool",className:"rounded-md border bg-secondary px-3 py-1.5 text-sm font-semibold hover:bg-accent",disabled:T,onClick:()=>window.GD14.openAllot(n),children:"\\ud83e\\uddee T\\u00ednh l\\u00e3i t\\u1ea5t to\\u00e1n"}),'
reps(BTN, '')
reps('gd14T=b.reduce((F,A)=>F+(window.GD14.duThuNum(A.row)||0),0),', 'gd14T=b.reduce((F,A)=>F+(window.GD14.duThuNum(A.row)||0),0),gd14R=(window.GD14.ldRows=n),')
m = re.search(r'<script id="gd14-js">\n?(.*?)</script>', s, re.S); g = m.group(1); assert core in g
def rep(old, new, n=1):
    global g
    c = g.count(old); assert c == n, ('anchor count', c, n, old[:90]); g = g.replace(old, new)
rep('  function openCalc(rows, opts) {', frag + '  function openCalc(rows, opts) {')
rep('    if (C.tab === "kh") renderKH(bd); else renderTay(bd);', '    if (C.tab === "kh") { renderKH(bd); hm19Layout(bd); } else renderTay(bd);')
rep('    bd.appendChild(el("div", { cls: "g14c-fm" }, [', '    bd.appendChild(el("div", { cls: "g14c-fm" + (C.tab === "kh" && C.cust ? " mini" : "") }, [')
rep('''        lk.push(el("span", { cls: "adr", "data-testid": "gd14-calc-hit-addr", text: c.dc ? "📍 " + c.dc : "📍 (chưa có địa chỉ)" }));''',
    '''        lk.push(el("span", { cls: "adr", "data-testid": "gd14-calc-hit-addr", text: c.dc ? "📍 " + c.dc : "📍 (chưa có địa chỉ)" }));
        lk.push(el("span", { cls: "adr ku", "data-testid": "gd14-calc-hit-ku", text: hm19Ku(c) }));''')
s = s[:m.start(1)] + g + s[m.end(1):]
CSS = '''<style id="gd14-hm19-css">
.g14c-fm.mini{padding:4px 10px;margin-bottom:6px}.g14c-fm.mini small,.g14c-fm.mini b{display:none}.g14c-fm.mini code{font-size:12px}
.g14c-sum{position:sticky;top:-12px;z-index:6;box-shadow:0 2px 6px rgba(15,42,74,.15);margin-bottom:8px}
.g14c-res .ku{color:#1F4E79}
.g14c-pn .g14c-t.cmp .x{width:0!important;min-width:0!important;max-width:0!important;padding:0!important;border:0!important;overflow:hidden;box-shadow:none!important}.g14c-pn .g14c-t.cmp .x,.g14c-pn .g14c-t.cmp .x *{font-size:0!important;line-height:0!important}.g14c-t:not(.cmp) .y{display:none!important}
.g14c-pn .g14c-t.cmp th small{font-size:0!important;line-height:0}.g14c-t.cmp td{white-space:normal}.g14c-t td .sm.y{display:block}
.g14c-t .qhv{color:#b91c1c;font-weight:700}
.g14c-t.cmp .s0{position:static}
.g14c-t.cmp{min-width:0}.g14c-pn .g14c-t.cmp td,.g14c-pn .g14c-t.cmp th{white-space:normal}.g14c-pn .g14c-t.cmp .gd7-date input{width:88px}.g14c-t.cmp td .sm{white-space:normal}.g14c-t.cmp td[data-testid=gd14-calc-ipcas]{max-width:140px}.g14c-t.cmp td[data-lb="SỐ HĐTD"]{max-width:150px;word-break:break-word}.g14c-t.cmp td[data-testid=gd14-calc-lai2]{max-width:130px}.g14c-t.cmp td .sm{font-size:11px}.g14c-t.cmp td,.g14c-t.cmp th{white-space:normal}.g14c-t.cmp .g14c-goc{width:104px}.g14c-t.cmp .g14c-nd{min-width:0}
.g14c-cap .src{display:none}
.g14c-pr{margin:8px 0;border:1px solid #e2e8f0;border-radius:8px;padding:6px 8px;background:#fff}
.g14c-prw{overflow:auto}.g14c-prt{border-collapse:collapse;width:100%;font-size:12px}
.g14c-prt th{background:#eef2ff;color:#0f2a4a;padding:4px 6px;text-align:left;white-space:nowrap}
.g14c-prt td{padding:4px 6px;border-top:1px solid #f1f5f9;white-space:nowrap}.g14c-prt td.n{text-align:right;font-variant-numeric:tabular-nums}
.g14c-prt tr.tg td{font-weight:800;color:#0f2a4a;border-top:2px solid #0f2a4a}.g14c-prt tr.ct td{color:#475569;font-style:italic;white-space:normal}
.g14c-ldn{font-size:11.5px;color:#475569;flex-basis:100%}
@media (max-width:600px){
.g14c-tw{max-height:none;border:0;overflow:visible}
.g14c-t,.g14c-t tbody,.g14c-t tr{display:block;width:100%}
.g14c-t thead{display:block;width:100%}.g14c-t thead tr{display:flex;border:0;background:none;margin:0 0 6px}.g14c-t thead th{flex:0 0 0;width:0!important;min-width:0!important;padding:0!important;border:0!important;overflow:hidden;position:static!important}.g14c-t thead th:not(.s0),.g14c-t thead th:not(.s0) *{font-size:0!important;line-height:0!important}.g14c-t thead th.s0{flex:1 1 auto;width:auto!important;padding:8px 12px!important;display:flex!important;align-items:center;gap:8px;position:static;width:auto;min-width:0;background:#0f2a4a;border-radius:8px;padding:8px 12px;min-height:40px}.g14c-t thead th.s0::after{content:"Chọn tất cả khoản";font-size:12px}
.g14c-t tr{border:1px solid #cbd5e1;border-radius:10px;margin:0 0 8px;background:#f7fdf9;overflow:hidden}
.g14c-t td{display:flex;justify-content:space-between;align-items:center;gap:8px;border:0;border-bottom:1px solid #eef2f7;text-align:right;white-space:normal;position:static!important;max-width:none!important;min-width:0!important;width:auto!important;box-shadow:none!important}
.g14c-pn .g14c-t.cmp td.x{display:block;height:0;border:0}.g14c-pn .g14c-t.cmp td.x::before{content:none}
.g14c-t td::before{content:attr(data-lb);font-weight:700;color:#475569;font-size:11px;text-align:left;flex:0 0 38%}
.g14c-t td.s0{justify-content:flex-start}.g14c-t td.s0::before{content:"Tính khoản này"}
.g14c-t td > *{text-align:right}
.g14c-t input[type=checkbox]{width:22px;height:22px}
.g14c-pn input.g14c-in,.g14c-pn .g14c-goc,.g14c-pn .g14c-btn,.g14c-pn select,.g14c-tab,.g14c-x,.g14c-res button{min-height:40px}
.g14c-pn .gd7-date input,.g14c-pn .gd7-date button{min-height:40px}
.g14c-sum{top:-12px}
}
</style>
'''
assert s.count('<style id="gd14-hm14-css">') == 1
s = s.replace('<style id="gd14-hm14-css">', CSS + '<style id="gd14-hm14-css">')
c = s.count('24.17.18'); assert c == 2, c
s = s.replace('24.17.18', '24.17.19')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.18' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.18', '24.17.19'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
