# P04 · HM-23 + HM-24 · v24.17.26 — Trang Tài sản bảo đảm: mốc TSBĐ tự lưu theo ngày tệp (Q16), tab "🆕 TS chưa có HĐTD",
# tab "📅 Đầu kỳ & 2 mốc". Lớp gd23 1.0.0 (nguon_P04/gd23.js). Bundle: 2 tab + 2 khung chứa + truyền tên tệp cho móc lưu.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P04/build_p04_hm23.py
import hashlib
SRC = 'app/QLTDPRO_v24.17.25.html'; DST = 'app/QLTDPRO_v24.17.26.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:80]); s = s.replace(old, new)
rep('zN=[["ds","📋 Danh sách"],["th","📊 Tổng hợp"],["snap","🕘 Mốc & so sánh"],["qc","🩺 Chất lượng dữ liệu"]]',
    'zN=[["ds","📋 Danh sách"],["th","📊 Tổng hợp"],["kct","🆕 TS chưa có HĐTD"],["dk","📅 Đầu kỳ & 2 mốc"],["snap","🕘 Mốc & so sánh"],["qc","🩺 Chất lượng dữ liệu"]]')
rep('l==="snap"&&o.jsx(q,{}),l==="qc"&&o.jsx(H,{})',
    'l==="snap"&&o.jsx(q,{}),l==="kct"&&o.jsx("div",{"data-testid":"ts-pane-kct",id:"gd23-kct",className:"p-3"}),l==="dk"&&o.jsx("div",{"data-testid":"ts-pane-dk",id:"gd23-dk",className:"p-3"}),l==="qc"&&o.jsx(H,{})')
rep('window.__khmTsbdHistSave&&window.__khmTsbdHistSave(r.objectStore("kv"),e.rows)', 'window.__khmTsbdHistSave&&window.__khmTsbdHistSave(r.objectStore("kv"),e.rows,e.src)')
rep('function taiXlsx(ten,sheets){', 'window.__gd15TaiXlsx=function(t,s){return taiXlsx(t,s)}; /* P04 HM-23: dùng chung bộ ghi .xlsx */\nfunction taiXlsx(ten,sheets){')
JS = open('nguon_P04/gd23.js', encoding='utf-8').read(); assert '</script' not in JS.lower()
CSS = '''<style id="gd23-css">
.gd23-bar{display:flex;flex-wrap:wrap;gap:6px 10px;align-items:center;margin:4px 0 8px;font-size:13px}
.gd23-sel{border:1px solid #9AA8BA;border-radius:6px;padding:4px 8px;min-height:30px;font-size:13px;background:#fff;color:inherit;max-width:100%}
.gd23-note{font-size:12px;color:#475569;margin:4px 0 8px}.gd23-note.red{color:#B42318;font-weight:700}
.gd23-wrap{overflow:auto;max-width:100%;border:1px solid #cbd5e1;border-radius:8px;margin-bottom:10px}
.gd23-t{border-collapse:collapse;width:100%;font-size:12.5px}
.gd23-t th{position:sticky;top:0;background:#1F4E79;color:#fff;padding:6px 8px;text-align:left;font-size:11.5px;white-space:nowrap}
.gd23-t th.n,.gd23-t td.n{text-align:right;font-variant-numeric:tabular-nums}
.gd23-t td{padding:5px 8px;border-top:1px solid #e2e8f0;white-space:nowrap}
.gd23-t tr.ph td{background:#EEF4FB;font-weight:800;color:#1F4E79}.gd23-t tr.tong td{font-weight:800;background:#f8fafc}
.gd23-t td:first-child{position:sticky;left:0;background:inherit;background-color:#fff}.gd23-t tr.ph td:first-child{background:#EEF4FB}.gd23-t tr.tong td:first-child{background:#f8fafc}
.gd23-so{border:0;background:none;color:#1d4ed8;font-weight:700;text-decoration:underline;cursor:pointer;padding:0;font:inherit}
.gd23-btn{border:1px solid #1F4E79;border-radius:6px;background:#fff;color:#1F4E79;font-weight:700;font-size:12px;padding:4px 10px;min-height:30px;cursor:pointer}
.gd23-ct{margin-top:8px}.gd23-ctbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:6px}
.gd23-2moc{margin-top:14px;border-top:2px solid #C9D8EA;padding-top:8px}.gd23-2moc h4{margin:0 0 6px;font-size:14px;color:#1F4E79}
@media (max-width:600px){.gd23-sel,.gd23-btn{min-height:40px}.gd23-t td,.gd23-t th{white-space:normal}}
</style>
'''
assert s.count('<style id="gd20-css">') == 1
s = s.replace('<style id="gd20-css">', CSS + '<style id="gd20-css">')
i = s.rfind('</body>'); assert i > len(s) - 400, i   # thẻ đóng thật ở cuối tệp (3 lần khác nằm trong chuỗi mã)
s = s[:i] + '<script id="gd23-js">\n' + JS + '</script>\n' + s[i:]
c = s.count('"24.17.25"'); assert c == 2, c
s = s.replace('"24.17.25"', '"24.17.26"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.25' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.25', '24.17.26'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
