# P04 · HM-03 · v24.17.23 — lớp lưu trữ: thêm gd21 (báo rõ khi localStorage đầy). Không đổi schema/khóa/CSDL.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P04/build_p04_hm03.py
import hashlib
SRC = 'app/QLTDPRO_v24.17.22.html'; DST = 'app/QLTDPRO_v24.17.23.html'
s = open(SRC, encoding='utf-8').read()
JS = open('nguon_P04/gd21.js', encoding='utf-8').read(); assert '</script' not in JS.lower()
assert s.count('<script id="gd10-js">') == 1
s = s.replace('<script id="gd10-js">', '<script id="gd21-js">\n' + JS + '</script>\n<script id="gd10-js">', 1)
assert s.index('<script id="gd9-js">') < s.index('<script id="gd21-js">')
c = s.count('"24.17.22"'); assert c == 2, c
s = s.replace('"24.17.22"', '"24.17.23"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.22' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.22', '24.17.23'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
