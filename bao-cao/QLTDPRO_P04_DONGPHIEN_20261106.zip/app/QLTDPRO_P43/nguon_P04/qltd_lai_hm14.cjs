/*
 * QLTDLai.hm14 — mở rộng lõi lãi (HM-14, đề án v1.2, P04). KHÔNG sửa qltd_lai.cjs (giữ từng byte).
 * Thuần túy: không DOM, không ghi dữ liệu, không mạng. Mọi phép tính lãi gọi lại DUY NHẤT
 * QLTDLai.tinhLaiKhoan (365 ngày; quá hạn LS × 1,5 cơ bản + phạt; tròn từng phần) — không nhân bản công thức.
 *
 * Bổ sung:
 *  1. phanLoaiKyHan(r)        — ngắn / trung / dài hạn / thấu chi từ r[13] (lntpcd đã đổi tên), dự phòng theo thời hạn.
 *  2. ngayKyLaiQ12(r, opts)   — Q12 (người dùng 05/11): TRUNG/DÀI hạn đến kỳ trả lãi mà chưa trả đủ lãi → LS 150%
 *                               từ ngày kỳ trả lãi. Kỳ trả lãi = r[25] nxtrpmtschddt (lịch IPCAS) nếu sau mốc,
 *                               hoặc mốc + opts.kyLaiThang tháng (người dùng chọn). NGẮN hạn: không có lãi chậm
 *                               trả; quá hạn chỉ sau ngày đến hạn khoản GN r[7] như cũ.
 *  3. tinhLaiQ12(r, opts)     — = tinhLaiKhoan, chỉ dời ngày xác định quá hạn sớm lên theo (2) cho trung/dài hạn.
 *  4. lichSuDuNo(...)         — dựng các đoạn dư nợ từ mốc Lưu trữ (dư nợ theo dsbsseq + lstrpmtdt r[26]).
 *  5. tinhLaiTheoDoan(r, o)   — khi có trả gốc giữa kỳ: lãi từng đoạn dư nợ (mỗi đoạn gọi tinhLaiQ12), cộng số đã tròn.
 *                               Không có đoạn đổi dư nợ → trả về ĐÚNG kết quả tinhLaiQ12 (không đổi số cũ).
 *  6. doiChieuIPCAS(r, k)     — chênh = lãi app đến ngày dữ liệu − r[10] intamt (lãi dự thu IPCAS) + lý do.
 *  7. canhBaoNgayChot(...)    — ngày chốt trước ngày dữ liệu / cách quá xa / trước mốc.
 */
(function (root) {
  "use strict";
  var L = root.QLTDLai || (typeof require === "function" ? require("../nguon_P41/qltd_lai.cjs") : null);
  if (!L) return;
  var MS = 86400000;

  function iso(t) { return new Date(t).toISOString().slice(0, 10); }
  function dmy(t) { var s = iso(t); return s.slice(8, 10) + "/" + s.slice(5, 7) + "/" + s.slice(0, 4); }
  function mocMs(r) { var a = L.parseDate(r && r[23]); return a != null ? a : L.parseDate(r && r[6]); }
  function addMonths(t, n) {
    var d = new Date(t), y = d.getUTCFullYear(), m = d.getUTCMonth() + n, day = d.getUTCDate();
    var last = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
    return Date.UTC(y, m, Math.min(day, last));
  }
  function fold(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/g, "d"); }

  /* 1 ---------- loại kỳ hạn ---------- */
  function phanLoaiKyHan(r) {
    var t = fold(r && r[13]);
    if (/thau ?chi|overdraft/.test(t)) return { loai: "thauchi", nhan: "Thấu chi", nguon: "loại vay" };
    if (/ngan ?han|tk ?211|^211/.test(t)) return { loai: "ngan", nhan: "Ngắn hạn", nguon: "loại vay" };
    if (/trung ?han|tk ?212|^212/.test(t)) return { loai: "trung", nhan: "Trung hạn", nguon: "loại vay" };
    if (/dai ?han|tk ?213|^213/.test(t)) return { loai: "dai", nhan: "Dài hạn", nguon: "loại vay" };
    var a = L.parseDate(r && r[6]), b = L.parseDate(r && r[7]);
    if (a != null && b != null && b > a) {
      var thang = (b - a) / MS / 30.4375;
      if (thang <= 12.5) return { loai: "ngan", nhan: "Ngắn hạn", nguon: "thời hạn GN → đến hạn" };
      if (thang <= 60.5) return { loai: "trung", nhan: "Trung hạn", nguon: "thời hạn GN → đến hạn" };
      return { loai: "dai", nhan: "Dài hạn", nguon: "thời hạn GN → đến hạn" };
    }
    return { loai: null, nhan: "Chưa rõ kỳ hạn", nguon: "" };
  }
  function laTrungDai(pl) { return pl.loai === "trung" || pl.loai === "dai"; }

  /* 2 ---------- kỳ trả lãi (Q12) ---------- */
  function ngayKyLaiQ12(r, opts) {
    opts = opts || {};
    var pl = phanLoaiKyHan(r);
    if (!laTrungDai(pl)) return null;
    var moc = mocMs(r);
    if (moc == null) return null;
    var nx = L.parseDate(r && r[25]);
    if (nx != null && nx > moc && opts.kyLaiThang !== "tat") return { ngay: nx, nguon: "lịch trả nợ IPCAS (nxtrpmtschddt)" };
    var n = Number(opts.kyLaiThang);
    if (isFinite(n) && n > 0) return { ngay: addMonths(moc, n), nguon: "kỳ trả lãi " + n + " tháng kể từ ngày đã thu lãi đến" };
    return null;
  }

  /* 3 ---------- lãi một khoản theo Q12 ---------- */
  function tinhLaiQ12(r, opts) {
    opts = opts || {};
    var pl = phanLoaiKyHan(r);
    var ky = opts.q12 === false ? null : (opts.kyCoDinh !== undefined ? opts.kyCoDinh : ngayKyLaiQ12(r, opts));
    var chot = L.parseDate(opts.chot) != null ? L.parseDate(opts.chot) : L.todayUTC();
    var mat = L.parseDate(r && r[7]);
    var k, apQ12 = false;
    if (ky && ky.ngay < chot && (mat == null || ky.ngay < mat)) {
      var r2 = r.slice(); r2[7] = iso(ky.ngay);
      k = L.tinhLaiKhoan(r2, opts);
      apQ12 = !!(k && k.ok);
      if (apQ12) k.canhBao.push("Q12 — " + pl.nhan.toLowerCase() + ": đến kỳ trả lãi " + dmy(ky.ngay) + " (" + ky.nguon + ") chưa trả đủ lãi → từ ngày này tính LS × 1,5" + (mat != null ? " (đến hạn gốc " + dmy(mat) + ")" : "") + ".");
    } else {
      k = L.tinhLaiKhoan(r, opts);
      if (k && k.ok && opts.q12 !== false && laTrungDai(pl) && !ky && !(Number(opts.kyLaiThang) > 0))
        k.canhBao.push("Q12 — " + pl.nhan.toLowerCase() + ": thiếu lịch trả nợ (nxtrpmtschddt) sau ngày đã thu lãi đến — CHƯA xét quá hạn lãi (mỗi khách có định kỳ riêng, không có mặc định; chọn kỳ của khách nếu biết).");
    }
    if (k) {
      k.kyHan = pl;
      k.q12 = apQ12 ? { ngay: iso(ky.ngay), nguon: ky.nguon } : null;
      k.chamTraApDung = !(pl.loai === "ngan" || pl.loai === "thauchi");
      if (k.ok && !k.chamTraApDung && k.soNgayQH > 0) k.ghiChuQ12 = "Ngắn hạn: không tính lãi chậm trả (Q12); đoạn quá hạn là sau ngày đến hạn gốc.";
    }
    return k;
  }

  /* 4 ---------- lịch sử dư nợ từ mốc Lưu trữ ----------
   * snaps: [{ngay: ISO, duno: số | null (khế ước không có trong mốc), lst: lstrpmtdt}] (mọi mốc, mọi thứ tự)
   * moc, den: ms UTC; hienTai: {ngay: ISO ngày dữ liệu | null, duno, lst} (dòng đang tính).
   * Trả {doan:[{tu: ms, duno}], canhBao:[]} — đoạn đầu bắt đầu tại moc. Không đủ căn cứ → doan rỗng. */
  function lichSuDuNo(snaps, moc, den, hienTai) {
    var cb = [], pts = [];
    (snaps || []).forEach(function (s) {
      var t = L.parseDate(s.ngay); if (t == null) return;
      pts.push({ t: t, duno: s.duno == null ? 0 : Number(s.duno) || 0, lst: L.parseDate(s.lst), coMat: s.duno != null });
    });
    if (hienTai && L.parseDate(hienTai.ngay) != null) {
      var th = L.parseDate(hienTai.ngay);
      pts = pts.filter(function (p) { return p.t !== th; });
      pts.push({ t: th, duno: Number(hienTai.duno) || 0, lst: L.parseDate(hienTai.lst), coMat: true });
    }
    pts.sort(function (a, b) { return a.t - b.t; });
    if (!pts.length || moc == null) return { doan: [], canhBao: cb };
    var truoc = null, sau = [];
    pts.forEach(function (p) { if (p.t <= moc) truoc = p; else if (p.t < den) sau.push(p); });
    var dau;
    if (truoc && truoc.coMat) dau = truoc.duno;
    else {
      var f = sau.filter(function (p) { return p.coMat; })[0];
      if (!f) return { doan: [], canhBao: cb };
      dau = f.duno;
      if (sau.some(function (p) { return p.coMat && p.duno !== dau; }))
        cb.push("Không có mốc Lưu trữ tại/trước ngày " + dmy(moc) + " — dư nợ đoạn đầu lấy theo mốc " + dmy(f.t) + ".");
    }
    var doan = [{ tu: moc, duno: dau }], cur = dau, prevT = truoc ? truoc.t : moc;
    sau.forEach(function (p) {
      if (!p.coMat) { prevT = p.t; return; }
      if (p.duno !== cur) {
        var ngay = p.t, uoc = true;
        if (p.lst != null && p.lst > prevT && p.lst <= p.t && p.lst > moc) { ngay = p.lst; uoc = false; }
        if (uoc) cb.push("Dư nợ đổi " + L.fmt(cur) + " → " + L.fmt(p.duno) + " giữa hai mốc, không có ngày trả (lstrpmtdt) — tạm lấy ngày mốc " + dmy(p.t) + ".");
        if (ngay <= doan[doan.length - 1].tu) doan[doan.length - 1].duno = p.duno;
        else doan.push({ tu: ngay, duno: p.duno, uocTinh: uoc });
        cur = p.duno;
      }
      prevT = p.t;
    });
    return { doan: doan, canhBao: cb };
  }

  /* 5 ---------- lãi theo đoạn dư nợ ---------- */
  function tinhLaiTheoDoan(r, opts) {
    opts = opts || {};
    var doan = (opts.doan || []).filter(function (d) { return d && d.tu != null; });
    var doi = doan.length > 1 || (doan.length === 1 && Number(doan[0].duno) !== Number(r && r[11]));
    if (!doi) return tinhLaiQ12(r, opts);
    var tong0 = tinhLaiQ12(r, opts); // để lấy mốc, ngày chốt, lỗi đầu vào giống hệt cách cũ
    var kyGoc = opts.q12 === false ? null : ngayKyLaiQ12(r, opts); // kỳ trả lãi xác định MỘT lần theo mốc gốc
    if (!tong0 || !tong0.ok) return tong0;
    var chot = L.parseDate(tong0.chot), parts = [], cb = [];
    var sumF = { soNgayTH: 0, laiTH: 0, soNgayQH: 0, laiQHCB: 0, laiQHPhat: 0 }, chiTiet = [];
    for (var i = 0; i < doan.length; i++) {
      var tu = Math.max(L.parseDate(tong0.moc), doan[i].tu), den = i + 1 < doan.length ? Math.min(doan[i + 1].tu, chot) : chot;
      if (den <= tu) continue;
      var dn = Number(doan[i].duno) || 0;
      var part = { tu: iso(tu), den: iso(den), duno: dn, soNgayTH: 0, laiTH: 0, soNgayQH: 0, laiQHCB: 0, laiQHPhat: 0, laiQH: 0, tong: 0, uocTinh: !!doan[i].uocTinh };
      if (dn > 0) {
        var r2 = r.slice(); r2[11] = dn; r2[23] = iso(tu);
        var k = tinhLaiQ12(r2, Object.assign({}, opts, { chot: iso(den), kyCoDinh: kyGoc }));
        if (!k || !k.ok) return k;
        ["soNgayTH", "laiTH", "soNgayQH", "laiQHCB", "laiQHPhat"].forEach(function (f) { part[f] = k[f]; sumF[f] += k[f]; });
        part.laiQH = k.laiQH; part.tong = k.tong;
        k.chiTiet.forEach(function (t) { chiTiet.push("Đoạn " + dmy(tu) + "→" + dmy(den) + " · " + t); });
        k.canhBao.forEach(function (t) { if (cb.indexOf(t) < 0 && !/trước mốc tính lãi/.test(t)) cb.push(t); });
      } else chiTiet.push("Đoạn " + dmy(tu) + "→" + dmy(den) + " · dư nợ 0 — không tính lãi");
      parts.push(part);
    }
    var out = Object.assign({}, tong0, sumF);
    out.q12 = tong0.q12;
    out.laiQH = sumF.laiQHCB + sumF.laiQHPhat;
    out.tong = sumF.laiTH + out.laiQH;
    out.chiTiet = chiTiet;
    out.canhBao = cb.concat(["Có trả gốc giữa kỳ: lãi tính theo " + parts.length + " đoạn dư nợ (dư nợ hiện tại " + L.fmt(Number(r[11]) || 0) + " đ)."]);
    out.doan = parts;
    out.duno = Number(r[11]) || 0;
    return out;
  }

  /* 6 ---------- đối chiếu lãi dự thu IPCAS ---------- */
  function doiChieuIPCAS(r, kData, ungVien) {
    var ip = Number(r && r[10]);
    if (!(isFinite(ip) && ip > 0)) return { coSo: false, lyDo: "IPCAS không ghi lãi dự thu (intamt = 0/trống) — không đối chiếu được." };
    if (!kData || !kData.ok) return { coSo: false, ipcas: ip, lyDo: "App không tính được lãi đến ngày dữ liệu: " + (kData ? kData.lyDo : "") };
    var ch = kData.tong - ip, ly = [];
    if (ch === 0) ly.push("Khớp từng đồng.");
    else {
      var ngay1 = Math.round(kData.duno * kData.ls / 100 / 365);
      if (Math.abs(ch) <= 2) ly.push("Chênh làm tròn (≤ 2 đ).");
      else if (ngay1 > 0 && Math.abs(ch / ngay1 - Math.round(ch / ngay1)) < 0.02 && Math.abs(Math.round(ch / ngay1)) <= 31)
        ly.push("Lệch khoảng " + Math.abs(Math.round(ch / ngay1)) + " ngày lãi — kiểm tra ngày đã thu lãi đến / cách tính ngày cuối của IPCAS.");
      if (kData.doan && kData.doan.length > 1) ly.push("Có trả gốc giữa kỳ (lãi theo đoạn).");
      if (kData.soNgayQH > 0) ly.push("Có đoạn quá hạn (IPCAS có thể hạch toán lãi quá hạn riêng, không nằm trong intamt).");
      if (!ly.length) ly.push("Chưa rõ nguyên nhân — đối chiếu chứng từ IPCAS.");
    }
    var khop = null;
    if (ch !== 0) (ungVien || []).some(function (u) {
      if (u && u.k && u.k.ok && u.k.tong === ip) { khop = { nhan: u.nhan, ngay: u.ngay }; return true; }
      return false;
    });
    if (khop) ly.unshift("Khớp 0 đồng nếu IPCAS tính lãi dự thu đến " + khop.nhan + " " + dmy(L.parseDate(khop.ngay)) + " (Q7 — chưa chốt).");
    return { coSo: true, ipcas: ip, app: kData.tong, chenh: ch, lyDo: ly.join(" "), khop: khop };
  }

  /* 7 ---------- cảnh báo ngày chốt ---------- */
  function canhBaoNgayChot(chot, ngayDuLieu, nguongNgay) {
    var c = L.parseDate(chot), d = L.parseDate(ngayDuLieu), w = [], g = Number(nguongNgay) || 31;
    if (c == null) return w;
    if (d == null) { w.push("Chưa xác định ngày dữ liệu (chưa có mốc trong Lưu trữ) — không đối chiếu được ngày chốt với dữ liệu."); return w; }
    var n = Math.round((c - d) / MS);
    if (n < 0) w.push("Ngày chốt " + dmy(c) + " TRƯỚC ngày dữ liệu " + dmy(d) + " " + (-n) + " ngày — dư nợ, ngày đã thu lãi đến là số sau ngày chốt; kết quả có thể sai.");
    else if (n > g) w.push("Ngày chốt cách ngày dữ liệu " + dmy(d) + " tới " + n + " ngày (> " + g + ") — dư nợ/ngày thu lãi có thể đã đổi; nên nạp tệp msit80 mới hơn.");
    return w;
  }

  var api = {
    phanLoaiKyHan: phanLoaiKyHan, ngayKyLaiQ12: ngayKyLaiQ12, tinhLaiQ12: tinhLaiQ12,
    lichSuDuNo: lichSuDuNo, tinhLaiTheoDoan: tinhLaiTheoDoan, doiChieuIPCAS: doiChieuIPCAS,
    canhBaoNgayChot: canhBaoNgayChot, addMonths: addMonths,
    PHIEN_BAN: "P04-HM14 1.1.0"
  };
  L.hm14 = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
