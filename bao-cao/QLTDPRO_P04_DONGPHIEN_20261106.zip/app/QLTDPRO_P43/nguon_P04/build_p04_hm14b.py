# P04 · HM-14b · v24.17.18 — áp trả lời của người dùng (05/11):
#  Q15a: LS × 1,5 trên toàn bộ dư nợ gốc (giữ như v24.17.17).
#  Q15b: kỳ trả lãi = nxtrpmtschddt; mỗi khách định kỳ riêng, KHÔNG có mặc định → kỳ chọn tay không giữ sang khách/lần mở khác;
#        khoản trung/dài hạn thiếu lịch → cảnh báo "chưa xét quá hạn lãi".
#  Q7 (chưa chốt, "có khả năng dự thu tính đến ngày đến hạn"): Chênh IPCAS thử thêm mốc ngày đến hạn kỳ (r[25]) và đến hạn gốc (r[7]).
# Lõi qltd_lai.cjs giữ từng byte; QLTDLai.hm14 1.0.0 → 1.1.0.  Chạy từ app/QLTDPRO_P43/:  python3 nguon_P04/build_p04_hm14b.py
import re, hashlib
SRC = 'app/QLTDPRO_v24.17.17.html'; DST = 'app/QLTDPRO_v24.17.18.html'
s = open(SRC, encoding='utf-8').read()
core = open('nguon_P41/qltd_lai.cjs', encoding='utf-8').read().rstrip('\n')
mod = open('nguon_P04/qltd_lai_hm14.cjs', encoding='utf-8').read().rstrip('\n'); assert '</script' not in mod.lower()
m = re.search(r'<script id="gd14-js">\n?(.*?)</script>', s, re.S); g = m.group(1)
assert core in g
def rep(old, new, n=1):
    global g
    c = g.count(old); assert c == n, ('anchor count', c, n, old[:90]); g = g.replace(old, new)
END = '})(typeof globalThis !== "undefined" ? globalThis : this);'
a = g.index('/*\n * QLTDLai.hm14 —'); b = g.index(END, a) + len(END); assert 'P04-HM14 1.0.0' in g[a:b]
g = g[:a] + mod + g[b:]
# Q15b: không giữ kỳ chọn tay giữa các lần mở / các khách
rep('C.kyLai = C.kyLai || ""; C.arc = null;', 'C.kyLai = ""; C.arc = null;')
rep('''    render();
    hm14Hist();''', '''    C.kyLai = "";
    render();
    hm14Hist();''')
rep('[["", "Theo lịch IPCAS (nxtrpmtschddt)"], ["1", "Hằng tháng (1 tháng)"], ["3", "Hằng quý (3 tháng)"], ["6", "6 tháng"], ["tat", "Không áp Q12"]]',
    '[["", "Theo lịch IPCAS (nxtrpmtschddt) — không mặc định"], ["1", "Kỳ của khách: 1 tháng"], ["3", "Kỳ của khách: 3 tháng"], ["6", "Kỳ của khách: 6 tháng"], ["tat", "Không áp Q12"]]')
# Q7: mốc ứng viên cho Chênh IPCAS
rep('''    return H14.doiChieuIPCAS(it.r, C.ngayDL ? H14.tinhLaiTheoDoan(it.r, hm14Opts(it, C.ngayDL)) : null);''',
    '''    var uv = [], m0 = mocMs(it.r);
    [["ngày đến hạn kỳ", it.r[25]], ["ngày đến hạn gốc", it.r[7]]].forEach(function (x) {
      var t = L.parseDate(x[1]); if (t == null || m0 == null || t <= m0 || iso(t) === C.ngayDL) return;
      if (uv.some(function (u) { return u.ngay === iso(t); })) return;
      uv.push({ nhan: x[0], ngay: iso(t), k: H14.tinhLaiTheoDoan(it.r, hm14Opts(it, iso(t))) });
    });
    return H14.doiChieuIPCAS(it.r, C.ngayDL ? H14.tinhLaiTheoDoan(it.r, hm14Opts(it, C.ngayDL)) : null, uv);''')
rep('''    return el("td", { cls: "n " + (p.chenh === 0 ? "ip0" : "ipl"), "data-testid": "gd14-calc-ipcas", "data-chenh": String(p.chenh),''',
    '''    return el("td", { cls: "n " + (p.chenh === 0 ? "ip0" : (p.khop ? "ipq" : "ipl")), "data-testid": "gd14-calc-ipcas", "data-chenh": String(p.chenh), "data-khop": p.khop ? p.khop.ngay : null,''')
rep('''el("span", { cls: "sm", text: p.chenh === 0 ? "khớp" : p.lyDo.slice(0, 60) })''',
    '''el("span", { cls: "sm", text: p.chenh === 0 ? "khớp" : (p.khop ? "khớp nếu đến " + dmy(p.khop.ngay) : p.lyDo.slice(0, 60)) })''')
s = s[:m.start(1)] + g + s[m.end(1):]
CSS_OLD = '.g14c-t td.ipl{background:#fff7ed;color:#9a3412;font-weight:700}'
assert s.count(CSS_OLD) == 1; s = s.replace(CSS_OLD, CSS_OLD + '.g14c-t td.ipq{background:#eff6ff;color:#1d4ed8;font-weight:700}')
c = s.count('24.17.17'); assert c == 2, c
s = s.replace('24.17.17', '24.17.18')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.17' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.17', '24.17.18'))
print('OK', DST, 'lõi sha256', hashlib.sha256((core + '\n').encode()).hexdigest()[:16], 'md5', hashlib.md5(s.encode()).hexdigest())
