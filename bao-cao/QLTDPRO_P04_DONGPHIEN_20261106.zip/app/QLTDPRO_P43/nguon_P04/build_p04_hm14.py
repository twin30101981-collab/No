# P04 · HM-14 · v24.17.17 — Máy tính lãi: chính xác số liệu.
#  - Q12 (người dùng 05/11): ngắn hạn/thấu chi không lãi chậm trả (quá hạn chỉ sau đến hạn gốc r[7]);
#    trung/dài hạn đến kỳ trả lãi (nxtrpmtschddt, hoặc kỳ người dùng chọn) chưa trả đủ lãi → LS × 1,5 từ ngày kỳ.
#  - Lãi theo từng đoạn dư nợ khi có trả gốc giữa kỳ (dư nợ khế ước ở các mốc Lưu trữ + lstrpmtdt).
#  - Cột "CHÊNH IPCAS" = lãi app đến ngày dữ liệu − intamt (r[10]), tô + lý do; cảnh báo ngày chốt.
# Lõi nguon_P41/qltd_lai.cjs GIỮ TỪNG BYTE (kiểm sha256); mô-đun mới nguon_P04/qltd_lai_hm14.cjs gọi lại tinhLaiKhoan.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P04/build_p04_hm14.py
import re, hashlib
SRC = 'app/QLTDPRO_v24.17.16.html'; DST = 'app/QLTDPRO_v24.17.17.html'
s = open(SRC, encoding='utf-8').read()
core = open('nguon_P41/qltd_lai.cjs', encoding='utf-8').read()
def doc(path):
    t = open(path, encoding='utf-8').read().rstrip('\n'); assert '</script' not in t.lower(); return t
m = re.search(r'<script id="gd14-js">\n?(.*?)</script>', s, re.S); assert m and s.count('<script id="gd14-js">') == 1
g = m.group(1)
assert core.rstrip('\n') in g, 'lõi qltd_lai.cjs trong bản nguồn đã khác nguon_P41'
def rep(old, new, n=1):
    global g
    c = g.count(old); assert c == n, ('anchor count', c, n, old[:90]); g = g.replace(old, new)

END_CORE = '})(typeof globalThis !== "undefined" ? globalThis : this);\n'
i = g.index(END_CORE) + len(END_CORE); assert g.index(END_CORE) == g.index(core.rstrip('\n')) + len(core.rstrip('\n')) - len(END_CORE) + 1
g = g[:i] + doc('nguon_P04/qltd_lai_hm14.cjs') + '\n' + g[i:]

# 1. Lãi dự thu (trang Lãi đọng) + công cụ Tính lãi tất toán: cùng quy tắc Q12
rep('return L.tinhLaiKhoan(row, { chot: chotGet() });', 'return (L.hm14 ? L.hm14.tinhLaiQ12 : L.tinhLaiKhoan)(row, { chot: chotGet() });')
rep('var k = L.tinhLaiKhoan(row, { chot: chot, heSoQH: heSo });', 'var k = (L.hm14 ? L.hm14.tinhLaiQ12 : L.tinhLaiKhoan)(row, { chot: chot, heSoQH: heSo });')
rep('    if (chamTra && k.soNgayQH > 0) {',
    '    if (chamTra && k.soNgayQH > 0 && k.chamTraApDung === false) card.appendChild(el("div", { cls: "text-warn-foreground", "data-testid": "gd14-tool-q12", text: "Ngắn hạn/thấu chi: không tính lãi chậm trả (Q12)." }));\n'
    '    if (chamTra && k.soNgayQH > 0 && k.chamTraApDung !== false) {')

# 2. Máy tính lãi: hàm phụ HM-14
HELP = r'''  /* ---- HM-14 (P04): Q12, lãi theo đoạn dư nợ (Lưu trữ), đối chiếu IPCAS, cảnh báo ngày chốt ---- */
  var H14 = L.hm14;
  function hm14Api() { var A = window.__gd11Api; return A && A.arcList && A.loadArcRows ? A : null; }
  function hm14Metas() {
    var A = hm14Api(); if (!A) return [];
    var byDay = {};
    A.arcList().forEach(function (m) { var d = A.vnToIso(m.dayKey || ""); if (!d) return; if (!byDay[d] || (m.timestamp || 0) > (byDay[d].timestamp || 0)) byDay[d] = m; });
    return Object.keys(byDay).sort().map(function (d) { return { ngay: d, meta: byDay[d] }; });
  }
  function hm14NgayDL() { try { var ms = hm14Metas(); return ms.length ? ms[ms.length - 1].ngay : ""; } catch (e) { return ""; } }
  function hm14LoadArc() {
    if (C.arc) return C.arc;
    var A = hm14Api(), ms = hm14Metas();
    C.arc = Promise.all(ms.map(function (m) {
      return Promise.all([A.loadArcRows(m.meta).catch(function () { return null; }), A.loadZeroRows ? A.loadZeroRows(m.meta).catch(function () { return null; }) : Promise.resolve(null)])
        .then(function (x) {
          var map = new Map();
          (x[0] || []).concat(x[1] || []).forEach(function (r) { var q = String(r && r[20] || "").trim(); if (q) map.set(q, { duno: Number(r[11]) || 0, lst: r[26] == null ? "" : String(r[26]).trim() }); });
          return { ngay: m.ngay, map: map, ok: !!(x[0] && x[0].length) };
        });
    }));
    return C.arc;
  }
  function hm14Hist() {
    var cust = C.cust; if (!cust || !hm14Api()) return;
    hm14LoadArc().then(function (arcs) {
      if (C.cust !== cust) return;
      C.loans.forEach(function (it) {
        var q = String(it.r[20] || "").trim(), m = mocMs(it.r);
        if (!q || m == null) return;
        var snaps = arcs.filter(function (a) { return a.ok; }).map(function (a) { var v = a.map.get(q); return { ngay: a.ngay, duno: v ? v.duno : null, lst: v ? v.lst : "" }; });
        var h = H14.lichSuDuNo(snaps, m, Date.UTC(2999, 0, 1), C.ngayDL ? { ngay: C.ngayDL, duno: duNo(it.r), lst: it.r[26] } : null);
        it.doan = h.doan; it.hcb = h.canhBao;
      });
      C.histOk = true;
      render();
    }).catch(function () {});
  }
  function hm14Opts(it, chot) { return { chot: chot, doan: it.doan || [], kyLaiThang: C.kyLai, q12: C.kyLai !== "tat" }; }
  function hm14K(it) {
    var k = H14.tinhLaiTheoDoan(it.r, hm14Opts(it, chotOf(it)));
    if (k && k.ok && k.doan && it.hcb && it.hcb.length) k.canhBao = it.hcb.concat(k.canhBao);
    return k;
  }
  function hm14Ip(it) {
    if (!C.ngayDL && Number(it.r[10]) > 0) return { coSo: false, lyDo: "Chưa xác định ngày dữ liệu (Lưu trữ trống) — chưa đối chiếu được với IPCAS." };
    return H14.doiChieuIPCAS(it.r, C.ngayDL ? H14.tinhLaiTheoDoan(it.r, hm14Opts(it, C.ngayDL)) : null);
  }
  function ipCell(it) {
    var p = it.ip || {};
    if (!p.coSo) return el("td", { cls: "c ipn", "data-testid": "gd14-calc-ipcas", title: p.lyDo || "", text: "—" });
    return el("td", { cls: "n " + (p.chenh === 0 ? "ip0" : "ipl"), "data-testid": "gd14-calc-ipcas", "data-chenh": String(p.chenh),
      title: "Lãi app đến " + dmy(C.ngayDL) + ": " + L.fmt(p.app) + " − IPCAS (intamt) " + L.fmt(p.ipcas) + " = " + L.fmt(p.chenh) + " đ\n" + p.lyDo },
      [el("span", { text: p.chenh === 0 ? "0" : L.fmt(p.chenh) }), el("span", { cls: "sm", text: p.chenh === 0 ? "khớp" : p.lyDo.slice(0, 60) })]);
  }
  function hm14Badges(k, ok) {
    if (!ok || !k) return [];
    var b = [];
    if (k.kyHan && k.kyHan.loai && k.kyHan.nguon !== "loại vay") b.push(el("span", { cls: "sm", "data-testid": "gd14-calc-kyhan", text: k.kyHan.nhan + " (theo thời hạn)" }));
    if (k.q12) b.push(el("span", { cls: "sm q12", "data-testid": "gd14-calc-q12", text: "Q12: LS × 1,5 từ " + dmy(k.q12.ngay) }));
    if (k.doan) b.push(el("span", { cls: "sm dn", "data-testid": "gd14-calc-doan", text: k.doan.length + " đoạn dư nợ" }));
    return b;
  }
  function hm14Bar() {
    var sel = el("select", { cls: "g14c-in", "data-testid": "gd14-calc-kylai", "aria-label": "Kỳ trả lãi trung/dài hạn" },
      [["", "Theo lịch IPCAS (nxtrpmtschddt)"], ["1", "Hằng tháng (1 tháng)"], ["3", "Hằng quý (3 tháng)"], ["6", "6 tháng"], ["tat", "Không áp Q12"]].map(function (o) {
        var x = el("option", { value: o[0], text: o[1] }); if (String(C.kyLai || "") === o[0]) x.selected = true; return x; }));
    sel.addEventListener("change", function () { C.kyLai = sel.value; render(); });
    var w = H14.canhBaoNgayChot(C.chot, C.ngayDL), own = {};
    C.loans.forEach(function (x) { if (x.tick && x.chot && L.parseDate(x.chot) != null && x.chot !== C.chot) own[x.chot] = 1; });
    if (C.ngayDL) Object.keys(own).sort().forEach(function (d) { H14.canhBaoNgayChot(d, C.ngayDL).forEach(function (t) { w.push("Ngày thu riêng — " + t); }); });
    var nDoan = C.loans.filter(function (x) { return x.tick && x.k && x.k.ok && x.k.doan; }).length;
    var nQ12 = C.loans.filter(function (x) { return x.tick && x.k && x.k.ok && x.k.q12; }).length;
    var nIp = C.loans.filter(function (x) { return x.tick && x.ip && x.ip.coSo && x.ip.chenh !== 0; }).length;
    var kids = [el("div", { cls: "g14c-h14r" }, [
      el("span", { style: "font-weight:700", text: "⚖️ Kỳ trả lãi trung/dài hạn (Q12):" }), sel,
      el("span", { cls: "g14c-h14i", "data-testid": "gd14-calc-ngaydl", text: "Ngày dữ liệu: " + (C.ngayDL ? dmy(C.ngayDL) + " (mốc Lưu trữ mới nhất)" : "chưa có (Lưu trữ trống)") }),
      el("span", { cls: "g14c-h14i", "data-testid": "gd14-calc-h14-tk", text: nQ12 + " khoản áp Q12 · " + nDoan + " khoản tính theo đoạn dư nợ · " + nIp + " khoản lệch IPCAS" })
    ])];
    if (w.length) kids.push(el("div", { cls: "g14c-note red", "data-testid": "gd14-calc-chot-warn" }, w.map(function (t) { return el("div", { text: "⚠ " + t }); })));
    kids.push(el("div", { cls: "g14c-h14i", text: "Ngắn hạn/thấu chi: không lãi chậm trả; quá hạn chỉ sau ngày đến hạn gốc. Trung/dài hạn: đến kỳ trả lãi chưa trả đủ → LS × 1,5 từ ngày kỳ (Q12). Có trả gốc giữa kỳ → lãi theo từng đoạn dư nợ (mốc Lưu trữ)." }));
    return el("div", { cls: "g14c-h14", "data-testid": "gd14-calc-h14" }, kids);
  }
  function hm14CopyLines(x) {
    var k = x.k, o = []; if (!k || !k.ok) return o;
    if (k.q12) o.push("Q12: " + k.kyHan.nhan.toLowerCase() + " — đến kỳ trả lãi " + dmy(k.q12.ngay) + " chưa trả đủ lãi → LS × 1,5 từ ngày này");
    if (k.doan) k.doan.forEach(function (d) { o.push("Đoạn " + dmy(d.tu) + " → " + dmy(d.den) + " · DN " + L.fmt(d.duno) + " · lãi " + L.fmt(d.tong)); });
    if (x.ip && x.ip.coSo) o.push("Chênh so IPCAS (đến ngày dữ liệu " + dmy(C.ngayDL) + "): " + L.fmt(x.ip.chenh) + " đ — " + x.ip.lyDo);
    return o;
  }

  /* ---- tính toàn bảng'''
rep('  /* ---- tính toàn bảng', HELP)
rep('      it.k = L.tinhLaiKhoan(it.r, { chot: chotOf(it) });', '      it.k = hm14K(it);\n      it.ip = hm14Ip(it);')
rep('''    C.loans = rows.map(function (r) { return { r: r, tick: duNo(r) > 0, goc: 0, gocWarn: "", k: null, chot: "" }; });
    render();''', '''    C.loans = rows.map(function (r) { return { r: r, tick: duNo(r) > 0, goc: 0, gocWarn: "", k: null, chot: "" }; });
    render();
    hm14Hist();''')
rep('''    C.chot = opts.chot && L.parseDate(opts.chot) != null ? opts.chot : chotGet();''',
    '''    C.chot = opts.chot && L.parseDate(opts.chot) != null ? opts.chot : chotGet();
    C.kyLai = C.kyLai || ""; C.arc = null; C.histOk = false; C.ngayDL = hm14NgayDL();''')
rep('    bd.appendChild(bulkBar());', '    bd.appendChild(bulkBar());\n    bd.appendChild(hm14Bar());')
rep('''      th("TỔNG LÃI PHẢI THU", "")''', '''      th("TỔNG LÃI PHẢI THU", ""),
      th("CHÊNH IPCAS", "app − intamt", "", "Lãi app tính đến NGÀY DỮ LIỆU − lãi dự thu IPCAS (intamt) của khoản; ô tô cam = lệch, rê chuột xem lý do")''')
rep('''tds.push(el("td", { cls: "n tg", "data-testid": "gd14-calc-tong", text: L.fmt(k.tong) }));''',
    '''tds.push(el("td", { cls: "n tg", "data-testid": "gd14-calc-tong", text: L.fmt(k.tong) }));
        tds.push(ipCell(it));''')
rep('colspan: "5"', 'colspan: "6"')
rep('el("span", { cls: "sm", text: String(r[13] || "") })]', 'el("span", { cls: "sm", text: String(r[13] || "") })].concat(hm14Badges(k, ok))')
rep('''" · Lãi " + L.fmt(k2.tong) + (x.goc ? " · Trả gốc " + L.fmt(x.goc) : ""));''',
    '''" · Lãi " + L.fmt(k2.tong) + (x.goc ? " · Trả gốc " + L.fmt(x.goc) : ""));
      hm14CopyLines(x).forEach(function (z) { t.push("   " + z); });''')

s = s[:m.start(1)] + g + s[m.end(1):]
CSS = '''<style id="gd14-hm14-css">
.g14c-h14{border:1px solid #c7d2fe;background:#eef2ff;border-radius:8px;padding:6px 10px;margin:6px 0;display:flex;flex-direction:column;gap:4px}
.g14c-h14r{display:flex;flex-wrap:wrap;gap:8px;align-items:center}.g14c-h14r select{width:auto;min-width:200px}
.g14c-h14i{font-size:12px;color:#475569}
.g14c-t td.ipl{background:#fff7ed;color:#9a3412;font-weight:700}.g14c-t td.ip0{color:#15803d;font-weight:700}
.g14c-t .sm.q12{color:#b45309;font-weight:700}.g14c-t .sm.dn{color:#1d4ed8;font-weight:700}
@media (max-width:600px){.g14c-h14r select{min-height:40px;width:100%}}
</style>
'''
assert s.count('<style id="gd16-css">') == 1
s = s.replace('<style id="gd16-css">', CSS + '<style id="gd16-css">')
c = s.count('24.17.16'); assert c == 2, c
s = s.replace('24.17.16', '24.17.17')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.16' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.16', '24.17.17'))
print('OK', DST, 'lõi sha256', hashlib.sha256(core.encode()).hexdigest()[:16], 'md5', hashlib.md5(s.encode()).hexdigest())
