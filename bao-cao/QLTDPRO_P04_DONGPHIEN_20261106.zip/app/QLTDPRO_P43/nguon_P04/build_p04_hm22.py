# P04 · HM-22 · v24.17.25 — Trang Tài sản bảo đảm: thêm cột Số TS, Số HĐ thế chấp (plgno, LCA…), Số giải ngân (ghép từ msit80:
# các khế ước dsbsseq còn dư nợ > 0 của khách hàng — theo mã KH, không có thì theo mã chủ TS; ghép theo tên → để trống),
# bật mặc định Số HĐ thế chấp / Số giải ngân / Địa chỉ TS. Bố cục bảng đã lưu trước đây chuyển sang bộ mới MỘT lần (cờ l22).
# Người dùng 06/11. Chạy từ app/QLTDPRO_P43/:  python3 nguon_P04/build_p04_hm22.py
import hashlib
SRC = 'app/QLTDPRO_v24.17.24.html'; DST = 'app/QLTDPRO_v24.17.25.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:80]); s = s.replace(old, new)
rep('{id:"machu",label:"Mã chủ TS",kind:"text",width:130,get:e=>za(e.maChuTS),copy:!0},',
    '{id:"machu",label:"Mã chủ TS",kind:"text",width:130,get:e=>za(e.maChuTS),copy:!0},{id:"sots",label:"Số TS",kind:"text",width:120,get:e=>e.soTS,copy:!0},{id:"hdtc",label:"Số HĐ thế chấp",kind:"text",width:160,get:e=>e.soHDTC,copy:!0},{id:"sogn",label:"Số giải ngân (còn dư nợ)",kind:"text",width:200,get:e=>(e.soGN||[]).join(", "),copy:!0},')
rep('{id:"dc",label:"Địa chỉ / mô tả",kind:"text",width:220,get:e=>e.diaChiTS}', '{id:"dc",label:"Địa chỉ TS",kind:"text",width:240,get:e=>e.diaChiTS}')
rep('function N4(e,t){const n=db(t);',
    'function N4(e,t){const n=db(t),gnm=Object.create(null);for(const x of t||[]){if(!x||!(ei(x[11])>0))continue;const k=ct(x[0]),q=String(x[20]??"").trim();k&&q&&(gnm[k]=gnm[k]||[]).push(q)}')
rep('return u?(r++,c.duNoHienTai=u.dn,c.matchBy=g,', 'return c.soGN=g==="ma"?gnm[h]||[]:g==="chu"?gnm[d]||[]:[],u?(r++,c.duNoHienTai=u.dn,c.matchBy=g,')
rep("'tai-san-bao-dam':  { lead: ['ten','cb','hh','conlai','tc','dg','ma','loai','gt','tl','dn','tt'], pin:['ten','cb','hh'], sort:[{id:'hh',desc:false}], show:['ten','cb','hh','conlai','tc','dg','ma','loai','gt','tl','dn','tt'] },",
    "'tai-san-bao-dam':  { lead: ['ten','cb','hh','conlai','tc','dg','ma','hdtc','sogn','dc','loai','gt','tl','dn','tt'], pin:['ten','cb','hh'], sort:[{id:'hh',desc:false}], show:['ten','cb','hh','conlai','tc','dg','ma','hdtc','sogn','dc','loai','gt','tl','dn','tt'] },")
rep("  if (id === 'lai-dong') def.l07 = 1;", "  if (id === 'lai-dong') def.l07 = 1;\n  if (id === 'tai-san-bao-dam') def.l22 = 1;")
rep("  if (ok && id === 'lai-dong' && !ok.l07) ok = null;", "  if (ok && id === 'lai-dong' && !ok.l07) ok = null;\n  if (ok && id === 'tai-san-bao-dam' && !ok.l22) ok = null; /* HM-22: bộ cột TS mới áp một lần */")
c = s.count('"24.17.24"'); assert c == 2, c
s = s.replace('"24.17.24"', '"24.17.25"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.24' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.24', '24.17.25'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
