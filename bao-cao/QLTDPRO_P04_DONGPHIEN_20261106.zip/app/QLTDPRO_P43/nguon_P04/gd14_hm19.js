  /* ================= HM-19 + HM-13 (P04, v24.17.19): một lối vào, bảng Gọn ≤ 9 cột, tổng dính, thẻ điện thoại,
   * bảng phân rã lãi (từ–đến–ngày–DN–LS–tiền), ghi chú nguồn 3 tổng trang Lãi đọng.
   * CHỈ đổi trình bày: mọi số lấy nguyên từ it.k (QLTDLai.hm14 → tinhLaiKhoan), không tính lại. ================= */
  var HM19_AN = [1, 4, 5, 8, 10, 11, 12, 13]; // cột ẩn ở chế độ Gọn (thứ tự cột đầy đủ)
  function hm19Day(isoS, n) { var t = L.parseDate(isoS); return t == null ? "" : iso(t + n * 86400000); }
  function hm19Layout(bd) {
    var tbl = bd.querySelector("[data-testid=gd14-calc-table]");
    var se = bd.querySelector(".g14c-sum"), cap = bd.querySelector(".g14c-cap");
    if (se && cap) bd.insertBefore(se, cap);              // tổng lên trên bảng, dính đầu khung cuộn
    if (!tbl || !tbl.tHead) return;
    var gon = C.cols !== "full";
    tbl.classList.toggle("cmp", gon);
    if (cap) cap.appendChild(el("button", { cls: "g14c-btn sm", "data-testid": "gd14-calc-cols", title: "Gọn: 9 cột chính · Đầy đủ: mọi cột kèm tên trường IPCAS",
      text: gon ? "⇔ Xem đầy đủ cột" : "⇔ Thu gọn cột", onclick: function () { C.cols = gon ? "full" : ""; render(); } }));
    var hr = tbl.tHead.rows[0], ths = Array.prototype.slice.call(hr.cells);
    var lb = ths.map(function (h) { return (h.firstChild && h.firstChild.nodeType === 3 ? h.firstChild.nodeValue : h.textContent).trim(); });
    HM19_AN.forEach(function (i) { if (ths[i]) ths[i].classList.add("x"); });
    if (ths[14]) hr.insertBefore(el("th", { cls: "y", title: "Lãi trong hạn + lãi quá hạn (LS × 1,5, gồm phạt). Từng đoạn: mục 📊 dưới bảng" }, [document.createTextNode("LÃI TRONG HẠN / QUÁ HẠN")]), ths[14]);
    Array.prototype.forEach.call(tbl.tBodies[0].rows, function (tr, ri) {
      var it = C.loans[ri], tds = Array.prototype.slice.call(tr.cells), okR = tr.getAttribute("data-ok") === "1";
      tds.forEach(function (td, j) {
        if (lb[j] && !td.hasAttribute("colspan")) td.setAttribute("data-lb", lb[j]);
        if (HM19_AN.indexOf(j) >= 0 && (okR || j < 10)) td.classList.add("x");
      });
      if (!it) return;
      var r = it.r, k = it.k;
      if (tds[2]) {
        var ls = L.normalizeRate(r[8]);
        var info = [el("span", { cls: "sm y", text: "Đến hạn " + (dmy(r[7]) || "—") + " · LS " + (ls != null ? L.fmtDec(ls) + "%" : "—") })];
        var lv = String(r[13] || "").replace(/\s*\(TK \d+\)/, "");
        var tag = [lv];
        if (okR && k && k.q12) tag.push("Q12 từ " + dmy(k.q12.ngay));
        if (okR && k && k.doan) tag.push(k.doan.length + " đoạn dư nợ");
        if (tag.join("")) info.push(el("span", { cls: "sm y" + (okR && k && k.q12 ? " q12" : ""), text: tag.filter(Boolean).join(" · ") }));
        info.forEach(function (x) { tds[2].appendChild(x); });
      }
      if (!okR) { var w = tr.querySelector("td.why"); if (w) w.setAttribute("colspan", gon ? "3" : "6"); return; }
      var lai = [el("div", { text: k.soNgayTH > 0 ? "TH " + L.fmt(k.laiTH) + " · " + k.soNgayTH + " ngày" : "TH —" })];
      if (k.soNgayQH > 0) lai.push(el("div", { cls: "qhv", text: "QH " + L.fmt(k.laiQH) + " · " + k.soNgayQH + " ngày" }));
      if (tds[14]) tr.insertBefore(el("td", { cls: "n y", "data-lb": "LÃI TH / QH", "data-testid": "gd14-calc-lai2" }, lai), tds[14]);
    });
    hm19PhanRa(bd);
  }
  function hm19PhanRa(bd) {
    var items = C.loans.filter(function (x) { return x.tick && x.k && x.k.ok; });
    if (!items.length) return;
    var det = el("details", { cls: "g14c-det", "data-testid": "gd14-calc-phanra", open: items.length <= 3 ? "" : null }, [
      el("summary", { text: "📊 Bảng phân rã lãi từng khoản (" + items.length + " khoản) — từ ngày, đến ngày, số ngày, dư nợ, lãi suất, tiền" })]);
    items.forEach(function (x) {
      var k = x.k, r = x.r, parts = k.doan || [{ tu: k.moc, den: k.chot, duno: k.duno, soNgayTH: k.soNgayTH, laiTH: k.laiTH, soNgayQH: k.soNgayQH, laiQHCB: k.laiQHCB, laiQHPhat: k.laiQHPhat }];
      var rows = [];
      parts.forEach(function (p) {
        var lsF = L.fmtDec(k.ls) + "%";
        if (p.soNgayTH > 0) rows.push(["Trong hạn", dmy(p.tu), dmy(hm19Day(p.tu, p.soNgayTH)), p.soNgayTH, L.fmt(p.duno), lsF, L.fmt(p.laiTH)]);
        if (p.soNgayQH > 0) {
          var tuQ = hm19Day(p.tu, p.soNgayTH);
          rows.push(["Quá hạn (LS × 1,5)", dmy(tuQ), dmy(p.den), p.soNgayQH, L.fmt(p.duno), L.fmtDec(k.ls * 1.5) + "%", L.fmt(p.laiQHCB + p.laiQHPhat) + " (" + L.fmt(p.laiQHCB) + " + phạt " + L.fmt(p.laiQHPhat) + ")"]);
        }
        if (!p.soNgayTH && !p.soNgayQH) rows.push(["Dư nợ 0", dmy(p.tu), dmy(p.den), 0, L.fmt(p.duno), "—", "0"]);
      });
      var ct = k.chamTraApDung === false ? "Không áp dụng — ngắn hạn/thấu chi (Q12)" : (k.q12 ? "Đã tính trong quá hạn LS × 1,5 từ kỳ trả lãi " + dmy(k.q12.ngay) + " (Q12/Q15)" : "Không phát sinh (chưa quá kỳ trả lãi)");
      var tb = el("tbody", {}, rows.map(function (a) { return el("tr", {}, a.map(function (v, i) { return el("td", { cls: i >= 3 ? "n" : "", text: String(v) }); })); })
        .concat([el("tr", { cls: "ct" }, [el("td", { text: "Chậm trả" }), el("td", { colspan: "6", text: ct })]),
                 el("tr", { cls: "tg" }, [el("td", { colspan: "6", text: "TỔNG LÃI" }), el("td", { cls: "n", "data-testid": "gd14-calc-phanra-tong", text: L.fmt(k.tong) })])]));
      det.appendChild(el("div", { cls: "g14c-pr" }, [
        el("b", { text: (r[2] || "") + (r[20] ? " / " + r[20] : "") + " · đến hạn " + (dmy(r[7]) || "—") }),
        el("div", { cls: "g14c-prw" }, [el("table", { cls: "g14c-prt" }, [el("thead", {}, [el("tr", {}, ["Phần", "Từ ngày", "Đến ngày", "Số ngày", "Dư nợ", "Lãi suất", "Tiền (đ)"].map(function (h) { return el("th", { text: h }); }))]), tb])])
      ]));
    });
    bd.appendChild(det);
  }
  function hm19Ku(c) {
    var a = c.rows.filter(function (r) { return duNo(r) > 0; }).sort(function (x, y) { return (L.parseDate(x[7]) || 0) - (L.parseDate(y[7]) || 0); });
    if (!a.length) return "Không còn khoản dư nợ";
    return "📄 " + a.slice(0, 3).map(function (r) { return (r[20] || r[2] || "?") + " (đến hạn " + (dmy(r[7]) || "—") + ")"; }).join(" · ") + (a.length > 3 ? " · +" + (a.length - 3) + " khoản" : "");
  }
  /* Trang Lãi đọng: ghi rõ nguồn 3 tổng (bundle không sửa; đọc DOM, chỉ thêm ghi chú) */
  function hm19Num(s) { var m = String(s || "").replace(/[^\d]/g, ""); return m ? Number(m) : 0; }
  function hm19LaiDong() {
    var dt = document.querySelector("[data-testid=gd14-tong-duthu]"); if (!dt) return;
    var tg = document.querySelector("[data-testid=tong]");
    var M = tg ? hm19Num(tg.textContent) : 0, T = hm19Num(dt.textContent);
    var txt = "ⓘ Σ lãi = lãi đọng IPCAS (cột intamt) của các khoản đang hiện (thẻ \"Tổng lãi đọng\" cùng nguồn, theo phạm vi đang chọn) · Σ lãi dự thu = app tự tính đến ngày chốt (365 ngày, quá hạn LS × 1,5, Q12) · khác nghĩa, chênh " + L.fmt(T - M) + " đ";
    var n = document.querySelector("[data-testid=gd14-ld-note]");
    if (!n) { n = el("span", { cls: "g14c-ldn", "data-testid": "gd14-ld-note" }); dt.parentNode.insertBefore(n, dt.nextSibling); }
    if (n.textContent !== txt) { n.textContent = txt; n.setAttribute("data-m", String(M)); n.setAttribute("data-t", String(T)); }
  }
  (function () {
    var q = false;
    function go() {
      new MutationObserver(function () { if (q) return; q = true; requestAnimationFrame(function () { q = false; try { hm19LaiDong(); } catch (e) {} }); })
        .observe(document.body, { childList: true, subtree: true, characterData: true });
    }
    if (document.body) go(); else document.addEventListener("DOMContentLoaded", go);
  })();

