/* gd23 1.0.0 — HM-23 + HM-24 (P04, 06/11/2026) — Trang Tài sản bảo đảm.
 * (1) Q16: mỗi lần lưu tệp sao kê TSBĐ → thêm mốc "moc_<ngày tệp>" vào kho kv sẵn có của CSDL QLTDProTSBD (không tạo CSDL mới,
 *     sao lưu toàn bộ vẫn đủ); bản cài cũ chưa có mốc → tạo mốc từ dữ liệu hiện hành MỘT lần. Mốc bấm tay giữ nguyên.
 * (2) Tab "🆕 TS chưa có HĐTD": tài sản mà khách KHÔNG có dòng nào (kể cả dư nợ 0) trong mốc dư nợ Lưu trữ cùng ngày / gần nhất trước đó;
 *     gom Phòng → Cán bộ, so mốc trước: mới / đã có HĐTD / không còn trong sao kê; bấm số xem danh sách; Xuất Excel.
 * (3) Tab "📅 Đầu kỳ & 2 mốc": bảng như Báo cáo ngày (Đầu năm/quý/tháng = mốc gần nhất ≤ ngày cuối kỳ trước — Q14) cho
 *     Số TS / Giá trị TS / TS chưa có HĐTD; chọn 2 mốc bất kỳ (tự lưu hoặc bấm tay) xem thêm / mất / đổi trạng thái.
 * Chỉ ĐỌC dữ liệu khác; nội dung dựng bằng textContent (không innerHTML dữ liệu). */
(function () {
  "use strict";
  var DB = "QLTDProTSBD", MAXM = 120;
  var F = ["soTS", "maKH", "maChuTS", "tenKH", "tenChuTS", "cbtd", "phong", "giaTriTS", "tienTe", "loaiTS", "ngayTheChap", "soHDTC", "diaChiTS"];
  function p2(x) { return String(x).padStart(2, "0"); }
  function isoOf(d) { return d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate()); }
  function vn(iso) { return iso ? iso.slice(8, 10) + "/" + iso.slice(5, 7) + "/" + iso.slice(0, 4) : ""; }
  function ngayTep(src) {
    var s = String(src || "").replace(/\.[A-Za-z0-9]{2,5}$/, ""), re = /(?:^|[^\d])(\d{1,2})[._\-\/](\d{1,2})[._\-\/](\d{4}|\d{2})(?!\d)/g, m, last = null;
    while ((m = re.exec(s))) {
      var y = +m[3]; if (y < 100) y += 2000;
      var d = new Date(y, +m[2] - 1, +m[1]);
      if (d.getFullYear() === y && d.getMonth() === +m[2] - 1 && d.getDate() === +m[1]) last = isoOf(d);
      re.lastIndex = m.index + 1;
    }
    return last;
  }
  function gon(rows) { return (rows || []).filter(Boolean).map(function (r) { var o = {}; F.forEach(function (f) { if (r[f] != null && r[f] !== "") o[f] = r[f]; }); return o; }); }
  function normMa(x) { return String(x == null ? "" : x).replace(/[^0-9A-Za-z]/g, "").toUpperCase(); }
  function normTen(x) { return String(x == null ? "" : x).toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/g, "d").replace(/\s+/g, " ").trim(); }
  function num(x) { var n = Number(x); return isFinite(n) ? n : 0; }
  function vnd(r) { var t = String(r.tienTe || "VND").toUpperCase().trim(); return !t || t === "VND"; }
  function fmt(n) { return Math.round(n).toLocaleString("vi-VN"); }
  function ngayVN(x) { var t = String(x == null ? "" : x).trim(), m = /^(\d{4})-(\d{2})-(\d{2})/.exec(t); return m ? m[3] + "/" + m[2] + "/" + m[1] : t; }
  function E(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  function toast(m) { try { window.gd9Toast && window.gd9Toast(m, true); } catch (e) {} }

  /* ---------- (1) lưu mốc theo ngày tệp ---------- */
  function datMoc(store, rows, src, luc) {
    var ngay = ngayTep(src) || isoOf(luc ? new Date(luc) : new Date());
    store.put({ ngay: ngay, src: String(src || ""), luc: new Date().toISOString(), auto: 1, rows: gon(rows) }, "moc_" + ngay);
    var kq = store.getAllKeys();
    kq.onsuccess = function () { var ks = (kq.result || []).map(String).filter(function (x) { return x.indexOf("moc_") === 0; }).sort(); while (ks.length > MAXM) store.delete(ks.shift()); };
    return ngay;
  }
  function caiMoc() {
    var g = window.__khmTsbdHistSave;
    if (g && g.__gd23) return;
    var f = function (store, rows, src) {
      try { if (g) g(store, rows, src); } catch (e) {}
      try { datMoc(store, rows, src); } catch (e) { toast("⚠️ Không lưu được mốc tài sản theo ngày tệp: " + ((e && e.message) || e)); }
    };
    f.__gd23 = 1; window.__khmTsbdHistSave = f;
  }
  caiMoc(); document.addEventListener("DOMContentLoaded", caiMoc);

  function mo() {
    return new Promise(function (res, rej) {
      var r = indexedDB.open(DB, 1);
      r.onupgradeneeded = function () { var d = r.result; if (!d.objectStoreNames.contains("kv")) d.createObjectStore("kv"); if (!d.objectStoreNames.contains("snapshots")) d.createObjectStore("snapshots", { keyPath: "id" }); };
      r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); };
    });
  }
  function docTatCa() {
    return mo().then(function (db) {
      return new Promise(function (res) {
        var out = { auto: [], cur: null, tay: [] };
        try {
          var tx = db.transaction(["kv", "snapshots"], "readonly"), kv = tx.objectStore("kv");
          var rk = kv.getAllKeys(), rv = kv.getAll(), rs = tx.objectStore("snapshots").getAll();
          tx.oncomplete = function () {
            var ks = rk.result || [], vs = rv.result || [];
            for (var i = 0; i < ks.length; i++) {
              var k = String(ks[i]), v = vs[i];
              if (k === "current" && v && Array.isArray(v.rows)) out.cur = v;
              else if (k.indexOf("moc_") === 0 && v && Array.isArray(v.rows)) out.auto.push(v);
            }
            out.auto.sort(function (a, b) { return a.ngay < b.ngay ? -1 : a.ngay > b.ngay ? 1 : 0; });
            out.tay = (rs.result || []).slice().sort(function (a, b) { return (a.ts || 0) - (b.ts || 0); });
            db.close(); res(out);
          };
          tx.onerror = function () { db.close(); res(out); };
        } catch (e) { db.close(); res(out); }
      });
    });
  }
  function boSung(d) { /* bản cài cũ: tạo mốc từ dữ liệu hiện hành nếu chưa có mốc cho ngày đó */
    if (!d.cur || !d.cur.rows.length) return Promise.resolve(d);
    var ngay = ngayTep(d.cur.src) || (d.cur.importedAt ? isoOf(new Date(d.cur.importedAt)) : isoOf(new Date()));
    if (d.auto.some(function (a) { return a.ngay === ngay; })) return Promise.resolve(d);
    return mo().then(function (db) {
      return new Promise(function (res) {
        try { var tx = db.transaction("kv", "readwrite"); datMoc(tx.objectStore("kv"), d.cur.rows, d.cur.src, d.cur.importedAt); tx.oncomplete = function () { db.close(); res(); }; tx.onerror = function () { db.close(); res(); }; }
        catch (e) { db.close(); res(); }
      });
    }).then(docTatCa);
  }

  /* ---------- dư nợ ở một ngày (mốc Lưu trữ gần nhất ≤ ngày) ---------- */
  var cacheDN = {};
  function duNoTai(iso) {
    var A = window.__gd11Api; if (!A || !A.arcList) return Promise.resolve(null);
    var by = {};
    A.arcList().forEach(function (m) { var d = A.vnToIso(m.dayKey || ""); if (!d || d > iso) return; if (!by[d] || (m.timestamp || 0) > (by[d].timestamp || 0)) by[d] = m; });
    var ds = Object.keys(by).sort(); if (!ds.length) return Promise.resolve(null);
    var d = ds[ds.length - 1];
    if (!cacheDN[d]) cacheDN[d] = Promise.all([A.loadArcRows(by[d]).catch(function () { return null; }), A.loadZeroRows ? A.loadZeroRows(by[d]).catch(function () { return null; }) : Promise.resolve(null)])
      .then(function (x) {
        if (!x[0]) { delete cacheDN[d]; toast("⚠️ Không đọc được mốc dư nợ " + vn(d) + " trong Lưu trữ — chưa xác định được tài sản chưa có HĐTD."); return null; }
        var ma = {}, ten = {}, dup = {};
        x[0].concat(x[1] || []).forEach(function (r) {
          if (!r) return; var k = normMa(r[0]); if (k) ma[k] = 1;
          var t = normTen(r[1]); if (t) { if (ten[t] && ten[t] !== (k || 1)) dup[t] = 1; ten[t] = k || 1; }
        });
        return { ngay: d, ma: ma, ten: ten, dup: dup };
      });
    return cacheDN[d];
  }
  function coHS(r, dn) {
    var a = normMa(r.maKH), b = normMa(r.maChuTS);
    if (a && dn.ma[a]) return true;
    if (b && dn.ma[b]) return true;
    var t = normTen(r.tenKH) || normTen(r.tenChuTS);
    return !!(t && dn.ten[t] && !dn.dup[t]);
  }
  var cacheMoc = {};
  function tinhMoc(m) { /* m = mốc tự lưu {ngay, rows} → {ngay, dn, ds:[{k, r, co}]} (mỗi TS một lần theo Số TS) */
    var key = "a" + m.ngay + "#" + (m.luc || "");
    if (!cacheMoc[key]) cacheMoc[key] = duNoTai(m.ngay).then(function (dn) {
      var seen = {}, ds = [];
      (m.rows || []).forEach(function (r, i) { var k = String(r.soTS || "").trim() || ("#" + normMa(r.maKH) + i); if (seen[k]) return; seen[k] = 1; ds.push({ k: k, r: r, co: dn ? coHS(r, dn) : null }); });
      return { ngay: m.ngay, dn: dn ? dn.ngay : null, ds: ds, ten: "📅 " + vn(m.ngay) + " (tự lưu)" };
    });
    return cacheMoc[key];
  }
  function tinhTay(z, tra) { /* mốc bấm tay: keys [soTS, maKH, giaTriTS, trangThai]; cán bộ/phòng tra theo Số TS từ mốc tự lưu mới nhất */
    var seen = {}, ds = [];
    (z.keys || []).forEach(function (a, i) {
      var k = String(a[0] || "").trim() || ("#" + i); if (seen[k]) return; seen[k] = 1;
      var r = Object.assign({}, tra[k] || {}, { soTS: a[0], maKH: a[1], giaTriTS: a[2] });
      ds.push({ k: k, r: r, co: a[3] === "kct" ? false : true });
    });
    return Promise.resolve({ ngay: z.ts ? isoOf(new Date(z.ts)) : "", dn: "(trạng thái lúc lưu)", ds: ds, ten: "✋ " + (z.label || "Mốc tay") + " (lưu " + (z.ts ? new Date(z.ts).toLocaleDateString("vi-VN") : "") + ")" });
  }
  function cb(r) { return String(r.cbtd || "").trim() || "(chưa ghi cán bộ)"; }
  function ph(r) { return String(r.phong || "").trim() || "(chưa ghi phòng)"; }
  function nhom(lists) { /* gom thứ tự Phòng → Cán bộ từ mọi danh sách */
    var m = {};
    lists.forEach(function (L) { (L || []).forEach(function (x) { var p = ph(x.r), c = cb(x.r); (m[p] = m[p] || {})[c] = 1; }); });
    return Object.keys(m).sort(function (a, b) { return a.localeCompare(b, "vi"); }).map(function (p) { return { p: p, cbs: Object.keys(m[p]).sort(function (a, b) { return a.localeCompare(b, "vi"); }) }; });
  }

  /* ---------- bảng dùng chung ---------- */
  function bang(cols, rowsSpec, onCell, tid) {
    var w = E("div", "gd23-wrap"), t = E("table", "gd23-t"); t.setAttribute("data-testid", tid);
    var th = E("thead"), tr = E("tr");
    cols.forEach(function (c) { var h = E("th", c.n ? "n" : "", c.t); if (c.title) h.title = c.title; tr.appendChild(h); });
    th.appendChild(tr); t.appendChild(th);
    var tb = E("tbody");
    rowsSpec.forEach(function (rs) {
      var r = E("tr", rs.cls || ""); if (rs.attrs) Object.keys(rs.attrs).forEach(function (a) { r.setAttribute(a, rs.attrs[a]); });
      rs.cells.forEach(function (v, i) {
        var c = cols[i], td = E("td", c.n ? "n" : "");
        td.setAttribute("data-lb", c.t);
        if (c.k) td.setAttribute("data-k", c.k);
        if (onCell && c.k && rs.click && typeof v === "number" && v) {
          var b = E("button", "gd23-so", c.fmt ? c.fmt(v) : fmt(v)); b.type = "button";
          b.addEventListener("click", function () { onCell(rs.click, c.k); }); td.appendChild(b);
        } else td.textContent = v == null ? "—" : (typeof v === "number" ? (c.fmt ? c.fmt(v) : fmt(v)) : String(v));
        r.appendChild(td);
      });
      tb.appendChild(r);
    });
    t.appendChild(tb); w.appendChild(t); return w;
  }
  function chiTiet(host, tieuDe, items, extraCol, ten) {
    var old = host.querySelector(".gd23-ct"); if (old) old.remove();
    var box = E("div", "gd23-ct"); box.setAttribute("data-testid", "gd23-chitiet");
    var hd = E("div", "gd23-ctbar"); hd.appendChild(E("b", null, tieuDe + " — " + items.length + " tài sản"));
    var xl = E("button", "gd23-btn", "⬇ Xuất Excel"); xl.type = "button"; xl.setAttribute("data-testid", "gd23-xlsx");
    xl.addEventListener("click", function () {
      try {
        var X = window.XLSX;
        var aoa = [["Số TS", "Số HĐ thế chấp", "Khách hàng", "Mã KH", "Mã chủ TS", "Phòng", "Cán bộ", "Loại TS", "Giá trị TS", "Ngày thế chấp", "Địa chỉ TS", extraCol || "Ghi chú"]]
          .concat(items.map(function (x) { var r = x.r; return [r.soTS || "", r.soHDTC || "", r.tenKH || r.tenChuTS || "", r.maKH || "", r.maChuTS || "", ph(r), cb(r), r.loaiTS || "", num(r.giaTriTS), ngayVN(r.ngayTheChap), r.diaChiTS || "", x.ghi || ""]; }));
        if (window.__gd15TaiXlsx) window.__gd15TaiXlsx((ten || "TS") + ".xlsx", [{ name: "TS", rows: aoa }]);   /* bộ ghi .xlsx sẵn có của gd15 */
        else if (X && X.utils) { var wb = X.utils.book_new(); X.utils.book_append_sheet(wb, X.utils.aoa_to_sheet(aoa), "TS"); X.writeFile(wb, (ten || "TS") + ".xlsx"); }
        else throw new Error("không có bộ ghi Excel");
      } catch (e) { toast("⚠️ Không xuất được Excel: " + ((e && e.message) || e)); }
    });
    hd.appendChild(xl); box.appendChild(hd);
    var cols = [{ t: "Số TS" }, { t: "Số HĐ thế chấp" }, { t: "Khách hàng" }, { t: "Mã KH" }, { t: "Cán bộ" }, { t: "Loại TS" }, { t: "Giá trị TS", n: 1 }, { t: "Ngày thế chấp" }, { t: "Địa chỉ TS" }, { t: extraCol || "Ghi chú" }];
    box.appendChild(bang(cols, items.map(function (x) { var r = x.r; return { attrs: { "data-sots": x.k }, cells: [r.soTS || "", r.soHDTC || "", r.tenKH || r.tenChuTS || "", r.maKH || r.maChuTS || "", cb(r), r.loaiTS || "", num(r.giaTriTS), ngayVN(r.ngayTheChap), r.diaChiTS || "", x.ghi || ""] }; }), null, "gd23-ct-t"));
    host.appendChild(box); box.scrollIntoView({ block: "nearest" });
  }
  function chon(opts, val, tid, onch) {
    var s = E("select", "gd23-sel"); s.setAttribute("data-testid", tid);
    opts.forEach(function (o) { var x = E("option", null, o[1]); x.value = o[0]; if (o[0] === val) x.selected = true; s.appendChild(x); });
    s.addEventListener("change", function () { onch(s.value); }); return s;
  }

  /* ---------- (2) tab TS chưa có HĐTD ---------- */
  var S23 = { moc: "", so: "" };
  function ve23(host) {
    host.textContent = ""; host.appendChild(E("div", "gd23-note", "⏳ Đang đọc mốc tài sản và dư nợ…"));
    docTatCa().then(boSung).then(function (d) {
      host.textContent = "";
      if (!d.auto.length) { host.appendChild(E("div", "gd23-note", "Chưa có mốc tài sản. Nhập tệp sao kê TSBĐ ở trang Nhập dữ liệu — mỗi tệp tự lưu một mốc theo ngày trong tên tệp.")); return; }
      var ng = d.auto.map(function (a) { return a.ngay; });
      if (ng.indexOf(S23.moc) < 0) S23.moc = ng[ng.length - 1];
      var iB = ng.indexOf(S23.moc);
      if (S23.so && S23.so !== "-" && (ng.indexOf(S23.so) < 0 || S23.so >= S23.moc)) S23.so = "";
      if (!S23.so) S23.so = iB > 0 ? ng[iB - 1] : "-";
      var bar = E("div", "gd23-bar");
      bar.appendChild(E("b", null, "Mốc:"));
      bar.appendChild(chon(d.auto.slice().reverse().map(function (a) { return [a.ngay, vn(a.ngay) + " · " + (a.src || "").slice(0, 40)]; }), S23.moc, "gd23-kct-moc", function (v) { S23.moc = v; S23.so = ""; ve23(host); }));
      bar.appendChild(E("b", null, "So với:"));
      bar.appendChild(chon([["-", "— không so —"]].concat(d.auto.filter(function (a) { return a.ngay < S23.moc; }).reverse().map(function (a) { return [a.ngay, vn(a.ngay)]; })), S23.so, "gd23-kct-so", function (v) { S23.so = v; ve23(host); }));
      host.appendChild(bar);
      var mB = d.auto[iB], mA = S23.so !== "-" ? d.auto[ng.indexOf(S23.so)] : null;
      Promise.all([tinhMoc(mB), mA ? tinhMoc(mA) : Promise.resolve(null)]).then(function (x) {
        var B = x[0], A = x[1];
        host.appendChild(E("div", "gd23-note", "Tài sản CHƯA CÓ HĐTD = khách (theo mã KH → mã chủ TS → tên không trùng) không có dòng nào, kể cả dư nợ 0, trong mốc dư nợ Lưu trữ " + (B.dn ? vn(B.dn) : "—") + " (mốc dư nợ gần nhất ≤ " + vn(B.ngay) + ")." + (A ? " So với mốc TS " + vn(A.ngay) + " (dư nợ " + (A.dn ? vn(A.dn) : "—") + ")." : "")));
        if (!B.dn) { host.appendChild(E("div", "gd23-note red", "⚠️ Chưa có mốc dư nợ ≤ " + vn(B.ngay) + " trong Lưu trữ — không xác định được tài sản chưa có HĐTD. Nhập tệp msit80 cùng ngày hoặc trước đó.")); return; }
        var kB = {}, inB = {}, kA = {};
        B.ds.forEach(function (z) { inB[z.k] = z; if (z.co === false) kB[z.k] = z; });
        if (A) A.ds.forEach(function (z) { if (z.co === false) kA[z.k] = z; });
        var loai = {
          n: function (z) { return kB[z.k] ? [z] : []; },
          moi: function (z) { return kB[z.k] && A && !kA[z.k] ? [z] : []; }
        };
        var grp = nhom([B.ds, A ? A.ds : []]), rowsSpec = [], T = { n: 0, gt: 0, moi: 0, daco: 0, mat: 0 };
        var dsKA = A ? A.ds.filter(function (z) { return z.co === false; }) : [];
        function dem(p, c) {
          var o = { n: 0, gt: 0, moi: 0, daco: 0, mat: 0 };
          Object.keys(kB).forEach(function (k) { var z = kB[k]; if (ph(z.r) !== p || (c && cb(z.r) !== c)) return; o.n++; if (vnd(z.r)) o.gt += num(z.r.giaTriTS); if (A && !kA[k]) o.moi++; });
          dsKA.forEach(function (z) { if (ph(z.r) !== p || (c && cb(z.r) !== c)) return; var b = inB[z.k]; if (b && b.co === true) o.daco++; else if (!b) o.mat++; });
          return o;
        }
        grp.forEach(function (g) {
          rowsSpec.push({ cls: "ph", cells: [g.p, null, null, null, null, null] });
          g.cbs.forEach(function (c) { var o = dem(g.p, c); if (!o.n && !o.daco && !o.mat) return; rowsSpec.push({ attrs: { "data-cb": c }, click: { p: g.p, c: c }, cells: [c, o.n, o.gt / 1e6, A ? o.moi : null, A ? o.daco : null, A ? o.mat : null] }); });
          var t = dem(g.p, null); ["n", "gt", "moi", "daco", "mat"].forEach(function (f) { T[f] += t[f]; });
          rowsSpec.push({ cls: "tong", attrs: { "data-cb": "Tổng " + g.p }, click: { p: g.p, c: null }, cells: ["Tổng " + g.p, t.n, t.gt / 1e6, A ? t.moi : null, A ? t.daco : null, A ? t.mat : null] });
        });
        rowsSpec.push({ cls: "tong", attrs: { "data-cb": "TỔNG" }, click: { p: null, c: null }, cells: ["TỔNG", T.n, T.gt / 1e6, A ? T.moi : null, A ? T.daco : null, A ? T.mat : null] });
        var cols = [{ t: "Phòng / Cán bộ" }, { t: "TS chưa có HĐTD", n: 1, k: "n" }, { t: "Giá trị (tr.đ)", n: 1, k: "gt", fmt: function (v) { return fmt(v); } },
          { t: "Mới (so mốc trước)", n: 1, k: "moi", title: "Chưa có HĐTD ở mốc này nhưng chưa có trong danh sách chưa-có-HĐTD ở mốc trước (TS mới nhập)" },
          { t: "Đã có HĐTD", n: 1, k: "daco", title: "Mốc trước chưa có HĐTD, mốc này khách đã có hồ sơ vay" },
          { t: "Không còn trong sao kê", n: 1, k: "mat", title: "Mốc trước chưa có HĐTD, mốc này không còn tài sản trong tệp sao kê" }];
        var loc = function (sel, k) {
          var keep = function (z) { return (!sel.p || ph(z.r) === sel.p) && (!sel.c || cb(z.r) === sel.c); }, items;
          if (k === "n" || k === "gt") items = Object.keys(kB).map(function (x) { return kB[x]; }).filter(keep).map(function (z) { return { k: z.k, r: z.r, ghi: A ? (kA[z.k] ? "Đã chưa-có-HĐTD từ " + vn(A.ngay) : "Mới so " + vn(A.ngay)) : "" }; });
          else if (k === "moi") items = Object.keys(kB).map(function (x) { return kB[x]; }).filter(function (z) { return keep(z) && A && !kA[z.k]; }).map(function (z) { return { k: z.k, r: z.r, ghi: "Mới so " + vn(A.ngay) }; });
          else if (k === "daco") items = dsKA.filter(function (z) { var b = inB[z.k]; return keep(z) && b && b.co === true; }).map(function (z) { return { k: z.k, r: inB[z.k].r, ghi: "Đã có HĐTD ở " + vn(B.ngay) }; });
          else items = dsKA.filter(function (z) { return keep(z) && !inB[z.k]; }).map(function (z) { return { k: z.k, r: z.r, ghi: "Không còn trong sao kê " + vn(B.ngay) }; });
          var tt = { n: "TS chưa có HĐTD", gt: "TS chưa có HĐTD", moi: "Mới chưa có HĐTD", daco: "Đã có HĐTD", mat: "Không còn trong sao kê" }[k];
          chiTiet(host, tt + " · " + (sel.c || (sel.p ? "Tổng " + sel.p : "Toàn chi nhánh")) + " · mốc " + vn(B.ngay), items, "So mốc trước", "TS_chua_HDTD_" + B.ngay);
        };
        host.appendChild(bang(cols, rowsSpec, loc, "gd23-kct-t"));
      });
    }).catch(function (e) { host.textContent = ""; host.appendChild(E("div", "gd23-note red", "⚠️ Không đọc được mốc tài sản: " + ((e && e.message) || e))); });
  }

  /* ---------- (3) tab Đầu kỳ & 2 mốc ---------- */
  var S24 = { cs: "kct", A: "", B: "" };
  function cuoiKy(iso, kieu) { /* ngày cuối kỳ trước của ngày iso: nam / quy / thang */
    var y = +iso.slice(0, 4), m = +iso.slice(5, 7);
    if (kieu === "nam") return (y - 1) + "-12-31";
    if (kieu === "quy") { var q = Math.floor((m - 1) / 3); return q === 0 ? (y - 1) + "-12-31" : isoOf(new Date(y, q * 3, 0)); }
    return isoOf(new Date(y, m - 1, 0));
  }
  function moiNhat(auto, iso) { var r = null; auto.forEach(function (a) { if (a.ngay <= iso) r = a; }); return r; }
  function soLieu(M, cs) { /* M = kết quả tinhMoc → {"phòng|cán bộ": giá trị} */
    var o = {};
    if (!M) return null;
    M.ds.forEach(function (z) {
      var key = ph(z.r) + "\u0001" + cb(z.r), v;
      if (cs === "n") v = 1; else if (cs === "gt") v = vnd(z.r) ? num(z.r.giaTriTS) / 1e6 : 0; else v = z.co === false ? 1 : 0;
      o[key] = (o[key] || 0) + v;
    });
    if (cs === "kct" && !M.dn) return null;
    return o;
  }
  function ve24(host) {
    host.textContent = ""; host.appendChild(E("div", "gd23-note", "⏳ Đang đọc mốc tài sản…"));
    docTatCa().then(boSung).then(function (d) {
      host.textContent = "";
      if (!d.auto.length) { host.appendChild(E("div", "gd23-note", "Chưa có mốc tài sản. Nhập tệp sao kê TSBĐ — mỗi tệp tự lưu một mốc theo ngày trong tên tệp.")); return; }
      var bc = d.auto[d.auto.length - 1];
      var moc = { nam: moiNhat(d.auto, cuoiKy(bc.ngay, "nam")), quy: moiNhat(d.auto, cuoiKy(bc.ngay, "quy")), thang: moiNhat(d.auto, cuoiKy(bc.ngay, "thang")), bc: bc };
      var bar = E("div", "gd23-bar"); bar.appendChild(E("b", null, "Chỉ số:"));
      bar.appendChild(chon([["kct", "TS chưa có HĐTD"], ["n", "Số tài sản"], ["gt", "Giá trị TS (tr.đ)"]], S24.cs, "gd23-dk-cs", function (v) { S24.cs = v; ve24(host); }));
      host.appendChild(bar);
      var keys = ["nam", "quy", "thang", "bc"];
      Promise.all(keys.map(function (k) { return moc[k] ? tinhMoc(moc[k]) : Promise.resolve(null); })).then(function (R) {
        var V = R.map(function (M) { return soLieu(M, S24.cs); });
        var nh = function (k, i, lb) { return lb + (moc[k] ? " (mốc " + vn(moc[k].ngay) + ")" : " (chưa có mốc)") + (V[i] === null && moc[k] ? " — chưa có dư nợ" : ""); };
        var cols = [{ t: "Phòng / Cán bộ" }, { t: nh("nam", 0, "Đầu năm"), n: 1 }, { t: nh("quy", 1, "Đầu quý"), n: 1 }, { t: nh("thang", 2, "Đầu tháng"), n: 1 }, { t: "Ngày BC (mốc " + vn(bc.ngay) + ")", n: 1 },
          { t: "+/- đầu tháng", n: 1 }, { t: "+/- đầu quý", n: 1 }, { t: "+/- đầu năm", n: 1 }];
        var grp = nhom(R.filter(Boolean).map(function (M) { return M.ds; })), rowsSpec = [], tot = [0, 0, 0, 0];
        var gt = function (i, p, c) { if (!V[i]) return null; var s = 0; Object.keys(V[i]).forEach(function (k) { var a = k.split("\u0001"); if (a[0] === p && (c == null || a[1] === c)) s += V[i][k]; }); return s; };
        var hieu = function (a, b) { return a == null || b == null ? null : a - b; };
        var dong = function (lbl, p, c, cls) { var v = [0, 1, 2, 3].map(function (i) { return gt(i, p, c); }); return { cls: cls, attrs: { "data-cb": lbl }, cells: [lbl, v[0], v[1], v[2], v[3], hieu(v[3], v[2]), hieu(v[3], v[1]), hieu(v[3], v[0])] }; };
        grp.forEach(function (g) {
          rowsSpec.push({ cls: "ph", cells: [g.p, null, null, null, null, null, null, null] });
          g.cbs.forEach(function (c) { rowsSpec.push(dong(c, g.p, c, "")); });
          var t = dong("Tổng " + g.p, g.p, null, "tong"); rowsSpec.push(t);
          [1, 2, 3, 4].forEach(function (i) { tot[i - 1] = t.cells[i] == null || tot[i - 1] == null ? null : tot[i - 1] + t.cells[i]; });
        });
        rowsSpec.push({ cls: "tong", attrs: { "data-cb": "TỔNG" }, cells: ["TỔNG", tot[0], tot[1], tot[2], tot[3], hieu(tot[3], tot[2]), hieu(tot[3], tot[1]), hieu(tot[3], tot[0])] });
        cols.forEach(function (c, i) { if (i) c.fmt = function (v) { return (i >= 5 && v > 0 ? "+" : "") + (S24.cs === "gt" ? fmt(v) : fmt(v)); }; });
        host.appendChild(E("div", "gd23-note", "Đầu năm / Đầu quý / Đầu tháng = mốc tài sản tự lưu gần nhất ≤ ngày cuối kỳ trước của Ngày BC (như Báo cáo ngày, Q14). Ngày BC = mốc tài sản mới nhất."));
        host.appendChild(bang(cols, rowsSpec, null, "gd23-dk-t"));
        ve2Moc(host, d);
      });
    }).catch(function (e) { host.textContent = ""; host.appendChild(E("div", "gd23-note red", "⚠️ Không đọc được mốc tài sản: " + ((e && e.message) || e))); });
  }
  function ve2Moc(host, d) {
    var box = E("div", "gd23-2moc"); box.setAttribute("data-testid", "gd23-2moc");
    box.appendChild(E("h4", null, "So sánh 2 mốc bất kỳ"));
    var opts = d.auto.slice().reverse().map(function (a) { return ["a:" + a.ngay, "📅 " + vn(a.ngay) + " (tự lưu)"]; })
      .concat(d.tay.slice().reverse().map(function (z) { return ["t:" + z.id, "✋ " + (z.label || "Mốc tay") + " (lưu " + new Date(z.ts || 0).toLocaleDateString("vi-VN") + ")"]; }));
    var vals = opts.map(function (o) { return o[0]; });
    if (vals.indexOf(S24.B) < 0) S24.B = vals[0];
    if (vals.indexOf(S24.A) < 0) S24.A = vals[1] || vals[0];
    var bar = E("div", "gd23-bar");
    bar.appendChild(E("b", null, "Mốc A:")); bar.appendChild(chon(opts, S24.A, "gd23-2moc-a", function (v) { S24.A = v; ve2(); }));
    bar.appendChild(E("b", null, "Mốc B:")); bar.appendChild(chon(opts, S24.B, "gd23-2moc-b", function (v) { S24.B = v; ve2(); }));
    box.appendChild(bar);
    var kq = E("div"); box.appendChild(kq); host.appendChild(box);
    var tra = {}; (d.auto.length ? d.auto[d.auto.length - 1].rows : []).forEach(function (r) { var k = String(r.soTS || "").trim(); if (k && !tra[k]) tra[k] = r; });
    function lay(v) { if (v.indexOf("a:") === 0) { var a = d.auto.filter(function (x) { return x.ngay === v.slice(2); })[0]; return tinhMoc(a); } var z = d.tay.filter(function (x) { return String(x.id) === v.slice(2); })[0]; return tinhTay(z, tra); }
    function ve2() {
      kq.textContent = "";
      Promise.all([lay(S24.A), lay(S24.B)]).then(function (x) {
        var A = x[0], B = x[1], mA = {}, mB = {};
        A.ds.forEach(function (z) { mA[z.k] = z; }); B.ds.forEach(function (z) { mB[z.k] = z; });
        var grp = nhom([A.ds, B.ds]), rowsSpec = [], T = [0, 0, 0, 0, 0];
        var dem = function (p, c) {
          var keep = function (z) { return ph(z.r) === p && (c == null || cb(z.r) === c); }, o = [0, 0, 0, 0, 0];
          A.ds.forEach(function (z) { if (!keep(z)) return; o[0]++; if (!mB[z.k]) o[3]++; });
          B.ds.forEach(function (z) { if (!keep(z)) return; o[1]++; if (!mA[z.k]) o[2]++; else if (mA[z.k].co !== null && z.co !== null && mA[z.k].co !== z.co) o[4]++; });
          return o;
        };
        grp.forEach(function (g) {
          rowsSpec.push({ cls: "ph", cells: [g.p, null, null, null, null, null] });
          g.cbs.forEach(function (c) { var o = dem(g.p, c); rowsSpec.push({ attrs: { "data-cb": c }, click: { p: g.p, c: c }, cells: [c].concat(o) }); });
          var t = dem(g.p, null); t.forEach(function (v, i) { T[i] += v; });
          rowsSpec.push({ cls: "tong", attrs: { "data-cb": "Tổng " + g.p }, click: { p: g.p, c: null }, cells: ["Tổng " + g.p].concat(t) });
        });
        rowsSpec.push({ cls: "tong", attrs: { "data-cb": "TỔNG" }, click: { p: null, c: null }, cells: ["TỔNG"].concat(T) });
        var cols = [{ t: "Phòng / Cán bộ" }, { t: "Số TS ở A", n: 1, k: "a" }, { t: "Số TS ở B", n: 1, k: "b" }, { t: "Thêm (có ở B, không ở A)", n: 1, k: "them" }, { t: "Mất (có ở A, không ở B)", n: 1, k: "mat" }, { t: "Đổi trạng thái HĐTD", n: 1, k: "doi" }];
        kq.appendChild(E("div", "gd23-note", "A = " + A.ten + " · B = " + B.ten + ". Đổi trạng thái HĐTD: tài sản có ở cả hai mốc nhưng chuyển giữa \"chưa có HĐTD\" và \"đã có hồ sơ\"."));
        kq.appendChild(bang(cols, rowsSpec, function (sel, k) {
          var keep = function (z) { return (!sel.p || ph(z.r) === sel.p) && (!sel.c || cb(z.r) === sel.c); }, it;
          if (k === "a") it = A.ds.filter(keep).map(function (z) { return { k: z.k, r: z.r, ghi: z.co === false ? "Chưa có HĐTD" : "Đã có hồ sơ" }; });
          else if (k === "b") it = B.ds.filter(keep).map(function (z) { return { k: z.k, r: z.r, ghi: z.co === false ? "Chưa có HĐTD" : "Đã có hồ sơ" }; });
          else if (k === "them") it = B.ds.filter(function (z) { return keep(z) && !mA[z.k]; }).map(function (z) { return { k: z.k, r: z.r, ghi: "Thêm ở B" }; });
          else if (k === "mat") it = A.ds.filter(function (z) { return keep(z) && !mB[z.k]; }).map(function (z) { return { k: z.k, r: z.r, ghi: "Mất ở B" }; });
          else it = B.ds.filter(function (z) { var a = mA[z.k]; return keep(z) && a && a.co !== null && z.co !== null && a.co !== z.co; }).map(function (z) { return { k: z.k, r: z.r, ghi: (z.co ? "Chưa có HĐTD → đã có hồ sơ" : "Đã có hồ sơ → chưa có HĐTD") }; });
          chiTiet(kq, { a: "Số TS ở A", b: "Số TS ở B", them: "Thêm", mat: "Mất", doi: "Đổi trạng thái HĐTD" }[k] + " · " + (sel.c || (sel.p ? "Tổng " + sel.p : "Toàn chi nhánh")), it, "So 2 mốc", "TS_so_2_moc");
        }, "gd23-2moc-t"));
      });
    }
    ve2();
  }

  /* ---------- gắn vào khung tab React ---------- */
  function gan() {
    var a = document.getElementById("gd23-kct"); if (a && !a.getAttribute("data-m")) { a.setAttribute("data-m", "1"); ve23(a); }
    var b = document.getElementById("gd23-dk"); if (b && !b.getAttribute("data-m")) { b.setAttribute("data-m", "1"); ve24(b); }
  }
  function go() {
    var q = false;
    new MutationObserver(function () { if (q) return; q = true; requestAnimationFrame(function () { q = false; gan(); }); }).observe(document.body, { childList: true, subtree: true });
    gan();
  }
  if (document.body) go(); else document.addEventListener("DOMContentLoaded", go);
  window.__gd23 = { PHIEN_BAN: "1.0.0", ngayTep: ngayTep, docTatCa: docTatCa, xoaCache: function () { cacheDN = {}; cacheMoc = {}; } };
})();
