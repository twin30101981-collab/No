# P04 · HM-05 · v24.17.24 — lỗi bị nuốt âm thầm ở luồng nghiệp vụ → thông báo ngắn (window.gd9Toast có sẵn). Không đổi số liệu/luồng.
#  H1 gd11 loadMidSnaps: mốc giữa kỳ đọc lỗi → báo ngày mốc lỗi (trước: bỏ qua) + trả về danh sách lỗi; nơi gọi .catch(()=>null) → báo.
#     Xuất loadMidSnaps trong __gd11Api (chỉ đọc) để kiểm.
#  H2 gd14 hm14Hist: đọc Lưu trữ lỗi → báo "đang tính 1 đoạn" (trước: im lặng).
#  H3 khung Phương án SXKD: nạp / tự lưu / bấm lưu lỗi → báo (trước: catch{} rỗng). Tự lưu: ≤ 1 thông báo / 15 giây.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P04/build_p04_hm05.py
import hashlib, re
SRC = 'app/QLTDPRO_v24.17.23.html'; DST = 'app/QLTDPRO_v24.17.24.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:80]); s = s.replace(old, new)
T = 'window.gd9Toast&&window.gd9Toast'
# H1
rep('  var days=Object.keys(byDay).sort(),seen=new Map();', '  var days=Object.keys(byDay).sort(),seen=new Map(),loi=[];')
rep("""    }).catch(function(){});
  })},Promise.resolve()).then(function(){return{rows:Array.from(seen.values()),days:days.length}});""",
    """    }).catch(function(e){loi.push(d);try{""" + T + """('⚠️ Không đọc được mốc Lưu trữ '+d.split('-').reverse().join('/')+' — báo cáo có thể thiếu khoản giải ngân giữa kỳ ('+((e&&e.message)||e)+').',true)}catch(_){}});
  })},Promise.resolve()).then(function(){return{rows:Array.from(seen.values()),days:days.length,loi:loi}});""")
rep('loadMidSnaps(md,mc,all).catch(function(){return null})',
    "loadMidSnaps(md,mc,all).catch(function(e){try{" + T + "('⚠️ Không đọc được các mốc giữa kỳ — báo cáo chỉ dùng mốc đầu và cuối ('+((e&&e.message)||e)+').',true)}catch(_){}return null})")
rep('window.__gd11Api={arcList:arcList,', 'window.__gd11Api={arcList:arcList,loadMidSnaps:loadMidSnaps,')
# H2
rep("""      C.histOk = true;
      render();
    }).catch(function () {});""", """      C.histOk = true;
      render();
    }).catch(function (e) { C.histLoi = String((e && e.message) || e); try { """ + T + """("⚠️ Không đọc được Lưu trữ để tính lãi theo đoạn dư nợ — đang tính 1 đoạn theo dư nợ hiện tại (" + C.histLoi + ").", true); } catch (_) {} });""")
# H2b — đọc từng mốc lỗi (catch → null) trong hm14LoadArc: ghi lại + báo 1 lần mỗi lần mở hộp
rep('return Promise.all([A.loadArcRows(m.meta).catch(function () { return null; }),',
    'return Promise.all([A.loadArcRows(m.meta).catch(function (e) { (C.arcLoi = C.arcLoi || []).push(m.ngay); return null; }),')
rep('C.kyLai = ""; C.arc = null;', 'C.kyLai = ""; C.arc = null; C.arcLoi = []; C.arcLoiBao = 0;')
rep("""      C.histOk = true;
      render();
    }).catch(function (e) {""", """      C.histOk = true;
      if (C.arcLoi && C.arcLoi.length && !C.arcLoiBao) { C.arcLoiBao = 1; try { """ + T + """("⚠️ Không đọc được " + C.arcLoi.length + " mốc Lưu trữ (" + C.arcLoi.map(function (d) { return d.split("-").reverse().join("/"); }).join(", ") + ") — lãi theo đoạn dư nợ có thể thiếu đoạn.", true); } catch (_) {} }
      render();
    }).catch(function (e) {""")
# H3
rep('setTimeout(()=>{try{u.loadData()}catch{}},250)', 'setTimeout(()=>{try{u.loadData()}catch(x){' + T + '("⚠️ Không nạp được phương án SXKD đã lưu: "+(x&&x.message||x),!0)}},250)')
rep('r=setTimeout(()=>{try{typeof u.saveData=="function"&&u.saveData()}catch{}},900)',
    'r=setTimeout(()=>{try{typeof u.saveData=="function"&&u.saveData()}catch(x){const n=Date.now();n-(window.__paErrT||0)>15e3&&(window.__paErrT=n,' + T + '("⚠️ Không tự lưu được phương án SXKD — thay đổi chưa được lưu: "+(x&&x.message||x),!0))}},900)')
rep('save:()=>{var u,g;try{(g=(u=s())==null?void 0:u.saveData)==null||g.call(u)}catch{}}',
    'save:()=>{var u,g;try{(g=(u=s())==null?void 0:u.saveData)==null||g.call(u)}catch(x){' + T + '("⚠️ Không lưu được phương án SXKD: "+(x&&x.message||x),!0)}}')
rep('load:u=>{var g,f;try{localStorage.setItem(Ui,u),(f=(g=s())==null?void 0:g.loadData)==null||f.call(g)}catch{}}',
    'load:u=>{var g,f;try{localStorage.setItem(Ui,u),(f=(g=s())==null?void 0:g.loadData)==null||f.call(g)}catch(x){' + T + '("⚠️ Không nạp được phương án SXKD: "+(x&&x.message||x),!0)}}')
c = s.count('"24.17.23"'); assert c == 2, c
s = s.replace('"24.17.23"', '"24.17.24"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.23' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.23', '24.17.24'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
