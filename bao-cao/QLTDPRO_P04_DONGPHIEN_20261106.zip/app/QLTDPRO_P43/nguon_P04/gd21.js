/* gd21 1.0.0 — HM-03 (P04): báo rõ khi bộ nhớ trình duyệt (localStorage) ĐẦY.
 * Chỉ bọc setItem: gọi lệnh ghi gốc; nếu lỗi QuotaExceededError → hiện thông báo (≤ 1 lần / 20 giây) rồi NÉM LẠI lỗi
 * để mọi nơi gọi xử lý như cũ (không đổi luồng, không đổi schema, không xoá dữ liệu). */
(function () {
  "use strict";
  var goc = Storage.prototype.setItem, last = 0;
  function laDay(e) { return !!e && (e.name === "QuotaExceededError" || e.name === "NS_ERROR_DOM_QUOTA_REACHED" || e.code === 22 || e.code === 1014); }
  function bao(k) {
    try {
      if (!document.body) return;
      var b = document.querySelector('[data-testid="gd21-quota"]');
      if (!b) {
        b = document.createElement("div"); b.setAttribute("data-testid", "gd21-quota"); b.setAttribute("role", "alert");
        b.style.cssText = "position:fixed;left:12px;right:12px;bottom:12px;z-index:9999;background:#FDF0EE;color:#7A1F14;border:1px solid #B42318;border-radius:10px;padding:10px 14px;font-size:13px;box-shadow:0 6px 20px rgba(0,0,0,.18);display:flex;gap:10px;align-items:flex-start";
        var t = document.createElement("span"); t.setAttribute("data-gd21", "t"); b.appendChild(t);
        var x = document.createElement("button"); x.type = "button"; x.textContent = "✕"; x.setAttribute("aria-label", "Đóng");
        x.style.cssText = "margin-left:auto;border:0;background:none;font-size:16px;cursor:pointer;min-width:32px;min-height:32px";
        x.addEventListener("click", function () { b.remove(); }); b.appendChild(x);
        document.body.appendChild(b);
      }
      b.querySelector('[data-gd21="t"]').textContent = "⚠ Bộ nhớ trình duyệt đã ĐẦY — thay đổi vừa rồi (" + String(k).slice(0, 40) + ") KHÔNG được lưu. Dữ liệu dư nợ, mốc lưu trữ (IndexedDB) vẫn an toàn. Hãy vào Lưu trữ → \"Tải bản sao lưu toàn bộ\", rồi xoá bớt mốc cũ không dùng.";
    } catch (e) {}
  }
  Storage.prototype.setItem = function (k, v) {
    try { return goc.call(this, k, v); }
    catch (e) { if (laDay(e)) { var n = Date.now(); if (n - last > 20000) { last = n; bao(k); } } throw e; }
  };
  window.__gd21 = { PHIEN_BAN: "1.0.0" };
})();
