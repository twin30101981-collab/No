# P49 · v24.17.5 — Trang Khách hàng mới (tab Chi tiết): mã KH copy được như các trang khác
SRC='app/QLTDPRO_v24.17.4.html'; DST='app/QLTDPRO_v24.17.5.html'
s=open(SRC,encoding='utf-8').read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n,('anchor count',c,n,old[:70]); s=s.replace(old,new)
# Mã KH (brcd) dưới tên khách: dùng đúng ô copy cC của các trang khác (chạm để copy, gạch chấm, toast "📋 Đã copy Mã KH: …")
rep('o.jsxs("small",{className:"text-muted-foreground",children:[L.brcd,L.khMoi&&',
    'o.jsxs("small",{className:"text-muted-foreground",children:[L.brcd?o.jsx("span",{className:"inline-block align-middle","data-testid":"khm-makh",children:o.jsx(cC,{text:String(L.brcd).trim(),label:"Mã KH"})}):null,L.khMoi&&')
rep('24.17.4','24.17.5',s.count('24.17.4'))
open(DST,'w',encoding='utf-8').write(s)
for f in ('app/sw.js','app/manifest.json'):
    t=open(f,encoding='utf-8').read().replace('24.17.4','24.17.5').replace('p48-','p49-')
    open(f,'w',encoding='utf-8').write(t)
print('OK',DST)
