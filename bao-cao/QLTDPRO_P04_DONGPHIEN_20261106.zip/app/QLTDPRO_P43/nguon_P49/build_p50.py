# P50 · v24.17.6 — Trang Khách hàng mới (tab Chi tiết): tách "Mã KH" thành CỘT RIÊNG ngay sau cột Khách hàng
SRC='app/QLTDPRO_v24.17.5.html'; DST='app/QLTDPRO_v24.17.6.html'
s=open(SRC,encoding='utf-8').read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n,('anchor count',c,n,old[:70]); s=s.replace(old,new)
MK='L.brcd?o.jsx("span",{className:"inline-block align-middle","data-testid":"khm-makh",children:o.jsx(cC,{text:String(L.brcd).trim(),label:"Mã KH"})}):null,'
# 1) bỏ mã khỏi dòng nhỏ dưới tên (tên đứng một mình, nhãn mới/cầm cố/đã tất toán ở dòng nhỏ)
rep('children:['+MK+'L.khMoi&&','children:[L.khMoi&&')
# 2) cột riêng sau cột tên
rep('children:"cầm cố?"})]})]}),o.jsx("td",{className:"border px-2 py-1",children:Ee.fmtDate(L.dsbsdt)})',
    'children:"cầm cố?"})]})]}),o.jsx("td",{className:"border px-2 py-1 whitespace-nowrap","data-testid":"khm-makh",children:L.brcd?o.jsx(cC,{text:String(L.brcd).trim(),label:"Mã KH"}):null}),o.jsx("td",{className:"border px-2 py-1",children:Ee.fmtDate(L.dsbsdt)})')
# 3) tiêu đề + colSpan
rep('["Khách hàng","Ngày GN","Số tiền"','["Khách hàng","Mã KH","Ngày GN","Số tiền"')
rep('colSpan:9,className:"p-4 text-center text-muted-foreground",children:"Không có món vay phù hợp."','colSpan:10,className:"p-4 text-center text-muted-foreground",children:"Không có món vay phù hợp."')
rep('24.17.5','24.17.6',s.count('24.17.5'))
open(DST,'w',encoding='utf-8').write(s)
for f in ('app/sw.js','app/manifest.json'):
    t=open(f,encoding='utf-8').read().replace('24.17.5','24.17.6').replace('p49-','p50-')
    open(f,'w',encoding='utf-8').write(t)
print('OK',DST)
