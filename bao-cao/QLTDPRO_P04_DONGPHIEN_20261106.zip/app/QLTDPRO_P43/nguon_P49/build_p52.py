# P52 · v24.17.8 — Rà soát toàn bộ: mọi nơi HIỂN THỊ mã KH đều dạng 3201-xxxxxxxxx qua MỘT hàm chung window.QLTD_maKH
# Gốc rễ: trước đây có 4 bản sao quy tắc (maFmt, on, za, khối inline khm) + nhiều chỗ in mã thô -> lệch khi sửa 1 nơi.
# Quy tắc (giữ nguyên P51): đúng 13 chữ số -> 4 số đầu + "-" + 9 số cuối; mã khác độ dài giữ nguyên.
SRC='app/QLTDPRO_v24.17.7.html'; DST='app/QLTDPRO_v24.17.8.html'
s=open(SRC,encoding='utf-8').read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n,('anchor count',c,n,old[:90]); s=s.replace(old,new)
# 1) Hàm chung, nạp TRƯỚC mọi khối khác (CSP đã cho phép script nội tuyến)
rep('<script id="gd7-js">',
 '<script id="makh-js">(function(){"use strict";function f(v){var t=String(v==null?"":v).trim();return /^\\d{13}$/.test(t)?t.slice(0,4)+"-"+t.slice(4):t}'
 'try{Object.defineProperty(window,"QLTD_maKH",{value:f,writable:false,configurable:false})}catch(e){window.QLTD_maKH=f}})();</script>\n<script id="gd7-js">')
# 2) Các bản sao cũ -> uỷ quyền cho hàm chung
rep("function maFmt(v){ var t = String(v == null ? '' : v).trim(); return /^\\d{13}$/.test(t) ? t.slice(0,4) + '-' + t.slice(4) : t; }",
    "function maFmt(v){ return window.QLTD_maKH(v); }")
rep('function on(e){const t=String(e??"").trim();return/^\\d{13}$/.test(t)?t.slice(0,4)+"-"+t.slice(4):t}',
    'function on(e){return window.QLTD_maKH(e)}')
rep('za=e=>{const t=ct(e);return t.length===13?t.slice(0,4)+"-"+t.slice(4):t||Fe(e)}',
    'za=e=>{const t=ct(e);return t.length===13?window.QLTD_maKH(t):t||Fe(e)}')
rep('text:(t=>/^\\d{13}$/.test(t)?t.slice(0,4)+"-"+t.slice(4):t)(String(L.brcd).trim())','text:on(L.brcd)')
# 3) Chỗ in mã thô
rep('}),String(r[0]??"")]}):null}','}),o.jsx(cC,{text:on(r[0]),label:"Mã KH"})]}):null}')   # ô Mã KH có huy hiệu HSVV (mọi bảng): trước in thô + mất nút copy
rep('o.jsx("td",{style:{padding:"5px 8px",color:"#6b7280"},children:t.ma})','o.jsx("td",{style:{padding:"5px 8px",color:"#6b7280"},children:on(t.ma)})')  # danh sách nhóm nợ chuyển
rep('o.jsx("td",{className:"px-2 py-1 font-mono",children:U[1]})','o.jsx("td",{className:"px-2 py-1 font-mono",children:za(U[1])})')      # TSBĐ lịch sử: đã rút/giải chấp
rep('o.jsx("td",{className:"px-2 py-1 font-mono",children:U.maKH})','o.jsx("td",{className:"px-2 py-1 font-mono",children:za(U.maKH)})')      # TSBĐ lịch sử: đổi trạng thái
rep('children:String(K.v[z.ma]||"").trim()||','children:window.QLTD_maKH(K.v[z.ma])||')                                                                   # Hồ sơ vay: dòng tóm tắt Mã KH
# 4) Máy tính lãi (gd14)
rep('var ten = String(r[1] || ""), ma = String(r[0] || "");','var ten = String(r[1] || ""), ma = String(r[0] || ""), maf = window.QLTD_maKH(ma);')
rep('ma.toLowerCase().indexOf(q) < 0) continue;','ma.toLowerCase().indexOf(q) < 0 && maf.toLowerCase().indexOf(q) < 0) continue;')
rep('el("span", { text: (ten + " · " + ma).slice(0, 60) }),','el("span", { text: (ten + " · " + maf).slice(0, 60) }),')
rep('c.f = fold(c.ten + " " + c.ma + " " +','c.f = fold(c.ten + " " + c.ma + " " + window.QLTD_maKH(c.ma) + " " +')
rep('c.fm = fold(c.ten + " " + c.ma + " " +','c.fm = fold(c.ten + " " + c.ma + " " + window.QLTD_maKH(c.ma) + " " +')
rep('text: c.ten + (c.ma ? " · " + c.ma : "")','text: c.ten + (c.ma ? " · " + window.QLTD_maKH(c.ma) : "")')
rep('"Mã đơn vị (brcd): " + (C.cust.ma || "—")','"Mã đơn vị (brcd): " + (window.QLTD_maKH(C.cust.ma) || "—")')
rep('(C.cust.ma ? " (" + C.cust.ma + ")" : "")','(C.cust.ma ? " (" + window.QLTD_maKH(C.cust.ma) + ")" : "")')
# 5) Nhãn phiên bản
rep('24.17.7','24.17.8',s.count('24.17.7'))
open(DST,'w',encoding='utf-8').write(s)
for f in ('app/sw.js','app/manifest.json'):
    t=open(f,encoding='utf-8').read().replace('24.17.7','24.17.8').replace('p51-','p52-')
    open(f,'w',encoding='utf-8').write(t)
print('OK',DST)
