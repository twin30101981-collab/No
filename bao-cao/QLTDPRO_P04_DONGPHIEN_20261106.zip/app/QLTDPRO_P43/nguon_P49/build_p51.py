# P51 · v24.17.7 — Cột Mã KH trang Khách hàng mới: hiển thị + copy theo định dạng 3201-xxxxxxxxx như các trang khác
# (cùng quy tắc hàm on()/maFmt: đúng 13 chữ số → 4 số đầu + "-" + 9 số cuối; còn lại giữ nguyên)
SRC='app/QLTDPRO_v24.17.6.html'; DST='app/QLTDPRO_v24.17.7.html'
s=open(SRC,encoding='utf-8').read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n,('anchor count',c,n,old[:70]); s=s.replace(old,new)
rep('L.brcd?o.jsx(cC,{text:String(L.brcd).trim(),label:"Mã KH"}):null',
    'L.brcd?o.jsx(cC,{text:(t=>/^\\d{13}$/.test(t)?t.slice(0,4)+"-"+t.slice(4):t)(String(L.brcd).trim()),label:"Mã KH"}):null')
rep('24.17.6','24.17.7',s.count('24.17.6'))
open(DST,'w',encoding='utf-8').write(s)
for f in ('app/sw.js','app/manifest.json'):
    t=open(f,encoding='utf-8').read().replace('24.17.6','24.17.7').replace('p50-','p51-')
    open(f,'w',encoding='utf-8').write(t)
print('OK',DST)
