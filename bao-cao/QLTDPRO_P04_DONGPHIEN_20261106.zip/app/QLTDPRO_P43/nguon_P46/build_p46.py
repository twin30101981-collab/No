# P46 · v24.17.2 — Kho lịch sử TSBĐ (chứng chỉ tiền gửi) theo ngày nạp, dùng tra cầm cố cho món đã tất toán
SRC='app/QLTDPRO_v24.17.1.html'; DST='app/QLTDPRO_v24.17.2.html'
s=open(SRC,encoding='utf-8').read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n,('anchor count',c,n,old[:70]); s=s.replace(old,new)

# 1) Ghi lịch sử mỗi lần lưu sao kê TSBĐ hiện hành: khóa kv "hist_YYYY-MM-DD" (cùng kho kv sẵn có, KHÔNG đổi phiên bản/cấu trúc CSDL), giữ tối đa 90 ngày
rep('r.objectStore("kv").put({rows:e.rows,src:e.src,importedAt:e.importedAt},"current"),await Jd(r)}',
    'r.objectStore("kv").put({rows:e.rows,src:e.src,importedAt:e.importedAt},"current"),window.__khmTsbdHistSave&&window.__khmTsbdHistSave(r.objectStore("kv"),e.rows),await Jd(r)}')
rep("function nonEmptyN(rows){","""var HIST_FIELDS=['soTS','loaiTS','chiTietTS','maKH','maChuTS','tenKH','tenChuTS','giaTriTS','giaTriTC','ngayTheChap','ngayHetHan','phong'],HIST_MAX=90;
window.__khmTsbdHistSave=function(store,rows){
  try{
    var cc=/chứng chỉ tiền gửi/i,p2=function(x){return String(x).padStart(2,'0')};
    var keep=(rows||[]).filter(function(r){return r&&(cc.test(String(r.loaiTS||''))||cc.test(String(r.chiTietTS||'')))}).map(function(r){var o={};HIST_FIELDS.forEach(function(f){if(r[f]!=null)o[f]=r[f]});return o});
    var d=new Date();
    store.put({rows:keep,savedAt:d.toISOString(),n:(rows||[]).length},'hist_'+d.getFullYear()+'-'+p2(d.getMonth()+1)+'-'+p2(d.getDate()));
    var kq=store.getAllKeys();
    kq.onsuccess=function(){var ks=(kq.result||[]).map(String).filter(function(x){return x.indexOf('hist_')===0}).sort();while(ks.length>HIST_MAX)store.delete(ks.shift())};
  }catch(_){}
};
function loadTsbdHist(isoD){
  return idbOpen(TSBD_DB,1,'kv').then(function(db){
    return new Promise(function(res){
      var seen=new Map(),days=0,rq=db.transaction('kv','readonly').objectStore('kv').openCursor();
      rq.onsuccess=function(){var c=rq.result;
        if(!c){db.close();res({rows:Array.from(seen.values()),days:days});return}
        var k=String(c.key);
        if(k.indexOf('hist_')===0&&k.slice(5)>=isoD&&c.value&&Array.isArray(c.value.rows)){
          days++;tsbdToObjects(c.value.rows).forEach(function(o){seen.set(o.clcustno+'|'+o.clno,o)});
        }
        c.continue();
      };
      rq.onerror=function(){db.close();res(null)};
    });
  }).catch(function(){return null});
}
function nonEmptyN(rows){""")

# 2) Nạp từ Lưu trữ: kèm lịch sử TSBĐ từ ngày đầu kỳ
rep("loadMidSnaps(md,mc,all).catch(function(){return null})]).then(function(res){",
    "loadMidSnaps(md,mc,all).catch(function(){return null}),loadTsbdHist(isoD)]).then(function(res){")
rep("mid=res[3];window.__khmMid=","mid=res[3],th=res[4];window.__khmTsbdHist=th?th.rows:[];window.__khmTsbdHistN=th?th.days:0;window.__khmMid=")
rep("window.__khmMid.days+' bản MIS80 giữa 2 mốc.':'')",
    "window.__khmMid.days+' bản MIS80 giữa 2 mốc.':'')+(window.__khmTsbdHistN?' Tra cầm cố thêm '+window.__khmTsbdHistN+' bản lịch sử TSBĐ.':'')")

# 3) buildReport: món tất toán tra cầm cố thêm theo lịch sử TSBĐ
rep("__tt=[],__xk=function(W)","__tt=[],__oh=new Set((window.__khmTsbdHist||[]).filter(d).map(function(W){return a(W.clcustno).trim()})),__xk=function(W)")
rep("camCo:ne&&O.has(re),tatToan:","camCo:ne&&(O.has(re)||(!!W.__tt&&__oh.has(re))),tatToan:")
rep("camCoKXD:!!W.__tt&&ne&&!O.has(re)}","camCoKXD:!!W.__tt&&ne&&!O.has(re)&&!__oh.has(re)}")

rep('24.17.1','24.17.2',s.count('24.17.1'))
open(DST,'w',encoding='utf-8').write(s)
for f in ('app/sw.js','app/manifest.json'):
    t=open(f,encoding='utf-8').read().replace('24.17.1','24.17.2').replace('p45-','p46-')
    open(f,'w',encoding='utf-8').write(t)
print('OK',DST)
