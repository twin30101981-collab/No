# P48 · v24.17.4 — Máy tính lãi: hiện + tìm theo ĐỊA CHỈ khi tra cứu khách hàng (mục 2 đề xuất bổ sung)
# Địa chỉ = r[14] của bản ghi 27 cột (addr1 + commmn, đã ghép sẵn lúc nhập msit80). Không đổi lõi tính lãi, không đổi CSDL, không đổi CSP.
SRC='app/QLTDPRO_v24.17.3.html'; DST='app/QLTDPRO_v24.17.4.html'
s=open(SRC,encoding='utf-8').read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n,('anchor count',c,n,old[:70]); s=s.replace(old,new)

# 1) customers(): lấy địa chỉ đầu tiên không rỗng của KH; đưa vào chuỗi tìm kiếm c.f
rep('map[k] = { key: k, ten: String(r[1]).trim(), ma: String(r[0] || "").trim(), rows: [], hd: {}, f: "" };',
    'map[k] = { key: k, ten: String(r[1]).trim(), ma: String(r[0] || "").trim(), rows: [], hd: {}, f: "", dc: "", fn: "" };')
rep('      map[k].rows.push(r);\n      map[k].hd[String(r[2] || "")] = 1;',
    '      map[k].rows.push(r);\n      if (!map[k].dc) { var dc0 = String(r[14] == null ? "" : r[14]).trim(); if (dc0) map[k].dc = dc0; }\n      map[k].hd[String(r[2] || "")] = 1;')
rep('c.f = fold(c.ten + " " + c.ma + " " + Object.keys(c.hd).join(" "));',
    'c.f = fold(c.ten + " " + c.ma + " " + Object.keys(c.hd).join(" ") + " " + c.dc); c.fn = fold(c.ten); c.fm = fold(c.ten + " " + c.ma + " " + Object.keys(c.hd).join(" "));')

# 2) Tìm: tách từ khoá, mọi từ phải có mặt (tên/mã/HĐTD/địa chỉ, không phân biệt dấu); xếp: khớp tên liền cụm → khớp tên/mã/HĐTD → khớp có dùng địa chỉ (tránh "Phường" lấn "Hương")
rep('var hits = customers().filter(function (c) { return c.f.indexOf(qf) >= 0; }).slice(0, 50);',
    '''var qt = qf.split(/\\s+/).filter(Boolean);
      var hits = customers().filter(function (c) { return qt.every(function (t) { return c.f.indexOf(t) >= 0; }); });
      var rk = function (c) { return c.fn.indexOf(qf) >= 0 ? 0 : (qt.every(function (t) { return c.fm.indexOf(t) >= 0; }) ? 1 : 2); };
      hits.sort(function (a, b) { return rk(a) - rk(b); });
      var nHit = hits.length; hits = hits.slice(0, 50);''')
rep('''      hits.forEach(function (c) {
        var cd = conDuNo(c.rows);
        res.appendChild(el("button", { "data-testid": "gd14-calc-hit", onclick: function () { pick(c); } }, [
          el("span", { text: c.ten + (c.ma ? " · " + c.ma : "") }),''',
'''      hits.forEach(function (c) {
        var cd = conDuNo(c.rows);
        var lk = [el("span", { cls: "hn", text: c.ten + (c.ma ? " · " + c.ma : "") })];
        lk.push(el("span", { cls: "adr", "data-testid": "gd14-calc-hit-addr", text: c.dc ? "📍 " + c.dc : "📍 (chưa có địa chỉ)" }));
        res.appendChild(el("button", { "data-testid": "gd14-calc-hit", onclick: function () { pick(c); } }, [
          el("span", { cls: "hl" }, lk),''')
rep('''      bd.appendChild(res);
    }

    if (!C.cust) {''',
'''      if (nHit > 50) res.appendChild(el("div", { cls: "g14c-empty", "data-testid": "gd14-calc-more", text: "Còn " + (nHit - 50) + " khách hàng nữa — gõ thêm tên đệm / địa chỉ để thu hẹp." }));
      bd.appendChild(res);
    }

    if (!C.cust) {''')
rep('placeholder: "Gõ ít nhất 2 ký tự…"','placeholder: "Gõ tên, mã, số HĐTD hoặc địa chỉ (≥ 2 ký tự)…"')
rep('el("label", { text: "🔍 Tìm khách hàng (tên, mã, số HĐTD)" })','el("label", { text: "🔍 Tìm khách hàng (tên, mã, số HĐTD, địa chỉ)" })')

# 3) Thẻ KH đã chọn + bản copy: thêm dòng địa chỉ
rep('el("div", { cls: "sub", text: "Mã đơn vị (brcd): " + (C.cust.ma || "—") + " · " + C.cust.rows.length + " dòng trong tệp nguồn" })]),',
    'el("div", { cls: "sub", "data-testid": "gd14-calc-diachi", text: "📍 " + (C.cust.dc || "chưa có địa chỉ") }), el("div", { cls: "sub", text: "Mã đơn vị (brcd): " + (C.cust.ma || "—") + " · " + C.cust.rows.length + " dòng trong tệp nguồn" })]),')
rep('t.push("Khách hàng: " + C.cust.ten + (C.cust.ma ? " (" + C.cust.ma + ")" : ""));',
    't.push("Khách hàng: " + C.cust.ten + (C.cust.ma ? " (" + C.cust.ma + ")" : ""));\n    if (C.cust.dc) t.push("Địa chỉ: " + C.cust.dc);')

# 4) CSS
rep('    ".g14c-res button:hover{background:#f0fdf4}",',
    '''    ".g14c-res button:hover{background:#f0fdf4}",
    ".g14c-res{max-height:280px}",
    ".g14c-res button{flex-wrap:wrap;align-items:flex-start}",
    ".g14c-res .hl{display:flex;flex-direction:column;gap:1px;min-width:0;flex:1 1 220px}",
    ".g14c-res .hn{font-weight:600}",
    ".g14c-res .adr{color:#64748b;font-size:11.5px;white-space:normal;word-break:break-word}",''')

rep('24.17.3','24.17.4',s.count('24.17.3'))
open(DST,'w',encoding='utf-8').write(s)
for f in ('app/sw.js','app/manifest.json'):
    t=open(f,encoding='utf-8').read().replace('24.17.3','24.17.4').replace('p47-','p48-')
    open(f,'w',encoding='utf-8').write(t)
print('OK',DST)
