#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""P43 · Ngày thu lãi riêng từng khoản: dựng QLTDPRO_v24.16.0.html từ v24.15.0.
Kế thừa luật P39–P42: chỉ vá chuỗi chính xác đếm đúng số lần; lõi qltd_lai.cjs giữ nguyên từng byte (kiểm sha256);
không mạng, không đổi CSP, không đổi 4 CSDL. gd14_ui.js (P43) = nguon_P42_mtl/gd14_ui.js + các điểm vá dưới đây."""
import hashlib, io, os, sys
ROOT = os.path.dirname(os.path.abspath(__file__)); BASE = os.path.join(ROOT, '..'); APP = os.path.join(BASE, 'app')
SRC = os.path.join(APP, 'QLTDPRO_v24.15.0.html'); DST = os.path.join(APP, 'QLTDPRO_v24.16.0.html')
LOI = os.path.join(BASE, 'nguon_P41', 'qltd_lai.cjs')
LOI_SHA256 = '55908dc63a2d209465f60f1e19f689dfe3001dee7d466acfc6d828a1db85a1a0'
def read(p):
    with io.open(p, encoding='utf-8') as f: return f.read()
def write(p, s):
    with io.open(p, 'w', encoding='utf-8', newline='') as f: f.write(s)
def rep(h, old, new, expect=1):
    n = h.count(old)
    if n != expect: sys.exit('ANCHOR FAIL: expect %d, got %d: %r' % (expect, n, old[:90]))
    return h.replace(old, new)

HELPERS = r'''  /* ---- P43: ngày thu lãi RIÊNG từng khoản (it.chot; trống = theo ngày chung C.chot) ---- */
  function chotOf(it) { return (it.chot && L.parseDate(it.chot) != null) ? it.chot : C.chot; }
  function mocMs(r) { var a = L.parseDate(r && r[23]); return a != null ? a : L.parseDate(r && r[6]); }
  function ngayStat() {
    var set = {}, own = 0, n = 0;
    C.loans.forEach(function (it) { if (!it.tick) return; n++; set[chotOf(it)] = 1; if (it.chot && L.parseDate(it.chot) != null) own++; });
    return { n: n, own: own, distinct: Object.keys(set).length };
  }
  function ngayCell(it, i) {
    var own = !!(it.chot && L.parseDate(it.chot) != null), m = mocMs(it.r);
    var inp = el("input", { type: "date", cls: "g14c-in g14c-nd", "data-fk": "ngay" + i, "data-testid": "gd14-calc-ngay", value: own ? it.chot : "", min: m != null ? iso(m) : null, "aria-label": "Ngày thu lãi riêng" });
    inp.addEventListener("change", function () {
      if (inp.value === "") it.chot = "";
      else if (L.parseDate(inp.value) != null) it.chot = inp.value;
      render();
    });
    var kids = [inp, el("span", { cls: "sm" + (own ? " rg" : ""), "data-testid": "gd14-calc-ngay-lbl", text: own ? "riêng" : "theo ngày chung " + dmy(C.chot) })];
    if (own) kids.push(el("button", { cls: "g14c-btn sm", "data-testid": "gd14-calc-ngay-clr", title: "Bỏ ngày riêng", text: "↺", onclick: function () { it.chot = ""; render(); } }));
    return el("td", { cls: "c" + (own ? " nr" : "") }, kids);
  }
  function bulkBar() {
    var inp = el("input", { type: "date", cls: "g14c-in g14c-nd", "data-fk": "bulk", "data-testid": "gd14-calc-bulk-date", value: C.bulk || "", "aria-label": "Ngày thu lãi cho các khoản đã tick" });
    inp.addEventListener("change", function () { C.bulk = L.parseDate(inp.value) != null ? inp.value : ""; render(); });
    return el("div", { cls: "g14c-bulk", "data-testid": "gd14-calc-bulk" }, [
      el("span", { style: "font-weight:700", text: "📅 Ngày thu lãi riêng:" }), inp,
      el("button", { cls: "g14c-btn sm ok", "data-testid": "gd14-calc-bulk-apply", text: "Áp cho khoản đã tick", onclick: bulkApply }),
      el("button", { cls: "g14c-btn sm", "data-testid": "gd14-calc-bulk-clear", text: "Xoá ngày riêng", onclick: function () { C.loans.forEach(function (x) { x.chot = ""; }); toast("Đã xoá ngày riêng — các khoản theo ngày chung."); render(); } })
    ]);
  }
  function bulkApply() {
    var t = L.parseDate(C.bulk);
    if (t == null) { toast("Chọn ngày thu lãi trước khi áp."); return; }
    var okn = 0, skip = 0;
    C.loans.forEach(function (x) {
      if (!x.tick) return;
      var m = mocMs(x.r);
      if (m != null && t < m) { skip++; return; }
      x.chot = C.bulk; okn++;
    });
    toast("Đã áp ngày " + dmy(C.bulk) + " cho " + okn + " khoản" + (skip ? "; bỏ qua " + skip + " khoản vì ngày thu trước ngày đã thu lãi đến." : "."));
    render();
  }

'''
NGAY_NOTE = r'''    var ns = ngayStat();
    if (ns.own > 0) {
      bd.appendChild(el("div", { cls: "g14c-note", "data-testid": "gd14-calc-ngay-info", text: "📅 " + ns.distinct + " ngày thu khác nhau · " + ns.own + "/" + ns.n + " khoản đã tick dùng ngày riêng (còn lại theo ngày chung " + dmy(C.chot) + ")." }));
    }
'''
def main():
    with open(LOI, 'rb') as f:
        if hashlib.sha256(f.read()).hexdigest() != LOI_SHA256: sys.exit('LÕI qltd_lai.cjs ĐÃ BỊ ĐỔI — dừng')
    g = read(os.path.join(BASE, 'nguon_P42_mtl', 'gd14_ui.js'))
    g = rep(g, '      it.k = L.tinhLaiKhoan(it.r, { chot: C.chot });', '      it.k = L.tinhLaiKhoan(it.r, { chot: chotOf(it) });')
    g = rep(g, '  /* ---- tính toàn bảng (một nguồn: L.tinhLaiKhoan) ---- */\n', HELPERS + '  /* ---- tính toàn bảng (một nguồn: L.tinhLaiKhoan) ---- */\n')
    g = rep(g, '      th("SỐ NGÀY", "chốt − mốc"),', '      th("NGÀY THU LÃI", "trống = ngày chung", "th", "Ngày chốt lãi RIÊNG của khoản này; để trống thì dùng ô Chốt lãi đến ngày ở trên"),\n      th("SỐ NGÀY", "chốt − mốc"),')
    g = rep(g, '      if (ok) {\n        tds.push(el("td", { cls: "c", "data-testid": "gd14-calc-songay"', '      tds.push(ngayCell(it, i));\n      if (ok) {\n        tds.push(el("td", { cls: "c", "data-testid": "gd14-calc-songay"')
    g = rep(g, '    var allOn = C.loans.length && C.loans.every(', '    bd.appendChild(bulkBar());\n    var allOn = C.loans.length && C.loans.every(')
    g = rep(g, '    if (sum.loi.length) {\n      bd.appendChild(el("div", { cls: "g14c-note red"', NGAY_NOTE + '    if (sum.loi.length) {\n      bd.appendChild(el("div", { cls: "g14c-note red"')
    g = rep(g, 'goc: 0, gocWarn: "", k: null }; });', 'goc: 0, gocWarn: "", k: null, chot: "" }; });')
    g = rep(g, 'x.tick = duNo(x.r) > 0; x.goc = 0; x.gocWarn = ""; });', 'x.tick = duNo(x.r) > 0; x.goc = 0; x.gocWarn = ""; x.chot = ""; });\n    C.bulk = "";')
    g = rep(g, 'C.man = {}; C.manLast = null; C.lastCopy = "";\n    C.chot =', 'C.man = {}; C.manLast = null; C.lastCopy = ""; C.bulk = "";\n    C.chot =')
    g = rep(g, '" · mốc " + dmy(k2.moc) + " · TH "', '" · mốc " + dmy(k2.moc) + " → thu đến " + dmy(k2.chot) + " · TH "')
    g = rep(g, '    var n = 0;\n    s.items.forEach(function (x) {', '    var nOwn = s.items.filter(function (x) { return x.chot && L.parseDate(x.chot) != null; }).length;\n    if (nOwn) t.push("Có " + nOwn + " khoản chốt ngày riêng (ghi ở từng dòng: “thu đến”).");\n    var n = 0;\n    s.items.forEach(function (x) {')
    g = rep(g, '    \".g14c-btn.sm{padding:4px 10px;font-size:12px}\",', '    \".g14c-btn.sm{padding:4px 10px;font-size:12px}\",\n    \".g14c-bulk{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:6px 0}.g14c-nd{min-width:128px;width:auto}\",\n    \".g14c-t td.nr{background:#fff7ed}.g14c-t td .sm.rg{color:#c2410c;font-weight:700}\",')
    g = rep(g, 'min-width:1480px', 'min-width:1640px')
    g = rep(g, 'PHIEN_BAN: "P42-GD14 1.1.0"', 'PHIEN_BAN: "P43-GD14 1.2.0"')
    write(os.path.join(ROOT, 'gd14_ui.js'), g)
    h = read(SRC)
    h = rep(h, 'children:["v","24.15.0"," · ","2026-11-03"]', 'children:["v","24.16.0"," · ","2026-11-04"]')
    h = rep(h, 'Wk("24.15.0",r)', 'Wk("24.16.0",r)')
    js = read(LOI) + '\n' + g
    if '</script' in js.lower(): sys.exit('gd14 chứa </script')
    for bad in ('fetch(', 'XMLHttpRequest', 'WebAssembly', 'eval(', 'new Function'):
        if bad in js: sys.exit('gd14 chứa ' + bad)
    if h.count('<script id="gd14-js">') != 1: sys.exit('MARKER FAIL gd14-js mở')
    s = h.find('<script id="gd14-js">'); e = h.find('</script>', s)
    if e < 0: sys.exit('MARKER FAIL gd14-js đóng')
    h = h[:s] + '<script id="gd14-js">\n' + js + '\n' + h[e:]
    write(DST, h)
    sw = read(os.path.join(APP, 'sw.js'))
    sw = rep(sw, 'qltdpro-p42-v24.15.0', 'qltdpro-p43-v24.16.0') if 'qltdpro-p42-v24.15.0' in sw else sw
    sw = sw.replace('QLTDPRO_v24.15.0.html', 'QLTDPRO_v24.16.0.html'); write(os.path.join(APP, 'sw.js'), sw)
    mf = read(os.path.join(APP, 'manifest.json')); write(os.path.join(APP, 'manifest.json'), mf.replace('QLTDPRO_v24.15.0.html', 'QLTDPRO_v24.16.0.html'))
    with open(DST, 'rb') as f: md5 = hashlib.md5(f.read()).hexdigest()
    print('build OK: %s (%d bytes, +%.1f KB) md5 %s' % (os.path.basename(DST), os.path.getsize(DST), (os.path.getsize(DST) - os.path.getsize(SRC)) / 1024.0, md5))
if __name__ == '__main__': main()
