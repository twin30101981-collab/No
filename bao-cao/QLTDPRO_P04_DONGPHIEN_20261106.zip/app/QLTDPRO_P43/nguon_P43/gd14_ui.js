/*
 * GD14 — glue giao diện P42 (kế thừa P41; bổ theo backlog đề án 03/11/2026).
 * Phụ thuộc window.QLTDLai (được nối trước nó trong cùng khối gd14-js, nguồn qltd_lai.cjs).
 * Nguyên tắc: chỉ ĐỌC dữ liệu; không mạng; không đổi CSP; không chạm 4 CSDL cũ.
 * Handle thư mục lưu CSDL RIÊNG QLTDProFolder_v1 (chủ dự án đã chấp nhận — Q6).
 *
 * Mới so với P41:
 *  1. Quét thư mục con TUỲ CHỌN (Q4): mặc định mức 1; ô "Bao gồm thư mục con" lưu cùng CSDL
 *     riêng; khi bật quét đệ quy (sâu tối đa 5 mức, bỏ thư mục ẩn), khoá tệp tính theo ĐƯỜNG
 *     DẪN tương đối nên không trùng tệp cùng tên ở thư mục khác; tệp mức 1 giữ khoá y như P41
 *     nên danh sách đã đề xuất không bị đề xuất lại.
 *  2. Cột "Nguồn" của bảng kế hoạch: tệp lấy từ thư mục được gắn nhãn (gd14src), tệp lấy từ
 *     trong ZIP giữ nguyên chuỗi gd13src của khối gd13 — GD14.nguon(file) trả nhãn hiển thị.
 *
 * Mới ở v24.15.0 (P42 — Máy tính lãi, quyết định nghiệp vụ chốt 03/11/2026):
 *  3. Modal "Máy Tính Lãi — Cơ Sở 365 Ngày" (GD14.openCalc): tra cứu KH / tính tay, bảng khoản vay
 *     ghim cột đầu, thanh 4 tổng, Copy / Reset. Toàn bộ số lãi lấy từ QLTDLai.tinhLaiKhoan —
 *     xử lý 7 lỗi V2 (L1–L7) theo PHAN_TICH_MAY_TINH_LAI_P42.md.
 */
(function () {
  "use strict";
  if (!window.QLTDLai) return;
  var L = window.QLTDLai;

  /* ================= M1 glue · ngày chốt + cột lãi dự thu ================= */

  var CHOT_KEY = "gd14_chot";
  function chotGet() {
    try { var v = localStorage.getItem(CHOT_KEY); if (v && L.parseDate(v) != null) return v; } catch (e) {}
    return iso(L.todayUTC());
  }
  function chotSet(v) {
    try { if (v && L.parseDate(v) != null) localStorage.setItem(CHOT_KEY, v); } catch (e) {}
  }
  function iso(t) { return new Date(t).toISOString().slice(0, 10); }

  // Tổng lãi dự thu đến ngày chốt của 1 khoản (tổng đã tròn; không tính được → null)
  function duThu(row) {
    return L.tinhLaiKhoan(row, { chot: chotGet() });
  }
  function duThuNum(row) {
    var k = duThu(row);
    return k && k.ok ? k.tong : null;
  }

  /* ================= Công cụ "Tính lãi tất toán" (overlay DOM riêng, ngoài React) ================= */

  var toolRows = null, toolEl = null;

  function el(tag, attrs, kids) {
    var e = document.createElement(tag);
    attrs = attrs || {};
    Object.keys(attrs).forEach(function (k) {
      if (k === "text") e.textContent = attrs[k];
      else if (k === "cls") e.className = attrs[k];
      else if (k === "children") return;
      else if (k.slice(0, 2) === "on") e.addEventListener(k.slice(2), attrs[k]);
      else if (attrs[k] != null) e.setAttribute(k, attrs[k]);
    });
    (kids || []).forEach(function (c) { if (c) e.appendChild(c); });
    return e;
  }
  function esc(s) { var d = el("div"); d.textContent = s == null ? "" : String(s); return d.innerHTML; }

  function renderResult(box, row, chot, heSo, chamTra) {
    box.innerHTML = "";
    var k = L.tinhLaiKhoan(row, { chot: chot, heSoQH: heSo });
    var line = function (t, strong) {
      return el("div", { text: t, cls: strong ? "font-semibold" : "text-muted-foreground" });
    };
    if (!k || !k.ok) {
      box.appendChild(el("div", { cls: "rounded-md border border-warn/50 bg-warn/15 px-3 py-2 text-sm text-warn-foreground", text: "Không tính được: " + (k && k.lyDo ? k.lyDo : "lỗi không rõ") }));
      return;
    }
    var card = el("div", { cls: "rounded-md border bg-card p-3 text-sm", "data-testid": "gd14-tool-result" });
    card.appendChild(line("Từ " + k.moc + " (" + k.mocNguon + ") đến " + k.chot + " · dư nợ " + L.fmt(k.duno) + " đ · lãi suất " + L.fmtDec(k.ls) + "%/năm"));
    card.appendChild(el("div", { cls: "my-2 border-t" }));
    card.appendChild(line("Lãi trong hạn: " + k.soNgayTH + " ngày = " + L.fmt(k.laiTH) + " đ", true));
    card.appendChild(line("Lãi quá hạn (cơ bản): " + k.soNgayQH + " ngày = " + L.fmt(k.laiQHCB) + " đ", true));
    card.appendChild(line("Phạt lãi quá hạn (" + L.fmtDec((k.heSoQH - 1) * 100) + "%): " + L.fmt(k.laiQHPhat) + " đ", true));
    card.appendChild(line("TỔNG LÃI: " + L.fmt(k.tong) + " đ", true));
    if (chamTra && k.soNgayQH > 0) {
      var p = L.tinhLaiChamTra(k.duno, k.soNgayQH, 10);
      if (p.ok) {
        card.appendChild(el("div", { cls: "my-2 border-t" }));
        card.appendChild(line(p.chiTiet + " (tách riêng, không tính vào tổng lãi trên)", true));
      }
    }
    k.canhBao.forEach(function (c) {
      card.appendChild(el("div", { cls: "text-warn-foreground", text: "⚠ " + c }));
    });
    card.appendChild(el("div", { cls: "my-2 border-t" }));
    k.chiTiet.forEach(function (c) { card.appendChild(line(c)); });
    box.appendChild(card);
  }

  function renderTool() {
    if (!toolEl || !toolRows) return;
    var q = (toolEl.querySelector("[data-testid=gd14-tool-search]").value || "").trim().toLowerCase();
    var list = toolEl.querySelector("[data-testid=gd14-tool-list]");
    list.innerHTML = "";
    var n = 0;
    for (var i = 0; i < toolRows.length && n < 60; i++) {
      var r = toolRows[i];
      var ten = String(r[1] || ""), ma = String(r[0] || "");
      if (q && ten.toLowerCase().indexOf(q) < 0 && ma.toLowerCase().indexOf(q) < 0) continue;
      n++;
      list.appendChild(el("button", {
        cls: "flex w-full items-center justify-between gap-2 rounded border px-2 py-1.5 text-left text-sm hover:bg-accent",
        "data-testid": "gd14-tool-row",
        onclick: (function (rr) { return function () { renderPick(rr); }; })(r)
      }, [
        el("span", { text: (ten + " · " + ma).slice(0, 60) }),
        el("span", { text: "DN " + L.fmt(Number(r[11]) || 0) + " · LS " + L.fmtDec(Number(String(r[8]).replace(",", ".")) || 0) + "%", cls: "shrink-0 text-xs text-muted-foreground" })
      ]));
    }
    if (!n) list.appendChild(el("p", { cls: "px-2 py-3 text-sm text-muted-foreground", text: "Không có khoản nào khớp từ khoá." }));
    var rs = toolEl.querySelector("[data-testid=gd14-tool-resultbox]");
    rs.innerHTML = "";
    rs.appendChild(el("p", { cls: "px-1 py-2 text-sm text-muted-foreground", text: "Chọn một khoản vay để xem phân rã lãi." }));
  }

  var toolState = { date: null, heSo: "1,5", cham: false };

  function renderPick(row) {
    var rs = toolEl.querySelector("[data-testid=gd14-tool-resultbox]");
    rs.innerHTML = "";
    var dateInput = el("input", {
      type: "date", "data-testid": "gd14-tool-date", cls: "rounded border px-1", value: toolState.date || chotGet(),
      onchange: function (e) { toolState.date = e.target.value; renderPick(row); }
    });
    var heSoInput = el("input", {
      type: "text", "data-testid": "gd14-tool-heso", value: toolState.heSo, cls: "w-14 rounded border px-1",
      onchange: function (e) { toolState.heSo = e.target.value || "1,5"; renderPick(row); }
    });
    var chamInput = el("input", { type: "checkbox", "data-testid": "gd14-tool-chamtra" });
    chamInput.checked = toolState.cham;
    chamInput.addEventListener("change", function () { toolState.cham = chamInput.checked; renderPick(row); });
    var head = el("div", { cls: "flex flex-wrap items-center gap-2 py-2 text-sm" }, [
      el("b", { text: String(row[1] || "") + " · " + String(row[0] || "") }),
      el("label", { cls: "flex items-center gap-1" }, [el("span", { text: "Tất toán đến" }), dateInput]),
      el("label", { cls: "flex items-center gap-1 text-xs" }, [el("span", { text: "Hệ số QH" }), heSoInput]),
      el("label", { cls: "flex items-center gap-1 text-xs" }, [chamInput, el("span", { text: "Cộng lãi chậm trả 10%/năm (tách riêng)" })])
    ]);
    rs.appendChild(head);
    var box = el("div");
    rs.appendChild(box);
    renderResult(box, row, toolState.date || chotGet(), Number(String(toolState.heSo).replace(",", ".")) || 1.5, toolState.cham);
  }

  function closeTool() {
    if (toolEl) { toolEl.remove(); toolEl = null; }
  }

  function openAllot(rows) {
    closeTool();
    toolRows = rows || [];
    toolEl = el("div", { cls: "fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4", "data-testid": "gd14-tool-overlay" });
    var panel = el("div", { role: "dialog", "aria-modal": "true", cls: "flex max-h-[90vh] w-[640px] max-w-full flex-col gap-3 overflow-auto rounded-lg border bg-background p-4 shadow-2xl" });
    var top = el("div", { cls: "flex items-center justify-between" }, [
      el("b", { text: "🧮 Tính lãi tất toán — QLTDPRO P42 (chỉ đọc, không ghi dữ liệu)" }),
      el("button", { cls: "rounded px-2 text-muted-foreground hover:bg-accent", text: "×", "aria-label": "Đóng", "data-testid": "gd14-tool-close", onclick: closeTool })
    ]);
    var search = el("input", {
      type: "search", "data-testid": "gd14-tool-search", placeholder: "Tìm theo tên khách hàng hoặc mã KH…",
      cls: "w-full rounded border px-2 py-1.5 text-sm", oninput: renderTool
    });
    var list = el("div", { cls: "max-h-56 overflow-auto rounded border bg-card", "data-testid": "gd14-tool-list" });
    var rs = el("div", { cls: "rounded border bg-card px-2 py-1", "data-testid": "gd14-tool-resultbox" });
    panel.appendChild(top); panel.appendChild(search); panel.appendChild(list); panel.appendChild(rs);
    toolEl.appendChild(panel);
    toolEl.addEventListener("click", function (e) { if (e.target === toolEl) closeTool(); });
    document.addEventListener("keydown", function escListener(e) {
      if (e.key === "Escape") { closeTool(); document.removeEventListener("keydown", escListener); }
    });
    document.body.appendChild(toolEl);
    renderTool();
  }

  /* ================= M2 · Nguồn thư mục IPCAS ================= */

  var DB_NAME = "QLTDProFolder_v1", DB_STORE = "kv";
  function dbOpen() {
    return new Promise(function (res, rej) {
      var rq = indexedDB.open(DB_NAME, 1);
      rq.onupgradeneeded = function () { rq.result.createObjectStore(DB_STORE); };
      rq.onsuccess = function () { res(rq.result); };
      rq.onerror = function () { rej(rq.error); };
    });
  }
  function dbGet(k) {
    return dbOpen().then(function (db) {
      return new Promise(function (res, rej) {
        var tx = db.transaction(DB_STORE, "readonly"), rq = tx.objectStore(DB_STORE).get(k);
        rq.onsuccess = function () { res(rq.result); }; rq.onerror = function () { rej(rq.error); };
      });
    });
  }
  function dbSet(k, v) {
    return dbOpen().then(function (db) {
      return new Promise(function (res, rej) {
        var tx = db.transaction(DB_STORE, "readwrite"), rq = tx.objectStore(DB_STORE).put(v, k);
        rq.onsuccess = function () { res(); }; rq.onerror = function () { rej(rq.error); };
      });
    });
  }

  var F = {
    POLL_MS: 10 * 60 * 1000,        // chu kỳ quét quyền/quét tệp (mặc định 10 phút — Q-giới hạn đề án)
    STABLE_MS: 30 * 1000,           // tệp vừa sửa trong 30s → bỏ qua, lần quét sau
    MAX_DEPTH: 5,                   // sâu tối đa khi bật "Bao gồm thư mục con" (mức 1 của thư mục đã chọn = 0)
    extOK: /\.(xlsx|xlsm|xls|csv|zip)$/i,
    busy: false, lastScan: "", lastNote: "", mode: "hoi", sub: false,
    seen: [] // [{key,n,at}] — đã đề xuất/nhập; key = đường_dẫn_tương_đối + tên + kích thước + lastModified
  };

  function logEvent(text) {
    F.lastNote = text;
    if (F.card) F.card.querySelector("[data-testid=gd14-folder-status]").textContent = text;
    var d = new Date().toISOString();
    F.log = (F.log || []).concat([{ at: d, text: text }]).slice(-30);
    dbSet("log", F.log).catch(function () {});
  }

  function permState(handle) {
    return handle && handle.queryPermission ? handle.queryPermission({ mode: "read" }) : Promise.resolve("unavailable");
  }

  function pickFolder() {
    if (!window.showDirectoryPicker) return;
    window.showDirectoryPicker({ mode: "read" }).then(function (h) {
      F.handle = h;
      return dbSet("handle", h).then(function () {
        logEvent("Đã chọn thư mục: " + (h.name || "(không rõ tên)"));
        return scan(true);
      });
    }).catch(function (e) { if (e && e.name !== "AbortError") logEvent("Không chọn được thư mục: " + (e.message || e.name)); });
  }

  function regrant() {
    if (!F.handle || !F.handle.requestPermission) { logEvent("Chưa có thư mục nào được lưu."); return; }
    F.handle.requestPermission({ mode: "read" }).then(function (s) {
      if (s === "granted") { logEvent("Đã cấp lại quyền — quét lại thư mục."); scan(true); }
      else logEvent("Quyền chưa được cấp (" + s + ").");
    }).catch(function (e) { logEvent("Cấp quyền thất bại: " + (e.message || e.name)); });
  }

  function forget() {
    F.handle = null; F.seen = []; F.lastNote = "";
    return Promise.all([dbSet("handle", null), dbSet("seen", [])]).then(function () {
      logEvent("Chưa chọn thư mục. Chọn một lần là đủ — app ghi nhớ và tự nhận tệp mới.");
      renderCard();
    });
  }

  // Nhãn "Nguồn" cho cột mới của bảng kế hoạch (tệp File đã qua gd13 giữ chuỗi zip gốc)
  function nguon(f) {
    if (f && f.gd14src) return f.gd14src + (f.gd13src ? " › ZIP: " + f.gd13src : "");
    if (f && f.gd13src) return "ZIP: " + f.gd13src;
    return "Chọn tệp / Kéo thả";
  }

  function dispatchFiles(files) {
    var input = document.querySelector('[data-testid="file-input"]');
    if (!input) { logEvent("Không tìm thấy ô nhập tệp — hãy mở trang Nhập IPCAS."); return; }
    var dt = new DataTransfer();
    files.forEach(function (f) { try { dt.items.add(f); } catch (e) {} });
    input.files = dt.files;
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function autoImport() {
    var blocked = document.querySelector('[data-testid="import-blocked"]');
    if (blocked) { logEvent("Bỏ qua tự nhập: app chỉ xem hoặc còn thay đổi chưa lưu."); return; }
    var run = document.querySelector('[data-testid="chay"]');
    if (!run || run.disabled) { logEvent("Tự nhập: không có tệp mới để nhập."); return; }
    run.click();
    var tries = 0;
    var timer = setInterval(function () {
      var yes = document.querySelector('[data-testid="confirm-yes"]');
      if (yes) { clearInterval(timer); yes.click(); logEvent("Đã tự nhập theo chế độ Tự nhập."); return; }
      if (++tries > 15) { clearInterval(timer); logEvent("Tự nhập: không thấy bước xác nhận — dừng."); }
    }, 200);
  }

  /* Thu thập tệp trong thư mục (mức 1; khi F.sub bật thì đệ quy theo đường dẫn tương đối) */
  function collect(dir, rel, depth, out) {
    var it = dir.values();
    function step() {
      return it.next().then(function (r) {
        if (r.done) return;
        var h = r.value, name = h.name, relName = (rel ? rel + "/" : "") + name;
        if (h.kind === "directory") {
          if (F.sub && depth < F.MAX_DEPTH && !/^\./.test(name)) {
            return collect(h, relName, depth + 1, out).then(step);
          }
          return step();
        }
        if (!F.extOK.test(name) || /^\W*~\$/.test(name) || /^\./.test(name)) return step();
        return h.getFile().then(function (file) {
          if (out.now - file.lastModified < F.STABLE_MS) { out.skipped++; return; }
          var key = relName + "|" + file.size + "|" + file.lastModified;
          for (var i = 0; i < F.seen.length; i++) if (F.seen[i].key === key) return;
          // cảnh báo tệp mang ngày tương lai trong tên (dd.mm / dd-mm / dd_mm yyyy)
          var m = /(\d{1,2})[.\-_\/](\d{1,2})[.\-_\/](\d{4})/.exec(name);
          if (m) {
            var d = new Date(+m[3], +m[2] - 1, +m[1]);
            if (d.getTime() > out.now + 86400000) out.warns.push(relName + " (ngày " + m[1] + "/" + m[2] + "/" + m[3] + " ở tương lai)");
          }
          F.seen.push({ key: key, n: relName, at: new Date().toISOString() });
          file.gd14src = "Thư mục IPCAS" + (rel ? " › " + rel : "");
          out.found.push(file);
        }).catch(function () { out.warns.push(relName + " (đọc lỗi — thử lại lần quét sau)"); }).then(step);
      });
    }
    return step();
  }

  function scan(manual) {
    if (F.busy) return Promise.resolve();
    if (!F.handle) { if (manual) logEvent("Chưa chọn thư mục."); return Promise.resolve(); }
    F.busy = true;
    return permState(F.handle).then(function (s) {
      if (s !== "granted") {
        logEvent(s === "prompt" ? "Cần cấp lại quyền — bấm “Cập quyền”." : "Thư mục không đọc được (bị xoá/đổi tên hoặc quyền bị thu hồi).");
        renderCard(); F.busy = false; return;
      }
      var out = { found: [], warns: [], skipped: 0, now: Date.now() };
      var sigLen = F.seen.length;
      return collect(F.handle, "", 0, out).then(function () {
        F.lastScan = new Date().toLocaleTimeString("vi-VN");
        if (F.seen.length !== sigLen || out.found.length) return dbSet("seen", F.seen.slice(-500));
      }).then(function () {
        if (out.found.length) {
          logEvent("Quét " + F.lastScan + ": đề xuất " + out.found.length + " tệp mới" + (out.skipped ? ", " + out.skipped + " tệp đang chép dở (bỏ qua)" : "") + (out.warns.length ? " · ⚠ " + out.warns.join("; ") : ""));
          dispatchFiles(out.found);
          if (F.mode === "tu") setTimeout(autoImport, 1200);
        } else if (manual) {
          logEvent("Quét " + F.lastScan + ": không có tệp mới" + (out.skipped ? " (" + out.skipped + " tệp đang chép dở)" : "") + (out.warns.length ? " · ⚠ " + out.warns.join("; ") : ""));
        }
        renderCard();
        F.busy = false;
      });
    }).catch(function (e) {
      logEvent("Quét lỗi: " + (e.message || e.name));
      renderCard(); F.busy = false;
    });
  }

  /* ---- thẻ giao diện gắn vào trang Nhập (DOM riêng, ngoài React) ---- */

  function renderCard() {
    if (!F.card) return;
    var has = !!F.handle, sup = !!window.showDirectoryPicker;
    F.card.innerHTML = "";
    var box = el("div", { cls: "rounded-lg border bg-card p-3 text-sm", "data-testid": "gd14-folder" });
    var head = el("div", { cls: "flex flex-wrap items-center gap-2" }, [
      el("h2", { cls: "mr-auto text-sm font-bold", text: "📁 Nguồn thư mục IPCAS (P42 — chỉ đọc)" })
    ]);
    box.appendChild(head);
    if (!sup) {
      box.appendChild(el("p", { cls: "text-muted-foreground", text: "Trình duyệt này không hỗ trợ chọn thư mục (cần Chrome/Edge máy tính). Dùng Kéo thả hoặc tệp ZIP ở ô phía trên." }));
      return;
    }
    var b1 = el("button", { cls: "rounded-md border bg-secondary px-3 py-1.5 text-sm font-semibold hover:bg-accent", "data-testid": "gd14-folder-pick", text: has ? "Đổi thư mục…" : "Chọn thư mục…", onclick: pickFolder });
    head.appendChild(b1);
    if (has) {
      head.appendChild(el("button", { cls: "rounded-md border px-3 py-1.5 text-sm hover:bg-accent", "data-testid": "gd14-folder-scan", text: "Quét ngay", onclick: function () { scan(true); } }));
      head.appendChild(el("button", { cls: "rounded-md border px-3 py-1.5 text-sm hover:bg-accent", "data-testid": "gd14-folder-repropose", text: "Đưa lại tất cả tệp", title: "Xoá danh sách đã đề xuất rồi quét lại — mọi tệp trong thư mục được đưa lại vào bảng kế hoạch", onclick: function () { F.seen = []; dbSet("seen", []).then(function () { scan(true); }); } }));
      head.appendChild(el("button", { cls: "rounded-md border px-3 py-1.5 text-sm hover:bg-accent", "data-testid": "gd14-folder-regrant", text: "Cập quyền", onclick: regrant }));
      head.appendChild(el("button", { cls: "rounded-md border px-3 py-1.5 text-sm text-destructive hover:bg-accent", "data-testid": "gd14-folder-forget", text: "Bỏ thư mục", onclick: forget }));
    }
    var mode = el("label", { cls: "flex items-center gap-1 text-xs", "data-testid": "gd14-folder-mode" }, [
      (function () {
        var cb = el("input", { type: "checkbox", "data-testid": "gd14-folder-auto" });
        cb.checked = F.mode === "tu";
        cb.addEventListener("change", function () {
          F.mode = cb.checked ? "tu" : "hoi";
          dbSet("mode", F.mode).catch(function () {});
          logEvent(cb.checked ? "Đã bật Tự nhập — tệp mới sẽ nhập ngay (vẫn chặn khi chỉ xem / còn thay đổi chưa lưu)." : "Đã về chế độ Hỏi — tệp mới chỉ vào bảng kế hoạch chờ bấm Nhập.");
        });
        return cb;
      })(),
      el("span", { text: "Tự nhập (mặc định: Hỏi — tệp mới chỉ vào bảng kế hoạch chờ bấm Nhập)" })
    ]);
    box.appendChild(mode);
    var sub = el("label", { cls: "flex items-center gap-1 text-xs", "data-testid": "gd14-folder-sublbl" }, [
      (function () {
        var cb = el("input", { type: "checkbox", "data-testid": "gd14-folder-sub" });
        cb.checked = !!F.sub;
        cb.addEventListener("change", function () {
          F.sub = cb.checked;
          dbSet("sub", F.sub).catch(function () {});
          logEvent(F.sub ? "Đã bật quét cả thư mục con — bấm “Quét ngay” để quét lại." : "Đã tắt quét thư mục con — chỉ quét mức 1.");
        });
        return cb;
      })(),
      el("span", { text: "Bao gồm thư mục con (mặc định: chỉ quét mức 1)" })
    ]);
    box.appendChild(sub);
    var st = el("p", { cls: "text-muted-foreground", "data-testid": "gd14-folder-status", text: F.lastNote || (has ? "Sẵn sàng — bấm “Quét ngay” hoặc chờ quét định kỳ 10 phút." : "Chưa chọn thư mục. Chọn một lần là đủ — app ghi nhớ và tự nhận tệp mới.") });
    box.appendChild(st);
    if (has && (F.log || []).length) {
      var lgBtn = el("button", { cls: "text-xs text-muted-foreground underline decoration-dotted", "data-testid": "gd14-folder-logbtn", text: "▸ Nhật ký thư mục", onclick: function () {
        var open = lgBox.style.display !== "none";
        lgBox.style.display = open ? "none" : "block";
        lgBtn.textContent = open ? "▸ Nhật ký thư mục" : "▾ Nhật ký thư mục";
      } });
      var lgBox = el("div", { cls: "mt-1 max-h-40 overflow-auto rounded border bg-secondary/40 p-2 text-xs text-muted-foreground", "data-testid": "gd14-folder-log", style: "display:none" });
      (F.log || []).slice().reverse().forEach(function (e2) {
        lgBox.appendChild(el("div", { text: (e2.at || "").replace("T", " ").slice(0, 19) + " · " + e2.text }));
      });
      box.appendChild(lgBtn); box.appendChild(lgBox);
    }
    F.card.appendChild(box);
  }

  function ensureCard() {
    var page = document.querySelector('[data-testid="page-nhap"]');
    if (!page) { if (F.card && !document.contains(F.card)) F.card = null; return; }
    if (F.card && document.contains(F.card)) return;
    F.card = el("div", { "data-testid": "gd14-folder-slot" });
    page.appendChild(F.card);
    renderCard();
  }

  function init() {
    Promise.all([dbGet("handle"), dbGet("seen"), dbGet("mode"), dbGet("log"), dbGet("sub")]).then(function (r) {
      F.handle = r[0] || null; F.seen = r[1] || []; F.mode = r[2] || "hoi"; F.log = r[3] || []; F.sub = !!r[4];
      ensureCard();
      renderCard();
      if (F.handle) setTimeout(function () { scan(true); }, 4000);
    }).catch(function () { ensureCard(); renderCard(); });

    new MutationObserver(function () { ensureCard(); }).observe(document.body, { childList: true, subtree: true });
    document.addEventListener("visibilitychange", function () {
      if (!document.hidden && F.handle) scan(false);
    });
    window.addEventListener("focus", function () { if (F.handle) scan(false); });
    setInterval(function () { if (!document.hidden && F.handle) scan(false); }, F.POLL_MS);
  }

  /* ================= P42 v24.15.0 · MÁY TÍNH LÃI — CƠ SỞ 365 NGÀY (modal DOM riêng, ngoài React) =================
   * Mọi con số lãi lấy DUY NHẤT từ L.tinhLaiKhoan (lõi qltd_lai.cjs, không sửa):
   *  - lãi quá hạn = LS hợp đồng × 1,5 (lõi: cơ bản + phạt 50%), không dùng mức 4,25% cố định (V2-L1, L3);
   *  - làm tròn từng thành phần của từng khoản, tổng = cộng các số đã tròn (V2-L2);
   *  - ngày xác định quá hạn = r[7] dsbsmatdt (đến hạn khoản giải ngân), KHÔNG dùng r[24] apprmatdt (V2-L4);
   *  - khoản không tính được hiển thị xám + lý do, KHÔNG cộng vào tổng, có thông báo (V2-L5);
   *  - "N khoản vay còn dư nợ" chỉ đếm dư nợ > 0 (V2-L6);
   *  - trả gốc bị chặn ở mức dư nợ khoản + cảnh báo; tổng thu = trả gốc + lãi (V2-L7).
   * Bản ghi 27 cột: r[0] brcd · r[1] custnm · r[2] apprseq (số HĐTD) · r[6] dsbsdt · r[7] dsbsmatdt ·
   * r[8] sprd · r[11] dsbsbal (dư nợ) · r[13] loại vay · r[20] dsbsseq · r[23] lstintchrgprd · r[24] apprmatdt.
   */
  var C = { rows: [], el: null, tab: "kh", chot: null, cust: null, loans: [], q: "", lastCopy: "", man: {} };

  var CSS = [
    ".g14c-ov{position:fixed;inset:0;z-index:60;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,.45);padding:12px}",
    ".g14c-pn{display:flex;flex-direction:column;width:1100px;max-width:100%;max-height:94vh;background:hsl(var(--background,0 0% 100%));color:hsl(var(--foreground,215 45% 14%));border-radius:12px;box-shadow:0 20px 50px rgba(0,0,0,.3);overflow:hidden;font-size:13px}",
    ".g14c-hd{display:flex;align-items:center;gap:8px;padding:12px 16px;border-bottom:1px solid hsl(var(--border,214 25% 85%))}",
    ".g14c-hd h2{margin:0;font-size:15px;font-weight:700;flex:1}",
    ".g14c-x{border:0;background:none;font-size:20px;line-height:1;cursor:pointer;color:#64748b;padding:2px 8px;border-radius:6px}",
    ".g14c-x:hover{background:hsl(var(--accent,214 32% 91%))}",
    ".g14c-bd{overflow:auto;padding:12px 16px;flex:1;min-height:0}",
    ".g14c-ft{display:flex;justify-content:flex-end;gap:8px;flex-wrap:wrap;padding:10px 16px;border-top:1px solid hsl(var(--border,214 25% 85%))}",
    ".g14c-btn{border:1px solid hsl(var(--border,214 25% 85%));background:#fff;border-radius:8px;padding:6px 12px;font-size:12.5px;font-weight:600;cursor:pointer;color:inherit}",
    ".g14c-btn:hover{filter:brightness(.97)}",
    ".g14c-btn.ok{background:#15803d;border-color:#15803d;color:#fff}",
    ".g14c-btn.warn{background:#d97706;border-color:#d97706;color:#fff}",
    ".g14c-btn.sm{padding:4px 10px;font-size:12px}",
    ".g14c-bulk{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:6px 0}.g14c-nd{min-width:128px;width:auto}",
    ".g14c-t td.nr{background:#fff7ed}.g14c-t td .sm.rg{color:#c2410c;font-weight:700}",
    ".g14c-fm{background:linear-gradient(135deg,#e8f5ec,#eef4ff);border-left:4px solid #15803d;border-radius:8px;padding:8px 12px;margin-bottom:12px}",
    ".g14c-fm b{display:block;font-size:11.5px;color:#0f2a4a}",
    ".g14c-fm code{display:block;text-align:center;font-family:'Courier New',monospace;font-size:13px;font-weight:700;color:#166534;padding:3px 0;white-space:normal}",
    ".g14c-fm small{display:block;text-align:center;font-size:11px;color:#475569}",
    ".g14c-tabs{display:flex;gap:4px;border-bottom:2px solid #e2e8f0;margin-bottom:12px}",
    ".g14c-tab{border:0;background:none;padding:8px 12px;font-size:12px;font-weight:700;cursor:pointer;color:#475569;border-bottom:3px solid transparent;margin-bottom:-2px}",
    ".g14c-tab.on{color:#166534;border-bottom-color:#15803d}",
    ".g14c-row{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;margin-bottom:10px}",
    ".g14c-row label{display:block;font-size:10.5px;font-weight:700;color:#0f2a4a;margin-bottom:4px;text-transform:uppercase}",
    ".g14c-in{width:100%;padding:7px 10px;border:1px solid #cbd5e1;border-radius:7px;font-size:13px;font-weight:600;background:#fff;color:inherit}",
    ".g14c-in.srch{border:2px solid #15803d}",
    ".g14c-res{max-height:200px;overflow:auto;border:1px solid #cbd5e1;border-radius:8px;margin-bottom:10px;background:#fff}",
    ".g14c-res button{display:flex;width:100%;justify-content:space-between;gap:8px;border:0;border-bottom:1px solid #f1f5f9;background:none;padding:7px 10px;text-align:left;cursor:pointer;font-size:12.5px;color:inherit}",
    ".g14c-res button:hover{background:#f0fdf4}",
    ".g14c-sel{display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px;background:#0f2a4a;color:#fff;border-radius:8px;padding:10px 14px;margin-bottom:10px}",
    ".g14c-sel .nm{font-size:15px;font-weight:800}",
    ".g14c-sel .sub{font-size:11px;opacity:.75}",
    ".g14c-sel .tot{text-align:right}",
    ".g14c-sel .tot b{display:block;font-size:20px;color:#fcd34d;font-variant-numeric:tabular-nums}",
    ".g14c-cap{display:flex;flex-wrap:wrap;align-items:center;gap:6px 10px;font-size:11px;font-weight:700;color:#0f2a4a;margin-bottom:6px}",
    ".g14c-cap .src{margin-left:auto;font-weight:600;background:#eff6ff;color:#1d4ed8;border:1px solid #93c5fd;border-radius:6px;padding:2px 8px;font-size:10.5px}",
    ".g14c-tw{overflow:auto;max-height:52vh;border:1px solid #cbd5e1;border-radius:8px;-webkit-overflow-scrolling:touch}",
    ".g14c-t{border-collapse:separate;border-spacing:0;font-size:12px;min-width:1640px;width:100%}",
    ".g14c-t th{position:sticky;top:0;z-index:2;background:#0f2a4a;color:#fff;font-size:11px;font-weight:700;padding:8px 8px;text-align:center;white-space:nowrap;border-right:1px solid rgba(255,255,255,.12)}",
    ".g14c-t th small{display:block;font-size:9px;font-weight:400;opacity:.75;font-family:monospace}",
    ".g14c-t th.qh{background:#7f1d1d;color:#fee2e2}",
    ".g14c-t th.th{background:#14532d}",
    ".g14c-t td{padding:6px 8px;border-bottom:1px solid #e2e8f0;border-right:1px solid #f1f5f9;white-space:nowrap;background:#f7fdf9}",
    ".g14c-t td.n{text-align:right;font-variant-numeric:tabular-nums}",
    ".g14c-t td.c{text-align:center}",
    ".g14c-t .s0{position:sticky;left:0;z-index:1;width:40px;min-width:40px;text-align:center}",
    ".g14c-t .s1{position:sticky;left:40px;z-index:1;min-width:150px;max-width:170px;white-space:normal;box-shadow:2px 0 0 #cbd5e1}",
    ".g14c-t th.s0,.g14c-t th.s1{z-index:3}",
    ".g14c-t td .sm{display:block;font-size:10px;color:#64748b}",
    ".g14c-t tr.qh td{background:#fef2f2}",
    ".g14c-t tr.qh td.lqh{color:#b91c1c;font-weight:700}",
    ".g14c-t tr.er td{background:#f1f5f9;color:#64748b}",
    ".g14c-t tr.er td.why{white-space:normal;font-style:italic;min-width:260px}",
    ".g14c-t td .sm.er1{color:#b91c1c;font-weight:700}",
    ".g14c-t tr.off td{opacity:.55}",
    ".g14c-t td.lth{background:#fefce8;font-weight:700}",
    ".g14c-t td.tg{font-weight:800}",
    ".g14c-goc{width:120px;padding:4px 6px;border:1px solid #cbd5e1;border-radius:6px;text-align:right;font-size:12px;font-variant-numeric:tabular-nums}",
    ".g14c-goc.bad{border-color:#dc2626;background:#fef2f2}",
    ".g14c-gw{display:block;font-size:10px;color:#dc2626;white-space:normal;max-width:140px}",
    ".g14c-sum{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin-top:12px;background:linear-gradient(135deg,#0f2a4a,#1e3a5f);color:#fff;border-radius:10px;padding:12px 16px}",
    ".g14c-sum div div{font-size:10px;text-transform:uppercase;letter-spacing:.6px;opacity:.65}",
    ".g14c-sum b{display:block;font-size:17px;font-variant-numeric:tabular-nums;word-break:break-word}",
    ".g14c-sum .lai{background:rgba(255,255,255,.08);border-radius:8px;padding:6px 10px;margin:-6px 0}",
    ".g14c-sum .lai b{color:#fcd34d;font-size:20px}",
    ".g14c-sum .goc b{color:#86efac}",
    ".g14c-note{margin-top:8px;border:1px solid #fcd34d;background:#fffbeb;color:#92400e;border-radius:8px;padding:8px 10px;font-size:12px}",
    ".g14c-note.red{border-color:#fca5a5;background:#fef2f2;color:#991b1b}",
    ".g14c-note div{margin-top:2px}",
    ".g14c-empty{text-align:center;padding:26px 16px;color:#64748b;background:#f8fafc;border-radius:8px;font-size:12.5px}",
    ".g14c-det{margin-top:10px;font-size:12px}",
    ".g14c-det summary{cursor:pointer;font-weight:700;color:#0f2a4a}",
    ".g14c-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px}",
    ".g14c-card{border:1px solid #cbd5e1;border-radius:8px;padding:10px 12px;background:#fff;margin-top:10px}",
    ".g14c-card .ln{display:flex;justify-content:space-between;gap:10px;padding:2px 0}",
    ".g14c-card .ln b{font-variant-numeric:tabular-nums}",
    ".g14c-card .tt{border-top:1px solid #e2e8f0;margin-top:4px;padding-top:6px;font-size:15px}",
    ".g14c-card .ct{color:#475569;font-size:11.5px}",
    ".g14c-toast{font-size:12px;color:#15803d;font-weight:700;margin-right:auto;align-self:center}",
    ".g14c-toast:empty{display:none}",
    "@media (max-width:640px){.g14c-ov{padding:0;align-items:stretch}.g14c-pn{max-height:100vh;height:100%;border-radius:0}",
    ".g14c-sum{grid-template-columns:repeat(2,minmax(0,1fr))}.g14c-sum .lai{margin:0}.g14c-bd{padding:10px}",
    ".g14c-t .s1{min-width:120px;max-width:130px}.g14c-sel .tot{text-align:left}",
    ".g14c-tab{font-size:11px;padding:8px 6px}.g14c-fm code{font-size:12px}",
    ".g14c-sum .lai b{font-size:17px}.g14c-sum b{font-size:15px}.g14c-toast{flex-basis:100%;text-align:center}.g14c-ft{justify-content:center}}"
  ].join("\n");

  function cssOnce() {
    if (document.getElementById("gd14-calc-css")) return;
    var s = document.createElement("style");
    s.id = "gd14-calc-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }

  // ISO "yyyy-mm-dd" | "dd/mm/yyyy" → "dd/mm/yyyy" (không đọc được → chuỗi gốc)
  function dmy(v) {
    var t = L.parseDate(v);
    if (t == null) return v == null ? "" : String(v);
    var d = new Date(t);
    return pad(d.getUTCDate()) + "/" + pad(d.getUTCMonth() + 1) + "/" + d.getUTCFullYear();
  }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function fold(s) {
    return String(s == null ? "" : s).toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/g, "d").trim();
  }
  function duNo(r) { var n = Number(r && r[11]); return isFinite(n) ? n : 0; }
  function digits(s) { var d = String(s == null ? "" : s).replace(/[^\d]/g, ""); return d ? Number(d) : 0; }
  function custKey(r) { return String(r[1] || "").trim() + "\u0001" + String(r[0] || "").trim(); }

  /* ---- nhóm khách hàng: (tên, mã đơn vị) ---- */
  function customers() {
    var map = {}, list = [];
    for (var i = 0; i < C.rows.length; i++) {
      var r = C.rows[i];
      if (!r || !String(r[1] || "").trim()) continue;
      var k = custKey(r);
      if (!map[k]) {
        map[k] = { key: k, ten: String(r[1]).trim(), ma: String(r[0] || "").trim(), rows: [], hd: {}, f: "" };
        list.push(map[k]);
      }
      map[k].rows.push(r);
      map[k].hd[String(r[2] || "")] = 1;
      map[k].hd[String(r[20] || "")] = 1;
    }
    list.forEach(function (c) { c.f = fold(c.ten + " " + c.ma + " " + Object.keys(c.hd).join(" ")); });
    return list;
  }
  function conDuNo(rows) {
    var n = 0, s = 0;
    rows.forEach(function (r) { var d = duNo(r); if (d > 0) { n++; s += d; } });
    return { n: n, s: s };
  }

  /* ---- P43: ngày thu lãi RIÊNG từng khoản (it.chot; trống = theo ngày chung C.chot) ---- */
  function chotOf(it) { return (it.chot && L.parseDate(it.chot) != null) ? it.chot : C.chot; }
  function mocMs(r) { var a = L.parseDate(r && r[23]); return a != null ? a : L.parseDate(r && r[6]); }
  function ngayStat() {
    var set = {}, own = 0, n = 0;
    C.loans.forEach(function (it) { if (!it.tick) return; n++; set[chotOf(it)] = 1; if (it.chot && L.parseDate(it.chot) != null) own++; });
    return { n: n, own: own, distinct: Object.keys(set).length };
  }
  function ngayCell(it, i) {
    var own = !!(it.chot && L.parseDate(it.chot) != null), m = mocMs(it.r);
    var inp = el("input", { type: "date", cls: "g14c-in g14c-nd", "data-fk": "ngay" + i, "data-testid": "gd14-calc-ngay", value: own ? it.chot : "", min: m != null ? iso(m) : null, "aria-label": "Ngày thu lãi riêng" });
    inp.addEventListener("change", function () {
      if (inp.value === "") it.chot = "";
      else if (L.parseDate(inp.value) != null) it.chot = inp.value;
      render();
    });
    var kids = [inp, el("span", { cls: "sm" + (own ? " rg" : ""), "data-testid": "gd14-calc-ngay-lbl", text: own ? "riêng" : "theo ngày chung " + dmy(C.chot) })];
    if (own) kids.push(el("button", { cls: "g14c-btn sm", "data-testid": "gd14-calc-ngay-clr", title: "Bỏ ngày riêng", text: "↺", onclick: function () { it.chot = ""; render(); } }));
    return el("td", { cls: "c" + (own ? " nr" : "") }, kids);
  }
  function bulkBar() {
    var inp = el("input", { type: "date", cls: "g14c-in g14c-nd", "data-fk": "bulk", "data-testid": "gd14-calc-bulk-date", value: C.bulk || "", "aria-label": "Ngày thu lãi cho các khoản đã tick" });
    inp.addEventListener("change", function () { C.bulk = L.parseDate(inp.value) != null ? inp.value : ""; render(); });
    return el("div", { cls: "g14c-bulk", "data-testid": "gd14-calc-bulk" }, [
      el("span", { style: "font-weight:700", text: "📅 Ngày thu lãi riêng:" }), inp,
      el("button", { cls: "g14c-btn sm ok", "data-testid": "gd14-calc-bulk-apply", text: "Áp cho khoản đã tick", onclick: bulkApply }),
      el("button", { cls: "g14c-btn sm", "data-testid": "gd14-calc-bulk-clear", text: "Xoá ngày riêng", onclick: function () { C.loans.forEach(function (x) { x.chot = ""; }); toast("Đã xoá ngày riêng — các khoản theo ngày chung."); render(); } })
    ]);
  }
  function bulkApply() {
    var t = L.parseDate(C.bulk);
    if (t == null) { toast("Chọn ngày thu lãi trước khi áp."); return; }
    var okn = 0, skip = 0;
    C.loans.forEach(function (x) {
      if (!x.tick) return;
      var m = mocMs(x.r);
      if (m != null && t < m) { skip++; return; }
      x.chot = C.bulk; okn++;
    });
    toast("Đã áp ngày " + dmy(C.bulk) + " cho " + okn + " khoản" + (skip ? "; bỏ qua " + skip + " khoản vì ngày thu trước ngày đã thu lãi đến." : "."));
    render();
  }

  /* ---- tính toàn bảng (một nguồn: L.tinhLaiKhoan) ---- */
  function compute() {
    var out = { tick: 0, goc: 0, lai: 0, thu: 0, loi: [], items: [] };
    C.loans.forEach(function (it, i) {
      it.k = L.tinhLaiKhoan(it.r, { chot: chotOf(it) });
      if (!it.tick) return;
      out.tick++;
      out.goc += it.goc;
      if (it.k && it.k.ok) out.lai += it.k.tong;
      else out.loi.push({ i: i, r: it.r, lyDo: it.k ? it.k.lyDo : "lỗi không rõ" });
      out.items.push(it);
    });
    out.thu = out.goc + out.lai;
    return out;
  }

  /* ---- vẽ ---- */
  function render() {
    if (!C.el) return;
    var bd = C.el.querySelector("[data-testid=gd14-calc-body]");
    var keepX = 0, tw = bd.querySelector(".g14c-tw");
    if (tw) keepX = tw.scrollLeft;
    var focusId = document.activeElement && document.activeElement.getAttribute && document.activeElement.getAttribute("data-fk");
    bd.innerHTML = "";
    bd.appendChild(el("div", { cls: "g14c-fm" }, [
      el("b", { text: "📘 CÔNG THỨC CHUẨN (Thông tư 14/2017/TT-NHNN, Điều 4) — cơ sở 365 ngày" }),
      el("code", { text: "Tiền lãi = Dư nợ gốc × LS năm × Số ngày ÷ 365" }),
      el("small", { text: "Số ngày = (Ngày chốt tính lãi) − (Ngày đã thu lãi đến) · Quá hạn (sau ngày đến hạn khoản giải ngân r[7]): LS × 1,5" })
    ]));
    var tabs = el("div", { cls: "g14c-tabs", role: "tablist" }, [
      el("button", { cls: "g14c-tab" + (C.tab === "kh" ? " on" : ""), role: "tab", "aria-selected": String(C.tab === "kh"), "data-testid": "gd14-calc-tab-kh", text: "👤 TRA CỨU KH TỪ HỆ THỐNG", onclick: function () { C.tab = "kh"; render(); } }),
      el("button", { cls: "g14c-tab" + (C.tab === "tay" ? " on" : ""), role: "tab", "aria-selected": String(C.tab === "tay"), "data-testid": "gd14-calc-tab-tay", text: "✍️ TÍNH TAY (NHẬP TỰ DO)", onclick: function () { C.tab = "tay"; render(); } })
    ]);
    bd.appendChild(tabs);
    if (C.tab === "kh") renderKH(bd); else renderTay(bd);
    var tw2 = bd.querySelector(".g14c-tw");
    if (tw2) tw2.scrollLeft = keepX;
    if (focusId) {
      var f = bd.querySelector('[data-fk="' + focusId + '"]');
      if (f) { f.focus(); try { var L2 = f.value.length; f.setSelectionRange(L2, L2); } catch (e) {} }
    }
  }

  function chotField() {
    return el("div", {}, [
      el("label", { text: "📅 Chốt lãi đến ngày" }),
      el("div", { style: "display:flex;gap:6px" }, [
        el("input", { type: "date", cls: "g14c-in", style: "min-width:150px", "data-testid": "gd14-calc-chot", value: C.chot,
          onchange: function (e) { if (L.parseDate(e.target.value) != null) { C.chot = e.target.value; render(); } } }),
        el("button", { cls: "g14c-btn sm", "data-testid": "gd14-calc-homnay", text: "📆 Hôm nay", onclick: function () { C.chot = iso(L.todayUTC()); render(); } })
      ])
    ]);
  }

  function renderKH(bd) {
    var row = el("div", { cls: "g14c-row" }, [
      el("div", { style: "flex:1;min-width:220px" }, [
        el("label", { text: "🔍 Tìm khách hàng (tên, mã, số HĐTD)" }),
        el("input", { type: "search", cls: "g14c-in srch", "data-fk": "q", "data-testid": "gd14-calc-search", placeholder: "Gõ ít nhất 2 ký tự…", value: C.q,
          oninput: function (e) { C.q = e.target.value; render(); } })
      ]),
      chotField()
    ]);
    bd.appendChild(row);

    var qf = fold(C.q);
    if (qf.length >= 2 && !(C.cust && fold(C.cust.ten) === qf)) {
      var hits = customers().filter(function (c) { return c.f.indexOf(qf) >= 0; }).slice(0, 50);
      var res = el("div", { cls: "g14c-res", "data-testid": "gd14-calc-results" });
      if (!hits.length) res.appendChild(el("div", { cls: "g14c-empty", text: "Không có khách hàng nào khớp “" + C.q + "”." }));
      hits.forEach(function (c) {
        var cd = conDuNo(c.rows);
        res.appendChild(el("button", { "data-testid": "gd14-calc-hit", onclick: function () { pick(c); } }, [
          el("span", { text: c.ten + (c.ma ? " · " + c.ma : "") }),
          el("span", { style: "color:#64748b;font-size:11.5px;white-space:nowrap", text: cd.n + " khoản còn dư nợ · " + L.fmt(cd.s) + " đ" })
        ]));
      });
      bd.appendChild(res);
    }

    if (!C.cust) {
      bd.appendChild(el("div", { cls: "g14c-empty", "data-testid": "gd14-calc-empty", text: C.rows.length
        ? "👆 Gõ tên / mã / số HĐTD của khách hàng để xem các khoản vay và lãi phải thu đến ngày chốt."
        : "Chưa có dữ liệu dư nợ — nhập tệp IPCAS ở Trung tâm nhập dữ liệu trước. Có thể dùng tab “Tính tay”." }));
      return;
    }

    var cd = conDuNo(C.cust.rows);
    bd.appendChild(el("div", { cls: "g14c-sel", "data-testid": "gd14-calc-selected" }, [
      el("div", {}, [el("div", { cls: "nm", "data-testid": "gd14-calc-ten", text: C.cust.ten }), el("div", { cls: "sub", text: "Mã đơn vị (brcd): " + (C.cust.ma || "—") + " · " + C.cust.rows.length + " dòng trong tệp nguồn" })]),
      el("div", { cls: "tot" }, [
        el("div", { cls: "sub", text: "TỔNG DƯ NỢ" }),
        el("b", { "data-testid": "gd14-calc-tongduno", text: L.fmt(cd.s) + " đồng" }),
        el("div", { cls: "sub", "data-testid": "gd14-calc-sokhoan", text: cd.n + " khoản vay còn dư nợ" })
      ])
    ]));

    var sum = compute();
    bd.appendChild(el("div", { cls: "g14c-cap" }, [
      el("span", { text: "📋 BẢNG CÁC KHOẢN VAY — TẤT CẢ DÒNG TỪ FILE NGUỒN IPCAS" }),
      el("span", { style: "font-weight:500;color:#475569", text: "Tick khoản cần tính + nhập SỐ TIỀN TRẢ GỐC nếu có" }),
      el("span", { cls: "src", text: "🔗 NGÀY GN ← dsbsdt | ĐÃ THU LÃI ĐẾN ← lstintchrgprd | ĐẾN HẠN ← dsbsmatdt r[7]" })
    ]));

    bd.appendChild(bulkBar());
    var allOn = C.loans.length && C.loans.every(function (x) { return x.tick; });
    var tickAll = el("input", { type: "checkbox", "data-testid": "gd14-calc-tickall", "aria-label": "Chọn tất cả" });
    tickAll.checked = !!allOn;
    tickAll.addEventListener("change", function () { C.loans.forEach(function (x) { x.tick = tickAll.checked; }); render(); });
    var th = function (t, sub, cls, title) { return el("th", { cls: cls || "", title: title || null }, [document.createTextNode(t)].concat(sub ? [el("small", { text: sub })] : [])); };
    var thead = el("thead", {}, [el("tr", {}, [
      el("th", { cls: "s0" }, [tickAll]),
      th("TÊN KH", "", "s1"),
      th("SỐ HĐTD", "← apprseq"),
      th("ĐÃ THU LÃI ĐẾN", "← lstintchrgprd", "", "Mốc tính lãi; trống thì dùng ngày giải ngân"),
      th("NGÀY GN", "← dsbsdt"),
      th("NGÀY ĐẾN HẠN", "← dsbsmatdt · r[7]", "", "Ngày đến hạn của TỪNG khoản giải ngân — căn cứ xác định quá hạn. Dòng nhỏ: đáo hạn HĐTD (apprmatdt, chỉ tham khảo)"),
      th("SỐ TIỀN TRẢ GỐC", "≤ dư nợ khoản", "th"),
      th("DƯ NỢ", "← dsbsbal"),
      th("L/S %", "← sprd"),
      th("NGÀY THU LÃI", "trống = ngày chung", "th", "Ngày chốt lãi RIÊNG của khoản này; để trống thì dùng ô Chốt lãi đến ngày ở trên"),
      th("SỐ NGÀY", "chốt − mốc"),
      th("LÃI TRONG HẠN", "", "th"),
      th("SỐ NGÀY QH", "", "qh"),
      th("LÃI QUÁ HẠN", "LS × 1,5", "qh", "Lãi quá hạn = cơ bản (LS) + phạt 50% LS = LS × 1,5 — mỗi phần làm tròn riêng"),
      th("TỔNG LÃI PHẢI THU", "")
    ])]);
    var tb = el("tbody", { "data-testid": "gd14-calc-tbody" });
    C.loans.forEach(function (it, i) {
      var r = it.r, k = it.k, ok = k && k.ok;
      var cls = !ok ? "er" : (k.soNgayQH > 0 ? "qh" : "");
      if (!it.tick) cls += " off";
      var cb = el("input", { type: "checkbox", "data-testid": "gd14-calc-tick", "aria-label": "Tính khoản " + (r[20] || r[2] || i + 1) });
      cb.checked = it.tick;
      cb.addEventListener("change", function () { it.tick = cb.checked; render(); });
      var gocIn = el("input", { type: "text", inputmode: "numeric", cls: "g14c-goc" + (it.gocWarn ? " bad" : ""), "data-fk": "goc" + i, "data-testid": "gd14-calc-goc",
        value: it.goc ? L.fmt(it.goc) : "", placeholder: "0", "aria-label": "Số tiền trả gốc" });
      gocIn.addEventListener("change", function () { setGoc(it, gocIn.value); render(); });
      gocIn.addEventListener("keydown", function (e) { if (e.key === "Enter") { setGoc(it, gocIn.value); render(); } });
      var title = ok ? k.chiTiet.concat(k.canhBao.map(function (c) { return "⚠ " + c; })).join("\n") : "Không tính được — " + (k ? k.lyDo : "");
      var tds = [
        el("td", { cls: "s0" }, [cb]),
        el("td", { cls: "s1" }, [el("b", { text: String(r[1] || "") }), el("span", { cls: "sm", text: String(r[13] || "") })]
          .concat(ok ? [] : [el("span", { cls: "sm er1", text: "⛔ Không tính được" })])),
        el("td", {}, [el("span", { text: String(r[2] || "") }), el("span", { cls: "sm", text: r[20] ? "GN: " + r[20] : "" })]),
        el("td", { cls: "c", "data-testid": "gd14-calc-moc", text: r[23] ? dmy(r[23]) : "—" }),
        el("td", { cls: "c", text: dmy(r[6]) || "—" }),
        el("td", { cls: "c", "data-testid": "gd14-calc-denhan" }, [el("span", { text: dmy(r[7]) || "—" }), el("span", { cls: "sm", text: r[24] ? "HĐTD: " + dmy(r[24]) : "" })]),
        el("td", {}, [gocIn].concat(it.gocWarn ? [el("span", { cls: "g14c-gw", "data-testid": "gd14-calc-goc-warn", text: it.gocWarn })] : [])),
        el("td", { cls: "n", "data-testid": "gd14-calc-duno", text: L.fmt(duNo(r)) }),
        el("td", { cls: "n", style: "color:#b91c1c;font-weight:700", "data-testid": "gd14-calc-ls", text: (L.normalizeRate(r[8]) != null ? L.fmtDec(L.normalizeRate(r[8])) + "%" : "—") })
      ];
      tds.push(ngayCell(it, i));
      if (ok) {
        tds.push(el("td", { cls: "c", "data-testid": "gd14-calc-songay", text: (k.soNgayTH + k.soNgayQH) + " ngày" }));
        tds.push(el("td", { cls: "n lth", "data-testid": "gd14-calc-laith", text: k.soNgayTH > 0 ? L.fmt(k.laiTH) : "—" }));
        tds.push(el("td", { cls: "c", "data-testid": "gd14-calc-songayqh", text: k.soNgayQH > 0 ? k.soNgayQH + " ngày" : "—" }));
        tds.push(el("td", { cls: "n lqh", "data-testid": "gd14-calc-laiqh" }, k.soNgayQH > 0
          ? [el("span", { text: L.fmt(k.laiQH) }), el("span", { cls: "sm", text: L.fmt(k.laiQHCB) + " + phạt " + L.fmt(k.laiQHPhat) })]
          : [el("span", { text: "—" })]));
        tds.push(el("td", { cls: "n tg", "data-testid": "gd14-calc-tong", text: L.fmt(k.tong) }));
      } else {
        tds.push(el("td", { cls: "why", colspan: "5", "data-testid": "gd14-calc-loi", text: "Không tính được — " + (k ? k.lyDo : "lỗi không rõ") }));
      }
      tb.appendChild(el("tr", { cls: cls.trim(), "data-testid": "gd14-calc-row", "data-ok": ok ? "1" : "0", title: title }, tds));
    });
    var tbl = el("table", { cls: "g14c-t", "data-testid": "gd14-calc-table" }, [thead, tb]);
    bd.appendChild(el("div", { cls: "g14c-tw", "data-testid": "gd14-calc-scroll" }, [tbl]));

    bd.appendChild(el("div", { cls: "g14c-sum", "data-testid": "gd14-calc-sum" }, [
      el("div", {}, [el("div", { text: "Số khoản đã tick" }), el("b", { "data-testid": "gd14-calc-sotick", text: String(sum.tick) })]),
      el("div", { cls: "goc" }, [el("div", { text: "Tổng trả gốc" }), el("b", { "data-testid": "gd14-calc-tonggoc", text: L.fmt(sum.goc) + " đồng" })]),
      el("div", { cls: "lai" }, [el("div", { text: "Tổng lãi phải thu" }), el("b", { "data-testid": "gd14-calc-tonglai", text: L.fmt(sum.lai) + " đồng" })]),
      el("div", {}, [el("div", { text: "Tổng thu (gốc + lãi)" }), el("b", { "data-testid": "gd14-calc-tongthu", text: L.fmt(sum.thu) + " đồng" })])
    ]));

    var ns = ngayStat();
    if (ns.own > 0) {
      bd.appendChild(el("div", { cls: "g14c-note", "data-testid": "gd14-calc-ngay-info", text: "📅 " + ns.distinct + " ngày thu khác nhau · " + ns.own + "/" + ns.n + " khoản đã tick dùng ngày riêng (còn lại theo ngày chung " + dmy(C.chot) + ")." }));
    }
    if (sum.loi.length) {
      bd.appendChild(el("div", { cls: "g14c-note red", "data-testid": "gd14-calc-loi-note" }, [
        el("b", { text: "⚠ " + sum.loi.length + " khoản đã tick KHÔNG tính được lãi — không cộng vào tổng lãi:" })
      ].concat(sum.loi.map(function (x) {
        return el("div", { text: "• " + (x.r[20] || x.r[2] || "dòng " + (x.i + 1)) + " (dư nợ " + L.fmt(duNo(x.r)) + " đ): " + x.lyDo });
      }))));
    }
    var warns = C.loans.filter(function (x) { return x.gocWarn; });
    if (warns.length) {
      bd.appendChild(el("div", { cls: "g14c-note", "data-testid": "gd14-calc-goc-note", text: "⚠ " + warns.length + " khoản nhập trả gốc vượt dư nợ — đã chặn ở mức dư nợ của khoản." }));
    }
    var qh = sum.items.filter(function (x) { return x.k && x.k.ok && x.k.soNgayQH > 0; });
    var cbs = sum.items.filter(function (x) { return x.k && x.k.ok && x.k.canhBao.length; });
    if (qh.length || cbs.length) {
      var det = el("details", { cls: "g14c-det", "data-testid": "gd14-calc-chitiet", open: qh.length ? "" : null }, [
        el("summary", { text: "📖 Chi tiết thành phần tính (" + qh.length + " khoản quá hạn" + (cbs.length ? ", " + cbs.length + " khoản có cảnh báo" : "") + ")" })
      ]);
      qh.concat(cbs.filter(function (x) { return qh.indexOf(x) < 0; })).forEach(function (x) {
        var box = el("div", { cls: "g14c-card" }, [el("b", { text: (x.r[20] || x.r[2] || "") + " · dư nợ " + L.fmt(x.k.duno) + " đ · LS " + L.fmtDec(x.k.ls) + "% · mốc " + dmy(x.k.moc) + " (" + x.k.mocNguon + ") → chốt " + dmy(x.k.chot) })]);
        x.k.chiTiet.forEach(function (t) { box.appendChild(el("div", { cls: "ct", text: t })); });
        x.k.canhBao.forEach(function (t) { box.appendChild(el("div", { cls: "ct", style: "color:#b45309", text: "⚠ " + t })); });
        box.appendChild(el("div", { cls: "ct", style: "font-weight:700;color:#0f2a4a", text: "Tổng = " + L.fmt(x.k.laiTH) + " + " + L.fmt(x.k.laiQHCB) + " + " + L.fmt(x.k.laiQHPhat) + " = " + L.fmt(x.k.tong) + " đ" }));
        det.appendChild(box);
      });
      bd.appendChild(det);
    }
  }

  function setGoc(it, raw) {
    var v = digits(raw), dn = Math.max(0, duNo(it.r));
    it.gocWarn = "";
    if (v > dn) {
      it.gocWarn = "Vượt dư nợ " + L.fmt(dn) + " — đã chặn bằng dư nợ";
      v = dn;
    }
    it.goc = v;
  }

  function renderTay(bd) {
    var m = C.man;
    var inp = function (key, label, attrs) {
      var a = { cls: "g14c-in", "data-fk": "m" + key, "data-testid": "gd14-calc-m-" + key, value: m[key] || "" };
      Object.keys(attrs || {}).forEach(function (k) { a[k] = attrs[k]; });
      var e = el("input", a);
      e.addEventListener(a.type === "date" ? "change" : "input", function () { m[key] = e.value; renderTayResult(); });
      return el("div", { style: "flex:1;min-width:170px" }, [el("label", { text: label }), e]);
    };
    bd.appendChild(el("div", { cls: "g14c-grid" }, [
      inp("duno", "💰 Dư nợ gốc (đồng)", { type: "text", inputmode: "numeric", placeholder: "VD: 1.000.000.000" }),
      inp("ls", "📊 Lãi suất năm (%)", { type: "text", inputmode: "decimal", placeholder: "VD: 8,8" }),
      inp("moc", "📅 Ngày đã thu lãi đến", { type: "date" }),
      inp("mat", "📅 Ngày đến hạn khoản vay (r[7])", { type: "date", title: "Bỏ trống = coi như chưa quá hạn" }),
      chotField()
    ]));
    bd.appendChild(el("div", { "data-testid": "gd14-calc-m-result" }));
    renderTayResult();
  }

  function renderTayResult() {
    var box = C.el && C.el.querySelector("[data-testid=gd14-calc-m-result]");
    if (!box) return;
    box.innerHTML = "";
    var m = C.man;
    if (!m.duno && !m.ls && !m.moc) {
      box.appendChild(el("div", { cls: "g14c-empty", style: "margin-top:10px", text: "Nhập dư nợ, lãi suất, ngày đã thu lãi đến; ngày đến hạn để tách phần quá hạn (LS × 1,5)." }));
      return;
    }
    var row = { 6: m.moc || "", 7: m.mat || "", 8: m.ls || "", 11: digits(m.duno), 23: m.moc || "" };
    var k = L.tinhLaiKhoan(row, { chot: C.chot });
    C.manLast = k;
    if (!k.ok) {
      box.appendChild(el("div", { cls: "g14c-note red", "data-testid": "gd14-calc-m-loi", text: "Không tính được — " + k.lyDo }));
      return;
    }
    var ln = function (t, v, tid) { return el("div", { cls: "ln" }, [el("span", { text: t }), el("b", { "data-testid": tid, text: v })]); };
    var card = el("div", { cls: "g14c-card" }, [
      el("div", { cls: "ct", text: "Từ " + dmy(k.moc) + " đến " + dmy(k.chot) + " · dư nợ " + L.fmt(k.duno) + " đ · LS " + L.fmtDec(k.ls) + "%/năm" }),
      ln("Lãi trong hạn (" + k.soNgayTH + " ngày)", L.fmt(k.laiTH) + " đ", "gd14-calc-m-laith"),
      ln("Lãi quá hạn cơ bản (" + k.soNgayQH + " ngày × LS)", L.fmt(k.laiQHCB) + " đ", "gd14-calc-m-qhcb"),
      ln("Phạt quá hạn (50% LS) → tổng quá hạn = LS × 1,5", L.fmt(k.laiQHPhat) + " đ", "gd14-calc-m-qhphat"),
      el("div", { cls: "ln tt" }, [el("span", { text: "TỔNG LÃI" }), el("b", { "data-testid": "gd14-calc-m-tong", text: L.fmt(k.tong) + " đ" })])
    ]);
    k.chiTiet.forEach(function (t) { card.appendChild(el("div", { cls: "ct", text: t })); });
    k.canhBao.forEach(function (t) { card.appendChild(el("div", { cls: "ct", style: "color:#b45309", text: "⚠ " + t })); });
    box.appendChild(card);
  }

  function pick(c) {
    C.cust = c;
    C.q = c.ten;
    // dòng còn dư nợ lên trước, sau đó theo ngày giải ngân; mặc định tick khoản còn dư nợ
    var rows = c.rows.slice().sort(function (a, b) {
      var pa = duNo(a) > 0 ? 0 : 1, pb = duNo(b) > 0 ? 0 : 1;
      if (pa !== pb) return pa - pb;
      return (L.parseDate(a[6]) || 0) - (L.parseDate(b[6]) || 0);
    });
    C.loans = rows.map(function (r) { return { r: r, tick: duNo(r) > 0, goc: 0, gocWarn: "", k: null, chot: "" }; });
    render();
  }

  function resetCalc() {
    if (C.tab === "tay") { C.man = {}; C.manLast = null; }
    else C.loans.forEach(function (x) { x.tick = duNo(x.r) > 0; x.goc = 0; x.gocWarn = ""; x.chot = ""; });
    C.bulk = "";
    toast("Đã reset bảng.");
    render();
  }

  function copyText() {
    var t = [];
    t.push("MÁY TÍNH LÃI — CƠ SỞ 365 NGÀY (TT 14/2017/TT-NHNN, Điều 4; quá hạn = LS × 1,5)");
    t.push("Chốt lãi đến: " + dmy(C.chot));
    if (C.tab === "tay") {
      var k = C.manLast;
      if (!k) return "";
      if (!k.ok) t.push("Không tính được — " + k.lyDo);
      else {
        t.push("Dư nợ " + L.fmt(k.duno) + " đ · LS " + L.fmtDec(k.ls) + "% · từ " + dmy(k.moc));
        k.chiTiet.forEach(function (c) { t.push(c); });
        t.push("TỔNG LÃI: " + L.fmt(k.tong) + " đ");
      }
      return t.join("\n");
    }
    if (!C.cust) return "";
    var s = compute();
    t.push("Khách hàng: " + C.cust.ten + (C.cust.ma ? " (" + C.cust.ma + ")" : ""));
    var nOwn = s.items.filter(function (x) { return x.chot && L.parseDate(x.chot) != null; }).length;
    if (nOwn) t.push("Có " + nOwn + " khoản chốt ngày riêng (ghi ở từng dòng: “thu đến”).");
    var n = 0;
    s.items.forEach(function (x) {
      n++;
      var r = x.r, k2 = x.k;
      var head = n + ". " + (r[2] || "") + (r[20] ? " / " + r[20] : "") + " · DN " + L.fmt(duNo(r)) + " · LS " + (L.normalizeRate(r[8]) != null ? L.fmtDec(L.normalizeRate(r[8])) : "?") + "%";
      if (!k2.ok) { t.push(head + " · KHÔNG TÍNH ĐƯỢC — " + k2.lyDo); return; }
      t.push(head + " · mốc " + dmy(k2.moc) + " → thu đến " + dmy(k2.chot) + " · TH " + k2.soNgayTH + " ngày = " + L.fmt(k2.laiTH) +
        (k2.soNgayQH > 0 ? " · QH " + k2.soNgayQH + " ngày = " + L.fmt(k2.laiQH) + " (" + L.fmt(k2.laiQHCB) + " + phạt " + L.fmt(k2.laiQHPhat) + ")" : "") +
        " · Lãi " + L.fmt(k2.tong) + (x.goc ? " · Trả gốc " + L.fmt(x.goc) : ""));
    });
    t.push("Số khoản đã tick: " + s.tick + (s.loi.length ? " (" + s.loi.length + " khoản không tính được, không cộng)" : ""));
    t.push("Tổng trả gốc: " + L.fmt(s.goc) + " đồng");
    t.push("Tổng lãi phải thu: " + L.fmt(s.lai) + " đồng");
    t.push("Tổng thu: " + L.fmt(s.thu) + " đồng");
    return t.join("\n");
  }

  function doCopy() {
    var txt = copyText();
    if (!txt) { toast("Chưa có kết quả để chép."); return; }
    C.lastCopy = txt;
    var fallback = function () {
      var ta = el("textarea", { style: "position:fixed;left:-9999px;top:0" });
      ta.value = txt; document.body.appendChild(ta); ta.select();
      var okc = false;
      try { okc = document.execCommand("copy"); } catch (e) {}
      ta.remove();
      toast(okc ? "Đã chép kết quả vào bộ nhớ tạm." : "Trình duyệt chặn chép — bôi đen và chép tay.");
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(txt).then(function () { toast("Đã chép kết quả vào bộ nhớ tạm."); }, fallback);
    } else fallback();
  }

  function toast(t) {
    var e = C.el && C.el.querySelector("[data-testid=gd14-calc-toast]");
    if (!e) return;
    e.textContent = t;
    clearTimeout(C.toastT);
    C.toastT = setTimeout(function () { if (e.textContent === t) e.textContent = ""; }, 4000);
  }

  function closeCalc() {
    if (C.el) { C.el.remove(); C.el = null; }
    document.removeEventListener("keydown", calcEsc);
  }
  function calcEsc(e) { if (e.key === "Escape") closeCalc(); }

  function openCalc(rows, opts) {
    closeCalc();
    cssOnce();
    opts = opts || {};
    C.rows = rows || [];
    C.tab = "kh"; C.cust = null; C.loans = []; C.q = ""; C.man = {}; C.manLast = null; C.lastCopy = ""; C.bulk = "";
    C.chot = opts.chot && L.parseDate(opts.chot) != null ? opts.chot : chotGet();
    C.el = el("div", { cls: "g14c-ov", "data-testid": "gd14-calc-overlay" });
    var pn = el("div", { cls: "g14c-pn", role: "dialog", "aria-modal": "true", "aria-label": "Máy tính lãi" }, [
      el("div", { cls: "g14c-hd" }, [
        el("h2", { text: "🧮 Máy Tính Lãi — Cơ Sở 365 Ngày" }),
        el("button", { cls: "g14c-x", "aria-label": "Đóng", "data-testid": "gd14-calc-x", text: "×", onclick: closeCalc })
      ]),
      el("div", { cls: "g14c-bd", "data-testid": "gd14-calc-body" }),
      el("div", { cls: "g14c-ft" }, [
        el("span", { cls: "g14c-toast", "data-testid": "gd14-calc-toast", "aria-live": "polite" }),
        el("button", { cls: "g14c-btn", "data-testid": "gd14-calc-close", text: "Đóng", onclick: closeCalc }),
        el("button", { cls: "g14c-btn warn", "data-testid": "gd14-calc-reset", text: "↺ Reset bảng", onclick: resetCalc }),
        el("button", { cls: "g14c-btn ok", "data-testid": "gd14-calc-copy", text: "📋 Copy kết quả", onclick: doCopy })
      ])
    ]);
    C.el.appendChild(pn);
    C.el.addEventListener("click", function (e) { if (e.target === C.el) closeCalc(); });
    document.addEventListener("keydown", calcEsc);
    document.body.appendChild(C.el);
    render();
    var s = C.el.querySelector("[data-testid=gd14-calc-search]");
    if (s) s.focus();
  }

  window.GD14 = {
    chotGet: chotGet, chotSet: chotSet,
    duThu: duThu, duThuNum: duThuNum,
    fmt: L.fmt, openAllot: openAllot, closeTool: closeTool,
    folder: F, scan: scan, nguon: nguon,
    openCalc: openCalc, closeCalc: closeCalc, calc: C,
    PHIEN_BAN: "P43-GD14 1.2.0"
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
