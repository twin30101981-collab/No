# Hồi quy P42 = bộ kiểm P40/P41 chạy trên v24.14.0 (Playwright Chromium): nhập IPCAS từ .zip;
# RAR báo rõ; cộng thêm zip tạo bằng 7-Zip, Info-ZIP, nén bzip2, và zip64. 
# Chạy: python3 kiem_thu_p42/test_p42_regress.py (cổng 8824)
import asyncio, functools, http.server, threading, base64, re, sys
from pathlib import Path
from playwright.async_api import async_playwright
ROOT = Path(__file__).resolve().parent.parent / 'app'; HERE = Path(__file__).resolve().parent
Z = HERE / 'zip'; X = ROOT / 'kiem_thu_p40' / 'xlsx'; C = ROOT / 'kiem_thu_p40' / 'du_lieu_thu'
PORT = 8824; URL = f'http://127.0.0.1:{PORT}/QLTDPRO_v24.14.0.html'
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:400]))
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
httpd = http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT))); threading.Thread(target=httpd.serve_forever, daemon=True).start()

async def newpage(p):
    b = await p.chromium.launch(headless=True); ctx = await b.new_context(viewport={'width': 1366, 'height': 768}, locale='vi-VN')
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); pg.errs = []; pg.on('pageerror', lambda e: pg.errs.append(str(e)))
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1300); return b, pg
async def put(pg, files, wait=2200):
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in files]); await pg.wait_for_timeout(wait)
async def rows(pg):
    t = pg.locator('[data-testid="plan"] tbody tr'); out = []
    for i in range(await t.count()): out.append((await t.nth(i).inner_text()).replace('\n', ' | '))
    return out
async def note(pg):
    n = pg.locator('[data-testid="gd13-note"]'); return (await n.inner_text()) if await n.count() else ''
async def scen(p, name, files, nrows, must=(), mustnot=(), notemust=()):
    b, pg = await newpage(p)
    try:
        await put(pg, files); r = await rows(pg); nt = await note(pg); allr = ' ## '.join(r)
        ok(f'{name}: {nrows} dòng kế hoạch', len(r) == nrows, (len(r), r))
        for m in must: ok(f'{name}: có "{m}"', m in allr, allr)
        for m in mustnot: ok(f'{name}: KHÔNG có "{m}"', m not in allr, allr)
        for m in notemust: ok(f'{name}: thông báo có "{m}"', m in nt, nt)
        ok(f'{name}: không lỗi JS', not pg.errs, pg.errs)
    finally: await b.close()

async def do_import(pg):
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(4500)
async def result(pg):
    await pg.goto(URL + '#/nhap'); await pg.wait_for_timeout(800)
    st = [re.sub(r'\s+', ' ', re.sub(r'(Chọn tệp / Kéo thả|Thư mục IPCAS[^\t]*|ZIP: [^\t]*)', '', t)) for t in await pg.locator('[data-testid="plan"] tbody tr').all_inner_texts()]
    await pg.goto(URL + '#/'); await pg.wait_for_timeout(2000)
    k = [re.sub(r'\s+', ' ', t) for t in await pg.locator('button[data-testid^="kpi-"]').all_inner_texts()]
    return st, k

async def main():
    async with async_playwright() as p:
        html = (ROOT / 'QLTDPRO_v24.14.0.html').read_text(encoding='utf-8'); base = (ROOT / 'QLTDPRO_v24.13.0.html').read_text(encoding='utf-8')
        csp = lambda s: re.search(r'Content-Security-Policy" content="([^"]*)"', s).group(1)
        ok('T1 nhãn 24.14.0 + khối gd14 + accept có .zip', '"24.14.0"' in html and 'id="gd14-js"' in html and 'accept:".xls,.xlsx,.xlsm,.csv,.zip' in html)
        ok('T1b CSP không đổi so với P41', csp(html) == csp(base))
        ok('T1c gd13 không mạng/WASM/eval', not re.search(r'fetch\(|XMLHttpRequest|WebAssembly|eval\(|new Function', (ROOT / 'nguon_P40' / 'gd13.js').read_text(encoding='utf-8')))
        ok('T1d gd14 P42 không mạng/eval + cột lãi dự thu', not re.search(r'fetch\(|XMLHttpRequest|WebAssembly|eval\(|new Function', (ROOT.parent / 'nguon_P42' / 'gd14_ui.js').read_text(encoding='utf-8')) and 'lai_duthu' in html and 'window.GD14' in html)
        ok('T1e cột Nguồn: tiêu đề (1 mới + 1 có sẵn) + 2 ô dữ liệu + nhãn nguồn gd14src', html.count('children:"Nguồn"') == 2 and html.count('"data-testid":"nguon"') == 2 and 'gd14src' in html)
        # đối chứng: nhập thẳng 3 xlsx vs nhập qua zip phải cho kết quả GIỐNG HỆT
        b1, g1 = await newpage(p); await put(g1, [X / 'msit80_30-09-2026.xlsx', X / 'msit80_31-10-2026.xlsx', X / '18_08_2026-TS.xlsx']); await do_import(g1); s1, k1 = await result(g1)
        b2, g2 = await newpage(p); await put(g2, [Path(__file__).resolve().parent.parent / 'app' / 'kiem_thu_p40' / 'zip' / 'ok_3tep.zip']); r2 = await rows(g2); await do_import(g2); s2, k2 = await result(g2)
        ok('T2 zip 3 tệp: 3 dòng, 2 dư nợ + 1 TSBĐ (nhận theo tiêu đề)', len(r2) == 3 and sum('Dư nợ IPCAS' in x for x in r2) == 2 and sum('Sao kê TSBĐ' in x for x in r2) == 1, r2)
        ok('T2b nhập qua zip == nhập thẳng xlsx (trạng thái từng tệp)', s1 == s2 and len(s1) == 3 and all('Đã nhập' in x or 'tài sản' in x or 'dòng' in x for x in s1), (s1, s2))
        ok('T2c nhập qua zip == nhập thẳng xlsx (KPI Tổng quan)', k1 == k2 and len(k1) >= 3, (k1, k2))
        ok('T2d không lỗi JS', not g1.errs and not g2.errs, g1.errs + g2.errs); await b1.close(); await b2.close()
        Z40 = ROOT / 'kiem_thu_p40' / 'zip'
        await scen(p, 'T3 thư mục/rác', [Z40 / 'thumuc_rac.zip'], 1, must=['msit80_31-10-2026.xlsx'], mustnot=['~$', 'Thumbs', 'ghichu', 'thoat', 'MACOSX'], notemust=['bỏ qua'])
        await scen(p, 'T4 zip lồng zip', [Z40 / 'long_nhau.zip'], 2, must=['msit80_30-09-2026.xlsx', 'msit80_31-10-2026.xlsx'])
        await scen(p, 'T5 tên tiếng Việt', [Z40 / 'ten_tieng_viet.zip'], 2, must=['Sao kê TSBĐ 18-08-2026.xlsx', 'Sao kê TSBĐ'])
        await scen(p, 'T6 tên không cờ UTF-8', [Z40 / 'ten_khong_utf8.zip'], 1, must=['msit80_31-10-2026.xlsx'])
        await scen(p, 'T7 hai zip trùng tên tệp', [Z40 / 'trung_a.zip', Z40 / 'trung_b.zip'], 2, must=['msit80_31-10-2026 (2).xlsx', 'Trùng loại + ngày'])
        await scen(p, 'T8 zip hỏng', [Z40 / 'hong.zip'], 0, notemust=['✗'])
        await scen(p, 'T9 không phải zip', [Z40 / 'khong_phai_zip.zip'], 0, notemust=['không phải tệp zip'])
        await scen(p, 'T10a .rar', [Z40 / 'gia_rar.rar'], 0, notemust=['RAR', 'ZIP', 'gia_rar.rar'], mustnot=['Định dạng không hỗ trợ'])
        await scen(p, 'T10b rar đổi đuôi .zip', [Z40 / 'rar_doi_duoi.zip'], 0, notemust=['RAR', 'ZIP'])
        await scen(p, 'T11 có mật khẩu', [Z40 / 'co_mat_khau.zip'], 0, notemust=['mật khẩu'])
        await scen(p, 'T12a bom tỉ lệ', [Z40 / 'bom_ti_le.zip'], 0, notemust=['bất thường'])
        await scen(p, 'T12b bom khai báo lớn', [Z40 / 'bom_khong_lo.zip'], 0, notemust=['quá lớn'])
        await scen(p, 'T13 zip không có bảng tính', [Z40 / 'khong_co_bang_tinh.zip'], 0, notemust=['không có'])
        await scen(p, 'T14 lô trộn zip + csv + rar', [Z40 / 'ok_3tep.zip', C / 'lon_cuoi_ky.csv', Z40 / 'gia_rar.rar'], 4, must=['lon_cuoi_ky.csv'], notemust=['RAR'])
        # zip từ công cụ nén khác nhau (backlog P39/P40: 7-Zip/WinRAR/Explorer — 7-Zip + Info-ZIP kiểm ở đây)
        await scen(p, 'T17 zip tạo bằng 7-Zip', [Z / 'zip_7za.zip'], 2, must=['msit80_30-09-2026.xlsx', '18_08_2026-TS.xlsx', 'Sao kê TSBĐ'])
        await scen(p, 'T18 zip tạo bằng Info-ZIP', [Z / 'zip_infozip.zip'], 2, must=['msit80_30-09-2026.xlsx', '18_08_2026-TS.xlsx'])
        await scen(p, 'T19 zip Info-ZIP nén bzip2 (kiểu nén chưa hỗ trợ → báo rõ)', [Z / 'zip_bzip2.zip'], 0, notemust=['kiểu nén', 'zip_bzip2.zip'])
        await scen(p, 'T20 zip64 (khai báo mở rộng) đọc được', [Z / 'zip_zip64.zip'], 1, must=['18_08_2026-TS.xlsx'])
        # kéo thả
        b, pg = await newpage(p)
        data = base64.b64encode((Z40 / 'ok_3tep.zip').read_bytes()).decode()
        await pg.evaluate("""async (b64)=>{const bin=atob(b64),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);
          const dt=new DataTransfer();dt.items.add(new File([u],'ok_3tep.zip',{type:'application/zip'}));
          document.querySelector('[data-testid="drop"]').dispatchEvent(new DragEvent('drop',{bubbles:true,cancelable:true,dataTransfer:dt}));}""", data)
        await pg.wait_for_timeout(2500); r = await rows(pg)
        ok('T15 kéo thả zip: 3 dòng', len(r) == 3, r); ok('T15b không lỗi JS', not pg.errs, pg.errs)
        await pg.screenshot(path=str(HERE / 'anh_p42_keo_tha_zip.png')); await b.close()
        # tệp thường không bị ảnh hưởng
        await scen(p, 'T16 xlsx thường (không zip)', [X / 'msit80_31-10-2026.xlsx'], 1, must=['msit80_31-10-2026.xlsx'])
    n = sum(res); print(f'\nKẾT QUẢ P42: {n}/{len(res)} đạt'); sys.exit(0 if n == len(res) else 1)
asyncio.run(main())
