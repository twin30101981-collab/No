// HM-11a (P02): kiểm đơn vị lõi QLTD_DSTN (nguon_P02/qltd_dstn.cjs). Chạy: node kiem_thu_p02/test_hm11_dstn.test.cjs
'use strict';
const path = require('path');
const L = require(path.join(__dirname, '..', 'nguon_P02', 'qltd_dstn.cjs'));
let pass = 0, fail = 0;
function ok(n, c, info) { if (c) { pass++; console.log('PASS  ' + n); } else { fail++; console.log('FAIL  ' + n + ' — ' + JSON.stringify(info)); } }
const r = (seq, appr, cust, dt, amt, bal, cb, phong) => ({ dsbsseq: seq, apprseq: appr, brcd: cust, custseq: '3201' /* custseq thật = mã chi nhánh, giống nhau mọi dòng */, dsbsdt: dt, dsbsamt: amt, dsbsbal: bal, ofcno: cb, ofcnm: 'CB ' + cb, trctnm: phong, lntpcd: 'Vay ngắn hạn (TK 211)' });
const bat = (x) => Math.abs(x.dauKy + x.gn - x.thu + x.dieuChinh - x.cuoiKy) < 0.5;
const k = (res, seq) => res.khe.find(z => z.dsbsseq === seq);

// Đầu kỳ 30/09, cuối kỳ 31/10
const DAU = [
  r('001', 'HD1', 'KH1', '2026-01-10', 500e6, 500e6, 'A', 'Hội Sở'),       // trả một phần 200tr
  r('002', 'HD2', 'KH2', '2026-02-10', 300e6, 300e6, 'A', 'Hội Sở'),       // tất toán, KH2 còn khoản khác cuối kỳ (CB mới B)
  r('003', 'HD3', 'KH3', '2026-03-10', 100e6, 100e6, 'B', 'PGD Số 2'),     // tất toán, KH3 hết dư nợ → CB ở mốc cuối cùng (B)
  r('004', 'HD4', 'KH4', '2026-04-05', 800e6, 800e6, 'A', 'Hội Sở'),       // đổi HĐTD (apprseq) giữ dsbsseq, không trả
  r('005', 'HD5', 'KH5', '2026-05-05', 400e6, 400e6, 'A', 'Hội Sở'),       // đổi cán bộ A → C, trả 100tr
];
const CUOI = [
  r('001', 'HD1', 'KH1', '2026-01-10', 500e6, 300e6, 'A', 'Hội Sở'),
  r('006', 'HD6', 'KH2', '2026-10-05', 250e6, 250e6, 'B', 'Hội Sở'),       // GN mới 05/10 (ngày ≤ 12), KH2 → CB B
  r('004', 'HD4b', 'KH4', '2026-04-05', 800e6, 800e6, 'A', 'Hội Sở'),
  r('005', 'HD5', 'KH5', '2026-05-05', 400e6, 300e6, 'C', 'Hội Sở'),
  r('007', 'HD7', 'KH7', '2026-10-12', 90e6, 60e6, 'C', 'PGD Số 2'),        // GN 12/10 và trả 30tr trong kỳ
];
const R = L.tinh([{ ngay: '30/09/2026', rows: DAU }, { ngay: '31/10/2026', rows: CUOI }]);
ok('U1 phiên bản lõi', L.PHIEN_BAN === 'P04-HM12 1.1.0'); // 1.0.1 → 1.1.0 (HM-12): chỉ CỘNG THÊM k.moc
ok('U2 tổng dư nợ đầu/cuối = tổng tệp', R.tong.dauKy === 2100e6 && R.tong.cuoiKy === 1710e6 && R.tong.dauTep === R.tong.dauKy && R.tong.cuoiTep === R.tong.cuoiKy, R.tong);
ok('U3 GN = 250tr + 90tr, 2 món', R.tong.gn === 340e6 && R.tong.gnMon === 2, R.tong);
ok('U4 thu nợ = 200 + 300 + 100 + 100 + 30 = 730tr', R.tong.thu === 730e6, R.tong);
ok('U5 bất biến tổng: Đầu + GN − Thu + ĐC = Cuối, ĐC = 0', bat(R.tong) && R.tong.dieuChinh === 0 && R.tong.kiemTra === 0, R.tong);
ok('U6 đổi HĐTD giữ dsbsseq: KHÔNG tất toán giả, thu 0', k(R, '004').thu === 0 && !k(R, '004').tatToan && k(R, '004').gn === 0);
ok('U7 tất toán: KH còn dư nợ cuối kỳ → gán CB cuối kỳ của KH (B)', k(R, '002').tatToan && k(R, '002').thu === 300e6 && k(R, '002').cbMa === 'B', k(R, '002'));
ok('U8 tất toán: KH hết dư nợ → CB ở mốc cuối cùng (B, PGD Số 2)', k(R, '003').cbMa === 'B' && k(R, '003').phong === 'PGD Số 2', k(R, '003'));
ok('U9 đổi cán bộ A→C: thu 100tr tính cho C (cán bộ cuối kỳ)', k(R, '005').cbMa === 'C' && k(R, '005').thu === 100e6);
ok('U10 GN 12/10 trả 30tr trong kỳ: GN 90tr, thu 30tr', k(R, '007').gn === 90e6 && k(R, '007').thu === 30e6);
const cb = id => R.canBo.find(x => x.cbMa === id && x.phong === 'Hội Sở');
ok('U11 cán bộ A (Hội Sở): chỉ gồm khế ước gán cho A cuối kỳ (001 + 004): cuối 1.100tr, thu 200tr', cb('A').cuoiKy === 1100e6 && cb('A').thu === 200e6, cb('A'));
ok('U12 tổng cán bộ = tổng phòng = tổng', ['dauKy', 'gn', 'thu', 'dieuChinh', 'cuoiKy'].every(f => Math.abs(R.canBo.reduce((a, x) => a + x[f], 0) - R.tong[f]) < 0.5 && Math.abs(R.phong.reduce((a, x) => a + x[f], 0) - R.tong[f]) < 0.5));
ok('U13 mọi cán bộ/phòng: kiểm tra = 0', R.canBo.concat(R.phong).every(x => Math.abs(x.kiemTra) < 0.5));
ok('U14 không có cảnh báo', R.canhBao.length === 0, R.canhBao);

// Mốc giữa kỳ: khoản GN 10/10 rồi tất toán 25/10 chỉ thấy được nhờ mốc 15/10
const GIUA = DAU.concat([r('008', 'HD8', 'KH8', '2026-10-10', 120e6, 120e6, 'A', 'Hội Sở')]);
const R2 = L.tinh([{ ngay: '2026-09-30', rows: DAU }, { ngay: '2026-10-15', rows: GIUA }, { ngay: '2026-10-31', rows: CUOI }]);
ok('U15 có mốc giữa kỳ: thấy GN 120tr rồi tất toán → GN 460tr, thu 850tr', R2.tong.gn === 460e6 && R2.tong.thu === 850e6 && R2.tong.kiemTra === 0, R2.tong);
const R1 = L.tinh([{ ngay: '2026-09-30', rows: DAU }, { ngay: '2026-10-31', rows: CUOI }]);
ok('U16 không mốc giữa: khoản 008 không thấy (giới hạn đã nêu)', !R1.khe.find(z => z.dsbsseq === '008'));

// Biên: dư nợ tăng không có GN; khoản xuất hiện với ngày GN trước kỳ
const R3 = L.tinh([{ ngay: '2026-09-30', rows: [r('009', 'H', 'K9', '2026-01-01', 100e6, 50e6, 'A', 'Hội Sở')] },
  { ngay: '2026-10-31', rows: [r('009', 'H', 'K9', '2026-01-01', 100e6, 70e6, 'A', 'Hội Sở'), r('010', 'H', 'K10', '2026-06-01', 40e6, 40e6, 'A', 'Hội Sở')] }]);
ok('U17 dư nợ tăng không GN → điều chỉnh +20tr, thu 0', k(R3, '009').thu === 0 && k(R3, '009').dieuChinh === 20e6);
ok('U18 khoản xuất hiện có ngày GN trước kỳ → điều chỉnh +40tr, không tính GN', k(R3, '010').gn === 0 && k(R3, '010').dieuChinh === 40e6 && R3.tong.kiemTra === 0);
ok('U19 ngày dd/mm/yyyy không đảo: 05/10/2026 → 2026-10-05', L.iso('05/10/2026') === '2026-10-05' && L.iso('2026-10-05 00:00:00') === '2026-10-05');
ok('U21 mã KH lấy từ brcd (custseq giống nhau mọi dòng không gộp khách hàng)', k(R, '003').cbMa === 'B' && k(R, '003').maKH === 'KH3' && k(R, '002').maKH === 'KH2');
// HM-12: sự kiện theo cặp mốc cộng đúng bằng số khế ước (mọi bộ R, R1, R2, R3)
const sumEv = (z, l) => z.moc.filter(e => e.loai === l).reduce((a, e) => a + e.so, 0);
ok('U22 HM-12: Σ sự kiện gn/thu/dc mỗi khế ước = gn/thu/dieuChinh (4 bộ)', [R, R1, R2, R3].every(X => X.khe.every(z => Math.abs(sumEv(z, 'gn') - z.gn) < 0.5 && Math.abs(sumEv(z, 'thu') - z.thu) < 0.5 && Math.abs(sumEv(z, 'dc') - z.dieuChinh) < 0.5)));
ok('U23 HM-12: sự kiện ghi đúng cặp mốc (008 GN ở 30/09→15/10, tất toán ở 15/10→31/10)', (() => { const z = R2.khe.find(q => q.dsbsseq === '008'); return z.moc.length === 2 && z.moc[0].loai === 'gn' && z.moc[0].den === '2026-10-15' && z.moc[1].loai === 'thu' && z.moc[1].tu === '2026-10-15' && z.moc[1].den === '2026-10-31'; })(), R2.khe.find(q => q.dsbsseq === '008').moc);
let loi = ''; try { L.tinh([{ ngay: '2026-10-31', rows: [] }, { ngay: '2026-09-30', rows: [] }]); } catch (e) { loi = e.message; }
ok('U20 mốc không tăng dần → báo lỗi rõ', /tăng dần/.test(loi), loi);
console.log(`\n${pass}/${pass + fail} PASS`); process.exit(fail ? 1 : 0);
