# HM-11a: đọc các tệp msit80 (tên dd.mm.yyyy.xls/.xlsx) thành pickle tạm. DỮ LIỆU THẬT — không đưa vào repo/ZIP.
# Dùng: python3 -I kiem_thu_p02/doc_mis80.py <thư mục> <tam.pkl>
import sys, re, pickle
from pathlib import Path
import pandas as pd
src, out = Path(sys.argv[1]), Path(sys.argv[2])
data = {}
for f in sorted(src.glob('*')):
    if not f.is_file() or not re.match(r'\d\d\.\d\d\.\d{4}\.(xlsx|XLS)$', f.name): continue
    eng = 'openpyxl' if f.suffix.lower() == '.xlsx' else 'xlrd'
    df = pd.read_excel(f, engine=eng, dtype=str)
    d, m, y = f.name[:10].split('.')
    data[f'{y}-{m}-{d}'] = df
    print(f.name, df.shape, list(df.columns)[:12])
pickle.dump(data, open(out, 'wb'))
cols = {k: list(v.columns) for k, v in data.items()}
base = cols[min(cols)]
for k, c in cols.items():
    if c != base: print('KHÁC CỘT', k, set(c) ^ set(base))
