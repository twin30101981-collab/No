# -*- coding: utf-8 -*-
# HM-02 (P02): kiểm lan truyền lỗi đọc ngày dd/mm (≤ 12) và mã có số 0 đầu qua các đường nạp tệp.
# Phép thử ĐỐI CHỨNG: cùng một dữ liệu nạp dưới dạng .xlsx nhị phân (chuẩn) và dạng VĂN BẢN (CSV mang đuôi .xls như tệp
# "Nạp từ Lưu trữ" sinh ra, và đuôi .csv) phải cho bảng hiển thị GIỐNG HỆT.
# Dùng: python3 kiem_thu_p02/test_hm02_duong_doc.py [app/QLTDPRO_vX.html]   (cổng 8861)
import asyncio, csv, functools, http.server, io, re, shutil, subprocess, sys, tempfile, threading
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
HTML = (Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'app' / 'QLTDPRO_v24.17.9.html').resolve()
PORT = 8861; URL = f'http://127.0.0.1:{PORT}/{HTML.name}'
SRC = ROOT / 'app' / 'kiem_thu_p40' / 'xlsx'; TMP = Path(tempfile.mkdtemp(prefix='hm02_'))
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
httpd = http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(HTML.parent)))
threading.Thread(target=httpd.serve_forever, daemon=True).start()
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:700]), flush=True)

def to_text(src, dst, n=None):
    """Chép sheet đầu thành văn bản CSV (mọi ô là chuỗi như hiển thị trong tệp) — giống tệp trung gian của Nạp từ Lưu trữ."""
    ws = openpyxl.load_workbook(src).worksheets[0]; buf = io.StringIO(); w = csv.writer(buf)
    for i, r in enumerate(ws.iter_rows(values_only=True)):
        if n and i > n: break
        w.writerow(['' if v is None else (v if isinstance(v, str) else (str(int(v)) if isinstance(v, float) and v.is_integer() else str(v))) for v in r])
    dst.write_text(buf.getvalue(), encoding='utf-8-sig'); return dst  # có BOM như tệp CSV thực tế (Excel/Lưu trữ)

def ts_fixture():
    """TSBĐ: 40 dòng đầu của mẫu P40, ngày dạng dd/mm/yyyy (ngày ≤ 12) + mã có số 0 đầu ('0123.002')."""
    wb = openpyxl.load_workbook(SRC / '18_08_2026-TS.xlsx'); ws = wb.worksheets[0]
    ws.delete_rows(42, ws.max_row)
    hdr = [c.value for c in ws[1]]; ix = {h: i for i, h in enumerate(hdr)}
    for k, r in enumerate(ws.iter_rows(min_row=2)):
        r[ix['plgdt']].value = '%02d/%02d/2025' % (1 + k % 12, 1 + (k * 5) % 12)   # cả hai thành phần ≤ 12
        r[ix['ntydt']].value = '%02d/10/2026' % (1 + k % 12)
        r[ix['plgcustno']].value = '0%03d.%03d' % (100 + k, k)                   # số 0 đầu
        for c in (r[ix['plgdt']], r[ix['ntydt']], r[ix['plgcustno']]): c.number_format = '@'
    x = TMP / 'xlsx'; x.mkdir(exist_ok=True); t = TMP / 'txt'; t.mkdir(exist_ok=True); c = TMP / 'csv'; c.mkdir(exist_ok=True)
    wb.save(x / '18_08_2026-TS.xlsx')
    to_text(x / '18_08_2026-TS.xlsx', t / '18_08_2026-TS.xls'); to_text(x / '18_08_2026-TS.xlsx', c / '18_08_2026-TS.csv')
    bf = TMP / 'biff'; bf.mkdir(exist_ok=True); so = shutil.which('soffice') or shutil.which('libreoffice')
    if so:  # .xls nhị phân thật (BIFF8) để đối chứng: raw không được làm đổi kết quả tệp nhị phân
        subprocess.run([so, '--headless', '--convert-to', 'xls:MS Excel 97', '--outdir', str(bf), str(x / '18_08_2026-TS.xlsx')], capture_output=True, timeout=120)
    b = bf / '18_08_2026-TS.xls'
    return x / '18_08_2026-TS.xlsx', t / '18_08_2026-TS.xls', c / '18_08_2026-TS.csv', (b if b.exists() else None)

def duno_fixture():
    """Dư nợ: 60 dòng đầu msit80 31/10, ngày dạng chuỗi dd/mm ≤ 12 + dsbsseq có số 0 đầu."""
    wb = openpyxl.load_workbook(SRC / 'msit80_31-10-2026.xlsx'); ws = wb.worksheets[0]
    ws.delete_rows(62, ws.max_row); hdr = [c.value for c in ws[1]]; ix = {h: i for i, h in enumerate(hdr)}
    for k, r in enumerate(ws.iter_rows(min_row=2)):
        for col in ('dsbsdt', 'apprdt'):
            if col in ix: r[ix[col]].value = '%02d/%02d/2026' % (1 + k % 12, 1 + (k * 7) % 10); r[ix[col]].number_format = '@'
        for col in ('dsbsmatdt', 'apprmatdt'):
            if col in ix: r[ix[col]].value = '%02d/%02d/2027' % (1 + k % 12, 1 + (k * 7) % 10); r[ix[col]].number_format = '@'
        if 'dsbsseq' in ix: r[ix['dsbsseq']].value = '%03d' % (1 + k % 9); r[ix['dsbsseq']].number_format = '@'
    x = TMP / 'dx'; x.mkdir(exist_ok=True); t = TMP / 'dt'; t.mkdir(exist_ok=True)
    wb.save(x / 'msit80_31-10-2026.xlsx'); to_text(x / 'msit80_31-10-2026.xlsx', t / 'msit80_31-10-2026.xls')
    return x / 'msit80_31-10-2026.xlsx', t / 'msit80_31-10-2026.xls'

async def nap(p, files):
    b = await p.chromium.launch(); ctx = await b.new_context(viewport={'width': 1600, 'height': 1000}, locale='vi-VN')
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); pg.errs = []; pg.on('pageerror', lambda e: pg.errs.append(str(e)))
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in files]); await pg.wait_for_timeout(2500)
    plan = [re.sub(r'\s+', ' ', t) for t in await pg.locator('[data-testid="plan"] tbody tr').all_inner_texts()]
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(5000)
    return b, pg, plan

async def luoi(pg, route, n=40):
    await pg.goto(URL + '#/' + route, wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    return await pg.evaluate("""(n) => [...document.querySelectorAll('main div.flex.hover\\\\:bg-accent\\\\/50')].slice(0, n)
        .map(r => [...r.children].map(c => c.innerText.trim().replace(/\\s+/g, ' ')).join(' | '))""", n)

def lech(a, b):
    return [(i, x, y) for i, (x, y) in enumerate(zip(a, b)) if x != y][:3]

async def main():
    tsx, tst, tsc, tsb = ts_fixture(); dx, dt = duno_fixture()
    print(f'Bản kiểm: {HTML.name} · dữ liệu thử: {TMP}')
    async with async_playwright() as p:
        # Đường 1 — Nhập dữ liệu, sao kê TSBĐ
        b0, g0, _ = await nap(p, [dx, tsx]); L0 = await luoi(g0, 'tai-san-bao-dam')
        b1, g1, pl1 = await nap(p, [dx, tst]); L1 = await luoi(g1, 'tai-san-bao-dam')
        b2, g2, pl2 = await nap(p, [dx, tsc]); L2 = await luoi(g2, 'tai-san-bao-dam')
        ok('D0 đối chứng xlsx TSBĐ: bảng có ≥ 30 dòng và có ngày thế chấp dạng dd/mm/yyyy', len(L0) >= 30 and re.search(r'\d\d/\d\d/2025', ' '.join(L0)), L0[:2])
        ok('D1 nhận loại: tệp văn bản .xls được nhận là Sao kê TSBĐ', any('Sao kê TSBĐ' in x for x in pl1), pl1)
        ok('D1b TSBĐ dạng văn bản .xls == xlsx (ngày ≤ 12 và mã số 0 đầu không đổi)', L1 == L0, lech(L0, L1))
        # Ghi nhận (thẻ riêng HM-15, KHÔNG tính vào cổng HM-02): tệp TSBĐ đuôi .csv bị nhận nhầm loại "Dư nợ IPCAS".
        print('GHI_NHAN HM-15 tệp .csv TSBĐ nhận loại: ' + ('Sao kê TSBĐ' if any('Sao kê TSBĐ' in x for x in pl2) else 'SAI — ' + ' ## '.join(pl2)[:300]), flush=True)
        if tsb:
            b5, g5, pl5 = await nap(p, [dx, tsb]); L5 = await luoi(g5, 'tai-san-bao-dam')
            ok('D3 TSBĐ .xls nhị phân (BIFF8) == xlsx', L5 == L0 and any('Sao kê TSBĐ' in x for x in pl5), lech(L0, L5) or pl5)
            ok('D9 không lỗi JS (TSBĐ BIFF8)', not g5.errs, g5.errs); await b5.close()
        else:
            print('SKIP D3 TSBĐ .xls nhị phân (BIFF8) — không có LibreOffice để tạo tệp', flush=True)
        for g in (g0, g1, g2): ok('D9 không lỗi JS (TSBĐ)', not g.errs, g.errs)
        for x in (b0, b1, b2): await x.close()
        # Đường 2 — Nhập dữ liệu, dư nợ IPCAS (ipcasRows raw:true — kỳ vọng đúng)
        b3, g3, _ = await nap(p, [dx]); M0 = await luoi(g3, 'tat-ca-du-no')
        b4, g4, _ = await nap(p, [dt]); M1 = await luoi(g4, 'tat-ca-du-no')
        ok('E0 đối chứng dư nợ xlsx: ≥ 30 dòng', len(M0) >= 30, len(M0))
        ok('E1 dư nợ dạng văn bản .xls == xlsx (ngày GN/đến hạn ≤ 12, số GN "001")', M1 == M0, lech(M0, M1))
        for g in (g3, g4): ok('E9 không lỗi JS (dư nợ)', not g.errs, g.errs)
        await b3.close(); await b4.close()
    print(f'\n{sum(res)}/{len(res)} PASS'); sys.exit(0 if all(res) else 1)

asyncio.run(main())
