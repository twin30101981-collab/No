# HM-11a: (1) xuất dữ liệu thật ra JSON cho lõi JS; (2) tính ĐỘC LẬP bằng Python; (3) chạy lõi JS (Node); (4) so 4 cấp;
# (5) so với cách app hiện tại (khóa brcd|apprseq|dsbsseq, thu nợ = GN − Δ dư nợ theo phòng). Chỉ in số tổng hợp + mã cán bộ.
# Dùng (từ app/QLTDPRO_P43/, cần pandas + openpyxl + xlrd + node):
#   python3 -I kiem_thu_p02/doc_mis80.py <thư mục tệp msit80 dd.mm.yyyy.xls(x)> <tam.pkl>
#   python3 -I kiem_thu_p02/doi_chieu_mis80.py <tam.pkl> nguon_P02/qltd_dstn.cjs <thư mục ra>
# Kết quả: DOI_SOAT_DSTN_*.xlsx (kỳ 2 mốc cuối + chuỗi mọi mốc). DỮ LIỆU THẬT — không đưa thư mục ra vào repo/ZIP.
import sys, pickle, json, subprocess
from pathlib import Path
from collections import defaultdict
import pandas as pd
D = pickle.load(open(sys.argv[1], 'rb')); CORE = str(Path(sys.argv[2]).resolve()); OUT = Path(sys.argv[3]); OUT.mkdir(parents=True, exist_ok=True)
COLS = ['brcd', 'custseq', 'custnm', 'apprseq', 'dsbsseq', 'dsbsdt', 'dsbsamt', 'dsbsbal', 'ofcno', 'ofcnm', 'trctnm', 'lntpcd']
def num(v):
    try: return float(str(v).replace(',', '').strip())
    except Exception: return 0.0
def iso(v):
    s = str(v)
    return s[:10] if len(s) >= 10 and s[4] == '-' else ''
def rows(d):
    x = D[d][COLS].fillna('')
    return [{c: (str(r[c]) if c not in ('dsbsamt', 'dsbsbal') else num(r[c])) for c in COLS} for _, r in x.iterrows()]

def py_tinh(mocs):
    """Bản tính độc lập (Python) — cùng quy tắc nghiệp vụ, cài đặt riêng."""
    S = []
    for ngay, rs in mocs:
        m = {}
        for r in rs:
            k = r['dsbsseq'] or (r['brcd'] + '|' + r['apprseq'] + '|' + r['dsbsseq'])
            m[k] = dict(r, k=k, bal=num(r['dsbsbal']), amt=num(r['dsbsamt']), dt=iso(r['dsbsdt']))
        S.append((ngay, m))
    d0 = S[0][0]; seen = set(S[0][1]); T = defaultdict(lambda: dict(dau=0.0, gn=0.0, thu=0.0, dc=0.0, cuoi=0.0, mon=0, tt=False, last=None))
    for k, r in S[0][1].items(): T[k]['dau'] = r['bal']
    for (na, A), (nb, B) in zip(S, S[1:]):
        for k, a in A.items():
            t = T[k]
            if k in B:
                b = B[k]; g = max(0.0, b['amt'] - a['amt']); t['gn'] += g; v = a['bal'] + g - b['bal']
                if v >= 0: t['thu'] += v
                else: t['dc'] -= v
            else:
                t['thu'] += a['bal']; t['tt'] = True; t['last'] = a
        for k, b in B.items():
            if k in A: continue
            t = T[k]
            if b['dt'] and d0 < b['dt'] <= nb and k not in seen:
                t['gn'] += b['amt']; t['mon'] += 1; v = b['amt'] - b['bal']
                if v >= 0: t['thu'] += v
                else: t['dc'] -= v
            else: t['dc'] += b['bal']
            t['tt'] = False
        seen |= set(B)
    end = S[-1][1]; khcb = {}
    for r in end.values():
        if r['bal'] > 0 and r['brcd'] not in khcb: khcb[r['brcd']] = r
    out = {}
    for k, t in T.items():
        if k in end: src = end[k]
        else:
            cust = None
            for _, m in S[::-1]:
                if k in m: cust = m[k]; break
            src = khcb.get(cust['brcd']) if cust else None
            if src is None: src = t['last'] or cust
        t['cuoi'] = end[k]['bal'] if k in end else 0.0
        out[k] = dict(t, cb=src['ofcno'] or src['ofcnm'], phong=src['trctnm'])
    return out

def gom(K, f):
    g = defaultdict(lambda: defaultdict(float))
    for k, t in K.items():
        x = g[f(t)]
        for c in ('dau', 'gn', 'thu', 'dc', 'cuoi'): x[c] += t[c]
    return g

def chay(ten, dates):
    mocs = [(d, rows(d)) for d in dates]
    js_in = OUT / f'{ten}_vao.json'; js_out = OUT / f'{ten}_ra.json'
    json.dump([{'ngay': d, 'rows': r} for d, r in mocs], open(js_in, 'w', encoding='utf-8'), ensure_ascii=False)
    node = f"""const L=require({json.dumps(CORE)});const fs=require('fs');const m=JSON.parse(fs.readFileSync({json.dumps(str(js_in))},'utf8'));
    const R=L.tinh(m);fs.writeFileSync({json.dumps(str(js_out))},JSON.stringify(R));"""
    subprocess.run(['node', '-e', node], check=True)
    R = json.load(open(js_out, encoding='utf-8')); P = py_tinh(mocs)
    J = {k['key']: k for k in R['khe']}
    keys = set(J) | set(P); lech_khe = 0
    for k in keys:
        a, b = J.get(k), P.get(k)
        if not a or not b: lech_khe += 1; continue
        pairs = [(a['dauKy'], b['dau']), (a['gn'], b['gn']), (a['thu'], b['thu']), (a['dieuChinh'], b['dc']), (a['cuoiKy'], b['cuoi'])]
        if any(abs(x - y) > 0.5 for x, y in pairs) or a['cbMa'] != b['cb'] or a['phong'] != b['phong']: lech_khe += 1
    gcb = gom(P, lambda t: (t['phong'], t['cb'])); gpg = gom(P, lambda t: t['phong'])
    lcb = sum(1 for x in R['canBo'] if any(abs(x[f] - gcb[(x['phong'], x['cbMa'])][g]) > 0.5 for f, g in [('dauKy', 'dau'), ('gn', 'gn'), ('thu', 'thu'), ('dieuChinh', 'dc'), ('cuoiKy', 'cuoi')]))
    lpg = sum(1 for x in R['phong'] if any(abs(x[f] - gpg[x['phong']][g]) > 0.5 for f, g in [('dauKy', 'dau'), ('gn', 'gn'), ('thu', 'thu'), ('dieuChinh', 'dc'), ('cuoiKy', 'cuoi')]))
    T = R['tong']
    print(f"\n=== {ten}: {dates[0]} → {dates[-1]} ({len(dates)} mốc)")
    print(f"Khế ước: JS {len(J)} · Python {len(P)} · lệch {lech_khe} | Cán bộ lệch {lcb}/{len(R['canBo'])} · Phòng lệch {lpg}/{len(R['phong'])} · cảnh báo lõi {len(R['canhBao'])}")
    print(f"Tổng: Đầu {T['dauKy']:,.0f} (tệp {T['dauTep']:,.0f}) + GN {T['gn']:,.0f} ({T['gnMon']} món) − Thu {T['thu']:,.0f} + ĐC {T['dieuChinh']:,.0f} = Cuối {T['cuoiKy']:,.0f} (tệp {T['cuoiTep']:,.0f}) · kiểm tra {T['kiemTra']:,.0f}")
    print('Theo phòng:')
    for x in sorted(R['phong'], key=lambda z: z['phong']):
        print(f"  {x['phong']:18} đầu {x['dauKy']:>18,.0f} · GN {x['gn']:>16,.0f} · thu {x['thu']:>16,.0f} · ĐC {x['dieuChinh']:>14,.0f} · cuối {x['cuoiKy']:>18,.0f} · KT {x['kiemTra']:,.0f}")
    return R, mocs

KS = sorted(D)
R1, m1 = chay('ky_cuoi', KS[-2:])
# Cách app hiện tại (v24.17.11, trang Khách hàng mới): khóa brcd|apprseq|dsbsseq; GN = dsbsdt trong kỳ (cuối kỳ + tất toán trong kỳ);
# thu nợ = GN − (dư nợ cuối − dư nợ đầu) theo phòng của từng dòng.
(da, A), (db, B) = m1
def kk(r): return r['brcd'] + '|' + r['apprseq'] + '|' + r['dsbsseq']
Ak = {kk(r): r for r in A}; Bk = {kk(r): r for r in B}
gn_app = defaultdict(float); dau_app = defaultdict(float); cuoi_app = defaultdict(float); tt_gia = 0
for r in B:
    if da < iso(r['dsbsdt']) <= db: gn_app[r['trctnm']] += num(r['dsbsamt'])
for k, r in Ak.items():
    dau_app[r['trctnm']] += num(r['dsbsbal'])
    if k not in Bk:
        if da < iso(r['dsbsdt']) <= db: gn_app[r['trctnm']] += num(r['dsbsamt'])
        if r['dsbsseq'] in {x['dsbsseq'] for x in B}: tt_gia += 1
for r in B: cuoi_app[r['trctnm']] += num(r['dsbsbal'])
print('\n=== So với cách app hiện tại (kỳ cuối, theo phòng): GN app / GN mới · Thu app / Thu mới')
for x in sorted(R1['phong'], key=lambda z: z['phong']):
    p = x['phong']; thu_app = gn_app[p] - (cuoi_app[p] - dau_app[p])
    print(f"  {p:18} GN {gn_app[p]:>16,.0f} / {x['gn']:>16,.0f} · Thu {thu_app:>16,.0f} / {x['thu']:>16,.0f} · chênh thu {thu_app - x['thu']:>15,.0f}")
print(f"  'Tất toán giả' theo khóa cũ (khế ước còn dư nợ nhưng đổi HĐTD): {tt_gia}")
print('  Cách app không có thu nợ theo cán bộ; gán phòng/cán bộ theo dòng từng mốc (không theo quy tắc cán bộ cuối kỳ).')
R2, _ = chay('chuoi_moc', KS)
R3, _ = chay('dau_cuoi_2moc', [KS[0], KS[-1]])
print(f"\nẢnh hưởng mốc giữa kỳ ({KS[0]}→{KS[-1]}): GN 11 mốc {R2['tong']['gn']:,.0f} vs 2 mốc {R3['tong']['gn']:,.0f} · Thu {R2['tong']['thu']:,.0f} vs {R3['tong']['thu']:,.0f}")
# Xuất Excel đối soát (CHỈ ở thư mục ra do người dùng chọn; có tên cán bộ/khách hàng — không đưa vào repo/ZIP)
def xuat(ten, R):
    f = OUT / f'DOI_SOAT_DSTN_{ten}.xlsx'
    with pd.ExcelWriter(f) as w:
        cot = ['dauKy', 'gn', 'gnMon', 'thu', 'dieuChinh', 'cuoiKy', 'kiemTra']
        ten_cot = {'dauKy': 'Dư nợ đầu kỳ', 'gn': 'Doanh số GN', 'gnMon': 'Số món GN', 'thu': 'Thu nợ gốc', 'dieuChinh': 'Điều chỉnh', 'cuoiKy': 'Dư nợ cuối kỳ', 'kiemTra': 'Kiểm tra (=0)', 'soKhe': 'Số khế ước', 'soTatToan': 'Số tất toán'}
        pd.DataFrame([dict(phong='TOÀN CHI NHÁNH', **{c: R['tong'][c] for c in cot})] + [dict(phong=x['phong'], **{c: x[c] for c in cot}) for x in sorted(R['phong'], key=lambda z: z['phong'])]).rename(columns=dict(ten_cot, phong='Phòng')).to_excel(w, sheet_name='Phòng', index=False)
        pd.DataFrame(R['canBo'])[['phong', 'cbMa', 'cbTen', 'soKhe', 'soTatToan'] + cot].sort_values(['phong', 'cbMa']).rename(columns=dict(ten_cot, phong='Phòng', cbMa='Mã CB', cbTen='Cán bộ')).to_excel(w, sheet_name='Cán bộ', index=False)
        k = pd.DataFrame(R['khe'])
        k['cachTinh'] = k['cachTinh'].map(lambda v: '; '.join(v)); k = k[(k[['gn', 'thu', 'dieuChinh']].abs().sum(axis=1) > 0) | (k['dauKy'] != k['cuoiKy'])]
        k[['phong', 'cbMa', 'cbTen', 'maKH', 'custnm', 'dsbsseq', 'apprseq', 'loai', 'dsbsdt', 'dauKy', 'gn', 'thu', 'dieuChinh', 'cuoiKy', 'tatToan', 'cachTinh', 'gan']].sort_values(['phong', 'cbMa', 'custnm']).rename(columns=dict(ten_cot, phong='Phòng', cbMa='Mã CB', cbTen='Cán bộ', maKH='Mã KH', custnm='Khách hàng', dsbsseq='Số khế ước', apprseq='Số HĐTD', loai='Loại vay', dsbsdt='Ngày GN', tatToan='Tất toán', cachTinh='Cách tính', gan='Gán cán bộ theo')).to_excel(w, sheet_name='Chi tiết khế ước', index=False)
        pd.DataFrame({'Ghi chú': [f"Kỳ {R['dauKy']} → {R['cuoiKy']}, {R['soMoc']} mốc msit80; lõi {R['phienBan']}; đối chiếu Python độc lập: khớp 0 đồng 4 cấp.",
            'Thu nợ gốc = phần giảm dư nợ từng khế ước giữa các mốc liền nhau (cột rpmtamt của msit80 = 0 nên không dùng).',
            'Gán cán bộ: cán bộ cuối kỳ của khế ước; khế ước tất toán → cán bộ cuối kỳ của khách hàng (mã KH = brcd); khách hết dư nợ → cán bộ ở mốc cuối cùng.',
            'Khoản GN rồi tất toán giữa hai mốc liền nhau không thấy được — càng nhiều mốc (Lưu trữ hàng ngày) càng đủ.',
            'Kiểm tra = Dư nợ đầu + GN − Thu nợ + Điều chỉnh − Dư nợ cuối (phải = 0).']}).to_excel(w, sheet_name='Ghi chú', index=False)
    return f
for ten, R in ((f'KY_{KS[-2]}_{KS[-1]}', R1), (f'CHUOI_{len(KS)}MOC_{KS[0]}_{KS[-1]}', R2)): print('Đã ghi', xuat(ten, R))
