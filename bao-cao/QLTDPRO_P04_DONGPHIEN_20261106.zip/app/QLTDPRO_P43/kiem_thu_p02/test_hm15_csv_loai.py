# -*- coding: utf-8 -*-
# HM-15 (P02): tệp .csv (sao kê TSBĐ / dư nợ, kể cả nằm trong .zip) phải được nhận ĐÚNG LOẠI theo tiêu đề và nạp == .xlsx.
# (Hàm sinh dữ liệu chép từ test_hm02_duong_doc.py.)
# Phép thử ĐỐI CHỨNG: cùng một dữ liệu nạp dưới dạng .xlsx nhị phân (chuẩn) và dạng VĂN BẢN (CSV mang đuôi .xls như tệp
# "Nạp từ Lưu trữ" sinh ra, và đuôi .csv) phải cho bảng hiển thị GIỐNG HỆT.
# Dùng: python3 kiem_thu_p02/test_hm15_csv_loai.py [app/QLTDPRO_vX.html]   (cổng 8862)
import asyncio, zipfile, csv, functools, http.server, io, re, shutil, subprocess, sys, tempfile, threading
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
HTML = (Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'app' / 'QLTDPRO_v24.17.9.html').resolve()
PORT = 8862; URL = f'http://127.0.0.1:{PORT}/{HTML.name}'
SRC = ROOT / 'app' / 'kiem_thu_p40' / 'xlsx'; TMP = Path(tempfile.mkdtemp(prefix='hm15_'))
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
httpd = http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(HTML.parent)))
threading.Thread(target=httpd.serve_forever, daemon=True).start()
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:700]), flush=True)

def to_text(src, dst, n=None):
    """Chép sheet đầu thành văn bản CSV (mọi ô là chuỗi như hiển thị trong tệp) — giống tệp trung gian của Nạp từ Lưu trữ."""
    ws = openpyxl.load_workbook(src).worksheets[0]; buf = io.StringIO(); w = csv.writer(buf)
    for i, r in enumerate(ws.iter_rows(values_only=True)):
        if n and i > n: break
        w.writerow(['' if v is None else (v if isinstance(v, str) else (str(int(v)) if isinstance(v, float) and v.is_integer() else str(v))) for v in r])
    dst.write_text(buf.getvalue(), encoding='utf-8-sig'); return dst  # có BOM như tệp CSV thực tế (Excel/Lưu trữ)

def ts_fixture():
    """TSBĐ: 40 dòng đầu của mẫu P40, ngày dạng dd/mm/yyyy (ngày ≤ 12) + mã có số 0 đầu ('0123.002')."""
    wb = openpyxl.load_workbook(SRC / '18_08_2026-TS.xlsx'); ws = wb.worksheets[0]
    ws.delete_rows(42, ws.max_row)
    hdr = [c.value for c in ws[1]]; ix = {h: i for i, h in enumerate(hdr)}
    for k, r in enumerate(ws.iter_rows(min_row=2)):
        r[ix['plgdt']].value = '%02d/%02d/2025' % (1 + k % 12, 1 + (k * 5) % 12)   # cả hai thành phần ≤ 12
        r[ix['ntydt']].value = '%02d/10/2026' % (1 + k % 12)
        r[ix['plgcustno']].value = '0%03d.%03d' % (100 + k, k)                   # số 0 đầu
        for c in (r[ix['plgdt']], r[ix['ntydt']], r[ix['plgcustno']]): c.number_format = '@'
    x = TMP / 'xlsx'; x.mkdir(exist_ok=True); t = TMP / 'txt'; t.mkdir(exist_ok=True); c = TMP / 'csv'; c.mkdir(exist_ok=True)
    wb.save(x / '18_08_2026-TS.xlsx')
    to_text(x / '18_08_2026-TS.xlsx', t / '18_08_2026-TS.xls'); to_text(x / '18_08_2026-TS.xlsx', c / '18_08_2026-TS.csv')
    bf = TMP / 'biff'; bf.mkdir(exist_ok=True); so = shutil.which('soffice') or shutil.which('libreoffice')
    if so:  # .xls nhị phân thật (BIFF8) để đối chứng: raw không được làm đổi kết quả tệp nhị phân
        subprocess.run([so, '--headless', '--convert-to', 'xls:MS Excel 97', '--outdir', str(bf), str(x / '18_08_2026-TS.xlsx')], capture_output=True, timeout=120)
    b = bf / '18_08_2026-TS.xls'
    return x / '18_08_2026-TS.xlsx', t / '18_08_2026-TS.xls', c / '18_08_2026-TS.csv', (b if b.exists() else None)

def duno_fixture():
    """Dư nợ: 60 dòng đầu msit80 31/10, ngày dạng chuỗi dd/mm ≤ 12 + dsbsseq có số 0 đầu."""
    wb = openpyxl.load_workbook(SRC / 'msit80_31-10-2026.xlsx'); ws = wb.worksheets[0]
    ws.delete_rows(62, ws.max_row); hdr = [c.value for c in ws[1]]; ix = {h: i for i, h in enumerate(hdr)}
    for k, r in enumerate(ws.iter_rows(min_row=2)):
        for col in ('dsbsdt', 'apprdt'):
            if col in ix: r[ix[col]].value = '%02d/%02d/2026' % (1 + k % 12, 1 + (k * 7) % 10); r[ix[col]].number_format = '@'
        for col in ('dsbsmatdt', 'apprmatdt'):
            if col in ix: r[ix[col]].value = '%02d/%02d/2027' % (1 + k % 12, 1 + (k * 7) % 10); r[ix[col]].number_format = '@'
        if 'dsbsseq' in ix: r[ix['dsbsseq']].value = '%03d' % (1 + k % 9); r[ix['dsbsseq']].number_format = '@'
    x = TMP / 'dx'; x.mkdir(exist_ok=True); t = TMP / 'dt'; t.mkdir(exist_ok=True)
    wb.save(x / 'msit80_31-10-2026.xlsx'); to_text(x / 'msit80_31-10-2026.xlsx', t / 'msit80_31-10-2026.xls')
    return x / 'msit80_31-10-2026.xlsx', t / 'msit80_31-10-2026.xls'

async def nap(p, files):
    b = await p.chromium.launch(); ctx = await b.new_context(viewport={'width': 1600, 'height': 1000}, locale='vi-VN')
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); pg.errs = []; pg.on('pageerror', lambda e: pg.errs.append(str(e)))
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in files]); await pg.wait_for_timeout(2500)
    plan = [re.sub(r'\s+', ' ', t) for t in await pg.locator('[data-testid="plan"] tbody tr').all_inner_texts()]
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(5000)
    return b, pg, plan

async def luoi(pg, route, n=40):
    await pg.goto(URL + '#/' + route, wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    return await pg.evaluate("""(n) => [...document.querySelectorAll('main div.flex.hover\\\\:bg-accent\\\\/50')].slice(0, n)
        .map(r => [...r.children].map(c => c.innerText.trim().replace(/\\s+/g, ' ')).join(' | '))""", n)

def lech(a, b):
    return [(i, x, y) for i, (x, y) in enumerate(zip(a, b)) if x != y][:3]

async def main():
    tsx, tst, tsc, _ = ts_fixture(); dx, dt = duno_fixture()
    dcsv = TMP / 'dcsv'; dcsv.mkdir(exist_ok=True); dc = to_text(dx, dcsv / 'msit80_31-10-2026.csv')
    z = TMP / 'zip'; z.mkdir(exist_ok=True); zp = z / 'gui_ts.zip'
    with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as zf: zf.write(tsc, '18_08_2026-TS.csv')
    print(f'Bản kiểm: {HTML.name} · dữ liệu thử: {TMP}')
    kieu = lambda pl, ten: next((x for x in pl if ten in x), '')
    async with async_playwright() as p:
        b0, g0, _ = await nap(p, [dx, tsx]); L0 = await luoi(g0, 'tai-san-bao-dam'); M0 = await luoi(g0, 'tat-ca-du-no')
        ok('F0 đối chứng xlsx: TSBĐ ≥ 30 dòng, dư nợ ≥ 30 dòng', len(L0) >= 30 and len(M0) >= 30, (len(L0), len(M0)))
        b1, g1, pl1 = await nap(p, [dx, tsc]); L1 = await luoi(g1, 'tai-san-bao-dam'); M1 = await luoi(g1, 'tat-ca-du-no')
        ok('F1 .csv sao kê TSBĐ (tên không có chữ "tài sản") nhận loại Sao kê TSBĐ', 'Sao kê TSBĐ' in kieu(pl1, '18_08_2026-TS.csv'), pl1)
        ok('F2 nạp .csv TSBĐ == xlsx (ngày ≤ 12, mã số 0 đầu)', L1 == L0, lech(L0, L1) or ('bảng rỗng' if not L1 else ''))
        ok('F2b dư nợ không bị .csv TSBĐ ghi đè', M1 == M0, lech(M0, M1))
        b2, g2, pl2 = await nap(p, [dc]); M2 = await luoi(g2, 'tat-ca-du-no')
        ok('F3 .csv dư nợ vẫn nhận loại Dư nợ IPCAS', 'Dư nợ IPCAS' in kieu(pl2, 'msit80_31-10-2026.csv'), pl2)
        ok('F3b nạp .csv dư nợ == xlsx', M2 == M0, lech(M0, M2))
        b3, g3, pl3 = await nap(p, [dx, zp]); L3 = await luoi(g3, 'tai-san-bao-dam')
        ok('F4 .csv TSBĐ nằm trong .zip nhận loại Sao kê TSBĐ', 'Sao kê TSBĐ' in kieu(pl3, '18_08_2026-TS.csv'), pl3)
        ok('F4b nạp .csv TSBĐ từ .zip == xlsx', L3 == L0, lech(L0, L3) or ('bảng rỗng' if not L3 else ''))
        for g in (g0, g1, g2, g3): ok('F9 không lỗi JS', not g.errs, g.errs)
        for x in (b0, b1, b2, b3): await x.close()
    print(f'\n{sum(res)}/{len(res)} PASS'); sys.exit(0 if all(res) else 1)

asyncio.run(main())
