# -*- coding: utf-8 -*-
"""Bộ chạy hồi quy chung QLTDPRO (HM-01).

Chạy MỌI bộ kiểm hiện có (kiem_thu_p40…p53) trên MỘT bản HTML chỉ định, không sửa app, không sửa bộ kiểm.

Cách làm:
  1. Sao toàn bộ thư mục QLTDPRO_P43 sang một thư mục tạm (bản soi) -> bộ kiểm ghi tệp tạm cũng không chạm bản thật.
  2. Với mỗi bộ kiểm: tạo bản sao HTML dưới đúng tên bộ kiểm trỏ cứng
       - tên 'chinh'     -> bản ĐANG KIỂM (--app)
       - tên 'doi_chung' -> bản LIỀN TRƯỚC (--doi-chung, mặc định tự chọn bản số hiệu nhỏ hơn gần nhất trong app/)
     rồi chạy, thu từng dòng PASS/FAIL/SKIP, mã thoát, lỗi đầu tiên.
  3. Phân loại: PASS, FAIL, LECH_PB (FAIL ở ca đã khai báo là kiểm nhãn phiên bản cũ), SKIP (bộ kiểm tự báo bỏ qua),
     LOI (bộ kiểm dừng giữa chừng, không in kết quả), KHONG_CHAY (thiếu điều kiện, có lý do).
  4. Ghi báo cáo JSON + Markdown vào thư mục --ra (mặc định kiem_thu_chung/ket_qua/<phiên bản>/).

Dùng (từ app/QLTDPRO_P43/):
  python3 kiem_thu_chung/chay_hoi_quy.py                                  # bản mặc định app/QLTDPRO_v24.17.9.html
  python3 kiem_thu_chung/chay_hoi_quy.py --app app/QLTDPRO_v24.17.8.html  # bản khác
  python3 kiem_thu_chung/chay_hoi_quy.py --chi p53_khm,p41_lai_unit       # chỉ vài bộ
  python3 kiem_thu_chung/chay_hoi_quy.py --liet-ke                        # in danh mục, không chạy
Mã thoát: 0 khi không có FAIL/LOI; 1 nếu có.
"""
import argparse, hashlib, json, os, re, shutil, socket, subprocess, sys, tempfile, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent  # app/QLTDPRO_P43
DM = json.loads((HERE / 'danh_muc.json').read_text(encoding='utf-8'))
DONG = re.compile(r'^\s*(PASS|FAIL|SKIP)\b[\s:—-]*(.*)$')
PORT_RE = re.compile(r'PORT\s*=\s*(\d{4,5})')


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def so_hieu(name):
    m = re.search(r'v(\d+)\.(\d+)\.(\d+)', name)
    return tuple(int(x) for x in m.groups()) if m else None


def ban_lien_truoc(app_dir, target):
    t = so_hieu(target.name)
    cands = [(so_hieu(p.name), p) for p in app_dir.glob('QLTDPRO_v*.html') if so_hieu(p.name) and so_hieu(p.name) < t]
    return max(cands)[1] if cands else None


def cong_ban(port):
    s = socket.socket()
    try:
        return s.connect_ex(('127.0.0.1', port)) == 0
    finally:
        s.close()


def chuan_bi(soi):
    """Sinh dữ liệu thử còn thiếu bằng trình sinh có sẵn của dự án, chạy trên BẢN SAO riêng, chỉ chép thư mục còn thiếu vào bản soi."""
    for cb in DM.get('chuan_bi', []):
        gen, can, dong_bo = cb['sinh'], cb['khi_thieu'], cb['dong_bo']
        if (soi / can).exists():
            continue
        tam = Path(tempfile.mkdtemp(prefix='qltd_sinh_')) / 'g'
        shutil.copytree((soi / gen).parent, tam)
        r = subprocess.run([sys.executable, str(tam / Path(gen).name)], cwd=str(tam), capture_output=True, text=True)
        if r.returncode != 0:
            print(f'Chuẩn bị: KHÔNG sinh được {can} ({r.stderr.strip()[-200:]})')
        else:
            for tm in dong_bo:  # chép CÙNG LÚC mọi thư mục do trình sinh tạo để dữ liệu nhất quán byte (zip chứa đúng xlsx)
                dich = soi / Path(gen).parent / tm
                if dich.exists(): shutil.rmtree(dich)
                shutil.copytree(tam / tm, dich)
            print(f'Chuẩn bị: sinh {", ".join(dong_bo)} bằng {gen} (trên bản soi)')
        shutil.rmtree(tam.parent, ignore_errors=True)


def chay_mot(bk, soi, app, doi, args):
    kq = {'id': bk['id'], 'tep': bk['tep'], 'pass': 0, 'fail': 0, 'lech_pb': 0, 'skip': 0,
          'trang_thai': '', 'ly_do': '', 'ca_fail': [], 'ca_lech_pb': [], 'ca_skip': [], 'giay': 0, 'ma_thoat': None,
          'bi_danh': {}, 'ly_do_lech_pb': bk.get('ly_do_lech_pb', '')}
    if args.tu_log:
        lf = args.ra / 'log' / f"{bk['id']}.log"
        if not lf.exists():
            kq.update(trang_thai='KHONG_CHAY', ly_do='không có log của lần chạy trước'); return kq
        txt = lf.read_text(encoding='utf-8')
        head, _, body = txt.partition('\n# ma_thoat=')
        meta, _, rest = body.partition('\n')
        rc = None if meta.split()[0] == 'None' else int(meta.split()[0]); kq['giay'] = float(meta.split('giay=')[1])
        out, _, err = rest.partition('\n--- stderr ---\n')
        kq['ma_thoat'] = rc
        return phan_loai(bk, kq, out, err, rc)
    tep = soi / bk['tep']
    if not tep.exists():
        kq.update(trang_thai='KHONG_CHAY', ly_do='không thấy tệp bộ kiểm'); return kq
    src = tep.read_text(encoding='utf-8', errors='replace')
    m = PORT_RE.search(src)
    if m and cong_ban(int(m.group(1))):
        kq.update(trang_thai='KHONG_CHAY', ly_do=f'cổng {m.group(1)} đang bận'); return kq
    tao = []; tra = []
    for ten in bk.get('chinh', []):
        dst = soi / ten
        if dst.exists() and dst.resolve() == app.resolve():
            continue
        if dst.exists():  # tên trùng một bản thật trong BẢN SOI: cất tạm, chạy xong trả lại (bản thật ngoài bản soi không bị chạm)
            cat = dst.with_name(dst.name + '.cat_tam'); dst.rename(cat); tra.append((cat, dst))
        dst.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(app, dst); tao.append(dst)
        kq['bi_danh'][ten] = app.name
    for ten in bk.get('doi_chung', []):
        dst = soi / ten
        if doi is None:
            kq.update(trang_thai='KHONG_CHAY', ly_do=f'cần bản đối chứng cho {ten} nhưng không có bản liền trước'); break
        if not dst.exists():
            dst.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(doi, dst); tao.append(dst)
            kq['bi_danh'][ten] = doi.name + ' (đối chứng)'
    if kq['trang_thai']:
        for d in tao: d.unlink(missing_ok=True)
        for cat, dst in tra: cat.rename(dst)
        return kq
    if bk['loai'] == 'cjs':
        cmd = ['node', str(tep)]
    else:
        cmd = [sys.executable, str(tep)]
        if bk.get('doi_so') == 'ten':
            if app.parent.resolve() != (soi / 'app').resolve():
                dst = soi / 'app' / app.name; shutil.copyfile(app, dst); tao.append(dst)
            cmd.append(app.name)
        elif bk.get('doi_so') == 'duong_dan':
            cmd.append(str(soi / 'app' / app.name) if (soi / 'app' / app.name).exists() else str(app))
    env = dict(os.environ)
    env.setdefault('PLAYWRIGHT_BROWSERS_PATH', '/opt/pw-browsers')
    env['PYTHONUNBUFFERED'] = '1'
    if not args.co_reload: env.setdefault('QLTD_SKIP_RELOAD', '1')
    t0 = time.time()
    try:
        p = subprocess.run(cmd, cwd=str(soi), env=env, capture_output=True, text=True, timeout=args.timeout)
        out, err, rc = p.stdout, p.stderr, p.returncode
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b'').decode('utf-8', 'replace') if isinstance(e.stdout, bytes) else (e.stdout or '')
        err, rc = f'quá thời gian {args.timeout}s', None
    kq['giay'] = round(time.time() - t0, 1); kq['ma_thoat'] = rc
    for d in tao: d.unlink(missing_ok=True)
    for cat, dst in tra: cat.rename(dst)
    (args.ra / 'log').mkdir(parents=True, exist_ok=True)
    (args.ra / 'log' / f"{bk['id']}.log").write_text(f"$ {' '.join(cmd)}\n# ma_thoat={rc} giay={kq['giay']}\n" + out + ('\n--- stderr ---\n' + err if err else ''), encoding='utf-8')
    return phan_loai(bk, kq, out, err, rc)


def phan_loai(bk, kq, out, err, rc):
    """Phân loại thuần từ đầu ra của bộ kiểm (dùng chung cho lần chạy và chế độ --tu-log)."""
    lech = [re.compile(x) for x in bk.get('lech_phien_ban', [])]
    for line in out.splitlines():
        mm = DONG.match(line)
        if not mm: continue
        loai, ten = mm.group(1), mm.group(2).strip()
        if loai == 'PASS': kq['pass'] += 1
        elif loai == 'SKIP': kq['skip'] += 1; kq['ca_skip'].append(ten[:300])
        elif any(r.search(ten) for r in lech): kq['lech_pb'] += 1; kq['ca_lech_pb'].append(ten[:300])
        else: kq['fail'] += 1; kq['ca_fail'].append(ten[:300])
    tong = kq['pass'] + kq['fail'] + kq['lech_pb'] + kq['skip']
    loi_dau = next((l for l in err.splitlines()[::-1] if l.strip()), '') if err else ''
    co_tb = 'Traceback (most recent call last)' in (err or '') or bool(re.search(r'^\S*Error: ', err or '', re.M) and rc)
    kq['dung_giua_chung'] = co_tb
    if rc is None:
        kq.update(trang_thai='LOI', ly_do=err)
    elif co_tb and not kq['fail'] and any(re.search(x, err or '') for x in bk.get('loi_moi_truong', [])):
        kq.update(trang_thai='LOI_MT', ly_do=f'môi trường: {bk.get("ly_do_loi_mt", "")} — dừng sau {tong} ca; ' + loi_dau[:200])
    elif co_tb and not kq['fail']:
        kq.update(trang_thai='LOI', ly_do=f'dừng giữa chừng sau {tong} ca (các ca sau không chạy); ' + loi_dau[:300])
    elif tong == 0:
        kq.update(trang_thai='LOI', ly_do='không in kết quả PASS/FAIL; ' + loi_dau[:300])
    elif rc != 0 and kq['fail'] == 0 and kq['lech_pb'] == 0:
        kq.update(trang_thai='LOI', ly_do=f'dừng giữa chừng (mã {rc}) sau {tong} ca; ' + loi_dau[:300])
    elif kq['fail']:
        kq['trang_thai'] = 'FAIL'
        if co_tb: kq['ly_do'] = f'có FAIL, rồi dừng giữa chừng sau {tong} ca; ' + loi_dau[:200]
    elif kq['lech_pb']:
        kq['trang_thai'] = 'LECH_PB'
    else:
        kq['trang_thai'] = 'PASS'
    return kq


def main():
    ap = argparse.ArgumentParser(description='Bộ chạy hồi quy chung QLTDPRO')
    ap.add_argument('--app', default='app/QLTDPRO_v24.17.9.html', help='bản HTML cần kiểm (đường dẫn, tương đối với QLTDPRO_P43/)')
    ap.add_argument('--doi-chung', default='', help='bản đối chứng (mặc định: bản liền trước trong app/)')
    ap.add_argument('--chi', default='', help='chỉ chạy các id, phân cách bằng dấu phẩy')
    ap.add_argument('--bo', default='', help='bỏ các id, phân cách bằng dấu phẩy')
    ap.add_argument('--timeout', type=int, default=900, help='giới hạn giây cho mỗi bộ kiểm')
    ap.add_argument('--ra', default='', help='thư mục ghi báo cáo')
    ap.add_argument('--liet-ke', action='store_true')
    ap.add_argument('--tu-log', action='store_true', help='không chạy lại: phân loại lại từ log lần chạy trước (sau khi cập nhật danh_muc.json)')
    ap.add_argument('--co-reload', action='store_true', help='không đặt QLTD_SKIP_RELOAD=1 (mặc định đặt: Chromium container sập khi tải lại trang có handle thư mục, xem bàn giao P42)')
    args = ap.parse_args()
    ds = DM['bo_kiem']
    if args.chi: ds = [b for b in ds if b['id'] in args.chi.split(',')]
    if args.bo: ds = [b for b in ds if b['id'] not in args.bo.split(',')]
    if args.liet_ke:
        for b in ds: print(f"{b['id']:18} {b['tep']:45} chính={b.get('chinh')} đối chứng={b.get('doi_chung')}")
        return 0
    app = (ROOT / args.app).resolve() if not Path(args.app).is_absolute() else Path(args.app)
    if not app.exists():
        print('Không thấy bản app:', app); return 2
    doi = Path(args.doi_chung).resolve() if args.doi_chung else ban_lien_truoc(ROOT / 'app', app)
    ver = '.'.join(map(str, so_hieu(app.name) or ('?',)))
    args.ra = Path(args.ra).resolve() if args.ra else HERE / 'ket_qua' / ('v' + ver)
    if args.tu_log:
        if not (args.ra / 'log').exists():
            print('Không có log để phân loại lại:', args.ra); return 2
    else:
        if args.ra.exists(): shutil.rmtree(args.ra)
        args.ra.mkdir(parents=True)
    sha_truoc = sha(app)
    tmp = Path(tempfile.mkdtemp(prefix='qltd_soi_'))
    soi = tmp / 'QLTDPRO_P43'
    if not args.tu_log:
        shutil.copytree(ROOT, soi, ignore=shutil.ignore_patterns('ket_qua', '__pycache__'))
        chuan_bi(soi)
    else:
        (soi / 'app').mkdir(parents=True)
    soi_app = soi / 'app' / app.name
    if not soi_app.exists() and not args.tu_log: shutil.copyfile(app, soi_app)
    soi_doi = (soi / 'app' / doi.name) if doi and (soi / 'app' / doi.name).exists() else doi
    print(f'Bản kiểm: {app.name} (sha256 {sha_truoc[:12]}…) | đối chứng: {doi.name if doi else "không có"} | {len(ds)} bộ kiểm')
    kqs = []
    try:
        for bk in ds:
            print(f"▶ {bk['id']} …", flush=True)
            k = chay_mot(bk, soi, soi_app, soi_doi, args); kqs.append(k)
            print(f"  {k['trang_thai']:10} pass {k['pass']} · fail {k['fail']} · lệch PB {k['lech_pb']} · skip {k['skip']} · {k['giay']}s"
                  + (f" — {k['ly_do'][:200]}" if k['ly_do'] else ''), flush=True)
            for c in k['ca_fail'][:5]: print('    FAIL', c[:200])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    sha_sau = sha(app)
    T = {x: sum(k[x] for k in kqs) for x in ('pass', 'fail', 'lech_pb', 'skip')}
    bao = {'che_do': 'phân loại lại từ log' if args.tu_log else 'chạy thật', 'ban_kiem': app.name, 'sha256': sha_truoc, 'app_khong_doi': sha_truoc == sha_sau,
           'doi_chung': doi.name if doi else None, 'thoi_diem': time.strftime('%Y-%m-%d %H:%M:%S'),
           'tong': T, 'bo_kiem': kqs,
           'dem_trang_thai': {s: sum(1 for k in kqs if k['trang_thai'] == s) for s in ('PASS', 'FAIL', 'LECH_PB', 'LOI', 'LOI_MT', 'KHONG_CHAY')}}
    (args.ra / 'ket_qua.json').write_text(json.dumps(bao, ensure_ascii=False, indent=1), encoding='utf-8')
    md = [f"# Hồi quy chung — {app.name}", '',
          f"sha256 `{sha_truoc}` · app không đổi sau khi chạy: **{'có' if bao['app_khong_doi'] else 'KHÔNG'}** · đối chứng: {bao['doi_chung']} · {bao['thoi_diem']}", '',
          f"**Tổng ca:** PASS {T['pass']} · FAIL {T['fail']} · LỆCH PB {T['lech_pb']} · SKIP {T['skip']}", '',
          '| Bộ kiểm | Trạng thái | Pass | Fail | Lệch PB | Skip | Giây | Ghi chú |', '|---|---|---|---|---|---|---|---|']
    for k in kqs:
        note = k['ly_do'] or '; '.join(k['ca_fail'][:3])
        md.append(f"| {k['id']} | {k['trang_thai']} | {k['pass']} | {k['fail']} | {k['lech_pb']} | {k['skip']} | {k['giay']} | {note[:220].replace('|', '/')} |")
    md += ['', '## Ca LỆCH PB (FAIL do kiểm nhãn/giao diện gắn bản cũ — đã phân loại, KHÔNG tính PASS)']
    for k in kqs:
        for c in k['ca_lech_pb']: md.append(f"- **{k['id']}** · {c[:160]}")
        if k['ca_lech_pb']: md.append(f"  - Lý do: {k['ly_do_lech_pb']}")
    md += ['', '## Ca FAIL / bộ kiểm dừng (cần xem)']
    for k in kqs:
        if k['trang_thai'] in ('FAIL', 'LOI', 'LOI_MT', 'KHONG_CHAY'):
            md.append(f"- **{k['id']}** [{k['trang_thai']}] {k['ly_do'][:300]}")
            for c in k['ca_fail']: md.append(f"  - FAIL {c[:300]}")
    (args.ra / 'BAO_CAO.md').write_text('\n'.join(md) + '\n', encoding='utf-8')
    print(f"\nTỔNG: PASS {T['pass']} · FAIL {T['fail']} · LỆCH PB {T['lech_pb']} · SKIP {T['skip']} | bộ kiểm: {bao['dem_trang_thai']}")
    print(f"App không đổi: {bao['app_khong_doi']} | Báo cáo: {args.ra}")
    bad = T['fail'] or bao['dem_trang_thai']['LOI'] or not bao['app_khong_doi']
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
