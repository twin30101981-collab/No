# Hồi quy chung — QLTDPRO_v24.17.16.html

sha256 `3a1eff3f06587db5a12395c465884341adbb172b0a2945a0fd0884659d1f9c2e` · app không đổi sau khi chạy: **có** · đối chứng: QLTDPRO_v24.17.15.html · 2026-11-05 16:02:01

**Tổng ca:** PASS 56 · FAIL 0 · LỆCH PB 0 · SKIP 0

| Bộ kiểm | Trạng thái | Pass | Fail | Lệch PB | Skip | Giây | Ghi chú |
|---|---|---|---|---|---|---|---|
| p03_hm17 | PASS | 5 | 0 | 0 | 0 | 30.9 |  |
| p04_hm12 | PASS | 28 | 0 | 0 | 0 | 76.0 |  |
| p04_hm18 | PASS | 23 | 0 | 0 | 0 | 91.0 |  |

## Ca LỆCH PB (FAIL do kiểm nhãn/giao diện gắn bản cũ — đã phân loại, KHÔNG tính PASS)

## Ca FAIL / bộ kiểm dừng (cần xem)
