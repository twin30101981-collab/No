# P02 · HM-15 · v24.17.11 — Sửa gốc rễ: tệp sao kê TSBĐ đuôi .csv bị trang Nhập dữ liệu nhận nhầm loại "Dư nợ IPCAS".
# Gốc rễ: khi thêm tệp, app nhận loại theo TÊN (hub.kind: .xls/.xlsx/.xlsm/.csv; tên không có "tai san/tsbd/sao ke" -> "duno"),
#   rồi DÒ TIÊU ĐỀ (hub.sniffKind: có clno + clcustno/plgcustno -> "tsbd") để sửa loại. Bước dò tiêu đề chỉ chạy với
#   /\.(xls|xlsx|xlsm)$/i nên tệp .csv không bao giờ được dò -> giữ "duno" sai. Hậu quả: sao kê TSBĐ .csv bị nhập như dư nợ.
# Cách sửa (một điểm): cho bước dò tiêu đề chạy cả với .csv (cùng danh sách đuôi mà hub.kind chấp nhận).
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P02/build_p02_hm15.py
SRC='app/QLTDPRO_v24.17.10.html'; DST='app/QLTDPRO_v24.17.11.html'
s=open(SRC,encoding='utf-8').read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n,('anchor count',c,n,old[:90]); s=s.replace(old,new)
rep('ne.forEach(se=>{/\\.(xls|xlsx|xlsm)$/i.test(se.file.name)&&se.file.arrayBuffer().then(pe=>Zh(pe,2,!0))',
    'ne.forEach(se=>{/\\.(xls|xlsx|xlsm|csv)$/i.test(se.file.name)&&se.file.arrayBuffer().then(pe=>Zh(pe,2,!0))')
rep('24.17.10','24.17.11',2)
open(DST,'w',encoding='utf-8').write(s)
for f in ('app/sw.js','app/manifest.json'):
    t=open(f,encoding='utf-8').read().replace('24.17.10','24.17.11')
    open(f,'w',encoding='utf-8').write(t)
print('OK',DST)
