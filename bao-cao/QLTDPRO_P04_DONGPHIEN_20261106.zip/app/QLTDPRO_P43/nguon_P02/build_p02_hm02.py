# P02 · HM-02 · v24.17.10 — Sửa gốc rễ: nạp sao kê TSBĐ dạng VĂN BẢN (CSV mang đuôi .xls) đảo ngày dd/mm ≤ 12 và mất số 0 đầu.
# Gốc rễ (cùng cơ chế P53, khác đường đọc): thao tác worker "aoa" (dùng cho mọi lần nạp TSBĐ: trang Nhập dữ liệu và
#   trang Tài sản bảo đảm) gọi XLSX.read(...) với cellDates:true và KHÔNG có raw:true. SheetJS đọc văn bản CSV thì đoán
#   kiểu ô theo lịch Mỹ: "02/06/2025" -> 06/02/2025; chuỗi số "0123.002" -> số 123.002.
# Cách sửa (một điểm, tối thiểu): thêm raw:!0 vào XLSX.read của "aoa". raw chỉ tác động tới văn bản (CSV/HTML/SYLK);
#   tệp .xlsx/.xls nhị phân đọc ô theo kiểu lưu trong tệp nên KHÔNG đổi hành vi (bộ kiểm HM-02 đối chứng xlsx).
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P02/build_p02_hm02.py
SRC='app/QLTDPRO_v24.17.9.html'; DST='app/QLTDPRO_v24.17.10.html'
s=open(SRC,encoding='utf-8').read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n,('anchor count',c,n,old[:90]); s=s.replace(old,new)
rep('r.aoa=function(a,i){var s=a.read(i,{type:"array",cellDates:!0,dense:!0,cellText:!1})',
    'r.aoa=function(a,i){var s=a.read(i,{type:"array",cellDates:!0,dense:!0,cellText:!1,raw:!0})')
rep('24.17.9','24.17.10',2)
open(DST,'w',encoding='utf-8').write(s)
for f in ('app/sw.js','app/manifest.json'):
    t=open(f,encoding='utf-8').read()
    t=t.replace('24.17.9','24.17.10').replace('qltdpro-p53-','qltdpro-p02-')
    open(f,'w',encoding='utf-8').write(t)
print('OK',DST)
