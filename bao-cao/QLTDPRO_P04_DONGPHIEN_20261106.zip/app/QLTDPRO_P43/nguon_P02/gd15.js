/* gd15 (P03 · HM-11b) — Trang Khách hàng mới, tab Đối soát: bảng Phòng → Cán bộ theo KHẾ ƯỚC (lõi QLTD_DSTN),
   nối MỌI mốc dư nợ trong Lưu trữ từ mốc đầu kỳ đến mốc cuối kỳ đã chọn ở khối "Nạp từ Lưu trữ" (gd11).
   Thay bảng "Thu nợ suy ra" (GN − Δ dư nợ theo phòng) — bảng cũ vẫn xem được bằng nút "Xem bảng cũ".
   Không đổi schema: chỉ ĐỌC localStorage _archiveReportList + IndexedDB TWIN_Archive_v1/reportData qua API gd11.
   Không mạng, không eval. Kết quả để HM-12 dùng: window.__khmDstn (R của QLTD_DSTN.tinh, kèm danh sách mốc). */
(function(){
if(window.__gd15)return; window.__gd15=true;
var PB='P04-GD15 1.3.0'; /* 1.1.0 (HM-16): gộp dòng dư nợ 0 của mốc (kho phụ rpt0_) · 1.2.0 (HM-12): ô bấm → chi tiết khế ước, lọc Phòng/Cán bộ, xuất Excel */
function api(){return window.__gd11Api||null}
function core(){return window.QLTD_DSTN||null}
function E(tag,cls,text){var e=document.createElement(tag);if(cls)e.className=cls;if(text!=null)e.textContent=text;return e}
function fmt(v){var n=Math.round(+v||0);return n.toLocaleString('vi-VN')}
function vn(iso){var m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(iso||'');return m?m[3]+'/'+m[2]+'/'+m[1]:String(iso||'')}
function daysBetween(a,b){return Math.round((Date.parse(b+'T00:00:00Z')-Date.parse(a+'T00:00:00Z'))/864e5)}

/* Chọn chuỗi mốc: đúng bản đầu kỳ + cuối kỳ người dùng chọn; mỗi ngày ở giữa lấy bản lưu mới nhất. */
function chonMoc(A,tsD,tsC){
  var all=A.arcList(),md=null,mc=null;
  all.forEach(function(m){var t=String(m.timestamp||'');if(t===tsD)md=m;if(t===tsC)mc=m});
  if(!md||!mc)return{loi:'Không tìm thấy mốc đầu/cuối kỳ trong Lưu trữ.'};
  var isoD=A.vnToIso(md.dayKey||''),isoC=A.vnToIso(mc.dayKey||'');
  if(!isoD||!isoC)return{loi:'Mốc Lưu trữ không có ngày (dayKey) — không xếp được chuỗi mốc.'};
  if(isoD>=isoC)return{loi:'Mốc đầu kỳ phải trước mốc cuối kỳ.'};
  var byDay={};
  all.forEach(function(m){var d=A.vnToIso(m.dayKey||'');if(!d||d<=isoD||d>=isoC)return;
    if(!byDay[d]||(m.timestamp||0)>(byDay[d].timestamp||0))byDay[d]=m});
  var ds=[{ngay:isoD,meta:md}];
  Object.keys(byDay).sort().forEach(function(d){ds.push({ngay:d,meta:byDay[d]})});
  ds.push({ngay:isoC,meta:mc});
  return{mocs:ds,isoD:isoD,isoC:isoC};
}
function canhBaoMoc(mocs){
  var w=[];
  if(mocs.length===2)w.push('Chỉ có 2 mốc (đầu kỳ, cuối kỳ): khoản giải ngân rồi tất toán ngay trong kỳ sẽ KHÔNG thấy, thu nợ/GN có thể thiếu. Lưu thêm mốc cuối tháng (hoặc hằng ngày) trong kỳ ở Lưu trữ.');
  for(var i=1;i<mocs.length;i++){var g=daysBetween(mocs[i-1].ngay,mocs[i].ngay);
    if(g>31)w.push('Khoảng '+vn(mocs[i-1].ngay)+' → '+vn(mocs[i].ngay)+' dài '+g+' ngày: thiếu mốc giữa kỳ.')}
  return w;
}
function tinhDstn(A,C,sel){
  return sel.mocs.reduce(function(p,m){return p.then(function(acc){
    return Promise.all([A.loadArcRows(m.meta),A.loadZeroRows?A.loadZeroRows(m.meta).catch(function(){return null}):Promise.resolve(null)]).then(function(x){
      var rows=x[0],zero=x[1];
      if(!rows||!rows.length)throw new Error('Mốc '+vn(m.ngay)+' không còn dữ liệu dòng trong Lưu trữ.');
      if(!Array.isArray(zero))acc.thieu0.push(m.ngay);
      var raw=rows.concat(Array.isArray(zero)?zero:[]),obj=A.dunoToObjects(raw);
      obj.forEach(function(o,i){var r=raw[i]||[];o.__lst=r[26]==null?'':String(r[26]).trim()}); /* HM-12: lstrpmtdt = cột 26 dòng Lưu trữ */
      acc.push({ngay:m.ngay,rows:obj.filter(function(o){return String(o.dsbsseq||o.brcd||'').trim()!==''})});return acc;
    });
  })},Promise.resolve(Object.assign([],{thieu0:[]}))).then(function(mocs){var R=C.tinh(mocs.slice());R.thieu0=mocs.thieu0;boSung(R,mocs,sel);return R});
}

/* ========== HM-12 (1.2.0) ==========
   Bổ sung mỗi khế ước: ngày trả gần nhất (lstrpmtdt ở mốc gần nhất có ghi), mốc xuất hiện đầu/cuối, nguồn mốc.
   Khóa giống lõi (dsbsseq; thiếu thì brcd|apprseq|dsbsseq). KHÔNG đổi số liệu lõi. */
function khoa(o){var q=String(o.dsbsseq==null?'':o.dsbsseq).trim();return q||(String(o.brcd||'').trim()+'|'+String(o.apprseq||'').trim()+'|'+q)}
function boSung(R,mocs,sel){
  var info=new Map();
  mocs.forEach(function(m){m.rows.forEach(function(o){var k=khoa(o),x=info.get(k);if(!x){x={dau:m.ngay,cuoi:m.ngay,lst:''};info.set(k,x)}x.cuoi=m.ngay;if(o.__lst)x.lst=o.__lst})});
  R.nguon=sel.mocs.map(function(m){return{ngay:m.ngay,ten:String(m.meta.name||m.meta.fileName||m.meta.dayKey||''),ts:String(m.meta.timestamp||'')}});
  R.khe.forEach(function(z){var x=info.get(z.key)||{};z.lstrpmtdt=x.lst||'';z.mocDau=x.dau||'';z.mocCuoi=x.cuoi||'';
    z.nguon='Lưu trữ: mốc '+vn(z.mocDau)+(z.mocCuoi&&z.mocCuoi!==z.mocDau?' → '+vn(z.mocCuoi):'')});
}
var DO={dauKy:'Dư nợ đầu',gnMon:'Số món GN',gn:'Giải ngân',thu:'Thu nợ',dieuChinh:'Điều chỉnh',cuoiKy:'Dư nợ cuối',soKhe:'Số khế ước',soTatToan:'Tất toán'};
var LOAI={gn:'gn',gnMon:'gn',thu:'thu',dieuChinh:'dc'};
var DEM={soKhe:1,soTatToan:1,gnMon:1};
function giaTri(z,k){return k==='soKhe'?1:k==='soTatToan'?(z.tatToan?1:0):k==='gnMon'?(z.gnMon||0):(+z[k]||0)}
function chon(z,k){return k==='soKhe'?true:giaTri(z,k)!==0}
function suKien(z,k){
  if(k==='dauKy')return 'số dư ở mốc đầu kỳ';
  if(k==='cuoiKy')return 'số dư ở mốc cuối kỳ';
  var l=LOAI[k],ev=(z.moc||[]).filter(function(e){return l?e.loai===l:true});
  if(k==='soTatToan')ev=(z.moc||[]).filter(function(e){return e.loai==='thu'&&/tất toán/.test(e.cach)});
  if(!ev.length)return (z.cachTinh||[]).join('; ')||'không phát sinh';
  return ev.map(function(e){return vn(e.tu)+'→'+vn(e.den)+': '+e.cach+' '+fmt(e.so)}).join('; ');
}
function locKhe(R,sc,ph,cb,k){
  return R.khe.filter(function(z){if(sc!=='tong'&&z.phong!==ph)return false;if(sc==='cb'&&z.cbMa!==cb)return false;return chon(z,k)})
    .sort(function(a,b){return giaTri(b,k)-giaTri(a,k)||String(a.custnm).localeCompare(String(b.custnm),'vi')});
}
var CT_COT=[['dsbsseq','Số khế ước'],['apprseq','Số HĐTD'],['maKH','Mã KH'],['custnm','Khách hàng'],['cbTen','Cán bộ'],['phong','Phòng'],['dsbsdt','Ngày GN'],['lstrpmtdt','Ngày trả gần nhất'],
  ['dauKy','Dư nợ đầu'],['gn','Giải ngân'],['thu','Thu nợ gốc'],['dieuChinh','Điều chỉnh'],['cuoiKy','Dư nợ cuối']];
var NUMK={dauKy:1,gn:1,thu:1,dieuChinh:1,cuoiKy:1};
function moCT(blk,R,sc,ph,cb,k,oVal){
  var old=blk.querySelector('[data-testid="khm-dstn-ct"]');if(old)old.remove();
  var ds=locKhe(R,sc,ph,cb,k),tong=ds.reduce(function(a,z){return a+giaTri(z,k)},0),lech=Math.round(tong)-Math.round(oVal);
  var cbT=sc==='cb'?((R.canBo.find(function(x){return x.phong===ph&&x.cbMa===cb})||{}).cbTen||cb):'';
  var pham=sc==='tong'?'Toàn chi nhánh':sc==='phong'?(ph||'(không ghi phòng)'):(ph||'(không ghi phòng)')+' / '+(cbT||'(không ghi cán bộ)');
  var box=E('div','gd15-ct');box.setAttribute('data-testid','khm-dstn-ct');box.setAttribute('data-k',k);box.setAttribute('data-sc',sc);
  var hd=E('div','gd15-ct-h');hd.appendChild(E('b',null,'🔎 '+DO[k]+' · '+pham));
  var xl=E('button','gd15-btn gd15-btn-p','⬇ Excel chi tiết');xl.type='button';xl.setAttribute('data-testid','khm-dstn-ct-xlsx');
  xl.addEventListener('click',function(){taiXlsx(tenTep('CHI_TIET_'+k+'_'+pham,R),[shCT(ds,k,'Chi tiết'),shGhiChu(R,DO[k]+' · '+pham+' · '+ds.length+' khế ước · tổng '+fmt(tong))])});
  var x=E('button','gd15-btn','✕ Đóng');x.type='button';x.setAttribute('data-testid','khm-dstn-ct-dong');x.addEventListener('click',function(){box.remove()});
  hd.appendChild(xl);hd.appendChild(x);box.appendChild(hd);
  var kt=E('div','gd15-ct-kt'+(lech?' gd15-err':''),(lech?'✗ ':'✓ ')+ds.length+' khế ước · Tổng chi tiết = '+fmt(tong)+' · Ô đã bấm = '+fmt(oVal)+' · Lệch '+fmt(lech));
  kt.setAttribute('data-testid','khm-dstn-ct-kt');kt.setAttribute('data-tong',String(Math.round(tong)));kt.setAttribute('data-o',String(Math.round(oVal)));kt.setAttribute('data-n',String(ds.length));box.appendChild(kt);
  var wrap=E('div','gd15-wrap gd15-ct-wrap'),tb=E('table','gd15-t gd15-ct-t');tb.setAttribute('data-testid','khm-dstn-ct-t');
  var hr=E('tr');hr.appendChild(E('th',null,'#'));CT_COT.forEach(function(c){hr.appendChild(E('th',c[0]===k||(k==='gnMon'&&c[0]==='gn')?'gd15-hl':null,c[1]))});
  hr.appendChild(E('th','gd15-hl','Giá trị ô'));hr.appendChild(E('th',null,'Cách đo (theo cặp mốc)'));hr.appendChild(E('th',null,'Gán cán bộ theo'));hr.appendChild(E('th',null,'Nguồn'));
  var th=E('thead');th.appendChild(hr);tb.appendChild(th);var bd=E('tbody');tb.appendChild(bd);
  var more=E('button','gd15-btn');more.type='button';more.setAttribute('data-testid','khm-dstn-ct-them');
  var shown=0,BUOC=300;
  function them(){
    var het=Math.min(ds.length,shown+BUOC);
    for(var i=shown;i<het;i++){var z=ds[i],tr=E('tr');tr.setAttribute('data-testid','khm-dstn-ct-row');tr.setAttribute('data-v',String(Math.round(giaTri(z,k))));
      tr.appendChild(E('td','gd15-n',String(i+1)));
      CT_COT.forEach(function(c){var v=z[c[0]];tr.appendChild(E('td',NUMK[c[0]]?'gd15-n':null,NUMK[c[0]]?fmt(v):(c[0]==='dsbsdt'?vn(v):String(v==null?'':v))))});
      tr.appendChild(E('td','gd15-n gd15-hl',DEM[k]?String(giaTri(z,k)):fmt(giaTri(z,k))));
      tr.appendChild(E('td','gd15-wr',suKien(z,k)));tr.appendChild(E('td','gd15-wr',z.gan||''));tr.appendChild(E('td',null,z.nguon||''));bd.appendChild(tr)}
    shown=het;more.hidden=shown>=ds.length;more.textContent='Hiện thêm ('+(ds.length-shown)+' khế ước còn lại)';
  }
  more.addEventListener('click',them);
  var tf=E('tfoot'),fr=E('tr','gd15-tong');fr.appendChild(E('td',null,''));
  CT_COT.forEach(function(c,i){fr.appendChild(E('td',NUMK[c[0]]?'gd15-n':null,i===0?'Tổng ('+ds.length+')':NUMK[c[0]]?fmt(ds.reduce(function(a,z){return a+(+z[c[0]]||0)},0)):''))});
  var ft=E('td','gd15-n gd15-hl',DEM[k]?String(tong):fmt(tong));ft.setAttribute('data-testid','khm-dstn-ct-tong');ft.setAttribute('data-v',String(Math.round(tong)));fr.appendChild(ft);
  fr.appendChild(E('td',null,''));fr.appendChild(E('td',null,''));fr.appendChild(E('td',null,''));tf.appendChild(fr);tb.appendChild(tf);
  wrap.appendChild(tb);box.appendChild(wrap);box.appendChild(more);
  them();
  box.appendChild(E('div','gd15-note','Mốc Lưu trữ là số dư theo ngày, không phải nhật ký giao dịch: GN/thu nợ ghi theo từng cặp mốc liền nhau (mỗi mốc một lần chênh). "Ngày trả gần nhất" = cột lstrpmtdt ở mốc gần nhất có ghi. Tổng chi tiết luôn tính trên TOÀN BỘ khế ước, kể cả phần chưa hiện.'));
  var tbl=blk.querySelector('[data-testid="khm-dstn-t"]'),w0=tbl&&tbl.closest('.gd15-wrap');
  if(w0&&w0.parentNode)w0.parentNode.insertBefore(box,w0.nextSibling);else blk.appendChild(box);
  try{box.scrollIntoView({block:'nearest'})}catch(_){}
  return box;
}
/* ---------- Excel .xlsx tự dựng (ZIP không nén + CRC32), không thư viện, không mạng ---------- */
var CRC=(function(){var t=[],c,n,k;for(n=0;n<256;n++){c=n;for(k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0}return t})();
function crc32(u){var c=0xFFFFFFFF;for(var i=0;i<u.length;i++)c=CRC[(c^u[i])&255]^(c>>>8);return (c^0xFFFFFFFF)>>>0}
function zip(files){
  var te=new TextEncoder(),parts=[],cen=[],off=0,cs=0;
  function u16(v){return [v&255,(v>>>8)&255]}function u32(v){return [v&255,(v>>>8)&255,(v>>>16)&255,(v>>>24)&255]}
  files.forEach(function(f){var nm=te.encode(f[0]),d=te.encode(f[1]),cr=crc32(d);
    var lh=new Uint8Array([].concat(u32(0x04034b50),u16(20),u16(0x800),u16(0),u16(0),u16(0x21),u32(cr),u32(d.length),u32(d.length),u16(nm.length),u16(0)));
    parts.push(lh,nm,d);
    var ch=new Uint8Array([].concat(u32(0x02014b50),u16(20),u16(20),u16(0x800),u16(0),u16(0),u16(0x21),u32(cr),u32(d.length),u32(d.length),u16(nm.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(off)));
    cen.push(ch,nm);cs+=ch.length+nm.length;off+=lh.length+nm.length+d.length});
  var end=new Uint8Array([].concat(u32(0x06054b50),u16(0),u16(0),u16(files.length),u16(files.length),u32(cs),u32(off),u16(0)));
  return new Blob(parts.concat(cen,[end]),{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
}
function xe(s){return String(s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]}).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g,'')}
function colL(i){var s='';i++;while(i>0){var m=(i-1)%26;s=String.fromCharCode(65+m)+s;i=Math.floor((i-1)/26)}return s}
function sheetXml(rows){
  var w=[];rows.slice(0,400).forEach(function(r){r.forEach(function(v,i){var l=v==null?0:String(typeof v==='number'?fmt(v):v).length;w[i]=Math.max(w[i]||8,Math.min(60,l+2))})});
  var x='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>';
  w.forEach(function(v,i){x+='<col min="'+(i+1)+'" max="'+(i+1)+'" width="'+v+'" customWidth="1"/>'});x+='</cols><sheetData>';
  rows.forEach(function(r,ri){x+='<row r="'+(ri+1)+'">';r.forEach(function(v,ci){var ref=colL(ci)+(ri+1);
    if(typeof v==='number'&&isFinite(v))x+='<c r="'+ref+'" s="'+(ri===0?2:1)+'"><v>'+Math.round(v)+'</v></c>';
    else if(v!=null&&v!=='')x+='<c r="'+ref+'" t="inlineStr"'+(ri===0?' s="2"':'')+'><is><t xml:space="preserve">'+xe(v)+'</t></is></c>'});x+='</row>'});
  return x+'</sheetData></worksheet>';
}
function xlsx(sheets){
  var f=[],wb='',rel='',ct='',X='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n',NS='http://schemas.openxmlformats.org/';
  sheets.forEach(function(s,i){var n=i+1;f.push(['xl/worksheets/sheet'+n+'.xml',sheetXml(s.rows)]);
    wb+='<sheet name="'+xe(String(s.name).replace(/[\[\]:*?\/\\]/g,' ').slice(0,31))+'" sheetId="'+n+'" r:id="rId'+n+'"/>';
    rel+='<Relationship Id="rId'+n+'" Type="'+NS+'officeDocument/2006/relationships/worksheet" Target="worksheets/sheet'+n+'.xml"/>';
    ct+='<Override PartName="/xl/worksheets/sheet'+n+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'});
  var N=sheets.length+1;
  return zip([['[Content_Types].xml',X+'<Types xmlns="'+NS+'package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'+ct+'</Types>'],
    ['_rels/.rels',X+'<Relationships xmlns="'+NS+'package/2006/relationships"><Relationship Id="rId1" Type="'+NS+'officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
    ['xl/workbook.xml',X+'<workbook xmlns="'+NS+'spreadsheetml/2006/main" xmlns:r="'+NS+'officeDocument/2006/relationships"><sheets>'+wb+'</sheets></workbook>'],
    ['xl/_rels/workbook.xml.rels',X+'<Relationships xmlns="'+NS+'package/2006/relationships">'+rel+'<Relationship Id="rId'+N+'" Type="'+NS+'officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'],
    ['xl/styles.xml',X+'<styleSheet xmlns="'+NS+'spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0"/></numFmts><fonts count="2"><font><sz val="11"/><name val="Times New Roman"/></font><font><b/><sz val="11"/><name val="Times New Roman"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="164" fontId="1" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1"/></cellXfs></styleSheet>']].concat(f));
}
function bo(s){return String(s||'').normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').replace(/[^A-Za-z0-9]+/g,'_').replace(/^_|_$/g,'').slice(0,60)}
function tenTep(goc,R){return bo(goc)+'_'+vn(R.dauKy).replace(/\//g,'.')+'_'+vn(R.cuoiKy).replace(/\//g,'.')+'.xlsx'}
window.__gd15TaiXlsx=function(t,s){return taiXlsx(t,s)}; /* P04 HM-23: dùng chung bộ ghi .xlsx */
function taiXlsx(ten,sheets){var b=xlsx(sheets);window.__gd15LastXlsx={ten:ten,size:b.size};var a=document.createElement('a'),u=URL.createObjectURL(b);a.href=u;a.download=ten;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(u);a.remove()},1500)}
var SO=[['dauKy','Dư nợ đầu kỳ'],['gn','Doanh số GN'],['gnMon','Số món GN'],['thu','Thu nợ gốc'],['dieuChinh','Điều chỉnh'],['cuoiKy','Dư nợ cuối kỳ'],['kiemTra','Kiểm tra (=0)']];
function shPhong(R){var r=[['Phòng'].concat(SO.map(function(c){return c[1]}),['Số khế ước','Số tất toán'])];
  function d(t,x){return [t].concat(SO.map(function(c){return +x[c[0]]||0}),[x.soKhe||0,x.soTatToan||0])}
  r.push(d('TOÀN CHI NHÁNH',R.tong));R.phong.slice().sort(function(a,b){return String(a.phong).localeCompare(String(b.phong),'vi')}).forEach(function(p){r.push(d(p.phong,p))});return{name:'Phòng',rows:r}}
function shCanBo(R){var r=[['Phòng','Mã CB','Cán bộ','Số khế ước','Số tất toán'].concat(SO.map(function(c){return c[1]}))];
  R.canBo.slice().sort(function(a,b){return String(a.phong).localeCompare(String(b.phong),'vi')||String(a.cbMa).localeCompare(String(b.cbMa),'vi')})
    .forEach(function(x){r.push([x.phong,x.cbMa,x.cbTen,x.soKhe,x.soTatToan].concat(SO.map(function(c){return +x[c[0]]||0})))});return{name:'Cán bộ',rows:r}}
function shCT(ds,k,ten){
  var r=[['Phòng','Mã CB','Cán bộ','Mã KH','Khách hàng','Số khế ước','Số HĐTD','Loại vay','Ngày GN','Ngày trả gần nhất','Dư nợ đầu kỳ','Doanh số GN','Số món GN','Thu nợ gốc','Điều chỉnh','Dư nợ cuối kỳ','Kiểm tra (=0)','Tất toán','Cách tính','Sự kiện theo mốc','Gán cán bộ theo','Nguồn'].concat(k?['Giá trị ô ('+DO[k]+')']:[])];
  var F=['dauKy','gn','gnMon','thu','dieuChinh','cuoiKy'],T={v:0};F.forEach(function(f){T[f]=0});
  ds.forEach(function(z){var kt=z.dauKy+z.gn-z.thu+z.dieuChinh-z.cuoiKy;F.forEach(function(f){T[f]+=+z[f]||0});
    var row=[z.phong,z.cbMa,z.cbTen,z.maKH,z.custnm,z.dsbsseq,z.apprseq,z.loai,vn(z.dsbsdt),z.lstrpmtdt||'',z.dauKy,z.gn,z.gnMon,z.thu,z.dieuChinh,z.cuoiKy,kt,z.tatToan?'x':'',(z.cachTinh||[]).join('; '),
      (z.moc||[]).map(function(e){return vn(e.tu)+'→'+vn(e.den)+' '+e.loai+' '+fmt(e.so)+' ('+e.cach+')'}).join('; '),z.gan||'',z.nguon||''];
    if(k){var v=giaTri(z,k);T.v+=v;row.push(v)}r.push(row)});
  var tr=['TỔNG ('+ds.length+' khế ước)','','','','','','','','','',T.dauKy,T.gn,T.gnMon,T.thu,T.dieuChinh,T.cuoiKy,T.dauKy+T.gn-T.thu+T.dieuChinh-T.cuoiKy,'','','','',''];if(k)tr.push(T.v);r.push(tr);
  return{name:ten,rows:r};
}
function shGhiChu(R,pham){
  var r=[['Ghi chú']];
  r.push(['Công cụ: QLTDPRO '+PB+' · lõi '+(R.phienBan||'')+' · lập lúc '+new Date().toLocaleString('vi-VN')]);
  if(pham)r.push(['Phạm vi: '+pham]);
  r.push(['Kỳ: '+vn(R.dauKy)+' → '+vn(R.cuoiKy)+' · '+(R.nguon||[]).length+' mốc Lưu trữ:']);
  (R.nguon||[]).forEach(function(m){r.push(['  • '+vn(m.ngay)+(m.ten?' — '+m.ten:'')+(m.ts?' (lưu '+m.ts+')':'')])});
  ['Thu nợ = toàn bộ phần giảm dư nợ gốc từng khế ước giữa hai mốc liền nhau (Q6); rpmtamt của msit80 = 0 nên không dùng (Q4).',
   'Khế ước tất toán gán cho cán bộ cuối kỳ của khách hàng; khách hết dư nợ → cán bộ ở mốc cuối cùng khế ước còn dư nợ (Q5, như lõi 1.0.1).',
   'Kiểm tra = Dư nợ đầu + GN − Thu nợ + Điều chỉnh − Dư nợ cuối (phải = 0) ở mọi dòng.',
   'Mốc Lưu trữ là số dư theo ngày, không phải nhật ký giao dịch: chi tiết "từng lần trả" chính xác đến mức mốc có sẵn. Ngày trả gần nhất = cột lstrpmtdt ở mốc gần nhất có ghi (mốc nhập bằng bản cũ có thể trống).',
   'Đối chiếu báo cáo IPCAS: lọc cột Phòng / Cán bộ ở sheet chi tiết; tổng cột số = ô tương ứng ở sheet Phòng / Cán bộ.'].forEach(function(t){r.push([t])});
  if(R.thieu0&&R.thieu0.length)r.push(['⚠ '+R.thieu0.length+' mốc nhập trước v24.17.14 không lưu khế ước dư nợ 0: '+R.thieu0.map(vn).join(', ')+' — nhập lại các tệp đó.']);
  return{name:'Ghi chú',rows:r};
}
function xuatTatCa(R){taiXlsx(tenTep('DOI_SOAT_DSTN',R),[shPhong(R),shCanBo(R),shCT(R.khe.slice().sort(function(a,b){return String(a.phong).localeCompare(String(b.phong),'vi')||String(a.cbMa).localeCompare(String(b.cbMa),'vi')||String(a.custnm).localeCompare(String(b.custnm),'vi')}),null,'Chi tiết khế ước'),shGhiChu(R,'Toàn chi nhánh')])}
function kiem3(R){
  var F=['dauKy','gn','gnMon','thu','dieuChinh','cuoiKy','soKhe','soTatToan'],bad=[];
  F.forEach(function(f){var a=R.canBo.reduce(function(s,x){return s+(+x[f]||0)},0),b=R.phong.reduce(function(s,x){return s+(+x[f]||0)},0),t=+R.tong[f]||0;
    if(Math.round(a)!==Math.round(t)||Math.round(b)!==Math.round(t))bad.push(DO[f]+': cán bộ '+fmt(a)+' · phòng '+fmt(b)+' · chi nhánh '+fmt(t))});
  R.phong.forEach(function(p){F.forEach(function(f){var a=R.canBo.filter(function(c){return c.phong===p.phong}).reduce(function(s,x){return s+(+x[f]||0)},0);
    if(Math.round(a)!==Math.round(+p[f]||0))bad.push(p.phong+' · '+DO[f]+': Σ cán bộ '+fmt(a)+' ≠ phòng '+fmt(p[f]))})});
  return bad;
}
function locBar(blk,R){
  var bar=E('div','gd15-loc');bar.setAttribute('data-testid','khm-dstn-loc');
  var sp=E('select');sp.setAttribute('data-testid','khm-dstn-loc-phong');sp.setAttribute('aria-label','Lọc phòng');
  var sc=E('select');sc.setAttribute('data-testid','khm-dstn-loc-cb');sc.setAttribute('aria-label','Lọc cán bộ');
  function opt(s,v,t){var o=E('option',null,t);o.value=v;s.appendChild(o)}
  opt(sp,'','Tất cả phòng');R.phong.map(function(p){return p.phong}).sort(function(a,b){return String(a).localeCompare(String(b),'vi')}).forEach(function(p){opt(sp,p,p||'(không ghi phòng)')});
  function napCb(){sc.innerHTML='';opt(sc,'','Tất cả cán bộ');R.canBo.filter(function(c){return !sp.value||c.phong===sp.value})
    .sort(function(a,b){return String(a.cbTen||a.cbMa).localeCompare(String(b.cbTen||b.cbMa),'vi')}).forEach(function(c){opt(sc,c.phong+'\u0001'+c.cbMa,(c.cbTen||c.cbMa||'(không ghi cán bộ)')+(sp.value?'':' · '+c.phong))})}
  function ap(){var ph=sp.value,cv=sc.value?sc.value.split('\u0001'):null;
    blk.querySelectorAll('[data-testid="khm-dstn-phong"]').forEach(function(tr){var p=tr.getAttribute('data-phong');tr.hidden=!!(ph&&p!==ph)||!!(cv&&p!==cv[0])});
    blk.querySelectorAll('[data-testid="khm-dstn-cb"]').forEach(function(tr){var p=tr.getAttribute('data-phong');tr.hidden=!!(ph&&p!==ph)||!!(cv&&(p!==cv[0]||tr.getAttribute('data-cbma')!==cv[1]))});
    blk.querySelectorAll('.gd15-tg').forEach(function(b){b.setAttribute('aria-expanded','true');b.textContent='▾'})}
  sp.addEventListener('change',function(){napCb();ap()});sc.addEventListener('change',ap);napCb();
  bar.appendChild(E('span',null,'Lọc:'));bar.appendChild(sp);bar.appendChild(sc);
  var xl=E('button','gd15-btn gd15-btn-p','⬇ Xuất Excel đối soát (4 sheet)');xl.type='button';xl.setAttribute('data-testid','khm-dstn-xlsx');
  xl.addEventListener('click',function(){xuatTatCa(R)});bar.appendChild(xl);
  return bar;
}

/* ---------- hiển thị ---------- */
var COLS=[['dauKy','Dư nợ đầu'],['gnMon','Số món GN'],['gn','Giải ngân'],['thu','Thu nợ'],['dieuChinh','Điều chỉnh'],['cuoiKy','Dư nợ cuối'],['kiemTra','Kiểm tra'],['soKhe','Số khế ước'],['soTatToan','Tất toán']];
function rowEl(cls,tid,label,x,attrs){
  var tr=E('tr',cls);tr.setAttribute('data-testid',tid);
  for(var k in attrs)tr.setAttribute(k,attrs[k]);
  var th=E('td','gd15-lbl');th.appendChild(label);tr.appendChild(th);
  COLS.forEach(function(c){var v=x[c[0]]||0,td=E('td','gd15-n'+(c[0]==='kiemTra'&&Math.abs(v)>0.5?' gd15-bad':''),(c[0]==='gnMon'||c[0]==='soKhe'||c[0]==='soTatToan')?String(v):fmt(v));
    td.setAttribute('data-k',c[0]);td.setAttribute('data-v',String(Math.round(v)));
    if(c[0]!=='kiemTra'&&v){td.className+=' gd15-ck';td.tabIndex=0;td.setAttribute('role','button');td.title='Bấm xem chi tiết khế ước'}
    tr.appendChild(td)});
  return tr;
}
function renderBang(R,mocs){
  var wrap=E('div','gd15-wrap'),tb=E('table','gd15-t');tb.setAttribute('data-testid','khm-dstn-t');
  var th=E('thead'),hr=E('tr');hr.appendChild(E('th',null,'Phòng / Cán bộ'));COLS.forEach(function(c){hr.appendChild(E('th',null,c[1]))});th.appendChild(hr);tb.appendChild(th);
  var bd=E('tbody');
  var phong=R.phong.slice().sort(function(a,b){return String(a.phong).localeCompare(String(b.phong),'vi')});
  phong.forEach(function(p){
    var lb=E('span');var bt=E('button','gd15-tg','▾');bt.type='button';bt.setAttribute('aria-expanded','true');bt.setAttribute('aria-label','Thu gọn/mở cán bộ của '+(p.phong||'(không ghi phòng)'));
    lb.appendChild(bt);lb.appendChild(document.createTextNode(' '+(p.phong||'(không ghi phòng)')));
    var tr=rowEl('gd15-p','khm-dstn-phong',lb,p,{'data-phong':p.phong,'data-sc':'phong'});bd.appendChild(tr);
    var cbs=R.canBo.filter(function(c){return c.phong===p.phong}).sort(function(a,b){return String(a.cbTen||a.cbMa).localeCompare(String(b.cbTen||b.cbMa),'vi')});
    var trs=cbs.map(function(c){var l=E('span',null,c.cbTen||c.cbMa||'(không ghi cán bộ)');var r=rowEl('gd15-c','khm-dstn-cb',l,c,{'data-phong':c.phong,'data-cb':c.cbTen||c.cbMa||'','data-cbma':c.cbMa||'','data-sc':'cb'});bd.appendChild(r);return r});
    bt.addEventListener('click',function(){var open=bt.getAttribute('aria-expanded')==='true';bt.setAttribute('aria-expanded',open?'false':'true');bt.textContent=open?'▸':'▾';trs.forEach(function(r){r.hidden=open})});
  });
  bd.appendChild(rowEl('gd15-tong','khm-dstn-tong',E('span',null,'Tổng cộng'),R.tong,{'data-sc':'tong'}));
  tb.appendChild(bd);wrap.appendChild(tb);
  function bam(ev){var td=ev.target.closest&&ev.target.closest('td.gd15-ck');if(!td)return;if(ev.type==='keydown'&&ev.key!=='Enter'&&ev.key!==' ')return;if(ev.type==='keydown')ev.preventDefault();
    var tr=td.parentNode,blk=tb.closest('[data-testid="khm-dstn"]');if(!blk)return;
    tb.querySelectorAll('td.gd15-on').forEach(function(x){x.classList.remove('gd15-on')});td.classList.add('gd15-on');
    moCT(blk,R,tr.getAttribute('data-sc'),tr.getAttribute('data-phong')||'',tr.getAttribute('data-cbma')||'',td.getAttribute('data-k'),+td.getAttribute('data-v'))}
  tb.addEventListener('click',bam);tb.addEventListener('keydown',bam);
  return wrap;
}

var state={key:'',busy:false};
/* 1.3.0 (HM-18): một nguồn tính dùng chung — tính ngay khi có mốc đầu/cuối (không đợi mở tab Đối soát), nhớ theo khóa
   (mốc đầu|cuối # danh sách mốc Lưu trữ). gd16 (KPI, Tổng hợp, biểu đồ) và bảng Đối soát cùng đọc kết quả này. */
var cache={key:'',p:null};
function layR(){
  var A=api(),C=core();if(!A||!C)return null;
  var last=A.last();if(!last||!last.dau||!last.cuoi)return null;
  var k=keyOf(A,last);if(cache.key===k&&cache.p)return cache.p;
  var sel=chonMoc(A,String(last.dau),String(last.cuoi));
  if(sel.loi){cache={key:k,p:Promise.reject(new Error(sel.loi))};cache.p.catch(function(){});return cache.p}
  cache={key:k,p:tinhDstn(A,C,sel).then(function(R){R.mocs=sel.mocs.map(function(m){return m.ngay});R.sel=sel;R.khoa=k;window.__khmDstn=R;return R})};
  cache.p.catch(function(){cache.key=''});
  return cache.p;
}
function keyOf(A,last){var l=A.arcList().map(function(m){return m.timestamp}).join(',');return (last?last.dau+'|'+last.cuoi:'-')+'#'+l}
function ensure(){
  var tab=document.querySelector('[data-testid="khm-tab-doisoat"]');
  if(!tab)return;
  var A=api(),C=core();
  var blk=tab.querySelector('[data-testid="khm-dstn"]');
  var old=tab.querySelector('[data-testid="khm-t-doisoat"]');
  var oldWrap=old&&old.closest('.overflow-auto');
  if(!blk){
    blk=E('div','gd15-blk');blk.setAttribute('data-testid','khm-dstn');
    if(oldWrap&&oldWrap.parentNode===tab)tab.insertBefore(blk,oldWrap);else tab.appendChild(blk);
    state.key='';
  }
  if(!A||!C){if(!blk.__err){blk.textContent='Thiếu mô-đun QLTD_DSTN/gd11 — không lập được bảng theo cán bộ.';blk.__err=1}return}
  var last=A.last();
  var k=keyOf(A,last);
  if(k===state.key&&blk.__done)return;
  if(state.busy)return;
  state.key=k;blk.__done=false;
  blk.innerHTML='';
  var h=E('div','gd15-h');h.appendChild(E('b',null,'📊 Doanh số GN · Thu nợ theo Phòng → Cán bộ'));
  h.appendChild(E('span','gd15-sub',' (theo từng khế ước, cán bộ cuối kỳ; '+C.PHIEN_BAN+')'));blk.appendChild(h);
  var msg=E('div','gd15-msg');msg.setAttribute('data-testid','khm-dstn-msg');blk.appendChild(msg);
  function showOld(on){if(oldWrap){oldWrap.hidden=!on;oldWrap.classList.toggle('gd15-old',true)}}
  if(!last||!last.dau||!last.cuoi){
    msg.textContent='Bảng theo cán bộ cần các mốc dư nợ trong Lưu trữ: dùng "📥 Nạp từ Lưu trữ" ở khối Dữ liệu nguồn rồi Lập báo cáo. (Tệp chọn tay chỉ có bảng theo phòng bên dưới.)';
    msg.className='gd15-msg gd15-warn';showOld(true);blk.__done=true;return;
  }
  var sel=chonMoc(A,String(last.dau),String(last.cuoi));
  if(sel.loi){msg.textContent=sel.loi;msg.className='gd15-msg gd15-err';showOld(true);blk.__done=true;return}
  msg.textContent='⏳ Đang tính trên '+sel.mocs.length+' mốc Lưu trữ…';
  state.busy=true;
  layR().then(function(R){
    state.busy=false;
    var info=E('div','gd15-info');info.setAttribute('data-testid','khm-dstn-moc');
    info.textContent='Kỳ: '+vn(sel.isoD)+' → '+vn(sel.isoC)+' · '+sel.mocs.length+' mốc: '+R.mocs.map(vn).join(', ');
    msg.textContent='';msg.className='gd15-msg';
    var w=canhBaoMoc(sel.mocs).concat(R.canhBao||[]);
    if(R.thieu0&&R.thieu0.length)w.push(R.thieu0.length+' mốc nhập trước v24.17.14 ('+R.thieu0.map(vn).join(', ')+') không lưu khế ước dư nợ 0: khoản giải ngân rồi trả hết vẫn còn trong tệp msit80 sẽ không được tính — nhập lại các tệp đó ở trang Nhập dữ liệu.');
    var f=document.querySelector('input[data-testid="khm-from"]'),t=document.querySelector('input[data-testid="khm-to"]');
    if(f&&t&&f.value&&t.value&&(f.value!==A.addDaysIso(sel.isoD,1)||t.value!==sel.isoC))w.push('Kỳ báo cáo đang chọn ('+vn(f.value)+' → '+vn(t.value)+') khác kỳ của các mốc Lưu trữ — bảng này tính theo kỳ của mốc.');
    blk.appendChild(info);
    if(w.length){var ul=E('ul','gd15-cb');ul.setAttribute('data-testid','khm-dstn-canhbao');w.forEach(function(x){ul.appendChild(E('li',null,'⚠️ '+x))});blk.appendChild(ul)}
    var k3=kiem3(R),kd=E('div','gd15-kt3'+(k3.length?' gd15-err':''),k3.length?'✗ Tổng cán bộ / phòng / chi nhánh lệch: '+k3.slice(0,4).join(' | '):'✓ Tổng cán bộ = tổng phòng = tổng chi nhánh (mọi cột). Bấm một ô số để xem các khế ước cấu thành.');
    kd.setAttribute('data-testid','khm-dstn-kt3');kd.setAttribute('data-lech',String(k3.length));blk.appendChild(kd);
    blk.appendChild(locBar(blk,R));
    blk.appendChild(renderBang(R,sel.mocs));
    var note=E('div','gd15-note','Thu nợ = toàn bộ phần giảm dư nợ gốc từng khế ước giữa hai mốc liền nhau (trả nợ, tất toán, xử lý khác). Điều chỉnh = dư nợ tăng không do GN hoặc khế ước xuất hiện lại/chuyển đến. Đầu + GN − Thu + Điều chỉnh = Cuối (Kiểm tra = 0). Khế ước tất toán gán cho cán bộ cuối kỳ của khách hàng; khách hết dư nợ → cán bộ ở mốc cuối cùng.');
    blk.appendChild(note);
    if(oldWrap){
      showOld(false);
      var tg=E('button','gd15-oldbtn','Xem bảng cũ (thu nợ suy ra theo phòng)');tg.type='button';tg.setAttribute('data-testid','khm-dstn-old');
      tg.addEventListener('click',function(){var on=oldWrap.hidden;showOld(on);tg.textContent=on?'Ẩn bảng cũ':'Xem bảng cũ (thu nợ suy ra theo phòng)'});
      blk.appendChild(tg);
    }
    blk.__done=true;
  }).catch(function(e){
    state.busy=false;msg.textContent='Không lập được bảng theo cán bộ: '+(e&&e.message||e);msg.className='gd15-msg gd15-err';showOld(true);blk.__done=true;
  });
}
var raf=0;function sch(){if(raf)return;raf=requestAnimationFrame(function(){raf=0;try{ensure()}catch(e){if(window.console)console.warn('gd15',e)}})}
function init(){
  sch();
  if(window.MutationObserver){try{new MutationObserver(sch).observe(document.documentElement,{childList:true,subtree:true})}catch(_){}}
  setInterval(function(){if(!document.hidden)sch()},1500);
  window.__gd15Ensure=ensure;window.__gd15LayR=layR;window.GD15={PHIEN_BAN:PB,layR:layR,moCT:function(sc,ph,cb,k){var blk=document.querySelector('[data-testid="khm-dstn"]');var td=blk&&blk.querySelector('[data-testid="khm-dstn-t"] tr[data-sc="'+sc+'"]'+(sc!=='tong'?'[data-phong="'+ph+'"]':'')+(sc==='cb'?'[data-cbma="'+cb+'"]':'')+' td[data-k="'+k+'"]');if(td)td.dispatchEvent(new MouseEvent('click',{bubbles:true}));return !!td}};
}
if(document.body)init();else document.addEventListener('DOMContentLoaded',init);
})();
