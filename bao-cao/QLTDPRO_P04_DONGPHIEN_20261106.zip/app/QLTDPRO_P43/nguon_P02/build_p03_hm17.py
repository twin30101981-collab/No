# P03 · HM-17 · v24.17.13 — Trang Khách hàng mới tính TRÙNG giải ngân khi khế ước đổi HĐTD.
# Gốc rễ: buildReport (bundle) bổ sung "khế ước tất toán trong kỳ" từ các mốc MIS80 giữa kỳ (window.__khmMid) bằng cách so khóa
#   brcd|apprseq|dsbsseq với mốc cuối; gd11.loadMidSnaps cũng gom mốc giữa theo khóa đó. Khế ước đổi HĐTD (giữ dsbsseq) có khóa
#   khác ở mỗi mốc → bị coi là "tất toán" thêm 1–2 dòng ngoài dòng ở mốc cuối (dữ liệu thật 01–10/2026: thừa 1.116 món / 638,76 tỷ).
# Cách sửa: khóa khế ước = dsbsseq (rỗng → khóa cũ) ở cả hai chỗ; dấu tích "KH mới" (localStorage) vẫn dùng khóa cũ để không mất tích.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P02/build_p03_hm17.py
SRC='app/QLTDPRO_v24.17.12.html'; DST='app/QLTDPRO_v24.17.13.html'
s=open(SRC,encoding='utf-8').read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n,('anchor count',c,n,old[:90]); s=s.replace(old,new)
rep("function midKey(o){return String(o.brcd).trim()+'|'+String(o.apprseq)+'|'+String(o.dsbsseq)}",
    "function midKey(o){var q=String(o.dsbsseq==null?'':o.dsbsseq).trim();return q?'S|'+q:String(o.brcd).trim()+'|'+String(o.apprseq)+'|'+String(o.dsbsseq)} /* P03 HM-17: khóa = số khế ước */")
rep('__xk=function(W){return a(W.brcd).trim()+"|"+a(W.apprseq)+"|"+a(W.dsbsseq)};if(__mx&&__mx.nd===_.length&&__mx.nc===j.length){var __jk=new Set(j.map(__xk));__mx.rows.forEach(function(W){__jk.has(__xk(W))||',
    '__xk=function(W){return a(W.brcd).trim()+"|"+a(W.apprseq)+"|"+a(W.dsbsseq)},__xs=function(W){var q=a(W.dsbsseq).trim();return q?"S|"+q:__xk(W)};if(__mx&&__mx.nd===_.length&&__mx.nc===j.length){var __jk=new Set(j.map(__xs));__mx.rows.forEach(function(W){__jk.has(__xs(W))||')
rep('24.17.12','24.17.13',2)
open(DST,'w',encoding='utf-8').write(s)
for f in ('app/sw.js','app/manifest.json'):
    t=open(f,encoding='utf-8').read(); assert '24.17.12' in t,f
    open(f,'w',encoding='utf-8').write(t.replace('24.17.12','24.17.13'))
print('OK',DST)
