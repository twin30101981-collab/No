# P04 · HM-12 · v24.17.15 — Trang Khách hàng mới, tab Đối soát: mỗi ô số (Phòng / Cán bộ / Tổng) bấm được → bảng chi tiết
# khế ước cấu thành (tổng = ô đã bấm), lọc Phòng/Cán bộ, kiểm tổng 3 cấp, xuất Excel 4 sheet (Phòng, Cán bộ, Chi tiết khế ước, Ghi chú)
# và Excel riêng cho bảng chi tiết đang mở.
# Thay đổi:
#   - Lõi QLTD_DSTN 1.0.1 → 1.1.0: CHỈ CỘNG THÊM k.moc = sự kiện theo cặp mốc {tu,den,loai,so,cach}; số liệu + quy tắc gán giữ nguyên.
#   - gd15 1.1.0 → 1.2.0 (nguon_P02/gd15.js): ngày trả gần nhất (lstrpmtdt = cột 26 dòng Lưu trữ), nguồn mốc, ô bấm, Excel tự dựng.
#   - CSS thêm vào <style id="gd15-css">. Không đổi CSP, 4 CSDL, bundle.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P02/build_p04_hm12.py
import re
SRC = 'app/QLTDPRO_v24.17.14.html'; DST = 'app/QLTDPRO_v24.17.15.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor count', c, n, old[:90]); s = s.replace(old, new)
def thay_script(sid, path):
    global s
    m = re.search(r'<script id="' + sid + r'">\n(.*?)\n</script>', s, re.S)
    assert m and s.count('<script id="' + sid + '">') == 1, sid
    t = open(path, encoding='utf-8').read().rstrip('\n'); assert '</script' not in t.lower()
    s = s[:m.start(1)] + t + s[m.end(1):]
rep('24.17.14', '24.17.15', 3)  # 2 nhãn phiên bản + 1 trong gd15 cũ (khối gd15 bị thay ngay sau); làm TRƯỚC khi chèn gd15 mới (gd15 nhắc 'v24.17.14' trong cảnh báo mốc cũ)
thay_script('qltd-dstn-js', 'nguon_P02/qltd_dstn.cjs')
thay_script('gd15-js', 'nguon_P02/gd15.js')
CSS = '''.gd15-t td.gd15-ck{cursor:pointer;text-decoration:underline dotted #7A93B5;text-underline-offset:3px}
.gd15-t td.gd15-ck:hover,.gd15-t td.gd15-ck:focus{background:#E3EEFB;outline:2px solid #1F4E79;outline-offset:-2px}
.gd15-t td.gd15-on{background:#D6E6FA!important;box-shadow:inset 0 0 0 2px #1F4E79}
.gd15-kt3{font-size:12px;color:#166534;margin:4px 0}
.gd15-loc{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:6px 0;font-size:12.5px}
.gd15-loc select{border:1px solid #9AA8BA;border-radius:6px;padding:3px 6px;background:#fff;font-size:12.5px;min-height:30px;max-width:100%}
.gd15-btn{border:1px solid #9AA8BA;border-radius:6px;padding:3px 10px;font-size:12.5px;background:#fff;cursor:pointer;min-height:30px}
.gd15-btn-p{border-color:#1F4E79;background:#1F4E79;color:#fff;font-weight:700}
.gd15-ct{border:1px solid #1F4E79;border-radius:8px;background:#fff;padding:8px;margin:8px 0}
.gd15-ct-h{display:flex;flex-wrap:wrap;gap:6px;align-items:center}.gd15-ct-h b{flex:1 1 220px;color:#1F4E79;overflow-wrap:anywhere}
.gd15-ct-kt{font-size:12.5px;margin:6px 0;color:#166534;font-weight:600}
.gd15-ct-wrap{max-height:60vh;overflow:auto}
.gd15-ct-t{font-size:12px}.gd15-ct-t th.gd15-hl,.gd15-ct-t td.gd15-hl{background:#FFF8E1}
.gd15-ct-t td.gd15-wr{white-space:normal;min-width:220px;max-width:420px}
.gd15-ct-t tfoot td{position:sticky;bottom:0;background:#FFF4D6;font-weight:700}
'''
rep('.gd15-old[hidden]{display:none!important}\n</style>', '.gd15-old[hidden]{display:none!important}\n' + CSS + '</style>')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.14' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.14', '24.17.15'))
print('OK', DST)
