# P04 · HM-18 · v24.17.16 — Khách hàng mới: một nguồn số liệu (lõi QLTD_DSTN) cho KPI, Tổng hợp, biểu đồ phòng, ghi chú tab Chi tiết;
# KPI bấm được → chi tiết khế ước ở tab Đối soát; cỡ chữ ≥ 11px, nút ≥ 28px (điện thoại ≥ 40px).
# Gốc: KPI/Tổng hợp của bundle tính "Thu nợ = GN − chênh lệch dư nợ" và GN chỉ món mới có ngày GN trong tệp cuối kỳ
#   → lệch bảng Đối soát (dữ liệu thử: GN 50,658 vs 63,325 tỷ; thu 528,309 vs 544,705 tỷ). Q11: GN gồm GN thêm trên món cũ.
# Thay đổi: gd15 1.2.0 → 1.3.0 (layR: tính ngay khi có mốc, dùng chung), thêm gd16 1.0.0 (nguon_P02/gd16.js), CSS.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P02/build_p04_hm18.py
import re
SRC = 'app/QLTDPRO_v24.17.15.html'; DST = 'app/QLTDPRO_v24.17.16.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor count', c, n, old[:90]); s = s.replace(old, new)
def doc(path):
    t = open(path, encoding='utf-8').read().rstrip('\n'); assert '</script' not in t.lower(); return t
rep('24.17.15', '24.17.16', 2)  # chỉ 2 nhãn phiên bản (gd15 nhắc v24.17.14, không phải .15)
m = re.search(r'<script id="gd15-js">\n(.*?)\n</script>', s, re.S); assert m and s.count('<script id="gd15-js">') == 1
s = s[:m.start(1)] + doc('nguon_P02/gd15.js') + s[m.end(1):]
assert '<script id="gd16-js">' not in s
i = s.index('</script>', s.index('<script id="gd15-js">')) + len('</script>')
s = s[:i] + '\n<script id="gd16-js">\n' + doc('nguon_P02/gd16.js') + '\n</script>' + s[i:]
CSS = '''<style id="gd16-css">
.gd16-kpi{cursor:pointer}.gd16-kpi:hover,.gd16-kpi:focus{outline:2px solid #1F4E79;outline-offset:1px}
.gd16-note{font-size:12px;color:#1F4E79;background:#EEF4FB;border:1px solid #C9D8EA;border-radius:6px;padding:4px 8px;margin:4px 0;display:flex;flex-wrap:wrap;gap:6px;align-items:center}
.gd16-btn{border:1px solid #1F4E79;border-radius:6px;background:#fff;color:#1F4E79;font-weight:700;font-size:12px;padding:2px 10px;min-height:28px;cursor:pointer}
[data-testid^="khm-t-"] span.rounded.border{font-size:11px!important}
button[data-testid^="khm-"],select[data-testid^="khm-"],[data-testid^="khm-tab-"] button,.gd15-tg,.gd15-oldbtn{min-height:28px}
[data-testid^="khm-tab-"] button.rounded.border.px-2{min-width:28px}
input[type="checkbox"][data-testid^="khm-"]{width:18px;height:18px}
@media (max-width:600px){button[data-testid^="khm-"],select[data-testid^="khm-"],input[data-testid^="khm-"]:not([type="checkbox"]),[data-testid^="khm-tab-"] button,[data-testid^="khm-tab-"] select,[data-testid^="khm-tab-"] input:not([type="checkbox"]),.gd11-khm-arch .gd11-khm-load,.gd11-khm-arch select,.gd15-btn,.gd15-tg,.gd15-oldbtn,.gd15-loc select,.gd16-btn{min-height:40px!important}
[data-testid^="khm-tab-"] button.rounded.border.px-2{min-width:40px}}
</style>
'''
rep('<style id="gd15-css">', CSS + '<style id="gd15-css">')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.15' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.15', '24.17.16'))
print('OK', DST)
