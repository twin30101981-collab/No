# P03 · HM-16 · v24.17.14 — Mốc Lưu trữ bỏ khế ước dư nợ 0 khi nhập msit80 → bảng Phòng → Cán bộ (gd15) thiếu GN trả hết trong kỳ.
# Gốc rễ: luồng Nhập dữ liệu gọi k4(rows) loại dòng dư nợ 0 ("zero"/"thauchiZ") rồi Zf() lưu rpt_<timestamp> chỉ với dòng còn lại.
#   Tệp msit80 thật vẫn liệt kê khoản GN đã trả hết (13–15 dòng/tệp) → lõi QLTD_DSTN không thấy → thiếu GN (11 mốc: 10 món, 7,419 tỷ).
# Cách sửa (không đổi dữ liệu/KPI cũ): giữ các dòng bị k4 loại; Zf lưu thêm khóa phụ rpt0_<timestamp> cùng kho reportData;
#   gd11Api.loadZeroRows đọc khóa phụ; gd15 1.1.0 gộp khi tính, cảnh báo mốc cũ chưa có khóa phụ (cần nhập lại).
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P02/build_p03_hm16.py
import re
SRC='app/QLTDPRO_v24.17.13.html'; DST='app/QLTDPRO_v24.17.14.html'
s=open(SRC,encoding='utf-8').read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n,('anchor count',c,n,old[:90]); s=s.replace(old,new)
rep('const{rows:b,diag:T}=await nw(f,y),w=k4(b);',
    'const{rows:b,diag:T}=await nw(f,y),w=k4(b);window.__hm16Z={kept:w.kept,zero:b.filter(function(r0){var q=x4(r0);return q==="zero"||q==="thauchiZ"})};')
rep('await Os(l,kt(r),e),i>=0?a[i]=r:a.push(r)',
    'await Os(l,kt(r),e),window.__hm16Z&&window.__hm16Z.kept===e&&(await Os(l,"rpt0_"+(r.timestamp||r.name),window.__hm16Z.zero),window.__hm16Z=null),i>=0?a[i]=r:a.push(r)')
rep("last:function(){return buildKhmArchBlock.__last||null}};",
    "last:function(){return buildKhmArchBlock.__last||null},loadZeroRows:function(m){return idbOpen(ARC_DB,1,ARC_ST).then(function(db){return idbGet(db,ARC_ST,'rpt0_'+(m.timestamp||m.name)).then(function(r){db.close();return Array.isArray(r)?r:null},function(e){db.close();throw e})})}};")
m=re.search(r'<script id="gd15-js">\n(.*?)\n</script>',s,re.S); assert m and s.count('<script id="gd15-js">')==1
gd15=open('nguon_P02/gd15.js',encoding='utf-8').read(); assert '</script' not in gd15.lower()
s=s[:m.start(1)]+gd15+s[m.end(1):]
rep('24.17.13','24.17.14',2)
open(DST,'w',encoding='utf-8').write(s)
for f in ('app/sw.js','app/manifest.json'):
    t=open(f,encoding='utf-8').read(); assert '24.17.13' in t,f
    open(f,'w',encoding='utf-8').write(t.replace('24.17.13','24.17.14'))
print('OK',DST)
