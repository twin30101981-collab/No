# P03 · HM-11b · v24.17.12 — Gắn lõi QLTD_DSTN (nguon_P02/qltd_dstn.cjs) vào trang Khách hàng mới, tab Đối soát.
# Gốc rễ (HM-11a): bảng Đối soát tính "Thu nợ suy ra" = GN − Δ dư nợ THEO PHÒNG từ đúng 2 mốc, không có cấp cán bộ,
#   ghép khế ước theo brcd|apprseq|dsbsseq (đổi HĐTD sinh tất toán giả) và bỏ qua mọi mốc giữa kỳ.
# Cách sửa (lớp vá riêng, không sửa bundle React):
#   (1) gd11 xuất API đọc Lưu trữ (window.__gd11Api) — không đổi schema, chỉ đọc;
#   (2) chèn lõi QLTD_DSTN + gd15: lấy MỌI mốc Lưu trữ trong kỳ, bảng Phòng → Cán bộ thay bảng "Thu nợ suy ra" (bảng cũ xem được).
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P02/build_p03_hm11b.py
SRC='app/QLTDPRO_v24.17.11.html'; DST='app/QLTDPRO_v24.17.12.html'
s=open(SRC,encoding='utf-8').read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n,('anchor count',c,n,old[:90]); s=s.replace(old,new)
core=open('nguon_P02/qltd_dstn.cjs',encoding='utf-8').read()
gd15=open('nguon_P02/gd15.js',encoding='utf-8').read()
for t in (core,gd15): assert '</script' not in t.lower()
rep('window.__gd11Scan=scan; /* để bộ kiểm thử gọi trực tiếp */',
    'window.__gd11Scan=scan; /* để bộ kiểm thử gọi trực tiếp */\n  /* P03 HM-11b: API chỉ đọc Lưu trữ cho gd15 */\n  window.__gd11Api={arcList:arcList,loadArcRows:loadArcRows,dunoToObjects:dunoToObjects,vnToIso:vnToIso,addDaysIso:addDaysIso,last:function(){return buildKhmArchBlock.__last||null}};')
CSS='''<style id="gd15-css">
.gd15-blk{border:1px solid #C9D3E0;border-radius:8px;padding:8px 10px;margin:6px 0 10px;background:#F7FAFD}
.gd15-h b{color:#1F4E79}.gd15-sub{color:#4A5A70;font-size:12px}
.gd15-msg{margin:4px 0;font-size:13px}.gd15-warn{color:#8A5A00}.gd15-err{color:#B42318}
.gd15-info{font-size:12px;color:#4A5A70;margin:4px 0;overflow-wrap:anywhere}
.gd15-cb{margin:4px 0;padding-left:4px;list-style:none;font-size:12px;color:#8A5A00}
.gd15-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch;max-width:100%}
.gd15-t{border-collapse:collapse;font-size:13px;min-width:100%}
.gd15-t th,.gd15-t td{border:1px solid #D5DCE6;padding:3px 6px;white-space:nowrap}
.gd15-t th{background:#EAF0F7;text-align:left;position:sticky;top:0}
.gd15-t td.gd15-n{text-align:right;font-variant-numeric:tabular-nums}
.gd15-t td.gd15-bad{background:#FDE8E7;color:#B42318;font-weight:700}
.gd15-t tr.gd15-p td{background:#F0F4F9;font-weight:700}
.gd15-t tr.gd15-c td.gd15-lbl{padding-left:22px}
.gd15-t tr.gd15-tong td{background:#FFF4D6;font-weight:700}
.gd15-t td.gd15-lbl{position:sticky;left:0;background:inherit;max-width:46vw;overflow:hidden;text-overflow:ellipsis}
.gd15-t tr.gd15-c td.gd15-lbl{background:#fff}
.gd15-tg{border:0;background:none;cursor:pointer;padding:0 2px;font-size:13px}
.gd15-note{font-size:11px;color:#4A5A70;margin-top:6px}
.gd15-oldbtn{margin-top:6px;border:1px solid #9AA8BA;border-radius:6px;padding:2px 8px;font-size:12px;background:#fff;cursor:pointer}
.gd15-old[hidden]{display:none!important}
</style>
'''
rep('<style id="gd12-css">', CSS+'<style id="gd12-css">')
rep('<script type="module" crossorigin>',
    '<script id="qltd-dstn-js">\n'+core+'\n</script>\n<script id="gd15-js">\n'+gd15+'\n</script>\n<script type="module" crossorigin>')
rep('24.17.11','24.17.12',2)
rep('"2026-11-04"]','"2026-11-05"]',1)
open(DST,'w',encoding='utf-8').write(s)
for f in ('app/sw.js','app/manifest.json'):
    t=open(f,encoding='utf-8').read(); assert '24.17.11' in t,f
    open(f,'w',encoding='utf-8').write(t.replace('24.17.11','24.17.12'))
print('OK',DST)
