/* gd16 (P04 · HM-18) — Trang Khách hàng mới: MỘT nguồn số liệu cho thẻ KPI, bảng Tổng hợp, biểu đồ "Giải ngân theo phòng"
   = lõi QLTD_DSTN (theo từng khế ước, mọi mốc Lưu trữ trong kỳ) — cùng số với bảng Đối soát và Excel đối soát.
   Q11 (05/11/2026): Doanh số cho vay = GN món mới + GN thêm trên khế ước cũ. Q13: phòng theo phòng ghi trên khế ước.
   Khi không có mốc Lưu trữ (chọn tệp tay): giữ số của bundle, ghi nhãn "suy ra".
   Không sửa bundle; chỉ ghi đè chữ/độ rộng trong các phần tử bundle đã dựng (MutationObserver áp lại khi React vẽ lại). */
(function(){
if(window.__gd16)return; window.__gd16=true;
var PB='P04-GD16 1.0.0';
function E(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e}
function up(s){return String(s||'').trim().toLocaleUpperCase('vi')}
function donVi(){var b=document.querySelector('[data-testid^="khm-unit-"][aria-pressed="true"]');return b?b.getAttribute('data-testid').slice(9):'dong'}
function fmtU(v,u){v=+v||0;if(u==='trieu')return Math.round(v/1e6).toLocaleString('vi-VN');if(u==='ty')return (v/1e9).toLocaleString('vi-VN',{minimumFractionDigits:2,maximumFractionDigits:2});return Math.round(v).toLocaleString('vi-VN')}
function fmt(v){return Math.round(+v||0).toLocaleString('vi-VN')}
function setT(el,t){if(el&&el.textContent!==t)el.textContent=t}
function setA(el,k,v){if(el&&el.getAttribute(k)!==v)el.setAttribute(k,v)}
/* gom theo nhóm: số khế ước có GN (món mới hoặc GN thêm), tiền GN, số món mới, số lần GN thêm */
function gomGN(ds){var o={gn:0,kheGN:0,moi:0,them:0};ds.forEach(function(z){if(z.gn>0){o.gn+=z.gn;o.kheGN++}o.moi+=z.gnMon||0;
  (z.moc||[]).forEach(function(e){if(e.loai==='gn'&&/GN thêm/.test(e.cach))o.them++})});return o}
var KPI={'Doanh số cho vay':'gn','Thu nợ (kỳ này)':'thu','Dư nợ đầu kỳ':'dauKy','Dư nợ cuối kỳ':'cuoiKy'};
function moDoiSoat(k){
  var b=document.querySelector('[data-testid="khm-tab-doisoat-btn"]');if(b)b.click();
  var n=0;(function thu(){if(window.GD15&&window.GD15.moCT&&window.GD15.moCT('tong','','',k))return;if(++n<60)setTimeout(thu,100)})();
}
function kpi(R,G){
  document.querySelectorAll('[data-testid="khm-kpi"]').forEach(function(c){
    var l=(c.children[0]&&c.children[0].textContent||'').trim(),k=KPI[l];if(!k)return;
    var v=c.children[1],s=c.children[2];if(!v||!s)return;
    var val=fmt(R.tong[k])+' đ',sub;
    if(k==='gn')sub=G.kheGN+' khế ước: '+G.moi+' món mới + '+G.them+' lần GN thêm';
    else if(k==='thu')sub='giảm dư nợ gốc từng khế ước · '+R.soMoc+' mốc';
    else if(k==='dauKy')sub=R.khe.filter(function(z){return z.dauKy>0}).length.toLocaleString('vi-VN')+' món còn dư nợ';
    else sub=R.khe.filter(function(z){return z.cuoiKy>0}).length.toLocaleString('vi-VN')+' món còn dư nợ';
    if(v.textContent!==val&&!v.__gd16)c.__cu=v.textContent+' · '+s.textContent;  /* số bundle để đối chiếu */
    setT(v,val);setT(s,sub);v.__gd16=1;
    setA(c,'data-hm18',k);setA(c,'data-v',String(Math.round(R.tong[k])));setA(c,'role','button');setA(c,'tabindex','0');
    setA(c,'title','Theo từng khế ước (lõi '+R.phienBan+', '+R.soMoc+' mốc Lưu trữ) — cùng số với tab Đối soát. Bấm để xem các khế ước cấu thành.'+(c.__cu?' Cách tính cũ: '+c.__cu:''));
    c.classList.add('gd16-kpi');
    if(!c.__gd16b){c.__gd16b=1;var go=function(ev){if(ev.type==='keydown'&&ev.key!=='Enter'&&ev.key!==' ')return;ev.preventDefault();moDoiSoat(c.getAttribute('data-hm18'))};
      c.addEventListener('click',go);c.addEventListener('keydown',go)}
  });
}
function nhanSuyRa(){
  document.querySelectorAll('[data-testid="khm-kpi"]').forEach(function(c){var l=(c.children[0]&&c.children[0].textContent||'').trim();
    if(l==='Thu nợ (kỳ này)'&&c.children[2]&&!/suy ra/.test(c.children[2].textContent))setT(c.children[2],c.children[2].textContent+' (suy ra — chọn tệp tay)')});
}
function tongHop(R,u){
  var t=document.querySelector('[data-testid="khm-t-tonghop"]');if(!t)return;
  var ph='',thieu=[],da={};
  function dat(tr,ds){var td=tr.querySelectorAll('td');if(td.length<3)return null;var G=gomGN(ds);
    setT(td[1],G.kheGN?String(G.kheGN):'–');setT(td[2],G.gn?fmtU(G.gn,u):'–');setA(tr,'data-gn',String(Math.round(G.gn)));setA(tr,'data-gnkhe',String(G.kheGN));return G}
  t.querySelectorAll('tbody tr, tfoot tr').forEach(function(tr){
    var kind=tr.getAttribute('data-kind'),lab=(tr.querySelector('td')||{}).textContent||'';
    if(kind==='phong'){ph=up(lab.replace(/^\s*[IVXLC]+\.\s*/,''));da[ph]=da[ph]||{};dat(tr,R.khe.filter(function(z){return up(z.phong)===ph}))}
    else if(kind==='cb'){var nm=up(lab.replace(/^\s*\d+\.\s*/,''));da[ph]&&(da[ph][nm]=1);dat(tr,R.khe.filter(function(z){return up(z.phong)===ph&&up(z.cbTen||z.cbMa)===nm}))}
    else if(kind==='tong')dat(tr,R.khe);
  });
  /* nhóm có GN theo khế ước nhưng bảng bundle không có dòng (vd chỉ có GN thêm) */
  R.canBo.forEach(function(c){var p=up(c.phong),n=up(c.cbTen||c.cbMa);if(c.gn>0&&!(da[p]&&da[p][n]))thieu.push((c.cbTen||c.cbMa)+' ('+c.phong+'): '+fmt(c.gn)+' đ')});
  var w=t.closest('.overflow-auto')||t.parentNode,nt=w.parentNode.querySelector('[data-testid="khm-gd16-tonghop"]');
  if(!nt){nt=E('div','gd16-note');nt.setAttribute('data-testid','khm-gd16-tonghop');w.parentNode.insertBefore(nt,w)}
  setT(nt,'Cột Giải ngân theo từng khế ước ('+R.soMoc+' mốc Lưu trữ, gồm GN thêm trên khế ước cũ): "Món" = số khế ước có giải ngân trong kỳ. Cùng số với tab Đối soát.'+(thieu.length?' ⚠ Cán bộ có GN nhưng không có dòng ở bảng này: '+thieu.join('; ')+'.':''));
  setA(nt,'data-thieu',String(thieu.length));
}
function bieuDo(R){
  var b=document.querySelector('[data-testid="khm-bars"]');if(!b)return;
  var rows=[].slice.call(b.children),vals=rows.map(function(r){var n=up((r.children[0]||{}).textContent);return R.khe.filter(function(z){return up(z.phong)===n}).reduce(function(a,z){return a+z.gn},0)});
  var mx=Math.max.apply(null,vals.concat([1]));
  rows.forEach(function(r,i){var bar=r.children[1]&&r.children[1].children[0],num=r.children[2];if(!bar||!num)return;
    var w=(vals[i]/mx*100).toFixed(1)+'%';if(bar.style.width!==w)bar.style.width=w;
    var tn=num.firstChild,sau=tn&&tn.nextSibling,txt=fmtU(vals[i],'ty')+(sau&&sau.nodeType===3&&/·/.test(sau.textContent)?'':' · ');if(tn&&tn.nodeType===3&&tn.textContent!==txt)tn.textContent=txt;setA(r,'data-gn',String(Math.round(vals[i])))});
}
function chiTiet(R,G){
  var tab=document.querySelector('[data-testid="khm-tab-chitiet"]');if(!tab)return;
  var nt=tab.querySelector('[data-testid="khm-gd16-chitiet"]');
  if(!nt){nt=E('div','gd16-note');nt.setAttribute('data-testid','khm-gd16-chitiet');tab.insertBefore(nt,tab.firstChild);
    var bt=E('button','gd16-btn','Xem đủ ở tab Đối soát');bt.type='button';bt.setAttribute('data-testid','khm-gd16-chitiet-go');bt.addEventListener('click',function(){moDoiSoat('gn')});nt.__bt=bt}
  var t='Danh sách bên dưới lấy từ tệp dư nợ cuối kỳ (món có ngày GN trong kỳ). Doanh số cho vay theo khế ước: '+fmt(R.tong.gn)+' đ = '+G.moi+' món mới + '+G.them+' lần GN thêm trên khế ước cũ (gồm món GN rồi tất toán giữa kỳ).';
  if(nt.firstChild&&nt.firstChild.nodeType===3){if(nt.firstChild.textContent!==t)nt.firstChild.textContent=t}else{nt.insertBefore(document.createTextNode(t),nt.firstChild)}
  if(nt.__bt.parentNode!==nt)nt.appendChild(nt.__bt);
}
var st={k:'',R:null,dang:false};
function ap(){
  if(!document.querySelector('[data-testid="khm-kpi"],[data-testid="khm-t-tonghop"],[data-testid="khm-tab-chitiet"]'))return;
  var A=window.__gd11Api,last=A&&A.last&&A.last();
  if(!last||!last.dau||!last.cuoi){nhanSuyRa();return}
  var p=window.__gd15LayR&&window.__gd15LayR();if(!p)return;
  if(p!==st.p){st.p=p;st.R=null;p.then(function(R){if(st.p===p){st.R=R;sch()}},function(){})}
  var R=st.R;if(!R)return;
  var G=gomGN(R.khe);window.__gd16G=G;
  kpi(R,G);tongHop(R,donVi());bieuDo(R);chiTiet(R,G);
}
var raf=0;function sch(){if(raf)return;raf=requestAnimationFrame(function(){raf=0;try{ap()}catch(e){if(window.console)console.warn('gd16',e)}})}
function init(){sch();if(window.MutationObserver){try{new MutationObserver(sch).observe(document.documentElement,{childList:true,subtree:true,characterData:true})}catch(_){}}
  setInterval(function(){if(!document.hidden)sch()},1500);window.GD16={PHIEN_BAN:PB,ap:ap}}
if(document.body)init();else document.addEventListener('DOMContentLoaded',init);
})();
