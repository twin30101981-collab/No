/*
 * QLTD_DSTN — Doanh số giải ngân + thu nợ gốc theo KHẾ ƯỚC → cán bộ → phòng, có đối soát (HM-11a, P02).
 * Hàm thuần, không DOM, không mạng. Chạy được trong trình duyệt (window.QLTD_DSTN) và Node (require).
 *
 * Căn cứ dữ liệu thật msit80 (11 mốc cuối tháng 31/12/2025–31/10/2026, kiểm 04–05/11/2026):
 *  - rpmtamt = 0 ở MỌI dòng → không dùng được để đo thu nợ. Thu nợ đo theo TỪNG KHẾ ƯỚC từ số dư hai mốc liền nhau.
 *  - dsbsseq duy nhất trong mỗi tệp; 178 khế ước/tháng đổi apprseq (HĐTD) nhưng giữ dsbsseq → khóa khế ước = dsbsseq
 *    (khóa cũ brcd|apprseq|dsbsseq sinh "tất toán giả + khoản mới giả").
 *  - Tháng 10/2026 có 1.577 khế ước đổi cán bộ (ofcno) → phải chốt quy tắc gán cán bộ.
 * Quy tắc nghiệp vụ (người dùng chốt 05/11/2026):
 *  - Q5: tính cho CÁN BỘ CUỐI KỲ. Khế ước còn ở mốc cuối → cán bộ ở mốc cuối. Khế ước tất toán trong kỳ → cán bộ cuối kỳ
 *    của chính khách hàng (mã KH = brcd; cột custseq của msit80 là mã chi nhánh) nếu khách còn dư nợ ở mốc cuối; nếu không → cán bộ ở mốc cuối cùng khế ước còn xuất hiện.
 *  - Q6: thu nợ tính TOÀN BỘ phần giảm dư nợ gốc (trả nợ, tất toán, xử lý khác) — không lọc theo loại giao dịch.
 * Định nghĩa trên một chuỗi mốc s0 (đầu kỳ) … sn (cuối kỳ), cộng dồn từng cặp liền nhau (mốc giữa kỳ giúp thấy khoản
 * GN rồi tất toán trong kỳ):
 *   - Khế ước có ở cả 2 mốc: GN thêm = max(0, Δdsbsamt); thu = dư nợ trước + GN thêm − dư nợ sau;
 *     nếu thu < 0 (dư nợ tăng không có GN): thu = 0, ghi "điều chỉnh tăng" = −thu.
 *   - Khế ước mới ở mốc sau: nếu ngày GN trong (ĐẦU KỲ, mốc sau] và chưa từng xuất hiện ở mốc nào trước → GN = dsbsamt, thu = dsbsamt − dư nợ sau (≥ 0, âm → điều chỉnh);
 *     ngược lại → "xuất hiện lại / chuyển đến" (không phải GN): điều chỉnh tăng = dư nợ sau.
 *   - Khế ước mất ở mốc sau: thu = dư nợ trước (tất toán).
 * Bất biến mọi cấp: Dư nợ đầu + GN − Thu + Điều chỉnh = Dư nợ cuối (đúng tới đồng; lệch → lỗi lõi).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.QLTD_DSTN = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var PHIEN_BAN = 'P04-HM12 1.1.0'; // 1.1.0 (HM-12): CỘNG THÊM k.moc = sự kiện theo cặp mốc {tu,den,loai,so}; số liệu + quy tắc gán giữ như 1.0.1
  function num(v) {
    if (typeof v === 'number') return isFinite(v) ? v : 0;
    var s = String(v == null ? '' : v).replace(/[\s,]/g, '');
    var n = Number(s); return isFinite(n) ? n : 0;
  }
  function str(v) { return String(v == null ? '' : v).trim(); }
  // Ngày: 'yyyy-mm-dd', 'yyyy-mm-dd hh:mm:ss', 'dd/mm/yyyy', Date → 'yyyy-mm-dd' (không đoán kiểu Mỹ)
  function iso(v) {
    if (v instanceof Date && !isNaN(v)) return v.getFullYear() + '-' + ('0' + (v.getMonth() + 1)).slice(-2) + '-' + ('0' + v.getDate()).slice(-2);
    var s = str(v), m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
    if (m) return m[1] + '-' + m[2] + '-' + m[3];
    m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})/.exec(s);
    if (m) return m[3] + '-' + ('0' + m[2]).slice(-2) + '-' + ('0' + m[1]).slice(-2);
    return '';
  }
  // Chuẩn hoá một dòng msit80 (đối tượng theo tên cột) → bản ghi khế ước
  function chuanHoa(r) {
    var seq = str(r.dsbsseq);
    return {
      key: seq || (str(r.brcd) + '|' + str(r.apprseq) + '|' + seq),
      dsbsseq: seq, apprseq: str(r.apprseq), brcd: str(r.brcd), maKH: str(r.brcd), custnm: str(r.custnm), // mã KH = brcd (13 số); cột custseq là mã chi nhánh
      dsbsdt: iso(r.dsbsdt), dsbsamt: num(r.dsbsamt), bal: num(r.dsbsbal),
      cbMa: str(r.ofcno) || str(r.ofcnm), cbTen: str(r.ofcnm), phong: str(r.trctnm), loai: str(r.lntpcd)
    };
  }
  function mapMoc(rows) {
    var m = new Map(), kh = new Map(), trung = 0;
    rows.forEach(function (r0) {
      var r = r0 && r0.key ? r0 : chuanHoa(r0);
      if (m.has(r.key)) { trung++; var o = m.get(r.key); o.bal += r.bal; return; } // phòng thủ: không xảy ra với dữ liệu kiểm
      m.set(r.key, Object.assign({}, r));
      if (r.bal > 0 && !kh.has(r.maKH)) kh.set(r.maKH, { cbMa: r.cbMa, cbTen: r.cbTen, phong: r.phong });
    });
    return { m: m, kh: kh, trung: trung };
  }
  /**
   * @param {Array<{ngay:string, rows:Array}>} mocs  các mốc theo thứ tự thời gian; mocs[0] = đầu kỳ, mocs[n] = cuối kỳ
   * @returns {{khe:Array, canBo:Array, phong:Array, tong:Object, canhBao:Array}}
   */
  function tinh(mocs) {
    if (!Array.isArray(mocs) || mocs.length < 2) throw new Error('Cần ít nhất 2 mốc (đầu kỳ, cuối kỳ)');
    var M = mocs.map(function (x) { return Object.assign({ ngay: iso(x.ngay) }, mapMoc(x.rows || [])); });
    for (var i = 1; i < M.length; i++) if (!(M[i].ngay > M[i - 1].ngay)) throw new Error('Mốc phải tăng dần theo ngày');
    var cuoi = M[M.length - 1], dau = M[0];
    function su(k, A, B, loai, so, cach) { k.moc.push({ tu: A.ngay, den: B.ngay, loai: loai, so: so, cach: cach }); }
    var K = new Map(); // key -> tổng hợp khế ước
    function the(r) {
      var k = K.get(r.key);
      if (!k) { k = { key: r.key, dsbsseq: r.dsbsseq, apprseq: r.apprseq, maKH: r.maKH, custnm: r.custnm, loai: r.loai, dsbsdt: r.dsbsdt,
        dauKy: 0, gn: 0, thu: 0, dieuChinh: 0, cuoiKy: 0, gnMon: 0, tatToan: false, cachTinh: [], cbMa: '', cbTen: '', phong: '', gan: '', moc: [] }; K.set(r.key, k); }
      return k;
    }
    dau.m.forEach(function (r) { var k = the(r); k.dauKy = r.bal; });
    var daThay = new Set(); dau.m.forEach(function (r, key) { daThay.add(key); });
    for (var j = 1; j < M.length; j++) {
      var A = M[j - 1], B = M[j];
      A.m.forEach(function (a, key) {
        var k = the(a), b = B.m.get(key);
        if (b) {
          var gnThem = Math.max(0, b.dsbsamt - a.dsbsamt), t = a.bal + gnThem - b.bal;
          if (gnThem > 0) { k.gn += gnThem; k.cachTinh.push('GN thêm ' + B.ngay); su(k, A, B, 'gn', gnThem, 'GN thêm (Δ số tiền GN)'); }
          if (t >= 0) { k.thu += t; if (t > 0) su(k, A, B, 'thu', t, 'Δ dư nợ gốc giảm'); } else { k.dieuChinh += -t; k.cachTinh.push('dư nợ tăng không GN ' + B.ngay); su(k, A, B, 'dc', -t, 'dư nợ tăng không GN'); }
        } else {
          k.thu += a.bal; k.tatToan = true; k.cachTinh.push('tất toán (mất ở mốc ' + B.ngay + ')'); if (a.bal) su(k, A, B, 'thu', a.bal, 'tất toán (không còn ở mốc sau)');
          k._cuoiXuatHien = a;
        }
      });
      B.m.forEach(function (b, key) {
        if (A.m.has(key)) return;
        var k = the(b);
        // GN nếu ngày GN trong (đầu kỳ, mốc này] và khế ước CHƯA từng xuất hiện ở mốc nào trước (mốc giữa có thể thiếu dòng)
        if (b.dsbsdt && b.dsbsdt > dau.ngay && b.dsbsdt <= B.ngay && !daThay.has(key)) {
          k.gn += b.dsbsamt; k.gnMon += 1; su(k, A, B, 'gn', b.dsbsamt, 'GN mới ngày ' + b.dsbsdt);
          var t = b.dsbsamt - b.bal;
          if (t >= 0) { k.thu += t; if (t > 0) su(k, A, B, 'thu', t, 'suy ra: GN − dư nợ ở mốc sau'); } else { k.dieuChinh += -t; su(k, A, B, 'dc', -t, 'dư nợ > số tiền GN'); }
          k.cachTinh.push('GN mới ' + b.dsbsdt);
        } else {
          k.dieuChinh += b.bal; k.cachTinh.push('xuất hiện không phải GN trong kỳ (ngày GN ' + (b.dsbsdt || '?') + ')'); if (b.bal) su(k, A, B, 'dc', b.bal, 'xuất hiện lại / chuyển đến');
        }
        if (k.tatToan) { k.tatToan = false; } // tái xuất hiện sau khi mất
      });
      B.m.forEach(function (b, key) { daThay.add(key); });
    }
    var canhBao = [];
    M.forEach(function (x) { if (x.trung) canhBao.push(x.ngay + ': ' + x.trung + ' dòng trùng khóa khế ước (đã cộng dư nợ)'); });
    K.forEach(function (k, key) {
      var b = cuoi.m.get(key);
      k.cuoiKy = b ? b.bal : 0;
      if (b) { k.cbMa = b.cbMa; k.cbTen = b.cbTen; k.phong = b.phong; k.gan = 'cán bộ cuối kỳ của khế ước'; }
      else {
        var kh = cuoi.kh.get(k.maKH);
        if (kh) { k.cbMa = kh.cbMa; k.cbTen = kh.cbTen; k.phong = kh.phong; k.gan = 'cán bộ cuối kỳ của khách hàng (khế ước đã tất toán)'; }
        else {
          var last = k._cuoiXuatHien;
          if (!last) { for (var j2 = M.length - 1; j2 >= 0 && !last; j2--) last = M[j2].m.get(key); }
          k.cbMa = last ? last.cbMa : ''; k.cbTen = last ? last.cbTen : ''; k.phong = last ? last.phong : '';
          k.gan = 'cán bộ ở mốc cuối cùng khế ước còn dư nợ (khách hàng không còn dư nợ cuối kỳ)';
        }
      }
      delete k._cuoiXuatHien;
      var lech = k.dauKy + k.gn - k.thu + k.dieuChinh - k.cuoiKy;
      if (Math.abs(lech) > 0.5) canhBao.push('Khế ước ' + key + ' lệch bất biến ' + lech);
    });
    function gom(ds, fk) {
      var g = new Map();
      ds.forEach(function (k) {
        var id = fk(k), x = g.get(id);
        if (!x) { x = { id: id, dauKy: 0, gn: 0, gnMon: 0, thu: 0, dieuChinh: 0, cuoiKy: 0, soKhe: 0, soTatToan: 0 }; g.set(id, x); }
        x.dauKy += k.dauKy; x.gn += k.gn; x.gnMon += k.gnMon; x.thu += k.thu; x.dieuChinh += k.dieuChinh; x.cuoiKy += k.cuoiKy; x.soKhe++; if (k.tatToan) x.soTatToan++;
      });
      return Array.from(g.values()).map(function (x) { x.kiemTra = x.dauKy + x.gn - x.thu + x.dieuChinh - x.cuoiKy; return x; });
    }
    var khe = Array.from(K.values());
    var canBo = gom(khe, function (k) { return k.phong + '\u0001' + k.cbMa; }).map(function (x) {
      var p = x.id.split('\u0001'); x.phong = p[0]; x.cbMa = p[1];
      var t = khe.find(function (k) { return k.phong === x.phong && k.cbMa === x.cbMa; }); x.cbTen = t ? t.cbTen : ''; return x;
    });
    var phong = gom(khe, function (k) { return k.phong; }).map(function (x) { x.phong = x.id; return x; });
    var tong = gom(khe, function () { return 'tong'; })[0] || { dauKy: 0, gn: 0, thu: 0, dieuChinh: 0, cuoiKy: 0, kiemTra: 0 };
    // Đối soát với tổng của tệp (độc lập với phép cộng khế ước)
    var tDau = 0, tCuoi = 0; dau.m.forEach(function (r) { tDau += r.bal; }); cuoi.m.forEach(function (r) { tCuoi += r.bal; });
    tong.dauTep = tDau; tong.cuoiTep = tCuoi;
    if (Math.abs(tDau - tong.dauKy) > 0.5 || Math.abs(tCuoi - tong.cuoiKy) > 0.5) canhBao.push('Tổng dư nợ khế ước khác tổng tệp');
    return { phienBan: PHIEN_BAN, dauKy: dau.ngay, cuoiKy: cuoi.ngay, soMoc: M.length, khe: khe, canBo: canBo, phong: phong, tong: tong, canhBao: canhBao };
  }
  return { PHIEN_BAN: PHIEN_BAN, tinh: tinh, chuanHoa: chuanHoa, iso: iso, num: num };
});
