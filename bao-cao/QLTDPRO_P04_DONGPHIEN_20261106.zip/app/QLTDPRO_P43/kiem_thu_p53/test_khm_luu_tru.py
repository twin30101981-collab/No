# Kiểm thử P53: Nạp từ Lưu trữ -> Khách hàng mới -> Lập báo cáo (ngày dd/mm ≤ 12 không được đảo; mã số giữ số 0 đầu).
# Dùng: python3 kiem_thu_p53/test_khm_luu_tru.py [app/QLTDPRO_v24.17.9.html]   (SEQ=num|pad: dạng số khế ước)
import os, asyncio, functools, http.server, threading, sys, re, json
from pathlib import Path
from playwright.async_api import async_playwright
HTML = (Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent.parent/'app'/'QLTDPRO_v24.17.9.html').resolve(); PORT = 8847
URL = f'http://127.0.0.1:{PORT}/{HTML.name}'
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a,**k): pass
httpd = http.server.ThreadingHTTPServer(('127.0.0.1',PORT), functools.partial(Q, directory=str(HTML.parent))); threading.Thread(target=httpd.serve_forever,daemon=True).start()
res=[]
def ok(n,c,info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ')+n+('' if c else ' — '+str(info)[:500]))

PAD=os.environ.get('SEQ','num')=='pad'
def row(brcd,ten,hd,gn,dh,ls,tien,du,cb,loai,phong,seq):
    seq=seq if PAD else str(int(seq))
    r=[None]*21
    r[0]=brcd;r[1]=ten;r[2]=hd;r[6]=gn;r[7]=dh;r[8]=ls;r[9]=tien;r[11]=du;r[12]=cb;r[13]=loai;r[17]=phong;r[20]=seq
    return r
OLD=row('3201000000001','KH CU','HD-OLD','20/08/2026','20/08/2027',8.5,900000000,900000000,'CB A','Vay trung hạn','Phòng 1','001')
DAU=[OLD]
CUOI=[OLD,
 row('3201000000002','HO NGAY 05/10','HD-A','05/10/2026','05/10/2027',8.5,500000000,500000000,'CB A','Vay trung hạn','Phòng 1','001'),
 row('3201000000003','HO NGAY 12/10','HD-B','12/10/2026','12/10/2027',8.5,200000000,200000000,'CB A','Vay trung hạn','Phòng 1','002'),
 row('3201000000004','NGAY 15/10','HD-C','15/10/2026','15/10/2027',8.5,100000000,100000000,'CB B','Vay trung hạn','Phòng 2','003'),
 row('3201000000005','HO NGAY 03/11','HD-D','03/11/2026','03/05/2027',8.5,300000000,300000000,'CB B','Vay trung hạn','Phòng 2','004'),
]
EXPECT_N=4; EXPECT_TIEN=500_000_000+200_000_000+100_000_000+300_000_000

async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(headless=True); ctx=await b.new_context(viewport={'width':1366,'height':900},locale='vi-VN')
        await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
        pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL+'#/khach-hang-moi',wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
        seed = await pg.evaluate("""async ([dau,cuoi])=>{
          const open=()=>new Promise((res,rej)=>{const rq=indexedDB.open('TWIN_Archive_v1',1);rq.onupgradeneeded=()=>{if(!rq.result.objectStoreNames.contains('reportData'))rq.result.createObjectStore('reportData')};rq.onsuccess=()=>res(rq.result);rq.onerror=()=>rej(rq.error)});
          const db=await open();
          const put=(k,v)=>new Promise((res,rej)=>{const tx=db.transaction('reportData','readwrite');tx.objectStore('reportData').put(v,k);tx.oncomplete=res;tx.onerror=()=>rej(tx.error)});
          await put('rpt_1001',dau); await put('rpt_1002',cuoi); db.close();
          const d2=await new Promise((res,rej)=>{const rq=indexedDB.open('QLTDProTSBD',1);rq.onupgradeneeded=()=>{if(!rq.result.objectStoreNames.contains('kv'))rq.result.createObjectStore('kv')};rq.onsuccess=()=>res(rq.result);rq.onerror=()=>rej(rq.error)});
          await new Promise((res,rej)=>{const tx=d2.transaction('kv','readwrite');tx.objectStore('kv').put({rows:[{soTS:'TS1',loaiTS:'Chứng chỉ tiền gửi',chiTietTS:'CCTG',maKH:'3201000000005',tenKH:'HO NGAY 03/11',giaTriTS:'400000000',ngayTheChap:'03/11/2026',ngayHetHan:'05/10/2027',phong:'Phòng 2'}],src:'test',importedAt:new Date().toISOString()},'current');tx.oncomplete=res;tx.onerror=()=>rej(tx.error)});
          d2.close();
          localStorage.setItem('_archiveReportList',JSON.stringify([
            {type:'report',timestamp:1001,dayKey:'30/09/2026',name:'dau'},
            {type:'report',timestamp:1002,dayKey:'03/11/2026',name:'cuoi'}]));
          return 'seeded';}""",[DAU,CUOI])
        await pg.reload(wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
        blk=pg.locator('[data-testid="khm-archive"]')
        ok('T1 có khối Nạp từ Lưu trữ', await blk.count()>0, seed)
        n=await pg.locator('[data-testid="khm-arch-dau"] option').count()
        ok('T2 có 2 mốc lưu trữ', n==2, n)
        await pg.locator('[data-testid="khm-arch-load"]').click(); await pg.wait_for_timeout(2500)
        msg=await pg.locator('[data-testid="khm-arch-msg"]').inner_text()
        print('MSG:',msg)
        ok('T3 nạp được 2 nguồn', 'Đã nạp' in msg, msg)
        # điền kỳ nếu chưa có
        fr=await pg.locator('[data-testid="khm-from"]').input_value(); to=await pg.locator('[data-testid="khm-to"]').input_value()
        print('kỳ:',fr,to)
        go=pg.locator('[data-testid="khm-go"]'); print('khm-go enabled:',await go.is_enabled())
        await go.click(); await pg.wait_for_timeout(2500)
        res_=pg.locator('[data-testid="khm-res"]'); 
        txt=await res_.inner_text() if await res_.count() else ''
        err=pg.locator('[data-testid="khm-error"]'); et=await err.inner_text() if await err.count() else ''
        print('ERR:',et)
        kp=[re.sub(r'\s+',' ',t) for t in await pg.locator('[data-testid="khm-kpi"]').all_inner_texts()]
        print('KPI:',kp)
        await pg.screenshot(path='/tmp/shot_'+HTML.stem+'.png',full_page=False)
        ids=await pg.evaluate("[...document.querySelectorAll('[data-testid]')].map(e=>e.dataset.testid).filter(t=>t.startsWith('khm'))")
        print('TESTIDS:',sorted(set(ids)))
        tab=pg.locator('[data-testid="khm-tab-chitiet-btn"]')
        if await tab.count(): await tab.first.click(); await pg.wait_for_timeout(800)
        rows_=[re.sub(r'\s+',' ',t) for t in await pg.locator('[data-testid="khm-t-chitiet"] tbody tr').all_inner_texts()]
        for r_ in rows_: print('ROW:',r_)
        ok(f'T4 báo cáo có đủ {EXPECT_N} món giải ngân', len(rows_)==EXPECT_N, (len(rows_),rows_))
        allt=' '.join(rows_)
        for d in ['05/10/2026','12/10/2026','15/10/2026','03/11/2026']:
            ok(f'T5 hiển thị ngày GN {d}', d in allt, allt)
        ok('T6 ngày đáo hạn 03/05/2027 đúng (không bị đảo)', '03/05/2027' in allt, allt)
        ok('T7 không lỗi JS', not errs, errs)
        await b.close()
    print(f'\n{sum(res)}/{len(res)} PASS'); sys.exit(0 if all(res) else 1)
asyncio.run(main())
