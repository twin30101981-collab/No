# P44 · v24.17.0 — Khách hàng mới: quét mọi bản MIS80 giữa 2 mốc (món đã tất toán không bị sót)
import re,sys
SRC='app/QLTDPRO_v24.16.0.html'; DST='app/QLTDPRO_v24.17.0.html'
s=open(SRC,encoding='utf-8').read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n,('anchor count',c,n,old[:60]); s=s.replace(old,new)

# 1) Nạp từ Lưu trữ: gom mọi bản MIS80 giữa 2 mốc (mỗi ngày lấy bản mới nhất) -> window.__khmMid
rep("var khmBusy=false;","""function nonEmptyN(rows){return dunoToObjects(rows||[]).filter(function(o){for(var k in o)if(o[k]!=='')return true;return false}).length}
function midKey(o){return String(o.brcd).trim()+'|'+String(o.apprseq)+'|'+String(o.dsbsseq)}
function loadMidSnaps(md,mc,all){
  var isoD=vnToIso(md.dayKey||''),isoC=vnToIso(mc.dayKey||'');
  if(!isoD||!isoC)return Promise.resolve(null);
  var byDay={};
  all.forEach(function(m){var d=vnToIso(m.dayKey||'');if(!d||d<isoD||d>isoC)return;
    if(!byDay[d]||(m.timestamp||0)>(byDay[d].timestamp||0))byDay[d]=m});
  var days=Object.keys(byDay).sort(),seen=new Map();
  return days.reduce(function(p,d){return p.then(function(){
    return loadArcRows(byDay[d]).then(function(rows){
      dunoToObjects(rows||[]).forEach(function(o){
        var iso=vnToIso(o.dsbsdt);if(iso&&iso<=isoD)return;
        o.__d=d.split('-').reverse().join('/');seen.set(midKey(o),o);
      });
    }).catch(function(){});
  })},Promise.resolve()).then(function(){return{rows:Array.from(seen.values()),days:days.length}});
}
var khmBusy=false;""")
rep("cbTsbd.checked?loadTsbdCurrent():Promise.resolve(null)]).then(function(res){",
    "cbTsbd.checked?loadTsbdCurrent():Promise.resolve(null),loadMidSnaps(md,mc,all).catch(function(){return null})]).then(function(res){")
rep("var rd=res[0],rc=res[1],rt=res[2];",
    "var rd=res[0],rc=res[1],rt=res[2],mid=res[3];window.__khmMid=mid&&rd&&rc?{nd:nonEmptyN(rd),nc:nonEmptyN(rc),days:mid.days,rows:mid.rows}:null;")
rep("""files.length+' nguồn từ Lưu trữ vào các ô — kiểm tra kỳ rồi bấm "Lập báo cáo".'""",
    """files.length+' nguồn từ Lưu trữ vào các ô — kiểm tra kỳ rồi bấm "Lập báo cáo".'+(window.__khmMid?' Đã quét '+window.__khmMid.days+' bản MIS80 giữa 2 mốc.':'')""")

# 2) buildReport: thêm món có ở ngày giữa kỳ nhưng vắng ở cuối kỳ (đã tất toán)
rep('$=[],J=[];j.forEach(function(W){var U=s(W.dsbsdt);if(!(!U||U<k||U>R)){var re=a(W.brcd).trim(),ne=!K.has(re),se={',
    '$=[],J=[],__mx=window.__khmMid,__tt=[],__xk=function(W){return a(W.brcd).trim()+"|"+a(W.apprseq)+"|"+a(W.dsbsseq)};'
    'if(__mx&&__mx.nd===_.length&&__mx.nc===j.length){var __jk=new Set(j.map(__xk));__mx.rows.forEach(function(W){__jk.has(__xk(W))||__tt.push(Object.assign({},W,{__tt:W.__d,dsbsbal:0}))})}'
    'j.concat(__tt).forEach(function(W){var U=s(W.dsbsdt);if(!(!U||U<k||U>R)){var re=a(W.brcd).trim(),ne=!K.has(re),se={')
rep("khMoi:ne,camCo:ne&&O.has(re)};$.push(se),",
    'khMoi:ne,camCo:ne&&O.has(re),tatToan:!!W.__tt,thayCuoi:W.__tt||"",camCoKXD:!!W.__tt&&ne&&!O.has(re)};$.push(se),')

# 3) Nhãn trong bảng chi tiết
old='L.camCo&&o.jsx("span",{className:"ml-1 rounded bg-warn/30 px-1",children:"cầm cố"})'
rep(old,old+',L.tatToan&&o.jsx("span",{className:"ml-1 rounded border px-1 text-muted-foreground",title:"Thấy lần cuối "+L.thayCuoi,children:"đã tất toán"}),L.camCoKXD&&o.jsx("span",{className:"ml-1 rounded bg-warn/30 px-1",title:"Không có TSBĐ để tra — cần rà tay",children:"cầm cố?"})')

rep('24.16.0','24.17.0',2)
open(DST,'w',encoding='utf-8').write(s)
for f in ('app/sw.js','app/manifest.json'):
    t=open(f,encoding='utf-8').read().replace('24.16.0','24.17.0').replace('p43-','p44-')
    open(f,'w',encoding='utf-8').write(t)
print('OK',DST,len(s))
