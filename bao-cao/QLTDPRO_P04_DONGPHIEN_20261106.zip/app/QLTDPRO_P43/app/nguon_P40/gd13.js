/* ===== QLTDPRO GD13 (P40) — nhập IPCAS từ tệp nén .zip (RAR: báo rõ, không giải nén) =====
   Chạy TRƯỚC bước nhận tệp cũ: mỗi tệp bảng tính trong zip thành một File ảo, rồi đi vào luồng cũ
   (phân loại theo tên/tiêu đề, ngày từ tên, chống trùng, nhật ký SHA-256, hoàn tác — không đổi).
   Không mạng, không wasm, không đổi CSP: đọc zip thuần JS + DecompressionStream('deflate-raw'). */
(function () {
  'use strict';
  var LIM = { files: 200, depth: 3, total: 400 * 1048576, one: 200 * 1048576, ratio: 300 };
  var SHEET = /\.(xls|xlsx|xlsm|csv)$/i, JUNK = /(^|\/)(__MACOSX\/|\.|~\$|thumbs\.db$|desktop\.ini$)/i;
  var NOTE_ID = 'gd13-note', timer = null;

  function u16(d, o) { return d.getUint16(o, true); }
  function u32(d, o) { return d.getUint32(o, true); }
  function isRarBytes(b) { return b.length > 7 && b[0] === 0x52 && b[1] === 0x61 && b[2] === 0x72 && b[3] === 0x21; }
  function isPK(b) { return b.length > 3 && b[0] === 0x50 && b[1] === 0x4b; }
  function decName(bytes, utf8flag) {
    try { return new TextDecoder('utf-8', { fatal: true }).decode(bytes); } catch (e) {}
    try { return new TextDecoder(utf8flag ? 'utf-8' : 'windows-1252').decode(bytes); } catch (e2) { return ''; }
  }

  /* Đọc danh mục (central directory); hỗ trợ zip64 cơ bản */
  function listZip(buf) {
    var b = new Uint8Array(buf), d = new DataView(buf), i, eocd = -1;
    for (i = b.length - 22; i >= Math.max(0, b.length - 22 - 65535); i--) if (u32(d, i) === 0x06054b50) { eocd = i; break; }
    if (eocd < 0) throw new Error('không tìm thấy danh mục zip (tệp hỏng/không phải zip)');
    var n = u16(d, eocd + 10), cdSize = u32(d, eocd + 12), cdOff = u32(d, eocd + 16);
    if (n === 0xffff || cdOff === 0xffffffff) {
      var loc = eocd - 20;
      if (loc >= 0 && u32(d, loc) === 0x07064b50) {
        var z = Number(d.getBigUint64(loc + 8, true));
        if (u32(d, z) === 0x06064b50) { n = Number(d.getBigUint64(z + 32, true)); cdOff = Number(d.getBigUint64(z + 48, true)); }
      }
    }
    var out = [], p = cdOff;
    for (i = 0; i < n; i++) {
      if (p + 46 > b.length || u32(d, p) !== 0x02014b50) throw new Error('danh mục zip bị hỏng');
      var fl = u16(d, p + 8), nl = u16(d, p + 28), el = u16(d, p + 30), cl = u16(d, p + 32);
      var e = { flags: fl, method: u16(d, p + 10), csize: u32(d, p + 20), usize: u32(d, p + 24), off: u32(d, p + 42),
                name: decName(b.subarray(p + 46, p + 46 + nl), !!(fl & 2048)).replace(/\\/g, '/') };
      if (e.csize === 0xffffffff || e.usize === 0xffffffff || e.off === 0xffffffff) { /* zip64 extra */
        var q = p + 46 + nl, end = q + el;
        while (q + 4 <= end) {
          var id = u16(d, q), sz = u16(d, q + 2);
          if (id === 1) { var r = q + 4;
            if (e.usize === 0xffffffff) { e.usize = Number(d.getBigUint64(r, true)); r += 8; }
            if (e.csize === 0xffffffff) { e.csize = Number(d.getBigUint64(r, true)); r += 8; }
            if (e.off === 0xffffffff) { e.off = Number(d.getBigUint64(r, true)); } }
          q += 4 + sz;
        }
      }
      out.push(e); p += 46 + nl + el + cl;
    }
    return out;
  }

  /* Giải nén một mục, có trần dung lượng thật (không tin kích thước khai báo) */
  async function readEntry(buf, e, cap) {
    var d = new DataView(buf), b = new Uint8Array(buf), o = e.off;
    if (u32(d, o) !== 0x04034b50) throw new Error('đầu mục bị hỏng');
    var start = o + 30 + u16(d, o + 26) + u16(d, o + 28), raw = b.subarray(start, start + e.csize);
    if (e.method === 0) { if (raw.length > cap) throw new Error('vượt giới hạn dung lượng'); return raw.slice().buffer; }
    if (e.method !== 8) throw new Error('kiểu nén ' + e.method + ' chưa hỗ trợ');
    if (typeof DecompressionStream === 'undefined') throw new Error('trình duyệt quá cũ (thiếu DecompressionStream)');
    var rd = new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader(), parts = [], got = 0, c;
    while (!(c = await rd.read()).done) {
      got += c.value.length;
      if (got > cap || (raw.length > 64 && got > raw.length * LIM.ratio)) { try { await rd.cancel(); } catch (x) {} throw new Error('dung lượng giải nén bất thường (nghi zip bomb)'); }
      parts.push(c.value);
    }
    var res = new Uint8Array(got), k = 0; parts.forEach(function (x) { res.set(x, k); k += x.length; });
    return res.buffer;
  }

  /* Mở rộng một tệp nén; đẩy File ảo vào ctx.out, ghi chú vào ctx.notes */
  async function openZip(buf, label, depth, ctx) {
    var list, st = { ok: 0, skip: 0 };
    try { list = listZip(buf); } catch (e) { ctx.notes.push({ t: 'err', m: label + ': ' + e.message }); return; }
    for (var i = 0; i < list.length; i++) {
      var e = list[i], nm = e.name, base = nm.split('/').pop();
      if (!nm || /\/$/.test(nm)) continue;
      if (nm.split('/').indexOf('..') >= 0 || JUNK.test(nm) || !base) { st.skip++; continue; }
      var isZip = /\.zip$/i.test(base), isRar = /\.(rar|7z)$/i.test(base);
      if (isRar) { ctx.rar.push(label + ' › ' + base); continue; }
      if (!SHEET.test(base) && !isZip) { st.skip++; continue; }
      if (e.flags & 1) { ctx.notes.push({ t: 'err', m: label + ' › ' + base + ': có mật khẩu — không giải nén được' }); continue; }
      if (ctx.count >= LIM.files) { ctx.notes.push({ t: 'err', m: 'Vượt ' + LIM.files + ' tệp — bỏ phần còn lại của ' + label }); break; }
      if (e.usize > LIM.one) { ctx.notes.push({ t: 'err', m: label + ' › ' + base + ': quá lớn (> ' + (LIM.one >> 20) + ' MB)' }); continue; }
      try {
        var data = await readEntry(buf, e, Math.min(LIM.one, LIM.total - ctx.bytes));
        ctx.bytes += data.byteLength;
        if (isZip) { if (depth + 1 > LIM.depth) { st.skip++; } else await openZip(data, label + ' › ' + base, depth + 1, ctx); continue; }
        ctx.count++; st.ok++;
        var f = new File([data], uniq(base, ctx), { lastModified: Date.now() }); f.gd13src = label; ctx.out.push(f);
      } catch (err) { ctx.notes.push({ t: 'err', m: label + ' › ' + base + ': ' + err.message }); }
    }
    ctx.notes.push({ t: st.ok ? 'ok' : 'warn', m: label + ': lấy ' + st.ok + ' tệp bảng tính' + (st.skip ? ', bỏ qua ' + st.skip + ' tệp khác' : '') + (st.ok ? '' : ' — không có .xls/.xlsx/.csv') });
  }
  function uniq(name, ctx) {
    var n = name, k = 1, m = /^(.*?)(\.[^.]+)$/.exec(name) || [0, name, ''];
    while (ctx.names[n.toLowerCase()]) n = m[1] + ' (' + (++k) + ')' + m[2];
    ctx.names[n.toLowerCase()] = 1; return n;
  }

  function note(ctx) {
    var msgs = ctx.notes.slice(), tail = '';
    if (ctx.rar.length) msgs.push({ t: 'err', m: 'RAR/7z chưa giải nén được trong trình duyệt (' + ctx.rar.slice(0, 3).join(', ') + (ctx.rar.length > 3 ? '…' : '') + '). Hãy nén lại thành ZIP bằng 7-Zip/WinRAR: chuột phải → Add to archive → định dạng zip.' });
    if (!msgs.length) return;
    var el = document.getElementById(NOTE_ID);
    if (!el) { el = document.createElement('div'); el.id = NOTE_ID; el.setAttribute('data-testid', 'gd13-note'); el.setAttribute('role', 'status');
      el.style.cssText = 'position:fixed;right:12px;bottom:12px;z-index:99999;max-width:min(560px,92vw);padding:10px 14px;border-radius:8px;font:13px/1.45 system-ui,sans-serif;background:#0b1f3a;color:#fff;box-shadow:0 6px 24px rgba(0,0,0,.35);cursor:pointer;white-space:normal';
      el.title = 'Bấm để đóng'; el.onclick = function () { el.remove(); }; document.body.appendChild(el); }
    el.textContent = '';
    msgs.forEach(function (x) { var r = document.createElement('div'); r.textContent = (x.t === 'ok' ? '✓ ' : x.t === 'warn' ? '⚠ ' : '✗ ') + x.m; if (x.t === 'err') r.style.color = '#ffb4a8'; el.appendChild(r); });
    clearTimeout(timer); timer = setTimeout(function () { var z = document.getElementById(NOTE_ID); if (z) z.remove(); }, 20000);
  }

  /* Cửa vào: nhận mảng File, trả mảng File (tệp thường giữ nguyên, tệp nén được mở ra) */
  window.__qltdExpand = async function (files) {
    var arr = Array.prototype.slice.call(files || []), ctx = { out: [], notes: [], rar: [], count: 0, bytes: 0, names: {} };
    try {
      var plain = [];
      arr.forEach(function (f) { if (!/\.(zip|rar|7z)$/i.test(f.name)) ctx.names[f.name.toLowerCase()] = 1; });
      for (var i = 0; i < arr.length; i++) {
        var f = arr[i], isZipName = /\.zip$/i.test(f.name), isRarName = /\.(rar|7z)$/i.test(f.name);
        if (isRarName) { ctx.rar.push(f.name); continue; }
        if (!isZipName) { plain.push(f); continue; }
        var buf = await f.arrayBuffer(), head = new Uint8Array(buf, 0, Math.min(8, buf.byteLength));
        if (isRarBytes(head)) { ctx.rar.push(f.name); continue; }
        if (!isPK(head)) { ctx.notes.push({ t: 'err', m: f.name + ': không phải tệp zip hợp lệ' }); continue; }
        await openZip(buf, f.name, 1, ctx);
      }
      var res = plain.concat(ctx.out);
      if (ctx.notes.length || ctx.rar.length) note(ctx);
      return res;
    } catch (e) {
      ctx.notes.push({ t: 'err', m: 'Lỗi giải nén: ' + (e && e.message || e) }); note(ctx);
      return arr.filter(function (f) { return !/\.(zip|rar|7z)$/i.test(f.name); });
    }
  };
})();
