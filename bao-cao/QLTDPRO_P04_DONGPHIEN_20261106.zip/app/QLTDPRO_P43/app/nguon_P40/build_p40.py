#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gói P40: dựng QLTDPRO_v24.12.0.html từ P39 (v24.11.0) — nhập IPCAS từ .zip (RAR: báo rõ).
Quy tắc: chỉ vá theo chuỗi chính xác đếm đúng số lần; nghiệp vụ mới nằm trong khối JS gd13 (sau gd12).
Không đổi CSP, không đổi lược IndexedDB, không thêm mạng."""
import io, sys, os

ROOT = os.path.dirname(os.path.abspath(__file__)); APP = os.path.join(ROOT, '..')
SRC = os.path.join(APP, '..', 'baseline', 'QLTDPRO_v24.11.0.html'); DST = os.path.join(APP, 'QLTDPRO_v24.12.0.html')
def read(p):
    with io.open(p, encoding='utf-8') as f: return f.read()
def write(p, s):
    with io.open(p, 'w', encoding='utf-8', newline='') as f: f.write(s)
def rep(h, old, new, expect=1):
    n = h.count(old)
    if n != expect: sys.exit('ANCHOR FAIL: expect %d, got %d: %r' % (expect, n, old[:90]))
    return h.replace(old, new)

def main():
    h = read(SRC)
    h = rep(h, 'children:["v","24.11.0"," · ","2026-11-03"]', 'children:["v","24.12.0"," · ","2026-11-03"]')
    h = rep(h, 'Wk("24.11.0",r)', 'Wk("24.12.0",r)')
    # cửa vào nhập: chọn tệp + kéo thả đều đi qua __qltdExpand (đọc FileList ĐỒNG BỘ trước khi xoá value)
    h = rep(h, 'accept:".xls,.xlsx,.xlsm,.csv","data-testid":"file-input"',
               'accept:".xls,.xlsx,.xlsm,.csv,.zip,.rar,.7z","data-testid":"file-input"')
    h = rep(h, 'onChange:U=>{B(U.target.files),U.target.value=""}',
               'onChange:U=>{const __f=Array.from(U.target.files);U.target.value="",window.__qltdExpand(__f).then(B)}')
    h = rep(h, 'B(U.dataTransfer.files)', 'window.__qltdExpand(Array.from(U.dataTransfer.files)).then(B)')
    h = rep(h, 'Hỗ trợ .xls .xlsx .xlsm .csv.', 'Hỗ trợ .xls .xlsx .xlsm .csv và tệp nén .zip chứa nhiều tệp (RAR: nén lại thành ZIP).')
    js = read(os.path.join(ROOT, 'gd13.js'))
    if '</script' in js.lower(): sys.exit('gd13.js chứa </script')
    i = h.find('id="gd12-css"'); j = h.find('</style>', i)
    if i < 0 or j < 0: sys.exit('MARKER FAIL gd12-css')
    k = j + len('</style>')
    h = h[:k] + '\n<script id="gd13-js">\n' + js + '\n</script>\n' + h[k:]
    write(DST, h)
    sw = read(os.path.join(APP, 'sw.js'))
    sw = sw.replace('qltdpro-p39-v24.11.0', 'qltdpro-p40-v24.12.0').replace('QLTDPRO_v24.11.0.html', 'QLTDPRO_v24.12.0.html').replace('Service Worker (P39)', 'Service Worker (P40)')
    write(os.path.join(APP, 'sw.js'), sw)
    mf = read(os.path.join(APP, 'manifest.json')); write(os.path.join(APP, 'manifest.json'), mf.replace('QLTDPRO_v24.11.0.html', 'QLTDPRO_v24.12.0.html'))
    print('build OK: %s (%d bytes, +%.1f KB)' % (os.path.basename(DST), os.path.getsize(DST), (os.path.getsize(DST) - os.path.getsize(SRC)) / 1024.0))
if __name__ == '__main__': main()
