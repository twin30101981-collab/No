# Tạo dữ liệu thử P40: xlsx (từ csv của P39) và các loại zip/rar giả
import csv, io, os, zipfile, struct, zlib
from pathlib import Path
from openpyxl import Workbook
H = Path(__file__).resolve().parent; D = H / 'du_lieu_thu'; Z = H / 'zip'; Z.mkdir(exist_ok=True)
def rows(p): return list(csv.reader(io.open(p, encoding='utf-8-sig', newline='')))
def tonum(v):
    return int(v) if v.isdigit() and not (len(v) > 1 and v[0] == '0') and len(v) < 16 else v
def xlsx(src, dst):
    wb = Workbook(); ws = wb.active; ws.title = 'Sheet1'
    for i, r in enumerate(rows(src)): ws.append(r if i == 0 else [tonum(v) for v in r])
    wb.save(dst)
XL = H / 'xlsx'; XL.mkdir(exist_ok=True)
xlsx(D / 'lon_dau_ky.csv',  XL / 'msit80_30-09-2026.xlsx')
xlsx(D / 'lon_cuoi_ky.csv', XL / 'msit80_31-10-2026.xlsx')
xlsx(D / 'lon_tsbd.csv',    XL / '18_08_2026-TS.xlsx')      # tên KHÔNG có "tài sản": phải nhận loại bằng tiêu đề cột
def zipw(name, items, utf8=True):
    with zipfile.ZipFile(Z / name, 'w', zipfile.ZIP_DEFLATED) as zf:
        for arc, data in items:
            zi = zipfile.ZipInfo(arc); zi.compress_type = zipfile.ZIP_DEFLATED
            if not utf8: zi.flag_bits &= ~0x800
            zf.writestr(zi, data)
rd = lambda p: Path(p).read_bytes()
a, b, t = rd(XL/'msit80_30-09-2026.xlsx'), rd(XL/'msit80_31-10-2026.xlsx'), rd(XL/'18_08_2026-TS.xlsx')
zipw('ok_3tep.zip', [('msit80_30-09-2026.xlsx', a), ('msit80_31-10-2026.xlsx', b), ('18_08_2026-TS.xlsx', t)])
zipw('thumuc_rac.zip', [('Thang10/', b''), ('Thang10/msit80_31-10-2026.xlsx', b), ('Thang10/~$msit80.xlsx', b'x'),
                        ('__MACOSX/Thang10/._msit80_31-10-2026.xlsx', b'x'), ('Thang10/Thumbs.db', b'x'), ('Thang10/ghichu.docx', b'x'),
                        ('../thoat.xlsx', b'x')])
inner = io.BytesIO()
with zipfile.ZipFile(inner, 'w', zipfile.ZIP_DEFLATED) as zf: zf.writestr('msit80_30-09-2026.xlsx', a)
zipw('long_nhau.zip', [('dau_ky.zip', inner.getvalue()), ('msit80_31-10-2026.xlsx', b)])
zipw('ten_tieng_viet.zip', [('Dư nợ/msit80_31-10-2026.xlsx', b), ('Tài sản/Sao kê TSBĐ 18-08-2026.xlsx', t)])
zipw('ten_khong_utf8.zip', [('Dư nợ/msit80_31-10-2026.xlsx', b)], utf8=False)
zipw('trung_a.zip', [('msit80_31-10-2026.xlsx', b)]); zipw('trung_b.zip', [('msit80_31-10-2026.xlsx', b)])
(Z / 'hong.zip').write_bytes((Z / 'ok_3tep.zip').read_bytes()[:-60])
(Z / 'khong_phai_zip.zip').write_bytes(b'hello, khong phai zip')
(Z / 'gia_rar.rar').write_bytes(b'Rar!\x1a\x07\x01\x00' + b'\0' * 64)
(Z / 'rar_doi_duoi.zip').write_bytes(b'Rar!\x1a\x07\x00' + b'\0' * 64)
# có mật khẩu: bật bit 0 ở cờ danh mục
raw = bytearray((Z / 'trung_a.zip').read_bytes()); i = raw.find(b'PK\x01\x02'); raw[i + 8] |= 1; (Z / 'co_mat_khau.zip').write_bytes(bytes(raw))
# bom: 20 MB số 0 nén ~20 KB (tỉ lệ ≈1000:1) và tệp khai báo 210 MB
zipw('bom_ti_le.zip', [('msit80_01-11-2026.xlsx', b'\0' * (20 * 1048576))])
zipw('bom_khong_lo.zip', [('msit80_02-11-2026.xlsx', b'\0' * (210 * 1048576))])
zipw('khong_co_bang_tinh.zip', [('a.docx', b'x'), ('b.pdf', b'x')])
print('tao xong:', sorted(p.name for p in Z.iterdir()))
