# -*- coding: utf-8 -*-
"""Dữ liệu kiểm thử Máy tính lãi (P42 v24.15.0) + phép tính ĐỘC LẬP bằng Python (không dùng mã JS của app).
Quy tắc nghiệp vụ đã chốt 03/11/2026: 365 ngày; số ngày = chốt − mốc; mốc = lstintchrgprd, trống thì dsbsdt;
quá hạn xét theo dsbsmatdt (đến hạn khoản giải ngân); đoạn quá hạn = LS × 1,5 = phần cơ bản (LS) + phạt (0,5 LS),
mỗi phần làm tròn nửa-lên tới đồng; tổng = cộng các số đã tròn."""
from datetime import date
from fractions import Fraction
from pathlib import Path

HEAD = ['brcd', 'custnm', 'apprseq', 'apprdt', 'apprmatdt', 'appramt', 'dsbsseq', 'dsbsdt', 'dsbsmatdt', 'sprd', 'dsbsamt',
        'rpmtamt', 'intamt', 'dsbsbal', 'ofcnm', 'lntpcd', 'addr1', 'commmn', 'fndprpstpcd', 'trctnm', 'aqccdfin',
        'lstintchrgprd', 'nxtrpmtschddt', 'lstrpmtdt']

VXT = 'Vũ Xuân Tuấn'
# (dsbsdt, dsbsmatdt, apprmatdt, sprd, dư nợ, số HĐTD, lntpcd) — đúng 10 khoản trong ảnh mockup
VXT_LOANS = [
    ('05/06/2026', '10/04/2027', '10/04/2027', '8.8', 1000000000, '3201LAV202600506', '211'),
    ('17/06/2026', '10/04/2027', '10/04/2027', '8.8', 500000000, '3201LAV202600506', '211'),
    ('14/07/2026', '10/04/2027', '10/04/2027', '8.8', 500000000, '3201LAV202600506', '211'),
    ('21/07/2026', '10/04/2027', '10/04/2027', '8.8', 500000000, '3201LAV202600506', '211'),
    ('12/08/2026', '10/04/2027', '10/04/2027', '8.8', 650000000, '3201LAV202600506', '211'),
    ('28/08/2026', '28/08/2029', '28/08/2029', '9.5', 700000000, '3201LAV202601233', '212'),
    ('04/09/2026', '10/04/2027', '10/04/2027', '8.8', 700000000, '3201LAV202600506', '211'),
    ('08/09/2026', '10/04/2027', '10/04/2027', '8.8', 700000000, '3201LAV202600506', '211'),
    ('10/09/2026', '10/04/2027', '10/04/2027', '8.8', 550000000, '3201LAV202600506', '211'),
    ('14/09/2026', '10/04/2027', '10/04/2027', '8.8', 550000000, '3201LAV202600506', '211'),
]

def rows():
    out = []
    def add(cust, seq, ds, dsbsdt, dsbsmatdt, apprmatdt, sprd, bal, lstint, lntpcd='211', amt=None):
        out.append(['3201', cust, seq, dsbsdt, apprmatdt, amt or max(bal, 1000000), ds, dsbsdt, dsbsmatdt, sprd, amt or max(bal, 1000000),
                    0, 0, bal, 'NGUYỄN VĂN CB', lntpcd, '1 Hai Bà Trưng, Hà Nội', '', 'TD001', 'PGD Hai Bà Trưng', 'Nhóm 1',
                    lstint, '', ''])
    for i, (gn, mat, amat, ls, bal, hd, tp) in enumerate(VXT_LOANS):
        add(VXT, hd, '3201LD26%05d' % (i + 1), gn, mat, amat, ls, bal, '22/10/2026', tp)
    # dòng đã tất toán (dư nợ 0) của cùng KH — không được đếm vào "khoản còn dư nợ" (V2-L6)
    add(VXT, '3201LAV202500100', '3201LD2500099', '02/01/2025', '02/01/2026', '02/01/2026', '8.5', 0, '02/01/2026', '211', 300000000)
    # ca quá hạn bắt buộc: đến hạn khoản GN 29/10/2026 nhưng HĐTD (apprmatdt) còn đến 10/04/2027 (V2-L4)
    add('Trần Quá Hạn', '3201LAV202600900', '3201LD2600901', '29/04/2026', '29/10/2026', '10/04/2027', '8.8', 1000000000, '22/10/2026')
    # ca lỗi dữ liệu (V2-L5): mốc sau ngày chốt; thiếu lãi suất; 1 khoản bình thường
    add('Lê Lỗi Dữ Liệu', '3201LAV202600950', '3201LD2600951', '01/09/2026', '01/09/2027', '01/09/2027', '8.8', 300000000, '10/11/2026')
    add('Lê Lỗi Dữ Liệu', '3201LAV202600950', '3201LD2600952', '01/09/2026', '01/09/2027', '01/09/2027', '', 400000000, '01/10/2026')
    add('Lê Lỗi Dữ Liệu', '3201LAV202600950', '3201LD2600953', '15/09/2026', '01/03/2027', '01/03/2027', '7.5', 200000000, '01/10/2026')
    return out

def write_xlsx(path):
    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active; ws.title = 'Sheet1'
    ws.append(HEAD)
    # tệp msit80 IPCAS ghi ngày dạng MM/DD/YYYY (bộ nhập P42 đọc a/b/yyyy mơ hồ theo quy ước này)
    us = lambda v: (v.split('/')[1] + '/' + v.split('/')[0] + '/' + v.split('/')[2]) if isinstance(v, str) and v.count('/') == 2 else v
    for r in rows(): ws.append([us(v) for v in r])
    wb.save(path)

# ───────── phép tính độc lập ─────────
def d(s):
    dd, mm, yy = s.split('/'); return date(int(yy), int(mm), int(dd))
def rnd(fr):  # làm tròn nửa-lên (số dương) — chuẩn chứng từ
    return int((fr + Fraction(1, 2)) // 1)
def lai(bal, sprd, lstint, dsbsdt, dsbsmatdt, chot):
    if bal <= 0: return {'ok': False, 'ly': 'Dư nợ'}
    if sprd in ('', None): return {'ok': False, 'ly': 'Lãi suất'}
    ls = Fraction(str(sprd))
    moc = d(lstint) if lstint else d(dsbsdt)
    if chot < moc: return {'ok': False, 'ly': 'trước mốc'}
    n = (chot - moc).days
    mat = d(dsbsmatdt)
    nth = n if mat > chot else max(0, min(n, (mat - moc).days))
    nqh = n - nth
    th = rnd(bal * ls / 100 * nth / 365) if nth else 0
    cb = rnd(bal * ls / 100 * nqh / 365) if nqh else 0
    ph = rnd(bal * ls / 100 * Fraction(1, 2) * nqh / 365) if nqh else 0
    return {'ok': True, 'n': n, 'nth': nth, 'nqh': nqh, 'th': th, 'cb': cb, 'ph': ph, 'qh': cb + ph, 'tong': th + cb + ph}

def expect(cust, chot):
    """Kết quả kỳ vọng cho từng dòng của KH theo thứ tự hiển thị (còn dư nợ trước, rồi theo ngày GN)."""
    rs = [r for r in rows() if r[1] == cust]
    rs.sort(key=lambda r: (0 if r[13] > 0 else 1, d(r[7])))
    return [dict(r=r, k=lai(r[13], r[9], r[21], r[7], r[8], chot)) for r in rs]

def vn(n): return '{:,}'.format(n).replace(',', '.')

if __name__ == '__main__':
    e = expect(VXT, date(2026, 11, 3))
    for x in e: print(x['r'][13], x['r'][9], x['k'])
    print('Tổng VXT 03/11/2026:', vn(sum(x['k']['tong'] for x in e if x['k']['ok'])))
    print('Ca quá hạn:', expect('Trần Quá Hạn', date(2026, 11, 3))[0]['k'])
