# -*- coding: utf-8 -*-
# Kiểm thử Máy tính lãi P42 v24.15.0 (Playwright Chromium) — mobile 390×844 + desktop 1280×1800.
# Mọi ô số đọc từ DOM được so với phép tính ĐỘC LẬP trong du_lieu_mtl.py (Python, Fraction, không dùng mã JS app).
# Chạy: python3 kiem_thu_p42_mtl/test_may_tinh_lai.py   (cổng 8826; ảnh bằng chứng → kiem_thu_p42_mtl/anh/)
import asyncio, functools, http.server, threading, sys, re
from datetime import date
from pathlib import Path
from playwright.async_api import async_playwright

HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import du_lieu_mtl as D

PORT = 8826; URL = f'http://127.0.0.1:{PORT}/QLTDPRO_v24.15.0.html'
SHOT = HERE / 'anh'; SHOT.mkdir(exist_ok=True)
FIX = HERE / 'msit80_03-11-2026.xlsx'; D.write_xlsx(FIX)
CHOT = date(2026, 11, 3)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:600]), flush=True)

class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
httpd = http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / 'app')))
threading.Thread(target=httpd.serve_forever, daemon=True).start()

VN = D.vn
def isod(d0): return d0.isoformat()
def EXP(cust, d0):  # bộ nhập P42 loại dòng dư nợ 0 (đã tất toán) khỏi dữ liệu — kỳ vọng mô phỏng đúng điều đó
    return [e for e in D.expect(cust, d0) if e['r'][13] > 0]
def num(s): return int(re.sub(r'[^\d]', '', s) or 0)

async def cell(row, tid):
    loc = row.locator(f'[data-testid="{tid}"]')
    return (await loc.inner_text()).strip() if await loc.count() else None

async def read_rows(pg):
    out = []
    rows = pg.locator('[data-testid="gd14-calc-row"]')
    for i in range(await rows.count()):
        r = rows.nth(i)
        o = {'cls': await r.get_attribute('class') or '', 'ok': await r.get_attribute('data-ok')}
        for t in ('moc', 'denhan', 'duno', 'ls', 'songay', 'laith', 'songayqh', 'laiqh', 'tong', 'loi'):
            o[t] = await cell(r, 'gd14-calc-' + t)
        o['tick'] = await r.locator('[data-testid="gd14-calc-tick"]').is_checked()
        out.append(o)
    return out

def compare(dom, exp):
    """So từng ô DOM với kỳ vọng Python; trả danh sách sai lệch (rỗng = khớp 0 đồng)."""
    bad = []
    if len(dom) != len(exp): return ['số dòng %d ≠ %d' % (len(dom), len(exp))]
    for i, (a, e) in enumerate(zip(dom, exp)):
        r, k = e['r'], e['k']
        want = {'moc': r[21], 'duno': VN(r[13]), 'ls': (r[9].replace('.', ',') + '%') if r[9] else '—'}
        if k['ok']:
            want.update({'songay': '%d ngày' % k['n'], 'laith': VN(k['th']) if k['nth'] else '—',
                         'songayqh': '%d ngày' % k['nqh'] if k['nqh'] else '—', 'tong': VN(k['tong'])})
            laiqh_first = (a['laiqh'] or '').split('\n')[0].strip()
            if laiqh_first != (VN(k['qh']) if k['nqh'] else '—'): bad.append((i, 'laiqh', a['laiqh'], k['qh']))
            if k['nqh'] and ('%s + phạt %s' % (VN(k['cb']), VN(k['ph']))) not in (a['laiqh'] or ''): bad.append((i, 'laiqh-tp', a['laiqh'], k['cb'], k['ph']))
            if ('qh' in a['cls'].split()) != bool(k['nqh']): bad.append((i, 'tô đỏ quá hạn', a['cls']))
            if a['ok'] != '1': bad.append((i, 'data-ok', a['ok']))
        else:
            if a['ok'] != '0' or not (a['loi'] or '').startswith('Không tính được — ') or k['ly'] not in a['loi']:
                bad.append((i, 'lỗi', a['loi'], k['ly']))
        for t, v in want.items():
            if a[t] != v: bad.append((i, t, a[t], v))
        if not (a['denhan'] or '').startswith(r[8]): bad.append((i, 'denhan r[7]', a['denhan'], r[8]))
    return bad

def exp_total(exp, ticked=None):
    return sum(e['k']['tong'] for j, e in enumerate(exp) if e['k']['ok'] and (ticked is None or ticked[j]))

async def summary(pg):
    g = lambda t: pg.locator(f'[data-testid="gd14-calc-{t}"]').inner_text()
    return {'tick': num(await g('sotick')), 'goc': num(await g('tonggoc')), 'lai': num(await g('tonglai')), 'thu': num(await g('tongthu'))}

async def set_chot(pg, d0):
    await pg.fill('[data-testid="gd14-calc-chot"]', isod(d0)); await pg.wait_for_timeout(250)

async def pick(pg, q, name):
    await pg.fill('[data-testid="gd14-calc-search"]', q); await pg.wait_for_timeout(250)
    hit = pg.locator('[data-testid="gd14-calc-hit"]', has_text=name)
    await hit.first.click(); await pg.wait_for_timeout(250)

async def run(p, tag, vw, vh):
    print(f'\n══ {tag} {vw}×{vh} ══', flush=True)
    b = await p.chromium.launch()
    ctx = await b.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN', device_scale_factor=2 if tag == 'mobile' else 1)
    await ctx.grant_permissions(['clipboard-read', 'clipboard-write'], origin=f'http://127.0.0.1:{PORT}')
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append('pageerror: ' + str(e)))
    pg.on('console', lambda m: m.type == 'error' and errs.append('console: ' + m.text))
    shot = lambda n: pg.screenshot(path=str(SHOT / f'{tag}_{n}.png'))
    T = tag + ' '
    try:
        await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
        await pg.set_input_files('[data-testid="file-input"]', [str(FIX)]); await pg.wait_for_timeout(2500)
        await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
        y = pg.locator('[data-testid="confirm-yes"]')
        if await y.count(): await y.click()
        await pg.wait_for_timeout(4500)

        await pg.goto(URL + '#/no-den-han', wait_until='domcontentloaded'); await pg.wait_for_timeout(2000)
        ok(T + 'M0 nút "Máy tính lãi" có ở trang Nợ đến hạn', await pg.locator('[data-testid="gd14-calc"]').count() == 1)
        await pg.goto(URL + '#/lai-dong', wait_until='domcontentloaded'); await pg.wait_for_timeout(2000)
        ok(T + 'M1 nút "Máy tính lãi" có ở trang Lãi đọng (cạnh công cụ tất toán cũ)', await pg.locator('[data-testid="gd14-calc"]').count() == 1 and await pg.locator('[data-testid="gd14-tool"]').count() in (0, 1))
        ok(T + 'M1b lõi nạp nguyên bản + GD14 1.1.0', await pg.evaluate("window.QLTDLai.PHIEN_BAN==='P41-GD1-M1 1.0.0' && window.GD14.PHIEN_BAN==='P42-GD14 1.1.0'"))
        await pg.click('[data-testid="gd14-calc"]'); await pg.wait_for_timeout(400)
        body = await pg.locator('[data-testid="gd14-calc-overlay"]').inner_text()
        ok(T + 'M2 mở modal: công thức TT14 + 2 tab + ngày chốt + Hôm nay', 'Thông tư 14/2017/TT-NHNN' in body and 'Số ngày ÷ 365' in body
           and await pg.locator('[data-testid="gd14-calc-tab-kh"]').count() == 1 and await pg.locator('[data-testid="gd14-calc-tab-tay"]').count() == 1
           and await pg.locator('[data-testid="gd14-calc-chot"]').count() == 1 and await pg.locator('[data-testid="gd14-calc-homnay"]').count() == 1, body[:300])
        await shot('01_mo_modal')
        await set_chot(pg, CHOT)

        # tìm kiếm không dấu + theo số HĐTD
        await pg.fill('[data-testid="gd14-calc-search"]', 'vu xuan'); await pg.wait_for_timeout(250)
        hits = await pg.locator('[data-testid="gd14-calc-hit"]').all_inner_texts()
        ok(T + 'M3 tìm không dấu "vu xuan" → Vũ Xuân Tuấn (10 khoản còn dư nợ)', len(hits) == 1 and 'Vũ Xuân Tuấn' in hits[0] and '10 khoản còn dư nợ' in hits[0], hits)
        await shot('02_tim_kiem')
        await pg.fill('[data-testid="gd14-calc-search"]', 'LAV202601233'); await pg.wait_for_timeout(250)
        hits = await pg.locator('[data-testid="gd14-calc-hit"]').all_inner_texts()
        ok(T + 'M3b tìm theo số HĐTD → đúng KH', len(hits) == 1 and 'Vũ Xuân Tuấn' in hits[0], hits)
        await pg.locator('[data-testid="gd14-calc-hit"]').first.click(); await pg.wait_for_timeout(300)
        ok(T + 'M4 thẻ KH: tổng dư nợ 6.350.000.000 + 10 khoản còn dư nợ',
           (await pg.locator('[data-testid="gd14-calc-tongduno"]').inner_text()).strip() == '6.350.000.000 đồng'
           and (await pg.locator('[data-testid="gd14-calc-sokhoan"]').inner_text()).strip() == '10 khoản vay còn dư nợ')

        exp = EXP(D.VXT, CHOT)
        dom = await read_rows(pg)
        ok(T + 'M4b dòng dư nợ 0 (đã tất toán 3201LD2500099) không có trong dữ liệu sau nhập — không lẫn vào bảng', len(dom) == 10 and len(D.expect(D.VXT, CHOT)) == 11, len(dom))
        bad = compare(dom, exp)
        ok(T + 'M5 10 dòng × mọi ô (mốc, đến hạn r[7], dư nợ, LS, số ngày, lãi TH, ngày QH, lãi QH, tổng) khớp Python — sai lệch 0', not bad, bad)
        s = await summary(pg)
        ok(T + 'M6 thanh tổng: 10 khoản · gốc 0 · LÃI 18.532.601 · THU 18.532.601', s == {'tick': 10, 'goc': 0, 'lai': 18532601, 'thu': 18532601} and exp_total(exp) == 18532601, s)
        ok(T + 'M7 tổng = cộng các số đã tròn của từng dòng (không phải tròn tổng)', sum(num(r['tong']) for r in dom) == s['lai'] == 18532601)
        await shot('03_bang_VXT')
        await pg.locator('[data-testid="gd14-calc-sum"]').scroll_into_view_if_needed(); await shot('04_thanh_tong')

        # cuộn ngang + cột ghim
        _cols = pg.locator('[data-testid="gd14-calc-cols"]')
        if await _cols.count() and pg.viewport_size['width'] < 600:
            print('SKIP ' + T + 'M8 cuộn ngang + cột ghim — HM-13: điện thoại hiển thị mỗi khoản thành thẻ, không còn bảng cuộn ngang')
        else:
            if await _cols.count(): await _cols.click(); await pg.wait_for_timeout(200)  # HM-13: kiểm ở chế độ Đầy đủ cột
            sc = pg.locator('[data-testid="gd14-calc-scroll"]')
            name0 = pg.locator('[data-testid="gd14-calc-row"]').first.locator('td.s1')
            await sc.scroll_into_view_if_needed()
            x0 = (await name0.bounding_box())['x']
            sw = await sc.evaluate('e => [e.scrollWidth, e.clientWidth]')
            await sc.evaluate('e => { e.scrollLeft = e.scrollWidth; }'); await pg.wait_for_timeout(200)
            x1 = (await name0.bounding_box())['x']
            tong_vis = await pg.locator('[data-testid="gd14-calc-row"]').first.locator('[data-testid="gd14-calc-tong"]').bounding_box()
            box = await sc.bounding_box()
            ok(T + 'M8 bảng cuộn ngang được + cột TÊN KH ghim (x không đổi) + cột tổng hiện ra', sw[0] > sw[1] and abs(x1 - x0) < 1 and tong_vis['x'] + tong_vis['width'] <= box['x'] + box['width'] + 1, (sw, x0, x1, tong_vis, box))
            await shot('05_cuon_ngang')
            await sc.evaluate('e => { e.scrollLeft = 0; }')
            if await _cols.count(): await pg.locator('[data-testid="gd14-calc-cols"]').click(); await pg.wait_for_timeout(200)

        # tick / bỏ tick
        await pg.locator('[data-testid="gd14-calc-tick"]').first.uncheck(); await pg.wait_for_timeout(200)
        s = await summary(pg); t2 = [False] + [True] * 9
        ok(T + 'M9 bỏ tick khoản 1 → 9 khoản, lãi = Python', s['tick'] == 9 and s['lai'] == exp_total(exp, t2) == 18532601 - 2893151, s)
        ok(T + 'M9b dòng bỏ tick vẫn hiện số nhưng mờ', 'off' in (await pg.locator('[data-testid="gd14-calc-row"]').first.get_attribute('class')))
        await pg.check('[data-testid="gd14-calc-tickall"]'); await pg.wait_for_timeout(200)
        ok(T + 'M9c tick tất cả → lại 10 khoản / 18.532.601', (await summary(pg))['lai'] == 18532601 and (await summary(pg))['tick'] == 10)

        # trả gốc vượt dư nợ (V2-L7)
        g1 = pg.locator('[data-testid="gd14-calc-goc"]').nth(0)
        await g1.fill('2000000000'); await g1.press('Enter'); await pg.wait_for_timeout(250)
        v1 = await pg.locator('[data-testid="gd14-calc-goc"]').nth(0).input_value()
        warn = await pg.locator('[data-testid="gd14-calc-goc-warn"]').count()
        s = await summary(pg)
        ok(T + 'M10 nhập trả gốc 2 tỷ > dư nợ 1 tỷ → chặn bằng 1.000.000.000 + cảnh báo', v1 == '1.000.000.000' and warn == 1 and await pg.locator('[data-testid="gd14-calc-goc-note"]').count() == 1, (v1, warn))
        ok(T + 'M10b tổng thu = trả gốc + lãi', s['goc'] == 1000000000 and s['thu'] == 1000000000 + 18532601, s)
        g2 = pg.locator('[data-testid="gd14-calc-goc"]').nth(1)
        await g2.fill('200.000.000'); await g2.press('Enter'); await pg.wait_for_timeout(250)
        s = await summary(pg)
        ok(T + 'M10c thêm trả gốc 200.000.000 khoản 2 → gốc 1,2 tỷ; thu = gốc + lãi', s['goc'] == 1200000000 and s['thu'] == 1200000000 + 18532601 and s['lai'] == 18532601, s)
        await pg.locator('[data-testid="gd14-calc-goc-warn"]').scroll_into_view_if_needed(); await shot('06_tra_goc_vuot_du_no')

        # copy kết quả
        await pg.click('[data-testid="gd14-calc-copy"]'); await pg.wait_for_timeout(400)
        clip = await pg.evaluate('navigator.clipboard.readText()')
        ok(T + 'M11 Copy kết quả → bộ nhớ tạm có KH, 10 dòng, tổng gốc/lãi/thu', 'Khách hàng: Vũ Xuân Tuấn' in clip and 'Tổng lãi phải thu: 18.532.601 đồng' in clip
           and 'Tổng trả gốc: 1.200.000.000 đồng' in clip and 'Tổng thu: 1.218.532.601 đồng' in clip and clip.count('\n10. ') == 1, clip[:400])
        ok(T + 'M11b báo đã chép', 'Đã chép' in (await pg.locator('[data-testid="gd14-calc-toast"]').inner_text()))

        # reset
        await pg.locator('[data-testid="gd14-calc-tick"]').nth(2).uncheck(); await pg.wait_for_timeout(150)
        await pg.click('[data-testid="gd14-calc-reset"]'); await pg.wait_for_timeout(250)
        s = await summary(pg)
        vals = [await pg.locator('[data-testid="gd14-calc-goc"]').nth(i).input_value() for i in range(2)]
        ok(T + 'M12 Reset bảng → bỏ trả gốc, tick lại đủ 10, lãi 18.532.601', s == {'tick': 10, 'goc': 0, 'lai': 18532601, 'thu': 18532601} and vals == ['', ''] and await pg.locator('[data-testid="gd14-calc-goc-warn"]').count() == 0, (s, vals))
        await shot('07_sau_reset')

        # đổi ngày chốt: 10/11/2026 và 20/04/2027 (9 khoản qua hạn 10/04/2027 → tách quá hạn × 1,5)
        for d0 in (date(2026, 11, 10), date(2027, 4, 20)):
            await set_chot(pg, d0)
            e2 = EXP(D.VXT, d0); dom2 = await read_rows(pg); bad = compare(dom2, e2); s = await summary(pg)
            ok(T + f'M13 chốt {d0:%d/%m/%Y} → mọi ô khớp Python, tổng {VN(exp_total(e2))}', not bad and s['lai'] == exp_total(e2), (bad, s, exp_total(e2)))
        nqh = sum(1 for r in await read_rows(pg) if 'qh' in r['cls'].split())
        ok(T + 'M13b chốt 20/04/2027: 9 dòng quá hạn tô đỏ (khoản 28/08/2029 vẫn trong hạn)', nqh == 9, nqh)
        await pg.locator('[data-testid="gd14-calc-row"]').first.scroll_into_view_if_needed()
        await pg.locator('[data-testid="gd14-calc-scroll"]').evaluate('e => { e.scrollLeft = e.scrollWidth; }')
        await shot('08_chot_20-04-2027_qua_han')
        await pg.locator('[data-testid="gd14-calc-scroll"]').evaluate('e => { e.scrollLeft = 0; }')
        await pg.click('[data-testid="gd14-calc-homnay"]'); await pg.wait_for_timeout(250)
        today = await pg.evaluate("new Date(window.QLTDLai.todayUTC()).toISOString().slice(0,10)")
        tdate = date.fromisoformat(today); e3 = EXP(D.VXT, tdate)
        ok(T + f'M14 nút Hôm nay → chốt {today}, số liệu khớp Python', (await pg.locator('[data-testid="gd14-calc-chot"]').input_value()) == today and not compare(await read_rows(pg), e3) and (await summary(pg))['lai'] == exp_total(e3))

        # ca quá hạn bắt buộc (V2-L1/L2/L4)
        await set_chot(pg, CHOT)
        await pick(pg, 'tran qua', 'Trần Quá Hạn')
        eq = EXP('Trần Quá Hạn', CHOT); dq = await read_rows(pg)
        ok(T + 'M15 ca quá hạn: TH 7 ngày 1.687.671 + QH 5 ngày 1.205.479 + phạt 602.740 = 3.495.890 (khớp Python)', not compare(dq, eq) and dq[0]['tong'] == '3.495.890' and dq[0]['laith'] == '1.687.671'
           and dq[0]['songayqh'] == '5 ngày' and '1.205.479 + phạt 602.740' in dq[0]['laiqh'] and (await summary(pg))['lai'] == 3495890, (dq, compare(dq, eq)))
        ok(T + 'M15b quá hạn xét theo đến hạn khoản GN r[7]=29/10/2026, không theo HĐTD 10/04/2027', dq[0]['denhan'].startswith('29/10/2026') and 'HĐTD: 10/04/2027' in dq[0]['denhan'] and 'qh' in dq[0]['cls'].split())
        ct = await pg.locator('[data-testid="gd14-calc-chitiet"]').inner_text()
        ok(T + 'M15c chú giải chiTiet hiển thị thành phần tính', 'Trong hạn: 1.000.000.000 × 8,8% × 7/365 = 1.687.671 đ' in ct and 'Quá hạn (cơ bản)' in ct and 'Phạt lãi quá hạn (50%)' in ct and '= 3.495.890 đ' in ct, ct[:400])
        mt = await pg.locator('[data-testid="gd14-calc-overlay"]').inner_text()
        hd = await pg.locator('[data-testid="gd14-calc-table"] thead').inner_text()
        ok(T + 'M16 không còn 4,25%/năm; cột quá hạn ghi "LS × 1,5"', '4,25' not in mt and '4.25' not in mt and 'LS × 1,5' in hd, hd)
        await pg.locator('[data-testid="gd14-calc-scroll"]').scroll_into_view_if_needed()
        await pg.locator('[data-testid="gd14-calc-scroll"]').evaluate('e => { e.scrollLeft = e.scrollWidth; }')
        await shot('09_ca_qua_han_3.495.890')
        await pg.locator('[data-testid="gd14-calc-chitiet"]').scroll_into_view_if_needed(); await shot('10_chu_giai_qua_han')

        # ca không tính được (V2-L5)
        await pick(pg, 'le loi', 'Lê Lỗi Dữ Liệu')
        el_ = EXP('Lê Lỗi Dữ Liệu', CHOT); dl = await read_rows(pg); s = await summary(pg)
        note = await pg.locator('[data-testid="gd14-calc-loi-note"]').inner_text() if await pg.locator('[data-testid="gd14-calc-loi-note"]').count() else ''
        ok(T + 'M17 khoản lỗi: xám + "Không tính được — lý do" (mốc sau ngày chốt; thiếu lãi suất)', not compare(dl, el_) and sum(1 for r in dl if r['ok'] == '0') == 2
           and any('trước mốc tính lãi' in (r['loi'] or '') for r in dl) and any('Lãi suất không đọc được' in (r['loi'] or '') for r in dl), dl)
        ok(T + 'M17b không cộng khoản lỗi vào tổng + có thông báo rõ', s['tick'] == 3 and s['lai'] == exp_total(el_) and '2 khoản đã tick KHÔNG tính được' in note, (s, exp_total(el_), note))
        await pg.locator('[data-testid="gd14-calc-scroll"]').scroll_into_view_if_needed()
        await pg.locator('[data-testid="gd14-calc-scroll"]').evaluate('e => { e.scrollLeft = e.scrollWidth; }')
        await shot('11_khoan_khong_tinh_duoc')

        # tính tay — ca quá hạn + ca mockup khoản 1
        await pg.click('[data-testid="gd14-calc-tab-tay"]'); await pg.wait_for_timeout(200)
        await pg.fill('[data-testid="gd14-calc-m-duno"]', '1.000.000.000')
        await pg.fill('[data-testid="gd14-calc-m-ls"]', '8,8')
        await pg.fill('[data-testid="gd14-calc-m-moc"]', '2026-10-22')
        await pg.fill('[data-testid="gd14-calc-m-mat"]', '2026-10-29'); await pg.wait_for_timeout(250)
        g = lambda t: pg.locator(f'[data-testid="gd14-calc-m-{t}"]').inner_text()
        mres = (await g('laith'), await g('qhcb'), await g('qhphat'), await g('tong'))
        ok(T + 'M18 tính tay ca quá hạn = 1.687.671 / 1.205.479 / 602.740 / 3.495.890', mres == ('1.687.671 đ', '1.205.479 đ', '602.740 đ', '3.495.890 đ'), mres)
        await shot('12_tinh_tay_qua_han')
        await pg.click('[data-testid="gd14-calc-copy"]'); await pg.wait_for_timeout(300)
        clip = await pg.evaluate('navigator.clipboard.readText()')
        ok(T + 'M18b Copy ở tab tính tay', 'TỔNG LÃI: 3.495.890 đ' in clip, clip)
        await pg.fill('[data-testid="gd14-calc-m-mat"]', ''); await pg.wait_for_timeout(250)
        ok(T + 'M19 tính tay không có ngày đến hạn → 12 ngày trong hạn = 2.893.151 (khoản 1 mockup)', (await g('tong')) == '2.893.151 đ')
        await pg.fill('[data-testid="gd14-calc-m-moc"]', '2026-11-20'); await pg.wait_for_timeout(250)
        ok(T + 'M19b tính tay mốc sau ngày chốt → báo "Không tính được"', 'Không tính được' in (await g('loi')))
        await pg.click('[data-testid="gd14-calc-reset"]'); await pg.wait_for_timeout(200)
        ok(T + 'M19c Reset ở tab tính tay xoá ô nhập', (await pg.locator('[data-testid="gd14-calc-m-duno"]').input_value()) == '')

        # đóng: nút Đóng, phím Esc, nút ×
        await pg.click('[data-testid="gd14-calc-close"]'); await pg.wait_for_timeout(150)
        c1 = await pg.locator('[data-testid="gd14-calc-overlay"]').count()
        await pg.click('[data-testid="gd14-calc"]'); await pg.wait_for_timeout(200); await pg.keyboard.press('Escape'); await pg.wait_for_timeout(150)
        c2 = await pg.locator('[data-testid="gd14-calc-overlay"]').count()
        await pg.click('[data-testid="gd14-calc"]'); await pg.wait_for_timeout(200); await pg.click('[data-testid="gd14-calc-x"]'); await pg.wait_for_timeout(150)
        c3 = await pg.locator('[data-testid="gd14-calc-overlay"]').count()
        ok(T + 'M20 đóng bằng Đóng / Esc / ×', (c1, c2, c3) == (0, 0, 0), (c1, c2, c3))

        # V2-L6: dòng dư nợ 0 không đếm (gọi trực tiếp với dữ liệu tổng hợp vì bộ nhập đã loại dòng dư nợ 0)
        await pg.evaluate("""() => {
          const base = (bal, ds) => ['3201','KH Đếm Dư Nợ','HD1','','',0,'01/09/2026','01/09/2027',8.8,0,0,bal,'','Vay ngắn hạn (TK 211)','','',0,'','','HD1',ds,'','','22/10/2026','01/09/2027','',''];
          window.GD14.openCalc([base(100000000,'A'), base(0,'B'), base(250000000,'C'), base(-5,'D')], {chot:'2026-11-03'});
        }""")
        await pick(pg, 'dem du', 'KH Đếm Dư Nợ')
        sk = (await pg.locator('[data-testid="gd14-calc-sokhoan"]').inner_text()).strip()
        dd = await read_rows(pg); s = await summary(pg)
        e100 = D.lai(100000000, '8.8', '22/10/2026', '01/09/2026', '01/09/2027', CHOT)['tong']; e250 = D.lai(250000000, '8.8', '22/10/2026', '01/09/2026', '01/09/2027', CHOT)['tong']
        ok(T + 'M21 "khoản còn dư nợ" chỉ đếm dư nợ > 0 (2/4) + tổng dư nợ 350.000.000', sk == '2 khoản vay còn dư nợ' and (await pg.locator('[data-testid="gd14-calc-tongduno"]').inner_text()).strip() == '350.000.000 đồng', sk)
        ok(T + 'M21b dòng dư nợ ≤ 0 mặc định không tick, xám + lý do; tổng = 2 khoản', [r['tick'] for r in dd] == [True, True, False, False] and [r['ok'] for r in dd] == ['1', '1', '0', '0']
           and s['lai'] == e100 + e250 and 'Dư nợ' in (dd[2]['loi'] or ''), (dd, s))
        await pg.click('[data-testid="gd14-calc-close"]')

        ok(T + 'M22 không lỗi console / runtime trong toàn bộ luồng', not errs, errs)
    finally:
        await b.close()

async def main():
    async with async_playwright() as p:
        await run(p, 'mobile', 390, 844)
        await run(p, 'desktop', 1280, 1800)
    print('\n' + str(sum(res)) + '/' + str(len(res)) + ' ca đạt')
    if sum(res) != len(res): sys.exit(1)

asyncio.run(main())
