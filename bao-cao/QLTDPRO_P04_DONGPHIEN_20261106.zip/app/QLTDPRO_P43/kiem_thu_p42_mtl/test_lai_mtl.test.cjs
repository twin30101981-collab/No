// Bộ kiểm lõi bổ sung cho Máy tính lãi (v24.15.0) — chạy trên nguon_P41/qltd_lai.cjs (KHÔNG sửa lõi).
// Chạy: node kiem_thu_p42_mtl/test_lai_mtl.test.cjs
"use strict";
const path = require("path");
const L = require(path.join(__dirname, "..", "nguon_P41", "qltd_lai.cjs"));
let pass = 0, fail = 0;
function ok(name, cond, info) {
  if (cond) { pass++; console.log("PASS  " + name); } else { fail++; console.log("FAIL  " + name + " — " + JSON.stringify(info)); }
}
const row = (duno, ls, moc, mat) => ({ 6: "2026-06-01", 7: mat, 8: ls, 11: duno, 23: moc });
const CHOT = "2026-11-03";

// Ca mockup Vũ Xuân Tuấn: 10 khoản trong hạn, đã thu lãi đến 22/10/2026, chốt 03/11/2026
const VXT = [[1e9, 8.8, 2893151], [5e8, 8.8, 1446575], [5e8, 8.8, 1446575], [5e8, 8.8, 1446575], [6.5e8, 8.8, 1880548],
             [7e8, 9.5, 2186301], [7e8, 8.8, 2025205], [7e8, 8.8, 2025205], [5.5e8, 8.8, 1591233], [5.5e8, 8.8, 1591233]];
let tong = 0, tho = 0, allOk = true;
VXT.forEach(([d, ls, want], i) => {
  const mat = ls === 9.5 ? "2029-08-28" : "2027-04-10";
  const k = L.tinhLaiKhoan(row(d, ls, "2026-10-22", mat), { chot: CHOT });
  if (!(k.ok && k.soNgayTH === 12 && k.soNgayQH === 0 && k.tong === want)) { allOk = false; console.log("  lệch khoản", i + 1, k); }
  tong += k.tong; tho += d * (ls / 100) * 12 / 365;
});
ok("MTL1 mockup: 10 khoản đúng từng khoản (12 ngày trong hạn)", allOk);
ok("MTL2 mockup: tổng cộng các số đã tròn = 18.532.601", tong === 18532601, tong);
ok("MTL3 nếu tròn SAU khi cộng sẽ ra 18.532.603 (lệch 2 đ) — lõi KHÔNG làm vậy", Math.round(tho) === 18532603 && tong !== Math.round(tho), Math.round(tho));

// Ca quá hạn bắt buộc: đến hạn khoản GN 29/10/2026
const q = L.tinhLaiKhoan(row(1e9, 8.8, "2026-10-22", "2026-10-29"), { chot: CHOT });
ok("MTL4 quá hạn: 7 ngày TH = 1.687.671", q.ok && q.soNgayTH === 7 && q.laiTH === 1687671, q);
ok("MTL5 quá hạn: 5 ngày, cơ bản 1.205.479 + phạt 602.740", q.soNgayQH === 5 && q.laiQHCB === 1205479 && q.laiQHPhat === 602740, q);
ok("MTL6 quá hạn: tổng 3.495.890 (V2 cho 2.269.862,78)", q.tong === 3495890, q.tong);
ok("MTL7 lãi QH = LS × 1,5 (không phải 4,25%/năm)", q.laiQH === 1205479 + 602740 && q.heSoQH === 1.5, q);
// cùng khoản nhưng xét theo đáo hạn HĐTD (apprmatdt 10/04/2027) sẽ sai — lõi dùng r[7]
const qHD = L.tinhLaiKhoan({ 6: "2026-04-29", 7: "2026-10-29", 8: 8.8, 11: 1e9, 23: "2026-10-22", 24: "2027-04-10" }, { chot: CHOT });
ok("MTL8 có r[24]=10/04/2027 vẫn tách quá hạn theo r[7] (V2-L4)", qHD.tong === 3495890 && qHD.soNgayQH === 5, qHD);

// Ngày chốt trước mốc
const e = L.tinhLaiKhoan(row(3e8, 8.8, "2026-11-10", "2027-09-01"), { chot: CHOT });
ok("MTL9 chốt trước mốc → ok:false + lý do (không bỏ qua im lặng)", !e.ok && /trước mốc tính lãi/.test(e.lyDo), e);
const z = L.tinhLaiKhoan(row(0, 8.8, "2026-10-22", "2027-09-01"), { chot: CHOT });
ok("MTL10 dư nợ 0 → ok:false (không tính, không đếm còn dư nợ)", !z.ok && /Dư nợ/.test(z.lyDo), z);
const n = L.tinhLaiKhoan(row(4e8, "", "2026-10-01", "2027-09-01"), { chot: CHOT });
ok("MTL11 thiếu lãi suất → ok:false + lý do", !n.ok && /Lãi suất không đọc được/.test(n.lyDo), n);

console.log("\n" + pass + "/" + (pass + fail) + " ca đạt");
process.exit(fail ? 1 : 0);
