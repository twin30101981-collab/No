# P53 · v24.17.9 — Sửa gốc rễ: "Nạp từ Lưu trữ" làm mất / sai doanh số giải ngân (ngày dd/mm bị đảo thành mm/dd)
# Gốc rễ: trang Khách hàng mới đọc tệp bằng thao tác worker "head" -> XLSX.read(...) KHÔNG có raw:true.
#   Khối "Nạp từ Lưu trữ" ghi dư nợ ra CSV trung gian (đuôi .xls) rồi nạp qua đúng đường đọc tệp.
#   SheetJS đọc CSV mà không có raw:true thì ĐOÁN kiểu ô theo kiểu Mỹ: "05/10/2026" -> 10/05, "03/11/2026" -> 11/03
#   (ngày <= 12 bị đảo; ngày > 12 vẫn là chuỗi nên đúng). Món GN ngày 05/10, 03/11... rơi khỏi kỳ => cột Giải ngân thiếu
#   dù dư nợ cuối kỳ vẫn có. Mã số cũng bị ép thành số (mất số 0 đầu) => khóa brcd|apprseq|dsbsseq lệch với bản quét giữa kỳ.
#   (Đường Nhập dữ liệu dùng ipcasRows có raw:true nên không bị.)
# Cách sửa (tối thiểu, đúng chỗ): thêm cờ txt cho thao tác "head" -> đọc văn bản thô (raw:true, giữ nguyên chuỗi);
#   chỉ trang Khách hàng mới (hàm em) bật cờ. Tệp xlsx/xls nhị phân không đổi hành vi.
SRC='app/QLTDPRO_v24.17.8.html'; DST='app/QLTDPRO_v24.17.9.html'
s=open(SRC,encoding='utf-8').read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n,('anchor count',c,n,old[:90]); s=s.replace(old,new)
# 1) worker + module: head đọc raw khi có cờ txt
rep('r.head=function(a,i,s){s=s||{};var l=a.read(i,{type:"array",sheetRows:s.rows||2,dense:!0,cellText:!1})',
    'r.head=function(a,i,s){s=s||{};var l=a.read(i,{type:"array",sheetRows:s.rows||2,dense:!0,cellText:!1,raw:!!s.txt})')
# 2) cầu nối: Zh nhận thêm tham số thứ 5 (txt)
rep('Zh=(e,t=2,n=!0,r="")=>El("head",{buf:e,o:{rows:t,raw:n,defval:r}})',
    'Zh=(e,t=2,n=!0,r="",x)=>El("head",{buf:e,o:{rows:t,raw:n,defval:r,txt:!!x}})')
# 3) trang Khách hàng mới đọc tệp ở chế độ văn bản thô
rep('async function em(e,t){const n=await Zh(t,2e6,!0,null);','async function em(e,t){const n=await Zh(t,2e6,!0,null,!0);')
# 4) Nhãn phiên bản
rep('24.17.8','24.17.9',s.count('24.17.8'))
open(DST,'w',encoding='utf-8').write(s)
for f in ('app/sw.js','app/manifest.json'):
    t=open(f,encoding='utf-8').read().replace('24.17.8','24.17.9').replace('p52-','p53-')
    open(f,'w',encoding='utf-8').write(t)
print('OK',DST)
