import json,time
from playwright.sync_api import sync_playwright
URL='http://localhost:8765/QLTDPRO_v24.17.9.html'
with sync_playwright() as p:
    b=p.chromium.launch(); 
    for name,vp in (('desktop',{'width':1366,'height':768}),('mobile',{'width':390,'height':844})):
        ctx=b.new_context(viewport=vp); pg=ctx.new_page()
        errs=[];fails=[];cons=[]
        pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
        pg.on('console',lambda m:cons.append((m.type,m.text[:160])) if m.type in('error','warning') else None)
        pg.on('requestfailed',lambda r:fails.append(r.url[:120]))
        t=time.time(); pg.goto(URL,wait_until='load'); pg.wait_for_timeout(2500)
        print(name,'load ms',int((time.time()-t)*1000),'pageerror',errs,'requestfailed',fails,'console',cons[:6])
        info=pg.evaluate("""()=>{const t=e=>(e.innerText||'').trim().replace(/\\s+/g,' ').slice(0,40);
        const nav=[...document.querySelectorAll('nav a,nav button,aside a,aside button,[role=tab],[role=menuitem],header button')].map(t).filter(Boolean);
        return {title:document.title,hash:location.hash,nav:[...new Set(nav)].slice(0,60),btn:document.querySelectorAll('button').length,inp:document.querySelectorAll('input').length,sw:('serviceWorker' in navigator),body:document.body.innerText.slice(0,300).replace(/\\s+/g,' ')}}""")
        print(json.dumps(info,ensure_ascii=False)[:1400])
        pg.screenshot(path=f'baseline_{name}_mo_dau.png')
        ctx.close()
    b.close()
