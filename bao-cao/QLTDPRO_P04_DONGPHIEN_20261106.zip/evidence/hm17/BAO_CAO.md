# HM-17 — Trang Khách hàng mới tính trùng giải ngân khi khế ước đổi HĐTD (P03, 05/11/2026) — P0

**Bản:** app/QLTDPRO_P43/app/QLTDPRO_v24.17.13.html (sha256 5429e960…719b7ba3), dựng bằng `nguon_P02/build_p03_hm17.py` từ v24.17.12.
**Phát hiện:** tệp người dùng xuất từ app (Báo cáo giải ngân 01/01–31/10/2026): 7.057 món / 4.538,67 tỷ, trong đó 1.115 khế ước có 2–3 dòng (cùng số tiền, khác Số HĐ/HM) → thừa 1.116 món / 638,76 tỷ; Thu nợ ở Đối soát cũ thừa theo.
**Nguyên nhân gốc:** `buildReport` (bundle) thêm "khế ước tất toán trong kỳ" từ các mốc MIS80 giữa kỳ khi khóa brcd|apprseq|dsbsseq không có ở mốc cuối; `gd11.loadMidSnaps` cũng gom theo khóa đó. Khế ước đổi HĐTD giữ dsbsseq nhưng đổi apprseq → mỗi HĐTD cũ thành một dòng "tất toán" thêm.
**Sửa (2 điểm, vá chuỗi đếm số lần):** khóa = số khế ước (dsbsseq; rỗng → khóa cũ) ở `midKey` (gd11) và phép so với mốc cuối trong `buildReport`. Dấu tích "Chuyển KH vay mới" (localStorage) giữ khóa cũ → không mất tích đã đánh. Ảnh hưởng mọi tab + Excel xuất vì cùng dùng kết quả buildReport.
**Chưa đổi (ghi rõ):** khế ước tất toán trong kỳ vẫn gán cán bộ ở mốc cuối nó xuất hiện (bảng Đối soát gd15 dùng quy tắc cán bộ cuối kỳ của KH).

## Kiểm chứng (V3 Chromium 153)
| Lệnh | Bản | Kết quả |
|---|---|---|
| `python3 kiem_thu_p03/test_hm17_trung_gn.py app/QLTDPRO_v24.17.12.html` (dữ liệu thử, 3 khế ước đổi HĐTD) | v24.17.12 | 2/5 — tái hiện: 113 dòng / 110 khế ước, 3 lặp; KPI 113 món |
| cùng lệnh | v24.17.13 | **5/5** — 110 dòng = 110 khế ước, KPI 110 món, 0 pageerror |
| cùng lệnh, MIS_DIR = 11 tệp msit80 thật (thư mục tạm, không lưu log) | v24.17.13 | **5/5** — 1.154 khế ước đổi HĐTD; Chi tiết 5.957 dòng = 5.957 khế ước; KPI Doanh số cho vay 3.901.317.839.311 đ / 5.957 món (trước: 4.538,67 tỷ / 7.057 món) |
| `kiem_thu_chung/chay_hoi_quy.py --app app/QLTDPRO_v24.17.13.html` | v24.17.13 | PASS 828 · FAIL 1 · LỆCH PB 12 · SKIP 2 (thêm p03_hm11b 25, p03_hm17 5). FAIL duy nhất: p52 R2 — mã băm ngẫu nhiên trong title ở #/nhap-du-lieu chứa 13 chữ số liền; chạy lại riêng p52 hai lần: 14/14 cả hai → ca chập chờn có sẵn, không do HM-17 |

Chênh 16 món so với bản người dùng xuất đã bỏ trùng (5.941): bản người dùng lập trên Lưu trữ của máy họ (có thể nhiều mốc hơn 11 mốc cuối tháng) — cần người dùng xác nhận khi kiểm tay.
