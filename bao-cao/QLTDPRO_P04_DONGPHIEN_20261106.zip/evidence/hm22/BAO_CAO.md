# HM-22 — Tài sản bảo đảm: cột Số HĐ thế chấp, Số giải ngân, Địa chỉ TS — BÁO CÁO (P04, 06/11/2026)

Bản: **v24.17.24 → v24.17.25** (`app/QLTDPRO_P43/nguon_P04/build_p04_hm22.py`). Bậc đạt: **V3** (dữ liệu thử ẩn danh). Quyết định người dùng 06/11: số giải ngân "Ghép từ msit80".

## Thay đổi (chỉ trang #/tai-san-bao-dam)
- Cột mới: **Số TS** (clno), **Số HĐ thế chấp** (plgno — dạng LCA3201…), **Số giải ngân (còn dư nợ)**: các số khế ước (dsbsseq, LCL…) **còn dư nợ > 0** của khách hàng trong tệp dư nợ hiện hành — ghép theo mã KH; không khớp mã KH thì theo mã chủ TS; tài sản chỉ ghép được theo TÊN thì để trống (tránh nhầm khách trùng tên). Nhiều khế ước → liệt kê cách nhau dấu phẩy (Xuất Excel lấy đủ).
- Cột "Địa chỉ / mô tả" đổi tên **Địa chỉ TS** (clloc).
- Bộ cột mặc định: … Mã KH → **Số HĐ thế chấp → Số giải ngân → Địa chỉ TS** → Loại TS … Bố cục bảng đã lưu trước đây chuyển sang bộ mới **một lần** (cờ `l22`); sau đó người dùng chỉnh tự do ở "Cột ▾".
- Không đổi cách tính trạng thái (Còn dư nợ / Đã tất toán / Không có hồ sơ trong DATA), không đổi dữ liệu lưu.

## Kiểm chứng — `python3 kiem_thu_p04/test_hm22_ts_cot.py app/QLTDPRO_v24.17.25.html` — **6/6**
Tệp TSBĐ thử sinh từ tệp dư nợ thử 31/10/2026 (đáp án Python độc lập): 6 khách nhiều khế ước (ghép mã KH), 1 tài sản ghép theo mã chủ TS, 3 tài sản của khách chưa có trong dư nợ.
| Ca | Kết quả |
|---|---|
| T1 / T1b | Có 3 cột mặc định, thứ tự ngay sau Mã KH: hdtc, sogn, dc |
| T2 | 10/10 tài sản: Số giải ngân = tập khế ước còn dư nợ (Python), Số HĐ thế chấp, Địa chỉ TS đúng |
| T3 | Khách chưa có trong dư nợ: Số GN trống, trạng thái "Không có hồ sơ trong DATA" |
| T4 | Bố cục cũ đã lưu (ẩn 3 cột, không cờ) → tải lại hiện cột mới |
| E1 | 0 pageerror |
| Cùng bộ trên v24.17.24 | 1/5 — FAIL T1–T4 |
| Hồi quy chung v24.17.25 | 1313 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ) |
Ảnh: `anh/desktop_ts.png`.
