# HM-20 — Chỉ tiêu kế hoạch — BÁO CÁO (P04, 05/11/2026)

Bản: **v24.17.20 → v24.17.21** (`app/QLTDPRO_P43/nguon_P04/build_p04_hm20.py`, lớp vá `nguon_P04/gd20.js`). Bậc đạt: **V3 (dữ liệu thử ẩn danh 3 mốc 30/09, 15/10, 31/10/2026 nạp qua #/nhap)**.

## 1. Thay đổi
| Điểm nghẽn | Làm |
|---|---|
| C-03 nhãn mốc lệch kỳ (Q14) | Mốc gắn theo ngày CUỐI kỳ (30/09 → "quý 3", 31/10 → "tháng 10") nhưng bảng ghi "Đầu Q3", "Đầu T10". Nay ghi **"Đầu Q4/2026 (số dư 30/09/2026)"**, **"Đầu T11/2026 (số dư 31/10/2026)"**; cột Δ ghi "Đầu Q4 (số dư cuối Q3)". Cột **"Δ so Đầu tháng"** so với số dư cuối tháng TRƯỚC (trước đây tìm mốc cuối tháng hiện tại — thường chưa có nên cột không hiện). Tab Báo cáo ngày vốn đã đúng (EoM1/EoQ1/EoY1), không đổi. |
| C-02 gom phòng (Q13) | Dòng "Tổng <phòng>", tab Theo phòng và Δ theo phòng gom dư nợ theo **phòng ghi trên khế ước** (trctnm r[17]); khế ước không ghi phòng → theo danh mục cán bộ như cũ. Kế hoạch (KH) phòng vẫn cộng từ KH cán bộ theo danh mục. Ghi chú trên trang. |
| C-01 48 cột, cột tên không dính | Lớp gd20 (chỉ trình bày, không sửa React): thanh **Nhóm chỉ tiêu** (Dư nợ – mặc định / Nguồn vốn / KH & thẻ / Dịch vụ / Tất cả), **Chỉ Live/%HT**, **Δ so mốc** (mặc định tắt), **Ẩn chỉ tiêu toàn 0** (mặc định bật, liệt kê chỉ tiêu bị ẩn); cột CBTD/Đơn vị và tiêu đề dính khi cuộn; lựa chọn nhớ ở localStorage `gd20_ctkh`. |
| C-04 | Chỉ tiêu chưa có nguồn (Nguồn vốn, Thẻ, Dịch vụ, ABIC) tự ẩn khi toàn 0. |
| C-05 điện thoại | ≤ 600 px: mỗi CBTD / phòng một thẻ (nhãn – giá trị), nút nhóm ≥ 40 px. |

## 2. Kiểm chứng
| Bộ | Kết quả |
|---|---|
| `python3 kiem_thu_p04/test_hm20_ctkh.py app/QLTDPRO_v24.17.21.html` (1366×768 + 390×844) | **27/27**, 0 pageerror. Nhãn mốc + số ở cột mốc = Σ dư nợ tệp 30/09 (2.245.115.285.000) và 31/10 (1.767.464.001.000); Δ chi nhánh so đầu Q4 = −477.651.284.000, so đầu T11 = 0; Live 3 phòng = Σ khế ước theo trctnm (580.498.066.000 / 586.551.500.000 / 600.414.435.000), Σ = chi nhánh; mặc định vừa 1366; "Tất cả" cuộn ngang vẫn thấy tên; Chỉ Live/%HT; thẻ điện thoại không tràn |
| Cùng bộ trên v24.17.20 | FAIL ngay Q14a (nhãn "Đầu Q3/2026", "Đầu T10/2026") rồi dừng |
| Hồi quy chung v24.17.21 | 1252 PASS · 1 FAIL (p52_ma_kh R2 chập chờn đã biết — mã băm hex trong title #/nhap-du-lieu; chạy lại: lần 1 vẫn FAIL đúng ca R2 với mã băm khác, lần 2 đạt 14/0 — lỗi bộ kiểm, không do HM-20) ⇒ 0 FAIL do HM-20; LOI_MT p41/p42_gd14 như cũ |
Ảnh: `evidence/hm20/anh/`; số đo trước: `evidence/hm20/truoc/do_dac_ctkh.json`.

## 3. Ghi chú / còn mở
- Theo Q13, dòng Tổng phòng (theo khế ước) có thể khác tổng các CBTD xếp dưới nó (theo danh mục cán bộ). Dữ liệu thử: danh mục chỉ có 1 CBTD ở Phòng Khách hàng, 0 ở PGD HBT, 6 ở PGD Số 2 → nếu muốn xếp CBTD theo phòng của khế ước, cần quyết định thêm (một CBTD có khế ước ở nhiều phòng).
- Xuất Excel/Word của trang chưa thêm cột kiểm tra (để hạng mục sau nếu cần).

## 4. HM-20b — v24.17.22 (05/11): xếp cán bộ theo phòng GIỐNG Báo cáo ngày (yêu cầu người dùng, thay Q13 cũ)
- `nguon_P04/build_p04_hm20b.py`: dòng "Tổng <phòng>", tab Theo phòng và Δ theo phòng trở lại gom theo **phòng của cán bộ trong danh mục cán bộ** — đúng cách tab Báo cáo ngày làm (phòng = cộng các cán bộ thuộc phòng; dư nợ cán bộ = khế ước có ofcnm của cán bộ). Bỏ cách gom theo trctnm của v24.17.21. Nhãn mốc Q14 và gd20 giữ nguyên (gd20 1.1.0 chỉ đổi ghi chú).
- Kiểm `test_hm20_ctkh.py app/QLTDPRO_v24.17.22.html`: **31/31** — X1 thứ tự phòng → cán bộ của Chỉ tiêu kế hoạch trùng Báo cáo ngày (Phòng Khách hàng: Lê Văn CB; PGD HBT: không có cán bộ; PGD Số 2: 6 cán bộ); X2 Live từng cán bộ = Σ khế ước theo ofcnm (Python), Tổng phòng = cộng cán bộ; X3 Σ phòng = Σ khế ước của cán bộ trong danh mục, chi nhánh = Σ tệp; X4 tab Theo phòng = dòng Tổng phòng; X5 ghi chú.
- Hệ quả cần biết: dư nợ phòng ở trang này nay theo danh mục cán bộ (giống Báo cáo ngày), KHÁC trang Khách hàng mới (gom theo phòng ghi trên khế ước). Trên dữ liệu thử PGD HBT = 0 vì danh mục chưa có cán bộ nào thuộc PGD HBT → cập nhật danh mục cán bộ (Lưu trữ/Cài đặt) để phòng có số.
- Hồi quy chung v24.17.22: 1257 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ)
