# HM-06 — Bố cục bảng rộng trên điện thoại — BÁO CÁO (P04, 05/11/2026)

Bản kiểm: **v24.17.24 — không đổi app** (không có điểm nào có bằng chứng lỗi). Bậc đạt: **V3** (app thật, dữ liệu thử ẩn danh).

## Cách kiểm — `python3 kiem_thu_p04/test_hm06_bo_cuc.py app/QLTDPRO_v24.17.24.html` — **21/21**
- Dữ liệu: 3 mốc thử (30/09, 15/10, 31/10/2026) + tệp 01/11/2026 có 8 dòng tên KH / địa chỉ / cán bộ dài 150–180 ký tự **liền không dấu cách** (thử vỡ bố cục).
- 6 trang × 3 khổ: **1366×768, 390×844, 360×780** (360 = khổ thêm để lộ hồi quy). Trang Giải ngân bấm "Tất cả" để bảng có dữ liệu.
- Đo trên DOM toàn trang (kể cả phần dưới màn hình): (1) tràn ngang cấp tài liệu; (2) phần tử lòi khỏi mép phải mà KHÔNG nằm trong khung cuộn riêng; (3) nút/ô bị che — nếu vật che là thanh cố định/dính thì cuộn ô ra giữa rồi kiểm lại (ô cuộn ra được không tính là bị che); (4) bảng rộng hơn màn hình phải có khung cuộn riêng.

## Kết quả (`do_dac_QLTDPRO_v24.17.24.json`, ảnh `anh/QLTDPRO_v24.17.24/` 18 ảnh)
| Trang | 1366 | 390 | 360 | Ghi chú |
|---|---|---|---|---|
| Giá đất | ✅ | ✅ | ✅ | bảng rộng trong khung cuộn |
| Báo cáo IPCAS | ✅ | ✅ | ✅ | bảng rộng trong khung cuộn ở 390/360 |
| Đối soát số liệu | ✅ | ✅ | ✅ | 2 bảng rộng trong khung cuộn; chữ dài hiện 3 lần |
| Giải ngân (Tất cả) | ✅ | ✅ | ✅ | bảng ảo (div) 3.603 dòng; chữ dài hiện 10 lần, không lòi khung |
| Hồ sơ vay | ✅ | ✅ | ✅ | thanh "Lưu hồ sơ" ghim đáy che ô cuối khi chưa cuộn — cuộn ra được (không phải lỗi) |
| Lưu trữ | ✅ | ✅ | ✅ | bảng rộng trong khung cuộn ở 390/360 |
Tràn ngang cấp tài liệu: **0 px ở cả 18 tổ hợp**; 0 pageerror.

## Giới hạn
- Báo cáo IPCAS, Giá đất, Lưu trữ, Hồ sơ vay không hiển thị tên/địa chỉ khách hàng với dữ liệu thử → phần "chữ dài" chỉ thực sự thử ở Giải ngân và Đối soát.
- Hồ sơ vay chưa mở hồ sơ cụ thể (biểu mẫu chi tiết) — chỉ kiểm màn hình danh sách/biểu mẫu trống.
