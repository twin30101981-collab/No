import re,sys,json,collections
p=sys.argv[1]
src=open(p,encoding='utf-8').read()
lines=src.split('\n')
print('dong',len(lines),'byte',len(src.encode()))
# line length stats
ll=[len(l) for l in lines]
print('dong >5000 ky tu:',sum(1 for x in ll if x>5000),' >50000:',sum(1 for x in ll if x>50000),' max:',max(ll))
# blocks
def blocks(tag):
    out=[]
    for m in re.finditer(r'<%s\b([^>]*)>(.*?)</%s>'%(tag,tag),src,re.S):
        a=src[:m.start()].count('\n')+1; b=a+m.group(0).count('\n')
        out.append((a,b,len(m.group(2)),m.group(1).strip()[:70]))
    return out
for t in ('style','script'):
    bl=blocks(t); print(t,'khoi:',len(bl))
    for a,b,n,at in sorted(bl,key=lambda x:-x[2])[:14]: print('  %s dong %d-%d  %d KB  %s'%(t,a,b,n//1024,at))
print('ngoai script/style:', len(src)-sum(x[2] for x in blocks('style'))-sum(x[2] for x in blocks('script')))
