import json
from playwright.sync_api import sync_playwright
URL='http://localhost:8765/QLTDPRO_v24.17.9.html'
res={};ROUTES=[]
with sync_playwright() as p:
    b=p.chromium.launch()
    for name,vp in (('desktop',{'width':1366,'height':768}),('mobile',{'width':390,'height':844})):
        ctx=b.new_context(viewport=vp); pg=ctx.new_page()
        errs=[];cons=[];bad=[]
        pg.on('pageerror',lambda e:errs.append(str(e)[:160]))
        pg.on('console',lambda m:cons.append(m.text[:140]) if m.type=='error' else None)
        pg.on('response',lambda r:bad.append((r.status,r.url[-60:])) if r.status>=400 else None)
        pg.goto(URL,wait_until='load'); pg.wait_for_timeout(1500)
        routes=ROUTES if name=='mobile' else pg.evaluate("""()=>[...new Set([...document.querySelectorAll('a[href^=\"#/\"]')].map(a=>a.getAttribute('href')))]""")
        if name=='desktop': ROUTES=routes
        if name=='desktop': print('routes',len(routes),routes)
        out=[]
        for r in routes:
            n0=len(errs);c0=len(cons)
            pg.evaluate(f"location.hash='{r}'"); pg.wait_for_timeout(700)
            m=pg.evaluate("""()=>({t:document.title,sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,txt:document.body.innerText.length,
              wide:[...document.querySelectorAll('main *')].filter(e=>{const b=e.getBoundingClientRect();return b.right>innerWidth+2&&b.width>0&&getComputedStyle(e).position!='fixed'}).length})""")
            out.append((r,m['t'][:28],m['sw']-m['cw'],m['wide'],m['txt'],len(errs)-n0,len(cons)-c0))
        res[name]=out
        print(name,'pageerror',errs,'console',cons[:4],'http>=400',bad[:4])
        for o in out: print('  ',o)
        ctx.close()
    b.close()
