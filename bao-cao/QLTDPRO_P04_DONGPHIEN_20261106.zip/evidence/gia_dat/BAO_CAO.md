# Đối soát bảng giá đất 2026 — app QLTDPRO v24.17.19 ↔ Phụ lục 02 (05/11/2026)

**Nguồn đối chiếu**: "2. PL02_ Thành Phố Nam Định (cũ).docx" — Bảng giá đất ở 8 phường TP Nam Định cũ (tỉnh Ninh Bình), kèm Báo cáo tư vấn cập nhật bảng giá đất 275/2026/0019/VFI-BCCN.39.A ngày 16/03/2026 (ZIP người dùng gửi, ghép 2 phần, 52.362.674 byte). Đơn vị nghìn đồng/m²; VT1–VT4 × cao nhất / thấp nhất / trung bình.
**App**: hằng `oS` trong bundle (8 phường, 985 dòng) — trích bằng `kiem_thu_p04/trich_bang_gia_dat.py`.
**Công cụ**: `kiem_thu_p04/doi_soat_gia_dat.py` — ghép theo phường, khóa tên đường | từ | đến (chuẩn hoá), giữ thứ tự dòng. Kết quả: `DOI_SOAT_GIA_DAT_2026_APP_vs_PL02.xlsx` (Tong_hop, Lech_gia, Lech_chu, Chi_trong_app, Chi_trong_PL02, Loi_so_PL02).

## Kết quả
| Phường | App | PL02 | Khớp hoàn toàn | Lệch giá | Lệch chữ | Chỉ PL02 |
|---|---|---|---|---|---|---|
| Nam Định | 373 | 373 | 369 | 0 | 4 | 0 |
| Trường Thi | 113 | 116 | 112 | 0 | 1 | 3 |
| Thiên Trường | 119 | 120 | 119 | 0 | 0 | 1 |
| Đông A | 112 | 115 | 111 | 0 | 1 | 3 |
| Thành Nam | 72 | 74 | 72 | 0 | 0 | 2 |
| Vị Khê | 61 | 65 | 61 | 0 | 0 | 4 |
| Hồng Quang | 48 | 57 | 48 | 0 | 0 | 9 |
| Mỹ Lộc | 87 | 87 | 87 | 0 | 0 | 0 |
| **Tổng** | **985** | **1.007** | **979** | **0 (0 ô)** | **6** | **22** |

- **Giá: 985/985 dòng của app trùng PL02 cả 12 ô (11.820 ô, 0 ô lệch).** Không có dòng nào chỉ có trong app.
- **6 dòng lệch chữ** (giá trùng): PL02 gõ sai, app đã sửa chính tả — "địa phấn", "Đương/Đưỡng Trần…", "khuTĐC", "Đai Thắng", "San bóng". Không cần sửa app.
- **22 dòng chỉ có trong PL02 đều KHÔNG có giá**: 9 dòng tiêu đề nhóm (giá nằm ở các dòng con "tiếp giáp / không tiếp giáp đường sắt"…, 1 dòng có ô `#DIV/0!` của Excel gốc) và 13 dòng ghi "chưa hoàn thiện" (KDC tập trung Đông Phong – Địch Lễ ở Vị Khê 4, Hồng Quang 7; KDC Nam Quang 2). App không thiếu giá nào.
- **1 dòng lỗi số ở nguồn, app mang theo**: Phường Nam Định STT 212 — Đường Vũ Xuân Thiều (đầu → cuối đường): VT1 60.000 / 50.000 / **TB 28.000** (đúng công thức phải là 55.000); VT2 36.000 / 30.000 / **TB 16.800** (phải là 33.000; 16.800 = 28.000 × 0,6). VT3, VT4 đúng. Giá trung bình dùng ở thống kê trang Giá đất → dòng này bị kéo thấp ~49%. **Cần người dùng xác nhận** trước khi sửa app.

## Nghị quyết 38/2025/NQ-HĐND (bảng giá nhà nước)
Phụ lục I (đất ở đô thị, 266 trang, có lớp chữ) là bảng giá nhà nước — mỗi vị trí MỘT giá, thấp hơn nhiều PL02 (vd Trần Hưng Đạo, Trần Nhân Tông → Hàng Thao: NQ38 VT1 22.000; PL02 100.000/70.000). App hiện KHÔNG có bảng giá nhà nước (ô "Giá đất G0" ở TSBĐ nhập tay) → không đối soát được với app; có thể làm thành tính năng mới nếu người dùng cần.
