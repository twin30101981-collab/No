from playwright.sync_api import sync_playwright
URL='http://localhost:8765/QLTDPRO_v24.17.9.html'
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(); pg=ctx.new_page(); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:150]))
    pg.goto(URL); pg.wait_for_timeout(2000)
    reg=pg.evaluate("async()=>{const r=await navigator.serviceWorker.getRegistration();return r?{scope:r.scope,active:!!r.active}:null}")
    keys=pg.evaluate("async()=>await caches.keys()")
    ctx.set_offline(True); pg.reload(wait_until='load'); pg.wait_for_timeout(1500)
    print('SW',reg,'caches',keys,'| offline reload title:',pg.title(),'| pageerror',errs)
    # dung luong localStorage + IDB hien co
    print('ls keys',pg.evaluate("Object.keys(localStorage)"),'idb',pg.evaluate("async()=>(await indexedDB.databases()).map(d=>d.name+'@'+d.version)"))
    b.close()
