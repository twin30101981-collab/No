const fs = require('fs');
const D = require('docx');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  AlignmentType, HeadingLevel, LevelFormat, Footer, Header, PageNumber, ImageRun, PageBreak } = D;

const BL = JSON.parse(fs.readFileSync('/home/claude/work/handover/backlog.json', 'utf8'));
const HM = BL.hang_muc;
const TONG = HM.reduce((a, h) => a + h.chi_phi_uoc_tinh_pct, 0);
const TONG_BO9 = HM.filter(h => h.id !== 'HM-09').reduce((a, h) => a + h.chi_phi_uoc_tinh_pct, 0);
const CON = HM.filter(h => !['DA_BAN_GIAO', 'DAT_V3', 'DAT_V2'].includes(h.trang_thai)).reduce((a, h) => a + h.chi_phi_uoc_tinh_pct, 0);
const cnt = p => HM.filter(h => h.uu_tien === p).length;
const W = 9638; // 11906 - 2*1134
const FONT = 'Arial';

const run = (t, o = {}) => new TextRun({ text: t, font: FONT, size: 22, ...o });
const P = (t, o = {}) => new Paragraph({ spacing: { after: 100, line: 276 }, ...o.p, children: Array.isArray(t) ? t : [run(t, o.r || {})] });
const B = (t, lvl = 0) => new Paragraph({ numbering: { reference: 'bul', level: lvl }, spacing: { after: 60, line: 276 },
  children: Array.isArray(t) ? t : [run(t)] });
const H1 = t => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun({ text: t, font: FONT })] });
const H2 = t => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun({ text: t, font: FONT })] });
const bold = t => run(t, { bold: true });
const BR = () => new Paragraph({ children: [new PageBreak()] });

const bd = { style: BorderStyle.SINGLE, size: 4, color: 'A6A6A6' };
const borders = { top: bd, bottom: bd, left: bd, right: bd };
function cell(t, w, o = {}) {
  const paras = (Array.isArray(t) ? t : [t]).map(x => new Paragraph({ spacing: { after: 40, line: 252 },
    children: [new TextRun({ text: String(x), font: FONT, size: o.size || 19, bold: !!o.bold })] }));
  return new TableCell({ width: { size: w, type: WidthType.DXA }, borders,
    shading: o.fill ? { fill: o.fill, type: ShadingType.CLEAR, color: 'auto' } : undefined,
    margins: { top: 50, bottom: 50, left: 90, right: 90 }, children: paras });
}
function table(head, rows, widths, o = {}) {
  const sum = widths.reduce((a, b) => a + b, 0);
  if (sum !== W) widths = widths.map(x => Math.round(x * W / sum));
  widths[widths.length - 1] += W - widths.reduce((a, b) => a + b, 0);
  const hr = new TableRow({ tableHeader: true, cantSplit: true, children: head.map((h, i) => cell(h, widths[i], { bold: true, fill: 'D9E2F3', size: o.size })) });
  const br = rows.map(r => new TableRow({ cantSplit: true, children: r.map((c, i) => cell(c, widths[i], { size: o.size })) }));
  return new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: widths, rows: [hr, ...br] });
}
const gap = () => new Paragraph({ spacing: { after: 80 }, children: [] });

// ---------- ảnh ----------
let sharp = null; try { sharp = require('sharp'); } catch (e) {}
function img(path, wpx, caption) {
  const data = fs.readFileSync(path);
  let h = Math.round(wpx * 0.5625);
  if (path.includes('mobile')) h = Math.round(wpx * 844 / 390);
  return [new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 40 },
      children: [new ImageRun({ type: 'jpg', data, transformation: { width: wpx, height: h },
        altText: { title: caption, description: caption, name: caption } })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 160 }, children: [run(caption, { italics: true, size: 18 })] })];
}

const EV = '/home/claude/work/evidence/';
const c = [];

// ---------- Bìa ----------
c.push(new Paragraph({ spacing: { before: 2400, after: 200 }, alignment: AlignmentType.CENTER,
  children: [new TextRun({ text: 'ĐỀ ÁN ỔN ĐỊNH VÀ NÂNG CẤP', font: FONT, size: 44, bold: true, color: '1F3864' })] }));
c.push(new Paragraph({ spacing: { after: 600 }, alignment: AlignmentType.CENTER,
  children: [new TextRun({ text: 'QLTDPRO — ứng dụng quản lý tín dụng (HTML đơn tệp, PWA)', font: FONT, size: 28, color: '1F3864' })] }));
[['Phiên bản đề án', 'v1.2 (v1.0–v1.1 đã duyệt; phần bổ sung Đợt 5 chờ duyệt)'], ['Ngày lập', '04/11/2026 · cập nhật v1.2: 05/11/2026'], ['Phiên làm việc', 'S0 (P01 theo skill) — khảo sát, chưa sửa mã'],
  ['Trạng thái', 'CHỜ DUYỆT'], ['Bản app khảo sát', 'QLTDPRO_v24.17.9.html (gói QLTDPRO_P53_v36.zip)'],
  ['Căn cứ quy trình', 'Skill web-app-repair-upgrade v3.2.0, chế độ 1 (khảo sát)']]
  .forEach(([a, b]) => c.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80 }, children: [run(a + ': ', { bold: true }), run(b)] })));
c.push(new Paragraph({ spacing: { before: 600 }, alignment: AlignmentType.CENTER,
  children: [run('Chưa có hạng mục nào được thực hiện. Mọi thay đổi mã chỉ bắt đầu sau khi bạn duyệt đề án này.', { italics: true })] }));
c.push(BR());

// ---------- Mục lục tĩnh ----------
c.push(new Paragraph({ children: [new TextRun({ text: 'Mục lục', font: FONT, size: 30, bold: true, color: '1F3864' })], spacing: { after: 160 } }));
['1. Tóm tắt điều hành', '2. Phạm vi, giả định, độ phủ phân tích', '3. Hiện trạng kỹ thuật', '4. Kiểm kê chức năng',
  '5. Phát hiện và nguyên nhân', '6. UI/UX', '7. Dữ liệu, hiệu năng, PWA, bảo mật', '8. Cơ hội và đề xuất',
  '9. Lộ trình nâng cấp', '10. Chiến lược kiểm chứng', '11. Vận hành nhiều phiên', '12. Rủi ro và đường lui',
  '13. Tiêu chí nghiệm thu tổng', '14. Quyết định cần bạn chốt, câu hỏi mở',
  'Phụ lục A. Backlog đầy đủ', 'Phụ lục B. Bản đồ mã', 'Phụ lục C. Bằng chứng', 'Phụ lục D. Nhãn và thuật ngữ', 'Phụ lục E. Lịch sử bản đề án']
  .forEach(t => c.push(P(t, { p: { spacing: { after: 50 } } })));
c.push(BR());

// ---------- 1 ----------
c.push(H1('1. Tóm tắt điều hành'));
c.push(P([bold('Hiện trạng. '), run('QLTDPRO là ứng dụng một tệp HTML (~3,5 MB) chạy ngoại tuyến, gồm bản build React/Vite đã nén cộng 12 lớp vá nội tuyến (gd3–gd14). Có 23 màn hình, dữ liệu lưu trong trình duyệt, chặn mọi kết nối ra ngoài bằng CSP. Qua các phiên P42–P53 app đã thêm tính năng và sửa lỗi; bản mới nhất là v24.17.9.')]));
c.push(P([bold('Kết quả quét baseline (V3, Chromium). '), run('23 màn hình × 2 kích thước (1366×768 và 390×844) mở được, không có lỗi JavaScript ở trạng thái chưa nạp dữ liệu; tải lại khi ngoại tuyến vẫn mở. Các bộ kiểm hiện có chạy đạt: P53 10/10, lõi lãi 18/18 và 11/11 (trên v24.17.9), P52 14/14 (chạy trên v24.17.8).')]));
c.push(P([bold('Vấn đề chính (chưa có P0 được xác nhận). '), run('(1) Không có mã nguồn React/Vite gốc trong gói: mọi thay đổi là vá chuỗi trên bản build. (2) Bộ kiểm gắn cứng tên tệp HTML cũ, không có bộ chạy chung, nên hồi quy trên bản mới chưa được chạy lại đầy đủ. (3) Lỗi đọc ngày dd/mm đã sửa ở P53 tại một hàm; chưa biết các đường đọc tệp khác có còn lỗi (giả thuyết). (4) Hai nghi vấn cần xác minh bằng thử nghiệm: hiển thị HTML từ dữ liệu nhập và lỗi bị nuốt (catch rỗng). (5) Phát hành thủ công qua tên tệp, sw.js và manifest.')]));
c.push(P([bold('Hướng nâng cấp. '), run('Không viết lại, không thêm tính năng khi chưa có yêu cầu. Trước hết dựng nền kiểm chứng và xác minh các nghi vấn dữ liệu/an toàn; sau đó dọn lỗi nuốt, bố cục điện thoại, phát hành/PWA; hiệu năng chỉ làm nếu đo thấy chậm.')]));
c.push(P([bold('Lộ trình. '), run(`4 đợt có hạng mục, ${HM.length} hạng mục (P0: ${cnt('P0')}, P1: ${cnt('P1')}, P2: ${cnt('P2')}, P3: ${cnt('P3')}), tổng chi phí ước tính ${TONG}% ngữ cảnh một phiên (${TONG_BO9}% nếu bỏ hạng mục tùy chọn HM-09) → khoảng 2–3 phiên thực thi, chưa tính phiên S0 này. Đây là khoảng ước tính, không phải cam kết; sẽ hiệu chỉnh sau 2 hạng mục đầu.`)]));
c.push(P([bold('Cần bạn duyệt (v1.2). '), run('v1.0 và v1.1 đã duyệt. Cần duyệt phần bổ sung Đợt 5 (Mục Đợt 5: HM-18 Khách hàng mới, HM-19 Máy tính lãi & Lãi đọng, HM-20 Chỉ tiêu kế hoạch) và các câu hỏi Q11–Q14.')]));


// ---------- 2 ----------
c.push(H1('2. Phạm vi, giả định, độ phủ phân tích'));
c.push(H2('2.1. Mục tiêu và phạm vi'));
c.push(P('Bạn chưa nêu mục tiêu nâng cấp cụ thể; đề án giả định mục tiêu là: giữ app ổn định, kiểm chứng được và không phá chức năng đang dùng (Giả định G1).'));
c.push(B([bold('Trong phạm vi: '), run('QLTDPRO_v24.17.9.html, sw.js, manifest.json, các bộ kiểm trong gói.')]));
c.push(B([bold('Ngoài phạm vi (nếu chưa được bạn duyệt riêng): '), run('viết lại từ mã nguồn; đổi 4 CSDL IndexedDB; đổi quy tắc tính lãi/giải ngân; thêm tính năng mới; dùng dữ liệu khách hàng thật trong kiểm thử hoặc ZIP.')]));
c.push(B([bold('Ràng buộc kế thừa: '), run('đơn tệp, ngoại tuyến, tiếng Việt; CSP chặn mạng; khi chỉnh giao diện chỉ sửa trong khối <style>, không sửa chuỗi JavaScript.')]));
c.push(H2('2.2. Giả định'));
c.push(B('G1: mục tiêu như trên. G2: người dùng cuối là cán bộ tín dụng của chi nhánh (theo tiêu đề giao diện). G3: app được dùng như PWA/ngoại tuyến (chưa biết có mở bằng file:// hay host http — xem Q3).'));
c.push(H2('2.3. Độ phủ phân tích'));
c.push(table(['Mức', 'Phạm vi'], [
  ['Đọc kỹ', 'sw.js, manifest.json, phần đầu HTML (CSP, meta), build_p53.py, bàn giao P53, README, skill.'],
  ['Chạy thật (V3)', 'Mở app 2 kích thước; quét 23 route × 2 viewport (trạng thái rỗng); tải lại ngoại tuyến; 4 bộ kiểm hiện có.'],
  ['Lấy mẫu / đếm bằng script', 'Toàn bộ HTML: khối script/style, khóa lưu trữ, mẫu rủi ro (innerHTML, catch rỗng, fetch…).'],
  ['Chưa đọc', 'Nội dung bundle đã nén (2,6 MB); mã 12 lớp gd (chỉ đếm); nội dung các bộ kiểm cũ; bàn giao P42–P52; công thức nghiệp vụ ngoài lõi lãi.'],
  ['Chưa kiểm', 'Luồng nhập/xuất/lập báo cáo với dữ liệu; hiệu năng dữ liệu lớn; thiết bị thật; trình duyệt khác Chromium.'],
], [2200, 7438]));


// ---------- 3 ----------
c.push(H1('3. Hiện trạng kỹ thuật'));
c.push(table(['Mục', 'Thông tin (nhãn)'], [
  ['Loại app', 'HTML đơn tệp + PWA: sw.js cache-first, manifest chế độ standalone. (Đã xác minh)'],
  ['Quy mô', 'v24.17.9.html: 3,47 MB, 14.767 dòng. Module script 2,58 MB (React, SheetJS, JSZip đóng gói, đã nén); khối style gd10-align 1,44 MB; 12 lớp vá gd3–gd14 khoảng 0,2 MB JS nội tuyến. (Đã xác minh)'],
  ['Phụ thuộc ngoài', 'Không. CSP: default-src none, connect-src self; không có yêu cầu mạng thất bại ngoài 404 thăm dò mẫu. (Đã xác minh)'],
  ['Điều hướng', 'Hash route, 23 màn hình (Mục 4). (Đã xác minh)'],
  ['Lưu trữ', 'localStorage (≥14 khóa: qltd2_*, hsv_records_v1, pa_*…), sessionStorage, IndexedDB 4 CSDL: QLTDProDB v3, QLTDProFolder_v1, QLTDProGD9, QLTDProMauHsvx. (Đã xác minh nơi lưu; lược đồ chưa đọc)'],
  ['Cách thay đổi', 'Không có mã nguồn gốc. Mỗi phiên chạy build_pXX.py vá chuỗi chính xác (đếm neo bằng assert) từ HTML bản trước sang bản sau; 10 bước liên tiếp 24.16.0 → 24.17.9. (Đã xác minh)'],
  ['Kiểm thử', '19 tệp .py/.cjs (Playwright Python, Node); không có bộ chạy chung hay CI. (Đã xác minh)'],
  ['Môi trường kiểm', 'Node v22.23.4; Playwright + Chromium 153 chạy được (V3 khả dụng); không có jsdom; bash không ra mạng.'],
], [2000, 7638]));
c.push(gap());
c.push(P([bold('Luồng dữ liệu (theo bàn giao P53 và README; chưa đọc mã bundle — Giả thuyết cần xác minh ở HM-03): '),
  run('tệp IPCAS/MIS hoặc “Lưu trữ” → worker đọc bằng SheetJS → chuẩn hóa → lưu IndexedDB/localStorage → giao diện React → xuất Excel/Word (mẫu .docx).')]));


// ---------- 4 ----------
c.push(H1('4. Kiểm kê chức năng'));
c.push(P('Trạng thái “Mở được” nghĩa là: route tải, tiêu đề đúng, không pageerror ở trạng thái chưa có dữ liệu (V3). Chưa chứng minh luồng nghiệp vụ với dữ liệu, trừ các ca ghi ở cột Ghi chú.'));
const mo = 'Mở được';
c.push(table(['Nhóm menu', 'Màn hình (route)', 'Trạng thái', 'Ghi chú'], [
  ['Tổng quan', 'tong-quan, chi-tieu-ke-hoach, xu-huong-ky', mo, 'Chưa kiểm với dữ liệu'],
  ['Kiểm soát', 'canh-bao-som, doi-soat-so-lieu', mo, 'doi-soat: nhiều phần tử vượt khung trên điện thoại (F-08)'],
  ['Dư nợ', 'tat-ca-du-no, ngan-han-thau-chi, trung-dai-han, khach-hang-360, khach-hang-moi, du-no-cam-co', mo, 'khach-hang-moi: “Nạp từ Lưu trữ” có test P53 10/10'],
  ['Thu nợ và lãi', 'no-den-han, lai-dong, chuyen-han-muc, tra-no-xuat-ts, giai-ngan', mo, 'Máy tính lãi: lõi 18/18 và 11/11 (không chạy qua giao diện ở S0)'],
  ['Tài sản', 'tai-san-bao-dam, gia-dat', mo, 'gia-dat: trang nặng nhất (10.400 ký tự văn bản, F-08)'],
  ['Hồ sơ vay', 'ho-so-vay-hop-nhat', mo, 'Tạo hồ sơ từ mẫu .docx: chưa kiểm (F-07)'],
  ['Dữ liệu và hệ thống', 'nhap-du-lieu, luu-tru, bao-cao-ipcas, he-thong', mo, 'Luồng nhập/xuất chưa kiểm ở S0'],
], [1600, 3600, 1100, 3338]));


// ---------- 5 ----------
c.push(H1('5. Phát hiện và nguyên nhân'));
c.push(P('Ưu tiên theo skill: P0 mất/lộ dữ liệu hoặc app không dùng được; P1 luồng cốt lõi/hồi quy rộng; P2 chức năng phụ, bố cục; P3 tinh chỉnh. Không có phát hiện nào đạt P0 ở S0.'));
c.push(table(['Mã', 'Phát hiện', 'Ưu tiên', 'Nhãn', 'Nguyên nhân sơ bộ / lan truyền', 'HM'], [
  ['F-01', 'Không có mã nguồn gốc; thay đổi bằng vá chuỗi trên bản build', 'P1 (nền)', 'Đã xác minh', 'Quy trình phát hành không giữ source. Lan truyền: mọi phiên sau.', 'HM-10, Q1'],
  ['F-02', 'Bộ kiểm gắn cứng 9 phiên bản HTML khác nhau; không có bộ chạy chung; P52 chạy trên v24.17.8; bàn giao P53 nêu chưa chạy lại P40–P52', 'P1 (nền)', 'Đã xác minh', 'Test viết theo từng phiên, không tham số hóa. Hồi quy bản mới chưa đầy đủ.', 'HM-01'],
  ['F-03', 'Lỗi đọc ngày dd/mm và mã “001” có thể còn ở đường đọc tệp khác', 'P1', 'Giả thuyết', 'P53: head đọc không raw:true, sửa chỉ tại hàm em. Các nơi khác dùng Zh/head chưa rà.', 'HM-02'],
  ['F-04', '~105 chỗ innerHTML + 14 dangerouslySetInnerHTML; tên/địa chỉ KH từ tệp nhập là dữ liệu không tin cậy', 'P1', 'Chưa đủ bằng chứng', 'Đếm chuỗi (gồm thư viện). CSP cho phép script nội tuyến nên thiếu lớp chặn thứ hai.', 'HM-04'],
  ['F-05', 'Lưu trữ phức tạp (≥14 khóa + 4 CSDL + sessionStorage); chưa kiểm dữ liệu hỏng, thiếu khóa, quota, migration', 'P1', 'Chưa đủ bằng chứng', 'Chưa đọc lớp lưu trữ.', 'HM-03'],
  ['F-06', '94 catch rỗng trong bundle (gồm thư viện) + 42 trong lớp vá', 'P2', 'Giả thuyết', 'Có thể che lỗi nhập/lưu. Chưa tách mã app khỏi thư viện.', 'HM-05'],
  ['F-07', 'Mỗi lần mở app có HEAD tới templates/…docx trả 404 (84 tham chiếu mẫu; gói không có thư mục templates/)', 'P2', '404: Đã xác minh; ảnh hưởng chức năng: Chưa đủ bằng chứng', 'Mẫu có thể ở nơi khác hoặc nạp qua IndexedDB QLTDProMauHsvx (Giả thuyết).', 'HM-07, Q2'],
  ['F-08', 'Phần tử vượt khung nhìn trên điện thoại (gia-dat 773, bao-cao-ipcas 233, doi-soat 115, giai-ngan 56); tài liệu không tràn ngang (0 px ở cả 23 route)', 'P2', 'Chưa đủ bằng chứng', 'Phép đo thô: có thể là bảng cuộn nội bộ hợp lệ.', 'HM-06'],
  ['F-09', 'Phát hành thủ công: tên tệp gắn phiên bản; sw.js, manifest trỏ cứng; addAll(...).catch nuốt lỗi; 2 bản HTML 3,4 MB cùng nằm trong app/', 'P2', 'Đã xác minh', 'Mỗi phiên phải sửa 3 nơi; lỗi cache bị che.', 'HM-08'],
  ['F-10', 'Tải ~3,0 s ở trạng thái rỗng (headless, localhost); khối CSS gd10-align 1,44 MB', 'P3', 'Chưa đủ bằng chứng', 'Chưa đo với dữ liệu lớn.', 'HM-09'],
], [620, 2700, 800, 1200, 3100, 1218], { size: 17 }));
c.push(gap());
c.push(H2('Nhóm cùng nguyên nhân gốc'));
c.push(B('Quy trình phát hành và kiểm thử: F-01, F-02, F-09 (sửa một lần ở nền, không sửa lặp).'));
c.push(B('Xử lý dữ liệu nhập: F-03, F-05 (cùng điểm vào là đường đọc tệp và lớp lưu trữ).'));
c.push(B('An toàn xử lý và hiển thị: F-04, F-06. Độc lập: F-07, F-08, F-10.'));


// ---------- 6 ----------
c.push(H1('6. UI/UX'));
c.push(P('Ảnh baseline màn hình mở đầu (trạng thái chưa có dữ liệu), chụp bằng Chromium headless:'));
c.push(...img(EV + 'baseline_desktop_mo_dau.jpg', 560, 'Hình 1. Desktop 1366×768 — Tổng quan, chưa có dữ liệu'));
c.push(...img(EV + 'baseline_mobile_mo_dau.jpg', 190, 'Hình 2. Điện thoại 390×844 — menu thu gọn (☰)'));
c.push(B('Đã xác minh: không pageerror ở 23 route × 2 viewport; tài liệu không tràn ngang; có liên kết “Bỏ qua tới nội dung” và nút “Tương phản cao”; trên điện thoại menu thu gọn sau nút ☰.'));
c.push(B('Chưa đủ bằng chứng: bố cục với dữ liệu thật/dài, bàn phím, tương phản, kích thước chạm. Phần tử vượt khung (F-08) cần xác minh ở HM-06.'));
c.push(table(['Route', 'Desktop', 'Điện thoại'], [
  ['gia-dat', '517', '773'], ['bao-cao-ipcas', '0', '233'], ['doi-soat-so-lieu', '35', '115'], ['giai-ngan', '13', '56'],
  ['ho-so-vay-hop-nhat', '0', '10'], ['luu-tru', '0', '8'], ['khach-hang-360', '0', '5'],
], [4000, 2800, 2838]));
c.push(P('Bảng: số phần tử trong vùng nội dung có mép phải vượt chiều rộng khung nhìn (phép đo thô, không đồng nghĩa lỗi).', { r: { italics: true, size: 18 } }));


// ---------- 7 ----------
c.push(H1('7. Dữ liệu, hiệu năng, PWA, bảo mật'));
c.push(H2('7.1. Dữ liệu'));
c.push(B('Đã xác minh: lỗi ngày dd/mm của “Nạp từ Lưu trữ” đã sửa ở P53; test 10/10 trên v24.17.9 (v24.17.8 FAIL theo bàn giao).'));
c.push(B('Giả thuyết: lỗi tương tự còn ở đường khác (F-03). Chưa đủ bằng chứng: migration, JSON hỏng, quota (F-05).'));
c.push(B('Bàn giao P53 lưu ý: báo cáo đã lập bằng bản cũ cần lập lại mới ra số đúng (việc của người dùng).'));
c.push(H2('7.2. Hiệu năng'));
c.push(P('Tải ~3,0 s (desktop 3.061 ms; điện thoại 2.915 ms; headless, localhost, chưa có dữ liệu). Chưa đo nạp dữ liệu lớn, lập báo cáo, bộ nhớ.'));
c.push(H2('7.3. PWA/ngoại tuyến'));
c.push(B('Đã xác minh (V3): service worker đăng ký, cache qltdpro-p53-v24.17.9; tải lại khi ngoại tuyến vẫn mở đúng trang, không pageerror.'));
c.push(B('Chưa kiểm: luồng cập nhật phiên bản (skipWaiting + clients.claim có thể đổi bản giữa lúc đang nhập — Giả thuyết); chạy bằng file:// (không có service worker).'));
c.push(H2('7.4. Bảo mật và riêng tư'));
c.push(B('Đã xác minh: CSP default-src none, connect-src self, base-uri none, form-action none; không có CDN; không yêu cầu mạng ra ngoài.'));
c.push(B('Đánh đổi đã biết: script-src unsafe-inline là bắt buộc với đơn tệp.'));
c.push(B('Dữ liệu khách hàng nằm trong trình duyệt của máy dùng; mã hóa tại chỗ: Chưa xác minh. Nghi vấn hiển thị HTML từ dữ liệu nhập: F-04 (chưa phải sự cố đã xác nhận).'));


// ---------- 8 ----------
c.push(H1('8. Cơ hội và đề xuất'));
c.push(P('Bạn chưa nêu nhu cầu tính năng mới nên đề án không đưa tính năng mới vào lộ trình. Các mục dưới là nền cần có để mọi nâng cấp sau này an toàn.'));
c.push(table(['Mục', 'Loại', 'Giá trị', 'Rủi ro', 'Effort'], [
  ['Bộ chạy hồi quy chung (HM-01)', 'Cần sửa', 'Cao: mọi hạng mục sau dựa vào', 'Thấp', 'M'],
  ['Rà lan truyền lỗi ngày/mã (HM-02)', 'Cần sửa (nếu xác minh)', 'Cao: sai số liệu giải ngân', 'Thấp', 'S'],
  ['Kiểm lưu trữ, sao lưu/khôi phục (HM-03)', 'Cần sửa (nếu xác minh)', 'Cao: bảo vệ dữ liệu', 'Trung bình', 'M'],
  ['Xác minh hiển thị dữ liệu nhập (HM-04)', 'Cần xác minh', 'Cao nếu có lỗi', 'Thấp', 'S'],
  ['Một nguồn phiên bản cho sw/manifest (HM-08)', 'Nên thêm', 'Trung bình', 'Trung bình', 'S'],
  ['Thu hồi mã nguồn gốc (Q1)', 'Ý tưởng, chờ bạn', 'Rất cao nếu có', 'Phụ thuộc', 'Chưa ước tính'],
], [3400, 1700, 2300, 1100, 1138]));


// ---------- 9 ----------
c.push(H1('9. Lộ trình nâng cấp'));
const dots = { 1: 'Đợt 1 — Nền kiểm chứng và ổn định dữ liệu', 2: 'Đợt 2 — Nhất quán và khả dụng', 3: 'Đợt 3 — Phát hành, hiệu năng, tài liệu' };
const mocs = { 1: 'Mốc nghiệm thu: bộ chạy chung báo rõ pass/fail/skip trên v24.17.9; F-03/F-04/F-05 có kết luận bằng thử nghiệm; điểm dừng hợp lý (dùng tiếp v24.17.9).',
  2: 'Mốc nghiệm thu: lỗi nuốt ở luồng nhập/lưu được xử lý hoặc ghi thẻ; bảng rộng trên điện thoại ổn định; 404 mẫu có kết luận.',
  3: 'Mốc nghiệm thu: phát hành đổi phiên ở một chỗ, cập nhật PWA không mất dữ liệu; có số đo hiệu năng; có tài liệu lớp vá.' };
[1, 2, 3].forEach(d => {
  c.push(H2(dots[d]));
  c.push(table(['ID', 'Hạng mục', 'Ưu tiên / Effort', 'Phụ thuộc', 'Ngữ cảnh', 'Model Effort*'],
    HM.filter(h => h.dot === d).map(h => [h.id, h.ten, h.uu_tien + ' / ' + h.effort, h.phu_thuoc.join(', ') || '—', h.chi_phi_uoc_tinh_pct + '%', h.model_effort_recommended]),
    [800, 4100, 1200, 1100, 1000, 1438], { size: 18 }));
  c.push(P(mocs[d], { r: { italics: true, size: 20 }, p: { spacing: { before: 80, after: 160 } } }));
});
c.push(H2('Đợt 4 — Tính năng mới (bổ sung v1.1, chờ duyệt)'));
c.push(P([bold('Yêu cầu người dùng (04/11/2026). '), run('Lọc được doanh số giải ngân và thu nợ chính xác cho toàn bộ cán bộ tín dụng theo từng phòng ban, có đối soát số liệu khớp đúng.')]));
c.push(H2('Hiện trạng đã xác minh trên v24.17.9 (đọc mã bản build)'));
c.push(table(['#', 'Phát hiện', 'Trạng thái', 'Tác động'], [
  ['G-01', 'Doanh số giải ngân = Σ dsbsamt của khế ước có ngày GN (dsbsdt) trong kỳ, lấy từ tệp dư nợ cuối kỳ; khế ước GN rồi tất toán trong kỳ được bù bằng cơ chế "Tất toán trong kỳ" (dòng có ở đầu kỳ, mất ở cuối kỳ).', 'Đã xác minh', 'Khế ước GN SAU ngày đầu kỳ và tất toán TRƯỚC ngày cuối kỳ không có trong cả hai tệp → doanh số GN có thể thiếu.'],
  ['G-02', 'Thu nợ = GN − (dư nợ cuối − dư nợ đầu), chỉ tính theo PHÒNG ("Thu nợ suy ra").', 'Đã xác minh', 'Không phải số đo độc lập: dòng "Kiểm tra: Đầu + GN − Thu nợ − Cuối" luôn = 0 theo cách tính, nên không phát hiện được sai lệch.'],
  ['G-03', 'Không có thu nợ theo CÁN BỘ; doanh số GN theo cán bộ có ở bảng Tổng hợp nhưng không có đối soát dư nợ đầu/cuối theo cán bộ.', 'Đã xác minh', 'Chưa đáp ứng yêu cầu "toàn bộ cán bộ theo từng phòng có đối soát".'],
  ['G-04', 'Khế ước chuyển phòng/cán bộ giữa đầu kỳ và cuối kỳ bị tính là "thu nợ" ở nơi cũ và tăng dư nợ ở nơi mới.', 'Đã xác minh (theo công thức)', 'Thu nợ theo phòng/cán bộ sai khi có điều chuyển.'],
  ['G-05', 'Tệp msit80 có sẵn cột rpmtamt (gốc đã trả) và lstrpmtdt (ngày trả gần nhất); app đã đọc rpmtamt vào bản ghi nhưng chưa dùng cho thu nợ.', 'Đã xác minh', 'Có nguồn để đo thu nợ độc lập — cần xác nhận ý nghĩa cột (Q4).'],
  ['G-06', 'Ảnh người dùng gửi: "Không có món giải ngân trong kỳ đã chọn" khi nạp từ Lưu trữ, ô Đầu kỳ/Cuối kỳ trống, TSBĐ khác ngày.', 'Giả thuyết', 'Cần tái hiện với dữ liệu: có thể do Lưu trữ thiếu mốc cuối kỳ, hoặc đường đọc ngày dd/mm (liên quan HM-02).'],
], [700, 4300, 1400, 3238], { size: 17 }));
c.push(gap());
c.push(H2('Phương án tối ưu đề xuất (đo độc lập rồi đối chiếu)'));
c.push(B([bold('Đơn vị tính là khế ước (số GN). '), run('Ghép đầu kỳ ↔ cuối kỳ theo khóa khế ước; mỗi khế ước thuộc đúng một trong 4 nhóm: còn ở cả hai kỳ; mới GN trong kỳ; tất toán trong kỳ; GN và tất toán trong kỳ (chỉ thấy được nếu có mốc Lưu trữ hàng ngày ở giữa — app đã lưu mốc mỗi lần nhập).')]));
c.push(B([bold('GN trong kỳ (đo trực tiếp): '), run('dsbsamt của khế ước có dsbsdt trong kỳ, gom thêm từ các mốc Lưu trữ trong kỳ để không sót khế ước đã tất toán.')]));
c.push(B([bold('Thu nợ gốc (đo trực tiếp, không suy ra): '), run('khế ước còn cả hai kỳ: rpmtamt cuối − rpmtamt đầu; khế ước mới: rpmtamt cuối; khế ước tất toán: dư nợ đầu kỳ (hoặc rpmtamt mốc cuối cùng). Nếu Q4 cho thấy rpmtamt không lũy kế → dùng phương án dự phòng GN − Δ dư nợ ở cấp khế ước và gắn nhãn "suy ra".')]));
c.push(B([bold('Đối soát thật ở 4 cấp: '), run('khế ước → cán bộ → phòng → chi nhánh, kiểm Dư nợ đầu + GN − Thu nợ = Dư nợ cuối; vì GN và thu nợ đo độc lập nên phép kiểm có ý nghĩa. Dòng lệch được liệt kê kèm lý do (xử lý rủi ro, điều chỉnh, ngoại tệ, thiếu mốc).')]));
c.push(B([bold('Điều chuyển cán bộ/phòng: '), run('dòng "Chuyển đến / Chuyển đi" riêng, không lẫn vào thu nợ; GN gán cán bộ cuối kỳ, thu nợ gán cán bộ đầu kỳ (chờ chốt Q5).')]));
c.push(B([bold('Một nguồn tính: '), run('một hàm thuần dùng chung cho màn hình, Excel và trang Đối soát số liệu; kiểm bằng Node + đáp án Python độc lập + Playwright.')]));
c.push(B([bold('Bấm số tiền xem chi tiết (yêu cầu bổ sung 04/11/2026): '), run('mọi ô GN / thu nợ / dư nợ ở cấp chi nhánh → phòng → cán bộ đều bấm được, mở bảng các món cấu thành: khế ước, khách hàng, cán bộ, phòng, ngày trả gần nhất (lstrpmtdt), gốc thu trong kỳ, dư nợ đầu/cuối, cách đo (Δ gốc đã trả / tất toán / suy ra) và mốc Lưu trữ đã dùng. Tổng bảng chi tiết luôn bằng ô đã bấm; có Xuất Excel để đối chiếu với báo cáo IPCAS.')]));
c.push(B([bold('Giới hạn cần biết: '), run('tệp msit80 là ảnh chụp số dư theo ngày, không phải nhật ký giao dịch. Nếu trong kỳ khách trả nhiều lần, app chỉ tách được theo các mốc Lưu trữ hiện có (mỗi mốc ngày một chênh lệch). Muốn khớp TỪNG giao dịch trả nợ cần báo cáo giao dịch thu nợ của IPCAS (Q10).')]));
c.push(table(['ID', 'Hạng mục', 'Ưu tiên / Effort', 'Phụ thuộc', 'Ngữ cảnh', 'Model Effort*'],
  HM.filter(h => h.dot === 4).map(h => [h.id, h.ten, h.uu_tien + ' / ' + h.effort, h.phu_thuoc.join(', ') || '—', h.chi_phi_uoc_tinh_pct + '%', h.model_effort_recommended]),
  [800, 4100, 1200, 1100, 1000, 1438], { size: 18 }));
c.push(P('Mốc nghiệm thu Đợt 4: với bộ dữ liệu thử có đáp án độc lập, GN, thu nợ và dư nợ khớp 0 đồng ở mọi cấp (khế ước, cán bộ, phòng, chi nhánh); lọc từng phòng/cán bộ ra đúng danh sách khế ước cấu thành; hồi quy chung (HM-01) không có FAIL mới.', { r: { italics: true, size: 20 }, p: { spacing: { before: 80, after: 160 } } }));

c.push(H2('Đợt 4b — Máy tính lãi: điểm nghẽn và phương án (bổ sung v1.1, chờ duyệt)'));
c.push(P([bold('Yêu cầu người dùng (04/11/2026). '), run('Phân tích điểm nghẽn, đề xuất phương án tối ưu nhất về giao diện và tính chính xác số liệu của trang Máy tính lãi.')]));
c.push(P([bold('Cách khảo sát. '), run('Chạy Máy tính lãi v24.17.9 bằng Playwright (Chromium 153) với dữ liệu thử msit80_03-11-2026 (khách hàng mẫu 10 khoản), đo bố cục ở 1366×768 và 390×844; đọc lõi nguon_P41/qltd_lai.cjs. Script: evidence/do_mtl.py. Không sửa app.')]));
c.push(...img(EV + 'mtl_desktop_v24179.jpg', 560, 'Máy tính lãi v24.17.9 ở 1366×768: chưa thấy cột lãi và tổng lãi khi mở'));
c.push(H2('Điểm nghẽn giao diện (đã đo)'));
c.push(table(['#', 'Điểm nghẽn', 'Số đo', 'Tác động'], [
  ['U-01', 'Kết quả chính (lãi trong hạn, quá hạn, tổng phải thu) nằm ở 4 cột cuối của bảng 15 cột và thanh tổng ở dưới bảng.', 'Bảng rộng 1.640 px, khung nhìn 1.066 px; nội dung modal 1.009 px trong khung 768 px', 'Mở ra không thấy số cần tìm; phải cuộn ngang và cuộn dọc mới đọc được tổng.'],
  ['U-02', 'Tiêu đề cột có tên trường kỹ thuật (← apprseq, ← lstintchrgprd, r[7], ← sprd).', '15/15 cột', 'Rối mắt, chiếm 2 dòng tiêu đề; chỉ cần cho người kiểm tra.'],
  ['U-03', 'Cột "Tên KH" lặp lại cùng một khách hàng ở mọi dòng.', '1 cột cố định ~160 px', 'Tốn chỗ, đẩy cột lãi ra ngoài màn hình.'],
  ['U-04', 'Hộp "Công thức chuẩn" và dòng chú thích nguồn luôn mở.', '~110 px chiều cao', 'Chiếm 1/7 chiều cao màn hình 768 px.'],
  ['U-05', 'Điện thoại: bảng 15 cột chỉ thấy 2 cột; 61 nút/ô nhập nhỏ hơn 32 px.', '390×844: cuộn ngang; 46 ô nhập, 12 ô ngày', 'Khó thao tác bằng ngón tay, dễ nhập nhầm ô.'],
  ['U-06', 'Ô "Số tiền trả gốc" và "Ngày thu lãi" nằm giữa bảng, xa cột kết quả.', '—', 'Sửa số xong không thấy ngay lãi thay đổi.'],
], [700, 3600, 2500, 2838], { size: 17 }));
c.push(gap());
c.push(H2('Điểm nghẽn về tính chính xác (đọc lõi + đối chiếu quy tắc đã chốt)'));
c.push(table(['#', 'Vấn đề', 'Trạng thái', 'Tác động'], [
  ['A-01', 'Lãi trong hạn = dư nợ hiện tại (dsbsbal tại ngày dữ liệu) × LS × số ngày từ "đã thu lãi đến". Nếu khách trả một phần gốc SAU ngày đã thu lãi đến, cả quãng bị tính trên dư nợ sau khi trả.', 'Đã xác minh (mã lõi dòng 130)', 'Thiếu lãi cho đoạn trước ngày trả gốc. Cần dư nợ theo từng đoạn (mốc Lưu trữ hàng ngày, lstrpmtdt, rpmtamt).'],
  ['A-02', 'Không đối chiếu với lãi dự thu do IPCAS tính trong cùng tệp.', 'Đã xác minh', 'Không có phép tự kiểm; sai lệch do dữ liệu (LS điều chỉnh, miễn giảm, ngày dd/mm đảo) không được phát hiện.'],
  ['A-03', 'Không cảnh báo khi ngày chốt cách xa ngày dữ liệu của tệp.', 'Đã xác minh', 'Khách có thể đã trả lãi/gốc sau ngày dữ liệu → kết quả không còn đúng mà không ai biết.'],
  ['A-04', 'Lãi suất lấy một giá trị sprd tại ngày dữ liệu; không biết lịch sử điều chỉnh LS trong kỳ.', 'Giả thuyết cần xác nhận', 'Khoản LS thả nổi điều chỉnh trong kỳ sẽ lệch.'],
  ['A-05', 'Quá hạn chỉ xét ngày đến hạn khoản giải ngân; khoản trả góp theo kỳ (nxtrpmtschddt) có gốc kỳ quá hạn chưa được tách; lãi chậm trả trên tiền lãi quá hạn chỉ có ở công cụ Tính lãi tất toán.', 'Đã xác minh (phạm vi)', 'Ca trả góp / chậm trả lãi có thể thiếu; cần quy định áp dụng (Q8).'],
  ['A-06', 'Đường đọc ngày dd/mm ≤ 12 từ tệp (HM-02) ảnh hưởng trực tiếp số ngày tính lãi.', 'Nghi vấn (đã sửa một nơi ở P53)', 'Đảo ngày/tháng làm sai số ngày.'],
], [700, 4100, 1700, 3138], { size: 17 }));
c.push(gap());
c.push(P([bold('Điểm đúng cần giữ. '), run('Cơ sở 365 ngày; quá hạn = LS × 1,5 theo ngày đến hạn từng khoản giải ngân; làm tròn từng thành phần rồi cộng; khoản không tính được không cộng vào tổng; lõi đạt 18/18 + 11/11 và hồi quy Máy tính lãi 80/80 ở các phiên trước.')]));
c.push(H2('Phương án tối ưu'));
c.push(B([bold('Giao diện (HM-13): '), run('thanh kết quả dính đầu bảng: Tổng dư nợ · Lãi trong hạn · Lãi quá hạn · Tổng phải thu · số khoản tính/không tính; bỏ cột Tên KH lặp (đưa vào thẻ khách hàng); bộ cột mặc định 9 cột: ☑ · Số GN · Đã thu lãi đến · Đến hạn · Dư nợ · LS · Số ngày (TH/QH) · Lãi · Tổng — cột phụ (Ngày GN, HĐTD, trả gốc, ngày thu riêng) mở bằng "Cột ▾" hoặc mở rộng dòng; tên trường kỹ thuật chuyển vào biểu tượng ⓘ; hộp công thức thu thành một dòng; điện thoại hiện mỗi khoản một thẻ, ô nhập ≥ 40 px; khoản quá hạn tô đỏ nhạt.')]));
c.push(B([bold('Chính xác (HM-14): '), run('(1) cột "Chênh so IPCAS" = lãi app tính đến ngày dữ liệu − lãi dự thu IPCAS, tô khoản lệch và nêu lý do; (2) lãi theo đoạn dư nợ khi có trả gốc giữa kỳ (lấy từ mốc Lưu trữ / lstrpmtdt + rpmtamt), thêm hàm lõi mới, không đổi tinhLaiKhoan; (3) cảnh báo ngày chốt > ngày dữ liệu + 0 ngày hoặc trước "đã thu lãi đến"; (4) bộ đối chiếu ≥ 20 khoản chứng từ thật ẩn danh, sai số 0 đồng.')]));
c.push(table(['ID', 'Hạng mục', 'Ưu tiên / Effort', 'Phụ thuộc', 'Ngữ cảnh', 'Model Effort*'],
  HM.filter(h => ['HM-13', 'HM-14'].includes(h.id)).map(h => [h.id, h.ten, h.uu_tien + ' / ' + h.effort, h.phu_thuoc.join(', ') || '—', h.chi_phi_uoc_tinh_pct + '%', h.model_effort_recommended]),
  [800, 4100, 1200, 1100, 1000, 1438], { size: 18 }));
c.push(P('Mốc nghiệm thu Đợt 4b: tổng lãi thấy ngay khi mở ở 1366×768; không cuộn ngang ở bộ cột mặc định và trên điện thoại; số tiền trùng từng đồng với bản cũ ở mọi ca không có trả gốc giữa kỳ; ca trả gốc giữa kỳ và bộ chứng từ thật khớp 0 đồng; cột chênh IPCAS giải thích được mọi khoản lệch.', { r: { italics: true, size: 20 }, p: { spacing: { before: 80, after: 160 } } }));
c.push(P([bold('Thứ tự đề xuất toàn Đợt 4: '), run('HM-01 → HM-02 → HM-14 (chính xác lãi) → HM-11 → HM-12 → HM-13, rồi HM-03…HM-10. Lý do: sai số tiền (P1) trước giao diện (P2); HM-14 và HM-11 cùng dùng dữ liệu kỳ và đường đọc ngày của HM-02.')]));

// ---------- Đợt 5 (v1.2) ----------
const EV5 = EV + 'khao_sat_p04/';
c.push(H2('Đợt 5 — Rà soát điểm nghẽn có kiểm chứng ảnh Playwright (bổ sung v1.2, chờ duyệt)'));
c.push(P([bold('Yêu cầu người dùng (05/11/2026). '), run('Tìm điểm nghẽn để chỉnh sửa, nâng cấp giao diện và tính chính xác số liệu — như đã làm với doanh số cho vay / thu nợ — cho: (1) toàn trang Khách hàng mới; (2) trang Máy tính lãi (đang rối mắt, khó theo dõi, tra cứu lãi); (3) trang Chỉ tiêu kế hoạch (bảng nhiều cột dài quá màn hình). Mọi hạng mục có kiểm chứng Playwright bằng hình ảnh.')]));
c.push(P([bold('Cách khảo sát (đã chạy, chỉ đọc, 05/11/2026). '), run('Bản v24.17.15, dữ liệu thử ẩn danh 3 mốc msit80 (30/09, 15/10, 31/10/2026) + sao kê TSBĐ thử; Playwright Chromium 1366×768 và 390×844; chụp mọi tab, đo DOM: tràn ngang, số cột, bề rộng bảng so với khung, cột dính, nút < 28/40 px, chữ < 11 px, pageerror. Kịch bản: kiem_thu_p04/khao_sat_khm_lai.py, khao_sat_ctkh_tab.py; ảnh + số đo: evidence/khao_sat_p04/. Kết quả chung: 0 pageerror, 0 tràn ngang ở cấp trang — điểm nghẽn nằm ở SỐ LIỆU không thống nhất và BẢNG RỘNG/DÀY ĐẶC.')]));

c.push(H2('5.1 Khách hàng mới (HM-18)'));
c.push(table(['#', 'Điểm nghẽn (bằng chứng)', 'Loại', 'Hướng sửa'], [
  ['K-01', 'Cùng một trang, hai số Thu nợ: thẻ KPI "Thu nợ (kỳ này)" 528.309.284.000 đ (= GN − chênh lệch dư nợ, suy ra) ≠ bảng Đối soát 544.704.901.000 đ (đo từng khế ước) → lệch 16.395.617.000 đ.', 'Chính xác (P1)', 'KPI lấy từ lõi QLTD_DSTN khi có mốc Lưu trữ; chỉ dùng cách suy ra khi chọn tệp tay và ghi nhãn "suy ra".'],
  ['K-02', '"Doanh số cho vay" KPI 50.658.000.000 đ / 110 món ≠ Đối soát GN 63.325.000.000 đ / 124 món (khác ở GN thêm trên khế ước cũ và món GN rồi tất toán giữa kỳ).', 'Chính xác (P1)', 'Chốt định nghĩa (Q11); hiển thị cả 2 số có tên rõ, cùng nguồn.'],
  ['K-03', 'Dư nợ đầu kỳ "3.881 món" (KPI) ≠ 4.006 khế ước ở Đối soát (gồm khế ước dư nợ 0, GN mới).', 'Nhãn', 'Ghi rõ "món còn dư nợ" vs "khế ước tham gia kỳ".'],
  ['K-04', 'Tab Chi tiết: 19 phần tử chữ < 11 px (nhãn "đã tất toán"), 18 nút < 28 px; điện thoại: bảng 10 cột rộng 913 px trong khung 360 px, cột Khách hàng không dính.', 'Giao diện', 'Chữ ≥ 11 px, nút ≥ 28/40 px, cột đầu dính, điện thoại dạng thẻ.'],
  ['K-05', 'KPI và bảng Tổng hợp/Chi tiết không bấm được để xem món cấu thành (Đối soát đã có từ HM-12).', 'Tra cứu', 'Áp mô hình HM-12 cho KPI và Tổng hợp.'],
  ['K-06', 'Kỳ báo cáo (Từ–Đến) và cặp mốc Lưu trữ chọn ở 2 nơi; có thể lệch nhau (đã có cảnh báo ở Đối soát).', 'Luồng', 'Một bộ chọn kỳ; tự suy kỳ từ mốc.'],
  ['K-07', 'Ảnh "toàn trang" chỉ chụp được 768 px vì nội dung cuộn trong khung chính, không phải cửa sổ.', 'Kiểm chứng', 'Bộ kiểm cuộn khung chính, ghép ảnh từng đoạn; so ảnh chuẩn.'],
], [700, 4500, 1300, 3138], { size: 17 }));
c.push(...img(EV5 + 'khm_desktop_1_tongquan.jpg', 560, 'Tab Tổng quan (1366): Thu nợ 528,31 tỷ (suy ra) — cùng kỳ, bảng Đối soát cho 544,70 tỷ'));

c.push(H2('5.2 Máy tính lãi & Lãi đọng (HM-19, làm cùng HM-13; dùng kết quả HM-14)'));
c.push(table(['#', 'Điểm nghẽn (bằng chứng)', 'Loại', 'Hướng sửa'], [
  ['L-01', 'Hai nút cạnh nhau "Máy tính lãi" và "Tính lãi tất toán" mở hai công cụ khác nhau.', 'Luồng', 'Một lối vào, 2 chế độ (Tra cứu KH / Tính tay).'],
  ['L-02', 'Hộp tính: danh sách khách chiếm ~60% chiều cao, kết quả bị đẩy xuống đáy; điện thoại phải cuộn trong hộp mới thấy TỔNG LÃI.', 'Giao diện', 'Chọn xong thu gọn danh sách; thanh tổng dính đầu.'],
  ['L-03', 'Khách có nhiều khoản hiện trùng tên (vd "Khách hàng 4" ×2) chỉ khác DN/LS — không có số khế ước, ngày đến hạn.', 'Tra cứu', 'Mỗi dòng: số khế ước · đến hạn · DN · LS.'],
  ['L-04', 'Kết quả dạng đoạn văn, ngày kiểu ISO "2026-02-01" lẫn dd/mm/yyyy; 3 dòng công thức lặp lại số.', 'Giao diện', 'Bảng 3 dòng (trong hạn / quá hạn / chậm trả) × (từ, đến, ngày, DN, LS, tiền); dd/mm/yyyy; nút Sao chép.'],
  ['L-05', 'Ví dụ thử: khoản chưa đến hạn gốc nhưng chậm lãi bị tính "quá hạn" 249 ngày × 150% LS trên TOÀN dư nợ (26,26 tr + phạt 13,13 tr).', 'Chính xác (cần xác nhận)', 'Chốt Q12; không đổi quy tắc khi chưa có căn cứ (quyết định đã chốt).'],
  ['L-06', 'Trang Lãi đọng có 3 tổng khác nhau không giải thích: "Tổng lãi đọng 18.830.000.000 đ", "Σ lãi 18.830.000.000", "Σ lãi dự thu 96.005.357.336".', 'Chính xác / nhãn', 'Ghi nguồn + công thức từng tổng, đối chiếu Python.'],
  ['L-07', '≥ 13 cột, cột Mã KH bị cắt ở 1366; 86–90 ô nhập (hàng lọc từng cột); 96 nút/ô < 28 px; toàn bộ dòng chữ đỏ → không phân cấp.', 'Giao diện', 'Bộ cột mặc định vừa khung; lọc gom vào 1 thanh; tô theo mức quá hạn.'],
], [700, 4500, 1300, 3138], { size: 17 }));
c.push(...img(EV5 + 'lai_desktop_3_hop_toan_bo.jpg', 560, 'Hộp Tính lãi tất toán (1366): danh sách chiếm phần lớn hộp, kết quả dạng văn bản ở đáy'));

c.push(H2('5.3 Chỉ tiêu kế hoạch (HM-20)'));
c.push(table(['#', 'Điểm nghẽn (bằng chứng)', 'Loại', 'Hướng sửa'], [
  ['C-01', 'Tab Theo CBTD / Theo phòng / Theo loại vay: 48 cột, tiêu đề 3 tầng, bảng rộng 2.908–2.964 px trong khung 1.104 px (điện thoại: 360 px); cột tên CBTD KHÔNG dính → cuộn ngang mất tên dòng.', 'Giao diện (P1)', 'Cột tên + tiêu đề dính; thanh chọn nhóm chỉ tiêu; chế độ "Live/%HT"; ẩn cột toàn 0; thẻ trên điện thoại.'],
  ['C-02', 'Theo CBTD gom phòng theo danh mục cán bộ ("Phòng Khách hàng" 1 CBTD, "PGD HBT" = 0, "PGD Số 2" 1.520,6 tỷ) trong khi trang Khách hàng mới gom theo phòng của khế ước (Hội Sở / PGD Hai Bà Trưng / PGD Số 2). Tổng chi nhánh khớp 1.767.464.001.000 đ, tổng PHÒNG khác nhau giữa 2 trang.', 'Chính xác (cần xác nhận)', 'Chốt Q13; ghi nguồn phòng; đối chiếu Python 0 đồng 3 cấp.'],
  ['C-03', 'Tab Tổng quan: cột "Đầu Q3/2026" = 2.245.115.285.000 (số dư 30/09 = đầu Q4), "Đầu T10/2026" = số dư 31/10 (cuối T10) → nhãn mốc lệch kỳ.', 'Chính xác (giả thuyết)', 'Chốt Q14; nhãn ghi kèm ngày số dư.'],
  ['C-04', 'Chỉ tiêu Nguồn vốn, Thẻ, Doanh thu dịch vụ, ABIC luôn 0 / "—" (app không có nguồn dữ liệu) — chiếm 8/12 dòng.', 'Giao diện', 'Thu gọn nhóm chưa có dữ liệu, ghi "nhập tay".'],
  ['C-05', '24 phần tử chữ < 11 px, 9–13 nút < 28/40 px; điện thoại bảng Tổng quan 719 px / khung 360 px, cột số bị cắt.', 'Giao diện', 'Như HM-06; kiểm 360 px.'],
], [700, 4500, 1300, 3138], { size: 17 }));
c.push(...img(EV5 + 'ctkh_desktop_tab1.jpg', 560, 'Theo CBTD (1366): 48 cột, chỉ thấy ~5 nhóm đầu; cột tên không dính khi cuộn ngang'));

c.push(H2('Hạng mục Đợt 5'));
c.push(table(['ID', 'Hạng mục', 'Ưu tiên / Effort', 'Phụ thuộc', 'Ngữ cảnh', 'Model Effort*'],
  HM.filter(h => h.dot === 5).map(h => [h.id, h.ten, h.uu_tien + ' / ' + h.effort, h.phu_thuoc.join(', ') || '—', h.chi_phi_uoc_tinh_pct + '%', h.model_effort_recommended]),
  [800, 4100, 1200, 1100, 1000, 1438], { size: 18 }));
HM.filter(h => h.dot === 5).forEach(h => { c.push(P([bold(h.id + ' — tiêu chí nghiệm thu: ')])); h.tieu_chi_nghiem_thu.forEach(t => c.push(B(t))); c.push(P([bold('Rủi ro: '), run(h.rui_ro)], { r: { size: 20 } })); });
c.push(P('Phương pháp kiểm chứng chung Đợt 5: (1) bộ kiểm V3 tái hiện điểm nghẽn trên bản trước sửa (phải FAIL) và PASS trên bản sửa; (2) ảnh toàn trang theo từng đoạn cuộn khung chính, mọi tab × 1366/390 (+360 khi có bảng rộng), lưu cặp trước–sau kèm số đo DOM; (3) số liệu đối chiếu công cụ Python độc lập 0 đồng trên dữ liệu thử, rồi dữ liệu thật ở thư mục tạm (không vào repo/ZIP); (4) hồi quy chung trước–sau.', { r: { italics: true, size: 20 }, p: { spacing: { before: 80, after: 160 } } }));
c.push(P([bold('Thứ tự đề xuất sau v1.2: '), run('HM-12 (đang làm, đóng) → HM-18 (cùng lõi, sửa sai số KPI) → HM-14 → HM-19 + HM-13 (cùng phiên) → HM-20 → HM-03…HM-10. Lý do: K-01/K-02 là sai số hiển thị đang có trên trang đã dùng; HM-19 cần kết quả chính xác của HM-14 trước khi dựng lại giao diện.')]));
c.push(H2('Ước tính số phiên'));
c.push(P(`Tổng chi phí ${TONG}% (bỏ HM-09: ${TONG_BO9}%). Sức chứa hữu dụng mỗi phiên ≈ 60%, nên ⌈${TONG}÷60⌉ = ${Math.ceil(TONG/60)}. Phần CHƯA làm (kể cả Đợt 5): ${CON}% → khoảng ${Math.ceil(CON/60)}–${Math.ceil(CON/60)+1} phiên thực thi nữa (P04 trở đi), vì mỗi hạng mục cần ZIP và câu hỏi chuyển tiếp. Hiệu chỉnh sau 2 hạng mục đầu; báo bạn nếu lệch quá ~25%.`));
c.push(P('*Model Effort: mức suy luận khuyến nghị theo Phụ lục E của skill (tự động đề xuất, chưa phải thay đổi cài đặt thật); khác với Effort XS/S/M/L là độ lớn hạng mục.', { r: { italics: true, size: 18 } }));


// ---------- 10 ----------
c.push(H1('10. Chiến lược kiểm chứng'));
c.push(B([bold('Bậc: '), run('V3 (Playwright Python + Chromium 153) khả dụng, dùng cho mọi hạng mục trừ HM-10 (tài liệu, V2). Không ghi V3 khi chỉ chạy V2.')]));
c.push(B([bold('Viewport: '), run('1366×768 và 390×844 cho mọi hạng mục giao diện; thêm 360×740 để lộ hồi quy tràn ngang.')]));
c.push(B([bold('Dữ liệu: '), run('chỉ fixture ẩn danh do tạo hoặc bạn cung cấp; không dùng dữ liệu khách hàng thật trong kiểm thử hay ZIP.')]));
c.push(B([bold('Hồi quy: '), run('HM-01 tạo bộ chạy chung; từ HM-02 trở đi mỗi hạng mục chạy bộ chung sau lần sửa cuối.')]));
c.push(B([bold('Chống tái diễn: '), run('mỗi lỗi có ít nhất một test tự động; khi khả thi, chứng minh test FAIL với mã cũ và PASS với mã mới.')]));
c.push(B([bold('Giới hạn: '), run('chỉ Chromium headless; chưa có thiết bị thật, Safari hay Firefox. Hạng mục chạm giao diện sẽ kèm kịch bản kiểm tay ngắn nếu cần.')]));
c.push(H1('11. Vận hành nhiều phiên'));
c.push(B('Mỗi phiên mở bằng ZIP bàn giao (HANDOVER.md, backlog.json, MANIFEST.sha256); xác minh checksum trước khi làm; không khảo sát lại từ đầu.'));
c.push(B('Sau mỗi hạng mục: dựng ZIP hạng mục (điểm hoàn tác), gửi bạn, rồi hỏi trước khi sang hạng mục kế; chỉ một hạng mục đang mở.'));
c.push(B('Ngưỡng ngữ cảnh: Xanh dưới ~60%, Vàng 60–80% (không mở hạng mục lớn), Đỏ trên ~80% (đóng phiên ngay); luôn dành ≥15% để đóng gói.'));
c.push(B('Điểm hoàn tác: các ZIP cũ và gói gốc QLTDPRO_P53_v36.zip (sha256 ghi trong baseline/).'));


// ---------- 12 ----------
c.push(H1('12. Rủi ro và đường lui'));
c.push(table(['Rủi ro', 'Khả năng', 'Tác động', 'Giảm thiểu'], [
  ['Vá chuỗi trên bản build làm vỡ phần khác', 'Trung bình', 'Cao', 'Bộ hồi quy chung (HM-01); patch nhỏ, assert đếm neo; mỗi hạng mục có ZIP hoàn tác.'],
  ['Test cũ FAIL vì bản mới thay đổi hợp lệ', 'Cao', 'Thấp', 'Phân loại từng ca; không nới assertion; ghi lý do.'],
  ['Chạm dữ liệu khách hàng thật', 'Thấp', 'Rất cao', 'Chỉ fixture; hỏi trước mọi thay đổi schema; sao lưu trước.'],
  ['Đổi service worker làm kẹt bản cũ ở máy dùng', 'Trung bình', 'Cao', 'Kiểm cài mới/cập nhật/ngoại tuyến; có đường hoàn tác sw.js cũ.'],
  ['Phát hiện mới làm đổi lộ trình', 'Trung bình', 'Trung bình', 'Ghi thẻ mới; thay đổi lớn thì phát hành đề án bản mới và hỏi bạn.'],
  ['Hết ngữ cảnh giữa hạng mục', 'Trung bình', 'Trung bình', 'Ghi trước khi làm; ZIP khẩn cấp ở vùng Đỏ.'],
], [3000, 1100, 1100, 4438]));
c.push(gap());
c.push(P('Sao lưu: baseline ghi checksum toàn bộ gói gốc; file sắp sửa được sao vào backup/ trước khi đổi. Hoàn tác: dùng lại ZIP trước đó; riêng app có thể quay về v24.17.8 theo bàn giao P53.'));

// ---------- 13 ----------
c.push(H1('13. Tiêu chí nghiệm thu tổng'));
c.push(B('Mọi hạng mục đã duyệt ở trạng thái DA_BAN_GIAO hoặc được bạn hoãn/hủy có ghi nhận.'));
c.push(B('Bộ hồi quy chung chạy trên bản cuối: không FAIL chưa giải thích; ca skip đều có lý do.'));
c.push(B('Không pageerror/console.error không mong đợi ở 23 route × viewport chuẩn.'));
c.push(B('Các nghi vấn F-03, F-04, F-05, F-06 đều có kết luận bằng thử nghiệm (đã sửa hoặc xác nhận an toàn).'));
c.push(B('Phát hành đổi phiên ở một chỗ; PWA ngoại tuyến vẫn mở; bàn giao có ZIP cuối kiểm tra được.'));

// ---------- 14 ----------
c.push(H1('14. Quyết định cần bạn chốt, câu hỏi mở'));
c.push(table(['Mã', 'Câu hỏi', 'Vì sao quan trọng'], [
  ['Q1', 'Mã nguồn React/Vite gốc còn ở nơi nào (repo, máy khác) không?', 'Nếu có, nâng cấp từ nguồn an toàn hơn vá chuỗi; nếu không, tiếp tục vá có kiểm soát.'],
  ['Q2', 'Thư mục templates/ (mẫu .docx) nằm ở đâu khi bạn dùng app, hay nạp vào IndexedDB?', 'Quyết định HM-07 và xác nhận chức năng tạo hồ sơ từ mẫu.'],
  ['Q3', 'Bạn mở app bằng cách nào (file://, host http, cài PWA) và có thể cung cấp bộ dữ liệu mẫu đã ẩn danh không?', 'Quyết định kiểm service worker (HM-08) và chất lượng fixture (HM-02…06).'],
], [700, 4500, 4438]));
c.push(gap());
c.push(table(['Mã', 'Câu hỏi (thêm ở v1.1)', 'Vì sao quan trọng'], [
  ['Q4', 'Cột rpmtamt của tệp msit80 là số gốc đã trả LŨY KẾ từ ngày giải ngân hay chỉ trong kỳ? Có thể gửi 2 tệp msit80 thật (đầu + cuối một tháng) đã ẩn danh tên?', 'Quyết định cách đo thu nợ độc lập ở HM-11; sai ý nghĩa cột sẽ sai toàn bộ thu nợ.'],
  ['Q5', 'Khế ước chuyển cán bộ/phòng giữa kỳ: tính GN/thu nợ cho cán bộ CUỐI KỲ (đang quản lý) hay tách theo thời điểm?', 'Ảnh hưởng doanh số từng cán bộ; đề án đề xuất: GN theo cán bộ cuối kỳ, thu nợ theo cán bộ đầu kỳ, có dòng "chuyển giao".'],
  ['Q6', 'Thu nợ cần gồm những gì: chỉ gốc, hay cả gốc xử lý rủi ro/bán nợ? Có cần thu lãi?', 'Xác định phạm vi số liệu và cột báo cáo.'],
  ['Q7', 'Trong tệp msit80, cột nào là lãi dự thu IPCAS tính đến ngày dữ liệu (intamt hay acramt), có gồm lãi quá hạn không?', 'Quyết định cột "Chênh so IPCAS" của HM-14.'],
  ['Q8', 'Có áp dụng lãi chậm trả trên tiền lãi quá hạn (tối đa 10%/năm) và tách gốc từng kỳ trả góp quá hạn trong Máy tính lãi không?', 'Phạm vi quy tắc nghiệp vụ — không tự đổi khi chưa có xác nhận.'],
  ['Q9', 'Có thể gửi ≥ 20 khoản có chứng từ thu lãi thật (đã ẩn tên) để đối chiếu 0 đồng không?', 'Tiêu chí nghiệm thu HM-14.'],
  ['Q11', 'KPI "Doanh số cho vay" (Khách hàng mới): chỉ món GN mới trong kỳ, hay cả GN thêm trên khế ước cũ + món GN rồi tất toán giữa kỳ (như bảng Đối soát)?', 'HM-18 (K-02).'],
  ['Q12', 'Khách chậm trả LÃI, gốc chưa đến hạn: tính 150% LS trên toàn dư nợ từ kỳ lãi kế tiếp (như hiện nay) hay lãi chậm trả ≤ 10%/năm trên số lãi chậm trả?', 'HM-19 (L-05), HM-14.'],
  ['Q13', 'Chỉ tiêu kế hoạch theo phòng: CBTD thuộc phòng theo danh mục cán bộ hay theo phòng ghi trên khế ước (trctnm)?', 'HM-20 (C-02).'],
  ['Q14', 'Cột "Đầu Q3", "Đầu T10": số dư ngày cuối kỳ trước (30/06, 30/09) hay mốc gắn nhãn Quý 3 / T10 trong Lưu trữ?', 'HM-20 (C-03).'],
  ['Q10', 'Báo cáo IPCAS nào đang dùng để đối chiếu doanh số thu nợ (mã báo cáo, có danh sách giao dịch trả nợ từng món không)? Có thể gửi một bản đã ẩn tên?', 'Quyết định HM-11/HM-12 khớp đến từng giao dịch hay đến từng mốc Lưu trữ.'],
], [700, 4500, 4438]));
c.push(gap());
c.push(BR());

// ---------- Phụ lục A ----------
c.push(H1('Phụ lục A. Backlog đầy đủ'));
c.push(table(['ID', 'Tên / phạm vi', 'Ưu tiên, Effort', 'Phụ thuộc', 'Tiêu chí nghiệm thu chính'],
  HM.map(h => [h.id, [h.ten, 'Phạm vi: ' + h.pham_vi], h.uu_tien + ', ' + h.effort + ', ' + h.chi_phi_uoc_tinh_pct + '%', h.phu_thuoc.join(', ') || '—', h.tieu_chi_nghiem_thu]),
  [700, 3300, 1100, 900, 3638], { size: 16 }));


// ---------- Phụ lục B ----------
c.push(H1('Phụ lục B. Bản đồ mã (v24.17.9.html)'));
c.push(table(['Khối', 'Dòng', 'Kích thước', 'Ghi chú'], [
  ['script module (bundle)', '2032–12259', '2.582 KB', 'React, SheetJS, JSZip, mã app — đã nén'],
  ['style gd10-align', '1480–2650', '1.442 KB', 'Có 2 chuỗi font base64 (Giả thuyết: phần lớn dung lượng)'],
  ['style bundle', '12260–12322', '188 KB', 'CSS của bản build'],
  ['script gd14-js', '13384–14616', '68 KB', 'Lớp vá lớn nhất (máy tính lãi/giao diện theo test P41–P42)'],
  ['script gd7-js', '198–1180', '67 KB', 'Lớp vá'],
  ['script gd11-js', '1541–2030', '25 KB', 'Lớp vá'],
  ['gd3, gd4, gd5, gd6, gd8, gd9, gd10, gd13 (JS)', 'rải rác', '≈ 40 KB', '8 lớp vá nhỏ'],
  ['style gd3–gd12', 'rải rác', '≈ 30 KB', 'CSS lớp vá'],
], [3000, 1500, 1300, 3838]));
c.push(gap());
c.push(P('Mẫu đếm chuỗi (module / lớp vá): innerHTML 78 / 27; localStorage 80 / 24; indexedDB 14 / 5; catch rỗng 94 / 42; console.error 38 / 0; fetch 1 / 2. Số trong module gồm cả thư viện đóng gói nên chỉ là chỉ báo.', { r: { size: 20 } }));

// ---------- Phụ lục C ----------
c.push(H1('Phụ lục C. Bằng chứng'));
c.push(table(['Tệp (evidence/)', 'Nội dung / kết quả'], [
  ['01_ban_do_ma.log', 'Bản đồ khối script/style; 14.767 dòng; 55 dòng >5.000 ký tự.'],
  ['02_khoi_nen_dom.log', 'Mở app 2 viewport: pageerror 0; 1 console 404 (mẫu .docx); tải 3.061 / 2.915 ms.'],
  ['03_quet_route_23x2.log', '23 route × 2 viewport: pageerror 0; tràn ngang tài liệu 0 px; phần tử vượt khung (Mục 6).'],
  ['04_sw_offline.log', 'Service worker active; cache qltdpro-p53-v24.17.9; tải lại ngoại tuyến mở được.'],
  ['05_test_p53_khm_luu_tru.log', 'P53: 10/10 PASS trên v24.17.9.'],
  ['06 / 07 (lõi lãi)', '18/18 và 11/11 ca đạt.'],
  ['08_test_p52_tren_v24.17.8.log', 'P52: 14/14 nhưng trên v24.17.8 (bộ kiểm trỏ cứng bản cũ).'],
  ['*.py, baseline_*.jpg', 'Script khảo sát và 2 ảnh baseline.'],
], [3300, 6338]));

// ---------- Phụ lục D ----------
c.push(H1('Phụ lục D. Nhãn và thuật ngữ'));
c.push(B([bold('Đã xác minh: '), run('có bằng chứng chạy hoặc đọc trực tiếp. '), bold('Giả thuyết: '), run('suy luận hợp lý, chưa kiểm. '), bold('Chưa đủ bằng chứng: '), run('nghi vấn, chưa kết luận.')]));
c.push(B([bold('V3/V2/V1: '), run('Playwright thật / kiểm tự động không trình duyệt / rà tĩnh + kiểm tay.')]));
c.push(B([bold('Effort: '), run('XS≈3%, S≈6%, M≈10%, L≈18% ngữ cảnh một phiên.')]));
c.push(B([bold('Lớp vá gdN: '), run('khối script/style nội tuyến thêm vào bản build ở các phiên trước.')]));

// ---------- Phụ lục E ----------
c.push(H1('Phụ lục E. Lịch sử bản đề án'));
c.push(table(['Bản', 'Ngày', 'Nội dung'], [['v1.0', '04/11/2026', 'Bản đầu. Người dùng duyệt bằng lệnh "Thực thi" (04/11/2026).'], ['v1.1', '04/11/2026', 'Thêm Đợt 4: HM-11, HM-12 (doanh số giải ngân + thu nợ theo cán bộ/phòng, đối soát độc lập) theo yêu cầu người dùng; thêm Đợt 4b Máy tính lãi: HM-13 (giao diện), HM-14 (chính xác số liệu); HM-12 mở rộng: bấm số tiền thu nợ xem chi tiết từng món theo cán bộ/phòng; thêm Q4–Q10. Chờ duyệt phần bổ sung.'], ['v1.2', '05/11/2026', 'Thêm Đợt 5 (rà soát điểm nghẽn, kiểm chứng ảnh Playwright): HM-18 Khách hàng mới toàn trang, HM-19 Máy tính lãi & Lãi đọng, HM-20 Chỉ tiêu kế hoạch; khảo sát thật trên v24.17.15 (evidence/khao_sat_p04); thêm Q11–Q14. HM-12 đang làm (v24.17.15, V3 28/28). Chờ duyệt phần bổ sung.']], [1200, 1800, 6638]));

const doc = new Document({
  creator: 'Claude', title: 'Đề án QLTDPRO v1.2', description: 'Đề án S0 theo skill web-app-repair-upgrade v3.2.0',
  styles: {
    default: { document: { run: { font: FONT, size: 22 } } },
    paragraphStyles: [
      { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { font: FONT, size: 32, bold: true, color: '1F3864' }, paragraph: { spacing: { before: 240, after: 140 }, keepNext: true, outlineLevel: 0 } },
      { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { font: FONT, size: 26, bold: true, color: '2F5496' }, paragraph: { spacing: { before: 200, after: 100 }, keepNext: true, outlineLevel: 1 } },
    ],
  },
  numbering: { config: [{ reference: 'bul', levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 540, hanging: 270 } } } }] }] },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1134, bottom: 1134, left: 1134, right: 1134 } } },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [run('QLTDPRO — Đề án v1.2 (v1.0–v1.1 đã duyệt · Đợt 5 chờ duyệt)', { size: 16, color: '7F7F7F' })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [run('Trang ', { size: 16 }), new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 16 })] })] }) },
    children: c,
  }],
});
Packer.toBuffer(doc).then(b => { fs.writeFileSync('/home/claude/work/de-an/DE_AN_QLTDPRO_v1.2.docx', b); console.log('OK', b.length); });
