# HM-23 + HM-24 — Tài sản bảo đảm: tab "TS chưa có HĐTD", tab "Đầu kỳ & 2 mốc", mốc tự lưu — BÁO CÁO (P04, 06/11/2026)

Bản: **v24.17.25 → v24.17.26** (`app/QLTDPRO_P43/nguon_P04/build_p04_hm23.py`, lớp `nguon_P04/gd23.js` 1.0.0). Bậc đạt: **V3** (dữ liệu thử ẩn danh).
Quyết định người dùng 06/11: HM-23 chỉ tài sản "chưa có hồ sơ"; HM-24 "Cả hai"; Q16 mốc TSBĐ "Cả hai" (tự lưu theo ngày tệp + giữ bấm tay).

## 1. Thay đổi
| Phần | Nội dung |
|---|---|
| Mốc tự lưu (Q16) | Mỗi lần lưu tệp sao kê TSBĐ, app ghi thêm `moc_<ngày>` vào kho **kv sẵn có** của CSDL `QLTDProTSBD` (không tạo CSDL mới → "Tải bản sao lưu toàn bộ" vẫn chứa). Ngày = ngày trong tên tệp (vd 16.10.2026, 31_10_2026), không có thì ngày nhập. Giữ tối đa 120 mốc. Bản cài cũ chưa có mốc → khi mở tab tự tạo mốc từ dữ liệu hiện hành một lần. Nút "Lưu mốc hiện tại" (bấm tay) giữ nguyên. |
| Tab 🆕 TS chưa có HĐTD | Chọn mốc và mốc so sánh. Bảng Phòng → Cán bộ: số TS chưa có HĐTD, giá trị (tr.đ), **Mới** (so mốc trước — TS mới nhập chưa có hồ sơ), **Đã có HĐTD**, **Không còn trong sao kê**. Bấm số → danh sách (Số TS, Số HĐ thế chấp, khách hàng, mã KH, cán bộ, loại, giá trị, ngày thế chấp, địa chỉ) + **Xuất Excel**. |
| Định nghĩa "chưa có HĐTD" | Khách (mã KH → mã chủ TS → tên không trùng) **không có dòng nào, kể cả khế ước dư nợ 0**, trong mốc dư nợ Lưu trữ cùng ngày hoặc gần nhất trước ngày mốc TS. (Khác chỉ số "Không có hồ sơ trong DATA" ở tab Danh sách — chỉ số đó so với dư nợ hiện hành, không tính khế ước dư nợ 0.) |
| Tab 📅 Đầu kỳ & 2 mốc | Bảng như Báo cáo ngày: Đầu năm / Đầu quý / Đầu tháng (= mốc tự lưu gần nhất ≤ ngày cuối kỳ trước của Ngày BC — Q14) / Ngày BC (mốc mới nhất) / +/- tháng, quý, năm; chọn chỉ số Số TS / Giá trị TS / TS chưa có HĐTD; nhãn cột ghi ngày mốc thật hoặc "chưa có mốc". Phần dưới: chọn 2 mốc bất kỳ (tự lưu hoặc bấm tay) → Số TS ở A, ở B, Thêm, Mất, Đổi trạng thái HĐTD; bấm số xem danh sách. |
| Khác | gd15 xuất bộ ghi .xlsx dùng chung (`window.__gd15TaiXlsx`); nội dung dựng bằng textContent (an toàn như HM-04). Thứ tự phòng/cán bộ trong 2 tab hiện theo bảng chữ cái — HM-21 sẽ đổi theo Báo cáo ngày cho mọi trang. |

## 2. Kiểm chứng — `python3 kiem_thu_p04/test_hm23_ts_moc.py app/QLTDPRO_v24.17.26.html` — **25/25** (1366 + 390)
Dữ liệu: dư nợ 3 mốc + 1 khách vay mới thêm ở 31/10; tệp TS 30/09 (4 TS khách cũ, N1, N2 mới, N3 khách vay mới ở 31/10, N4) và 31/10 (bỏ N4, thêm N5, N6, thêm TS của khách cũ); 2 cán bộ ở 2 phòng. Đáp án Python độc lập.
| Ca | Kết quả |
|---|---|
| M1 | Nhập 2 tệp TS → mốc moc_2026-09-30, moc_2026-10-31 |
| K1–K4, K3b | Theo cán bộ: chưa có HĐTD / mới / đã có HĐTD / không còn = Python; bấm "Mới" → N5; "Đã có HĐTD" → N3; Xuất Excel; ngày dd/mm/yyyy |
| D0–D2 | Nhãn mốc (Đầu năm chưa có mốc; Đầu quý, Đầu tháng = 30/09; Ngày BC 31/10); chỉ số TS chưa có HĐTD và Số TS: cột + chênh = Python; so 2 mốc: Thêm / Mất / Đổi trạng thái = Python |
| T1–T2 | Mốc bấm tay xuất hiện trong "So 2 mốc" và cho số như mốc tự lưu cùng dữ liệu |
| B1 | Xoá mốc tự lưu (giả lập bản cài cũ) → mở tab tạo lại mốc từ dữ liệu hiện hành |
| M2, E1 | Điện thoại không tràn ngang; 0 pageerror |
| Cùng bộ trên v24.17.25 | FAIL M1 rồi dừng (chưa có tab) |
| Hồi quy chung v24.17.26 | 1338 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ) |
Ảnh: `anh/` (tab TS chưa có HĐTD, tab Đầu kỳ & 2 mốc — máy tính và điện thoại).

## 3. Lưu ý dùng
- Để bảng Đầu kỳ có số: nhập tệp sao kê TSBĐ vào cuối mỗi tháng/quý (tên tệp có ngày), và có tệp dư nợ msit80 cùng ngày hoặc trước đó trong Lưu trữ.
- Mốc tự lưu chỉ bắt đầu từ bản này; các tệp TS đã nhập trước đây không có mốc lịch sử (trừ mốc tạo từ dữ liệu hiện hành).
