# HM-11b — Gắn lõi QLTD_DSTN vào trang Khách hàng mới (P03, 05/11/2026)

**Bản:** app/QLTDPRO_P43/app/QLTDPRO_v24.17.12.html (sha256 259a9d94…66d1), dựng bằng `nguon_P02/build_p03_hm11b.py` từ v24.17.11.
**Thay đổi:** (1) gd11 xuất API chỉ đọc Lưu trữ `window.__gd11Api` (không đổi schema); (2) chèn `<script id="qltd-dstn-js">` (lõi 1.0.1 nguyên văn) + `<script id="gd15-js">` (nguon_P02/gd15.js) + `<style id="gd15-css">`.
**Hành vi:** tab Đối soát → khối `khm-dstn`: lấy mốc đầu/cuối đã chọn ở "Nạp từ Lưu trữ" + MỌI mốc Lưu trữ ở giữa (mỗi ngày lấy bản mới nhất) → QLTD_DSTN → bảng Phòng → Cán bộ (Dư nợ đầu, Số món GN, GN, Thu nợ, Điều chỉnh, Dư nợ cuối, Kiểm tra, Số khế ước, Tất toán), thu gọn theo phòng; cảnh báo chỉ 2 mốc / khoảng > 31 ngày / kỳ báo cáo khác kỳ mốc. Bảng cũ "Thu nợ suy ra" ẩn, có nút "Xem bảng cũ". Tệp chọn tay (không qua Lưu trữ): báo cần mốc Lưu trữ, giữ bảng cũ. `window.__khmDstn` = kết quả lõi (khe[]) cho HM-12.

## Kiểm chứng
| Bậc | Lệnh | Kết quả |
|---|---|---|
| V3 Chromium 153, 1366×900 + 390×844 (is_mobile) | `python3 kiem_thu_p03/test_hm11b_dstn.py app/QLTDPRO_v24.17.12.html` (dữ liệu thử ẩn danh `tao_mis80_thu.py`: 3 mốc, đổi HĐTD, đổi CB, tất toán, GN mốc giữa rồi tất toán, xuất hiện lại, chuyển đến, khách hết dư nợ) | **25/25 PASS**, 0 pageerror/console.error/request lỗi |
| V3 dữ liệu THẬT (11 tệp msit80 31/12/2025→31/10/2026 người dùng gửi; chỉ ở thư mục tạm, không lưu log/ảnh) | `MIS_DIR=… TS_FILE=… python3 kiem_thu_p03/test_hm11b_dstn.py …` | **23/25 PASS** — FAIL A3 (chuỗi 11 mốc) và B1 (2 mốc): app thiếu GN so với công cụ (chuỗi: 10 món / 7.419.000.000 đ; 2 mốc: 11 món / 3.625.000.000 đ), thu nợ thiếu đúng bằng số đó; Kiểm tra = 0 mọi dòng |
| Hồi quy chung trước (v24.17.11) | `kiem_thu_chung/chay_hoi_quy.py --app app/QLTDPRO_v24.17.11.html` | PASS 799 · FAIL 0 · LỆCH PB 12 · SKIP 2 (LOI_MT 2 bộ: p41_gd14, p42_gd14 — lỗi nền đã biết) |
| Hồi quy chung sau (v24.17.12) | `… --app app/QLTDPRO_v24.17.12.html` | PASS 799 · FAIL 0 · LỆCH PB 12 · SKIP 2 — y hệt; p53_khm 10/10 |

## Nguyên nhân lệch trên dữ liệu thật (đã xác minh, ngoài gd15)
Tệp msit80 thật liệt kê cả khế ước **dư nợ = 0** (13 dòng ở 31/12/2025, 15 dòng ở 31/10/2026 — khoản GN rồi trả hết vẫn còn trong tệp). Khâu Nhập dữ liệu → Lưu trữ (bundle) chỉ lưu dòng có dư nợ > 0, nên mốc Lưu trữ không có các khoản này. Bằng chứng: chạy lõi trên đầu vào của công cụ đã lọc dòng dư nợ 0 → khớp app **0 đồng ở mọi cột, 0/7.065 khế ước lệch** (2 mốc). Không có lệch nào khác.
→ Thẻ mới **HM-16** (P1, S): giữ dòng dư nợ 0 của mỗi mốc (kho phụ, không đổi dữ liệu các báo cáo cũ) để GN trả hết trong kỳ được tính. Cần người dùng chọn.

## Chưa bao phủ
Xuất Excel đối soát từ màn hình (để HM-12); mốc Lưu trữ không có ngày (dayKey) → báo lỗi, không tính; số liệu theo đơn vị đồng (không theo nút đơn vị của app).
