| Khóa localStorage | Dài | Kiểu | Nhóm |
|---|---|---|---|
| `_archiveDataList` | 257 | array | Danh mục mốc Lưu trữ |
| `_archiveReportList` | 681 | array | Danh mục mốc Lưu trữ |
| `_currentFileDate` | 10 | text | Trạng thái tạm (ngày tệp, mốc trước) |
| `_prevDunoSnap` | 304833 | object | Trạng thái tạm (ngày tệp, mốc trước) |
| `gd14_chot` | 10 | text | Máy tính lãi (ngày chốt) |
| `gd9_tplok` | 1 | number | Mẫu Word (gd9) |
| `qltd2_baocao_v1` | 3280 | array | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_sb_groups` | 2 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_cam-co` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_canh-bao` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_chlm` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_denhan` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_giai-ngan` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_laidong` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_ngan` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_tat-ca-du-no` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_trung` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_tsbd` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `td_hub_log_v1` | 728 | array | Cài đặt chung (td.*) |

| CSDL IndexedDB | Phiên bản | Kho (số bản ghi, ~byte) |
|---|---|---|
| `QLTDKhachHangMoi` | 1 | files (0, 5) |
| `QLTDPro2Undo` | 1 | last (1, 1032) |
| `QLTDProDB` | 3 | chunks (7, 241438); snapshots (1, 205) |
| `QLTDProFolder_v1` | 1 | kv (0, 5) |
| `QLTDProGD9` | 1 | kv (19, 357973) |
| `QLTDProMauHsvx` | 1 | files (0, 5) |
| `QLTDProTSBD` | 1 | kv (0, 5); snapshots (0, 5) |
| `TWIN_Archive_v1` | 1 | reportData (6, 4723249) |

| sessionStorage | Dài |
|---|---|
| `hsvx_gd1a_tab` | 8 |
