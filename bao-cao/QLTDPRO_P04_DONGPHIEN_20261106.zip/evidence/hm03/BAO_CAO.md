# HM-03 — Kiểm kê và kiểm chứng lớp lưu trữ cục bộ — BÁO CÁO (P04, 05/11/2026)

Bản: **v24.17.22 → v24.17.23** (`app/QLTDPRO_P43/nguon_P04/build_p04_hm03.py`, `nguon_P04/gd21.js`). Bậc đạt: **V3** (app thật, dữ liệu thử 2 tệp msit80 có sẵn trong gói). **Không đổi schema, khóa, CSDL.**

## 1. Kiểm kê (động — sau khi nạp dữ liệu thử và đi qua mọi trang; chi tiết `kiem_ke_QLTDPRO_v24.17.23.json`)
| Khóa localStorage | Dài | Kiểu | Nhóm |
|---|---|---|---|
| `_archiveDataList` | 257 | array | Danh mục mốc Lưu trữ |
| `_archiveReportList` | 681 | array | Danh mục mốc Lưu trữ |
| `_currentFileDate` | 10 | text | Trạng thái tạm (ngày tệp, mốc trước) |
| `_prevDunoSnap` | 304833 | object | Trạng thái tạm (ngày tệp, mốc trước) |
| `gd14_chot` | 10 | text | Máy tính lãi (ngày chốt) |
| `gd9_tplok` | 1 | number | Mẫu Word (gd9) |
| `qltd2_baocao_v1` | 3280 | array | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_sb_groups` | 2 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_cam-co` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_canh-bao` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_chlm` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_denhan` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_giai-ngan` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_laidong` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_ngan` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_tat-ca-du-no` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_trung` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `qltd2_scope_tsbd` | 25 | object | Cài đặt bundle React (tiền tố qltd2_) |
| `td_hub_log_v1` | 728 | array | Cài đặt chung (td.*) |

| CSDL IndexedDB | Phiên bản | Kho (số bản ghi, ~byte) |
|---|---|---|
| `QLTDKhachHangMoi` | 1 | files (0, 5) |
| `QLTDPro2Undo` | 1 | last (1, 1032) |
| `QLTDProDB` | 3 | chunks (7, 241438); snapshots (1, 201) |
| `QLTDProFolder_v1` | 1 | kv (0, 5) |
| `QLTDProGD9` | 1 | kv (19, 357973) |
| `QLTDProMauHsvx` | 1 | files (0, 5) |
| `QLTDProTSBD` | 1 | kv (0, 5); snapshots (0, 5) |
| `TWIN_Archive_v1` | 1 | reportData (6, 4723249) |

| sessionStorage | Dài |
|---|---|
| `hsvx_gd1a_tab` | 8 |

**Nguồn sự thật / vai trò** (đối chiếu mã):
| Kho | Vai trò | Ghi bởi | Phiên bản / chuyển đổi |
|---|---|---|---|
| `QLTDProDB` (chunks, snapshots) | Dư nợ hiện hành (bảng qltd), chia khối | bundle (Nhập dữ liệu) | v3 |
| `TWIN_Archive_v1/reportData` | Mốc Lưu trữ (dòng dư nợ từng ngày; `rpt0_*` = dòng dư nợ 0 — HM-16) | gd11/bundle | v1; danh mục mốc ở localStorage `_archiveDataList`, `_archiveReportList` |
| `QLTDProGD9/kv` | **Bản sao dự phòng của localStorage** (gd9 bọc setItem/removeItem/clear, đẩy sau 400 ms); khi tải trang nếu localStorage thiếu khóa → ghi trả và tải lại 1 lần; kiểm khóa JSON hỏng → thông báo | gd9 | v1 |
| `QLTDPro2Undo/last` | Hoàn tác lần nhập cuối | bundle | v1 |
| `QLTDProTSBD`, `QLTDKhachHangMoi`, `QLTDProMauHsvx`, `QLTDProFolder_v1` | TSBĐ, Khách hàng mới (tệp), mẫu Word HSVX, thư mục tự quét (handle) | bundle/gd14 | v1 (rỗng khi chưa dùng) |
| localStorage `qltd2_*` | Cài đặt bundle (phạm vi trang, bố cục bảng `qltd2_tbl_*`, báo cáo) — đọc/ghi qua K0/is có try/catch | bundle | REV gd7 cho bố cục bảng; `l07` (L-07) |
| localStorage `_prevDunoSnap` | Ảnh dư nợ kỳ trước để so sánh (~300 KB với 3,9 nghìn dòng thử) | bundle | **rủi ro đầy bộ nhớ với dữ liệu lớn** |
| localStorage khác (khi dùng chức năng) | `ctkh_plan_v2` (đọc được `ctkh_plan_v1` cũ), `gd14_chot`, `gd20_ctkh`, `hsv_records_v1`, `pa_sxkd_v9…v12`, `pa_fm_links_v1`, `td.*`, `khm tick`, `tranop_notes_v1`, `qltd_links_v1`, `hsvx_links_v1` | các lớp | quét tĩnh: mọi `JSON.parse(localStorage…)` đều nằm trong try/catch |

## 2. Kiểm chứng (`python3 kiem_thu_p04/test_hm03_luu_tru.py app/QLTDPRO_v24.17.23.html` — **19/19**)
| Ca | Kết quả |
|---|---|
| A — đi qua mọi trang (từ thanh điều hướng) với dữ liệu thử | 0 pageerror, không trang lỗi |
| B — "Tải bản sao lưu toàn bộ" → khôi phục ở trình duyệt SẠCH | mọi kho IndexedDB có dữ liệu trùng từng bản ghi (băm nội dung), mọi khóa localStorage trùng, bản sao GD9 khớp localStorage, trang Tất cả dư nợ cùng số dòng + tổng, 0 pageerror |
| C — 16 khóa JSON thành "{hỏng" | mọi trang mở được, dư nợ còn nguyên; 11 khóa app tự ghi lại bằng giá trị mặc định hợp lệ khi dùng, 5 khóa còn lại giữ nguyên; tải lại trang → app báo "Phát hiện 5 mục dữ liệu lưu trữ hỏng" (cơ chế gd9 có sẵn) |
| D — xoá hết localStorage | mọi trang mở được, dư nợ (IndexedDB) còn nguyên |
| E — kế hoạch năm dạng cũ `ctkh_plan_v1` | đọc và chuyển đúng (KH tổng dư nợ 5.000.000.000.000) |
| F — localStorage đầy (QuotaExceededError giả lập ở tầng thấp nhất) | 0 pageerror, dư nợ đọc được; **mới (gd21)**: thông báo "Bộ nhớ trình duyệt đã ĐẦY — thay đổi … KHÔNG được lưu … Tải bản sao lưu toàn bộ" |
| Cùng bộ trên v24.17.22 | 18/19 — chỉ F2 FAIL (không có thông báo đầy bộ nhớ) |
| Hồi quy chung v24.17.23 | 1275 PASS · 1 FAIL (p52_ma_kh R2 chập chờn — bắt 13 số trong mã băm SHA-256 ở title; đã sửa bộ kiểm p52 bỏ chuỗi hex → chạy lại 3/3 lần 14/0) ⇒ 0 FAIL do HM-03; LOI_MT p41/p42_gd14 như cũ |

## 3. Đề xuất (chưa làm — cần duyệt vì chạm cách lưu)
- Chuyển `_prevDunoSnap` (~300 KB, tăng theo số dòng) từ localStorage sang IndexedDB để tránh đầy bộ nhớ với dữ liệu thật lớn.
- Thông báo dữ liệu hỏng của gd9 bảo "vào Hệ thống để sao lưu hoặc xóa mục hỏng" nhưng **app chưa có công cụ xoá mục hỏng** (không nơi nào gọi `__gd9Storage.validate()` ngoài lúc tải trang) → đề xuất thêm nút "Xoá các mục hỏng" ở trang Hệ thống, hoặc sửa câu thông báo.
