# HM-04 — Đầu vào không tin cậy (tên/địa chỉ KH trong tệp nhập) với innerHTML — BÁO CÁO (P04, 05/11/2026)

Bản kiểm: **v24.17.23** (không đổi app — không có điểm nào có bằng chứng lỗi). Bậc đạt: **V3** (app thật, dữ liệu thử ẩn danh tự sinh).

## 1. Kiểm động — `python3 kiem_thu_p04/test_hm04_xss.py app/QLTDPRO_v24.17.23.html` — **5/5**
Tệp msit80 thử 40 dòng; mỗi trường tên KH (N), địa chỉ (A), cán bộ (C), phòng (T), số HĐTD (H), số GN (G), mục đích (M), ghi chú (K) mang 5 kiểu chuỗi tấn công: `<img src=x onerror=…>`, `<svg onload=…>`, `</td></tr><b data-xss=…>`, phá thuộc tính `" onmouseover="…`, `' onfocus='…' autofocus='`. Nạp qua #/nhap như người dùng.
| Ca | Kết quả |
|---|---|
| X0 phủ | 23 trang; 8 trang hiển thị chuỗi tấn công dưới dạng CHỮ: Tổng quan (72 lần), Cảnh báo sớm (18), Đối soát số liệu (11), Tất cả dư nợ (39), Ngắn hạn + thấu chi (36), Trung–dài hạn (9), Khách hàng 360 (11), Trả nợ xuất TS (18) |
| X4 gd7 | bấm 9 điểm mở khung chi tiết / thẻ cán bộ / hồ sơ (KPI, ô bảng chéo, tên cán bộ, dòng trong khung) |
| Máy tính lãi | tìm "xss", chọn lần lượt 6 khách có tên tấn công, Copy kết quả |
| Rê chuột | 60 ô bảng Tất cả dư nợ (kích hoạt onmouseover nếu bị chèn) |
| X1 | **0 đoạn mã chạy**, 0 hộp thoại |
| X2 | **0 phần tử / thuộc tính on* bị chèn** (quét toàn DOM sau mỗi bước) |
| X3 | 0 pageerror |
Chi tiết: `ket_qua_QLTDPRO_v24.17.23.json`.

## 2. Rà tĩnh từng điểm (`diem_innerhtml_lop_va.json`)
| Nhóm | Số chỗ | Kết luận |
|---|---|---|
| Bundle React — JSX | (mọi nội dung) | An toàn: React tự thoát ký tự |
| Bundle — `dangerouslySetInnerHTML` | 1 thật (13 còn lại là mã nội bộ React) | An toàn: `_S(e)` = `ay.sections[e]` — HTML cố định của trang Giá đất, không lấy từ tệp nhập |
| Bundle — `.innerHTML` khác | ~57 | **Chưa đọc từng chỗ** (phần lớn nằm trong mã thư viện React DOM / SheetJS / docx). Được phủ bằng kiểm động X1–X2 trên 8 trang hiển thị dữ liệu tấn công — không phát hiện chèn |
| Lớp vá — hằng chuỗi / rỗng | 19 | An toàn |
| gd7 (khung chi tiết, thẻ cán bộ, Top 10, bảng chéo, KH 360, lịch) | 9 | An toàn: mọi giá trị dữ liệu qua `esc()`; số qua `fmt()`; tham số trong thuộc tính thay `"`→`&quot;` |
| hsv-v14-pa-enhancer (nhật ký lỗi, chẩn đoán, lịch sử hồ sơ) | 9 | An toàn: dữ liệu qua `escapeHtml()`; còn lại là hằng / số / thời gian |
| gd6 (điền đoạn mẫu) | 2 | An toàn: thoát cả khuôn mẫu bằng `esc()` trước khi chèn thẻ đánh dấu |
| gd14, gd11, gd15, gd9, gd20 | 14 | An toàn: gán chuỗi rỗng / hằng; nội dung dữ liệu dựng bằng textContent / createElement |

## 3. Chưa phủ động (ghi rõ)
- Trang Lãi đọng, Nợ đến hạn, Giải ngân, TSBĐ, Cầm cố với tệp thử này hiển thị 0 dòng (điều kiện lọc ngày/loại) — các bảng này dùng cùng thành phần bảng React (Xn) đã kiểm ở 3 trang dư nợ.
- Khách hàng mới (cần Lập báo cáo từ mốc Lưu trữ), Hồ sơ vay (cần chọn hồ sơ) — chưa thao tác; mã dựng của gd15/gd16 dùng textContent (rà tĩnh).
- Xuất Excel/Word: ngoài phạm vi (không hiển thị trong trình duyệt).
