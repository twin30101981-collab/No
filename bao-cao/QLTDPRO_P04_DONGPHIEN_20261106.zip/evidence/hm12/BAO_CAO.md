# HM-12 — Bấm ô số GN/thu nợ → chi tiết khế ước, lọc Phòng/Cán bộ, xuất Excel (P04, 05/11/2026)

Bản: v24.17.15 (`nguon_P02/build_p04_hm12.py` từ v24.17.14).

## Thay đổi
- Lõi QLTD_DSTN 1.0.1 → **1.1.0**: chỉ CỘNG THÊM `k.moc` = sự kiện theo cặp mốc `{tu, den, loai: gn|thu|dc, so, cach}`. Số liệu và quy tắc gán khế ước tất toán giữ như 1.0.1 (Q5).
- gd15 1.1.0 → **1.2.0**: mọi ô số ≠ 0 ở dòng Tổng/Phòng/Cán bộ bấm được (chuột, chạm, Enter) → bảng chi tiết khế ước (số KƯ, HĐTD, mã KH, KH, CB, phòng, ngày GN, **ngày trả gần nhất = lstrpmtdt** cột 26 dòng Lưu trữ, dư nợ đầu/GN/thu/ĐC/cuối, giá trị ô, cách đo theo cặp mốc, gán CB theo, nguồn mốc); dòng kiểm "Tổng chi tiết = Ô đã bấm · Lệch"; hiện 300 dòng/lần; lọc Phòng → Cán bộ; dòng kiểm tổng 3 cấp; Excel tự dựng (.xlsx, không thư viện, không mạng): 4 sheet Phòng / Cán bộ / Chi tiết khế ước / Ghi chú + Excel riêng cho bảng chi tiết đang mở (cột Kiểm tra = 0).
- Không đổi CSP, 4 CSDL, bundle.

## Kiểm chứng
| Bộ | Bản | Kết quả |
|---|---|---|
| test_hm11_dstn.test.cjs (lõi) | 1.1.0 | 23/23 (thêm U22 Σ sự kiện = số khế ước, U23 cặp mốc đúng) |
| test_hm12_chi_tiet.py (V3, dữ liệu thử 3 mốc) | v24.17.14 | 1/4 — không có ô bấm (đối chứng TRƯỚC SỬA) |
| test_hm12_chi_tiet.py | v24.17.15 | **28/28** — 200 ô bấm, tổng chi tiết = ô 0 đồng; 60 ô cán bộ = công cụ Python độc lập; Excel Phòng/Cán bộ = công cụ 0 đồng; 4.006 khế ước Kiểm tra = 0; điện thoại 390 không tràn; 0 pageerror |
| Hồi quy chung trước (v24.17.14) | | 829 PASS · 0 FAIL |
| Hồi quy chung sau (v24.17.15) | | **859 PASS · 0 FAIL** |

Chưa làm: chạy trên 11 tệp msit80 thật (cần bạn cung cấp lại vào thư mục tạm).
Ghi chú: Lưu trữ không lưu `ofcno` → "Mã CB" trong app = tên cán bộ (như HM-11b).
