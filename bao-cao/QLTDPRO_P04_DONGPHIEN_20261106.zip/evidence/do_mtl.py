# Khảo sát (chỉ đọc) Máy tính lãi v24.17.9: đo bố cục desktop/mobile + chụp ảnh. Chạy: python3 do_mtl.py <thư mục app> <fixture xlsx> <thư mục ảnh>
import asyncio, functools, http.server, threading, sys, json
from pathlib import Path
from playwright.async_api import async_playwright
APP, FIX, OUT = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]); OUT.mkdir(parents=True, exist_ok=True)
PORT = 8899; URL = f'http://127.0.0.1:{PORT}/QLTDPRO_v24.17.9.html'
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
httpd = http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(APP))); threading.Thread(target=httpd.serve_forever, daemon=True).start()
MEASURE = """() => {
 const ov = document.querySelector('[data-testid="gd14-calc-overlay"]'); if (!ov) return null;
 const box = ov.firstElementChild ? ov.firstElementChild.getBoundingClientRect() : ov.getBoundingClientRect();
 const tbl = ov.querySelector('table'); const ths = tbl ? [...tbl.querySelectorAll('thead th')].map(t => t.innerText.trim().replace(/\\s+/g,' ')) : [];
 const sc = tbl ? (()=>{let e=tbl.parentElement; while(e && e!==ov && e.scrollWidth<=e.clientWidth) e=e.parentElement; return e && e!==ov ? [e.scrollWidth, e.clientWidth] : null})() : null;
 const fs = [...ov.querySelectorAll('td,th,input,button,label,span')].map(e=>parseFloat(getComputedStyle(e).fontSize)).filter(x=>x>0);
 const small = [...ov.querySelectorAll('button,input,select')].filter(e=>{const r=e.getBoundingClientRect(); return r.width>0 && (r.height<32 || r.width<32)}).length;
 const inputs = [...ov.querySelectorAll('input')].map(i=>i.type);
 return {vw: innerWidth, vh: innerHeight, modal: [Math.round(box.width), Math.round(box.height)], modalScroll: [ov.scrollHeight, ov.clientHeight],
   cols: ths.length, headers: ths, tableScroll: sc, fontMin: Math.min(...fs), fontMax: Math.max(...fs), smallTargets: small,
   nButtons: ov.querySelectorAll('button').length, nInputs: inputs.length, dateInputs: inputs.filter(t=>t==='date').length,
   text: ov.innerText.slice(0, 1500)};
}"""
async def run(p, tag, vp):
    b = await p.chromium.launch(); ctx = await b.new_context(viewport=vp, locale='vi-VN', device_scale_factor=1)
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(FIX)]); await pg.wait_for_timeout(2500)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(4500)
    await pg.goto(URL + '#/no-den-han', wait_until='domcontentloaded'); await pg.wait_for_timeout(2000)
    await pg.click('[data-testid="gd14-calc"]'); await pg.wait_for_timeout(500)
    await pg.fill('[data-testid="gd14-calc-search"]', 'vu xuan'); await pg.wait_for_timeout(300)
    await pg.locator('[data-testid="gd14-calc-hit"]').first.click(); await pg.wait_for_timeout(800)
    m = await pg.evaluate(MEASURE); m['errs'] = errs
    await pg.screenshot(path=str(OUT / f'{tag}_mtl.png'))
    await b.close(); return m
async def main():
    async with async_playwright() as p:
        r = {'desktop': await run(p, 'desktop', {'width': 1366, 'height': 768}), 'mobile': await run(p, 'mobile', {'width': 390, 'height': 844})}
    print(json.dumps(r, ensure_ascii=False, indent=1))
asyncio.run(main())
