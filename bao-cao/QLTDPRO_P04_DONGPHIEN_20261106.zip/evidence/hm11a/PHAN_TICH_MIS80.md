# HM-11a — Phân tích 11 tệp msit80 thật (31/12/2025 → 31/10/2026) · chỉ số tổng hợp
Dữ liệu thật do người dùng gửi 05/11/2026; chỉ xử lý trong thư mục tạm, KHÔNG đưa vào repo/ZIP.

| # | Phát hiện | Bằng chứng | Hệ quả thiết kế |
|---|---|---|---|
| R-01 | Cột `rpmtamt` = 0 ở mọi dòng của cả 11 tệp | 0/3.847 dòng (31/10) có rpmtamt > 0; 993 dòng có dư nợ < số tiền GN | Không đo được thu nợ từ rpmtamt. Thu nợ = phần giảm dư nợ từng khế ước giữa các mốc liền nhau |
| R-02 | `dsbsseq` duy nhất trong mỗi tệp; 178 khế ước/tháng đổi `apprseq` (HĐTD) nhưng giữ dsbsseq, ngày & số tiền GN | 30/09→31/10: 178 khoản "mới nhưng ngày GN trước kỳ" khớp đúng 178 khoản "mất" | Khóa khế ước = dsbsseq. Khóa cũ brcd\|apprseq\|dsbsseq của app sinh 178 tất toán giả + khoản mới giả |
| R-03 | `custseq` có 1 giá trị cho mọi dòng (mã chi nhánh); mã KH thật = `brcd` (13 số, 1.863 KH) | nunique custseq = 1 | Gán theo khách hàng phải dùng brcd (lỗi này đã bắt và sửa ở lõi 1.0.1, ca U21) |
| R-04 | Tháng 10/2026 có 1.577 khế ước đổi cán bộ (ofcno/ofcnm/Officeruser đổi đồng bộ, 15 cặp chuyển giao); các tháng trước 0–7 | So khớp theo dsbsseq | Quy tắc Q5 (cán bộ cuối kỳ) quyết định số từng cán bộ tháng 10 |
| R-05 | Không khế ước nào đổi phòng 30/09→31/10; 3 phòng: Hội Sở, PGD Hai Bà Trưng, PGD Số 2 | — | — |
| R-06 | Chuỗi 11 mốc tháng cho GN 3.915,6 tỷ (5.935 món); chỉ 2 mốc đầu–cuối: 2.181,3 tỷ (3.405 món) | doi_chieu_mis80_tong_hop.log | Khoản GN rồi tất toán giữa hai mốc không thấy được → HM-11b phải nối MỌI mốc Lưu trữ trong kỳ; mốc hàng ngày càng tốt |
| R-07 | Tháng 10 theo phòng: thu nợ app (GN − Δ dư nợ) lệch lõi mới −0,31 → +0,15 tỷ; GN lệch 0,02–0,14 tỷ (GN thêm trên khế ước cũ) | doi_chieu_mis80_tong_hop.log | Khác biệt lớn nằm ở cấp CÁN BỘ (app không có) và ở danh sách chi tiết (tất toán giả) |

Đối chiếu: lõi JS `nguon_P02/qltd_dstn.cjs` (P02-HM11a 1.0.1) và bản tính Python độc lập trong `kiem_thu_p02/doi_chieu_mis80.py`
khớp **0 đồng** ở 4 cấp (khế ước, cán bộ, phòng, chi nhánh) cho cả 3 phép chạy; bất biến Đầu + GN − Thu + Điều chỉnh = Cuối đúng tới đồng,
tổng dư nợ khế ước = tổng tệp. Điều chỉnh ≠ 0 chỉ ở khoản dư nợ tăng không có GN hoặc khoản xuất hiện lại (1,5 triệu tháng 10; 8,9 tỷ cả chuỗi 11 mốc).
