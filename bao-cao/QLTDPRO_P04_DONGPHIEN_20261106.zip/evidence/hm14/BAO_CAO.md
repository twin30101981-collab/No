# HM-14 — Máy tính lãi: chính xác số liệu — BÁO CÁO (P04, 05/11/2026)

Bản: **v24.17.16 → v24.17.17** (`app/QLTDPRO_P43/nguon_P04/build_p04_hm14.py`). Bậc đạt: **V3 (dữ liệu thử ẩn danh)**.

## 1. Thay đổi
| Phần | Nội dung |
|---|---|
| Lõi | `nguon_P41/qltd_lai.cjs` **giữ từng byte** (sha256 55908dc6…a1db85a1a0; bản dựng kiểm). Mô-đun mới `nguon_P04/qltd_lai_hm14.cjs` (QLTDLai.hm14 1.0.0) — mọi số lãi vẫn do `tinhLaiKhoan` tính, không nhân bản công thức. |
| Q12 | Phân loại kỳ hạn từ loại vay r[13] (TK 211/212/213, thấu chi); trống → theo thời hạn GN→đến hạn. **Ngắn hạn/thấu chi**: không lãi chậm trả, quá hạn chỉ sau ngày đến hạn gốc r[7] (như cũ). **Trung/dài hạn**: kỳ trả lãi = `nxtrpmtschddt` (r[25]) nếu sau ngày đã thu lãi đến, hoặc kỳ người dùng chọn (1/3/6 tháng); đã qua kỳ mà chưa thu lãi → LS × 1,5 từ ngày kỳ (dời ngày xác định quá hạn sớm lên, chỉ khi trước r[7]). Có lựa chọn "Không áp Q12". |
| Lãi theo đoạn | Dư nợ khế ước (dsbsseq) ở mọi mốc Lưu trữ + dòng hiện tại → các đoạn dư nợ; ngày đổi = `lstrpmtdt` nếu nằm giữa hai mốc, không có thì ngày mốc (ghi cảnh báo "ước tính"). Mỗi đoạn gọi lõi, tròn từng phần, cộng. Không có thay đổi dư nợ → kết quả **y hệt** cách cũ. |
| Chênh IPCAS | Cột mới "CHÊNH IPCAS" = lãi app đến **ngày dữ liệu** (mốc Lưu trữ mới nhất) − `intamt` (r[10]). Khớp = xanh; lệch = cam + lý do (làm tròn ≤ 2 đ / lệch N ngày lãi / có trả gốc giữa kỳ / có quá hạn / chưa rõ). intamt = 0 → "—" (không đối chiếu). |
| Cảnh báo ngày chốt | Chốt trước ngày dữ liệu; chốt cách ngày dữ liệu > 31 ngày; áp cho cả ngày thu riêng. Không có Lưu trữ → ghi "chưa xác định ngày dữ liệu". |
| Đồng bộ | Cột lãi dự thu trang Lãi đọng và công cụ "Tính lãi tất toán" dùng cùng quy tắc Q12 (`tinhLaiQ12`); tất toán: ngắn hạn không hiện lãi chậm trả. |
| Copy kết quả | Thêm dòng Q12 / từng đoạn dư nợ / chênh IPCAS (chỉ khi có). |

## 2. Kiểm chứng
| Bộ | Kết quả |
|---|---|
| `python3 kiem_thu_p04/test_hm14_loi.py` — Python độc lập (Fraction, tròn nửa-lên) vs Node | **224/224** (200 khoản ngẫu nhiên: `tinhLaiTheoDoan` = `tinhLaiQ12` = `tinhLaiKhoan` từng trường; 24 ca Q12/đoạn/lịch sử dư nợ/IPCAS/ngày chốt, 0 đồng) |
| Lõi cũ `kiem_thu_p41/test_lai_unit.test.cjs`, `kiem_thu_p42_mtl/test_lai_mtl.test.cjs` | **18/18**, **11/11** |
| `python3 kiem_thu_p04/test_hm14_mtl.py app/QLTDPRO_v24.17.17.html` — Playwright 1366×768 + 390×844 | **43/43**, 0 pageerror |
| Cùng bộ trên v24.17.16 (trước sửa) | 7 FAIL rồi dừng (A3, B2, B3, B4, B5, B6, B8 — không có Q12, đoạn, cột IPCAS) |
| Hồi quy chung trước (v24.17.16) | **882 PASS · 0 FAIL** (LOI_MT p41/p42_gd14 — Chromium sập khi tải lại, như cũ) |
| Hồi quy chung sau (v24.17.17, thêm p04_hm14_loi + p04_hm14) | 1146 PASS · 3 FAIL (A10 "lãi chậm trả" ở p41_gd14/p42_gd14/p42_mtl_gd14 — khoản ngắn hạn, Q12 bỏ lãi chậm trả) → sửa kỳ vọng A10 → 3 bộ 75/0 ⇒ 1149 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ) |
Nhật ký: `evidence/hm14/log/`; ảnh: `evidence/hm14/anh/{desktop,mobile}_01_bang.png`.

## 3. Giới hạn / câu hỏi mới
- **Chưa đạt tiêu chí "≥ 20 khoản có chứng từ thật khớp 0 đồng"**: phiên này không có chứng từ IPCAS thật. Cần người dùng: mở Máy tính lãi với dữ liệu thật đã lưu Lưu trữ, xem cột CHÊNH IPCAS, gửi 20 khoản kèm chứng từ (ẩn danh) để đối chiếu.
- **Q15 (mở)**: (a) Q12 "lãi quá hạn 150%" tính trên **toàn bộ dư nợ gốc** từ ngày kỳ trả lãi (đang làm, cùng cơ chế quá hạn hiện có) hay chỉ trên **số lãi chưa trả**? (b) kỳ trả lãi lấy `nxtrpmtschddt` (ngày trả nợ kế tiếp của lịch IPCAS) có đúng là kỳ trả lãi không, kỳ mặc định khi trống là mấy tháng?
- **Q7 (vẫn mở)**: `intamt` là lãi dự thu tính đến hết ngày dữ liệu hay đến trước ngày dữ liệu — lý do "lệch 1 ngày" sẽ lộ ra khi có dữ liệu thật.
- Ca "đoạn dư nợ" trong bộ V3 dùng `__gd11Api` giả 3 mốc (Lưu trữ thật cần nhập tệp xlsx); đường thật không có Lưu trữ đã kiểm (A1–A3).
- Bố cục hộp (thanh tổng dính, thẻ điện thoại) để HM-13/HM-19.

## 5. HM-14b — v24.17.18 (05/11, áp trả lời Q15, Q7) — `nguon_P04/build_p04_hm14b.py`, QLTDLai.hm14 1.1.0
- **Q15a** (toàn bộ dư nợ gốc): đúng cách đã làm — không đổi số.
- **Q15b** (kỳ = nxtrpmtschddt, mỗi khách riêng, không mặc định): ô "Kỳ trả lãi" luôn về "Theo lịch IPCAS — không mặc định" khi mở hộp/chọn khách khác (kỳ chọn tay chỉ áp cho khách đang xem); khoản trung/dài hạn không có lịch sau ngày đã thu lãi đến → cảnh báo "CHƯA xét quá hạn lãi".
- **Q7** (chưa chốt; có thể dự thu tính đến ngày đến hạn): cột CHÊNH IPCAS vẫn so với ngày dữ liệu, nhưng thử thêm lãi đến **ngày đến hạn kỳ** (r[25]) và **ngày đến hạn gốc** (r[7]); khớp 0 đồng ở mốc nào → ô xanh dương "khớp nếu đến dd/mm" + lý do. Dữ liệu thật sẽ cho biết quy ước của IPCAS.
- Kiểm: lõi 229/229 (thêm G1–G5); V3 49/49 (thêm B7b, B7c, D0), 0 pageerror; lõi qltd_lai.cjs giữ byte. Hồi quy chung: 1159 PASS · 1 FAIL (p52_ma_kh R2 chập chờn đã biết — mã băm hex ngẫu nhiên trong title #/nhap-du-lieu; chạy lại 2 lần 14/0) ⇒ 0 FAIL do HM-14b; LOI_MT p41/p42_gd14 như cũ.
