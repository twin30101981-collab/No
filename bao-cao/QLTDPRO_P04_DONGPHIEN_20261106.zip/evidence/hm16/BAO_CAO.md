# HM-16 — Mốc Lưu trữ bỏ khế ước dư nợ 0 → bảng Phòng → Cán bộ thiếu GN trả hết trong kỳ (P03, 05/11/2026)
**Bản:** QLTDPRO_v24.17.14.html (sha256 7ad74461…b3001a6b), `nguon_P02/build_p03_hm16.py` từ v24.17.13; gd15 1.1.0.
**Gốc rễ:** Nhập dữ liệu gọi `k4` loại dòng dư nợ 0 ("zero"/"thauchiZ") rồi `Zf` lưu `rpt_<timestamp>` chỉ với dòng còn lại. Tệp msit80 thật vẫn liệt kê khoản GN đã trả hết (13–15 dòng/tệp).
**Sửa (3 điểm vá + gd15):** giữ dòng bị `k4` loại → `Zf` lưu khóa phụ `rpt0_<timestamp>` (cùng kho reportData; mốc chính, KPI, báo cáo cũ không đổi) → `__gd11Api.loadZeroRows` → gd15 gộp khi tính; mốc nhập trước v24.17.14 (không có khóa phụ) → cảnh báo "nhập lại".
**Chống tái diễn:** `tao_mis80_thu.py` sinh thêm dòng dư nợ 0 (M1: 8, M2: 10) → bộ `p03_hm11b` bắt lỗi này.
## Kiểm chứng (V3 Chromium 153)
| Lệnh | Bản | Kết quả |
|---|---|---|
| `test_hm11b_dstn.py` dữ liệu thử có dư nợ 0 | v24.17.13 | 23/25 — tái hiện: thiếu 14 món GN (A3), 10 món (B1) |
| cùng | v24.17.14 | **25/25** |
| cùng, 11 tệp msit80 thật (thư mục tạm) | v24.17.14 | **25/25** — chuỗi 11 mốc và 2 mốc khớp công cụ doi_chieu_mis80 0 đồng mọi phòng/cán bộ |
| hồi quy chung | v24.17.14 | PASS 829 · FAIL 0 · LỆCH PB 12 · SKIP 2 |
**Chưa kiểm bằng trình duyệt:** câu cảnh báo cho mốc cũ thiếu khóa phụ (chỉ rà mã); khóa phụ mồ côi khi xoá/hoàn tác mốc (vô hại, không dọn).
