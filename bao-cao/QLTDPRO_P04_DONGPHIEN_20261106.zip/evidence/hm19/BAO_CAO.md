# HM-19 + HM-13 — Máy tính lãi & Lãi đọng: một lối vào, giao diện gọn — BÁO CÁO (P04, 05/11/2026)

Bản: **v24.17.18 → v24.17.19** (`app/QLTDPRO_P43/nguon_P04/build_p04_hm19.py`, đoạn mã `nguon_P04/gd14_hm19.js`). Bậc đạt: **V3 (dữ liệu thử ẩn danh nạp qua #/nhap)**.
Chỉ đổi trình bày: mọi số lấy nguyên từ QLTDLai.hm14 (v24.17.18); lõi `qltd_lai.cjs` giữ byte.

## 1. Thay đổi
| Điểm nghẽn | Làm |
|---|---|
| L-01 hai nút | Bỏ nút "Tính lãi tất toán" ở trang Lãi đọng → một lối vào "Máy tính lãi" (2 chế độ: Tra cứu KH / Tính tay). Hàm cũ `GD14.openAllot` giữ làm API (bộ kiểm cũ), rows lưu ở `GD14.ldRows`. |
| L-02 kết quả bị đẩy xuống | Chọn khách → danh sách tìm thu gọn (có sẵn); khung công thức thu nhỏ; **thanh tổng (số khoản, trả gốc, TỔNG LÃI, tổng thu) đặt trên bảng và dính đầu khung cuộn**. |
| L-03 trùng tên | Mỗi khách trong danh sách tìm ghi tối đa 3 khế ước còn dư nợ kèm ngày đến hạn; mỗi dòng bảng ghi đến hạn + LS + loại vay + Q12/đoạn. |
| L-04 kết quả dạng văn | Mục "📊 Bảng phân rã lãi từng khoản": Phần (trong hạn / quá hạn LS×1,5 / chậm trả) × Từ ngày, Đến ngày, Số ngày, Dư nợ, Lãi suất, Tiền; dd/mm/yyyy; theo từng đoạn dư nợ; nút Copy kết quả giữ nguyên. |
| L-05 | Đã xử lý ở HM-14/14b (Q12, Q15). |
| L-06 ba tổng | Ghi chú dưới tổng ở trang Lãi đọng: Σ lãi = "Tổng lãi đọng" = lãi đọng IPCAS (intamt) của khoản đang hiện (thẻ theo phạm vi); Σ lãi dự thu = app tính đến ngày chốt; nêu chênh. |
| HM-13 bảng | Chế độ **Gọn 9 cột** mặc định (tick, Khế ước, Đã thu lãi đến, Trả gốc, Dư nợ, Ngày thu lãi, Lãi TH/QH, Tổng, Chênh IPCAS) — không cuộn ngang ở 1366; nút "⇔ Xem đầy đủ cột" (16 cột, kèm tên trường IPCAS). Tên trường kỹ thuật ẩn ở chế độ Gọn (còn trong chú thích rê chuột). |
| HM-13 điện thoại | ≤ 600 px: mỗi khoản là một thẻ (nhãn – giá trị), nút/ô ≥ 40 px (gồm bộ chọn ngày gd7). |

## 2. Kiểm chứng
| Bộ | Kết quả |
|---|---|
| `python3 kiem_thu_p04/test_hm19_mtl.py app/QLTDPRO_v24.17.19.html` (1366×768 + 390×844, nạp tệp msit80 thử qua #/nhap) | **36/36**, 0 pageerror. Σ lãi = Σ intamt (Python); Σ lãi dự thu = Σ lãi tính độc lập; tổng lãi + phân rã từng khoản khớp độc lập 0 đồng; ≤ 9 cột, không cuộn ngang; TỔNG LÃI thấy ngay ở cả 2 khung; thẻ điện thoại; 0 nút < 40 px |
| `test_hm14_mtl.py` trên v24.17.19 | **49/49** (số không đổi) |
| Bộ kiểm cũ bấm nút tất toán (p41_gd14, p42_gd14, p42_mtl_gd14, p42_mtl_ui, p43_mtl_ui) | sửa: chấp nhận không còn nút; mở công cụ cũ qua `GD14.openAllot(GD14.ldRows)` để vẫn kiểm phần tính |
| Hồi quy chung v24.17.19 | 1194 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ). Trong lúc làm: lượt 1 có 5 bộ cũ LOI do tôi chèn chú thích sai cú pháp khi sửa → gỡ; p42/p43_mtl_ui dừng ở M8 (thiết kế cũ cuộn ngang) → kiểm M8 ở chế độ Đầy đủ cột, điện thoại SKIP có lý do; lộ lỗi thật "Chọn tất cả" bị ẩn trên điện thoại → đã sửa; cột ẩn đổi sang thu 0 px để nội dung ô không đổi |
Ảnh: `evidence/hm19/anh/` (Lãi đọng + Máy tính lãi × desktop/mobile).

## 3. Chưa làm / ghi chú
- L-07 (bảng trang Lãi đọng ≥ 13 cột, hàng lọc từng cột, 96 ô < 28 px) là bảng của bundle React — chưa sửa (cần thẻ riêng nếu muốn).
- Ảnh trước–sau: ảnh "trước" là khảo sát `evidence/khao_sat_p04/lai_*.jpg`.
