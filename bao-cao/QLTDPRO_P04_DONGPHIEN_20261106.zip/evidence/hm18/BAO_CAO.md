# HM-18 — Khách hàng mới toàn trang: một nguồn số liệu, KPI bấm được, cỡ chữ/nút (P04, 05/11/2026)

Bản: v24.17.16 (`nguon_P02/build_p04_hm18.py` từ v24.17.15).

## Nguyên nhân gốc
Thẻ KPI, bảng Tổng hợp, biểu đồ "Giải ngân theo phòng" do bundle React tính riêng:
- Doanh số cho vay = Σ dsbsamt của khế ước có ngày GN trong kỳ trong TỆP CUỐI KỲ → thiếu GN thêm trên khế ước cũ (Q11) và món GN rồi tất toán giữa kỳ (chỉ thấy ở mốc giữa).
- Thu nợ = GN − (dư nợ cuối − dư nợ đầu) → suy ra, kéo theo sai số của GN.
Bảng Đối soát (HM-11b/HM-12) đo theo từng khế ước trên MỌI mốc Lưu trữ → hai số khác nhau trên cùng trang (dữ liệu thử: GN 50,658 vs 63,325 tỷ; thu 528,309 vs 544,705 tỷ).

## Sửa
- gd15 1.3.0: `layR()` — tính lõi QLTD_DSTN ngay khi có mốc đầu/cuối (không đợi mở tab Đối soát), nhớ theo khóa; bảng Đối soát và gd16 dùng chung một kết quả.
- gd16 1.0.0 (mới): KPI Doanh số cho vay / Thu nợ / Dư nợ đầu / Dư nợ cuối = lõi; dòng phụ ghi cách tính ("N khế ước: X món mới + Y lần GN thêm", "giảm dư nợ gốc từng khế ước · n mốc", "món còn dư nợ"); bấm/Enter → tab Đối soát mở chi tiết khế ước; số cách cũ giữ trong tooltip. Bảng Tổng hợp: cột Giải ngân (Món = số khế ước có GN, Tiền) theo lõi ở mọi dòng phòng/cán bộ/tổng, đúng đơn vị đồng/triệu/tỷ, cảnh báo nếu cán bộ có GN mà bảng không có dòng. Biểu đồ phòng: độ dài + số theo lõi. Tab Chi tiết: ghi chú nguồn danh sách + nút sang Đối soát. Tệp chọn tay (không mốc): giữ số bundle, ghi "suy ra".
- CSS: chữ ≥ 11px (nhãn "đã tất toán" 9px), nút ≥ 28px desktop / ≥ 40px điện thoại (tab, lọc, phân trang, Nạp từ Lưu trữ).
- Không sửa bundle, CSP, 4 CSDL. Ngoài phạm vi (còn lại): sổ "Tải Excel 7 trang" của bundle vẫn theo cách cũ — Excel khớp số là "Xuất Excel đối soát (4 sheet)" ở tab Đối soát (HM-12).

## Kiểm chứng (V3, dữ liệu thử 3 mốc ẩn danh)
| Bộ | Bản | Kết quả |
|---|---|---|
| test_hm18_khm_toan_trang.py | v24.17.15 | FAIL A1, A2, A4 (KPI lệch công cụ) — đối chứng TRƯỚC SỬA |
| test_hm18_khm_toan_trang.py | v24.17.16 | **23/23** — KPI = công cụ Python độc lập = dòng Tổng Đối soát (0 đồng); Tổng hợp 25 dòng = công cụ; đơn vị triệu/tỷ; biểu đồ; KPI bấm → chi tiết; 5 tab × 1366/390: không tràn, 0 chữ < 11px, 0 nút < 28/40px, 0 pageerror; tệp chọn tay ghi "suy ra" |
| Hồi quy chung trước (v24.17.15) | | 859 PASS · 0 FAIL |
| Hồi quy chung sau (v24.17.16) | | 881 PASS · 1 FAIL — p03_hm17 T3 giữ kỳ vọng cũ "món KPI = 110 món của tệp cuối kỳ"; đã cập nhật theo Q11 (món mới = số khế ước GN mới duy nhất của lõi, vẫn kiểm không lặp do đổi HĐTD) |
| Chạy lại p03_hm17 + p04_hm12 + p04_hm18 | v24.17.16 | **56 PASS · 0 FAIL** (hoi_quy_chay_lai_3bo.md) |

Ảnh toàn trang (cuộn khung chính, từng đoạn) 5 tab × 2 khung nhìn: `anh/`.
Chưa làm: chạy trên tệp msit80 thật (cần bạn gửi lại, chỉ thư mục tạm).
