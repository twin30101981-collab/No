# HM-05 — Kiểm kê catch rỗng ở luồng nhập/lưu/xuất, hiển thị lỗi — BÁO CÁO (P04, 05/11/2026)

Bản: **v24.17.23 → v24.17.24** (`app/QLTDPRO_P43/nguon_P04/build_p04_hm05.py`). Bậc đạt: **V3** cho H1, H2; **V1 (tĩnh)** cho H3.

## 1. Kiểm kê (`phan_loai_catch_lop_va.json`)
- Lớp vá (gd3–gd21, hsv-v14, …): **84** khối `catch` rỗng / `.catch(()=>{})` (thẻ ghi 42 — số cũ).
  - **79 chấp nhận được**: đọc/ghi localStorage + JSON dự phòng (27), dò tính năng trình duyệt (6), focus/cuộn (6), theo dõi DOM (5), bản sao gd9 (4), cài đặt thư mục (3), dọn dẹp (2), chính hàm thông báo (2), trình bày/chẩn đoán/sự kiện giao diện (≈24 — đọc từng chỗ, ghi lý do trong tệp JSON). gd15:269 chấp nhận vì lỗi vẫn trả về nơi gọi.
  - **5 có hại** (gom thành 3 nhóm, đều đã sửa — mục 2).
- Bundle: 90 `catch{}`; 8 chỗ gần luồng vào/ra đã đọc: thư viện SheetJS (2), nâng cấp IDB TSBĐ (1), ảnh chụp xlsx khi xuất hồ sơ — lỗi thì vẫn xuất JSON (1, chấp nhận), khung Phương án SXKD (4, có hại → H3). 82 chỗ còn lại **chưa đọc từng chỗ** (không nằm cạnh từ khoá lưu/xuất/nhập).
- Ngoài dạng catch rỗng, phát hiện thêm 2 chỗ nuốt lỗi bằng `.catch(()=>null)` ở luồng nghiệp vụ (gd11 nơi gọi loadMidSnaps; gd14 hm14LoadArc — mã HM-14 của chính phiên này) → đã sửa.

## 2. Sửa (thông báo ngắn qua `window.gd9Toast` có sẵn; không đổi số liệu, luồng, schema)
| Nhóm | Trước | Sau |
|---|---|---|
| H1 gd11 `loadMidSnaps` (mốc giữa kỳ cho Khách hàng mới) | mốc đọc lỗi bị bỏ qua âm thầm → GN giữa kỳ có thể thiếu | "⚠️ Không đọc được mốc Lưu trữ dd/mm/yyyy — báo cáo có thể thiếu khoản giải ngân giữa kỳ (…)"; trả thêm `loi:[ngày]`; nơi gọi lỗi toàn bộ → "chỉ dùng mốc đầu và cuối". Xuất `__gd11Api.loadMidSnaps` (chỉ đọc). |
| H2 gd14 Máy tính lãi đọc Lưu trữ | lỗi → im lặng tính 1 đoạn | "⚠️ Không đọc được N mốc Lưu trữ (…) — lãi theo đoạn dư nợ có thể thiếu đoạn" / "Không đọc được Lưu trữ… đang tính 1 đoạn" (1 lần mỗi lần mở hộp) |
| H3 khung Phương án SXKD (nạp / tự lưu / bấm lưu / nạp tệp) | `catch{}` rỗng → mất thay đổi không hay biết | "⚠️ Không tự lưu được phương án SXKD — thay đổi chưa được lưu" (≤ 1 lần/15 giây), "Không lưu được…", "Không nạp được…" |

## 3. Kiểm chứng (`python3 kiem_thu_p04/test_hm05_bao_loi.py app/QLTDPRO_v24.17.24.html` — **5 PASS · 0 FAIL · 1 SKIP**)
| Ca | Kết quả |
|---|---|
| H1a/H1b | loadMidSnaps đọc đủ 3 mốc giữa kỳ (110 khế ước), không báo lỗi khi bình thường |
| H1c | giả lập IndexedDB lỗi đúng bản ghi mốc 15/10/2026 → `loi:["2026-10-15"]` + thông báo đúng ngày |
| H2 | giả lập Lưu trữ lỗi → thông báo + Máy tính lãi vẫn ra tổng lãi |
| H3 | **SKIP** — khung PA chỉ dựng bên trong một hồ sơ vay cụ thể, không mở tới được với dữ liệu thử; vá kiểm tĩnh (4 điểm thay đúng 1 lần, trang tải 0 pageerror) |
| E1 | 0 pageerror |
| Cùng bộ trên v24.17.23 | H1a, H2 FAIL (không có thông báo) |
| Hồi quy chung v24.17.24 | 1286 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ; SKIP 5 gồm H3) |

## 4. Ghi chú
- Thông báo lỗi mới có thể làm lộ lỗi nền cũ (rủi ro của thẻ). Bộ hồi quy chung KHÔNG kiểm nội dung thông báo; trong bộ HM-05, ca bình thường H1b không sinh thông báo lỗi. Nếu người dùng thấy thông báo mới khi dùng dữ liệu thật → ghi thành thẻ riêng.
