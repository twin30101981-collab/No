# L-07 — Bảng trang Lãi đọng + sửa dòng giá đất 212 — BÁO CÁO (P04, 05/11/2026)

Bản: **v24.17.19 → v24.17.20** (`app/QLTDPRO_P43/nguon_P04/build_p04_l07.py`). Bậc đạt: **V3 (dữ liệu thử ẩn danh nạp qua #/nhap)**.

## 1. Thay đổi (chỉ trang #/lai-dong; bảng các trang khác không đổi)
| Điểm nghẽn L-07 | Làm |
|---|---|
| ≥ 13 cột, Mã KH bị cắt ở 1366 | Mặc định 8 cột: Tên KH · Cán bộ · Đã thu lãi đến · Số ngày chậm lãi · Tiền lãi (IPCAS) · Lãi dự thu đến chốt · Dư nợ · Đã thu. Kỳ lãi kế tiếp, Trạng thái, Mã KH, HĐTD, Loại vay vẫn bật được ở "Cột ▾". Bố cục đã lưu trước đây được chuyển sang mặc định mới MỘT lần (cờ `l07`); sau đó người dùng chỉnh tự do. |
| 86–90 ô lọc từng cột | Hàng lọc ẩn, gom vào nút "🔍 Lọc theo cột (n)"; đang có bộ lọc thì hàng lọc luôn hiện (không giấu bộ lọc đang chạy). |
| 96 nút/ô < 28 px | Nút/ô ngoài dòng dữ liệu ≥ 28 px (điện thoại ≥ 40 px). |
| Cả dòng chữ đỏ | Bỏ tô chữ đỏ cả dòng của gd7 trên trang này (nền cảnh báo giữ); vạch màu đầu dòng theo số ngày chậm lãi (so ngày dữ liệu): 1–30 vàng, 31–90 cam, > 90 đỏ + tên đậm; cột "Số ngày chậm lãi" giữ màu cũ. |

**Giá đất:** Phường Nam Định STT 212 Đường Vũ Xuân Thiều: TB VT1 28.000 → **55.000**, TB VT2 16.800 → **33.000** (= (cao + thấp)/2; lỗi gõ ở PL02 báo cáo tư vấn 275/2026). Sau sửa, toàn bộ 985 dòng app thỏa TB = (cao + thấp)/2. Hoàn tác: đổi lại 2 số trong build_p04_l07.py.

## 2. Kiểm chứng
| Bộ | Kết quả |
|---|---|
| `python3 kiem_thu_p04/test_l07_lai_dong.py app/QLTDPRO_v24.17.20.html` (1366×768 + 390×844) | **32/32**, 0 pageerror: 8 cột, không cuộn ngang ở 1366 (trước 1.683/1.132 px), lọc ẩn/hiện + lọc chạy đúng, phân cấp 4/4 dòng khớp Python, dòng gốc quá hạn không chữ đỏ, Σ lãi = Σ intamt, 0 nút/ô < 28/40 px, chuyển bố cục cũ đã lưu, giá đất G1–G2 |
| Cùng bộ trên v24.17.19 (trước) | 6 FAIL rồi dừng (G1, G2, T1–T4) |
| Hồi quy chung v24.17.20 | 1226 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ) |
Ảnh: `evidence/l07/anh/`.
