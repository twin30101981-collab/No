# -*- coding: utf-8 -*-
# HM-03 · V3 — kiểm kê + kiểm chứng lớp lưu trữ cục bộ (localStorage, sessionStorage, IndexedDB) và sao lưu/khôi phục toàn bộ.
# Dữ liệu thử ẩn danh (tệp msit80 thử có sẵn trong gói). Ghi kiểm kê ra evidence/hm03/kiem_ke_<bản>.json.
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p04/test_hm03_luu_tru.py [app/QLTDPRO_v24.17.23.html]
import asyncio, functools, http.server, threading, sys, json, tempfile, os, re
from pathlib import Path
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.23.html'
PORT = 8849; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm03'
if not EV.parent.exists(): EV = HERE / 'hm03'
EV.mkdir(parents=True, exist_ok=True)
FIX = [ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx', ROOT / 'app/kiem_thu_p40/xlsx/msit80_31-10-2026.xlsx']
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:500]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()

INV = r"""async () => {
  const h = s => { let x = 5381; for (let i = 0; i < s.length; i++) x = ((x << 5) + x + s.charCodeAt(i)) | 0; return (x >>> 0).toString(16); };
  const ser = v => { try { return JSON.stringify(v, (k, x) => (x instanceof Blob) ? ('blob:' + x.size + ':' + x.type) : (x instanceof ArrayBuffer) ? ('ab:' + x.byteLength) : (ArrayBuffer.isView(x) ? ('u8:' + x.byteLength) : x)); } catch (e) { return 'ERR'; } };
  const out = { ls: {}, ss: {}, idb: {} };
  for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i), v = localStorage.getItem(k) || '';
    let j = 'text'; try { const p = JSON.parse(v); j = Array.isArray(p) ? 'array' : (p && typeof p === 'object') ? 'object' : typeof p; } catch (e) {}
    out.ls[k] = { len: v.length, kind: j, h: h(v) }; }
  for (let i = 0; i < sessionStorage.length; i++) { const k = sessionStorage.key(i), v = sessionStorage.getItem(k) || ''; out.ss[k] = { len: v.length, h: h(v) }; }
  const dbs = indexedDB.databases ? await indexedDB.databases() : [];
  for (const d of dbs) {
    const db = await new Promise((ok, no) => { const r = indexedDB.open(d.name); r.onsuccess = () => ok(r.result); r.onerror = () => no(r.error); });
    const st = {};
    for (const s of Array.from(db.objectStoreNames)) {
      const tx = db.transaction(s, 'readonly'), os = tx.objectStore(s);
      const all = await new Promise(ok => { const r = os.getAll(); r.onsuccess = () => ok(r.result); r.onerror = () => ok([]); });
      const keys = await new Promise(ok => { const r = os.getAllKeys(); r.onsuccess = () => ok(r.result); r.onerror = () => ok([]); });
      const txt = ser(keys) + '|' + ser(all);
      st[s] = { n: all.length, bytes: txt.length, h: h(txt), keyPath: os.keyPath, sampleKeys: keys.slice(0, 3).map(String) };
    }
    out.idb[d.name] = { version: db.version, stores: st }; db.close();
  }
  return out; }"""

async def nap(pg):
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in FIX]); await pg.wait_for_timeout(3000)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(7000)

async def routes(pg):
    r = await pg.evaluate("[...new Set([...document.querySelectorAll('a[href^=\"#/\"]')].map(a=>a.getAttribute('href')))]")
    return [x for x in r if x and len(x) > 2]

async def di_qua(pg, rs, errs, tag):
    trang = {}
    for r in rs:
        n0 = len(errs)
        await pg.goto(URL + r, wait_until='domcontentloaded'); await pg.wait_for_timeout(900)
        txt = await pg.evaluate("(document.querySelector('main')||document.body).innerText")
        trang[r] = dict(chu=len(txt), loi=errs[n0:], hong=bool(re.search(r'Something went wrong|Đã xảy ra lỗi|Application error', txt)))
    return trang

async def so_dong(pg):
    await pg.goto(URL + '#/tat-ca-du-no', wait_until='domcontentloaded'); await pg.wait_for_timeout(1800)
    return await pg.locator('[data-testid=dt-row]').count(), await pg.evaluate("(document.querySelector('[data-testid=tong]')||{}).textContent||''")

def mo_ta(k):
    D = [(r'^qltd2_tbl_', 'Bố cục bảng (cột, mật độ, bộ lọc) — gd7/bundle'), (r'^qltd2_', 'Cài đặt bundle React (tiền tố qltd2_)'), (r'^hsv', 'Hồ sơ vay (HSV)'), (r'^pa_', 'Phương án SXKD'),
         (r'^gd14_', 'Máy tính lãi (ngày chốt)'), (r'^gd20_', 'Chỉ tiêu KH — lựa chọn nhóm (gd20)'), (r'^ctkh_', 'Kế hoạch năm (Chỉ tiêu kế hoạch)'), (r'^gd9', 'Mẫu Word (gd9)'),
         (r'ARC|arc|TWIN', 'Danh mục mốc Lưu trữ'), (r'^td', 'Cài đặt chung (td.*)'), (r'^_', 'Trạng thái tạm (ngày tệp, mốc trước)'), (r'khm', 'Khách hàng mới'), (r'roster|cbtd', 'Danh mục cán bộ')]
    for p, t in D:
        if re.search(p, k): return t
    return 'chưa phân loại'

async def run(pw):
    br = await pw.chromium.launch(); tmp = Path(tempfile.mkdtemp())
    ctx = await br.new_context(viewport={'width': 1366, 'height': 768}, accept_downloads=True)
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    await nap(pg)
    rs = await routes(pg)
    ok('A0 tìm được các trang từ thanh điều hướng', len(rs) >= 15, rs)
    t0 = await di_qua(pg, rs, errs, 'goc')
    ok('A1 đi qua mọi trang với dữ liệu thử: 0 pageerror, không trang lỗi', not errs and not any(v['hong'] for v in t0.values()), (errs[:5], [k for k, v in t0.items() if v['hong']]))
    inv = await pg.evaluate(INV)
    nd0 = await so_dong(pg)
    json.dump(inv, open(EV / f'kiem_ke_{Path(APP).stem}.json', 'w'), ensure_ascii=False, indent=1)
    ok('A2 kiểm kê: có localStorage + IndexedDB (QLTDProDB, TWIN_Archive_v1)', len(inv['ls']) > 5 and 'QLTDProDB' in inv['idb'] and 'TWIN_Archive_v1' in inv['idb'], list(inv['idb']))
    # bảng kiểm kê Markdown
    L = ['| Khóa localStorage | Dài | Kiểu | Nhóm |', '|---|---|---|---|'] + [f'| `{k}` | {v["len"]} | {v["kind"]} | {mo_ta(k)} |' for k, v in sorted(inv['ls'].items())]
    L += ['', '| CSDL IndexedDB | Phiên bản | Kho (số bản ghi, ~byte) |', '|---|---|---|'] + [f'| `{d}` | {x["version"]} | ' + '; '.join(f'{s} ({y["n"]}, {y["bytes"]})' for s, y in x['stores'].items()) + ' |' for d, x in sorted(inv['idb'].items())]
    L += ['', '| sessionStorage | Dài |', '|---|---|'] + [f'| `{k}` | {v["len"]} |' for k, v in sorted(inv['ss'].items())]
    open(EV / f'kiem_ke_{Path(APP).stem}.md', 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    # B. sao lưu toàn bộ → khôi phục ở trình duyệt sạch
    await pg.goto(URL + '#/luu-tru', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    tabd = pg.locator('[data-testid^=ar-tab-]', has_text=re.compile('Dữ liệu|dữ liệu'))
    if await tabd.count(): await tabd.first.click(); await pg.wait_for_timeout(500)
    async with pg.expect_download(timeout=60000) as dl: await pg.click('[data-testid=ar-full-dl]')
    d = await dl.value; bk = tmp / 'sao_luu.json'; await d.save_as(bk)
    ok('B1 tải được bản sao lưu toàn bộ', bk.stat().st_size > 1000, bk.stat().st_size)
    ctx2 = await br.new_context(viewport={'width': 1366, 'height': 768}, accept_downloads=True)
    p2 = await ctx2.new_page(); e2 = []; p2.on('pageerror', lambda e: e2.append(str(e)[:200]))
    await p2.goto(URL + '#/luu-tru', wait_until='domcontentloaded'); await p2.wait_for_timeout(1500)
    t2 = p2.locator('[data-testid^=ar-tab-]', has_text=re.compile('Dữ liệu|dữ liệu'))
    if await t2.count(): await t2.first.click(); await p2.wait_for_timeout(500)
    p2.on('dialog', lambda dg: asyncio.ensure_future(dg.accept()))
    try:
        async with p2.expect_download(timeout=15000): await p2.set_input_files('[data-testid=ar-full-file]', str(bk))
    except Exception: pass
    await p2.wait_for_timeout(6000)
    inv2 = await p2.evaluate(INV)
    miss_ls = [k for k in inv['ls'] if k not in inv2['ls'] and k != 'gd9_tplok']
    diff_ls = [k for k in inv['ls'] if k in inv2['ls'] and inv['ls'][k]['h'] != inv2['ls'][k]['h']]
    miss_db = [f'{dn}/{s}' for dn, x in inv['idb'].items() for s, y in x['stores'].items() if dn != 'QLTDProGD9' and y['n'] and not (dn in inv2['idb'] and s in inv2['idb'][dn]['stores'] and inv2['idb'][dn]['stores'][s]['h'] == y['h'])]
    await p2.evaluate("window.__gd9Storage&&window.__gd9Storage.mirrorNow()"); await p2.wait_for_timeout(800)
    gk = await p2.evaluate("(async()=>{const o=await window.__gd9Storage.export();const bad=Object.keys(localStorage).filter(k=>o[k]!==localStorage.getItem(k));return [Object.keys(o).length,localStorage.length,bad]})()")
    json.dump(dict(miss_ls=miss_ls, diff_ls=diff_ls, miss_db=miss_db), open(EV / f'sao_luu_khoi_phuc_{Path(APP).stem}.json', 'w'), ensure_ascii=False, indent=1)
    ok('B2 khôi phục: mọi kho IndexedDB có dữ liệu trùng từng bản ghi', not miss_db, miss_db)
    ok('B3 khôi phục: mọi khóa localStorage có mặt và trùng nội dung', not miss_ls and not diff_ls, dict(thieu=miss_ls, khac=diff_ls))
    ok('B3b kho QLTDProGD9/kv (bản sao dự phòng localStorage) khớp localStorage sau khôi phục', not gk[2], gk)
    nd2 = await so_dong(p2)
    ok('B4 sau khôi phục: trang Tất cả dư nợ cùng số dòng + tổng', nd2 == nd0, (nd0, nd2))
    ok('B5 0 pageerror khi khôi phục', not e2, e2[:3])
    await ctx2.close()
    # C. JSON hỏng: mọi khóa JSON → "{hỏng"
    goc = await pg.evaluate("Object.fromEntries(Object.keys(localStorage).map(k=>[k,localStorage.getItem(k)]))")
    jk = [k for k, v in inv['ls'].items() if v['kind'] in ('object', 'array')]
    await pg.evaluate("ks=>ks.forEach(k=>localStorage.setItem(k,'{hỏng'))", jk)
    errs.clear(); tC = await di_qua(pg, rs, errs, 'hong')
    ok(f'C1 {len(jk)} khóa JSON hỏng: mọi trang mở được, 0 pageerror', not errs and not any(v['hong'] for v in tC.values()), (errs[:5], [k for k, v in tC.items() if v['hong']]))
    ok('C2 JSON hỏng: dữ liệu dư nợ (IndexedDB) còn nguyên', await so_dong(pg) == nd0)
    con = await pg.evaluate("ks=>ks.filter(k=>localStorage.getItem(k)==='{hỏng').length", jk)
    lanh = await pg.evaluate("ks=>ks.filter(k=>{const v=localStorage.getItem(k);if(v===null||v==='{hỏng')return false;try{JSON.parse(v);return true}catch(e){return false}}).length", jk)
    ok(f'C4 sau khi dùng: {lanh} khóa app tự ghi lại bằng giá trị hợp lệ, {con} khóa còn giữ nguyên để kiểm tra; không khóa nào hỏng kiểu khác', lanh + con == len(jk), (lanh, con, len(jk)))
    await pg.reload(wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    bao = await pg.evaluate("(document.getElementById('gd9-toasts')||{}).innerText||''")
    ok(f'C3 JSON hỏng: tải lại trang → app báo rõ "{con} mục dữ liệu lưu trữ hỏng"', ('Phát hiện ' + str(con) + ' mục dữ liệu lưu trữ hỏng') in bao, bao)
    # D. thiếu khóa: xoá hết localStorage
    await pg.evaluate("localStorage.clear()"); errs.clear(); tD = await di_qua(pg, rs, errs, 'thieu')
    ok('D1 xoá hết localStorage: mọi trang mở được, 0 pageerror', not errs and not any(v['hong'] for v in tD.values()), (errs[:5], [k for k, v in tD.items() if v['hong']]))
    ok('D2 xoá hết localStorage: dư nợ (IndexedDB) còn nguyên', await so_dong(pg) == nd0)
    # trả lại trạng thái gốc
    await pg.evaluate("o=>{localStorage.clear();for(const k in o)localStorage.setItem(k,o[k])}", goc)
    # E. dữ liệu cũ: kế hoạch năm dạng ctkh_plan_v1 → v2
    await pg.evaluate("()=>{localStorage.removeItem('ctkh_plan_v2');localStorage.setItem('ctkh_plan_v1',JSON.stringify({keHoachNam:{slKH:1234,tongDuNo:5e12,duNoNH:3e12,duNoTDH:2e12,duNoDN:1e11}}))}")
    await pg.goto(URL + '#/chi-tieu-ke-hoach', wait_until='domcontentloaded'); await pg.wait_for_timeout(2000); await pg.evaluate("(()=>{const b=document.querySelector('[data-testid=ct-tab-matrix]');b&&b.click()})()"); await pg.wait_for_timeout(800)  # P06: tab mặc định nay là BÁO CÁO NGÀY
    mt = await pg.evaluate("(document.querySelector('[data-testid=ct-matrix]')||{}).innerText||''")
    ok('E1 kế hoạch dạng cũ (ctkh_plan_v1) được đọc: KH tổng dư nợ 5.000.000.000.000', '5.000.000.000.000' in mt, mt[:300])
    await pg.evaluate("o=>{localStorage.clear();for(const k in o)localStorage.setItem(k,o[k])}", goc)
    # F. đầy quota — chèn từ tầng thấp nhất trước khi app nạp; bật bằng window.__qFull
    ctx3 = await br.new_context(viewport={'width': 1366, 'height': 768})
    await ctx3.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){};(function(){const o=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(window.__qFull)throw new DOMException('Đầy','QuotaExceededError');return o.call(this,k,v)}})()")
    p3 = await ctx3.new_page(); e3 = []; p3.on('pageerror', lambda e: e3.append(str(e)[:200]))
    await nap(p3); nd3 = await so_dong(p3)
    await p3.goto(URL + '#/lai-dong', wait_until='domcontentloaded'); await p3.wait_for_timeout(1500)
    await p3.evaluate("window.__qFull=true")
    if await p3.locator('[data-testid=gd14-chot]').count(): await p3.fill('[data-testid=gd14-chot]', '2026-11-20'); await p3.wait_for_timeout(500)
    if await p3.locator('[data-testid=dt-den-gon]').count(): await p3.click('[data-testid=dt-den-gon]'); await p3.wait_for_timeout(500)
    q1 = await p3.evaluate("(document.querySelector('[data-testid=gd21-quota]')||{}).innerText||''")
    await p3.goto(URL + '#/chi-tieu-ke-hoach', wait_until='domcontentloaded'); await p3.wait_for_timeout(1500); await p3.evaluate("(()=>{const b=document.querySelector('[data-testid=ct-tab-matrix]');b&&b.click()})()"); await p3.wait_for_timeout(800)  # P06: tab mặc định nay là BÁO CÁO NGÀY
    tb = p3.locator('main button', has_text=re.compile('^THEO CBTD$', re.I))
    if await tb.count(): await tb.first.click(); await p3.wait_for_timeout(600)
    if await p3.locator('[data-testid=gd20-nhom-all]').count(): await p3.click('[data-testid=gd20-nhom-all]'); await p3.wait_for_timeout(500)
    ok('F1 bộ nhớ đầy: thao tác ghi cài đặt không làm app lỗi (0 pageerror)', not e3, e3[:5])
    ok('F2 bộ nhớ đầy: app báo rõ "bộ nhớ trình duyệt đầy" + hướng dẫn sao lưu', 'ĐẦY' in q1 and 'sao lưu' in q1, q1)
    await p3.evaluate("window.__qFull=false")
    ok('F3 bộ nhớ đầy: dư nợ vẫn đọc được', (await so_dong(p3)) == nd3)
    await ctx3.close()
    await br.close()

async def main():
    async with async_playwright() as pw: await run(pw)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
