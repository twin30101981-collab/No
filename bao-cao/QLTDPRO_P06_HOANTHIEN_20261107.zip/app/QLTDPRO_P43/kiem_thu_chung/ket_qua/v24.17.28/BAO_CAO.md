# Hồi quy chung — QLTDPRO_v24.17.28.html

sha256 `de8f8fb756f6e2fca28fdecc07a2fa0e71f8214e7990be4adaeb705353464eea` · app không đổi sau khi chạy: **có** · đối chứng: QLTDPRO_v24.17.27.html · 2026-11-06 05:47:39

**Tổng ca:** PASS 49 · FAIL 0 · LỆCH PB 0 · SKIP 0

| Bộ kiểm | Trạng thái | Pass | Fail | Lệch PB | Skip | Giây | Ghi chú |
|---|---|---|---|---|---|---|---|
| p52_ma_kh | PASS | 14 | 0 | 0 | 0 | 73.9 |  |
| p05_hm21 | PASS | 35 | 0 | 0 | 0 | 108.4 |  |

## Ca LỆCH PB (FAIL do kiểm nhãn/giao diện gắn bản cũ — đã phân loại, KHÔNG tính PASS)

## Ca FAIL / bộ kiểm dừng (cần xem)
