# Hồi quy chung — QLTDPRO_v24.17.40.html

sha256 `eb33e7d5c7b211fd4723ef00da32bdc3b573a6dadf127381fcc78a0ae272e599` · app không đổi sau khi chạy: **có** · đối chứng: QLTDPRO_v24.17.39.html · 2026-11-07 10:26:30

**Tổng ca:** PASS 1775 · FAIL 0 · LỆCH PB 12 · SKIP 7

| Bộ kiểm | Trạng thái | Pass | Fail | Lệch PB | Skip | Giây | Ghi chú |
|---|---|---|---|---|---|---|---|
| p40 | LECH_PB | 66 | 0 | 2 | 0 | 90.1 |  |
| p41_lai_unit | PASS | 18 | 0 | 0 | 0 | 0.0 |  |
| p41_gd14 | LOI_MT | 19 | 0 | 1 | 0 | 31.1 | môi trường: Chromium headless trong container sập khi tải lại trang có handle thư mục OPFS (đã ghi ở bàn giao P42); bộ kiểm này không có cờ QLTD_SKIP_RELOAD như bản v24150. — dừng sau 20 ca; playwright._impl._errors.Targ |
| p41_regress | LECH_PB | 67 | 0 | 2 | 0 | 90.1 |  |
| p42_gd14 | LOI_MT | 25 | 0 | 1 | 0 | 47.0 | môi trường: Chromium headless trong container sập khi tải lại trang có handle thư mục OPFS (đã ghi ở bàn giao P42); bộ kiểm này không có cờ QLTD_SKIP_RELOAD như bản v24150. — dừng sau 26 ca; playwright._impl._errors.Targ |
| p42_regress | LECH_PB | 85 | 0 | 1 | 0 | 106.2 |  |
| p42_mtl_lai | PASS | 11 | 0 | 0 | 0 | 0.0 |  |
| p42_mtl_ui | LECH_PB | 77 | 0 | 2 | 1 | 57.0 |  |
| p42_mtl_regress | LECH_PB | 85 | 0 | 1 | 0 | 106.2 |  |
| p42_mtl_gd14 | LECH_PB | 31 | 0 | 1 | 2 | 59.1 |  |
| p43_mtl_ui | PASS | 79 | 0 | 0 | 1 | 57.2 |  |
| p43_regress | LECH_PB | 85 | 0 | 1 | 0 | 106.2 |  |
| p43_ngay_rieng | PASS | 38 | 0 | 0 | 0 | 11.8 |  |
| p48_dia_chi | PASS | 22 | 0 | 0 | 0 | 31.4 |  |
| p49_ma_kh_copy | PASS | 20 | 0 | 0 | 0 | 24.3 |  |
| p52_ma_kh | PASS | 14 | 0 | 0 | 0 | 79.7 |  |
| p53_khm | PASS | 10 | 0 | 0 | 0 | 12.2 |  |
| p02_hm02 | PASS | 12 | 0 | 0 | 0 | 80.4 |  |
| p02_hm15 | PASS | 12 | 0 | 0 | 0 | 59.5 |  |
| p02_hm11 | PASS | 23 | 0 | 0 | 0 | 0.0 |  |
| p03_hm11b | PASS | 25 | 0 | 0 | 0 | 64.0 |  |
| p03_hm17 | PASS | 5 | 0 | 0 | 0 | 30.0 |  |
| p04_hm12 | PASS | 28 | 0 | 0 | 0 | 71.4 |  |
| p04_hm18 | PASS | 23 | 0 | 0 | 0 | 87.3 |  |
| p04_hm14_loi | PASS | 229 | 0 | 0 | 0 | 0.1 |  |
| p04_hm14 | PASS | 49 | 0 | 0 | 0 | 18.3 |  |
| p04_hm19 | PASS | 36 | 0 | 0 | 0 | 30.7 |  |
| p04_l07 | PASS | 32 | 0 | 0 | 0 | 32.1 |  |
| p04_hm20 | PASS | 31 | 0 | 0 | 0 | 59.4 |  |
| p04_hm03 | PASS | 19 | 0 | 0 | 0 | 128.1 |  |
| p04_hm04 | PASS | 5 | 0 | 0 | 0 | 77.0 |  |
| p04_hm05 | PASS | 5 | 0 | 0 | 1 | 31.3 |  |
| p04_hm06 | PASS | 21 | 0 | 0 | 0 | 87.7 |  |
| p04_hm22 | PASS | 6 | 0 | 0 | 0 | 27.7 |  |
| p04_hm23 | PASS | 25 | 0 | 0 | 0 | 106.4 |  |
| p05_hm21 | PASS | 35 | 0 | 0 | 0 | 111.4 |  |
| p05_hm21b | PASS | 77 | 0 | 0 | 2 | 191.6 |  |
| p05_hm25 | PASS | 34 | 0 | 0 | 0 | 91.7 |  |
| p05_hm26 | PASS | 14 | 0 | 0 | 0 | 57.4 |  |
| p05_hm27 | PASS | 28 | 0 | 0 | 0 | 62.9 |  |
| p05_hm28 | PASS | 19 | 0 | 0 | 0 | 91.9 |  |
| p05_hm29 | PASS | 26 | 0 | 0 | 0 | 98.4 |  |
| p05_hm30 | PASS | 32 | 0 | 0 | 0 | 65.0 |  |
| p06_hm31 | PASS | 32 | 0 | 0 | 0 | 159.4 |  |
| p06_hm31b | PASS | 59 | 0 | 0 | 0 | 125.9 |  |
| p06_hm07 | PASS | 9 | 0 | 0 | 0 | 34.7 |  |
| p06_hm31c | PASS | 36 | 0 | 0 | 0 | 147.7 |  |
| p06_hm31d | PASS | 27 | 0 | 0 | 0 | 127.5 |  |
| p06_hm31e | PASS | 9 | 0 | 0 | 0 | 62.4 |  |

## Ca LỆCH PB (FAIL do kiểm nhãn/giao diện gắn bản cũ — đã phân loại, KHÔNG tính PASS)
- **p40** · T1 nhãn 24.12.0 + khối gd13 + accept có .zip —
- **p40** · T2b nhập qua zip == nhập thẳng xlsx (trạng thái từng tệp) — ([' ✓ msit80_30-09-2026.xlsx Dư nợ IPCAS 30/09/2026🏷️ Mốc: 📊 Quý 3 (30/09/2026) (tự động) 440 KB Chọ
  - Lý do: Ca T1 gộp 3 điều kiện: nhãn chuỗi "24.x.0" của bản cũ + khối gd13 + accept có .zip. Đã kiểm v24.17.9: có id="gd13-js", accept ".xls,.xlsx,.xlsm,.csv,.zip,.rar,.7z" → chỉ nhãn phiên bản khác. | Ca T2b (bản P40/P41) so nguyên văn dòng bảng kế hoạch; từ P42 bảng có thêm cột "Nguồn" (Chọn tệp / ZIP: …) nên văn bản khác. Bản P42 của cùng ca (p42_regress T2b) đã lọc cột Nguồn — dùng làm đối chứng: phải PASS.
- **p41_gd14** · A4 module nạp: QLTDLai + GD14 —
  - Lý do: Ca A4 so GD14.PHIEN_BAN với "P41-GD14 1.0.0"; v24.17.9 khai báo "P43-GD14 1.2.0" (nâng cấp hợp lệ ở P43). Sự có mặt QLTDLai/GD14 được các ca khác của cùng bộ kiểm dùng.
- **p41_regress** · T1 nhãn 24.13.0 + khối gd14 + accept có .zip —
- **p41_regress** · T2b nhập qua zip == nhập thẳng xlsx (trạng thái từng tệp) — ([' ✓ msit80_30-09-2026.xlsx Dư nợ IPCAS 30/09/2026🏷️ Mốc: 📊 Quý 3 (30/09/2026) (tự động) 440 KB Chọ
  - Lý do: Ca T1 gộp 3 điều kiện: nhãn chuỗi "24.x.0" của bản cũ + khối gd13 + accept có .zip. Đã kiểm v24.17.9: có id="gd13-js", accept ".xls,.xlsx,.xlsm,.csv,.zip,.rar,.7z" → chỉ nhãn phiên bản khác. | Ca T2b (bản P40/P41) so nguyên văn dòng bảng kế hoạch; từ P42 bảng có thêm cột "Nguồn" (Chọn tệp / ZIP: …) nên văn bản khác. Bản P42 của cùng ca (p42_regress T2b) đã lọc cột Nguồn — dùng làm đối chứng: phải PASS.
- **p42_gd14** · A4 module nạp: QLTDLai + GD14 (P42) —
  - Lý do: Ca A4 so GD14.PHIEN_BAN với "P41-GD14 1.0.0"; v24.17.9 khai báo "P43-GD14 1.2.0" (nâng cấp hợp lệ ở P43). Sự có mặt QLTDLai/GD14 được các ca khác của cùng bộ kiểm dùng.
- **p42_regress** · T1 nhãn 24.14.0 + khối gd14 + accept có .zip —
  - Lý do: Ca T1 gộp 3 điều kiện: nhãn chuỗi "24.x.0" của bản cũ + khối gd13 + accept có .zip. Đã kiểm v24.17.9: có id="gd13-js", accept ".xls,.xlsx,.xlsm,.csv,.zip,.rar,.7z" → chỉ nhãn phiên bản khác.
- **p42_mtl_ui** · mobile M1b lõi nạp nguyên bản + GD14 1.1.0 —
- **p42_mtl_ui** · desktop M1b lõi nạp nguyên bản + GD14 1.1.0 —
  - Lý do: Ca M1b (bản P42) đòi GD14.PHIEN_BAN = "P42-GD14 1.1.0"; v24.17.9 là "P43-GD14 1.2.0". Bản P43 của cùng ca (p43_mtl_ui M1b) đòi "P43-GD14 1.2.0" và lõi "P41-GD1-M1 1.0.0" — dùng làm đối chứng: phải PASS.
- **p42_mtl_regress** · T1 nhãn 24.15.0 + khối gd14 + accept có .zip —
  - Lý do: Ca T1 gộp 3 điều kiện: nhãn chuỗi "24.x.0" của bản cũ + khối gd13 + accept có .zip. Đã kiểm v24.17.9: có id="gd13-js", accept ".xls,.xlsx,.xlsm,.csv,.zip,.rar,.7z" → chỉ nhãn phiên bản khác.
- **p42_mtl_gd14** · A4 module nạp: QLTDLai + GD14 (P42) —
  - Lý do: Ca A4 so GD14.PHIEN_BAN với "P41-GD14 1.0.0"; v24.17.9 khai báo "P43-GD14 1.2.0" (nâng cấp hợp lệ ở P43). Sự có mặt QLTDLai/GD14 được các ca khác của cùng bộ kiểm dùng.
- **p43_regress** · T1 nhãn 24.15.0 + khối gd14 + accept có .zip —
  - Lý do: Ca T1 gộp 3 điều kiện: nhãn chuỗi "24.x.0" của bản cũ + khối gd13 + accept có .zip. Đã kiểm v24.17.9: có id="gd13-js", accept ".xls,.xlsx,.xlsm,.csv,.zip,.rar,.7z" → chỉ nhãn phiên bản khác.

## Ca FAIL / bộ kiểm dừng (cần xem)
- **p41_gd14** [LOI_MT] môi trường: Chromium headless trong container sập khi tải lại trang có handle thư mục OPFS (đã ghi ở bàn giao P42); bộ kiểm này không có cờ QLTD_SKIP_RELOAD như bản v24150. — dừng sau 20 ca; playwright._impl._errors.TargetClosedError: Page.wait_for_timeout: Target page, context or browser has been c
- **p42_gd14** [LOI_MT] môi trường: Chromium headless trong container sập khi tải lại trang có handle thư mục OPFS (đã ghi ở bàn giao P42); bộ kiểm này không có cờ QLTD_SKIP_RELOAD như bản v24150. — dừng sau 26 ca; playwright._impl._errors.TargetClosedError: Page.wait_for_timeout: Target page, context or browser has been c
