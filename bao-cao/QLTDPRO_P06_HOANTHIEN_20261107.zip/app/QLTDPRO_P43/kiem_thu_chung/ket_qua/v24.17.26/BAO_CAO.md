# Hồi quy chung — QLTDPRO_v24.17.26.html

sha256 `a6bc331731c1846212787222eea0dc7debb45ed438bfe56218f809e71bec72b9` · app không đổi sau khi chạy: **có** · đối chứng: None · 2026-11-06 02:29:05

**Tổng ca:** PASS 950 · FAIL 0 · LỆCH PB 5 · SKIP 5

| Bộ kiểm | Trạng thái | Pass | Fail | Lệch PB | Skip | Giây | Ghi chú |
|---|---|---|---|---|---|---|---|
| p40 | KHONG_CHAY | 0 | 0 | 0 | 0 | 0 | cần bản đối chứng cho baseline/QLTDPRO_v24.11.0.html nhưng không có bản liền trước |
| p41_lai_unit | PASS | 18 | 0 | 0 | 0 | 0.1 |  |
| p41_gd14 | LOI_MT | 19 | 0 | 1 | 0 | 34.0 | môi trường: Chromium headless trong container sập khi tải lại trang có handle thư mục OPFS (đã ghi ở bàn giao P42); bộ kiểm này không có cờ QLTD_SKIP_RELOAD như bản v24150. — dừng sau 20 ca; playwright._impl._errors.Targ |
| p41_regress | KHONG_CHAY | 0 | 0 | 0 | 0 | 0 | cần bản đối chứng cho app/QLTDPRO_v24.12.0.html nhưng không có bản liền trước |
| p42_gd14 | LOI_MT | 25 | 0 | 1 | 0 | 46.1 | môi trường: Chromium headless trong container sập khi tải lại trang có handle thư mục OPFS (đã ghi ở bàn giao P42); bộ kiểm này không có cờ QLTD_SKIP_RELOAD như bản v24150. — dừng sau 26 ca; playwright._impl._errors.Targ |
| p42_regress | KHONG_CHAY | 0 | 0 | 0 | 0 | 0 | cần bản đối chứng cho app/QLTDPRO_v24.13.0.html nhưng không có bản liền trước |
| p42_mtl_lai | PASS | 11 | 0 | 0 | 0 | 0.0 |  |
| p42_mtl_ui | LECH_PB | 77 | 0 | 2 | 1 | 54.0 |  |
| p42_mtl_regress | KHONG_CHAY | 0 | 0 | 0 | 0 | 0 | cần bản đối chứng cho app/QLTDPRO_v24.14.0.html nhưng không có bản liền trước |
| p42_mtl_gd14 | LECH_PB | 31 | 0 | 1 | 2 | 58.3 |  |
| p43_mtl_ui | PASS | 79 | 0 | 0 | 1 | 53.4 |  |
| p43_regress | KHONG_CHAY | 0 | 0 | 0 | 0 | 0 | cần bản đối chứng cho app/QLTDPRO_v24.15.0.html nhưng không có bản liền trước |
| p43_ngay_rieng | PASS | 38 | 0 | 0 | 0 | 10.6 |  |
| p48_dia_chi | PASS | 22 | 0 | 0 | 0 | 30.9 |  |
| p49_ma_kh_copy | PASS | 20 | 0 | 0 | 0 | 23.8 |  |
| p52_ma_kh | PASS | 14 | 0 | 0 | 0 | 72.9 |  |
| p53_khm | PASS | 10 | 0 | 0 | 0 | 12.0 |  |
| p02_hm02 | PASS | 12 | 0 | 0 | 0 | 80.3 |  |
| p02_hm15 | PASS | 12 | 0 | 0 | 0 | 58.7 |  |
| p02_hm11 | PASS | 23 | 0 | 0 | 0 | 0.0 |  |
| p03_hm11b | PASS | 25 | 0 | 0 | 0 | 59.9 |  |
| p03_hm17 | PASS | 5 | 0 | 0 | 0 | 28.2 |  |
| p04_hm12 | PASS | 28 | 0 | 0 | 0 | 63.9 |  |
| p04_hm18 | PASS | 23 | 0 | 0 | 0 | 84.5 |  |
| p04_hm14_loi | PASS | 229 | 0 | 0 | 0 | 0.1 |  |
| p04_hm14 | PASS | 49 | 0 | 0 | 0 | 17.5 |  |
| p04_hm19 | PASS | 36 | 0 | 0 | 0 | 30.2 |  |
| p04_l07 | PASS | 32 | 0 | 0 | 0 | 31.6 |  |
| p04_hm20 | PASS | 31 | 0 | 0 | 0 | 55.2 |  |
| p04_hm03 | PASS | 19 | 0 | 0 | 0 | 121.3 |  |
| p04_hm04 | PASS | 5 | 0 | 0 | 0 | 74.5 |  |
| p04_hm05 | PASS | 5 | 0 | 0 | 1 | 29.7 |  |
| p04_hm06 | PASS | 21 | 0 | 0 | 0 | 84.4 |  |
| p04_hm22 | PASS | 6 | 0 | 0 | 0 | 25.9 |  |
| p04_hm23 | PASS | 25 | 0 | 0 | 0 | 103.7 |  |

## Ca LỆCH PB (FAIL do kiểm nhãn/giao diện gắn bản cũ — đã phân loại, KHÔNG tính PASS)
- **p41_gd14** · A4 module nạp: QLTDLai + GD14 —
  - Lý do: Ca A4 so GD14.PHIEN_BAN với "P41-GD14 1.0.0"; v24.17.9 khai báo "P43-GD14 1.2.0" (nâng cấp hợp lệ ở P43). Sự có mặt QLTDLai/GD14 được các ca khác của cùng bộ kiểm dùng.
- **p42_gd14** · A4 module nạp: QLTDLai + GD14 (P42) —
  - Lý do: Ca A4 so GD14.PHIEN_BAN với "P41-GD14 1.0.0"; v24.17.9 khai báo "P43-GD14 1.2.0" (nâng cấp hợp lệ ở P43). Sự có mặt QLTDLai/GD14 được các ca khác của cùng bộ kiểm dùng.
- **p42_mtl_ui** · mobile M1b lõi nạp nguyên bản + GD14 1.1.0 —
- **p42_mtl_ui** · desktop M1b lõi nạp nguyên bản + GD14 1.1.0 —
  - Lý do: Ca M1b (bản P42) đòi GD14.PHIEN_BAN = "P42-GD14 1.1.0"; v24.17.9 là "P43-GD14 1.2.0". Bản P43 của cùng ca (p43_mtl_ui M1b) đòi "P43-GD14 1.2.0" và lõi "P41-GD1-M1 1.0.0" — dùng làm đối chứng: phải PASS.
- **p42_mtl_gd14** · A4 module nạp: QLTDLai + GD14 (P42) —
  - Lý do: Ca A4 so GD14.PHIEN_BAN với "P41-GD14 1.0.0"; v24.17.9 khai báo "P43-GD14 1.2.0" (nâng cấp hợp lệ ở P43). Sự có mặt QLTDLai/GD14 được các ca khác của cùng bộ kiểm dùng.

## Ca FAIL / bộ kiểm dừng (cần xem)
- **p40** [KHONG_CHAY] cần bản đối chứng cho baseline/QLTDPRO_v24.11.0.html nhưng không có bản liền trước
- **p41_gd14** [LOI_MT] môi trường: Chromium headless trong container sập khi tải lại trang có handle thư mục OPFS (đã ghi ở bàn giao P42); bộ kiểm này không có cờ QLTD_SKIP_RELOAD như bản v24150. — dừng sau 20 ca; playwright._impl._errors.TargetClosedError: Page.wait_for_timeout: Target page, context or browser has been c
- **p41_regress** [KHONG_CHAY] cần bản đối chứng cho app/QLTDPRO_v24.12.0.html nhưng không có bản liền trước
- **p42_gd14** [LOI_MT] môi trường: Chromium headless trong container sập khi tải lại trang có handle thư mục OPFS (đã ghi ở bàn giao P42); bộ kiểm này không có cờ QLTD_SKIP_RELOAD như bản v24150. — dừng sau 26 ca; playwright._impl._errors.TargetClosedError: Page.wait_for_timeout: Target page, context or browser has been c
- **p42_regress** [KHONG_CHAY] cần bản đối chứng cho app/QLTDPRO_v24.13.0.html nhưng không có bản liền trước
- **p42_mtl_regress** [KHONG_CHAY] cần bản đối chứng cho app/QLTDPRO_v24.14.0.html nhưng không có bản liền trước
- **p43_regress** [KHONG_CHAY] cần bản đối chứng cho app/QLTDPRO_v24.15.0.html nhưng không có bản liền trước
