# P06 · HM-31 · v24.17.40 — từ v24.17.39: ngày HIỆU LỰC THỰC TẾ của sổ bàn giao (người dùng 07/11: bàn giao hiệu lực từ 01/10/2026).
#  Gợi ý vẫn đặt ngày = ngày mốc sau; người dùng nhập "Ngày hiệu lực thực tế" khi xác nhận (hoặc sửa ngay trong bảng "Đã xác nhận").
#  Dòng sổ lưu thêm "moc" (ngày mốc gợi ý) để gợi ý không lặp lại. Kế hoạch quý IV chuyển theo bàn giao có hiệu lực từ 01/10 (cả quý).
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P06/build_p06_hm31e.py   (cần v24.17.39)
import hashlib
SRC = 'app/QLTDPRO_v24.17.39.html'; DST = 'app/QLTDPRO_v24.17.40.html'
s = open(SRC, encoding='utf-8').read()
a = s.index('<script id="gd28-js">'); b = s.index('</script>', a) + len('</script>\n')
s = s[:a] + '<script id="gd28-js">\n' + open('nguon_P06/gd28_v40.js', encoding='utf-8').read() + '\n</script>\n' + s[b:]
c = s.count('"24.17.39"'); assert c == 2, c
s = s.replace('"24.17.39"', '"24.17.40"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.39' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.39', '24.17.40'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
