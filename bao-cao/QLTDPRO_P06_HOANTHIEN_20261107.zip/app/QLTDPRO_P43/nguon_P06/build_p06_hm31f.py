# P06 · v24.17.42 — từ v24.17.41 (người dùng 07/11, ảnh màn hình điện thoại):
#  (1) trang Chỉ tiêu kế hoạch mở mặc định ở tab BÁO CÁO NGÀY; (2) khối "📊 Kế hoạch quý" đặt TRÊN "🔁 Sổ bàn giao cán bộ";
#  (3) cho phép ngày hiệu lực thực tế SAU ngày mốc gợi ý (Lưu trữ có mốc "30/09" đã mang số sau bàn giao — tệp đầu tháng 10 gắn nhãn quý III).
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P06/build_p06_hm31f.py   (cần v24.17.41)
import hashlib
SRC = 'app/QLTDPRO_v24.17.41.html'; DST = 'app/QLTDPRO_v24.17.42.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:100]); s = s.replace(old, new)
a = s.index('<script id="gd28-js">'); b = s.index('</script>', a) + len('</script>\n')
s = s[:a] + '<script id="gd28-js">\n' + open('nguon_P06/gd28.js', encoding='utf-8').read() + '\n</script>\n' + s[b:]
rep('D.useState("matrix")', 'D.useState("ngay")')
i = s.index('o.jsx("div",{className:"no-print","data-testid":"bg-host"'); j = s.index(',o.jsx("div",{className:"no-print","data-testid":"kh-host"', i)
k = s.index('})}})', j) + len('})}})')            # hết khối kh-host
bg, kh = s[i:j], s[j + 1:k]
assert kh.startswith('o.jsx("div",{className:"no-print","data-testid":"kh-host"') and kh.count('QLTDKH.panel') == 1 and bg.count('QLTDBG.panel') == 1, (kh[:80], bg[:80])
s = s[:i] + kh + ',' + bg + s[k:]
c = s.count('"24.17.41"'); assert c == 2, c
s = s.replace('"24.17.41"', '"24.17.42"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.41' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.41', '24.17.42'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
