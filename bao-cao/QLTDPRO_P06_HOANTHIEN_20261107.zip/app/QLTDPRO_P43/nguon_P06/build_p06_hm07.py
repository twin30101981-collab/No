# P06 · HM-07 · v24.17.37 — bỏ tự tải 83 mẫu hồ sơ từ thư mục templates/ khi mở app.
#  Q27 (người dùng 07/11): mẫu nạp bằng "📁 Nạp thư mục mẫu…" trong 📚 Bộ hồ sơ; app mở bằng tệp .html trực tiếp (file://).
#  Trước sửa: mỗi trình duyệt mới mở app → 1 HEAD templates/… → http: 404 + 1 lỗi console; file://: 2 lỗi console (CORS + ERR_FAILED);
#  sau đó cờ gd9_tplok=0 khoá vĩnh viễn; CSDL QLTDProMauHsvx tạo rỗng ngay khi mở.
#  Sau sửa: 0 yêu cầu templates/, 0 lỗi console; CSDL mẫu chỉ tạo khi mở Bộ hồ sơ; báo lỗi "chưa nạp mẫu" chỉ cách nạp.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P06/build_p06_hm07.py   (cần v24.17.36)
import hashlib, re
SRC = 'app/QLTDPRO_v24.17.36.html'; DST = 'app/QLTDPRO_v24.17.37.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:90]); s = s.replace(old, new)
a = s.index('/* QLTDPRO: nạp sẵn 83 mẫu hồ sơ vào kho IndexedDB')
b = s.index('})();\n</script>', a) + len('})();\n')
blk = s[a:b]; assert blk.count('__gd9TplFetch(') == 1 and blk.count('var PATHS') == 1 and len(blk) < 12000, len(blk)
s = s[:a] + '/* HM-07 (P06, 07/11/2026): bỏ tự tải 83 mẫu từ templates/ khi mở app (Q27) — mẫu nạp bằng "📁 Nạp thư mục mẫu…" trong 📚 Bộ hồ sơ. */\n' + s[b:]
rep('new Error("chưa nạp mẫu")', 'new Error("chưa nạp mẫu — mở 📚 Bộ hồ sơ, bấm 📁 Nạp thư mục mẫu…")', 2)
assert s.count('__gd9TplFetch(') == 0
c = s.count('"24.17.36"'); assert c == 2, c
s = s.replace('"24.17.36"', '"24.17.37"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.36' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.36', '24.17.37'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest(), 'bỏ', len(blk), 'ký tự')
