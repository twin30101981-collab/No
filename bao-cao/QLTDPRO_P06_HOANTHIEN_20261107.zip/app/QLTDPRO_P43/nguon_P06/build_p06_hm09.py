# P06 · HM-09 Hiệu năng · v24.17.41 — từ v24.17.40. Đo bằng CDP profiler trên 12 mốc thật (evidence/hm09): điểm nghẽn trang Chỉ tiêu KH:
#  (1) chuẩn hoá tên lặp lại hàng chục nghìn lần (gr của bundle, norm của gd28) ⇒ bộ nhớ đệm theo chuỗi;
#  (2) Qv quét mọi mốc lưu trữ ⇒ chỉ quét dữ liệu hiện hành + 3 mốc dùng (Đầu năm/quý/tháng);
#  (3) Báo cáo ngày tính 2 lần (tính lại + thô) kể cả khi sổ trống / chế độ cũ ⇒ bỏ lần thứ 2 khi không có gì để áp;
#  (4) sổ bàn giao dựng lại ngữ cảnh/gợi ý/cảnh báo tên mỗi lần vẽ ⇒ dùng lại theo dữ liệu (gd28.js).
# Kết quả tính không đổi (hồi quy + bộ kiểm số thật). Chạy từ app/QLTDPRO_P43/:  python3 nguon_P06/build_p06_hm09.py
import hashlib
SRC = 'app/QLTDPRO_v24.17.40.html'; DST = 'app/QLTDPRO_v24.17.41.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:100]); s = s.replace(old, new)
a = s.index('<script id="gd28-js">'); b = s.index('</script>', a) + len('</script>\n')
s = s[:a] + '<script id="gd28-js">\n' + open('nguon_P06/gd28_v41.js', encoding='utf-8').read() + '\n</script>\n' + s[b:]
rep('gr=e=>String(e||"").trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/đ/g,"d").replace(/Đ/g,"d").replace(/\\./g," ").replace(/\\s+/g," ").trim();',
    'gr=(()=>{const __m=new Map;return e=>{const __k=String(e||"");let __v=__m.get(__k);if(__v===void 0){__v=__k.trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/đ/g,"d").replace(/Đ/g,"d").replace(/\\./g," ").replace(/\\s+/g," ").trim();__m.size>2e4&&__m.clear();__m.set(__k,__v)}return __v}})();')
rep('{map:s,members:l}=Qv(n,[e].concat(t.map(w=>w.rows)),1)', '{map:s,members:l}=Qv(n,[e].concat([i.EoY1,i.EoQ1,i.EoM1].map(w=>{const x=w&&H3(t,w);return x?x.rows:[]})),1)')
rep('const __a=P3(e,t,n,r,s),__b=window.QLTDBG.raw(()=>P3(e,t,n,r,s));return window.QLTDBG.gopBG(__a,__b)},[e,t,n,r,s,__S,e0,__v])',
    'const __a=P3(e,t,n,r,s),__b=window.QLTDBG.canApDung&&!window.QLTDBG.canApDung()?__a:window.QLTDBG.raw(()=>P3(e,t,n,r,s));return window.QLTDBG.gopBG(__a,__b)},[e,t,n,r,s,__S,e0,__v])')
c = s.count('"24.17.40"'); assert c == 2, c
s = s.replace('"24.17.40"', '"24.17.41"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.40' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.40', '24.17.41'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
