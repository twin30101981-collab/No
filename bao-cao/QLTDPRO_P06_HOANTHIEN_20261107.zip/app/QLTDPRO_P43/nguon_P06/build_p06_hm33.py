# P06 · v24.17.44 — từ v24.17.43 (người dùng 07/11: "ưu tiên kỳ mới nhất rồi mới đến các kỳ cũ hơn"):
#  cột mốc trang Chỉ tiêu KH (TỔNG QUAN / THEO CBTD / THEO PHÒNG / THEO LOẠI VAY) xếp mốc mới nhất trước, mốc "cùng kỳ năm trước" ở cuối;
#  Excel "Xu hướng các kỳ" (xuất báo cáo hệ thống) xếp kỳ mới nhất trước (chênh lệch vẫn so kỳ liền trước).
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P06/build_p06_hm33.py   (cần v24.17.43)
import hashlib
SRC = 'app/QLTDPRO_v24.17.43.html'; DST = 'app/QLTDPRO_v24.17.44.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:100]); s = s.replace(old, new)
rep('re=au(x,r,T).filter(se=>se.hasData),ne=re.map', 're=au(x,r,T).filter(se=>se.hasData).map((se,__i)=>[se,__i]).sort(([__a,__i],[__b,__j])=>(__a.yoy?1:0)-(__b.yoy?1:0)||String(Ud(__b.snap)||"").localeCompare(String(Ud(__a.snap)||""))||__i-__j).map(([__a])=>__a),ne=re.map')
rep('p?f.totals.duno-s.periods[p-1].totals.duno:""]}))', 'p?f.totals.duno-s.periods[p-1].totals.duno:""]}).reverse())')
c = s.count('"24.17.43"'); assert c == 2, c
s = s.replace('"24.17.43"', '"24.17.44"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.43' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.43', '24.17.44'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
