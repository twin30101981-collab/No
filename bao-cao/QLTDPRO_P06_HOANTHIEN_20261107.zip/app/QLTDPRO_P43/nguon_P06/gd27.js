/* gd27 · HM-31 GĐ1 (v24.17.35): ngày báo cáo = ngày DỮ LIỆU (không phải ngày máy) cho Báo cáo ngày + Trả nợ. */
(function () {
  function ngay(dd) {
    var t = String(dd || "").trim(), m = t.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if (m) return new Date(+m[3], +m[2] - 1, +m[1], 12, 0, 0);
    m = t.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (m) return new Date(+m[1], +m[2] - 1, +m[3], 12, 0, 0);
    return new Date();
  }
  window.QLTDBC31 = { ngay: ngay, NHOM: "CÁN BỘ ĐÃ BÀN GIAO / NGOÀI DANH MỤC" };
})();
