# P06 · HM-31 GĐ2 (phần còn lại) · v24.17.38 — từ v24.17.37.
#  (1) mã cán bộ (cột ofcno của msit80 → dòng r[32]); sổ bàn giao khớp theo MÃ (dòng cũ chưa có mã tra theo tên);
#  (2) cảnh báo tên gần giống / cùng mã khác tên;  (3) cột "Bàn giao đầu quý / đầu năm" (nhận + / giao −) + kiểm Σ bàn giao = 0;
#  (4) nút chọn "Mốc so sánh": theo danh mục đang quản lý (mặc định) / theo cán bộ tại thời điểm mốc (cách cũ);
#  (5) sổ: phạm vi theo mã KH / mã khế ước, ghi chú, người lập, thêm thủ công, xuất Excel biên bản;
#  (6) áp sổ bàn giao cho: Chỉ tiêu kế hoạch (THEO CBTD/PHÒNG/…), Tổng quan "Biến động dư nợ theo cán bộ", Trả nợ/xuất TS.
#  Quyết định thiết kế: dòng PHÒNG = Σ cán bộ của phòng (đúng bản in); không gom theo phòng của khế ước (N8) vì lệch bản in.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P06/build_p06_hm31c.py   (cần v24.17.37)
import hashlib, re
SRC = 'app/QLTDPRO_v24.17.37.html'; DST = 'app/QLTDPRO_v24.17.38.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:100]); s = s.replace(old, new)
# 0) thay khối gd28 (css + js)
a = s.index('<style id="gd28-css">'); b = s.index('</style>', a) + len('</style>\n')
s = s[:a] + '<style id="gd28-css">\n' + open('nguon_P06/gd28_v38.css', encoding='utf-8').read() + '</style>\n' + s[b:]
a = s.index('<script id="gd28-js">'); b = s.index('</script>', a) + len('</script>\n')
s = s[:a] + '<script id="gd28-js">\n' + open('nguon_P06/gd28_v38.js', encoding='utf-8').read() + '\n</script>\n' + s[b:]
# 1) mã cán bộ r[32]
rep('custtpnm:n("custtpnm"),custdtltpnm:n("custdtltpnm")};if(a.brcd<0||a.custnm<0)', 'custtpnm:n("custtpnm"),custdtltpnm:n("custdtltpnm"),ofcno:n("ofcno")};if(a.brcd<0||a.custnm<0)')
rep('a.custdtltpnm>=0?String(h[a.custdtltpnm]||"").trim():""])}let s=0,l=0;', 'a.custdtltpnm>=0?String(h[a.custdtltpnm]||"").trim():"",a.ofcno>=0?String(h[a.ofcno]||"").trim():""])}let s=0,l=0;')
rep("['ofcno',-1]", "['ofcno',32]")
# 3) P3: phát mọi dòng nhóm ngoài danh mục (gopBG lọc dòng 0), cảnh báo nhóm do gopBG dựng
rep(';if(w.key==="__bg"&&!(j.dauNam||j.dauQuy||j.dauThang||j.bc||k.dauNam||k.dauQuy||k.dauThang||k.bc))return;w.key==="__bg"&&__bg.push(N.name),__c++,m.push(', ';__c++,m.push(')
rep('warn:(b.length?`⚠ Chưa có snapshot mốc: ${b.join(", ")} — các cột tương ứng sẽ trống.`:"")+(__bg.length?(b.length?" · ":"")+`ℹ ${__bg.length} cán bộ không có trong danh mục (đã bàn giao hoặc tên khác danh mục): ${__bg.join(", ")} — vẫn cộng vào TỔNG, ở nhóm riêng.`:"")}}',
    'warn:b.length?`⚠ Chưa có snapshot mốc: ${b.join(", ")} — các cột tương ứng sẽ trống.`:""}}')
# cột Bàn giao
rep('yo=()=>({dauNam:0,dauQuy:0,dauThang:0,bc:0,plan:0})', 'yo=()=>({dauNam:0,dauQuy:0,dauThang:0,bc:0,plan:0,bgQ:0,bgN:0})')
rep('e.bc+=t.bc,e.plan+=t.plan}', 'e.bc+=t.bc,e.plan+=t.plan,e.bgQ+=t.bgQ||0,e.bgN+=t.bgN||0}')
rep('"+/- KH quý","Kế hoạch"]', '"+/- KH quý","Kế hoạch","Bàn giao đầu quý","Bàn giao đầu năm"]')
rep('"+/- kế hoạch","Kế hoạch quý"]', '"+/- kế hoạch","Kế hoạch quý","Bàn giao đầu quý","Bàn giao đầu năm"]')
rep('e.bc-e.dauQuy-e.plan,e.plan]', 'e.bc-e.dauQuy-e.plan,e.plan,e.bgQ||0,e.bgN||0]')
rep('widths:[24,13,13,13,13,13,13,13,13,13]', 'widths:[24,13,13,13,13,13,13,13,13,13,13,13]')
# s6: tính 2 lần (tính lại / thô) → gopBG; nút xuất Excel cho sổ
rep('l=D.useMemo(()=>(window.QLTDBG&&window.QLTDBG.ctx({snaps:__S,rows:e0,bcKey:bc(s)}),P3(e,t,n,r,s)),[e,t,n,r,s,__S,e0,__v])',
    'l=D.useMemo(()=>{if(!window.QLTDBG)return P3(e,t,n,r,s);window.QLTDBG.ctx({snaps:__S,rows:e0,bcKey:bc(s)});const __a=P3(e,t,n,r,s),__b=window.QLTDBG.raw(()=>P3(e,t,n,r,s));return window.QLTDBG.gopBG(__a,__b)},[e,t,n,r,s,__S,e0,__v])')
rep('res:l,setLoc:', 'res:l,xlsx:(__sh,__fn)=>St(new Blob([Qd(__sh)],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),__fn),setLoc:')
# 6a) Chỉ tiêu kế hoạch: ngữ cảnh + mốc của từng cột
rep('yc=(e,t,n)=>e.snap&&Array.isArray(e.snap.rows)?Kd(e.snap.rows,t,n):null', 'yc=(e,t,n)=>e.snap&&Array.isArray(e.snap.rows)?Kd(window.QLTDBG?window.QLTDBG.apDung(e.snap.rows,Ud(e.snap)):e.snap.rows,t,n):null')
rep(',T=new Date;if(!n)return o.jsx("div",{className:"p-4","data-testid":"page-chi-tieu-ke-hoach"',
    ',T=new Date;(()=>{try{window.QLTDBG&&r&&window.QLTDBG.setCtx(r.filter(zd).map(__x=>({key:Ud(__x),rows:__x.rows})).filter(__x=>__x.key),v,window.__qltdView?window.__qltdView.dd:c6("_currentFileDate"))}catch{}})();if(!n)return o.jsx("div",{className:"p-4","data-testid":"page-chi-tieu-ke-hoach"')
# 6b) Tổng quan: Biến động dư nợ theo cán bộ so kỳ trước
rep("return {label: dmy(best.d), rows: best.rows.filter(", "return {label: dmy(best.d), rows: (window.QLTDBG ? window.QLTDBG.apDungGd7(best.rows, best.label) : best.rows).filter(")
# 6c) Trả nợ / xuất TS
rep('function v3(e,t,n,r,a,i){const s=B=>', 'function v3(e,t,n,r,a,i){t=window.QLTDBG?window.QLTDBG.apDungSnaps(t,e,bc(a),Ud):t;const s=B=>')
c = s.count('"24.17.37"'); assert c == 2, c
s = s.replace('"24.17.37"', '"24.17.38"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.37' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.37', '24.17.38'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
