# P06 · HM-31 GĐ2 · v24.17.36 — Sổ bàn giao cán bộ (app gợi ý, người dùng xác nhận) + tính lại mốc theo sổ + phạm vi Báo cáo ngày
#  (Tất cả / Doanh nghiệp / Trung + dài hạn / Trung hạn TK 212 / Ngắn hạn) + kiểm Σ cán bộ = Σ phòng = TỔNG = tổng tệp.
#  Quy tắc (người dùng chốt 07/11): nguyên danh mục A→B ⇒ mọi số mốc trước ngày hiệu lực của A tính cho B; chia danh mục ⇒ theo từng KH mọi mốc
#  (KH còn ở ngày hiệu lực → cán bộ đang quản lý; đã tất toán → người nhận chính).
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P06/build_p06_hm31b.py   (cần v24.17.35)
import hashlib
SRC = 'app/QLTDPRO_v24.17.35.html'; DST = 'app/QLTDPRO_v24.17.36.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:90]); s = s.replace(old, new)
rep('<script id="gd7-js">', '<style id="gd28-css">\n' + open('nguon_P06/gd28_v36.css', encoding='utf-8').read() + '</style>\n<script id="gd28-js">\n' + open('nguon_P06/gd28_v36.js', encoding='utf-8').read() + '\n</script>\n<script id="gd7-js">')
# P3: áp sổ bàn giao lên dòng của mốc
rep('c=w=>{const x=H3(t,w);return x?ap(x.rows,s):null}', 'c=w=>{const x=H3(t,w);return x?ap(window.QLTDBG?window.QLTDBG.apDung(x.rows,w):x.rows,s):null}')
# s6: phạm vi + ngữ cảnh sổ bàn giao
rep('function s6({rows:e,snaps:t,R:n,plan:r}){const[a,i]=D.useState("kh"),__dd=',
    'function s6({rows:e0,snaps:t0,R:n,plan:r}){const[a,i]=D.useState("kh"),[__loc,__sl]=D.useState(()=>i6("td_bcn_loc")||""),[__v,__sv]=D.useState(0),__F=D.useMemo(()=>window.QLTDBG?window.QLTDBG.loc(__loc,b3):(__x=>__x),[__loc]),e=D.useMemo(()=>__F(e0),[e0,__F]),t=D.useMemo(()=>t0.map(__x=>__x&&Array.isArray(__x.rows)?{...__x,rows:__F(__x.rows)}:__x),[t0,__F]),__S=D.useMemo(()=>{const __m={};t0.filter(zd).forEach(__x=>{const __k=Ud(__x);__k&&(__m[__k]=1)});return Object.keys(__m).sort().map(__k=>({key:__k,rows:H3(t0,__k).rows}))},[t0]),__dd=')
rep('l=D.useMemo(()=>P3(e,t,n,r,s),[e,t,n,r,s]),c=__dd||ip(s)',
    'l=D.useMemo(()=>(window.QLTDBG&&window.QLTDBG.ctx({snaps:__S,rows:e0,bcKey:bc(s)}),P3(e,t,n,r,s)),[e,t,n,r,s,__S,e0,__v]),c=__dd||ip(s)')
rep('"data-testid":"bcn-header",children:R3(a,c)})',
    '"data-testid":"bcn-header",children:window.QLTDBG?window.QLTDBG.tieuDe(a,c,__loc):R3(a,c)}),o.jsx("div",{className:"no-print","data-testid":"bg-host",ref:__el=>{__el&&window.QLTDBG&&window.QLTDBG.panel(__el,{snaps:__S,rows:e0,bcKey:bc(s),loc:__loc,F:__F,res:l,setLoc:__x=>{try{localStorage.setItem("td_bcn_loc",__x)}catch{}__sl(__x)},onChange:()=>__sv(__x=>__x+1)})}})')
c = s.count('"24.17.35"'); assert c == 2, c
s = s.replace('"24.17.35"', '"24.17.36"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.35' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.35', '24.17.36'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
