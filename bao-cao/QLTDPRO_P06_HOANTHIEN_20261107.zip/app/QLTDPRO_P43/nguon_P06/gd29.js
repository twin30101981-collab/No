/* gd29 · HM-31 GĐ3 (v24.17.39): kế hoạch QUÝ theo cán bộ + chuyển kế hoạch theo sổ bàn giao + % thực hiện/dự báo cuối quý
   + xuất đúng mẫu 4 bảng + đối soát với báo cáo tay.
   Lưu: localStorage "td_kh_quy_v1" = { "2026-Q4": { "<M mã|N tên>": {ten, ma, dn (đồng), th (đồng, trung+dài), kh (khách)} } }.
   Chưa có kế hoạch quý ⇒ giữ nguyên kế hoạch năm ÷ 4 của Chỉ tiêu KH. Có ⇒ dùng kế hoạch quý (+ chuyển theo sổ bàn giao nếu bật). */
(function () {
  var KP = "td_kh_quy_v1", KC = "td_kh_chuyen", loai = "", moKH = false, moDS = false;
  function B() { return window.QLTDBG; }
  function norm(s) { return String(s == null ? "" : s).trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/g, "d").replace(/\./g, " ").replace(/\s+/g, " ").trim(); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function p2(n) { return ("0" + n).slice(-2); }
  function fmt(d) { return d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate()); }
  function qInfo(key) {
    var y = +key.slice(0, 4), m = +key.slice(5, 7), d = +key.slice(8, 10), q = Math.floor((m - 1) / 3) + 1;
    var s = new Date(y, (q - 1) * 3, 1), e = new Date(y, q * 3, 0), c = new Date(y, m - 1, d);
    return { q: y + "-Q" + q, nam: y, qn: q, start: fmt(s), end: fmt(e), days: Math.round((e - s) / 864e5) + 1, done: Math.round((c - s) / 864e5) + 1 };
  }
  function all() { try { return JSON.parse(localStorage.getItem(KP) || "{}") || {}; } catch (e) { return {}; } }
  function saveAll(o) { try { localStorage.setItem(KP, JSON.stringify(o)); return true; } catch (e) { return false; } }
  function chuyen() { try { return localStorage.getItem(KC) !== "0"; } catch (e) { return true; } }
  function nghin(n) { n = Math.round(Number(n) || 0); return n.toLocaleString("vi-VN"); }
  function tr(n) { return Math.round((Number(n) || 0) / 1e6).toLocaleString("vi-VN"); }
  function bcKeyOf() { var c = B() && B().getCtx(); return c ? c.bcKey : null; }
  /* kế hoạch quý áp dụng (đã chuyển theo sổ bàn giao nếu bật) */
  function tinh(qk, bcKey) {
    var P = all()[qk]; if (!P || !Object.keys(P).length) return null;
    var R = {}; Object.keys(P).forEach(function (k) { R[k] = { ten: P[k].ten, ma: P[k].ma || "", dn: +P[k].dn || 0, th: +P[k].th || 0, kh: +P[k].kh || 0 }; });
    if (chuyen() && B()) {
      var qi = qInfo(bcKey), so = B().load().filter(function (b) { return b.ngay >= qi.start && b.ngay <= bcKey; }).sort(function (a, b) { return a.ngay < b.ngay ? -1 : a.ngay > b.ngay ? 1 : 0; });
      var nhom = {}; so.forEach(function (b) { (nhom[b.ngay] = nhom[b.ngay] || []).push(b); });
      Object.keys(nhom).sort().forEach(function (ng) {
        var goc = {}; Object.keys(R).forEach(function (k) { goc[k] = { dn: R[k].dn, th: R[k].th, kh: R[k].kh }; });   /* cùng ngày: chia đồng thời từ số đầu ngày */
        nhom[ng].forEach(function (b) {
          var c = B().chiaKH(b); if (!c || !c.total || !goc[c.tuKey]) return; var g = goc[c.tuKey], src = R[c.tuKey];
          Object.keys(c.dest).forEach(function (k) {
            var sh = c.dest[k].n / c.total, d = R[k] || (R[k] = { ten: c.dest[k].ten, ma: c.dest[k].ma, dn: 0, th: 0, kh: 0 });
            d.dn += g.dn * sh; d.th += g.th * sh; d.kh += g.kh * sh; src.dn -= g.dn * sh; src.th -= g.th * sh; src.kh -= g.kh * sh;
          });
        });
      });
    }
    return R;
  }
  /* móc vào P3: ghi đè f[rid] = {khQuy, dnQuy} */
  function ap(f, s, a, gr) {
    var bk = fmt(a), qi = qInfo(bk), R = tinh(qi.q, bk); if (!R) return;
    Object.keys(f).forEach(function (k) { delete f[k]; });
    Object.keys(R).forEach(function (k) {
      var e = R[k], rid = s[gr(e.ten)]; if (!rid) return;
      var dn = loai === "th" || loai === "th212" ? e.th : loai === "dn" ? 0 : loai === "nh" ? Math.max(0, e.dn - e.th) : e.dn;
      f[rid] = { khQuy: loai === "" ? Math.round(e.kh) : 0, dnQuy: Math.round(dn) };
    });
  }
  /* "Tên ⇥ Dư nợ (tr) ⇥ Trung+dài (tr) ⇥ KH" dán từ Excel */
  function dan(txt, qk) {
    var o = all(), P = o[qk] || {}, ok = 0, bad = [], nm = B().getCtx() ? B().getCtx().nm : {};
    String(txt || "").split(/\r?\n/).forEach(function (ln) {
      var c = ln.split(/\t|\s{2,}|;/).map(function (x) { return x.trim(); }).filter(Boolean); if (c.length < 2) return;
      var n = c.slice(1).map(function (x) { return +String(x).replace(/\./g, "").replace(/,/g, "."); });
      if (n.some(function (x) { return !isFinite(x); }) || !c[0]) { bad.push(c[0]); return; }
      var ma = nm[norm(c[0])] || "", k = B().keyOf(c[0], ma);
      P[k] = { ten: c[0], ma: ma, dn: n[0] * 1e6, th: (n.length > 2 ? n[1] : n[0]) * 1e6, kh: n.length > 2 ? n[2] : n[1] || 0 }; ok++;
    });
    o[qk] = P; saveAll(o); return { ok: ok, bad: bad };
  }
  /* ---- panel ---- */
  function dong(res, t) {  /* [{ten, bg, plan, dauQuy, bc}] của cán bộ */
    return (res && res.rows || []).filter(function (r) { return r.kind === "cbtd"; }).map(function (r) { return { ten: r.name, bg: !!r.bg, x: r[t] }; });
  }
  function panel(el, o) {
    var bk = o.bcKey, qi = qInfo(bk), P = all()[qi.q] || {}, R = tinh(qi.q, bk), ch = chuyen(), res = o.res;
    var ten = {}; (res && res.rows || []).forEach(function (r) { if (r.kind === "cbtd" && !r.bg) ten[r.name] = 1; }); Object.keys(P).forEach(function (k) { ten[P[k].ten] = 1; });
    var ds = Object.keys(ten).sort(function (a, b) { return a < b ? -1 : 1; });
    var inp = function (k, f, v) { return '<input type="text" inputmode="numeric" data-k="' + esc(k) + '" data-f="' + f + '" value="' + esc(v) + '" data-testid="kh-in-' + f + '">'; };
    var h = '<details class="bg-so kh-so" data-testid="kh-so"' + (moKH ? " open" : "") + '><summary>📊 Kế hoạch quý ' + qi.qn + "/" + qi.nam + " theo cán bộ — " + (R ? '<b data-testid="kh-n">' + Object.keys(P).length + "</b> cán bộ đã nhập" : "chưa nhập (đang dùng kế hoạch năm ÷ 4)") + "</summary>";
    h += '<div class="bg-bar"><label>Chuyển kế hoạch theo sổ bàn giao <select data-testid="kh-chuyen"><option value="1"' + (ch ? " selected" : "") + '>Bật (mặc định)</option><option value="0"' + (ch ? "" : " selected") + '>Tắt</option></select></label>' +
      '<label>Áp mẫu cho mọi cán bộ: dư nợ <input type="text" size="6" value="2000" data-testid="kh-mau-dn"> tr · trung+dài <input type="text" size="6" value="2000" data-testid="kh-mau-th"> tr · KH <input type="text" size="3" value="2" data-testid="kh-mau-kh"> <button type="button" data-a="mau" data-testid="kh-mau-ok">Áp mẫu</button></label></div>';
    h += '<div class="bg-tw"><table class="bg-t" data-testid="kh-bang"><thead><tr><th>Cán bộ</th><th>Dư nợ (tr)</th><th>Trung + dài (tr)</th><th>KH</th><th>Áp dụng: dư nợ (tr)</th><th>Áp dụng: KH</th></tr></thead><tbody>';
    var tong = { dn: 0, th: 0, kh: 0, adn: 0, akh: 0 };
    ds.forEach(function (n) {
      var ma = B().maTen(n), k = B().keyOf(n, ma), e = P[k] || {}, a = R && R[k] ? R[k] : null;
      tong.dn += e.dn || 0; tong.th += e.th || 0; tong.kh += e.kh || 0; tong.adn += a ? a.dn : 0; tong.akh += a ? a.kh : 0;
      h += '<tr data-testid="kh-row" data-ten="' + esc(n) + '"><td>' + esc(n) + (ma ? '<div class="bg-ct">mã ' + esc(ma) + "</div>" : "") + "</td><td>" + inp(n, "dn", e.dn ? tr(e.dn) : "") + "</td><td>" + inp(n, "th", e.th ? tr(e.th) : "") + "</td><td>" + inp(n, "kh", e.kh || "") + '</td><td class="r" data-testid="kh-adn">' + (a ? tr(a.dn) : "") + '</td><td class="r" data-testid="kh-akh">' + (a ? (Math.round(a.kh * 100) / 100).toLocaleString("vi-VN") : "") + "</td></tr>";
    });
    h += '<tr class="kh-tong"><td><b>Tổng chi nhánh</b></td><td class="r" data-testid="kh-t-dn">' + tr(tong.dn) + '</td><td class="r">' + tr(tong.th) + '</td><td class="r" data-testid="kh-t-kh">' + tong.kh + '</td><td class="r" data-testid="kh-t-adn">' + tr(tong.adn) + '</td><td class="r" data-testid="kh-t-akh">' + (Math.round(tong.akh * 100) / 100).toLocaleString("vi-VN") + "</td></tr></tbody></table></div>";
    h += '<div class="bg-h">Dán từ Excel (mỗi dòng: Tên ⇥ Dư nợ tr ⇥ Trung+dài tr ⇥ KH — hoặc Tên ⇥ Dư nợ ⇥ KH):</div><textarea rows="3" data-testid="kh-dan" style="width:100%"></textarea><button type="button" data-a="dan" data-testid="kh-dan-ok">⬇ Nạp kế hoạch đã dán</button> <button type="button" data-a="xoa" data-testid="kh-xoa">🗑 Xoá kế hoạch quý này</button> <span data-testid="kh-msg"></span>';
    /* thực hiện + dự báo */
    h += '<div class="bg-h">📈 Thực hiện kế hoạch quý và dự báo đến ' + qi.end.split("-").reverse().join("/") + " (đã " + qi.done + "/" + qi.days + ' ngày) — tốc độ bình quân; số cán bộ đã tính lại theo sổ bàn giao:</div><div class="bg-tw"><table class="bg-t" data-testid="kh-thuchien"><thead><tr><th>Cán bộ</th><th>KH quý</th><th>Thực hiện KH</th><th>%</th><th>Dự báo KH</th><th>Dư nợ KH quý (tr)</th><th>Thực hiện (tr)</th><th>%</th><th>Dự báo cuối quý (tr)</th><th>Còn thiếu (tr)</th></tr></thead><tbody>';
    var dk = dong(res, "kh"), dd = dong(res, "dn"), pct = function (a, b) { return b > 0 ? Math.round(a / b * 1000) / 10 : null; };
    dk.forEach(function (r, i) {
      var x = r.x, y = dd[i].x, thk = x.bc - x.dauQuy, thd = y.bc - y.dauQuy, fk = x.dauQuy + thk * qi.days / qi.done, fd = y.dauQuy + thd * qi.days / qi.done;
      if (!x.plan && !y.plan && !thk && !thd) return;
      h += '<tr data-testid="kh-th-row" data-ten="' + esc(r.ten) + '"><td>' + esc(r.ten) + '</td><td class="r">' + nghin(x.plan) + '</td><td class="r">' + nghin(thk) + '</td><td class="r">' + (pct(thk, x.plan) == null ? "–" : pct(thk, x.plan) + "%") + '</td><td class="r">' + nghin(fk) + '</td><td class="r">' + tr(y.plan) + '</td><td class="r">' + tr(thd) + '</td><td class="r">' + (pct(thd, y.plan) == null ? "–" : pct(thd, y.plan) + "%") + '</td><td class="r">' + tr(fd) + '</td><td class="r">' + tr(Math.max(0, y.plan - thd)) + "</td></tr>";
    });
    h += "</tbody></table></div></details>";
    /* xuất 4 bảng + đối soát */
    h += '<details class="bg-so kh-ds" data-testid="ds-so"' + (moDS ? " open" : "") + '><summary>🧾 Xuất mẫu 4 bảng · Đối soát với báo cáo tay</summary><div class="bg-bar"><button type="button" data-a="xuat4" data-testid="kh-xuat4">⬇ Xuất Excel đúng mẫu 4 bảng (dư nợ: triệu đồng)</button></div>' +
      '<div class="bg-h">Đối soát: chọn bảng, dán số báo cáo tay (mỗi dòng: Tên ⇥ Đầu năm ⇥ Đầu quý ⇥ Đầu tháng ⇥ Ngày BC; dư nợ tính bằng triệu đồng):</div><div class="bg-bar"><select data-testid="ds-bang"><option value="kh">Khách hàng</option><option value="dn">Dư nợ hàng ngày</option><option value="dnn">Dư nợ doanh nghiệp</option><option value="th">Dư nợ trung + dài hạn</option></select></div><textarea rows="4" data-testid="ds-dan" style="width:100%"></textarea><button type="button" data-a="doisoat" data-testid="ds-ok">🧾 Đối soát</button><div data-testid="ds-kq"></div></details>';
    el.innerHTML = h;
    el.querySelector("[data-testid=kh-chuyen]").onchange = function (ev) { try { localStorage.setItem(KC, ev.target.value); } catch (e) { } moKH = true; o.onChange && o.onChange(); };
    el.querySelector("details.kh-so").ontoggle = function (ev) { if (ev.target === ev.currentTarget) moKH = ev.target.open; };
    el.querySelector("details.kh-ds").ontoggle = function (ev) { if (ev.target === ev.currentTarget) moDS = ev.target.open; };
    el.onchange = function (ev) {
      var t = ev.target; if (!t || !t.getAttribute || !t.getAttribute("data-f")) return;
      var n = t.getAttribute("data-k"), f = t.getAttribute("data-f"), ma = B().maTen(n), k = B().keyOf(n, ma), a = all(), Q = a[qi.q] = a[qi.q] || {}, e = Q[k] = Q[k] || { ten: n, ma: ma, dn: 0, th: 0, kh: 0 };
      var v = +String(t.value).replace(/\./g, "").replace(/,/g, ".") || 0; e[f] = f === "kh" ? v : v * 1e6; saveAll(a); moKH = true; o.onChange && o.onChange();
    };
    el.onclick = function (ev) {
      var t = ev.target.closest ? ev.target.closest("button[data-a]") : null; if (!t) return; var a = t.getAttribute("data-a");
      var q = function (s) { return el.querySelector("[data-testid=" + s + "]"); };
      if (a === "mau") {
        var o2 = all(), Q = o2[qi.q] = o2[qi.q] || {}, dn = +String(q("kh-mau-dn").value).replace(/\./g, "") || 0, th = +String(q("kh-mau-th").value).replace(/\./g, "") || 0, kh = +q("kh-mau-kh").value || 0;
        ds.forEach(function (n) { var ma = B().maTen(n), k = B().keyOf(n, ma); Q[k] = { ten: n, ma: ma, dn: dn * 1e6, th: th * 1e6, kh: kh }; }); saveAll(o2); moKH = true; o.onChange && o.onChange();
      } else if (a === "dan") { var r = dan(q("kh-dan").value, qi.q); q("kh-msg").textContent = "Đã nạp " + r.ok + " dòng" + (r.bad.length ? "; bỏ qua: " + r.bad.join(", ") : ""); moKH = true; o.onChange && o.onChange(); }
      else if (a === "xoa") { var a2 = all(); delete a2[qi.q]; saveAll(a2); moKH = true; o.onChange && o.onChange(); }
      else if (a === "xuat4") xuat4(o, qi);
      else if (a === "doisoat") doisoat(el, o, q("ds-bang").value, q("ds-dan").value);
    };
  }
  /* ---- 4 bảng đúng mẫu ---- */
  var TIEUDE = { kh: "BÁO CÁO KHÁCH HÀNG ĐẾN NGÀY ", dn: "BÁO CÁO DƯ NỢ HÀNG NGÀY ĐẾN NGÀY ", dnn: "BÁO CÁO DƯ NỢ DOANH NGHIỆP ĐẾN NGÀY ", th: "BÁO CÁO DƯ NỢ TRUNG + DÀI HẠN ĐẾN NGÀY " };
  var CODE = { kh: "", dn: "", dnn: "dn", th: "th" };
  function cells(r, t, dv) {
    var x = r[t], d = function (v) { return dv ? Math.round(v / dv) : Math.round(v); };
    return [d(x.dauNam), d(x.dauQuy), d(x.dauThang), d(x.bc), d(x.bc - x.dauThang), d(x.bc - x.dauQuy), d(x.bc - x.dauNam), d(x.bc - x.dauQuy - x.plan), d(x.plan), d(x.bgQ || 0), d(x.bgN || 0)];
  }
  function bang4(o, kind) {
    var res = o.calc(CODE[kind]), t = kind === "kh" ? "kh" : "dn", dv = kind === "kh" ? 0 : 1e6;
    return { kind: kind, res: res, rows: (res.rows || []).map(function (r) { return { kind: r.kind, name: r.name, cells: cells(r, t, dv) }; }) };
  }
  var HDR = ["CBTD", "Đầu năm", "Đầu quý", "Đầu tháng", "Ngày BC", "+/- đầu tháng", "+/- đầu quý", "+/- đầu năm", "+/- KH quý", "Kế hoạch", "Bàn giao đầu quý", "Bàn giao đầu năm"];
  function xuat4(o, qi) {
    if (!o.xlsx || !o.calc) return; var dd = o.bcKey.split("-").reverse().join("/");
    var S = ["kh", "dn", "dnn", "th"].map(function (k) {
      var b = bang4(o, k), h = HDR.slice(); if (k !== "kh") h[8] = "+/- kế hoạch";
      var rows = b.rows.map(function (r) { return [r.name].concat(r.cells.map(function (v) { return v; })); });
      return { name: { kh: "Khách hàng", dn: "Dư nợ hàng ngày", dnn: "Dư nợ doanh nghiệp", th: "Dư nợ trung + dài hạn" }[k], title: TIEUDE[k] + dd, headers: h, widths: [24, 13, 13, 13, 13, 13, 13, 13, 13, 12, 13, 13], rows: rows, boldRows: b.rows.map(function (r, i) { return r.kind === "cbtd" ? -1 : i; }).filter(function (i) { return i >= 0; }) };
    });
    o.xlsx(S, "BaoCao4Bang_" + o.bcKey + ".xlsx");
  }
  /* ---- đối soát với báo cáo tay ---- */
  function doisoat(el, o, kind, txt) {
    var b = bang4(o, kind), mp = {}; b.rows.forEach(function (r) { if (r.kind === "cbtd") mp[norm(r.name)] = r; else if (r.kind === "tong" || r.kind === "phong") mp["#" + norm(r.name)] = r; });
    var kq = [], ok = 0, tot = 0, lab = ["Đầu năm", "Đầu quý", "Đầu tháng", "Ngày BC"];
    String(txt || "").split(/\r?\n/).forEach(function (ln) {
      var c = ln.split(/\t|\s{2,}|;/).map(function (x) { return x.trim(); }).filter(Boolean); if (c.length < 2) return;
      var r = mp[norm(c[0])] || mp["#" + norm(c[0])];
      if (!r) { kq.push({ ten: c[0], loi: "tên không có trong báo cáo của app" }); return; }
      for (var i = 0; i < 4 && i + 1 < c.length; i++) {
        var v = c[i + 1]; if (v === "-" || v === "—" || v === "") v = "0"; var n = +String(v).replace(/\./g, "").replace(/,/g, "."); if (!isFinite(n)) continue;
        tot++; var a = r.cells[i], d = a - n;
        if (Math.abs(d) <= (kind === "kh" ? 0 : 1)) { ok++; continue; }
        var bg = i === 0 ? r.cells[10] : i === 1 || i === 2 ? r.cells[9] : 0, nh = "";
        if (r.kind === "cbtd" && bg && Math.abs(d - bg) <= (kind === "kh" ? 0 : 1)) nh = "đúng bằng cột Bàn giao — báo cáo tay chưa tính lại theo bàn giao";
        else if (r.kind === "cbtd" && bg) nh = "cán bộ có bàn giao (" + bg + ") — kiểm tra phạm vi bàn giao";
        else nh = "chênh " + d + (kind === "kh" ? "" : " tr") + " — kiểm tra số liệu / phạm vi";
        kq.push({ ten: c[0], cot: lab[i], tay: n, app: a, d: d, nh: nh });
      }
    });
    var h = '<div class="bg-kiem ' + (kq.length ? "bad" : "ok") + '" data-testid="ds-tong">Khớp ' + ok + "/" + tot + " ô" + (kq.length ? " — " + kq.length + " ô lệch" : "") + "</div>";
    if (kq.length) h += '<div class="bg-tw"><table class="bg-t" data-testid="ds-bang-kq"><thead><tr><th>Cán bộ</th><th>Cột</th><th>Báo cáo tay</th><th>App</th><th>Lệch</th><th>Nguyên nhân gợi ý</th></tr></thead><tbody>' + kq.map(function (x) { return x.loi ? '<tr><td>' + esc(x.ten) + '</td><td colspan="5">' + esc(x.loi) + "</td></tr>" : '<tr data-testid="ds-row"><td>' + esc(x.ten) + "</td><td>" + x.cot + '</td><td class="r">' + nghin(x.tay) + '</td><td class="r">' + nghin(x.app) + '</td><td class="r">' + nghin(x.d) + "</td><td>" + esc(x.nh) + "</td></tr>"; }).join("") + "</tbody></table></div>";
    el.querySelector("[data-testid=ds-kq]").innerHTML = h; moDS = true;
  }
  window.QLTDKH = { KP: KP, KC: KC, qInfo: qInfo, tinh: tinh, ap: ap, dan: dan, panel: panel, setLoai: function (c) { loai = c || ""; }, all: all, bang4: bang4, doisoat: doisoat };
})();
