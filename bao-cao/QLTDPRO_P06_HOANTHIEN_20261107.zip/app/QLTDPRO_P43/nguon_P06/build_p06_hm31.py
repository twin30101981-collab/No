# P06 · HM-31 GĐ1 · v24.17.35 — Bàn giao cán bộ tín dụng, giai đoạn 1 (đối soát 4 bảng in 31/10/2026).
#  N4: Báo cáo ngày chọn mốc Đầu tháng/Đầu quý/Đầu năm theo NGÀY DỮ LIỆU (ô "Dữ liệu ngày"), không theo ngày máy; tab Trả nợ cũng vậy
#      (+ D-1 so theo ngày dữ liệu của mốc thay vì giờ nhập).
#  N5: "+/- KH quý" / "+/- kế hoạch" = (Ngày BC − Đầu quý) − KH quý (người dùng chốt 07/11; khớp bảng in KHÁCH HÀNG 31/10).
#  N2: cán bộ không còn trong danh mục (đã bàn giao hết) vẫn được cộng vào TỔNG — nhóm riêng "CÁN BỘ ĐÃ BÀN GIAO / NGOÀI DANH MỤC" trước TỔNG.
#  N3: bỏ khớp tên gần đúng (tên khác danh mục → nhóm trên + cảnh báo, không gộp nhầm vào người khác).
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P06/build_p06_hm31.py
import hashlib
SRC = 'app/QLTDPRO_v24.17.34.html'; DST = 'app/QLTDPRO_v24.17.35.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:90]); s = s.replace(old, new)
rep('<script id="gd7-js">', '<script id="gd27-js">\n' + open('nguon_P06/gd27.js', encoding='utf-8').read() + '\n</script>\n<script id="gd7-js">')
# N3 + N2: Qv không khớp gần đúng; P3 (cờ x) thêm cán bộ ngoài danh mục vào nhóm __bg
rep('function Qv(e,t){const n={},r=[];', 'function Qv(e,t,__x){const n={},r=[];')
rep('a[l]=1;const c=e.match(s[12]);c&&n[gr(c.name)]&&(n[l]=n[gr(c.name)])}return{map:n,members:r}}',
    'a[l]=1;if(__x){const c="x_"+r.length;n[l]=c,r.push({rid:c,name:String(s[12]).trim(),pk:"__bg"})}}return{map:n,members:r}}')
rep('{map:s,members:l}=Qv(n,[e].concat(t.map(w=>w.rows)))', '{map:s,members:l}=Qv(n,[e].concat(t.map(w=>w.rows)),1)')
rep('fn.forEach(w=>{const x=yo(),S=yo();l.filter(N=>N.pk===w.key).forEach(N=>{',
    'const __bg=[];fn.concat([{key:"__bg",label:window.QLTDBC31?window.QLTDBC31.NHOM:"CÁN BỘ ĐÃ BÀN GIAO / NGOÀI DANH MỤC"}]).forEach(w=>{const x=yo(),S=yo();let __c=0;l.filter(N=>N.pk===w.key).forEach(N=>{')
rep(';m.push({kind:"cbtd",name:N.name,kh:j,dn:k}),To(x,j),To(S,k)}),m.push({kind:"phong",name:w.label,kh:x,dn:S}),To(y,x),To(v,S)}),',
    ';if(w.key==="__bg"&&!(j.dauNam||j.dauQuy||j.dauThang||j.bc||k.dauNam||k.dauQuy||k.dauThang||k.bc))return;w.key==="__bg"&&__bg.push(N.name),__c++,m.push({kind:"cbtd",name:N.name,kh:j,dn:k,bg:w.key==="__bg"}),To(x,j),To(S,k)}),(w.key!=="__bg"||__c)&&(m.push({kind:"phong",name:w.label,kh:x,dn:S,bg:w.key==="__bg"}),To(y,x),To(v,S))}),')
rep('warn:b.length?`⚠ Chưa có snapshot mốc: ${b.join(", ")} — các cột tương ứng sẽ trống.`:""}}',
    'warn:(b.length?`⚠ Chưa có snapshot mốc: ${b.join(", ")} — các cột tương ứng sẽ trống.`:"")+(__bg.length?(b.length?" · ":"")+`ℹ ${__bg.length} cán bộ không có trong danh mục (đã bàn giao hoặc tên khác danh mục): ${__bg.join(", ")} — vẫn cộng vào TỔNG, ở nhóm riêng.`:"")}}')
# N5
rep('I3=e=>[e.dauNam,e.dauQuy,e.dauThang,e.bc,e.bc-e.dauThang,e.bc-e.dauQuy,e.bc-e.dauNam,e.bc-e.plan,e.plan]',
    'I3=e=>[e.dauNam,e.dauQuy,e.dauThang,e.bc,e.bc-e.dauThang,e.bc-e.dauQuy,e.bc-e.dauNam,e.bc-e.dauQuy-e.plan,e.plan]')
# N4 Báo cáo ngày
rep('s=D.useMemo(()=>new Date,[]),l=D.useMemo(()=>P3(e,t,n,r,s),[e,t,n,r,s]),c=((window.__qltdView?window.__qltdView.dd:i6("_currentFileDate"))||"").trim()||ip(s)',
    '__dd=((window.__qltdView?window.__qltdView.dd:i6("_currentFileDate"))||"").trim(),s=D.useMemo(()=>window.QLTDBC31?window.QLTDBC31.ngay(__dd):new Date,[__dd]),l=D.useMemo(()=>P3(e,t,n,r,s),[e,t,n,r,s]),c=__dd||ip(s)')
# dòng nhóm bàn giao: nền xám
rep('style:p.kind==="phong"?{background:"#eff6ff",fontWeight:700,color:"#1e3a8a"}', '"data-bg":p.bg?"1":void 0,style:p.kind==="phong"&&p.bg?{background:"#f3f4f6",fontWeight:700,color:"#374151"}:p.kind==="phong"?{background:"#eff6ff",fontWeight:700,color:"#1e3a8a"}')
rep('h=p=>l.rows.map(m=>({kind:m.kind,name:m.name,cells:', 'h=p=>l.rows.map(m=>({kind:m.kind,name:m.name,bg:m.bg,cells:')
# N4 Trả nợ
rep('u=D.useMemo(()=>r?v3(t,r,h,d,new Date,i):null,[t,r,h,d,i])', 'u=D.useMemo(()=>r?v3(t,r,h,d,window.QLTDBC31?window.QLTDBC31.ngay(d):new Date,i):null,[t,r,h,d,i])')
rep('D1:t.filter(B=>B.ts&&bc(new Date(B.ts))<b).sort((B,O)=>O.ts-B.ts)[0]||null',
    'D1:t.filter(B=>(Ud(B)||(B.ts?bc(new Date(B.ts)):""))&&(Ud(B)||bc(new Date(B.ts)))<b).sort((B,O)=>(Ud(O)||"").localeCompare(Ud(B)||"")||(O.ts||0)-(B.ts||0))[0]||null')
rep('u=a.getFullYear()-1,g=Dn(t,"year_end",u),f=!!g', 'u=a.getFullYear()-1,__m=E3(t,a),g=H3(t,__m.EoY1)||Dn(t,"year_end",u),f=!!g')
rep('EoM1:Dn(t,"month",T.getFullYear(),T.getMonth()+1),EoQ1:x===4?Dn(t,"year_end",S):Dn(t,"quarter",S,x),EoY1:Dn(t,"year_end",u)}',
    'EoM1:H3(t,__m.EoM1)||Dn(t,"month",T.getFullYear(),T.getMonth()+1),EoQ1:H3(t,__m.EoQ1)||(x===4?Dn(t,"year_end",S):Dn(t,"quarter",S,x)),EoY1:g}')
rep('O&&(F[B]=O.ts?bc(new Date(O.ts)):O.date||"",', 'O&&(F[B]=Ud(O)||(O.ts?bc(new Date(O.ts)):O.date||""),')
rep('{snapAvail:f,snapName:g?g.name:"",mocDate:F,mocDup:A,giam:R,het:K}}', '(()=>{try{window.__qltdTraNoMoc=F}catch{}})(),{snapAvail:f,snapName:g?g.name:"",mocDate:F,mocDup:A,giam:R,het:K}}')
c = s.count('"24.17.34"'); assert c == 2, c
s = s.replace('"24.17.34"', '"24.17.35"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.34' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.34', '24.17.35'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
