# P06 · v24.17.43 — từ v24.17.42 (người dùng 07/11, tối ưu PC/laptop, không mobile):
#  (1) cột tiền (Dư nợ; HMTD ở Chuyển hạn mức; Dư nợ đầu năm/hiện tại/Giảm ở Trả nợ) xếp sớm để luôn nằm trong màn hình đầu tiên
#      (trừ Tổng quan, Chỉ tiêu KH); bố cục đã lưu của người dùng được đổi thứ tự cột MỘT lần (giữ độ rộng, lọc, cột ẩn);
#  (2) ma trận Loại vay × Nhóm nợ: ô đậm nhất không còn trùng màu thanh tiêu đề;
#  (3) trang Xu hướng kỳ: kỳ mới nhất lên đầu bảng;
#  (4) trang Tài sản bảo đảm khi chưa có sao kê: nói rõ msit80 không chứa TSBĐ, cần nhập tệp sao kê riêng.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P06/build_p06_hm32.py   (cần v24.17.42)
import hashlib
SRC = 'app/QLTDPRO_v24.17.42.html'; DST = 'app/QLTDPRO_v24.17.43.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:100]); s = s.replace(old, new)
rep("var defs = {};\nvar handoff = null;", """/* v24.17.43: cột tiền xếp sớm (nằm trong màn hình đầu tiên của PC/laptop) */
var MONEY = {
  'tat-ca-du-no':{ids:['duno'],at:6}, 'ngan-han-thau-chi':{ids:['duno'],at:6}, 'thau-chi':{ids:['duno'],at:6}, 'cho-vay-doanh-nghiep':{ids:['duno'],at:6}, 'trung-dai-han':{ids:['duno'],at:6},
  'no-den-han':{ids:['duno'],at:6}, 'lai-dong':{ids:['duno'],at:6}, 'chuyen-han-muc':{ids:['hmtd','duno'],at:4}, 'du-no-cam-co':{ids:['duno'],at:6},
  'tranop-giam':{ids:['boy','ht','giam'],at:2}, 'tranop-het':{ids:['boy'],at:3}
};
var defs = {};
var handoff = null;""")
rep("    def.order = lead.concat(ids.filter(function(x){ return lead.indexOf(x) < 0; }));",
    """    def.order = lead.concat(ids.filter(function(x){ return lead.indexOf(x) < 0; }));
    var mo = MONEY[id];
    if (mo){ var ord = def.order.filter(function(x){ return mo.ids.indexOf(x) < 0; }), add = mo.ids.filter(has); ord.splice.apply(ord, [Math.min(mo.at, ord.length), 0].concat(add)); def.order = ord; }""")
rep("  def.l21 = 1;\n  defs[id] = def;", "  def.l21 = 1; def.l31 = 1;\n  defs[id] = def;")
rep("/* HM-21b: sort mới áp một lần, giữ cột/độ rộng/lọc */", "if (ok && !ok.l31 && defs[id] && MONEY[id]){ var o3 = {}; for (var k3 in ok) o3[k3] = ok[k3]; o3.order = (defs[id].order || []).slice(); o3.l31 = 1; ok = o3; } /* v24.17.43: thứ tự cột tiền mới áp một lần, giữ độ rộng/lọc/cột ẩn */ /* HM-21b: sort mới áp một lần, giữ cột/độ rộng/lọc */")
rep("0.12 + a * 0.88 > 0.55 ? 'color:#fff !important;'", "0.12 + a * 0.5 > 0.4 ? 'color:#fff !important;'")
rep("0.12 + a * 0.88)", "0.12 + a * 0.5)")
rep('c.labels.map((u,g)=>o.jsxs("tr",{className:"border-t",children:[o.jsx("td",{className:"px-3 py-1.5",children:u})', 'c.labels.map((u,g)=>g).reverse().map(g=>{const u=c.labels[g];return o.jsxs("tr",{className:"border-t",children:[o.jsx("td",{className:"px-3 py-1.5",children:u})')
rep('+")":"—"})]},u))})]})})]}):o.jsxs("div",{className:"max-w-xl rounded-lg border bg-card p-4 text-sm text-muted-foreground"', '+")":"—"})]},u)})})]})})]}):o.jsxs("div",{className:"max-w-xl rounded-lg border bg-card p-4 text-sm text-muted-foreground"')
rep('"Chưa có sao kê tài sản bảo đảm. Nhập tệp TS.XLS xuất từ IPCAS (cột clcustno/plgcustno…)."', '"Chưa có sao kê tài sản bảo đảm. Tệp msit80 (dư nợ) KHÔNG chứa tài sản bảo đảm — cần nhập riêng tệp sao kê TSBĐ từ IPCAS (tên dạng “Sao ke tai san bao dam dd.mm.yyyy.XLS”, cột clcustno/plgcustno…) ở Trung tâm nhập dữ liệu; kéo thả cùng lúc với msit80 được."')
c = s.count('"24.17.42"'); assert c == 2, c
s = s.replace('"24.17.42"', '"24.17.43"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.42' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.42', '24.17.43'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
