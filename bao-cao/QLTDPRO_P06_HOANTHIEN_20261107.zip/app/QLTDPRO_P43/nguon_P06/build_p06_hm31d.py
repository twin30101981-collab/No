# P06 · HM-31 GĐ3 · v24.17.39 — từ v24.17.38.
#  (1) kế hoạch QUÝ theo cán bộ (nhập / dán Excel / áp mẫu), lưu theo MÃ cán bộ; chưa nhập ⇒ giữ kế hoạch năm ÷ 4;
#  (2) chuyển kế hoạch theo sổ bàn giao (tỷ lệ số KH chuyển; bật/tắt), tổng kế hoạch chi nhánh không đổi;
#  (3) % thực hiện + dự báo cuối quý (tốc độ bình quân) cho dư nợ và số KH;
#  (4) xuất Excel đúng mẫu 4 bảng (Khách hàng · Dư nợ hàng ngày · Doanh nghiệp · Trung + dài hạn; dư nợ triệu đồng);
#  (5) đối soát với báo cáo tay: dán số, app chỉ ô lệch + nguyên nhân gợi ý (bàn giao / tên / chênh).
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P06/build_p06_hm31d.py   (cần v24.17.38)
import hashlib
SRC = 'app/QLTDPRO_v24.17.38.html'; DST = 'app/QLTDPRO_v24.17.39.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:100]); s = s.replace(old, new)
a = s.index('<style id="gd28-css">'); b = s.index('</style>', a) + len('</style>\n')
s = s[:a] + '<style id="gd28-css">\n' + open('nguon_P06/gd28.css', encoding='utf-8').read() + '</style>\n' + s[b:]
a = s.index('<script id="gd28-js">'); b = s.index('</script>', a) + len('</script>\n')
s = s[:a] + '<script id="gd28-js">\n' + open('nguon_P06/gd28_v39.js', encoding='utf-8').read() + '\n</script>\n<script id="gd29-js">\n' + open('nguon_P06/gd29.js', encoding='utf-8').read() + '\n</script>\n' + s[b:]
rep('const p={kh:0,dn:0},m=[],y=yo(),v=yo();', 'window.QLTDKH&&window.QLTDKH.ap(f,s,a,gr);const p={kh:0,dn:0},m=[],y=yo(),v=yo();')
rep('window.QLTDBG.ctx({snaps:__S,rows:e0,bcKey:bc(s)});const __a=P3(e,t,n,r,s)', 'window.QLTDBG.ctx({snaps:__S,rows:e0,bcKey:bc(s)});window.QLTDKH&&window.QLTDKH.setLoai(__loc);const __a=P3(e,t,n,r,s)')
rep('onChange:()=>__sv(__x=>__x+1)})}})',
    'onChange:()=>__sv(__x=>__x+1)})}}),o.jsx("div",{className:"no-print","data-testid":"kh-host",ref:__el=>{__el&&window.QLTDKH&&window.QLTDKH.panel(__el,{bcKey:bc(s),res:l,xlsx:(__sh,__fn)=>St(new Blob([Qd(__sh)],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),__fn),onChange:()=>__sv(__x=>__x+1),calc:__c=>{const __F=window.QLTDBG.loc(__c,b3),__e=__F(e0),__t=t0.map(__x=>__x&&Array.isArray(__x.rows)?{...__x,rows:__F(__x.rows)}:__x);window.QLTDBG.ctx({snaps:__S,rows:e0,bcKey:bc(s)});window.QLTDKH.setLoai(__c);try{const __a=P3(__e,__t,n,r,s),__b=window.QLTDBG.raw(()=>P3(__e,__t,n,r,s));return window.QLTDBG.gopBG(__a,__b)}finally{window.QLTDKH.setLoai(__loc)}}})}})')
c = s.count('"24.17.38"'); assert c == 2, c
s = s.replace('"24.17.38"', '"24.17.39"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.38' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.38', '24.17.39'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
