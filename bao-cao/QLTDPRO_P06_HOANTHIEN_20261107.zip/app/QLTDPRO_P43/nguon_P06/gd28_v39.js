/* gd28 · HM-31 GĐ2 (v24.17.36 → .38): Sổ bàn giao cán bộ + phạm vi Báo cáo ngày + mã cán bộ + cột Bàn giao.
   Quy tắc (người dùng chốt 07/11/2026):
   - Nguyên danh mục A → B: mọi số liệu mốc TRƯỚC ngày hiệu lực của A tính cho B.
   - Chia danh mục A → nhiều người: theo từng KH, mọi mốc — KH còn ở ngày hiệu lực → cán bộ đang quản lý KH đó;
     KH đã tất toán → người nhận chính.
   - Sổ: app gợi ý (so 2 mốc liền nhau), người dùng xác nhận; lưu localStorage "td_ban_giao_v1" (xuất/nhập JSON, xuất Excel).
   - Định danh cán bộ bằng MÃ (cột ofcno của msit80 → dòng r[32]); dòng cũ chưa có mã được tra mã theo tên từ các dòng có mã. Không khớp tên gần đúng.
   - Phạm vi của một dòng sổ: toàn bộ danh mục, hoặc danh sách mã KH (brcd, r[0]) / mã khế ước (dsbsseq, r[20]). */
(function () {
  var KEY = "td_ban_giao_v1", BO = "td_ban_giao_bo_v1", CD = "td_bcn_cd";
  var ctx = null, moSo = false, raw = false, cache = typeof WeakMap === "function" ? new WeakMap() : null;
  function norm(s) {
    return String(s == null ? "" : s).trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "")
      .replace(/đ/g, "d").replace(/\./g, " ").replace(/\s+/g, " ").trim();
  }
  function rd(k) { try { var v = JSON.parse(localStorage.getItem(k) || "[]"); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function wr(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function hopLe(b) { return b && b.ngay && b.tu && b.den && (b.kieu === "nguyen" || b.kieu === "chia"); }
  function load() { return rd(KEY).filter(hopLe); }
  function save(l) { return wr(KEY, l); }
  function id(b) { return b.ngay + "|" + (b.tuMa || norm(b.tu)); }
  function mode() { try { return localStorage.getItem(CD) === "cu" ? "cu" : "moi"; } catch (e) { return "moi"; } }
  function ds(t) { return String(t == null ? "" : t).split(/[\s,;]+/).filter(Boolean); }
  /* ---- mã cán bộ ---- */
  function mkNm(sets) {
    var nm = {};
    sets.forEach(function (rows) { (rows || []).forEach(function (r) { if (r && r[32] != null && String(r[32]).trim() && r[12]) nm[norm(r[12])] = String(r[32]).trim(); }); });
    return nm;
  }
  function maOf(r, nm) { var m = r && r[32] != null ? String(r[32]).trim() : ""; return m || (nm && nm[norm(r && r[12])]) || ""; }
  function ckey(r, nm) { var m = maOf(r, nm); return m ? "M" + m : "N" + norm(r && r[12]); }
  function mkCtx(snaps, rows, bcKey) { return { snaps: snaps || [], rows: rows || [], bcKey: bcKey, nm: mkNm([rows].concat((snaps || []).map(function (s) { return s.rows; }))) }; }
  function keyDD(dd) {
    var t = String(dd || "").trim(), m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})/.exec(t);
    if (m) return m[3] + "-" + ("0" + m[2]).slice(-2) + "-" + ("0" + m[1]).slice(-2);
    m = /^(\d{4})-(\d{2})-(\d{2})/.exec(t); if (m) return m[0];
    var d = new Date(); return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
  }
  /* KH → {ten, ma} (dòng dư nợ > 0 có số dư lớn nhất) */
  function cbKH(rows, nm) {
    var m = {}, best = {};
    (rows || []).forEach(function (r) {
      if (!r) return; var k = String(r[0] == null ? "" : r[0]).trim(), cb = String(r[12] == null ? "" : r[12]).trim(), b = Number(r[11]) || 0;
      if (!k || !cb || !(b > 0)) return;
      if (best[k] == null || b > best[k]) { best[k] = b; m[k] = { ten: cb, ma: maOf(r, nm), key: ckey(r, nm) }; }
    });
    return m;
  }
  function goiYCap(truoc, sau, ngay, nm) {
    var x = cbKH(truoc, nm), y = cbKH(sau, nm), co = {}, mv = {}, ten = {};
    Object.keys(x).forEach(function (k) { var a = x[k].key; co[a] = (co[a] || 0) + 1; ten[a] = x[k]; });
    Object.keys(x).forEach(function (k) {
      if (!(k in y)) return; var a = x[k].key, b = y[k].key; if (a === b) return;
      ten[b] = y[k]; (mv[a] = mv[a] || {})[b] = (mv[a][b] || 0) + 1;
    });
    var out = [];
    Object.keys(mv).forEach(function (a) {
      var d = mv[a], ks = Object.keys(d).sort(function (p, q) { return d[q] - d[p] || (p < q ? -1 : 1); }), m = 0;
      ks.forEach(function (k) { m += d[k]; });
      if (m < 5 || m < 0.5 * (co[a] || 0)) return;
      out.push({ ngay: ngay, tu: ten[a].ten, tuMa: ten[a].ma || "", den: ten[ks[0]].ten, denMa: ten[ks[0]].ma || "", kieu: d[ks[0]] >= 0.9 * m ? "nguyen" : "chia", so: m,
        chiTiet: ks.slice(0, 6).map(function (k) { return ten[k].ten + " " + d[k]; }).join(", ") });
    });
    return out.sort(function (p, q) { return q.so - p.so; });
  }
  function moc() {
    if (!ctx) return [];
    var l = (ctx.snaps || []).filter(function (s) { return s.key && s.key < ctx.bcKey; }).sort(function (a, b) { return a.key < b.key ? -1 : 1; });
    return l.concat([{ key: ctx.bcKey, rows: ctx.rows }]);
  }
  function getRowsC(c, k) {
    if (k >= c.bcKey) return c.rows;
    var cand = (c.snaps || []).filter(function (x) { return x.key >= k; }).sort(function (a, b) { return a.key < b.key ? -1 : 1; })[0];
    return cand ? cand.rows : c.rows;
  }
  function goiY() {
    var m = moc(), out = [], co = {}, bo = {}; if (!ctx) return out;
    load().forEach(function (b) { co[id(b)] = 1; }); rd(BO).forEach(function (k) { bo[k] = 1; });
    for (var i = 1; i < m.length; i++) goiYCap(m[i - 1].rows, m[i].rows, m[i].key, ctx.nm).forEach(function (b) { if (!co[id(b)] && !bo[id(b)]) out.push(b); });
    return out;
  }
  /* ---- áp sổ bàn giao lên dòng của một mốc ---- */
  function apDung(rows, mocKey, c) {
    c = c || ctx;
    if (raw || !c || !rows || !mocKey || mode() === "cu") return rows;
    var so = load().filter(function (b) { return b.ngay > mocKey && b.ngay <= c.bcKey; });
    if (!so.length) return rows;
    var sig = mocKey + "|" + c.bcKey + "|" + c.rows.length + "|" + JSON.stringify(so);
    if (cache) { var h = cache.get(rows); if (h && h.sig === sig) return h.out; }
    var dot = {}; so.forEach(function (b) { (dot[b.ngay] = dot[b.ngay] || []).push(b); });
    var out = rows;
    Object.keys(dot).sort().forEach(function (ng) {
      var mp = {}, cur = null, nm = c.nm;
      dot[ng].forEach(function (b) {
        b.__kh = {}; b.__ks = {}; (b.kh || []).forEach(function (k) { b.__kh[String(k).trim()] = 1; }); (b.ks || []).forEach(function (k) { b.__ks[String(k).trim()] = 1; });
        (mp[b.tuMa ? "M" + b.tuMa : "N" + norm(b.tu)] = mp[b.tuMa ? "M" + b.tuMa : "N" + norm(b.tu)] || []).push(b);
      });
      out = out.map(function (r) {
        if (!r) return r; var bs = mp[ckey(r, nm)] || mp["N" + norm(r[12])]; if (!bs) return r;
        for (var i = 0; i < bs.length; i++) {
          var b = bs[i], hk = (b.kh || []).length, hs = (b.ks || []).length;
          if (hk || hs) { if (!((hk && b.__kh[String(r[0] == null ? "" : r[0]).trim()]) || (hs && b.__ks[String(r[20] == null ? "" : r[20]).trim()]))) continue; }
          var den = { ten: b.den, ma: b.denMa || "" };
          if (b.kieu === "chia") { if (!cur) cur = cbKH(getRowsC(c, ng), nm); var u = cur[String(r[0] == null ? "" : r[0]).trim()]; if (u) den = u; }
          var x = r.slice(); x[12] = den.ten; if (den.ma) x[32] = den.ma; return x;
        }
        return r;
      });
    });
    if (cache) cache.set(rows, { sig: sig, out: out });
    return out;
  }
  function apDungSnaps(t, cur, bcKey, UdFn) {
    if (raw || mode() === "cu" || !load().length) return t;
    var sn = (t || []).filter(function (x) { return x && Array.isArray(x.rows) && x.rows.length; }).map(function (x) { return { key: UdFn(x), rows: x.rows }; }).filter(function (x) { return x.key; });
    var c = mkCtx(sn, cur, bcKey);
    return (t || []).map(function (x) {
      var k = x && Array.isArray(x.rows) ? UdFn(x) : null; if (!k) return x;
      var r2 = apDung(x.rows, k, c); return r2 === x.rows ? x : Object.assign({}, x, { rows: r2 });
    });
  }
  function apDungGd7(rows, dayKey) {
    try {
      var sn = (window.__GD7SNAPS || []).filter(function (s) { return s && Array.isArray(s.reportData); }).map(function (s) { return { key: keyDD(s.dayKey), rows: s.reportData }; });
      var dd = window.TD && window.TD.dataDate && window.TD.dataDate.effective && window.TD.dataDate.effective();
      var bk = dd && !isNaN(dd) ? dd.getFullYear() + "-" + ("0" + (dd.getMonth() + 1)).slice(-2) + "-" + ("0" + dd.getDate()).slice(-2) : keyDD("");
      return apDung(rows, keyDD(dayKey), mkCtx(sn, (window.__GD7S && window.__GD7S.qltd) || [], bk));
    } catch (e) { return rows; }
  }
  /* ---- phạm vi ---- */
  var PV = [["", "Tất cả khách hàng & dư nợ"], ["dn", "Doanh nghiệp"], ["th", "Trung + dài hạn (TK 212, 213)"], ["th212", "Trung hạn (TK 212)"], ["nh", "Ngắn hạn + thấu chi"]];
  function loc(code, b3) {
    var f = null;
    if (code === "dn") f = function (r) { return window.QLTD_laDN ? window.QLTD_laDN(r, b3) : !!(b3 && b3(r[1], r[0])); };
    else if (code === "th") f = function (r) { return /trung\s*hạn|dài\s*hạn|tk\s*21[23]/i.test(String(r[13] || "")); };
    else if (code === "th212") f = function (r) { return /trung\s*hạn|tk\s*212/i.test(String(r[13] || "")); };
    else if (code === "nh") f = function (r) { return /ngắn\s*hạn|tk\s*211|thấu\s*chi/i.test(String(r[13] || "")); };
    return f ? function (rows) { return (rows || []).filter(function (r) { return r && f(r); }); } : function (rows) { return rows; };
  }
  function tieuDe(tab, dd, code) {
    if (tab === "kh") return "BÁO CÁO KHÁCH HÀNG" + (code === "dn" ? " DOANH NGHIỆP" : code === "th" ? " VAY TRUNG + DÀI HẠN" : code === "th212" ? " VAY TRUNG HẠN" : code === "nh" ? " VAY NGẮN HẠN" : "") + " ĐẾN NGÀY " + dd;
    return (code === "dn" ? "BÁO CÁO DƯ NỢ DOANH NGHIỆP" : code === "th" ? "BÁO CÁO DƯ NỢ TRUNG + DÀI HẠN" : code === "th212" ? "BÁO CÁO DƯ NỢ TRUNG HẠN" : code === "nh" ? "BÁO CÁO DƯ NỢ NGẮN HẠN" : "BÁO CÁO DƯ NỢ HÀNG NGÀY") + " ĐẾN NGÀY " + dd;
  }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function vn(d) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(d || ""); return m ? m[3] + "/" + m[2] + "/" + m[1] : d; }
  function pvTxt(b) { var a = (b.kh || []).length, k = (b.ks || []).length; return a || k ? (a ? a + " mã KH" : "") + (a && k ? " + " : "") + (k ? k + " mã khế ước" : "") : "Toàn bộ danh mục"; }
  function kieuTxt(b) { return b.kieu === "nguyen" ? "Nguyên danh mục → <b>" + esc(b.den) + "</b>" : "Chia theo từng KH (KH đã tất toán → <b>" + esc(b.den) + "</b>)"; }
  /* ---- cột Bàn giao + dòng nhóm ngoài danh mục ---- */
  function gopBG(a, b) {
    if (!a || !a.rows) return a;
    var mb = {}; (b && b.rows || []).forEach(function (r) { if (r.kind === "cbtd") mb[r.name] = r; });
    a.rows.forEach(function (r) {
      if (r.kind !== "cbtd") return; var q = mb[r.name];
      ["kh", "dn"].forEach(function (t) { var x = r[t], y = q ? q[t] : null; x.bgQ = y ? x.dauQuy - y.dauQuy : 0; x.bgN = y ? x.dauNam - y.dauNam : 0; });
    });
    var nul = function (r) { return ["kh", "dn"].every(function (t) { var x = r[t]; return !(x.dauNam || x.dauQuy || x.dauThang || x.bc || x.plan || x.bgQ || x.bgN); }); };
    var out = [], blk = [], all = [];
    var tong = function (rs, t) { var s = { bgQ: 0, bgN: 0 }; rs.forEach(function (r) { s.bgQ += r[t].bgQ || 0; s.bgN += r[t].bgN || 0; }); return s; };
    a.rows.forEach(function (r) {
      if (r.kind === "cbtd") { if (r.bg && nul(r)) return; blk.push(r); all.push(r); out.push(r); }
      else if (r.kind === "phong") {
        if (r.bg && !blk.length) return;
        ["kh", "dn"].forEach(function (t) { var s = tong(blk, t); r[t].bgQ = s.bgQ; r[t].bgN = s.bgN; }); out.push(r); blk = [];
      } else if (r.kind === "tong") { ["kh", "dn"].forEach(function (t) { var s = tong(all, t); r[t].bgQ = s.bgQ; r[t].bgN = s.bgN; }); out.push(r); }
      else out.push(r);
    });
    a.rows = out;
    var bg = out.filter(function (r) { return r.kind === "cbtd" && r.bg; }).map(function (r) { return r.name; });
    var w0 = String(a.warn || "").replace(/\s*·?\s*ℹ [^]*$/, "");
    a.warn = w0 + (bg.length ? (w0 ? " · " : "") + "ℹ " + bg.length + " cán bộ không có trong danh mục (đã bàn giao hoặc tên khác danh mục): " + bg.join(", ") + " — vẫn cộng vào TỔNG, ở nhóm riêng." : "");
    return a;
  }
  /* ---- cảnh báo tên gần giống ---- */
  function lev(a, b) {
    var p = [], i, j; for (j = 0; j <= b.length; j++) p[j] = j;
    for (i = 1; i <= a.length; i++) { var q = [i]; for (j = 1; j <= b.length; j++) q[j] = Math.min(p[j] + 1, q[j - 1] + 1, p[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); p = q; }
    return p[b.length];
  }
  function giong(a, b) {
    if (a === b) return false;
    var ta = a.split(" "), tb = b.split(" ");
    if (ta.length >= 2 && tb.length >= 2 && ta[0] === tb[0] && ta[ta.length - 1] === tb[tb.length - 1] && Math.abs(ta.length - tb.length) <= 2) {
      var s = ta.length < tb.length ? ta : tb, l = ta.length < tb.length ? tb : ta;
      if (s.every(function (t) { return l.indexOf(t) >= 0; })) return true;
    }
    return lev(a, b) <= 2;
  }
  function canhTen() {
    if (!ctx) return { gan: [], bietDanh: [] };
    var nm = ctx.nm, byKey = {}, sets = [ctx.rows].concat((ctx.snaps || []).map(function (s) { return s.rows; }));
    sets.forEach(function (rows) { (rows || []).forEach(function (r) { if (!r || !r[12]) return; var k = ckey(r, nm); (byKey[k] = byKey[k] || { ma: maOf(r, nm), ten: {} }).ten[String(r[12]).trim()] = 1; }); });
    var ks = Object.keys(byKey), gan = [], bd = [];
    ks.forEach(function (k) { var t = Object.keys(byKey[k].ten); if (t.length > 1) bd.push(t.join(" / ") + (byKey[k].ma ? " (mã " + byKey[k].ma + ")" : "")); });
    for (var i = 0; i < ks.length; i++) for (var j = i + 1; j < ks.length; j++) {
      var A = byKey[ks[i]], B = byKey[ks[j]], ta = Object.keys(A.ten)[0], tb = Object.keys(B.ten)[0];
      if (giong(norm(ta), norm(tb))) gan.push({ a: ta, ma: A.ma, b: tb, mb: B.ma });
    }
    return { gan: gan, bietDanh: bd };
  }
  /* ---- kiểm tổng ---- */
  function kiem(res, F) {
    if (!res || !res.rows) return { ok: true, txt: "" };
    var cols = ["dauNam", "dauQuy", "dauThang", "bc"], bad = [];
    ["kh", "dn"].forEach(function (t) {
      cols.forEach(function (c) {
        var a = 0, p = 0, z = 0;
        res.rows.forEach(function (r) { if (r.kind === "cbtd") a += r[t][c]; else if (r.kind === "phong") p += r[t][c]; else if (r.kind === "tong") z = r[t][c]; });
        if (Math.round(a) !== Math.round(z) || Math.round(p) !== Math.round(z)) bad.push(t + "." + c);
      });
      if (t === "dn") ["bgQ", "bgN"].forEach(function (c) { var s = 0; res.rows.forEach(function (r) { if (r.kind === "cbtd") s += r[t][c] || 0; }); if (Math.round(s) !== 0) bad.push(t + "." + c); });
    });
    var mk = { dauNam: res.mocs && res.mocs.EoY1, dauQuy: res.mocs && res.mocs.EoQ1, dauThang: res.mocs && res.mocs.EoM1, bc: ctx && ctx.bcKey };
    var tong = res.rows.filter(function (r) { return r.kind === "tong"; })[0];
    cols.forEach(function (c) {
      var k = mk[c]; if (!k || !tong) return; var rows = F(getRowsC(ctx, k) || []); if (!rows.length) return;
      var s = 0; rows.forEach(function (r) { var cb = String(r[12] == null ? "" : r[12]).trim(); if (cb) s += Number(r[11]) || 0; });
      if (Math.abs(s - tong.dn[c]) > 1) bad.push("tệp." + c);
    });
    return { ok: !bad.length, txt: bad.length ? "⚠ Lệch tổng: " + bad.join(", ") : "✓ Σ cán bộ = Σ phòng = TỔNG = tổng tệp (4 mốc, KH và dư nợ); Σ bàn giao dư nợ = 0" };
  }
  function dsCB() {
    var nm = ctx ? ctx.nm : {}, m = {};
    [ctx && ctx.rows].concat(((ctx && ctx.snaps) || []).map(function (s) { return s.rows; })).forEach(function (rows) { (rows || []).forEach(function (r) { if (!r || !r[12]) return; var k = ckey(r, nm); m[k] = { ten: String(r[12]).trim(), ma: maOf(r, nm) }; }); });
    return Object.keys(m).map(function (k) { return m[k]; }).sort(function (a, b) { return a.ten < b.ten ? -1 : a.ten > b.ten ? 1 : 0; });
  }
  function xuatExcel(o, so) {
    if (!o.xlsx) return;
    o.xlsx([{ name: "Sổ bàn giao", headers: ["Hiệu lực", "Từ cán bộ", "Mã cán bộ", "Đến cán bộ", "Mã cán bộ", "Cách tính", "Phạm vi", "Số KH chuyển", "Ghi chú", "Người lập", "Xác nhận lúc"],
      widths: [12, 24, 12, 24, 12, 22, 22, 12, 30, 18, 20],
      rows: so.map(function (b) { return [vn(b.ngay), b.tu, b.tuMa || "", b.den, b.denMa || "", b.kieu === "nguyen" ? "Nguyên danh mục" : "Chia theo từng KH", pvTxt(b), b.so || 0, b.ghiChu || "", b.nguoi || "", b.xn ? String(b.xn).slice(0, 19).replace("T", " ") : ""]; }), boldRows: [] }],
      "SoBanGiao_" + (o.bcKey || "") + ".xlsx");
  }
  function panel(el, o) {
    ctx = mkCtx(o.snaps, o.rows, o.bcKey);
    var so = load().filter(function (b) { return b.ngay <= o.bcKey; }), gy = goiY(), k = kiem(o.res, o.F || function (r) { return r; }), ct = canhTen(), cb = dsCB(), cd = mode();
    var opt = function (v) { return cb.map(function (c) { return '<option value="' + esc(c.ma || c.ten) + '|' + esc(c.ten) + '">' + esc(c.ten) + (c.ma ? " — " + esc(c.ma) : "") + "</option>"; }).join(""); };
    var h = '<div class="bg-bar" data-testid="bg-bar"><label>Phạm vi <select data-testid="bcn-loc">' +
      PV.map(function (p) { return '<option value="' + p[0] + '"' + (p[0] === (o.loc || "") ? " selected" : "") + ">" + p[1] + "</option>"; }).join("") +
      '</select></label><label>Mốc so sánh <select data-testid="bcn-cd"><option value="moi"' + (cd === "moi" ? " selected" : "") + '>Theo danh mục đang quản lý</option><option value="cu"' + (cd === "cu" ? " selected" : "") + '>Theo cán bộ tại thời điểm mốc (cách cũ)</option></select></label>' +
      '<span class="bg-kiem ' + (k.ok ? "ok" : "bad") + '" data-testid="bg-kiem">' + esc(k.txt) + "</span></div>";
    if (ct.gan.length || ct.bietDanh.length) {
      h += '<div class="bg-canh" data-testid="bg-canh">' + ct.gan.slice(0, 6).map(function (g) {
        return "⚠ Tên gần giống: <b>" + esc(g.a) + "</b>" + (g.ma ? " (mã " + esc(g.ma) + ")" : "") + " ≠ <b>" + esc(g.b) + "</b>" + (g.mb ? " (mã " + esc(g.mb) + ")" : "") + (g.ma && g.mb ? " — hai người khác nhau, app không gộp." : " — chưa có mã để phân biệt, app KHÔNG tự gộp.");
      }).join("<br>") + (ct.bietDanh.length ? (ct.gan.length ? "<br>" : "") + "ℹ Cùng mã cán bộ nhưng viết tên khác nhau giữa các mốc (nên thống nhất tên trong danh mục): " + ct.bietDanh.slice(0, 4).map(esc).join("; ") : "") + "</div>";
    }
    h += '<details class="bg-so" data-testid="bg-so"' + (moSo || gy.length ? " open" : "") + '><summary>🔁 Sổ bàn giao cán bộ — <b data-testid="bg-n">' + so.length + "</b> đã xác nhận" +
      (gy.length ? ' · <b class="bg-moi" data-testid="bg-n-goiy">' + gy.length + "</b> gợi ý chờ xác nhận" : "") + "</summary>";
    if (gy.length) {
      h += '<div class="bg-h">App phát hiện khách hàng chuyển cán bộ giữa 2 mốc — kiểm tra rồi xác nhận (số liệu các mốc trước ngày hiệu lực sẽ tính lại theo cán bộ nhận):</div><div class="bg-tw"><table class="bg-t" data-testid="bg-goiy"><thead><tr><th>Hiệu lực</th><th>Từ cán bộ</th><th>Cách tính</th><th>Số KH chuyển</th><th></th></tr></thead><tbody>' +
        gy.map(function (b, i) {
          return '<tr data-testid="bg-goiy-row" data-tu="' + esc(b.tu) + '" data-ma="' + esc(b.tuMa) + '" data-kieu="' + b.kieu + '"><td>' + vn(b.ngay) + "</td><td>" + esc(b.tu) + (b.tuMa ? '<div class="bg-ct">mã ' + esc(b.tuMa) + "</div>" : "") + "</td><td>" + kieuTxt(b) +
            '<div class="bg-ct">' + esc(b.chiTiet) + "</div></td><td class=\"r\">" + b.so + '</td><td class="nw"><button type="button" data-a="xn" data-i="' + i + '" data-testid="bg-xn">✓ Xác nhận</button> <button type="button" data-a="bo" data-i="' + i + '" data-testid="bg-bo">✕</button></td></tr>';
        }).join("") + '</tbody></table></div><button type="button" data-a="xnall" data-testid="bg-xn-all">✓ Xác nhận tất cả gợi ý</button>';
    }
    h += '<div class="bg-h">Đã xác nhận:</div>' + (so.length ? '<div class="bg-tw"><table class="bg-t" data-testid="bg-da"><thead><tr><th>Hiệu lực</th><th>Từ cán bộ</th><th>Cách tính</th><th>Phạm vi</th><th>Ghi chú</th><th>Người lập</th><th></th></tr></thead><tbody>' +
      so.map(function (b) {
        return '<tr data-testid="bg-da-row" data-k="' + esc(id(b)) + '"><td>' + vn(b.ngay) + "</td><td>" + esc(b.tu) + (b.tuMa ? '<div class="bg-ct">mã ' + esc(b.tuMa) + "</div>" : "") + "</td><td>" + kieuTxt(b) + "</td><td>" + esc(pvTxt(b)) +
          '</td><td><input type="text" data-f="ghiChu" data-testid="bg-gc" value="' + esc(b.ghiChu || "") + '" maxlength="300"></td><td><input type="text" data-f="nguoi" data-testid="bg-nguoi" value="' + esc(b.nguoi || "") + '" maxlength="80"></td><td><button type="button" data-a="xoa" data-k="' + esc(id(b)) + '" title="Xoá" data-testid="bg-xoa">🗑</button></td></tr>';
      }).join("") + "</tbody></table></div>" : '<div class="bg-h">(chưa có)</div>');
    h += '<details class="bg-add" data-testid="bg-add"><summary>＋ Thêm bàn giao thủ công</summary><div class="bg-form">' +
      '<label>Hiệu lực <input type="date" data-testid="bg-add-ngay" value="' + esc(o.bcKey) + '"></label>' +
      '<label>Từ cán bộ <select data-testid="bg-add-tu">' + opt() + '</select></label><label>Đến cán bộ <select data-testid="bg-add-den">' + opt() + '</select></label>' +
      '<label>Cách tính <select data-testid="bg-add-kieu"><option value="nguyen">Nguyên danh mục</option><option value="chia">Chia theo từng KH</option></select></label>' +
      '<label class="bg-w">Chỉ các mã KH (brcd) — để trống = toàn bộ <textarea data-testid="bg-add-kh" rows="2"></textarea></label>' +
      '<label class="bg-w">Chỉ các mã khế ước (dsbsseq) — để trống = toàn bộ <textarea data-testid="bg-add-ks" rows="2"></textarea></label>' +
      '<label class="bg-w">Ghi chú <input type="text" data-testid="bg-add-gc" maxlength="300"></label><label>Người lập <input type="text" data-testid="bg-add-nguoi" maxlength="80"></label>' +
      '<button type="button" data-a="them" data-testid="bg-add-ok">＋ Thêm vào sổ</button></div></details>' +
      '<div class="bg-io"><button type="button" data-a="xlsx" data-testid="bg-xlsx">⬇ Xuất Excel (biên bản)</button> <button type="button" data-a="xuat" data-testid="bg-xuat">⬇ Xuất sổ (JSON)</button> <label class="bg-nhap">⬆ Nhập sổ <input type="file" accept=".json,application/json" data-testid="bg-nhap"></label></div></details>';
    el.innerHTML = h;
    el.querySelector("[data-testid=bcn-loc]").onchange = function (ev) { o.setLoc && o.setLoc(ev.target.value); };
    el.querySelector("[data-testid=bcn-cd]").onchange = function (ev) { try { localStorage.setItem(CD, ev.target.value); } catch (e) { } o.onChange && o.onChange(); };
    el.querySelector("details").ontoggle = function (ev) { if (ev.target === el.querySelector("details")) moSo = ev.target.open; };
    el.onchange = function (ev) {
      var t = ev.target; if (!t || !t.getAttribute) return; var f = t.getAttribute("data-f"); if (!f) return;
      var tr = t.closest("tr"), kk = tr && tr.getAttribute("data-k"), l = load(); l.forEach(function (b) { if (id(b) === kk) b[f] = t.value; }); save(l);
    };
    el.onclick = function (ev) {
      var t = ev.target.closest ? ev.target.closest("button[data-a]") : null; if (!t) return;
      var a = t.getAttribute("data-a"), l = load();
      if (a === "xn" || a === "xnall") {
        (a === "xn" ? [gy[+t.getAttribute("data-i")]] : gy).forEach(function (b) { if (b) l.push({ ngay: b.ngay, tu: b.tu, tuMa: b.tuMa, den: b.den, denMa: b.denMa, kieu: b.kieu, so: b.so, xn: new Date().toISOString() }); });
        save(l); moSo = true;
      } else if (a === "bo") { var b = gy[+t.getAttribute("data-i")], x = rd(BO); if (b) { x.push(id(b)); wr(BO, x); } }
      else if (a === "xoa") { var kk = t.getAttribute("data-k"); save(l.filter(function (b) { return id(b) !== kk; })); }
      else if (a === "them") {
        var q = function (s) { return el.querySelector("[data-testid=" + s + "]"); }, tu = q("bg-add-tu").value.split("|"), de = q("bg-add-den").value.split("|");
        var ng = q("bg-add-ngay").value, tuMa = /^\d+$/.test(tu[0]) ? tu[0] : "", denMa = /^\d+$/.test(de[0]) ? de[0] : "";
        if (!ng || !tu[1] || !de[1] || norm(tu[1]) === norm(de[1])) { alert("Chọn ngày hiệu lực và 2 cán bộ khác nhau."); return; }
        var nb = { ngay: ng, tu: tu[1], tuMa: tuMa, den: de[1], denMa: denMa, kieu: q("bg-add-kieu").value, ghiChu: q("bg-add-gc").value.trim(), nguoi: q("bg-add-nguoi").value.trim(), kh: ds(q("bg-add-kh").value), ks: ds(q("bg-add-ks").value), so: 0, xn: new Date().toISOString(), tay: 1 };
        l = l.filter(function (b) { return id(b) !== id(nb); }); l.push(nb); save(l); moSo = true;
      }
      else if (a === "xlsx") { xuatExcel(o, load().filter(function (b) { return b.ngay <= o.bcKey; })); return; }
      else if (a === "xuat") {
        var bl = new Blob([JSON.stringify({ loai: "QLTDPRO-so-ban-giao", phien_ban: 2, so: l }, null, 1)], { type: "application/json" }), u = URL.createObjectURL(bl), aa = document.createElement("a");
        aa.href = u; aa.download = "SoBanGiao_" + (o.bcKey || "") + ".json"; document.body.appendChild(aa); aa.click(); setTimeout(function () { URL.revokeObjectURL(u); aa.remove(); }, 500); return;
      }
      o.onChange && o.onChange();
    };
    el.querySelector("[data-testid=bg-nhap]").onchange = function (ev) {
      var f = ev.target.files && ev.target.files[0]; if (!f) return;
      f.text().then(function (s) {
        var j = JSON.parse(s), n = (j && Array.isArray(j.so) ? j.so : Array.isArray(j) ? j : []).filter(hopLe);
        var l = load(), co = {}; l.forEach(function (b) { co[id(b)] = 1; }); n.forEach(function (b) { if (!co[id(b)]) l.push(b); });
        save(l); o.onChange && o.onChange();
      }).catch(function () { alert("Tệp sổ bàn giao không đọc được (cần JSON xuất từ QLTDPRO)."); });
    };
  }
  /* ---- GĐ3: khóa cán bộ + tỷ lệ chia kế hoạch theo bàn giao ---- */
  function maTen(ten) { return (ctx && ctx.nm && ctx.nm[norm(ten)]) || ""; }
  function keyOf(ten, ma) { var m = ma || maTen(ten); return m ? "M" + m : "N" + norm(ten); }
  function chiaKH(b) {
    if (!ctx) return null;
    var snaps = (ctx.snaps || []).filter(function (s) { return s.key < b.ngay; }).sort(function (a, c) { return a.key < c.key ? -1 : 1; });
    if (!snaps.length) return null;
    var prev = snaps[snaps.length - 1].rows, nm = ctx.nm, cur = cbKH(getRowsC(ctx, b.ngay), nm), X = cbKH(prev, nm), tuKey = keyOf(b.tu, b.tuMa);
    var hk = (b.kh || []).length, hs = (b.ks || []).length, skh = {}, sks = {}, ksKH = {}, total = 0, moved = 0, dest = {};
    (b.kh || []).forEach(function (k) { skh[String(k).trim()] = 1; }); (b.ks || []).forEach(function (k) { sks[String(k).trim()] = 1; });
    if (hs) prev.forEach(function (r) { if (r && sks[String(r[20] == null ? "" : r[20]).trim()]) ksKH[String(r[0] == null ? "" : r[0]).trim()] = 1; });
    Object.keys(X).forEach(function (k) {
      if (X[k].key !== tuKey) return; total++;
      if ((hk || hs) && !(skh[k] || ksKH[k])) return;
      moved++; var d = b.kieu === "chia" && cur[k] ? { ten: cur[k].ten, ma: cur[k].ma, key: cur[k].key } : { ten: b.den, ma: b.denMa || maTen(b.den), key: keyOf(b.den, b.denMa) };
      (dest[d.key] = dest[d.key] || { ten: d.ten, ma: d.ma, n: 0 }).n++;
    });
    return { total: total, moved: moved, dest: dest, tuKey: tuKey };
  }
  window.QLTDBG = { chiaKH: chiaKH, keyOf: keyOf, maTen: maTen, dsCB: dsCB, getCtx: function () { return ctx; }, KEY: KEY, CD: CD, load: load, save: save, cbKH: cbKH, goiY: goiY, goiYCap: goiYCap, apDung: apDung, apDungSnaps: apDungSnaps, apDungGd7: apDungGd7,
    loc: loc, tieuDe: tieuDe, panel: panel, gopBG: gopBG, canhTen: canhTen, kiem: kiem, mode: mode,
    ctx: function (o) { ctx = mkCtx(o.snaps, o.rows, o.bcKey); },
    setCtx: function (snaps, rows, dd) { ctx = mkCtx(snaps, rows, keyDD(dd)); },
    raw: function (fn) { raw = true; try { return fn(); } finally { raw = false; } } };
})();
