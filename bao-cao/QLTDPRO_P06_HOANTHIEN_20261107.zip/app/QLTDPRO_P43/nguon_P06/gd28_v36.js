/* gd28 · HM-31 GĐ2 (v24.17.36): Sổ bàn giao cán bộ + phạm vi Báo cáo ngày.
   Quy tắc (người dùng chốt 07/11/2026):
   - Nguyên danh mục A → B: mọi số liệu mốc TRƯỚC ngày hiệu lực của A tính cho B.
   - Chia danh mục A → nhiều người: theo từng KH, mọi mốc — KH còn ở ngày hiệu lực → cán bộ đang quản lý KH đó;
     KH đã tất toán → người nhận chính.
   - App gợi ý (so 2 mốc liền nhau), người dùng xác nhận; lưu localStorage "td_ban_giao_v1" (xuất/nhập JSON). */
(function () {
  var KEY = "td_ban_giao_v1", BO = "td_ban_giao_bo_v1", LOC = "td_bcn_loc";
  var ctx = null, moSo = false;
  function norm(s) {
    return String(s == null ? "" : s).trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "")
      .replace(/đ/g, "d").replace(/\./g, " ").replace(/\s+/g, " ").trim();
  }
  function rd(k) { try { var v = JSON.parse(localStorage.getItem(k) || "[]"); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function wr(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function load() { return rd(KEY).filter(function (b) { return b && b.ngay && b.tu && b.den && (b.kieu === "nguyen" || b.kieu === "chia"); }); }
  function save(l) { return wr(KEY, l); }
  function id(b) { return b.ngay + "|" + norm(b.tu); }
  /* KH → cán bộ (dòng dư nợ > 0 có số dư lớn nhất) */
  function cbKH(rows) {
    var m = {}, best = {};
    (rows || []).forEach(function (r) {
      if (!r) return; var k = String(r[0] == null ? "" : r[0]).trim(), cb = String(r[12] == null ? "" : r[12]).trim(), b = Number(r[11]) || 0;
      if (!k || !cb || !(b > 0)) return;
      if (best[k] == null || b > best[k]) { best[k] = b; m[k] = cb; }
    });
    return m;
  }
  function goiYCap(truoc, sau, ngay) {
    var x = cbKH(truoc), y = cbKH(sau), co = {}, mv = {}, ten = {};
    Object.keys(x).forEach(function (k) { var a = norm(x[k]); co[a] = (co[a] || 0) + 1; ten[a] = x[k]; });
    Object.keys(x).forEach(function (k) {
      if (!(k in y)) return; var a = norm(x[k]), b = norm(y[k]); if (a === b) return;
      ten[b] = y[k]; (mv[a] = mv[a] || {})[b] = (mv[a][b] || 0) + 1;
    });
    var out = [];
    Object.keys(mv).forEach(function (a) {
      var d = mv[a], ks = Object.keys(d).sort(function (p, q) { return d[q] - d[p] || (p < q ? -1 : 1); }), m = 0;
      ks.forEach(function (k) { m += d[k]; });
      if (m < 5 || m < 0.5 * (co[a] || 0)) return;
      out.push({ ngay: ngay, tu: ten[a], den: ten[ks[0]], kieu: d[ks[0]] >= 0.9 * m ? "nguyen" : "chia", so: m,
        chiTiet: ks.slice(0, 6).map(function (k) { return ten[k] + " " + d[k]; }).join(", ") });
    });
    return out.sort(function (p, q) { return q.so - p.so; });
  }
  function moc() { /* danh sách mốc [{key, rows}] ≤ ngày BC, ngày BC dùng dữ liệu hiện hành */
    if (!ctx) return [];
    var l = (ctx.snaps || []).filter(function (s) { return s.key && s.key < ctx.bcKey; });
    return l.concat([{ key: ctx.bcKey, rows: ctx.rows }]);
  }
  function getRows(k) { if (!ctx) return null; if (k === ctx.bcKey) return ctx.rows; var s = (ctx.snaps || []).filter(function (x) { return x.key === k; })[0]; return s ? s.rows : null; }
  function goiY() {
    var m = moc(), out = [], co = {}, bo = {};
    load().forEach(function (b) { co[id(b)] = 1; }); rd(BO).forEach(function (k) { bo[k] = 1; });
    for (var i = 1; i < m.length; i++) goiYCap(m[i - 1].rows, m[i].rows, m[i].key).forEach(function (b) { if (!co[id(b)] && !bo[id(b)]) out.push(b); });
    return out;
  }
  /* áp sổ bàn giao lên dòng của một mốc */
  function apDung(rows, mocKey) {
    if (!ctx || !rows || !mocKey) return rows;
    var so = load().filter(function (b) { return b.ngay > mocKey && b.ngay <= ctx.bcKey; });
    if (!so.length) return rows;
    var dot = {}; so.forEach(function (b) { (dot[b.ngay] = dot[b.ngay] || []).push(b); });
    var out = rows;
    Object.keys(dot).sort().forEach(function (ng) {
      var mp = {}; dot[ng].forEach(function (b) { mp[norm(b.tu)] = b; });
      var cur = null;
      out = out.map(function (r) {
        if (!r) return r; var b = mp[norm(r[12])]; if (!b) return r;
        var den = b.den;
        if (b.kieu === "chia") { if (!cur) cur = cbKH(getRows(ng) || []); var k = String(r[0] == null ? "" : r[0]).trim(); if (cur[k]) den = cur[k]; }
        var c = r.slice(); c[12] = den; return c;
      });
    });
    return out;
  }
  /* phạm vi */
  var PV = [["", "Tất cả khách hàng & dư nợ"], ["dn", "Doanh nghiệp"], ["th", "Trung + dài hạn (TK 212, 213)"], ["th212", "Trung hạn (TK 212)"], ["nh", "Ngắn hạn + thấu chi"]];
  function loc(code, b3) {
    var f = null;
    if (code === "dn") f = function (r) { return window.QLTD_laDN ? window.QLTD_laDN(r, b3) : !!(b3 && b3(r[1], r[0])); };
    else if (code === "th") f = function (r) { return /trung\s*hạn|dài\s*hạn|tk\s*21[23]/i.test(String(r[13] || "")); };
    else if (code === "th212") f = function (r) { return /trung\s*hạn|tk\s*212/i.test(String(r[13] || "")); };
    else if (code === "nh") f = function (r) { return /ngắn\s*hạn|tk\s*211|thấu\s*chi/i.test(String(r[13] || "")); };
    return f ? function (rows) { return (rows || []).filter(function (r) { return r && f(r); }); } : function (rows) { return rows; };
  }
  function tieuDe(tab, dd, code) {
    if (tab === "kh") return "BÁO CÁO KHÁCH HÀNG" + (code === "dn" ? " DOANH NGHIỆP" : code === "th" ? " VAY TRUNG + DÀI HẠN" : code === "th212" ? " VAY TRUNG HẠN" : code === "nh" ? " VAY NGẮN HẠN" : "") + " ĐẾN NGÀY " + dd;
    return (code === "dn" ? "BÁO CÁO DƯ NỢ DOANH NGHIỆP" : code === "th" ? "BÁO CÁO DƯ NỢ TRUNG + DÀI HẠN" : code === "th212" ? "BÁO CÁO DƯ NỢ TRUNG HẠN" : code === "nh" ? "BÁO CÁO DƯ NỢ NGẮN HẠN" : "BÁO CÁO DƯ NỢ HÀNG NGÀY") + " ĐẾN NGÀY " + dd;
  }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function vn(d) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(d || ""); return m ? m[3] + "/" + m[2] + "/" + m[1] : d; }
  function kieuTxt(b) { return b.kieu === "nguyen" ? "Nguyên danh mục → <b>" + esc(b.den) + "</b>" : "Chia theo từng KH (KH đã tất toán → <b>" + esc(b.den) + "</b>)"; }
  /* kiểm Σ cán bộ = Σ phòng = TỔNG; TỔNG dư nợ = tổng tệp (đã lọc) mỗi mốc */
  function kiem(res, F) {
    if (!res || !res.rows) return { ok: true, txt: "" };
    var cols = ["dauNam", "dauQuy", "dauThang", "bc"], bad = [];
    ["kh", "dn"].forEach(function (t) {
      cols.forEach(function (c) {
        var a = 0, p = 0, z = 0;
        res.rows.forEach(function (r) { if (r.kind === "cbtd") a += r[t][c]; else if (r.kind === "phong") p += r[t][c]; else if (r.kind === "tong") z = r[t][c]; });
        if (Math.round(a) !== Math.round(z) || Math.round(p) !== Math.round(z)) bad.push(t + "." + c);
      });
    });
    var mk = { dauNam: res.mocs && res.mocs.EoY1, dauQuy: res.mocs && res.mocs.EoQ1, dauThang: res.mocs && res.mocs.EoM1, bc: ctx && ctx.bcKey };
    var tong = res.rows.filter(function (r) { return r.kind === "tong"; })[0];
    cols.forEach(function (c) {
      var k = mk[c]; if (!k || !tong) return; var rows = F(getRows(k) || []); if (!rows.length) return;
      var s = 0; rows.forEach(function (r) { var cb = String(r[12] == null ? "" : r[12]).trim(); if (cb) s += Number(r[11]) || 0; });
      if (Math.abs(s - tong.dn[c]) > 1) bad.push("tệp." + c);
    });
    return { ok: !bad.length, txt: bad.length ? "⚠ Lệch tổng: " + bad.join(", ") : "✓ Σ cán bộ = Σ phòng = TỔNG = tổng tệp (4 mốc, KH và dư nợ)" };
  }
  function panel(el, o) {
    ctx = { snaps: o.snaps || [], rows: o.rows || [], bcKey: o.bcKey };
    var so = load().filter(function (b) { return b.ngay <= o.bcKey; }), gy = goiY(), k = kiem(o.res, o.F || function (r) { return r; });
    var h = '<div class="bg-bar" data-testid="bg-bar"><label>Phạm vi <select data-testid="bcn-loc">' +
      PV.map(function (p) { return '<option value="' + p[0] + '"' + (p[0] === (o.loc || "") ? " selected" : "") + ">" + p[1] + "</option>"; }).join("") +
      '</select></label><span class="bg-kiem ' + (k.ok ? "ok" : "bad") + '" data-testid="bg-kiem">' + esc(k.txt) + "</span></div>" +
      '<details class="bg-so" data-testid="bg-so"' + (moSo || gy.length ? " open" : "") + '><summary>🔁 Sổ bàn giao cán bộ — <b data-testid="bg-n">' + so.length + "</b> đã xác nhận" +
      (gy.length ? ' · <b class="bg-moi" data-testid="bg-n-goiy">' + gy.length + "</b> gợi ý chờ xác nhận" : "") + "</summary>";
    if (gy.length) {
      h += '<div class="bg-h">App phát hiện khách hàng chuyển cán bộ giữa 2 mốc — kiểm tra rồi xác nhận (số liệu các mốc trước ngày hiệu lực sẽ tính lại theo cán bộ nhận):</div><div class="bg-tw"><table class="bg-t" data-testid="bg-goiy"><thead><tr><th>Hiệu lực</th><th>Từ cán bộ</th><th>Cách tính</th><th>Số KH chuyển</th><th></th></tr></thead><tbody>' +
        gy.map(function (b, i) {
          return '<tr data-testid="bg-goiy-row" data-tu="' + esc(b.tu) + '" data-kieu="' + b.kieu + '"><td>' + vn(b.ngay) + "</td><td>" + esc(b.tu) + "</td><td>" + kieuTxt(b) +
            '<div class="bg-ct">' + esc(b.chiTiet) + "</div></td><td class=\"r\">" + b.so + '</td><td class="nw"><button type="button" data-a="xn" data-i="' + i + '" data-testid="bg-xn">✓ Xác nhận</button> <button type="button" data-a="bo" data-i="' + i + '" data-testid="bg-bo">✕</button></td></tr>';
        }).join("") + '</tbody></table></div><button type="button" data-a="xnall" data-testid="bg-xn-all">✓ Xác nhận tất cả gợi ý</button>';
    }
    h += '<div class="bg-h">Đã xác nhận:</div>' + (so.length ? '<div class="bg-tw"><table class="bg-t" data-testid="bg-da"><thead><tr><th>Hiệu lực</th><th>Từ cán bộ</th><th>Cách tính</th><th></th></tr></thead><tbody>' +
      so.map(function (b) { return '<tr data-testid="bg-da-row"><td>' + vn(b.ngay) + "</td><td>" + esc(b.tu) + "</td><td>" + kieuTxt(b) + '</td><td><button type="button" data-a="xoa" data-k="' + esc(id(b)) + '" title="Xoá" data-testid="bg-xoa">🗑</button></td></tr>'; }).join("") +
      "</tbody></table></div>" : '<div class="bg-h">(chưa có)</div>') +
      '<div class="bg-io"><button type="button" data-a="xuat" data-testid="bg-xuat">⬇ Xuất sổ (JSON)</button> <label class="bg-nhap">⬆ Nhập sổ <input type="file" accept=".json,application/json" data-testid="bg-nhap"></label></div></details>';
    el.innerHTML = h;
    el.querySelector("[data-testid=bcn-loc]").onchange = function (ev) { o.setLoc && o.setLoc(ev.target.value); };
    el.querySelector("details").ontoggle = function (ev) { moSo = ev.target.open; };
    el.onclick = function (ev) {
      var t = ev.target.closest ? ev.target.closest("button[data-a]") : null; if (!t) return;
      var a = t.getAttribute("data-a"), l = load();
      if (a === "xn" || a === "xnall") {
        (a === "xn" ? [gy[+t.getAttribute("data-i")]] : gy).forEach(function (b) { if (b) l.push({ ngay: b.ngay, tu: b.tu, den: b.den, kieu: b.kieu, so: b.so, xn: new Date().toISOString() }); });
        save(l); moSo = true;
      } else if (a === "bo") { var b = gy[+t.getAttribute("data-i")], x = rd(BO); if (b) { x.push(id(b)); wr(BO, x); } }
      else if (a === "xoa") { var kk = t.getAttribute("data-k"); save(l.filter(function (b) { return id(b) !== kk; })); }
      else if (a === "xuat") {
        var bl = new Blob([JSON.stringify({ loai: "QLTDPRO-so-ban-giao", phien_ban: 1, so: l }, null, 1)], { type: "application/json" }), u = URL.createObjectURL(bl), aa = document.createElement("a");
        aa.href = u; aa.download = "SoBanGiao_" + (o.bcKey || "") + ".json"; document.body.appendChild(aa); aa.click(); setTimeout(function () { URL.revokeObjectURL(u); aa.remove(); }, 500); return;
      }
      o.onChange && o.onChange();
    };
    el.querySelector("[data-testid=bg-nhap]").onchange = function (ev) {
      var f = ev.target.files && ev.target.files[0]; if (!f) return;
      f.text().then(function (s) {
        var j = JSON.parse(s), n = (j && Array.isArray(j.so) ? j.so : Array.isArray(j) ? j : []).filter(function (b) { return b && b.ngay && b.tu && b.den && (b.kieu === "nguyen" || b.kieu === "chia"); });
        var l = load(), co = {}; l.forEach(function (b) { co[id(b)] = 1; }); n.forEach(function (b) { if (!co[id(b)]) l.push(b); });
        save(l); o.onChange && o.onChange();
      }).catch(function () { alert("Tệp sổ bàn giao không đọc được (cần JSON xuất từ QLTDPRO)."); });
    };
  }
  window.QLTDBG = { KEY: KEY, LOC: LOC, load: load, save: save, cbKH: cbKH, goiY: goiY, goiYCap: goiYCap, apDung: apDung, loc: loc, tieuDe: tieuDe, panel: panel,
    ctx: function (c) { ctx = c; }, kiem: kiem };
})();
