# P05 · HM-30 · v24.17.34 — người dùng 07/11: Trung tâm nhập dữ liệu + Lưu trữ sắp theo loại dữ liệu đầu vào (Dư nợ / Tài sản), mới → cũ.
#  Lưu trữ: tab "💰 Dư nợ (msit80)" (đổi tên "Lưu trữ Báo cáo"; xếp theo ngày dữ liệu mới → cũ, gom tháng, cảnh báo mốc bất thường, lọc, nút 👁 xem tại mốc)
#  + tab mới "🏠 Tài sản bảo đảm". Trung tâm nhập: thẻ tóm tắt Dư nợ / Tài sản + lọc nhật ký theo loại, nhật ký xếp theo ngày dữ liệu mới → cũ.
#  Chỉ đổi HIỂN THỊ: thao tác xoá / gắn nhãn / đổi tên dùng nguyên chỉ số gốc (W). Cần v24.17.33 (HM-29) cho nút 👁.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P05/build_p05_hm30.py
import hashlib
SRC = 'app/QLTDPRO_v24.17.33.html'; DST = 'app/QLTDPRO_v24.17.34.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:90]); s = s.replace(old, new)
A = 'window.QLTDArc'
rep('<script id="gd7-js">', '<style id="gd26-css">\n' + open('nguon_P05/gd26.css', encoding='utf-8').read() + '</style>\n<script id="gd26-js">\n' + open('nguon_P05/gd26.js', encoding='utf-8').read() + '\n</script>\n<script id="gd7-js">')
# tab Lưu trữ
rep('const H_=[["report","📈 Lưu trữ Báo cáo"],["daily","📅 Hàng ngày"],["data","💾 Lưu trữ Dữ liệu"]]', 'const H_=[["report","💰 Dư nợ (msit80)"],["ts","🏠 Tài sản bảo đảm"],["daily","📅 Hàng ngày"],["data","💾 Lưu trữ Dữ liệu"]]')
rep('r==="daily"&&o.jsxs("div",{className:"space-y-3","data-testid":"ar-pane-daily"', 'r==="ts"&&o.jsx("div",{className:"space-y-3","data-testid":"ar-pane-ts",ref:__e=>{__e&&' + A + '&&' + A + '.paneTS(__e)}}),r==="daily"&&o.jsxs("div",{className:"space-y-3","data-testid":"ar-pane-daily"')
# tab Dư nợ: tóm tắt + xếp + gom tháng + cảnh báo + 👁
rep('o.jsxs("p",{className:"rounded-md bg-info/10 px-3 py-2 text-xs",children:[o.jsx("b",{children:"🏷️ Mốc so sánh:"})', 'o.jsx("div",{"data-testid":"ar-tomtat",ref:__e=>{__e&&' + A + '&&' + A + '.tomTatArc(__e)}}),o.jsxs("p",{className:"rounded-md bg-info/10 px-3 py-2 text-xs",children:[o.jsx("b",{children:"🏷️ Mốc so sánh:"})')
rep('i.map((E,W)=>{var U;return o.jsxs("tr",{"data-testid":"ar-row",className:"border-t "+(u.has(W)?"bg-warn/20":W%2?"":"bg-muted/30"),',
    A + '.xep(i).map(([E,W],__k)=>{var U;const __c=' + A + '.canh(i,E,S(E));return o.jsxs("tr",{"data-testid":"ar-row","data-day":E.dayKey||"","data-nhan":E.tag?"1":"0","data-canh":__c,title:' + A + '.canhTxt(i,E,S(E))||void 0,className:"border-t "+(u.has(W)?"bg-warn/20":__k%2?"":"bg-muted/30")+(__c?" ar-canh":""),')
rep('"data-testid":"ar-del",children:"🗑️"})]})]},W)})]})', '"data-testid":"ar-del",children:"🗑️"})]})]},W)}).reduce(' + A + '.nhom(o.jsx,' + A + '.xep(i)),[])]})')
rep('o.jsx("button",{type:"button",className:"rounded border px-1.5",onClick:()=>void B(W),title:"Tải xuống","data-testid":"ar-dl",children:"⬇️"})',
    'o.jsx("button",{type:"button",className:"rounded border px-1.5",onClick:()=>window.QLTDXemMoc&&window.QLTDXemMoc.xem(E),title:"Xem toàn app tại mốc này (chỉ xem)","data-testid":"ar-xem",children:"👁"})," ",o.jsx("button",{type:"button",className:"rounded border px-1.5",onClick:()=>void B(W),title:"Tải xuống","data-testid":"ar-dl",children:"⬇️"})')
# Trung tâm nhập
rep('o.jsxs("div",{className:"rounded-lg border bg-card",children:[o.jsxs("div",{className:"flex flex-wrap items-center gap-3 border-b px-3 py-2",children:[o.jsx("h2",{className:"mr-auto text-sm font-bold",children:"Nhật ký nhập"}),',
    'o.jsx("div",{"data-testid":"nhap-tomtat",ref:__e=>{__e&&' + A + '&&' + A + '.tomTatNhap(__e)}}),o.jsxs("div",{className:"rounded-lg border bg-card",children:[o.jsxs("div",{className:"flex flex-wrap items-center gap-3 border-b px-3 py-2",children:[o.jsx("h2",{className:"text-sm font-bold",children:"Nhật ký nhập"}),o.jsx("span",{className:"mr-auto","data-testid":"log-loc-host",ref:__e=>{__e&&' + A + '&&' + A + '.locLog(__e)}}),')
rep('o.jsx("tbody",{children:d.map((U,re)=>o.jsxs("tr",{className:"border-b last:border-0","data-testid":"log-row",children:', 'o.jsx("tbody",{children:' + A + '.xepLog(d).map((U,re)=>o.jsxs("tr",{className:"border-b last:border-0","data-testid":"log-row","data-kind":U.kind||"",children:')
c = s.count('"24.17.33"'); assert c == 2, c
s = s.replace('"24.17.33"', '"24.17.34"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.33' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.33', '24.17.34'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
