# P05 · HM-28 · v24.17.32 — người dùng 07/11: (1) đổi tên trang "Dư nợ cầm cố" → "Cầm cố", đặt ngay sau trang "Doanh nghiệp";
#  (2) trang "Khách hàng mới" đặt ngay sau trang "Cầm cố". Thứ tự menu Dư nợ: Tất cả dư nợ · Ngắn hạn · Thấu chi · Trung-dài hạn · Doanh nghiệp · Cầm cố · Khách hàng mới · Khách hàng 360°.
#  Slug cũ giữ nguyên (#/du-no-cam-co) ⇒ liên kết, bố cục bảng, phạm vi lọc đã lưu không đổi; không đụng dữ liệu/công thức.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P05/build_p05_hm28.py
import hashlib
SRC = 'app/QLTDPRO_v24.17.31.html'; DST = 'app/QLTDPRO_v24.17.32.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:90]); s = s.replace(old, new)
rep('Ge("du-no","khach-hang-360","Khách hàng 360°",["khachhang","khach-hang"]),Ge("du-no","khach-hang-moi","Khách hàng mới",["khmoi"]),Ge("du-no","du-no-cam-co","Dư nợ cầm cố",["qcamco","cam-co"]),',
    'Ge("du-no","du-no-cam-co","Cầm cố",["qcamco","cam-co","du-no-cam-co"]),Ge("du-no","khach-hang-moi","Khách hàng mới",["khmoi"]),Ge("du-no","khach-hang-360","Khách hàng 360°",["khachhang","khach-hang"]),')
rep('exportName:"Du_no_cam_co"', 'exportName:"Cam_co"')
c = s.count('"24.17.31"'); assert c == 2, c
s = s.replace('"24.17.31"', '"24.17.32"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.31' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.31', '24.17.32'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
