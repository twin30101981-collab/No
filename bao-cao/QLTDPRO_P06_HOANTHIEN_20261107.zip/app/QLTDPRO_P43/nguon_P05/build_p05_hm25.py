# P05 · HM-25 · v24.17.29 — người dùng 06/11: trang "Cho vay doanh nghiệp" cùng cấu trúc trang Ngắn hạn / Trung-dài hạn.
#  Q17 (người dùng): nhận diện DN theo cột msit80 custtpnm (khác "Cá nhân"/"Hộ gia đình"… ⇒ DN), custdtltpnm = loại hình chi tiết;
#  tệp/mốc cũ chưa có cột ⇒ tạm theo tên (quy tắc sẵn có b3 của Chỉ tiêu kế hoạch). Q18: chỉ tiêu "Dư nợ DN" đổi cùng cách nhận diện.
#  Dòng dư nợ: thêm r[30]=custtpnm, r[31]=custdtltpnm (r[27], r[28] đã dùng cho TSBĐ khi sửa tay).
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P05/build_p05_hm25.py
import hashlib
SRC = 'app/QLTDPRO_v24.17.28.html'; DST = 'app/QLTDPRO_v24.17.29.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:90]); s = s.replace(old, new)
QD = '(window.QLTD_laDN?window.QLTD_laDN(t,b3):b3(t[1],t[0]))'
# gd24: hàm nhận diện DN dùng chung
rep('  window.QLTDCB = { version: "1.0.0",', '''  /* HM-25: khách hàng doanh nghiệp — theo cột custtpnm (r[30]); chưa có cột ⇒ theo tên (b3 của bundle) */
  window.QLTD_laDN = function (r, b3) {
    var t = String(r && r[30] != null ? r[30] : "").trim();
    if (t) return !/(^|\\s)(ca nhan|ho gia dinh|ho ca the|ca the)(\\s|$)/.test(norm(t));
    return b3 ? !!b3(r && r[1], r && r[0]) : false;
  };
  window.QLTD_coCotDN = function (r) { return !!String(r && r[30] != null ? r[30] : "").trim(); };
  window.QLTDCB = { version: "1.0.0",''')
# bộ đọc msit80: thêm 2 cột
rep('lstrpmtdt:n("lstrpmtdt")};if(a.brcd<0||a.custnm<0)', 'lstrpmtdt:n("lstrpmtdt"),custtpnm:n("custtpnm"),custdtltpnm:n("custdtltpnm")};if(a.brcd<0||a.custnm<0)')
rep('Br(String(h[a.lstrpmtdt]||"").trim())])}let s=0,l=0;', 'Br(String(h[a.lstrpmtdt]||"").trim()),null,null,null,a.custtpnm>=0?String(h[a.custtpnm]||"").trim():"",a.custdtltpnm>=0?String(h[a.custdtltpnm]||"").trim():""])}let s=0,l=0;')
# Chỉ tiêu kế hoạch: Dư nợ DN cùng nhận diện
rep('b3(c[1],c[0])&&(i.duNoDN+=u)', '(window.QLTD_laDN?window.QLTD_laDN(c,b3):b3(c[1],c[0]))&&(i.duNoDN+=u)')
# menu + đếm + định tuyến
rep('Ge("du-no","trung-dai-han","Trung-dài hạn",["td","tieu-dung"]),', 'Ge("du-no","trung-dai-han","Trung-dài hạn",["td","tieu-dung"]),Ge("du-no","cho-vay-doanh-nghiep","Cho vay doanh nghiệp",["dn","doanh-nghiep","cong-ty"]),')
rep('"trung-dai-han":s(i.td),', '"trung-dai-han":s(i.td),"cho-vay-doanh-nghiep":s(e.filter(t=>' + QD + ').length),')
rep('g.slug==="trung-dai-han"?o.jsx(jp,{kind:"trung"}):', 'g.slug==="trung-dai-han"?o.jsx(jp,{kind:"trung"}):g.slug==="cho-vay-doanh-nghiep"?o.jsx(jp,{kind:"dn"}):')
# trang: dùng chung khung jp
rep('function jp({kind:e}){const t=$e(),n=t.qltd,r=D.useMemo(()=>e==="ngan"?O3(n):F3(n),[n,e])',
    'function QDN({rows:e,all:n}){const f=x=>Number(x[11])||0,lo={nh:0,th:0,dh:0,tc:0},kh=new Set;let tong=0,ten=0;e.forEach(t=>{const u=f(t);tong+=u;lo[x3(t[13])]+=u;kh.add(String(t[0]||"").trim());window.QLTD_coCotDN&&!window.QLTD_coCotDN(t)&&ten++});kh.delete("");const all=n.reduce((a,t)=>a+f(t),0),F=x=>le.num.fmt(x,0)+" đ";'
    'return o.jsxs("div",{className:"space-y-1 border-b bg-card px-3 py-2","data-testid":"dn-tong",children:[o.jsxs("div",{className:"grid grid-cols-2 gap-2 sm:grid-cols-5",children:['
    'o.jsx(Ao,{id:"dn-tytrong",label:"Tỷ trọng / dư nợ chi nhánh",value:(all?tong/all*100:0).toLocaleString("vi-VN",{maximumFractionDigits:2})+"%"}),'
    'o.jsx(Ao,{id:"dn-nh",label:"Ngắn hạn",value:F(lo.nh)}),o.jsx(Ao,{id:"dn-th",label:"Trung hạn",value:F(lo.th)}),o.jsx(Ao,{id:"dn-dh",label:"Dài hạn",value:F(lo.dh)}),o.jsx(Ao,{id:"dn-tc",label:"Thấu chi",value:F(lo.tc)})]}),'
    'o.jsx("div",{className:"text-xs text-muted-foreground","data-testid":"dn-nguon",children:"ⓘ Doanh nghiệp = cột Loại KH (custtpnm) của IPCAS khác Cá nhân / Hộ gia đình"+(ten?" · "+ten.toLocaleString("vi-VN")+" dòng chưa có cột (tệp cũ) → nhận theo tên KH như Chỉ tiêu kế hoạch":"")+". Khách hàng / Tổng dư nợ ở hàng trên = doanh nghiệp; thẻ theo bộ lọc Phòng / Cán bộ."})]})}'
    'function jp({kind:e}){const t=$e(),n=t.qltd,r=D.useMemo(()=>e==="ngan"?O3(n):e==="dn"?n.filter(t=>' + QD + '):F3(n),[n,e])')
rep('d=e==="ngan"?"ngan-han-thau-chi":"trung-dai-han";return t.state', 'd=e==="ngan"?"ngan-han-thau-chi":e==="dn"?"cho-vay-doanh-nghiep":"trung-dai-han";return t.state')
rep('children:[a.ui,o.jsx(Xn,{id:d,data:i,cols:pi,', 'children:[a.ui,e==="dn"&&o.jsx(QDN,{rows:i,all:n}),o.jsx(Xn,{id:d,data:i,cols:e==="dn"?pi.concat([{id:"loaikh",label:"Loại KH (IPCAS)",kind:"text",width:150,get:t=>t[31]||t[30]||""}]):pi,')
rep('exportName:e==="ngan"?"Ngan_han_thau_chi":"Trung_dai_han"', 'exportName:e==="ngan"?"Ngan_han_thau_chi":e==="dn"?"Cho_vay_doanh_nghiep":"Trung_dai_han"')
rep('emptyText:e==="ngan"?"Không có khoản vay ngắn hạn / thấu chi.":"Không có khoản vay trung-dài hạn."', 'emptyText:e==="ngan"?"Không có khoản vay ngắn hạn / thấu chi.":e==="dn"?"Không có khoản vay doanh nghiệp.":"Không có khoản vay trung-dài hạn."')
# gd7: bố cục bảng như Ngắn hạn
rep("'ngan-han-thau-chi':{ lead: DU, pin:['tenkh','cbtd','ngaytra'], sort:[{id:'ngaygn',desc:false}], show: DU },",
    "'ngan-han-thau-chi':{ lead: DU, pin:['tenkh','cbtd','ngaytra'], sort:[{id:'ngaygn',desc:false}], show: DU },\n  'cho-vay-doanh-nghiep':{ lead: DU.concat(['loaikh']), pin:['tenkh','cbtd','ngaytra'], sort:[{id:'ngaygn',desc:false}], show: DU.concat(['loaikh']) },")
c = s.count('"24.17.28"'); assert c == 2, c
s = s.replace('"24.17.28"', '"24.17.29"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.28' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.28', '24.17.29'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
