/* gd24 1.0.0 — HM-21 (P05, 06/11/2026) — Thứ tự cán bộ dùng chung cho MỌI trang, GIỐNG tab Báo cáo ngày.
 * Báo cáo ngày (Chỉ tiêu kế hoạch) xếp: Phòng KH (Hội Sở) → PGD HBT → PGD Số 2; trong phòng theo danh mục cán bộ
 * (Hệ thống → danh mục cán bộ; nếu chưa khai báo: tự học từ dữ liệu, như app). window.QLTDCB.cmp(a, b) so 2 tên
 * (cán bộ HOẶC phòng): tên có trong danh mục theo thứ tự danh mục; tên lạ sau, theo bảng chữ cái tiếng Việt;
 * ô trống / "(chưa có …)" cuối cùng. Ưu tiên đúng danh mục mà Báo cáo ngày vừa dựng (bundle ghi window.__qltdRosterBC).
 * Chỉ đọc; không lưu gì. */
(function () {
  "use strict";
  var PB = [["hoi so", "phong khach hang", "phong kh", "hoiso"], ["pgd hai ba trung", "pgd hbt", "hai ba trung", "hbt"], ["pgd so 2", "so 2", "s2"]];
  var COL = typeof Intl !== "undefined" ? new Intl.Collator("vi", { sensitivity: "base" }) : null;
  function norm(x) {
    return String(x == null ? "" : x).normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D")
      .toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
  }
  function rankPhong(n) {
    for (var i = 0; i < PB.length; i++) if (PB[i].indexOf(n) >= 0) return i;
    for (i = 0; i < PB.length; i++) for (var j = 0; j < 3 && j < PB[i].length; j++) if (PB[i][j].length > 4 && n.indexOf(PB[i][j]) >= 0) return i;
    return -1;
  }
  var cache = { key: null, map: null, list: [] };
  function rosterBC() {
    var R = window.__qltdRosterBC;
    if (R && typeof R.members === "function") return R;
    var T = window.TD && window.TD.roster; if (!T) return null;
    var txt = ""; try { txt = localStorage.getItem(T.KEY) || ""; } catch (e) {}
    var rows = (window.__GD7S && window.__GD7S.qltd) || [];
    var cfg = txt ? T.parse(txt).cfg : T.empty(), eff = T.effective(cfg, rows);
    return { members: function (pb) { var c = T.norm(pb), h = eff.cfg.pbs.filter(function (d) { return T.norm(d.pb) === c; })[0]; return h ? h.members : []; }, _own: 1 };
  }
  function build() {
    var R = window.__qltdRosterBC, txt = ""; try { txt = localStorage.getItem("td_roster_v1") || ""; } catch (e) {}
    var rows = window.__GD7S && window.__GD7S.qltd;
    var key = [R, rows, txt];
    if (cache.key && cache.key[0] === key[0] && cache.key[1] === key[1] && cache.key[2] === key[2]) return cache;
    var map = Object.create(null), list = [], ro = rosterBC();
    var T = window.TD && window.TD.roster, PBN = T ? T.PB_ORDER : ["Hội Sở", "PGD Hai Bà Trưng", "PGD Số 2"];
    if (ro) PBN.forEach(function (pb, pi) {
      (ro.members(pb) || []).forEach(function (m) { var n = norm(m.name); if (n && map[n] == null) { map[n] = list.length; list.push({ name: m.name, phong: pb, pi: pi }); } });
    });
    cache = { key: key, map: map, list: list };
    return cache;
  }
  function trong(n) { return !n || /^chua co|^khong ro|^khong ghi|^n a$/.test(n); }
  function rank(x) {
    var n = norm(x); if (trong(n)) return 3e6;
    var p = rankPhong(n); if (p >= 0) return p;
    var c = build().map[n]; return c == null ? 2e6 : 1000 + c;
  }
  function cmp(a, b) {
    var ra = rank(a), rb = rank(b);
    if (ra !== rb) return ra - rb;
    if (ra === 2e6 || ra === 3e6) { var sa = String(a == null ? "" : a), sb = String(b == null ? "" : b); return COL ? COL.compare(sa, sb) : sa < sb ? -1 : sa > sb ? 1 : 0; }
    return 0;
  }
  /* ngày → số để sắp cũ → mới (yyyy-mm-dd, dd/mm/yyyy, Date); trống/lỗi → +∞ (cuối) */
  function ngay(x) {
    if (x instanceof Date) return isNaN(+x) ? Infinity : +x;
    var t = String(x == null ? "" : x).trim(), m = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(t);
    if (m) return +m[1] * 1e4 + +m[2] * 100 + +m[3];
    m = /^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})/.exec(t);
    return m ? +m[3] * 1e4 + +m[2] * 100 + +m[1] : Infinity;
  }
  function cuMoi(a, b) { var x = ngay(a), y = ngay(b); return x === y ? 0 : x === Infinity ? 1 : y === Infinity ? -1 : x - y; }
  window.QLTDCB = { version: "1.0.0", cmp: cmp, ngay: ngay, cuMoi: cuMoi, rank: rank, norm: norm, thuTu: function () { return build().list.slice(); },
    /* so khóa ghép "phòng\u0001cán bộ" */
    cmp2: function (a, b) { var x = String(a).split("\u0001"), y = String(b).split("\u0001"); return cmp(x[0], y[0]) || cmp(x[1], y[1]); } };
})();
