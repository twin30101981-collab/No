# P05 · HM-26 · v24.17.30 — người dùng 06/11: trang Khách hàng mới — khách vay MỚI, KHÔNG cầm cố, mà KHÔNG có tài sản nhập trong kỳ
#  → nhãn tím "TS trước kỳ" thay chữ "mới". Quy tắc (người dùng chốt lại 06/11): khách có ≥1 TS trong sao kê TSBĐ (theo mã KH) với ngày thế chấp (plgdt) < ngày đầu kỳ ⇒ "TS trước kỳ"
#  (kể cả khi còn TS khác thế chấp trong kỳ)
#  (TS không có ngày: coi là trước kỳ nếu đã có trong sao kê đầu kỳ). Không có TS / không nạp sao kê → giữ "mới". Số đếm KH mới không đổi.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P05/build_p05_hm26.py
import hashlib
SRC = 'app/QLTDPRO_v24.17.29.html'; DST = 'app/QLTDPRO_v24.17.30.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:90]); s = s.replace(old, new)
rep('B=A.tsbdCuoi.concat(A.tsbdDau||[]),',
    'B=A.tsbdCuoi.concat(A.tsbdDau||[]),__tk=(function(){var m=new Map,dau=new Set((A.tsbdDau||[]).map(function(W){return a(W.clno).trim()}));'
    '(A.tsbdCuoi||[]).forEach(function(W){var c=a(W.clcustno).trim();if(!c)return;var d=s(W.plgdt),x=m.get(c)||{n:0,truoc:0};x.n++;'
    '(d?d<k:dau.has(a(W.clno).trim()))&&x.truoc++;m.set(c,x)});return function(c){var x=m.get(c);return!!x&&x.truoc>0}})(),')
rep('camCoKXD:!!W.__tt&&ne&&!O.has(re)&&!__oh.has(re)}', 'camCoKXD:!!W.__tt&&ne&&!O.has(re)&&!__oh.has(re),tsTruocKy:ne&&!(O.has(re)||(!!W.__tt&&__oh.has(re)))&&__tk(re)}')
rep('L.khMoi&&o.jsx("span",{className:"ml-1 rounded bg-success/15 px-1 text-success",children:"mới"})',
    'L.khMoi&&(L.tsTruocKy?o.jsx("span",{className:"ml-1 rounded px-1 font-semibold",style:{background:"#ede4ff",color:"#5b21b6"},"data-testid":"khm-ts-truoc",'
    'title:"Khách vay mới, không cầm cố, đã có tài sản bảo đảm thế chấp TRƯỚC kỳ báo cáo",children:"TS trước kỳ"})'
    ':o.jsx("span",{className:"ml-1 rounded bg-success/15 px-1 text-success",children:"mới"}))')
c = s.count('"24.17.29"'); assert c == 2, c
s = s.replace('"24.17.29"', '"24.17.30"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.29' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.29', '24.17.30'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
