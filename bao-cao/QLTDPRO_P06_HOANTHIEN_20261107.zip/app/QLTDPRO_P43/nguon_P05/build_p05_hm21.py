# P05 · HM-21 · v24.17.27 — người dùng 06/11 ("Cả hai"): MỌI trang xếp cán bộ theo phòng GIỐNG Báo cáo ngày
#  (Phòng KH → PGD HBT → PGD Số 2; trong phòng theo danh mục cán bộ) + danh sách dòng mặc định ngày cũ → mới.
#  Lớp mới gd24 (window.QLTDCB.cmp / cuMoi) chạy TRƯỚC bundle; bundle ghi danh mục Báo cáo ngày vừa dựng vào window.__qltdRosterBC.
#  + (người dùng 06/11) gd24-css: mọi ô chọn (dropdown) chữ xanh đậm, đổ bóng nhẹ, ô lọc đang chọn màu hổ phách.
#  Bảng XẾP HẠNG (cột #, Top KH, "CBTD (top 8)", Excel "Theo CBTD") giữ thứ tự theo số tiền — có chủ đích.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P05/build_p05_hm21.py
import hashlib
SRC = 'app/QLTDPRO_v24.17.26.html'; DST = 'app/QLTDPRO_v24.17.27.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:90]); s = s.replace(old, new)
Q = 'window.QLTDCB'
# --- lớp gd24 trước gd7 (gd7 phần 1 chạy trước bundle) ---
rep('<script id="gd7-js">', '<style id="gd24-css">\n' + open('nguon_P05/gd24.css', encoding='utf-8').read() + '</style>\n<script id="gd24-js">\n' + open('nguon_P05/gd24.js', encoding='utf-8').read() + '\n</script>\n<script id="gd7-js">')
# --- bundle ---
# B0 danh mục Báo cáo ngày (Wv) → window.__qltdRosterBC
rep('function Wv(e,t,n){const r=le.roster,', 'function Wv(e,t,n){const __r=Wv0(e,t,n);try{window.__qltdRosterBC=__r}catch{}return __r}function Wv0(e,t,n){const r=le.roster,')
# B1 bộ lọc phạm vi dùng chung sc-pb / sc-cb (Tất cả dư nợ, Ngắn hạn, Trung-dài hạn, Cảnh báo sớm, Nợ đến hạn, Lãi đọng, Chuyển HM, Giải ngân…)
rep('[...n.entries()].sort((r,a)=>r[0].localeCompare(a[0],"vi"))}', '[...n.entries()].sort((r,a)=>' + Q + '?' + Q + '.cmp(r[0],a[0]):r[0].localeCompare(a[0],"vi"))}')
# B2 bảng dữ liệu: "Gom Phòng → Cán bộ"
rep('g=r&&n.group==="pb-cb"?[xc(r.pb),xc(r.cb)]:null;', 'g=r&&n.group==="pb-cb"?[r.pb,r.cb].map(c=>' + Q + '?(x,y)=>' + Q + '.cmp(c.get(x),c.get(y)):xc(c)):null;')
# B3 Chuyển hạn mức (cán bộ trong phòng)
rep('hp(c.pb)-hp(h.pb)||up.compare(c.pb,h.pb)||up.compare(c.cbtd,h.cbtd)', 'hp(c.pb)-hp(h.pb)||up.compare(c.pb,h.pb)||(' + Q + '?' + Q + '.cmp(c.cbtd,h.cbtd):up.compare(c.cbtd,h.cbtd))')
# B4 Khách hàng mới: phòng → cán bộ → ngày GN cũ → mới
rep('$.sort(function(W,U){return l(W.phong,U.phong)||l(W.cbtd,U.cbtd)||l(W.dsbsdt,U.dsbsdt)})', '$.sort(function(W,U){var C=' + Q + ';return C?C.cmp(W.phong,U.phong)||C.cmp(W.cbtd,U.cbtd)||l(W.dsbsdt,U.dsbsdt):l(W.phong,U.phong)||l(W.cbtd,U.cbtd)||l(W.dsbsdt,U.dsbsdt)})')
rep('var H=Array.from(P.entries()).sort(function(W,U){return l(W[0],U[0])})', 'var H=Array.from(P.entries()).sort(function(W,U){return ' + Q + '?' + Q + '.cmp(W[0],U[0]):l(W[0],U[0])})')
rep('var re=Array.from(U.entries()).sort(function(ne,se){return l(ne[0],se[0])})', 'var re=Array.from(U.entries()).sort(function(ne,se){return ' + Q + '?' + Q + '.cmp(ne[0].split("\\0")[0],se[0].split("\\0")[0])||l(ne[0],se[0]):l(ne[0],se[0])})')
rep('z=Array.from(new Set(_.map(q).concat(j.map(q)))).sort(l)', 'z=Array.from(new Set(_.map(q).concat(j.map(q)))).sort(' + Q + '?' + Q + '.cmp:l)')
rep('G=Array.from(new Set(ee.loans.map(L=>L.cbtd))).sort()', 'G=Array.from(new Set(ee.loans.map(L=>L.cbtd))).sort(' + Q + '?' + Q + '.cmp:void 0)')
# B5 Giải ngân: thêm món thủ công — danh sách cán bộ
rep('cbs:[...new Set(t.map(S=>String(S[12]||"").trim()).filter(Boolean))].sort()', 'cbs:[...new Set(t.map(S=>String(S[12]||"").trim()).filter(Boolean))].sort(' + Q + '?' + Q + '.cmp:void 0)')
# B6 Trả nợ / xuất TS: ô chọn cán bộ + phòng
rep('g=D.useMemo(()=>[...new Set(t.map(x=>String(x[12]||"").trim()).filter(Boolean))].sort((x,S)=>x.localeCompare(S,"vi")),[t]),f=D.useMemo(()=>[...new Set(t.map(x=>String(x[17]||"").trim()).filter(Boolean))].sort((x,S)=>x.localeCompare(S,"vi")),[t])',
    'g=D.useMemo(()=>[...new Set(t.map(x=>String(x[12]||"").trim()).filter(Boolean))].sort((x,S)=>' + Q + '?' + Q + '.cmp(x,S):x.localeCompare(S,"vi")),[t]),f=D.useMemo(()=>[...new Set(t.map(x=>String(x[17]||"").trim()).filter(Boolean))].sort((x,S)=>' + Q + '?' + Q + '.cmp(x,S):x.localeCompare(S,"vi")),[t])')
# B7 Tài sản bảo đảm: lọc cán bộ
rep('cbtd:Array.from(new Set(N.map(z=>z.cbtd).filter(Boolean))).sort((z,E)=>z.localeCompare(E,"vi"))', 'cbtd:Array.from(new Set(N.map(z=>z.cbtd).filter(Boolean))).sort((z,E)=>' + Q + '?' + Q + '.cmp(z,E):z.localeCompare(E,"vi"))')
# --- gd7 (Tổng quan) ---
rep("optList(Object.keys(pbs).sort().map(", "optList(Object.keys(pbs).sort(window.QLTDCB ? window.QLTDCB.cmp : undefined).map(")
rep("optList(Object.keys(cbs).sort(function(a, b){ return a.localeCompare(b, 'vi'); }).map(", "optList(Object.keys(cbs).sort(function(a, b){ return window.QLTDCB ? window.QLTDCB.cmp(a, b) : a.localeCompare(b, 'vi'); }).map(")
rep("optList(Object.keys(cbsAll).sort().map(", "optList(Object.keys(cbsAll).sort(window.QLTDCB ? window.QLTDCB.cmp : undefined).map(")
rep("Object.keys(tree).sort(function(a, b){ return sumDN(tree[b].rows) - sumDN(tree[a].rows); })", "Object.keys(tree).sort(function(a, b){ return window.QLTDCB ? window.QLTDCB.cmp(a, b) : sumDN(tree[b].rows) - sumDN(tree[a].rows); })")
rep("Object.keys(P.cb).sort(function(a, b){ return sumDN(P.cb[b].rows) - sumDN(P.cb[a].rows); })", "Object.keys(P.cb).sort(function(a, b){ return window.QLTDCB ? window.QLTDCB.cmp(a, b) : sumDN(P.cb[b].rows) - sumDN(P.cb[a].rows); })")
rep("Object.keys(m).sort().forEach(function(k){\n    var rs = m[k], p = k.split('\\u0001')", "Object.keys(m).sort(window.QLTDCB ? window.QLTDCB.cmp2 : undefined).forEach(function(k){\n    var rs = m[k], p = k.split('\\u0001')")
rep("Object.keys(m).sort(function(a, b){ return (m[b].cur - m[b].prev) - (m[a].cur - m[a].prev); })", "Object.keys(m).sort(function(a, b){ var C = window.QLTDCB; return C ? C.cmp(m[a].pb, m[b].pb) || C.cmp(a, b) : (m[b].cur - m[b].prev) - (m[a].cur - m[a].prev); })")
# --- gd15 (Khách hàng mới · Đối soát; Excel) ---
P = "String(a.phong).localeCompare(String(b.phong),'vi')"
rep(P, "(window.QLTDCB?window.QLTDCB.cmp(a.phong,b.phong):" + P + ")", 4)
C = "String(a.cbTen||a.cbMa).localeCompare(String(b.cbTen||b.cbMa),'vi')"
#  ô Lọc cán bộ (khi "Tất cả phòng"): Phòng → Cán bộ như bảng
rep("R.canBo.filter(function(c){return !sp.value||c.phong===sp.value})\n    .sort(function(a,b){return " + C + "})", "R.canBo.filter(function(c){return !sp.value||c.phong===sp.value})\n    .sort(function(a,b){return window.QLTDCB?window.QLTDCB.cmp(a.phong,b.phong)||window.QLTDCB.cmp(a.cbTen||a.cbMa,b.cbTen||b.cbMa)||" + C + ":" + C + "})")
rep("R.canBo.filter(function(c){return c.phong===p.phong}).sort(function(a,b){return " + C, "R.canBo.filter(function(c){return c.phong===p.phong}).sort(function(a,b){return (window.QLTDCB?window.QLTDCB.cmp(a.cbTen||a.cbMa,b.cbTen||b.cbMa)||" + C + ":" + C + ")")
M = "String(a.cbMa).localeCompare(String(b.cbMa),'vi')"
rep(M, "(window.QLTDCB?window.QLTDCB.cmp(a.cbTen||a.cbMa,b.cbTen||b.cbMa)||" + M + ":" + M + ")", 2)
rep("R.phong.map(function(p){return p.phong}).sort(function(a,b){return String(a).localeCompare(String(b),'vi')})", "R.phong.map(function(p){return p.phong}).sort(function(a,b){return window.QLTDCB?window.QLTDCB.cmp(a,b):String(a).localeCompare(String(b),'vi')})")
#  chi tiết khi bấm số: ngày GN cũ → mới (trước: số tiền giảm dần)
rep(".sort(function(a,b){return giaTri(b,k)-giaTri(a,k)||String(a.custnm).localeCompare(String(b.custnm),'vi')});", ".sort(function(a,b){return (window.QLTDCB?window.QLTDCB.cuMoi(a.dsbsdt,b.dsbsdt):0)||giaTri(b,k)-giaTri(a,k)||String(a.custnm).localeCompare(String(b.custnm),'vi')});")
# --- gd23 (Tài sản bảo đảm: 2 tab mới) ---
rep('return Object.keys(m).sort(function (a, b) { return a.localeCompare(b, "vi"); }).map(function (p) { return { p: p, cbs: Object.keys(m[p]).sort(function (a, b) { return a.localeCompare(b, "vi"); }) }; });',
    'var C = window.QLTDCB, so = function (a, b) { return C ? C.cmp(a, b) : a.localeCompare(b, "vi"); };\n    return Object.keys(m).sort(so).map(function (p) { return { p: p, cbs: Object.keys(m[p]).sort(so) }; });')
rep('function chiTiet(host, tieuDe, items, extraCol, ten) {\n    var old = host.querySelector(".gd23-ct"); if (old) old.remove();',
    'function chiTiet(host, tieuDe, items, extraCol, ten) {\n    if (window.QLTDCB) items = items.slice().sort(function (a, b) { return window.QLTDCB.cuMoi(a.r.ngayTheChap, b.r.ngayTheChap); }); /* HM-21: ngày thế chấp cũ → mới */\n    var old = host.querySelector(".gd23-ct"); if (old) old.remove();')
# --- phiên bản ---
c = s.count('"24.17.26"'); assert c == 2, c
s = s.replace('"24.17.26"', '"24.17.27"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.26' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.26', '24.17.27'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
