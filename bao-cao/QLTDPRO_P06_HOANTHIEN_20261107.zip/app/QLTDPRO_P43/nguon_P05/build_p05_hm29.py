# P05 · HM-29 · v24.17.33 — người dùng 07/11: ô "Dữ liệu ngày … ▾" thành hộp chọn MỌI mốc msit80 đã nhập ⇒ xem toàn app tại mốc (chỉ xem)
#  + "So với mốc" cũ hơn; không phải nhập lại ở Trung tâm nhập dữ liệu. F5 ⇒ về dữ liệu hiện hành (người dùng chọn).
#  Lớp gd25 (trước bundle) + các điểm nối nhỏ trong bundle/gd11. Không đổi dữ liệu, không đổi schema.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P05/build_p05_hm29.py
import hashlib
SRC = 'app/QLTDPRO_v24.17.32.html'; DST = 'app/QLTDPRO_v24.17.33.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:90]); s = s.replace(old, new)
VW = 'window.__qltdView'
rep('<script id="gd7-js">', '<style id="gd25-css">\n' + open('nguon_P05/gd25.css', encoding='utf-8').read() + '</style>\n<script id="gd25-js">\n' + open('nguon_P05/gd25.js', encoding='utf-8').read() + '\n</script>\n<script id="gd7-js">')
# ngày dữ liệu đọc qua kho ảo khi đang xem mốc
rep('t.dataDate=a,typeof we<"u"', 't.dataDate=a,' + VW + '&&(a._store=' + VW + '.store),typeof we<"u"')
# danh sách mốc Lưu trữ: chỉ mốc ≤ mốc đang xem; chặn ghi khi đang xem
rep('function ba(){try{const e=JSON.parse(Ut.get(Uv)||"[]");return Array.isArray(e)?e:[]}', 'function ba(){try{const e=JSON.parse(Ut.get(Uv)||"[]");return Array.isArray(e)?(' + VW + '?' + VW + '.loc(e):e):[]}')
rep('function q0(e){Ut.set(Uv,', 'function q0(e){if(' + VW + '){' + VW + '.chan("danh sách mốc Lưu trữ");return}Ut.set(Uv,')
rep("try{var a=JSON.parse(localStorage.getItem(ARC_LIST)||'[]');return Array.isArray(a)?a.filter(function(x){return x&&x.type==='report'}):[]}",
    "try{var a=JSON.parse(localStorage.getItem(ARC_LIST)||'[]');a=Array.isArray(a)?a.filter(function(x){return x&&x.type==='report'}):[];return window.__qltdView?window.__qltdView.loc(a):a}")
# kho dư nợ: thay bằng dòng của mốc + chỉ xem
rep('result:await e0(H),error:""', 'result:await (window.__qltdViewLoad?window.__qltdViewLoad(e0(H)):e0(H)),error:""')
rep('readAll:async()=>{const H=await cr();try{return await e0(H)}finally', 'readAll:async()=>{const H=await cr();try{return await (window.__qltdViewLoad?window.__qltdViewLoad(e0(H)):e0(H))}finally')
# hai chỗ đọc thẳng _currentFileDate
rep('d=D.useMemo(()=>{try{return localStorage.getItem("_currentFileDate")}catch{return null}},[])', 'd=D.useMemo(()=>{try{return ' + VW + '?' + VW + '.dd:localStorage.getItem("_currentFileDate")}catch{return null}},[])')
rep('c=(i6("_currentFileDate")||"").trim()', 'c=((' + VW + '?' + VW + '.dd:i6("_currentFileDate"))||"").trim()')
# ô ngày: chữ + gợi ý
rep('return t?{text:"Dữ liệu ngày "+le.dataDate.vn(t),tone:"ok"}', 'return t?{text:(' + VW + '?"👁 Mốc ":"Dữ liệu ngày ")+le.dataDate.vn(t)+(' + VW + '?" · chỉ xem":""),tone:' + VW + '?"warn":"ok"}')
rep('title:"Dữ liệu đang xem — bấm để xem các kỳ đã lưu"', 'title:"Bấm để chọn mốc dữ liệu (msit80 đã nhập) để xem và so sánh với mốc cũ hơn"')
c = s.count('"24.17.32"'); assert c == 2, c
s = s.replace('"24.17.32"', '"24.17.33"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.32' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.32', '24.17.33'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
