# P05 · HM-21b · v24.17.28 — người dùng 06/11 (ảnh 8 trang): DÒNG dữ liệu ở mọi bảng mặc định xếp theo cán bộ
#  (thứ tự danh mục như Báo cáo ngày: Phòng KH → PGD HBT → PGD Số 2, trong phòng theo danh mục), trong mỗi cán bộ ngày cũ → mới.
#  - gd7.tdef: mọi bảng có cột Cán bộ (cbtd / cb) → sort mặc định = [Cán bộ ↑] + sort ngày sẵn có; cờ l21.
#  - gd7.tload: bố cục đã lưu chưa có l21 → CHỈ thay sort bằng mặc định mới một lần (giữ cột, độ rộng, lọc).
#  - bảng dùng chung: khóa dòng duy nhất (sửa dòng chồng chữ ở Nợ đến hạn / Lãi đọng sau khi cuộn).
#  - bundle xc: sắp theo cột Cán bộ dùng QLTDCB.cmp (thứ tự danh mục), không theo chữ cái.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P05/build_p05_hm21b.py
import hashlib
SRC = 'app/QLTDPRO_v24.17.27.html'; DST = 'app/QLTDPRO_v24.17.28.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:90]); s = s.replace(old, new)
rep("  if (id === 'tai-san-bao-dam') def.l22 = 1;\n  }\n  defs[id] = def;",
    "  if (id === 'tai-san-bao-dam') def.l22 = 1;\n  }\n"
    "  /* HM-21b: dòng xếp theo cán bộ (danh mục như Báo cáo ngày) rồi ngày cũ → mới */\n"
    "  var cbId = has('cbtd') ? 'cbtd' : has('cb') ? 'cb' : null;\n"
    "  if (cbId){ var so = (def.sort || []).filter(function(x){ return x.id !== cbId; }); def.sort = [{id:cbId, desc:false}].concat(so); }\n"
    "  def.l21 = 1;\n  defs[id] = def;")
rep("  if (ok && id === 'tai-san-bao-dam' && !ok.l22) ok = null;",
    "  if (ok && id === 'tai-san-bao-dam' && !ok.l22) ok = null;\n"
    "  if (ok && !ok.l21 && defs[id]){ var o2 = {}; for (var k2 in ok) o2[k2] = ok[k2]; o2.sort = (defs[id].sort || []).slice(); o2.l21 = 1; ok = o2; } /* HM-21b: sort mới áp một lần, giữ cột/độ rộng/lọc */")
rep('function xc(e){return(t,n)=>{const r=e.get(t),a=e.get(n),i=r==null||r==="",s=a==null||a==="";if(i||s)return i&&s?0:i?1:-1;',
    'function xc(e){return(t,n)=>{const r=e.get(t),a=e.get(n),i=r==null||r==="",s=a==null||a==="";if(i||s)return i&&s?0:i?1:-1;if((e.id==="cbtd"||e.id==="cb")&&window.QLTDCB)return window.QLTDCB.cmp(r,a);')
# Lỗi nền phát hiện khi kiểm ảnh: Nợ đến hạn / Lãi đọng dùng rowKey F.key KHÔNG duy nhất (1 khoản nhiều dòng) → React giữ dòng cũ khi cuộn
#  (dòng chồng chữ). Bảng dùng chung: khóa = rowKey + vị trí dòng → luôn duy nhất.
rep('},e.rowKey?e.rowKey(me,ge):V.index)}', '},e.rowKey?e.rowKey(me,ge)+"|"+ge:V.index)}')
c = s.count('"24.17.27"'); assert c == 2, c
s = s.replace('"24.17.27"', '"24.17.28"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.27' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.27', '24.17.28'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
