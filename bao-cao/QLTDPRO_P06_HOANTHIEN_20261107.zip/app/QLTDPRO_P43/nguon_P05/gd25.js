/* gd25 1.0.0 — HM-29 (P05, 07/11/2026) — "Xem tại mốc" + "So với mốc" từ ô "Dữ liệu ngày … ▾".
 * Bấm ô ngày → danh sách mọi mốc msit80 đã nhập (Lưu trữ). Chọn mốc → tải lại trang MỘT lần với cờ dùng-một-lần (sessionStorage):
 *  - kho dư nợ đọc từ mốc (IndexedDB TWIN_Archive_v1/reportData) thay vì dữ liệu hiện hành, chế độ CHỈ XEM (readOnlyReason sẵn có ⇒ mọi lệnh lưu bị chặn);
 *  - ngày dữ liệu = ngày mốc (TD.dataDate đọc qua kho ảo, không ghi localStorage);
 *  - danh sách mốc Lưu trữ chỉ gồm mốc ≤ mốc đang xem ⇒ mọi phép so sánh (Δ, đầu kỳ…) chỉ lùi về quá khứ; ghi danh sách mốc bị chặn.
 * F5 / "Về dữ liệu hiện hành" / vào trang Nhập dữ liệu ⇒ về dữ liệu hiện hành (người dùng chọn 07/11). Không đổi dữ liệu nào.
 * "So với mốc": bảng chênh lệch chỉ tiêu chính giữa dữ liệu đang xem và một mốc cũ hơn. Dựng DOM bằng textContent. */
(function () {
  "use strict";
  var KEY1 = "qltd_xem_moc_1lan", KEYERR = "qltd_xem_moc_loi", LS = window.localStorage;
  function lsGet(k) { try { return LS.getItem(k); } catch (e) { return null; } }
  function dk(vn) { var m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})/.exec(String(vn || "").trim()); return m ? (+m[3]) * 1e4 + (+m[2]) * 100 + (+m[1]) : 0; }
  function arcAll() { try { var a = JSON.parse(lsGet("_archiveReportList") || "[]"); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
  function toast(m) { try { if (window.gd9Toast) window.gd9Toast(m, true); else console.warn(m); } catch (e) {} }
  function E(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  var V = null;
  try { var raw = sessionStorage.getItem(KEY1); if (raw) { sessionStorage.removeItem(KEY1); V = JSON.parse(raw); } } catch (e) { V = null; }
  if (V && dk(V.dayKey)) {
    var LIM = dk(V.dayKey), RO = { "_currentFileDate": V.dayKey, "td_datemode": "data" };
    var store = {
      getItem: function (k) { return Object.prototype.hasOwnProperty.call(RO, k) ? RO[k] : LS.getItem(k); },
      setItem: function (k, v) { if (!Object.prototype.hasOwnProperty.call(RO, k)) LS.setItem(k, v); },
      removeItem: function (k) { if (!Object.prototype.hasOwnProperty.call(RO, k)) LS.removeItem(k); }
    };
    window.__qltdView = {
      dayKey: V.dayKey, meta: V, store: store, dd: V.dayKey,
      loc: function (list) { return (list || []).filter(function (m) { if (!m || m.type !== "report") return true; var d = dk(m.dayKey); return d && d <= LIM; }); },
      chan: function (what) { toast("Đang xem mốc " + V.dayKey + " (chỉ xem) — không ghi " + (what || "") + ". Bấm \"Về dữ liệu hiện hành\" để sửa."); }
    };
  } else V = null;

  function docMoc(m) {
    return new Promise(function (res) {
      try {
        var rq = indexedDB.open("TWIN_Archive_v1"), moi = false; /* KHÔNG tạo CSDL nếu chưa có (huỷ nâng cấp như zv() của app) */
        rq.onupgradeneeded = function () { moi = true; try { rq.transaction.abort(); } catch (e) {} };
        rq.onerror = function () { res(null); }; rq.onblocked = function () { res(null); };
        rq.onsuccess = function () {
          var db = rq.result; if (moi) { db.close(); return res(null); }
          try {
            if (!db.objectStoreNames.contains("reportData")) { db.close(); return res(null); }
            var g = db.transaction("reportData", "readonly").objectStore("reportData").get("rpt_" + (m.timestamp || m.name));
            g.onsuccess = function () { db.close(); res(Array.isArray(g.result) ? g.result : null); };
            g.onerror = function () { db.close(); res(null); };
          } catch (e) { db.close(); res(null); }
        };
      } catch (e) { res(null); }
    });
  }
  /* provider gọi khi đọc kho: thay mảng dư nợ bằng dòng của mốc + chỉ xem */
  window.__qltdViewLoad = function (p) {
    return Promise.resolve(p).then(function (r) {
      if (!window.__qltdView || !r || !r.arrays) return r;
      return docMoc(V).then(function (rows) {
        if (!rows || !rows.length) { try { sessionStorage.setItem(KEYERR, V.dayKey); } catch (e) {} location.reload(); return new Promise(function () {}); }
        var a = {}, o = {}, k; for (k in r.arrays) a[k] = r.arrays[k]; a.qltd = rows;
        for (k in r) o[k] = r[k]; o.arrays = a; o.readOnlyReason = "Đang xem mốc " + V.dayKey + " (chỉ xem — về dữ liệu hiện hành để sửa/nhập)";
        return o;
      });
    });
  };

  /* ---------- danh sách mốc ---------- */
  function mocs() {
    var by = {};
    arcAll().forEach(function (m) { if (!m || m.type !== "report" || !dk(m.dayKey)) return; var o = by[m.dayKey]; if (!o || (m.timestamp || 0) > (o.timestamp || 0)) by[m.dayKey] = m; });
    return Object.keys(by).map(function (k) { return by[k]; }).sort(function (a, b) { return dk(b.dayKey) - dk(a.dayKey); });
  }
  function nhan(g) {
    if (!g) return ""; if (typeof g === "string") return g === "other" ? "Mốc khác" : g;
    var p2 = function (n) { return ("0" + n).slice(-2); };
    return g.kind === "year_end" ? "Cuối năm " + g.year : g.kind === "quarter" ? "Quý " + g.quarter + "/" + g.year : g.kind === "month" ? "T" + p2(g.month) + "/" + g.year : g.kind === "other" ? "Mốc khác" : "";
  }
  function hienHanh() { return lsGet("_currentFileDate") || ""; }
  function xem(m) {
    if (!m || m.dayKey === hienHanh()) { ve(); return; }
    try { sessionStorage.setItem(KEY1, JSON.stringify({ dayKey: m.dayKey, timestamp: m.timestamp || null, name: m.name || null })); } catch (e) { toast("Không mở được chế độ xem mốc: " + e.message); return; }
    location.reload();
  }
  function ve() { try { sessionStorage.removeItem(KEY1); } catch (e) {} if (window.__qltdView) location.reload(); else dong(); }

  /* ---------- so với mốc ---------- */
  function norm(x) { return String(x == null ? "" : x).normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase(); }
  function tenDN(name) { return /cong ty|tnhh|co phan|doanh nghiep|hop tac xa/.test(norm(name)); }
  function chiTieu(rows) {
    var o = { duno: 0, kh: 0, hs: 0, n25: 0, nh: 0, td: 0, tc: 0, dn: 0 }, kh = {};
    (rows || []).forEach(function (r) {
      if (!r) return; var v = Number(r[11]) || 0, l = String(r[13] || "");
      o.duno += v; o.hs++;
      var k = (window.TD && window.TD.metrics && window.TD.metrics.customerKey) ? window.TD.metrics.customerKey(r) : String(r[0] || "").trim(); if (k) kh[k] = 1;
      var g = /(\d)/.exec(String(r[18] || "")); if (g && +g[1] >= 2) o.n25 += v;
      if (/thấu\s*chi/i.test(l)) o.tc += v; else if (/trung\s*hạn|dài\s*hạn|tk\s*21[23]/i.test(l)) o.td += v; else if (/ngắn\s*hạn|tk\s*211/i.test(l)) o.nh += v;
      if (window.QLTD_laDN ? window.QLTD_laDN(r, function (n) { return tenDN(n); }) : tenDN(r[1])) o.dn += v;
    });
    o.kh = Object.keys(kh).length; return o;
  }
  var CT = [["duno", "Tổng dư nợ", 1], ["kh", "Số khách hàng", 0], ["hs", "Số khoản (dòng)", 0], ["nh", "Ngắn hạn", 1], ["td", "Trung-dài hạn", 1], ["tc", "Thấu chi", 1], ["dn", "Doanh nghiệp", 1], ["n25", "Dư nợ nhóm 2–5", 1]];
  function f(n) { return Math.round(n).toLocaleString("vi-VN"); }
  function soSanh(host, mB) {
    host.textContent = "Đang đọc mốc " + mB.dayKey + "…";
    docMoc(mB).then(function (rowsB) {
      host.textContent = "";
      if (!rowsB) { host.textContent = "Không đọc được dòng của mốc " + mB.dayKey + " trong Lưu trữ."; return; }
      var A = chiTieu((window.__GD7S && window.__GD7S.qltd) || []), B = chiTieu(rowsB), nA = (window.__qltdView ? window.__qltdView.dayKey : hienHanh());
      var t = E("table", "xm-t"); t.setAttribute("data-testid", "xm-so-t");
      var tr = E("tr"); ["Chỉ tiêu", "Đang xem " + nA, "Mốc " + mB.dayKey, "Tăng / giảm", "%"].forEach(function (h, i) { tr.appendChild(E("th", i ? "n" : "", h)); });
      var th = E("thead"); th.appendChild(tr); t.appendChild(th); var tb = E("tbody");
      CT.forEach(function (c) {
        var a = A[c[0]], b = B[c[0]], d = a - b, r = E("tr"); r.setAttribute("data-k", c[0]); r.setAttribute("data-a", String(Math.round(a))); r.setAttribute("data-b", String(Math.round(b)));
        r.appendChild(E("td", "", c[1])); r.appendChild(E("td", "n", f(a))); r.appendChild(E("td", "n", f(b)));
        r.appendChild(E("td", "n " + (d > 0 ? "xm-up" : d < 0 ? "xm-down" : ""), (d > 0 ? "+" : "") + f(d)));
        r.appendChild(E("td", "n", b ? ((d / b * 100).toLocaleString("vi-VN", { maximumFractionDigits: 2 }) + "%") : "—")); tb.appendChild(r);
      });
      t.appendChild(tb); var w = E("div", "xm-tw"); w.appendChild(t); host.appendChild(w);
      host.appendChild(E("div", "xm-note", "Doanh nghiệp: theo cột Loại KH (custtpnm); mốc cũ chưa có cột ⇒ theo tên KH."));
    });
  }

  /* ---------- giao diện ---------- */
  var pop = null;
  function dong() { if (pop) { pop.remove(); pop = null; } }
  function mo(chip) {
    dong();
    var cur = window.__qltdView ? window.__qltdView.dayKey : hienHanh(), L = mocs();
    pop = E("div", "xm-pop"); pop.setAttribute("data-testid", "xm-pop"); pop.setAttribute("role", "dialog");
    var hd = E("div", "xm-hd"); hd.appendChild(E("b", null, "📅 Chọn mốc dữ liệu để xem"));
    var x = E("button", "xm-x", "✕"); x.type = "button"; x.setAttribute("aria-label", "Đóng"); x.addEventListener("click", dong); hd.appendChild(x); pop.appendChild(hd);
    var hh = E("button", "xm-it" + (!window.__qltdView ? " xm-on" : ""), "● Dữ liệu hiện hành" + (hienHanh() ? " — " + hienHanh() : "")); hh.type = "button"; hh.setAttribute("data-testid", "xm-hien-hanh");
    hh.addEventListener("click", ve); pop.appendChild(hh);
    var ls = E("div", "xm-ls");
    L.forEach(function (m) {
      var b = E("button", "xm-it" + (window.__qltdView && m.dayKey === cur ? " xm-on" : "")); b.type = "button"; b.setAttribute("data-testid", "xm-moc"); b.setAttribute("data-day", m.dayKey);
      b.appendChild(E("span", "xm-d", m.dayKey));
      var sub = [], tl = nhan(m.tag); if (tl) sub.push(tl); if (m.customers) sub.push(Number(m.customers).toLocaleString("vi-VN") + " KH"); if (m.totalBalance) sub.push((m.totalBalance / 1e9).toLocaleString("vi-VN", { maximumFractionDigits: 2 }) + " tỷ");
      if (m.dayKey === hienHanh()) sub.push("= hiện hành");
      b.appendChild(E("span", "xm-s", sub.join(" · ")));
      b.addEventListener("click", function () { xem(m); }); ls.appendChild(b);
    });
    if (!L.length) ls.appendChild(E("div", "xm-note", "Chưa có mốc nào trong Lưu trữ — nhập tệp msit80 ở Trung tâm nhập dữ liệu."));
    pop.appendChild(ls);
    var cu = L.filter(function (m) { return dk(m.dayKey) < dk(cur); });
    var so = E("div", "xm-so"); so.appendChild(E("b", null, "↔ So với mốc cũ hơn"));
    var row = E("div", "xm-row"), sel = E("select"); sel.setAttribute("data-testid", "xm-so-sel");
    cu.forEach(function (m) { var o = E("option", null, m.dayKey); o.value = m.dayKey; sel.appendChild(o); });
    var go = E("button", "xm-btn", "So sánh"); go.type = "button"; go.setAttribute("data-testid", "xm-so-btn"); go.disabled = !cu.length;
    var out = E("div", "xm-out"); out.setAttribute("data-testid", "xm-so-out");
    go.addEventListener("click", function () { var m = cu.filter(function (z) { return z.dayKey === sel.value; })[0]; if (m) soSanh(out, m); });
    row.appendChild(sel); row.appendChild(go); so.appendChild(row); if (!cu.length) so.appendChild(E("div", "xm-note", "Không có mốc nào cũ hơn " + cur + "."));
    so.appendChild(out); pop.appendChild(so);
    var ft = E("a", "xm-ft", "Quản lý mốc ở Lưu trữ →"); ft.href = "#/luu-tru"; ft.addEventListener("click", dong); pop.appendChild(ft);
    document.body.appendChild(pop);
    var r = chip.getBoundingClientRect(), w = Math.min(460, window.innerWidth - 16);
    pop.style.width = w + "px"; pop.style.top = Math.round(r.bottom + 6) + "px"; pop.style.left = Math.round(Math.max(8, Math.min(r.left, window.innerWidth - w - 8))) + "px";
  }
  function banner() {
    if (!window.__qltdView || document.querySelector("[data-testid=xm-banner]")) return;
    var b = E("div", "xm-banner"); b.setAttribute("data-testid", "xm-banner"); b.setAttribute("role", "status");
    b.appendChild(E("span", null, "👁 Đang xem mốc " + V.dayKey + " — CHỈ XEM. Số liệu, đến hạn/quá hạn, so sánh tính theo mốc này (Tài sản bảo đảm theo sao kê hiện hành)."));
    var bt = E("button", "xm-btn", "Về dữ liệu hiện hành"); bt.type = "button"; bt.setAttribute("data-testid", "xm-ve"); bt.addEventListener("click", ve); b.appendChild(bt);
    document.body.appendChild(b); document.body.classList.add("xm-on-view");
  }
  function chanNhap() { if (window.__qltdView && /^#\/(nhap|nhap-du-lieu)(\/|$|\?)/.test(location.hash)) { toast("Về dữ liệu hiện hành để nhập dữ liệu."); location.reload(); } }
  function init() {
    document.addEventListener("click", function (e) {
      var c = e.target.closest && e.target.closest("[data-testid=chip-ngay]");
      if (c) { e.preventDefault(); e.stopPropagation(); if (pop) dong(); else mo(c); return; }
      if (pop && !pop.contains(e.target)) dong();
    }, true);
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") dong(); });
    window.addEventListener("hashchange", function () { dong(); chanNhap(); });
    chanNhap(); banner();
    try { var er = sessionStorage.getItem(KEYERR); if (er) { sessionStorage.removeItem(KEYERR); setTimeout(function () { toast("Không đọc được dòng của mốc " + er + " trong Lưu trữ — đang hiển thị dữ liệu hiện hành."); }, 1500); } } catch (e) {}
  }
  if (document.body) init(); else document.addEventListener("DOMContentLoaded", init);
  window.QLTDXemMoc = { version: "1.0.0", mocs: mocs, xem: xem, ve: ve, chiTieu: chiTieu };
})();
