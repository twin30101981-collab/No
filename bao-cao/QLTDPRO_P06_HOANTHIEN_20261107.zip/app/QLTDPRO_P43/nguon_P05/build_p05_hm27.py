# P05 · HM-27 · v24.17.31 — người dùng 07/11: (1) đổi tên trang "Cho vay doanh nghiệp" → "Doanh nghiệp";
#  (2) trang mới "Thấu chi" (#/thau-chi) cùng cấu trúc trang Ngắn hạn; TÁCH thấu chi khỏi trang Ngắn hạn (đổi tên "Ngắn hạn").
#  Phân loại thấu chi = đúng quy tắc sẵn có của gi() (isNganHan): nhãn loại vay khớp /thấu\s*chi/i  ⇒ Ngắn hạn(mới) ⊔ Thấu chi = Ngắn hạn(cũ).
#  Số đếm menu lấy từ cùng sb() (badges) ⇒ "Đối soát số liệu / badgeLech" tự kiểm cả trang mới. Bảng tổng hợp Tổng quan/Chỉ tiêu/Báo cáo KHÔNG đổi
#  (vốn đã có cột "Thấu chi" riêng). Slug cũ giữ nguyên (ngan-han-thau-chi, cho-vay-doanh-nghiep) để không gãy liên kết/bố cục đã lưu.
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P05/build_p05_hm27.py
import hashlib
SRC = 'app/QLTDPRO_v24.17.30.html'; DST = 'app/QLTDPRO_v24.17.31.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:90]); s = s.replace(old, new)
TC = '/thấu\\s*chi/i.test(String(t[13]||""))'
# gd24: hàm dùng chung
rep('  window.QLTDCB = { version: "1.0.0",', '  window.QLTD_laTC = function (loai) { return /thấu\\s*chi/i.test(String(loai == null ? "" : loai)); };\n  window.QLTDCB = { version: "1.0.0",')
# menu: đổi tên + trang mới
rep('Ge("du-no","ngan-han-thau-chi","Ngắn hạn + thấu chi",["kd","han-muc"]),', 'Ge("du-no","ngan-han-thau-chi","Ngắn hạn",["kd","han-muc"]),Ge("du-no","thau-chi","Thấu chi",["thau-chi","od","overdraft","tc"]),')
rep('Ge("du-no","cho-vay-doanh-nghiep","Cho vay doanh nghiệp",["dn","doanh-nghiep","cong-ty"]),', 'Ge("du-no","cho-vay-doanh-nghiep","Doanh nghiệp",["dn","doanh-nghiep","cong-ty","cho-vay-doanh-nghiep"]),')
# số đếm menu + đối soát: sb() cho kd không gồm thấu chi, thêm tc
rep('function sb(e,t,n){return le.metrics.badges(e,{today:n,parseDate:le.date.parse,isActual:Od,isNganHan:gi,isTrungHan:fi,',
    'function sb(e,t,n){const __b=le.metrics.badges(e,{today:n,parseDate:le.date.parse,isActual:Od,isNganHan:r=>gi(r)&&!window.QLTD_laTC(r),isTrungHan:fi,')
rep('chlmDone:r=>!!(t.chlmStatus[h0(r)]||{}).dachuyen})}function ob(', 'chlmDone:r=>!!(t.chlmStatus[h0(r)]||{}).dachuyen});return __b.tc=e.filter(r=>window.QLTD_laTC(r[13])).length,__b}function ob(')
rep('"ngan-han-thau-chi":s(i.kd),', '"ngan-han-thau-chi":s(i.kd),"thau-chi":s(i.tc),')
rep('["ngan-han-thau-chi","kd","Ngắn hạn"],', '["ngan-han-thau-chi","kd","Ngắn hạn"],["thau-chi","tc","Thấu chi"],')
# trang: kind "tc"; ngắn hạn bỏ thấu chi
rep('r=D.useMemo(()=>e==="ngan"?O3(n):e==="dn"?', 'r=D.useMemo(()=>e==="ngan"?O3(n).filter(t=>!window.QLTD_laTC(t[13])):e==="tc"?n.filter(t=>window.QLTD_laTC(t[13])):e==="dn"?')
rep('d=e==="ngan"?"ngan-han-thau-chi":e==="dn"?"cho-vay-doanh-nghiep":"trung-dai-han";return t.state', 'd=e==="ngan"?"ngan-han-thau-chi":e==="tc"?"thau-chi":e==="dn"?"cho-vay-doanh-nghiep":"trung-dai-han";return t.state')
rep('children:[a.ui,e==="dn"&&o.jsx(QDN,{rows:i,all:n}),', 'children:[a.ui,e==="dn"&&o.jsx(QDN,{rows:i,all:n}),(e==="ngan"||e==="tc")&&o.jsx("div",{className:"border-b bg-card px-3 py-1 text-xs text-muted-foreground","data-testid":"tach-tc-note",children:e==="tc"?"ⓘ Thấu chi (số dư thấu chi trên tài khoản khách hàng) — đã tách khỏi trang Ngắn hạn. Ngắn hạn + Thấu chi = ngắn hạn cũ.":"ⓘ Trang Ngắn hạn không gồm thấu chi — xem trang Thấu chi (đã tách)."}),')
rep('exportName:e==="ngan"?"Ngan_han_thau_chi":e==="dn"?"Cho_vay_doanh_nghiep":"Trung_dai_han"', 'exportName:e==="ngan"?"Ngan_han":e==="tc"?"Thau_chi":e==="dn"?"Doanh_nghiep":"Trung_dai_han"')
rep('emptyText:e==="ngan"?"Không có khoản vay ngắn hạn / thấu chi.":e==="dn"?"Không có khoản vay doanh nghiệp."', 'emptyText:e==="ngan"?"Không có khoản vay ngắn hạn.":e==="tc"?"Không có khoản thấu chi.":e==="dn"?"Không có khoản vay doanh nghiệp."')
# định tuyến
rep('g.slug==="ngan-han-thau-chi"?o.jsx(jp,{kind:"ngan"}):', 'g.slug==="ngan-han-thau-chi"?o.jsx(jp,{kind:"ngan"}):g.slug==="thau-chi"?o.jsx(jp,{kind:"tc"}):')
# gd7: bố cục bảng
rep("  'cho-vay-doanh-nghiep':{", "  'thau-chi':{ lead: DU, pin:['tenkh','cbtd','ngaytra'], sort:[{id:'ngaygn',desc:false}], show: DU },\n  'cho-vay-doanh-nghiep':{")
# thẻ DN: nhãn
c = s.count('"24.17.30"'); assert c == 2, c
s = s.replace('"24.17.30"', '"24.17.31"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.30' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.30', '24.17.31'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
