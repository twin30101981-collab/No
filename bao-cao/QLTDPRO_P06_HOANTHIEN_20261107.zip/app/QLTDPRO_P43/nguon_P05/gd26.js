/* gd26 1.0.0 — HM-30 (P05, 07/11/2026) — Trung tâm nhập dữ liệu + Lưu trữ sắp theo LOẠI dữ liệu đầu vào (Dư nợ / Tài sản), mới → cũ.
 * Lưu trữ: tab "💰 Dư nợ (msit80)" (mốc xếp theo ngày dữ liệu mới → cũ, gom theo tháng, cảnh báo mốc bất thường: năm lệch xa, trùng ngày,
 *   chỉ siêu dữ liệu; lọc Tất cả / Có nhãn mốc / Cần xem; nút 👁 xem tại mốc — HM-29) + tab "🏠 Tài sản bảo đảm" (mốc TS tự lưu + bấm tay, chỉ đọc).
 * Trung tâm nhập: 2 thẻ tóm tắt (Dư nợ / Tài sản) + lọc nhật ký Tất cả / Dư nợ / Tài sản; nhật ký xếp theo ngày dữ liệu mới → cũ.
 * Chỉ ĐỌC; thao tác xoá/gắn nhãn vẫn dùng đúng chỉ số gốc của app (chỉ đổi THỨ TỰ HIỂN THỊ). Dựng DOM bằng textContent. */
(function () {
  "use strict";
  function dk(vn) { var m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})/.exec(String(vn || "").trim()); return m ? (+m[3]) * 1e4 + (+m[2]) * 100 + (+m[1]) : 0; }
  function E(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function arc() { var a; try { a = JSON.parse(lsGet("_archiveReportList") || "[]"); } catch (e) { a = []; } if (!Array.isArray(a)) a = []; a = a.filter(function (m) { return m && m.type === "report"; }); return window.__qltdView ? window.__qltdView.loc(a) : a; }
  function fmt(n) { return Math.round(n).toLocaleString("vi-VN"); }
  /* ---------- Lưu trữ · Dư nợ ---------- */
  function xep(list) { return (list || []).map(function (m, i) { return [m, i]; }).sort(function (a, b) { return dk(b[0] && b[0].dayKey) - dk(a[0] && a[0].dayKey) || ((b[0] && b[0].timestamp) || 0) - ((a[0] && a[0].timestamp) || 0); }); }
  function thang(m) { var x = /^(\d{1,2})\/(\d{1,2})\/(\d{4})/.exec(String(m && m.dayKey || "")); return x ? x[3] + "-" + ("0" + x[2]).slice(-2) : "?"; }
  function maxNam(list) { var y = 0; (list || []).forEach(function (m) { var d = dk(m && m.dayKey); if (d) y = Math.max(y, Math.floor(d / 1e4)); }); return y; }
  function canh(list, m, coDong) {
    var r = [], d = dk(m && m.dayKey), y = Math.floor(d / 1e4), my = maxNam(list);
    if (coDong === false) r.push("mat");
    if (!d || (my && y < my - 2) || y > new Date().getFullYear() + 1) r.push("nam");
    if (d && (list || []).some(function (o) { return o !== m && o && o.dayKey === m.dayKey && (o.timestamp || 0) > (m.timestamp || 0); })) r.push("trung");
    return r.join(" ");
  }
  var TXT = { mat: "chỉ còn siêu dữ liệu (mất dòng chi tiết) — nhập lại tệp ngày này", nam: "ngày dữ liệu bất thường (năm lệch xa) — kiểm tra tên tệp", trung: "trùng ngày với bản mới hơn — cân nhắc xoá bản cũ" };
  function canhTxt(list, m, coDong) { var c = canh(list, m, coDong); return c ? "⚠ " + c.split(" ").map(function (k) { return TXT[k]; }).join("; ") : ""; }
  function nhom(jsx, L) {
    var last = null;
    return function (acc, row, idx) {
      var m = L[idx] && L[idx][0], t = thang(m);
      if (t !== last) { last = t; var lb = t === "?" ? "Không rõ ngày" : "📅 Tháng " + t.slice(5) + "/" + t.slice(0, 4);
        acc.push(jsx("tr", { className: "ar-thang", "data-testid": "ar-thang", "data-thang": t, children: jsx("td", { colSpan: 6, children: lb }) }, "h_" + t + "_" + idx)); }
      acc.push(row); return acc;
    };
  }
  function chips(host, items, onPick, cur, tid) {
    var w = E("span", "q26-chips"); w.setAttribute("data-testid", tid);
    items.forEach(function (it) { var b = E("button", "q26-chip" + (it[0] === cur ? " q26-on" : ""), it[1]); b.type = "button"; b.setAttribute("data-loc", it[0]);
      b.addEventListener("click", function () { onPick(it[0]); [].forEach.call(w.children, function (c) { c.classList.toggle("q26-on", c === b); }); }); w.appendChild(b); });
    host.appendChild(w);
  }
  var locArc = "all";
  function tomTatArc(el) {
    var tb = document.querySelector("[data-testid=ar-table]"); if (!tb) { setTimeout(function () { if (el.isConnected) tomTatArc(el); }, 300); return; }
    tb.setAttribute("data-loc", locArc);
    var rows = [].slice.call(tb.querySelectorAll("tr[data-testid=ar-row]")), list = arc();
    var days = rows.map(function (r) { return r.getAttribute("data-day"); }).filter(Boolean).sort(function (a, b) { return dk(a) - dk(b); });
    var n = { mat: 0, nam: 0, trung: 0 }, can = 0;
    rows.forEach(function (r) { var c = r.getAttribute("data-canh") || ""; if (c) can++; c.split(" ").forEach(function (k) { if (n[k] != null) n[k]++; }); });
    var sig = [rows.length, can, n.mat, n.nam, n.trung, locArc, days[0], days[days.length - 1]].join("|"); if (el.getAttribute("data-sig") === sig) return;
    el.setAttribute("data-sig", sig); el.textContent = ""; el.className = "q26-box";
    var p = E("div", "q26-line"); p.appendChild(E("b", null, "💰 Dư nợ (msit80): " + rows.length + " mốc"));
    if (days.length) p.appendChild(E("span", null, " · từ " + days[0] + " đến " + days[days.length - 1] + " · xếp mới → cũ, gom theo tháng"));
    el.appendChild(p);
    if (can) { var w = E("div", "q26-warn"); w.setAttribute("data-testid", "ar-canh-tomtat");
      w.textContent = "⚠ " + can + " mốc cần xem: " + [n.nam ? n.nam + " ngày bất thường" : "", n.trung ? n.trung + " trùng ngày (bản cũ hơn)" : "", n.mat ? n.mat + " chỉ còn siêu dữ liệu" : ""].filter(Boolean).join(" · ") + ". App không tự xoá — bấm 🗑️ ở dòng tương ứng nếu muốn xoá."; el.appendChild(w); }
    chips(el, [["all", "Tất cả"], ["nhan", "Có nhãn mốc"], ["canh", "⚠ Cần xem (" + can + ")"]], function (k) { locArc = k; tb.setAttribute("data-loc", k); }, locArc, "ar-loc");
    void list;
  }
  /* ---------- Lưu trữ · Tài sản ---------- */
  function docTS() {
    return new Promise(function (res) {
      var out = { cur: null, auto: [], tay: [] };
      try {
        var rq = indexedDB.open("QLTDProTSBD"), moi = false; /* KHÔNG tạo CSDL nếu chưa có (huỷ nâng cấp như zv() của app) */
        rq.onupgradeneeded = function () { moi = true; try { rq.transaction.abort(); } catch (e) {} };
        rq.onerror = function () { res(out); }; rq.onblocked = function () { res(out); };
        rq.onsuccess = function () {
          var db = rq.result, st = [].slice.call(db.objectStoreNames).filter(function (x) { return x === "kv" || x === "snapshots"; });
          if (moi || !st.length) { db.close(); return res(out); }
          try {
            var tx = db.transaction(st, "readonly");
            if (st.indexOf("kv") >= 0) { var c = tx.objectStore("kv").openCursor(); c.onsuccess = function () { var cu = c.result; if (!cu) return; var k = String(cu.key), v = cu.value;
              if (k === "current" && v && Array.isArray(v.rows)) out.cur = v; else if (k.indexOf("moc_") === 0 && v && Array.isArray(v.rows)) out.auto.push(v); cu.continue(); }; }
            if (st.indexOf("snapshots") >= 0) { var g = tx.objectStore("snapshots").getAll(); g.onsuccess = function () { out.tay = g.result || []; }; }
            tx.oncomplete = function () { db.close(); res(out); }; tx.onerror = function () { db.close(); res(out); };
          } catch (e) { db.close(); res(out); }
        };
      } catch (e) { res(out); }
    });
  }
  function giaTri(rows) { var s = 0; (rows || []).forEach(function (r) { var t = String(r && r.tienTe || "VND").toUpperCase().trim(); if (!t || t === "VND") s += Number(r && r.giaTriTS) || 0; }); return s; }
  function vn(iso) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso || "")); return m ? m[3] + "/" + m[2] + "/" + m[1] : String(iso || ""); }
  function paneTS(el) {
    if (el.getAttribute("data-busy") === "1" || el.getAttribute("data-done") === "1") return; el.setAttribute("data-busy", "1");
    docTS().then(function (d) {
      el.removeAttribute("data-busy"); el.setAttribute("data-done", "1"); el.textContent = "";
      var L = d.auto.map(function (m) { return { ngay: m.ngay, loai: "Tự lưu theo ngày tệp", src: m.src || "", n: (m.rows || []).length, gt: giaTri(m.rows), luc: m.luc || "" }; })
        .concat(d.tay.map(function (z) { var t = z.ts ? new Date(z.ts) : null; return { ngay: t ? t.getFullYear() + "-" + ("0" + (t.getMonth() + 1)).slice(-2) + "-" + ("0" + t.getDate()).slice(-2) : "", loai: "Bấm tay", src: z.name || z.label || "", n: (z.keys || z.rows || []).length, gt: null, luc: t ? t.toISOString() : "" }; }))
        .sort(function (a, b) { return a.ngay < b.ngay ? 1 : a.ngay > b.ngay ? -1 : (a.luc < b.luc ? 1 : -1); });
      var hd = E("div", "q26-box"); var p = E("div", "q26-line");
      p.appendChild(E("b", null, "🏠 Tài sản bảo đảm: " + L.length + " mốc"));
      p.appendChild(E("span", null, d.cur ? " · sao kê hiện hành: " + (d.cur.src || "") + " (" + fmt((d.cur.rows || []).length) + " TS)" : " · chưa nhập sao kê TSBĐ"));
      hd.appendChild(p); hd.appendChild(E("div", "q26-note", "Mốc tự lưu mỗi lần nhập sao kê (theo ngày trong tên tệp) và mốc bấm tay ở trang Tài sản bảo đảm. So sánh 2 mốc: trang Tài sản bảo đảm → tab \"Đầu kỳ & 2 mốc\"."));
      var a = E("a", "q26-link", "Mở so sánh mốc tài sản →"); a.href = "#/tai-san-bao-dam"; hd.appendChild(a); el.appendChild(hd);
      var w = E("div", "q26-tw"), t = E("table", "q26-t"); t.setAttribute("data-testid", "ar-ts-table");
      var tr = E("tr"); ["Ngày dữ liệu", "Loại mốc", "Tệp nguồn / tên", "Số TS", "Giá trị TS (đồng)"].forEach(function (h, i) { tr.appendChild(E("th", i >= 3 ? "n" : "", h)); });
      var th = E("thead"); th.appendChild(tr); t.appendChild(th); var tb = E("tbody");
      if (!L.length) { var r0 = E("tr"), c0 = E("td", "", "Chưa có mốc tài sản — nhập sao kê TSBĐ ở Trung tâm nhập dữ liệu."); c0.colSpan = 5; r0.appendChild(c0); tb.appendChild(r0); }
      L.forEach(function (x) { var r = E("tr"); r.setAttribute("data-testid", "ar-ts-row"); r.setAttribute("data-day", vn(x.ngay));
        [vn(x.ngay), x.loai, x.src, fmt(x.n), x.gt == null ? "—" : fmt(x.gt)].forEach(function (v, i) { r.appendChild(E("td", i >= 3 ? "n" : "", v)); }); tb.appendChild(r); });
      t.appendChild(tb); w.appendChild(t); el.appendChild(w);
    });
  }
  /* ---------- Trung tâm nhập ---------- */
  function xepLog(d) { return (d || []).map(function (u, i) { return [u, i]; }).sort(function (a, b) { var x = dk(a[0] && a[0].date) || 99999999, y = dk(b[0] && b[0].date) || 99999999; return y - x || a[1] - b[1]; }).map(function (p) { return p[0]; }); }
  var locNhap = "all";
  function locLog(el) {
    if (el.firstChild) return;
    chips(el, [["all", "Tất cả"], ["duno", "💰 Dư nợ"], ["tsbd", "🏠 Tài sản"]], function (k) { locNhap = k; var t = document.querySelector("[data-testid=log]"); if (t) t.setAttribute("data-loc", k); }, locNhap, "log-loc");
    setTimeout(function () { var t = document.querySelector("[data-testid=log]"); if (t) t.setAttribute("data-loc", locNhap); }, 0);
  }
  function thieuThang(days) {
    var co = {}; days.forEach(function (d) { co[d] = 1; });
    var hh = dk(lsGet("_currentFileDate")); if (!hh) return [];
    var y = Math.floor(hh / 1e4), mm = Math.floor(hh / 100) % 100, out = [];
    for (var m = 1; m < mm; m++) { var last = new Date(y, m, 0).getDate(), a = ("0" + last).slice(-2) + "/" + ("0" + m).slice(-2) + "/" + y, b = "01/" + ("0" + (m + 1)).slice(-2) + "/" + y;
      if (!co[a] && !co[b]) out.push("T" + ("0" + m).slice(-2)); }
    return out;
  }
  function tomTatNhap(el) {
    if (el.getAttribute("data-busy") === "1") return; el.setAttribute("data-busy", "1");
    var t = document.querySelector("[data-testid=log]"); if (t) t.setAttribute("data-loc", locNhap);
    docTS().then(function (d) {
      el.removeAttribute("data-busy");
      var A = arc(), days = {}; A.forEach(function (m) { if (dk(m.dayKey)) days[m.dayKey] = 1; }); var dl = Object.keys(days).sort(function (a, b) { return dk(b) - dk(a); });
      var miss = thieuThang(dl), autos = d.auto.map(function (m) { return m.ngay; }).sort().reverse();
      var sig = [dl.length, dl[0], miss.join(","), d.cur ? (d.cur.src || "") + (d.cur.rows || []).length : "", autos.length, autos[0]].join("|"); if (el.getAttribute("data-sig") === sig) return;
      el.setAttribute("data-sig", sig); el.textContent = ""; el.className = "q26-cards";
      function card(tid, title, lines, href, lb) { var c = E("div", "q26-card"); c.setAttribute("data-testid", tid); c.appendChild(E("b", null, title)); lines.forEach(function (l) { c.appendChild(E("div", l[1] || "", l[0])); });
        var a = E("a", "q26-link", lb); a.href = href; c.appendChild(a); el.appendChild(c); }
      card("nhap-the-duno", "💰 Dư nợ (msit80)", [["Dữ liệu hiện hành: " + (lsGet("_currentFileDate") || "chưa có")], [dl.length + " mốc trong Lưu trữ" + (dl.length ? " · mới nhất " + dl[0] : "")],
        [miss.length ? "⚠ Cuối tháng chưa có mốc: " + miss.join(", ") : "✓ Đủ mốc cuối tháng năm nay", miss.length ? "q26-warnt" : "q26-okt"]], "#/luu-tru", "Xem mốc dư nợ ở Lưu trữ →");
      card("nhap-the-tsbd", "🏠 Tài sản bảo đảm", [[d.cur ? "Sao kê hiện hành: " + (d.cur.src || "") : "Chưa nhập sao kê TSBĐ"], [d.cur ? fmt((d.cur.rows || []).length) + " tài sản" : ""],
        [autos.length + " mốc tài sản tự lưu" + (autos.length ? " · mới nhất " + vn(autos[0]) : "")]], "#/tai-san-bao-dam", "Xem tài sản bảo đảm →");
    });
  }
  window.QLTDArc = { version: "1.0.0", xep: xep, thang: thang, canh: canh, canhTxt: canhTxt, nhom: nhom, tomTatArc: tomTatArc, paneTS: paneTS, xepLog: xepLog, locLog: locLog, tomTatNhap: tomTatNhap };
})();
