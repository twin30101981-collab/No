# -*- coding: utf-8 -*-
# HM-29 · V3 — Ô "Dữ liệu ngày ▾": chọn mốc msit80 đã nhập → xem toàn app tại mốc (chỉ xem) + "So với mốc"; F5 → về hiện hành.
# Dữ liệu thử ẩn danh: 3 mốc (30/09, 15/10, 31/10/2026) nhập một lần; đáp án Python độc lập cho từng mốc.
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p05/test_hm29_xem_moc.py [app/QLTDPRO_v24.17.33.html]
import asyncio, functools, http.server, threading, sys, tempfile, subprocess, re, datetime as dt
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.33.html'
PORT = 8867; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm29'
if not EV.parent.exists(): EV = HERE / 'hm29'
SHOT = EV / 'anh' / Path(APP).stem; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:600]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
TMP = Path(tempfile.mkdtemp()) / 'm'
subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(TMP)], check=True, stdout=subprocess.DEVNULL)
F = sorted(TMP.iterdir(), key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
def dap_an(f):
    ws = openpyxl.load_workbook(f, read_only=True).active; rows = list(ws.iter_rows(values_only=True)); h = rows[0]; I = {k: i for i, k in enumerate(h)}
    act = [r for r in rows[1:] if (r[I['dsbsbal']] or 0) != 0 and str(r[I['custnm']] or '').strip()]
    return dict(n=len(act), bal=sum(r[I['dsbsbal']] for r in act), kh=len({str(r[I['brcd']]).strip() for r in act}))
E = {'30/09/2026': dap_an(F[0]), '15/10/2026': dap_an(F[1]), '31/10/2026': dap_an(F[2])}
def num(s): t = (s or '').strip(); v = re.sub(r'[^\d]', '', t); return (-1 if t.startswith('-') else 1) * int(v) if v else None
async def tong(pg):
    return num(await pg.evaluate("[...document.querySelectorAll('[data-testid=sc-sum] .rounded-md')].find(x=>/tổng dư nợ/i.test(x.children[0].textContent)).children[1].textContent"))
async def chon(pg, day):
    await pg.click('[data-testid=chip-ngay]'); await pg.wait_for_selector('[data-testid=xm-pop]')
    async with pg.expect_navigation(wait_until='domcontentloaded'):
        await pg.click(f'[data-testid=xm-moc][data-day="{day}"]')
    await pg.wait_for_timeout(3500)
async def run(pw, name, vw, vh):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN', is_mobile=vw < 600, has_touch=vw < 600)
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    T = lambda s: f'{name}: {s}'
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in F]); await pg.wait_for_timeout(3500)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(9000)
    await pg.goto(URL + '#/tat-ca-du-no', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    raw0 = await pg.evaluate("[localStorage.getItem('_currentFileDate'), JSON.parse(localStorage.getItem('_archiveReportList')||'[]').filter(x=>x.type==='report').length]")
    await pg.click('[data-testid=chip-ngay]'); await pg.wait_for_selector('[data-testid=xm-pop]')
    days = await pg.evaluate("[...document.querySelectorAll('[data-testid=xm-moc]')].map(b=>b.dataset.day)")
    ok(T(f'X1 bấm ô ngày → hộp chọn: Dữ liệu hiện hành + 3 mốc mới → cũ ({days})'), await pg.locator('[data-testid=xm-hien-hanh]').count() == 1 and days == ['31/10/2026', '15/10/2026', '30/09/2026'], days)
    pt = await pg.inner_text('[data-testid=xm-pop]')
    ok(T('X1b nhãn mốc hiện chữ (Quý/Tháng/Cuối năm), không "[object Object]"'), 'object Object' not in pt and ('T10/2026' in pt or 'Quý' in pt), pt[:300])
    if vw < 600:
        r = await pg.evaluate("(()=>{const b=document.querySelector('[data-testid=xm-pop]').getBoundingClientRect();return [Math.round(b.left),Math.round(b.right),innerWidth]})()")
        ok(T(f'M1 điện thoại: hộp chọn nằm gọn màn hình ({r})'), r[0] >= 0 and r[1] <= r[2], r)
    await pg.screenshot(path=str(SHOT / f'{name}_1_hop_chon.png'))
    await pg.keyboard.press('Escape')
    await chon(pg, '30/09/2026')
    chip = (await pg.inner_text('[data-testid=chip-ngay]')).strip(); cd = (await pg.inner_text('[data-testid=che-do]')).strip()
    ok(T(f'X2 chọn mốc 30/09 → dải "Đang xem mốc", ô ngày "{chip}", chế độ "{cd}"'), await pg.locator('[data-testid=xm-banner]').count() == 1 and '30/09/2026' in chip and 'chỉ xem' in chip and cd == 'Chỉ xem', (chip, cd))
    n = num(await pg.inner_text('[data-testid=dt-count]')); t = await tong(pg); e = E['30/09/2026']
    ok(T(f'X3 Tất cả dư nợ tại mốc 30/09 = Python ({n} dòng / {t} đ; đáp án {e["n"]} / {e["bal"]})'), n == e['n'] and t == e['bal'], (n, t, e))
    cell = await pg.evaluate("""(()=>{const th=[...document.querySelectorAll('[data-testid=dt-th]')].map(x=>x.textContent.replace(/[▲▼]\\d*/g,'').trim());const a=th.indexOf('Ngày đến hạn'),b=th.indexOf('Số ngày còn lại');const r=document.querySelector('[data-testid=dt-row]');return r?[r.children[a].textContent.trim(),r.children[b].textContent.trim()]:null})()""")
    d0 = dt.date(2026, 9, 30); m = re.match(r'(\d+)/(\d+)/(\d+)', cell[0]) if cell else None
    ok(T(f'X4 "Số ngày còn lại" tính theo ngày mốc 30/09 ({cell})'), m and num(cell[1]) == (dt.date(int(m[3]), int(m[2]), int(m[1])) - d0).days, cell)
    if vw < 600: await pg.click('[data-testid=menu-open]'); await pg.wait_for_timeout(500)
    bd = await pg.evaluate("(()=>{const a=document.querySelector('a[href=\"#/tat-ca-du-no\"]');return a?a.textContent:''})()")
    ok(T(f'X5 số đếm menu Tất cả dư nợ theo mốc ({bd.strip()})'), num(bd) == e['n'], (bd, e['n']))
    await pg.screenshot(path=str(SHOT / f'{name}_2_xem_moc_3009.png'))
    if vw >= 1000:
        await pg.goto(URL + '#/luu-tru', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
        nar = await pg.locator('[data-testid=ar-row]').count()
        raw = await pg.evaluate("JSON.parse(localStorage.getItem('_archiveReportList')||'[]').filter(x=>x.type==='report').length")
        ok(T(f'X6 Lưu trữ khi xem mốc 30/09 chỉ hiện mốc ≤ 30/09 ({nar} dòng); danh sách mốc gốc vẫn {raw} mốc'), nar == 1 and raw == raw0[1] == 3, (nar, raw, raw0))
        await chon(pg, '15/10/2026')
        await pg.goto(URL + '#/tong-quan', wait_until='domcontentloaded'); await pg.wait_for_timeout(3500)
        hd = await pg.evaluate("[...document.querySelectorAll('[data-testid=gd7-delta] thead th')].map(x=>x.textContent.trim())")
        ok(T(f'X7 xem mốc 15/10: Tổng quan so với mốc TRƯỚC 30/09, không dùng 31/10 ({hd[2:4] if hd else hd})'), hd and 'Dư nợ 30/09/2026' in hd and 'Dư nợ 15/10/2026' in hd and not any('31/10' in x for x in hd), hd)
    # F5 → về hiện hành
    await pg.reload(wait_until='domcontentloaded'); await pg.wait_for_timeout(3500)
    await pg.goto(URL + '#/tat-ca-du-no', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    chip = (await pg.inner_text('[data-testid=chip-ngay]')).strip(); n = num(await pg.inner_text('[data-testid=dt-count]')); e = E['31/10/2026']
    ok(T(f'X8 F5 → về dữ liệu hiện hành ({chip}; {n} dòng = {e["n"]})'), await pg.locator('[data-testid=xm-banner]').count() == 0 and chip.startswith('Dữ liệu ngày 31/10/2026') and n == e['n'], (chip, n))
    await chon(pg, '15/10/2026')
    async with pg.expect_navigation(wait_until='domcontentloaded'):
        await pg.click('[data-testid=xm-ve]')
    await pg.wait_for_timeout(3000)
    ok(T('X9 nút "Về dữ liệu hiện hành" → hết dải, ô ngày 31/10'), await pg.locator('[data-testid=xm-banner]').count() == 0 and '31/10/2026' in await pg.inner_text('[data-testid=chip-ngay]'))
    if vw >= 1000:
        await chon(pg, '30/09/2026')
        async with pg.expect_navigation(wait_until='domcontentloaded'):
            await pg.evaluate("location.hash='#/nhap-du-lieu'")
        await pg.wait_for_timeout(3000)
        ok(T('X10 đang xem mốc mà vào Nhập dữ liệu → tự về hiện hành (không nhập vào mốc cũ)'), await pg.locator('[data-testid=xm-banner]').count() == 0 and '31/10/2026' in await pg.inner_text('[data-testid=chip-ngay]') and 'nhap' in pg.url, pg.url)
        # so với mốc
        await pg.goto(URL + '#/tat-ca-du-no', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
        await pg.click('[data-testid=chip-ngay]'); await pg.wait_for_selector('[data-testid=xm-pop]')
        await pg.select_option('[data-testid=xm-so-sel]', '30/09/2026'); await pg.click('[data-testid=xm-so-btn]')
        await pg.wait_for_selector('[data-testid=xm-so-t]', timeout=15000)
        v = await pg.evaluate("Object.fromEntries([...document.querySelectorAll('[data-testid=xm-so-t] tbody tr')].map(r=>[r.dataset.k,[+r.dataset.a,+r.dataset.b]]))")
        a, b = E['31/10/2026'], E['30/09/2026']
        ok(T(f'X11 So với mốc 30/09: Tổng dư nợ / Số KH / Số khoản = Python (31/10 vs 30/09)'), v.get('duno') == [a['bal'], b['bal']] and v.get('kh') == [a['kh'], b['kh']] and v.get('hs') == [a['n'], b['n']], (v, a, b))
        ok(T('X12 các nhóm Ngắn + Trung-dài + Thấu chi = Tổng dư nợ (cả 2 mốc)'), all(abs(v['nh'][i] + v['td'][i] + v['tc'][i] - v['duno'][i]) <= 1 for i in (0, 1)), v)
        await pg.screenshot(path=str(SHOT / f'{name}_3_so_voi_moc.png'))
    raw1 = await pg.evaluate("[localStorage.getItem('_currentFileDate'), JSON.parse(localStorage.getItem('_archiveReportList')||'[]').filter(x=>x.type==='report').length]")
    ok(T(f'X13 sau mọi thao tác: ngày dữ liệu & danh sách mốc trong máy KHÔNG đổi ({raw1})'), raw1 == raw0, (raw0, raw1))
    ok(T('E1 0 pageerror'), not errs, errs[:3])
    await br.close()
async def main():
    async with async_playwright() as pw:
        await run(pw, 'desktop', 1366, 900); await run(pw, 'mobile', 390, 844)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
