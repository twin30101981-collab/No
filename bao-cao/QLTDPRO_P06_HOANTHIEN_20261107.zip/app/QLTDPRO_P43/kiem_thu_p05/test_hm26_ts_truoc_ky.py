# -*- coding: utf-8 -*-
# HM-26 · V3 — Khách hàng mới: khách vay MỚI, không cầm cố, có ≥1 TS thế chấp TRƯỚC kỳ → nhãn tím "TS trước kỳ" thay "mới".
# Dữ liệu thử ẩn danh: dư nợ 3 mốc + 5 khách mới trong tháng 10/2026 ở tệp 31/10 + sao kê TS 31/10:
#  N1 TS 01/05/2025 (trước kỳ) → TS trước kỳ · N2 TS 10/10/2026 (trong kỳ) → mới · N3 không TS → mới ·
#  N4 chứng chỉ tiền gửi 01/05/2025 (cầm cố) → mới + cầm cố · N5 2 TS (trước + trong kỳ) → TS trước kỳ (có ≥1 TS trước kỳ).
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p05/test_hm26_ts_truoc_ky.py [app/QLTDPRO_v24.17.30.html]
import asyncio, functools, http.server, threading, sys, tempfile, subprocess, re, datetime as dt
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.30.html'
PORT = 8864; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm26'
if not EV.parent.exists(): EV = HERE / 'hm26'
SHOT = EV / 'anh' / Path(APP).stem; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:600]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
TMP = Path(tempfile.mkdtemp()) / 'm'
subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(TMP)], check=True, stdout=subprocess.DEVNULL)
F = sorted(TMP.iterdir(), key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
NEW = {'N1': 'Khách thử TS trước kỳ', 'N2': 'Khách thử TS trong kỳ', 'N3': 'Khách thử không TS', 'N4': 'Khách thử cầm cố', 'N5': 'Khách thử hai TS'}
wb = openpyxl.load_workbook(F[-1]); ws = wb.active; h = [c.value for c in ws[1]]; base = [c.value for c in ws[2]]
for i, (k, ten) in enumerate(NEW.items()):
    r = list(base); r[h.index('brcd')] = f'32019900000{i}'; r[h.index('custnm')] = ten; r[h.index('apprseq')] = f'HDTHU{i}'; r[h.index('dsbsseq')] = f'DSTHU{i}'
    r[h.index('dsbsdt')] = dt.datetime(2026, 10, 5 + i); r[h.index('dsbsamt')] = 300_000_000 + i; r[h.index('dsbsbal')] = 300_000_000 + i; ws.append(r)
wb.save(F[-1])
def ts(so, i, ngay, loai='Đất ở', ct='Thổ cư'):
    kh = f'32019900000{i}'
    return {'clno': so, 'clcustno': kh, 'clcustnm': list(NEW.values())[i], 'cltpcd': loai, 'cldtltpcd': ct, 'clqtysz': '100', 'clunittpcd': 'm2', 'clloc': so + ' Phố Thử',
            'clamt': 1_000_000_000, 'plgno': 'LCA' + so, 'plgdt': ngay, 'plgtpcd': 'TC', 'exprdt': '01/09/2030', 'avblamtrt': '70', 'plgamt': 700_000_000,
            'plgcustno': kh, 'plgcustnm': list(NEW.values())[i], 'clccycd': 'VND', 'clholdcd': 'N', 'ntydt': ngay, 'rem': '', 'lnofcnm': 'CÁN BỘ THỬ', 'trctcd': 'Hội Sở', 'name_2': 'GCN' + so}
TSR = [ts('A1', 0, '01/05/2025'), ts('A2', 1, '10/10/2026'), ts('A4', 3, '01/05/2025', 'Chứng chỉ tiền gửi', 'Chứng chỉ tiền gửi'), ts('A5', 4, '01/05/2025'), ts('A6', 4, '20/10/2026')]
TSF = Path(tempfile.mkdtemp()) / '31_10_2026-TS.xlsx'
_wb = openpyxl.Workbook(); _w = _wb.active; _hh = list(TSR[0].keys()); _w.append(_hh)
for r in TSR: _w.append([r[k] for k in _hh])
_wb.save(TSF)
EXP = {'N1': 'TS trước kỳ', 'N2': 'mới', 'N3': 'mới', 'N4': 'mới cầm cố', 'N5': 'TS trước kỳ'}

async def run(pw, name, vw, vh):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN', is_mobile=vw < 600, has_touch=vw < 600)
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in F + [TSF]]); await pg.wait_for_timeout(3500)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(9000)
    await pg.goto(URL + '#/khach-hang-moi', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    for sel, d in (('khm-arch-dau', '30/09/2026'), ('khm-arch-cuoi', '31/10/2026')):
        s = pg.locator(f'[data-testid="{sel}"]'); lab = [t for t in await s.locator('option').all_inner_texts() if d in t][0]; await s.select_option(label=lab)
    await pg.locator('[data-testid="khm-arch-load"]').click(); await pg.wait_for_timeout(2500)
    await pg.locator('[data-testid="khm-go"]').click(); await pg.wait_for_selector('[data-testid="khm-tab-chitiet-btn"]', timeout=30000); await pg.wait_for_timeout(1500)
    await pg.locator('[data-testid="khm-tab-chitiet-btn"]').first.click(); await pg.wait_for_timeout(900)
    await pg.locator('[data-testid=khm-tab-chitiet] button', has_text=re.compile('^KH vay mới$')).first.click(); await pg.wait_for_timeout(900)
    await pg.fill('[data-testid=khm-tab-chitiet] input[type=search], [data-testid=khm-tab-chitiet] input[placeholder*="Tên"]', 'Khách thử'); await pg.wait_for_timeout(900)
    rows = await pg.evaluate("""()=>[...document.querySelectorAll('[data-testid=khm-tab-chitiet] tbody tr')].map(r=>{const td=[...r.querySelectorAll('td')].find(t=>/Khách thử/.test(t.textContent));if(!td)return null;
        return [td.querySelector('div').textContent.trim(),[...td.querySelectorAll('small span')].map(s=>s.textContent.trim()).join(' '),(td.querySelector('[data-testid=khm-ts-truoc]')?getComputedStyle(td.querySelector('[data-testid=khm-ts-truoc]')).color:'')]}).filter(Boolean)""")
    got = {k: next((b for t, b, _ in rows if t == ten), None) for k, ten in NEW.items()}
    for k, e in EXP.items():
        ok(f'{name} {k} "{NEW[k]}" → nhãn "{e}"', got[k] == e, (got[k], rows))
    col = next((c for t, _, c in rows if t == NEW['N1']), '')
    ok(f'{name} T1 nhãn "TS trước kỳ" màu tím ({col})', col == 'rgb(91, 33, 182)', col)
    await pg.locator('[data-testid=khm-ts-truoc]').first.scroll_into_view_if_needed()
    await pg.screenshot(path=str(SHOT / f'{name}_kh_vay_moi.png'))
    ok(f'{name} E1 0 pageerror', not errs, errs[:3])
    await br.close()

async def main():
    async with async_playwright() as pw:
        await run(pw, 'desktop', 1366, 900); await run(pw, 'mobile', 390, 844)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
