# -*- coding: utf-8 -*-
# HM-30 · V3 — Lưu trữ + Trung tâm nhập sắp theo loại (Dư nợ / Tài sản), mới → cũ; cảnh báo mốc bất thường; thao tác vẫn đúng dòng.
# Dữ liệu thử ẩn danh: 3 mốc dư nợ (30/09, 15/10, 31/10/2026) + sao kê TS 31/10 (5 TS); thêm 2 mốc lỗi giả vào danh sách Lưu trữ:
#  "31/03/2006" (năm lệch xa, không có dòng) và bản trùng 15/10 cũ hơn (không có dòng).
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p05/test_hm30_luu_tru_loai.py [app/QLTDPRO_v24.17.34.html]
import asyncio, functools, http.server, threading, sys, tempfile, subprocess, re
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.34.html'
PORT = 8868; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm30'
if not EV.parent.exists(): EV = HERE / 'hm30'
SHOT = EV / 'anh' / Path(APP).stem; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:600]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
TMP = Path(tempfile.mkdtemp()) / 'm'
subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(TMP)], check=True, stdout=subprocess.DEVNULL)
F = sorted(TMP.iterdir(), key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
def ts(i):
    return {'clno': f'TS{i}', 'clcustno': f'MOI{i}', 'clcustnm': f'Khách TS {i}', 'cltpcd': 'Đất ở', 'cldtltpcd': 'Thổ cư', 'clqtysz': '100', 'clunittpcd': 'm2', 'clloc': 'Phố Thử',
            'clamt': 1_000_000_000 + i, 'plgno': f'LCA{i}', 'plgdt': '01/05/2025', 'plgtpcd': 'TC', 'exprdt': '01/09/2030', 'avblamtrt': '70', 'plgamt': 700_000_000,
            'plgcustno': f'MOI{i}', 'plgcustnm': f'Khách TS {i}', 'clccycd': 'VND', 'clholdcd': 'N', 'ntydt': '01/05/2025', 'rem': '', 'lnofcnm': 'CÁN BỘ THỬ', 'trctcd': 'Hội Sở', 'name_2': f'GCN{i}'}
TSR = [ts(i) for i in range(5)]
TSF = Path(tempfile.mkdtemp()) / '31_10_2026-TS.xlsx'
_wb = openpyxl.Workbook(); _w = _wb.active; _hh = list(TSR[0].keys()); _w.append(_hh)
for r in TSR: _w.append([r[k] for k in _hh])
_wb.save(TSF)
VIS = "(sel)=>[...document.querySelectorAll(sel)].filter(e=>e.offsetParent!==null).map(e=>e.getAttribute('data-day')||e.getAttribute('data-kind'))"
async def run(pw, name, vw, vh):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN', is_mobile=vw < 600, has_touch=vw < 600)
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200])); pg.on('dialog', lambda d: asyncio.ensure_future(d.accept()))
    T = lambda s: f'{name}: {s}'
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in F + [TSF]]); await pg.wait_for_timeout(3500)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(10000)
    # ---- Trung tâm nhập
    await pg.goto(URL + '#/nhap-du-lieu', wait_until='domcontentloaded'); await pg.wait_for_timeout(3000)
    du = await pg.inner_text('[data-testid=nhap-the-duno]'); tsb = await pg.inner_text('[data-testid=nhap-the-tsbd]')
    ok(T('N1 thẻ Dư nợ: hiện hành 31/10/2026, 3 mốc, cuối tháng thiếu T01–T08 (có T09 = 30/09)'), '31/10/2026' in du and '3 mốc' in du and 'T08' in du and 'T09' not in du, du)
    ok(T('N2 thẻ Tài sản: sao kê hiện hành, 5 tài sản, 1 mốc tự lưu'), '5 tài sản' in tsb and '1 mốc tài sản' in tsb, tsb)
    dates = await pg.evaluate("[...document.querySelectorAll('[data-testid=log-row]')].map(r=>r.children[4].textContent.trim())")
    key = [tuple(int(x) for x in reversed(d.split('/'))) if re.match(r'\d+/\d+/\d+', d) else (9999,) for d in dates]
    ok(T(f'N3 nhật ký xếp theo Ngày DL mới → cũ ({dates})'), key == sorted(key, reverse=True) and len(dates) == 4, dates)
    for k, n in (('tsbd', 1), ('duno', 3), ('all', 4)):
        await pg.click(f'[data-testid=log-loc] [data-loc={k}]'); await pg.wait_for_timeout(300)
        v = await pg.evaluate(VIS, '[data-testid=log-row]')
        ok(T(f'N4 lọc nhật ký "{k}" → {n} dòng đúng loại'), len(v) == n and (k == 'all' or all(x == k for x in v)), v)
    await pg.screenshot(path=str(SHOT / f'{name}_1_nhap.png'))
    if vw < 600:
        sw = await pg.evaluate('[document.documentElement.scrollWidth, innerWidth]'); ok(T('M1 điện thoại: Trung tâm nhập không tràn ngang'), sw[0] <= sw[1], sw)
    # ---- thêm 2 mốc lỗi giả vào danh sách Lưu trữ
    await pg.evaluate("""()=>{const L=JSON.parse(localStorage.getItem('_archiveReportList'));const r=L.filter(x=>x.type==='report');
      const b=r.find(x=>x.dayKey==='15/10/2026');const a=Object.assign({},b,{dayKey:'31/03/2006',name:'Hàng ngày 31/03/2006 (IPCAS)',timestamp:1000,tag:undefined});
      const c=Object.assign({},b,{timestamp:(b.timestamp||0)-5000,name:b.name+' (bản cũ)'});L.push(a,c);localStorage.setItem('_archiveReportList',JSON.stringify(L))}""")
    await pg.goto(URL + '#/luu-tru', wait_until='domcontentloaded'); await pg.wait_for_timeout(3500)
    tabs = await pg.evaluate("[...document.querySelectorAll('main button')].map(b=>b.textContent.trim()).filter(t=>/Dư nợ \\(msit80\\)|Tài sản bảo đảm|Hàng ngày|Lưu trữ Dữ liệu/.test(t))")
    ok(T(f'L1 tab Lưu trữ theo loại: {tabs}'), tabs[:2] == ['💰 Dư nợ (msit80)', '🏠 Tài sản bảo đảm'] and len(tabs) == 4, tabs)
    rows = await pg.evaluate("[...document.querySelectorAll('[data-testid=ar-row]')].map(r=>[r.dataset.day,r.dataset.canh])")
    ok(T(f'L2 mốc dư nợ xếp mới → cũ: {[d for d, _ in rows]}'), [d for d, _ in rows] == ['31/10/2026', '15/10/2026', '15/10/2026', '30/09/2026', '31/03/2006'], rows)
    th = await pg.evaluate("[...document.querySelectorAll('[data-testid=ar-thang]')].map(r=>r.dataset.thang)")
    ok(T(f'L3 gom theo tháng: {th}'), th == ['2026-10', '2026-09', '2006-03'], th)
    cz = dict(enumerate(c for _, c in rows))
    ok(T('L4 cảnh báo: 31/03/2006 = năm bất thường + chỉ siêu dữ liệu; bản 15/10 cũ hơn = trùng ngày; mốc thật không cảnh báo'),
       'nam' in cz[4] and 'mat' in cz[4] and 'trung' in cz[2] and cz[0] == '' and cz[1] == '' and cz[3] == '', rows)
    sm = await pg.inner_text('[data-testid=ar-canh-tomtat]')
    ok(T(f'L5 tóm tắt "2 mốc cần xem", không tự xoá ({sm[:60]})'), sm.startswith('⚠ 2 mốc cần xem') and 'không tự xoá' in sm, sm)
    await pg.click('[data-testid=ar-loc] [data-loc=canh]'); await pg.wait_for_timeout(300)
    v = await pg.evaluate(VIS, '[data-testid=ar-row]'); ok(T(f'L6 lọc "Cần xem" → 2 mốc ({v})'), v == ['15/10/2026', '31/03/2006'], v)
    await pg.click('[data-testid=ar-loc] [data-loc=all]'); await pg.wait_for_timeout(300)
    await pg.screenshot(path=str(SHOT / f'{name}_2_luu_tru_duno.png'))
    if vw >= 1000:
        # thao tác vẫn trúng đúng dòng sau khi sắp lại
        await pg.locator('[data-testid=ar-row][data-day="31/03/2006"] [data-testid=ar-del]').click(); await pg.wait_for_timeout(2000)
        left = await pg.evaluate("JSON.parse(localStorage.getItem('_archiveReportList')).filter(x=>x.type==='report').map(x=>x.dayKey).sort()")
        ok(T(f'L7 bấm 🗑️ ở dòng 31/03/2006 → xoá ĐÚNG mốc đó ({left})'), left == sorted(['31/10/2026', '15/10/2026', '15/10/2026', '30/09/2026']), left)
        sel = pg.locator('[data-testid=ar-row][data-day="30/09/2026"] [data-testid=ar-tag-select]')
        await sel.select_option(index=2); await pg.wait_for_timeout(800); val = await sel.input_value()
        tg = await pg.evaluate("JSON.parse(localStorage.getItem('_archiveReportList')).filter(x=>x.type==='report').map(x=>[x.dayKey,x.tag])")
        ok(T(f'L8 gắn nhãn ở dòng 30/09 → nhãn lưu vào ĐÚNG mốc 30/09 ({val})'), any(d == '30/09/2026' and t for d, t in tg) and val, tg)
        # tab Tài sản
        await pg.locator('main button', has_text='🏠 Tài sản bảo đảm').first.click(); await pg.wait_for_timeout(2000)
        tr = await pg.evaluate("[...document.querySelectorAll('[data-testid=ar-ts-row]')].map(r=>[...r.children].map(c=>c.textContent.trim()))")
        ok(T(f'L9 tab Tài sản: mốc 31/10/2026 tự lưu, 5 TS, giá trị = Python ({tr})'), tr and tr[0][0] == '31/10/2026' and tr[0][3] == '5' and tr[0][4] == f'{sum(r["clamt"] for r in TSR):,}'.replace(',', '.'), tr)
        await pg.screenshot(path=str(SHOT / f'{name}_3_luu_tru_ts.png'))
        await pg.locator('main button', has_text='💰 Dư nợ (msit80)').first.click(); await pg.wait_for_timeout(1500)
        async with pg.expect_navigation(wait_until='domcontentloaded'):
            await pg.locator('[data-testid=ar-row][data-day="30/09/2026"] [data-testid=ar-xem]').click()
        await pg.wait_for_timeout(3000)
        ok(T('L10 nút 👁 ở dòng 30/09 → xem toàn app tại mốc 30/09 (HM-29)'), await pg.locator('[data-testid=xm-banner]').count() == 1 and '30/09/2026' in await pg.inner_text('[data-testid=chip-ngay]'))
    else:
        sw = await pg.evaluate('[document.documentElement.scrollWidth, innerWidth]'); ok(T('M2 điện thoại: Lưu trữ không tràn ngang trang'), sw[0] <= sw[1], sw)
    ok(T('E1 0 pageerror'), not errs, errs[:3])
    await br.close()
async def main():
    async with async_playwright() as pw:
        await run(pw, 'desktop', 1366, 900); await run(pw, 'mobile', 390, 844)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
