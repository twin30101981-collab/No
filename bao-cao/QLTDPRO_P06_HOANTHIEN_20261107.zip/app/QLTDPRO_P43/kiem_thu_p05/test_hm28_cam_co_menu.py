# -*- coding: utf-8 -*-
# HM-28 · V3 — "Dư nợ cầm cố" → "Cầm cố" (ngay sau "Doanh nghiệp"); "Khách hàng mới" ngay sau "Cầm cố".
# Dữ liệu thử ẩn danh: dư nợ 3 mốc + sao kê TS 31/10 có 6 khách vay thế chấp CHỨNG CHỈ TIỀN GỬI (cầm cố) + vài TS thường. Đáp án Python độc lập.
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p05/test_hm28_cam_co_menu.py [app/QLTDPRO_v24.17.32.html]
import asyncio, functools, http.server, threading, sys, tempfile, subprocess, re
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.32.html'
PORT = 8866; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm28'
if not EV.parent.exists(): EV = HERE / 'hm28'
SHOT = EV / 'anh' / Path(APP).stem; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:700]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
TMP = Path(tempfile.mkdtemp()) / 'm'
subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(TMP)], check=True, stdout=subprocess.DEVNULL)
F = sorted(TMP.iterdir(), key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
ws = openpyxl.load_workbook(F[-1], read_only=True).active; rows = list(ws.iter_rows(values_only=True)); h = rows[0]; I = {k: i for i, k in enumerate(h)}
act = [r for r in rows[1:] if (r[I['dsbsbal']] or 0) != 0 and str(r[I['custnm']] or '').strip()]
khs = []
for r in act:
    k = str(r[I['brcd']]).strip()
    if k not in khs: khs.append(k)
CC, THUONG = khs[:6], khs[6:9]
exp_rows = [r for r in act if str(r[I['brcd']]).strip() in CC]; E = dict(kh=len(CC), n=len(exp_rows), bal=sum(r[I['dsbsbal']] for r in exp_rows))
def ts(i, kh, loai, ct):
    ten = next(str(r[I['custnm']]) for r in act if str(r[I['brcd']]).strip() == kh)
    return {'clno': f'TS{i:03d}', 'clcustno': kh, 'clcustnm': ten, 'cltpcd': loai, 'cldtltpcd': ct, 'clqtysz': '100', 'clunittpcd': 'm2', 'clloc': f'{i} Phố Thử',
            'clamt': 1_000_000_000, 'plgno': f'LCA{i:03d}', 'plgdt': '01/05/2025', 'plgtpcd': 'TC', 'exprdt': '01/09/2030', 'avblamtrt': '70', 'plgamt': 700_000_000,
            'plgcustno': kh, 'plgcustnm': ten, 'clccycd': 'VND', 'clholdcd': 'N', 'ntydt': '01/05/2025', 'rem': '', 'lnofcnm': 'CÁN BỘ THỬ', 'trctcd': 'Hội Sở', 'name_2': f'GCN{i}'}
TSR = [ts(i, k, 'Chứng chỉ tiền gửi', 'Chứng chỉ tiền gửi') for i, k in enumerate(CC)] + [ts(10 + i, k, 'Đất ở', 'Thổ cư') for i, k in enumerate(THUONG)]
TSF = Path(tempfile.mkdtemp()) / '31_10_2026-TS.xlsx'
_wb = openpyxl.Workbook(); _w = _wb.active; _hh = list(TSR[0].keys()); _w.append(_hh)
for r in TSR: _w.append([r[k] for k in _hh])
_wb.save(TSF)
ORDER = ['tat-ca-du-no', 'ngan-han-thau-chi', 'thau-chi', 'trung-dai-han', 'cho-vay-doanh-nghiep', 'du-no-cam-co', 'khach-hang-moi', 'khach-hang-360']
def num(s): v = re.sub(r'[^\d]', '', s or ''); return int(v) if v else None
async def run(pw, name, vw, vh):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN', is_mobile=vw < 600, has_touch=vw < 600, accept_downloads=True)
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    T = lambda s: f'{name}: {s}'
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in F + [TSF]]); await pg.wait_for_timeout(3500)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(9000)
    await pg.goto(URL + '#/tat-ca-du-no', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    if vw < 600: await pg.click('button[aria-label*="enu"], header button >> nth=0'); await pg.wait_for_timeout(600)
    menu = await pg.evaluate("[...document.querySelectorAll('a[href^=\"#/\"]')].map(a=>[a.getAttribute('href').slice(2),a.textContent.trim()])")
    seen = []
    for s, t in menu:
        if s not in [x for x, _ in seen]: seen.append((s, t))
    pos = [x for x, _ in seen]; sub = [x for x in pos if x in ORDER]
    ok(T('O1 thứ tự menu Dư nợ: Tất cả · Ngắn hạn · Thấu chi · Trung-dài · Doanh nghiệp · Cầm cố · Khách hàng mới · Khách hàng 360°'), sub == ORDER, sub)
    i0 = pos.index('tat-ca-du-no'); ok(T('O2 8 mục liền nhau, không xen mục khác'), pos[i0:i0 + 8] == ORDER, pos[i0:i0 + 9])
    lab = dict(seen); l = lambda s: re.sub(r'[\d./]+$', '', lab[s]).strip()
    ok(T(f'O3 "Cầm cố" (hết "Dư nợ cầm cố"); "Khách hàng mới" giữ tên ({l("du-no-cam-co")} / {l("khach-hang-moi")})'), l('du-no-cam-co') == 'Cầm cố' and l('khach-hang-moi') == 'Khách hàng mới' and not any('Dư nợ cầm cố' in t for _, t in seen), lab)
    await pg.goto(URL + '#/du-no-cam-co', wait_until='domcontentloaded'); await pg.wait_for_timeout(3000)
    title = (await pg.inner_text('h1')).strip() if await pg.locator('h1').count() else ''
    ok(T(f'C1 tiêu đề trang "Cầm cố" ({title})'), title == 'Cầm cố', title)
    ok(T('C2 trang cầm cố vẫn đủ khung: page-du-no-cam-co + bảng dt-du-no-cam-co'), await pg.locator('[data-testid=page-du-no-cam-co] [data-testid=dt-du-no-cam-co]').count() == 1)
    n = num(await pg.inner_text('[data-testid=dt-count]'))
    cards = await pg.evaluate("""()=>{const o={};document.querySelectorAll('main .rounded-md').forEach(x=>{if(x.children.length>=2)o[x.children[0].textContent.trim().toLowerCase()]=x.children[1].textContent.trim()});return o}""")
    kh = num(cards.get('khách hàng cầm cố')); bal = num(cards.get('dư nợ cầm cố'))
    ok(T(f'C3 trang Cầm cố (mỗi dòng 1 khách) = Python: {n} dòng / {kh} KH / dư nợ {bal} (đáp án {E["kh"]} / {E["kh"]} / {E["bal"]})'), n == E['kh'] and kh == E['kh'] and bal == E['bal'], (n, cards, E))
    await pg.screenshot(path=str(SHOT / f'{name}_cam_co.png'))
    if vw >= 1000:
        async with pg.expect_download(timeout=20000) as dl: await pg.click('[data-testid=dt-export]')
        d = await dl.value; ok(T(f'C4 Xuất Excel Cam_co ({d.suggested_filename})'), 'Cam_co' in d.suggested_filename, d.suggested_filename)
        # bấm lần lượt từng mục menu theo thứ tự mới → trang nào cũng mở được, không lỗi
        bad = []
        for s in ORDER:
            await pg.click(f'a[href="#/{s}"]'); await pg.wait_for_timeout(1500)
            ok_ = await pg.evaluate("(s)=>location.hash==='#/'+s&&(document.querySelector('main')||{innerText:''}).innerText.trim().length>20", s)
            if not ok_: bad.append(s)
        ok(T('N1 bấm lần lượt 8 mục menu Dư nợ theo thứ tự mới: trang nào cũng mở, không trống'), not bad, bad)
        # Khách hàng mới ngay sau Cầm cố: trang vẫn dựng được báo cáo
        await pg.goto(URL + '#/khach-hang-moi', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
        for sel, d in (('khm-arch-dau', '30/09/2026'), ('khm-arch-cuoi', '31/10/2026')):
            s = pg.locator(f'[data-testid="{sel}"]'); lb = [t for t in await s.locator('option').all_inner_texts() if d in t][0]; await s.select_option(label=lb)
        await pg.locator('[data-testid="khm-arch-load"]').click(); await pg.wait_for_timeout(2500)
        await pg.locator('[data-testid="khm-go"]').click(); await pg.wait_for_selector('[data-testid="khm-tab-doisoat-btn"]', timeout=30000)
        ok(T('K1 trang Khách hàng mới ở vị trí mới vẫn lập được báo cáo (tab Đối soát)'), await pg.locator('[data-testid="khm-tab-doisoat-btn"]').count() >= 1)
        # mọi trang trong ứng dụng mở không lỗi
        hrefs = await pg.evaluate("[...new Set([...document.querySelectorAll('a[href^=\"#/\"]')].map(a=>a.getAttribute('href')))]")
        bad = []
        for hr in hrefs:
            await pg.goto(URL + hr, wait_until='domcontentloaded'); await pg.wait_for_timeout(1000)
            if not await pg.evaluate("(document.querySelector('main')||{innerText:''}).innerText.trim().length>10"): bad.append(hr)
        ok(T(f'N2 quét {len(hrefs)} trang trong menu: không trang nào trống'), not bad, bad)
    else:
        sw = await pg.evaluate('[document.documentElement.scrollWidth, innerWidth]')
        ok(T('R1 điện thoại: trang Cầm cố không tràn ngang'), sw[0] <= sw[1], sw)
    ok(T('E1 0 pageerror'), not errs, errs[:3])
    await br.close()
async def main():
    async with async_playwright() as pw:
        await run(pw, 'desktop', 1366, 900); await run(pw, 'mobile', 390, 844)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
