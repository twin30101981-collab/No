# -*- coding: utf-8 -*-
# HM-27 · V3 — (1) trang "Cho vay doanh nghiệp" đổi tên "Doanh nghiệp"; (2) trang mới "Thấu chi" tách khỏi "Ngắn hạn" (hết "+ thấu chi").
# Dữ liệu thử ẩn danh: dư nợ 3 mốc; ở tệp mới nhất đổi 40 dòng còn dư nợ sang loại vay OD (thấu chi). Đáp án Python độc lập.
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p05/test_hm27_thau_chi.py [app/QLTDPRO_v24.17.31.html]
import asyncio, functools, http.server, threading, sys, tempfile, subprocess, re
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.31.html'
PORT = 8865; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm27'
if not EV.parent.exists(): EV = HERE / 'hm27'
SHOT = EV / 'anh' / Path(APP).stem; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:600]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
TMP = Path(tempfile.mkdtemp()) / 'm'
subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(TMP)], check=True, stdout=subprocess.DEVNULL)
F = sorted(TMP.iterdir(), key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
wb = openpyxl.load_workbook(F[-1]); ws = wb.active; h = [c.value for c in ws[1]]; L, B = h.index('lntpcd'), h.index('dsbsbal'); k = 0
for row in ws.iter_rows(min_row=2):
    if k < 40 and (row[B].value or 0) > 0 and str(row[L].value) == '211': row[L].value = 'OD'; k += 1
wb.save(F[-1])
ws = openpyxl.load_workbook(F[-1], read_only=True).active; rows = list(ws.iter_rows(values_only=True)); h = rows[0]; L, B, N = h.index('lntpcd'), h.index('dsbsbal'), h.index('custnm')
act = [r for r in rows[1:] if (r[B] or 0) != 0 and str(r[N] or '').strip()]
TC = [r for r in act if str(r[L]) == 'OD']; NG = [r for r in act if str(r[L]) == '211']; TD = [r for r in act if str(r[L]) in ('212', '213')]
E = dict(tc=len(TC), tc_bal=sum(r[B] for r in TC), ng=len(NG), td=len(TD), all=len(act), old=len(NG) + len(TC))
assert E['tc'] == 40
def num(s): v = re.sub(r'[^\d]', '', s or ''); return int(v) if v else None
async def menu(pg, slug):
    return await pg.evaluate("""(s)=>{const a=document.querySelector('a[href="#/'+s+'"]');return a?a.textContent.trim():null}""", slug)
async def tong(pg):
    return num(await pg.evaluate("[...document.querySelectorAll('[data-testid=sc-sum] .rounded-md')].find(x=>/tổng dư nợ/i.test(x.children[0].textContent)).children[1].textContent"))
async def run(pw, name, vw, vh):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN', is_mobile=vw < 600, has_touch=vw < 600, accept_downloads=True)
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    T = lambda s: f'{name}: {s}'
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in F]); await pg.wait_for_timeout(3500)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(9000)
    await pg.goto(URL + '#/tat-ca-du-no', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    if vw < 600: await pg.click('button[aria-label*="enu"], header button >> nth=0'); await pg.wait_for_timeout(500)
    mn = {s: await menu(pg, s) for s in ('tat-ca-du-no', 'ngan-han-thau-chi', 'thau-chi', 'trung-dai-han', 'cho-vay-doanh-nghiep', 'doi-soat-so-lieu')}
    lab = lambda s, l: (mn[s] or '').replace(l, '', 1)
    ok(T('M1 menu: "Ngắn hạn" (hết "+ thấu chi"), có mục "Thấu chi", "Doanh nghiệp" (hết "Cho vay")'), (mn['ngan-han-thau-chi'] or '').startswith('Ngắn hạn') and 'thấu chi' not in (mn['ngan-han-thau-chi'] or '').lower()
       and (mn['thau-chi'] or '').startswith('Thấu chi') and (mn['cho-vay-doanh-nghiep'] or '').startswith('Doanh nghiệp') and 'Cho vay' not in (mn['cho-vay-doanh-nghiep'] or ''), mn)
    c = dict(ng=num(lab('ngan-han-thau-chi', 'Ngắn hạn')), tc=num(lab('thau-chi', 'Thấu chi')), td=num(lab('trung-dai-han', 'Trung-dài hạn')), all=num(lab('tat-ca-du-no', 'Tất cả dư nợ')))
    ok(T(f'M2 số đếm menu = Python (Ngắn hạn {c["ng"]}/{E["ng"]}, Thấu chi {c["tc"]}/{E["tc"]}, Trung-dài {c["td"]}/{E["td"]})'), c['ng'] == E['ng'] and c['tc'] == E['tc'] and c['td'] == E['td'], (c, E))
    ok(T('M3 Ngắn hạn + Thấu chi = ngắn hạn cũ; + Trung-dài = Tất cả dư nợ'), c['ng'] + c['tc'] == E['old'] and c['ng'] + c['tc'] + c['td'] == c['all'] == E['all'], (c, E))
    ds = (mn['doi-soat-so-lieu'] or ''); m = re.search(r'(\d+)/(\d+)', ds)
    ok(T(f'M4 menu Đối soát số liệu: mọi kiểm tra khớp ({ds})'), m and m[1] == m[2], ds)
    # --- trang Ngắn hạn
    await pg.goto(URL + '#/ngan-han-thau-chi', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    n1 = num(await pg.inner_text('[data-testid=dt-count]'))
    ok(T(f'N1 trang Ngắn hạn = {E["ng"]} dòng, có ghi chú "không gồm thấu chi"'), n1 == E['ng'] and 'không gồm thấu chi' in await pg.inner_text('[data-testid=tach-tc-note]'), n1)
    loai = await pg.evaluate("(()=>{const th=[...document.querySelectorAll('[data-testid=dt-th]')].map(x=>x.textContent.replace(/[▲▼]\\d*/g,'').trim());const i=th.indexOf('Loại vay');return [...document.querySelectorAll('[data-testid=dt-row]')].map(r=>r.children[i].textContent.trim())})()")
    ok(T('N2 Ngắn hạn: không dòng nào là thấu chi'), loai and not any('hấu' in x for x in loai), loai[:5])
    # --- trang Thấu chi
    await pg.goto(URL + '#/thau-chi', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    st = {k: await pg.locator(f'[data-testid={k}]').count() for k in ('page-thau-chi', 'duno-scope', 'sc-pb', 'sc-cb', 'sc-sum', 'dt-thau-chi', 'dt-count', 'dt-export', 'dt-group', 'tach-tc-note')}
    ok(T('T1 trang Thấu chi cùng cấu trúc Ngắn hạn (ô Phòng/Cán bộ, thẻ, bảng, lọc cột, Gom, Excel)'), all(v >= 1 for v in st.values()), st)
    n2 = num(await pg.inner_text('[data-testid=dt-count]')); td = await tong(pg)
    ok(T(f'T2 {n2} dòng / Tổng dư nợ {td} = Python ({E["tc"]} / {E["tc_bal"]})'), n2 == E['tc'] and td == E['tc_bal'], (n2, td, E))
    th_ = await pg.evaluate("[...document.querySelectorAll('[data-testid=dt-th]')].map(x=>x.textContent.replace(/[▲▼]\\d*/g,'').trim())")
    loai = await pg.evaluate("(i)=>[...document.querySelectorAll('[data-testid=dt-row]')].map(r=>r.children[i].textContent.trim())", th_.index('Loại vay'))
    ok(T('T3 mọi dòng Thấu chi là loại thấu chi'), loai and all('hấu chi' in x for x in loai), loai[:5])
    si = await pg.inner_text('[data-testid=dt-sortinfo]')
    ok(T(f'T4 sắp mặc định Cán bộ ↑, Ngày GN ↑ ({si.strip()[:40]})'), 'Cán bộ ↑, Ngày GN ↑' in si, si)
    await pg.screenshot(path=str(SHOT / f'{name}_thau_chi.png'))
    if vw >= 1000:
        ph = await pg.eval_on_selector_all('[data-testid=sc-pb] option', 'o=>o.map(x=>x.value).filter(Boolean)')
        exp_ph = {}
        for r in TC: exp_ph[str(r[h.index('trctnm')]).strip()] = exp_ph.get(str(r[h.index('trctnm')]).strip(), 0) + r[B]
        bad = []
        for p in ph:
            await pg.select_option('[data-testid=sc-pb]', value=p); await pg.wait_for_timeout(700)
            g = await tong(pg)
            if g != exp_ph.get(p, 0): bad.append((p, g, exp_ph.get(p, 0)))
        await pg.select_option('[data-testid=sc-pb]', value=''); await pg.wait_for_timeout(500)
        ok(T(f'T5 lọc từng phòng ({len(ph)}) → Tổng dư nợ thấu chi = Python'), ph and not bad, bad)
        async with pg.expect_download(timeout=20000) as dl: await pg.click('[data-testid=dt-export]')
        d = await dl.value; ok(T(f'T6 Xuất Excel Thau_chi ({d.suggested_filename})'), 'Thau_chi' in d.suggested_filename, d.suggested_filename)
        # --- Doanh nghiệp: đổi tên
        await pg.goto(URL + '#/cho-vay-doanh-nghiep', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
        hd = (await pg.inner_text('header, [data-testid=page-title], h1')).strip().split('\n')[0] if await pg.locator('h1').count() else ''
        title = await pg.evaluate("(()=>{const e=document.querySelector('h1,[data-testid=page-heading],header h1,header .font-bold');return e?e.textContent.trim():document.title})()")
        ok(T(f'D1 trang DN: tiêu đề "Doanh nghiệp" ({title})'), title.startswith('Doanh nghiệp') or 'Doanh nghiệp' in title and 'Cho vay' not in title, title)
        async with pg.expect_download(timeout=20000) as dl: await pg.click('[data-testid=dt-export]')
        d = await dl.value; ok(T(f'D2 Xuất Excel Doanh_nghiep ({d.suggested_filename})'), 'Doanh_nghiep' in d.suggested_filename, d.suggested_filename)
        # --- Tổng quan: dòng Thấu chi không đổi
        await pg.goto(URL + '#/tong-quan', wait_until='domcontentloaded'); await pg.wait_for_timeout(3000)
        tq = await pg.evaluate("""()=>{const r=[...document.querySelectorAll('main table tbody tr')].find(x=>/^thấu chi/i.test(x.children[0].textContent.trim())&&x.children.length===4);return r?[r.children[1].textContent,r.children[2].textContent]:null}""")
        ok(T(f'Q1 Tổng quan: dòng "Thấu chi" của bảng loại vay vẫn = Python ({tq})'), tq and num(tq[1]) == E['tc_bal'] and num(tq[0]) > 0, (tq, E['tc_bal']))
    else:
        sw = await pg.evaluate('[document.documentElement.scrollWidth, innerWidth]')
        ok(T('R1 điện thoại: trang Thấu chi không tràn ngang'), sw[0] <= sw[1], sw)
    ok(T('E1 0 pageerror'), not errs, errs[:3])
    await br.close()
async def main():
    async with async_playwright() as pw:
        await run(pw, 'desktop', 1366, 900); await run(pw, 'mobile', 390, 844)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
