# -*- coding: utf-8 -*-
# HM-25 · V3 — trang "Cho vay doanh nghiệp": nhận diện DN theo cột msit80 custtpnm (khác Cá nhân/Hộ gia đình), custdtltpnm hiển thị;
# tệp cũ không có cột → theo tên (như Chỉ tiêu kế hoạch). Đáp án Python độc lập. Kịch bản A: tệp có cột; B: tệp không cột.
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p05/test_hm25_dn.py [app/QLTDPRO_v24.17.29.html]
import asyncio, functools, http.server, threading, sys, tempfile, subprocess, re, json, unicodedata
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.29.html'
PORT = 8863; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm25'
if not EV.parent.exists(): EV = HERE / 'hm25'
SHOT = EV / 'anh' / Path(APP).stem; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:600]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
def sinh():
    t = Path(tempfile.mkdtemp()) / 'm'
    subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(t)], check=True, stdout=subprocess.DEVNULL)
    return sorted(t.iterdir(), key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
LOAI = [('Doanh nghiệp', 'Công ty TNHH'), ('Doanh nghiệp', 'Công ty cổ phần'), ('Cá nhân', 'Cá nhân trong nước'), ('Hộ gia đình', 'Hộ gia đình'), ('Cá nhân', 'Cá nhân'), ('Tổ chức khác', 'Hợp tác xã')]
def them_cot(f):   # thêm custtpnm/custdtltpnm theo mã KH (ổn định giữa các tệp)
    wb = openpyxl.load_workbook(f); ws = wb.active; h = [c.value for c in ws[1]]; b = h.index('brcd')
    ws.cell(1, len(h) + 1, 'custtpnm'); ws.cell(1, len(h) + 2, 'custdtltpnm')
    for i in range(2, ws.max_row + 1):
        k = int(re.sub(r'\D', '', str(ws.cell(i, b + 1).value or '0')) or 0) % len(LOAI)
        ws.cell(i, len(h) + 1, LOAI[k][0]); ws.cell(i, len(h) + 2, LOAI[k][1])
    wb.save(f)
def doi_ten(f, n=25):  # kịch bản B: vài khách tên doanh nghiệp
    wb = openpyxl.load_workbook(f); ws = wb.active; h = [c.value for c in ws[1]]; c = h.index('custnm')
    for i in range(2, 2 + n): ws.cell(i, c + 1, f'CÔNG TY TNHH THỬ {i}')
    wb.save(f)
def norm(x): return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9\s]', ' ', unicodedata.normalize('NFD', str(x or '').replace('đ', 'd').replace('Đ', 'D')).encode('ascii', 'ignore').decode().lower())).strip()
def dap_an(f, theo_cot):
    ws = openpyxl.load_workbook(f, read_only=True).active; rows = list(ws.iter_rows(values_only=True)); h = rows[0]; I = {k: i for i, k in enumerate(h)}
    out = dict(n=0, tong=0, kh=set(), all=0, pb={})
    for r in rows[1:]:
        if not str(r[I['custnm']] or '').strip(): continue
        bal = r[I['dsbsbal']] or 0
        if bal == 0: continue
        out['all'] += bal
        if theo_cot: dn = not re.search(r'(^|\s)(ca nhan|ho gia dinh|ho ca the|ca the)(\s|$)', norm(r[I['custtpnm']]))
        else: dn = bool(re.search(r'cong ty|tnhh|co phan', norm(r[I['custnm']])))
        if not dn: continue
        out['n'] += 1; out['tong'] += bal; out['kh'].add(str(r[I['brcd']]).strip())
        p = str(r[I['trctnm']] or '').strip(); out['pb'][p] = out['pb'].get(p, 0) + bal
    return out
def num(s): v = re.sub(r'[^\d]', '', s or ''); return int(v) if v else None
async def nap(pg, files):
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in files]); await pg.wait_for_timeout(3500)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(9000)
async def the(pg, k): return num(await pg.inner_text(f'[data-testid=dn-tong] >> text=/{k}/ >> xpath=..'))
async def card(pg, lb):
    return await pg.evaluate("""(lb)=>{const c=[...document.querySelectorAll('[data-testid=dn-tong] .rounded-md')].find(x=>x.children[0]&&x.children[0].textContent.trim().toLowerCase()===lb.toLowerCase());return c?c.children[1].textContent.trim():null}""", lb)

async def run(pw, name, vw, vh, theo_cot):
    F = sinh()
    if theo_cot:
        for f in F: them_cot(f)
    else: doi_ten(F[-1])
    E = dap_an(F[-1], theo_cot)
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN', is_mobile=vw < 600, has_touch=vw < 600, accept_downloads=True)
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    T = lambda s: f'{name} {"A" if theo_cot else "B"}: {s}'
    await nap(pg, F)
    await pg.goto(URL + '#/cho-vay-doanh-nghiep', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    ok(T('P1 có trang #/cho-vay-doanh-nghiep (cùng khung trang Ngắn hạn: ô Phòng/Cán bộ, thẻ, bảng)'), await pg.locator('[data-testid=page-cho-vay-doanh-nghiep] [data-testid=sc-cb]').count() == 1 and await pg.locator('[data-testid=dt-cho-vay-doanh-nghiep]').count() == 1)
    cnt = num(await pg.inner_text('[data-testid=dt-count]'))
    ok(T(f'P2 số dòng = Python ({cnt} / {E["n"]})'), cnt == E['n'], (cnt, E['n']))
    v = {k: num(await card(pg, k)) for k in ('Ngắn hạn', 'Trung hạn', 'Dài hạn', 'Thấu chi')}
    v['Dư nợ doanh nghiệp'] = num(await pg.evaluate("[...document.querySelectorAll('[data-testid=sc-sum] .rounded-md')].find(x=>/tổng dư nợ/i.test(x.children[0].textContent)).children[1].textContent"))
    v['Số doanh nghiệp'] = num(await pg.evaluate("[...document.querySelectorAll('[data-testid=sc-sum] .rounded-md')].find(x=>/^khách hàng$/i.test(x.children[0].textContent.trim())).children[1].textContent"))
    ok(T(f'P3 thẻ Tổng dư nợ / Khách hàng (= DN) = Python ({v["Dư nợ doanh nghiệp"]} · {v["Số doanh nghiệp"]})'), v['Dư nợ doanh nghiệp'] == E['tong'] and v['Số doanh nghiệp'] == len(E['kh']), (v, E['tong'], len(E['kh'])))
    ok(T('P4 Ngắn + Trung + Dài + Thấu chi = Dư nợ DN'), sum(v[k] or 0 for k in ('Ngắn hạn', 'Trung hạn', 'Dài hạn', 'Thấu chi')) == E['tong'], v)
    tt = await card(pg, 'Tỷ trọng / dư nợ chi nhánh'); exp = round(E['tong'] / E['all'] * 100, 2)
    ok(T(f'P5 tỷ trọng = {exp}% ({tt})'), tt and abs(float(tt.replace('%', '').replace(',', '.')) - exp) < 0.006, (tt, exp))
    nguon = await pg.inner_text('[data-testid=dn-nguon]')
    ok(T('P6 ghi chú nguồn nhận diện' + (' (không có dòng tính theo tên)' if theo_cot else ' (báo số dòng tính theo tên)')), ('chưa có cột' not in nguon) if theo_cot else ('chưa có cột' in nguon), nguon)
    si = await pg.inner_text('[data-testid=dt-sortinfo]')
    ok(T(f'P7 sắp mặc định Cán bộ ↑, Ngày GN ↑ ({si.strip()[:40]})'), 'Cán bộ ↑, Ngày GN ↑' in si, si)
    await pg.screenshot(path=str(SHOT / f'{name}_{"A" if theo_cot else "B"}.png'))
    if vw >= 1000:
        th = await pg.evaluate("[...document.querySelectorAll('[data-testid=dt-th]')].map(x=>x.textContent.replace(/[▲▼]\\d*/g,'').trim())")
        if theo_cot:
            i = th.index('Loại KH (IPCAS)') if 'Loại KH (IPCAS)' in th else None
            vals = await pg.evaluate("(i)=>[...document.querySelectorAll('[data-testid=dt-row]')].slice(0,30).map(r=>r.children[i].textContent.trim())", i) if i is not None else []
            ok(T('P8 cột "Loại KH (IPCAS)" hiện custdtltpnm, chỉ loại DN'), vals and set(vals) <= {'Công ty TNHH', 'Công ty cổ phần', 'Hợp tác xã'}, (th, vals[:8]))
        ph = sorted(E['pb'])[0]
        await pg.select_option('[data-testid=sc-pb]', value=ph); await pg.wait_for_timeout(900)
        g = num(await pg.evaluate("[...document.querySelectorAll('[data-testid=sc-sum] .rounded-md')].find(x=>/tổng dư nợ/i.test(x.children[0].textContent)).children[1].textContent"))
        ok(T(f'P9 chọn phòng "{ph}" → thẻ Dư nợ DN theo phòng = Python'), g == E['pb'][ph], (g, E['pb'][ph]))
        await pg.select_option('[data-testid=sc-pb]', value=''); await pg.wait_for_timeout(500)
        async with pg.expect_download(timeout=20000) as dl: await pg.click('[data-testid=dt-export]')
        d = await dl.value; ok(T(f'P10 Xuất Excel ({d.suggested_filename})'), 'Doanh_nghiep' in d.suggested_filename, d.suggested_filename)
        mn = await pg.evaluate("(()=>{const a=[...document.querySelectorAll('a[href=\"#/cho-vay-doanh-nghiep\"]')][0];return a?a.textContent.trim():null})()")
        ok(T(f'P11 menu Dư nợ có mục "Doanh nghiệp" (đổi tên HM-27) kèm số dòng ({mn})'), mn and mn.startswith('Doanh nghiệp') and 'Cho vay' not in mn and num(mn) == E['n'], mn)
        await pg.goto(URL + '#/chi-tieu-ke-hoach', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500); await pg.evaluate("(()=>{const b=document.querySelector('[data-testid=ct-tab-matrix]');b&&b.click()})()"); await pg.wait_for_timeout(800)  # P06: tab mặc định nay là BÁO CÁO NGÀY
        lv = await pg.evaluate("""()=>{const t=document.querySelector('[data-testid=ct-matrix]');const hs=[...t.querySelectorAll('thead th')].map(x=>x.textContent.trim());
          const tr=[...t.tBodies[0].rows].find(r=>/dư nợ doanh nghiệp/i.test(r.children[0].textContent));return tr?tr.children[hs.indexOf('Hiện tại (Live)')].textContent:null}""")
        lvn = num((re.match(r'\s*[\d.]+', lv or '') or [''])[0])
        ok(T(f'P12 Chỉ tiêu kế hoạch "Dư nợ Doanh nghiệp" Live = tổng trang DN ({lv})'), lvn == E['tong'], (lv, E['tong']))
    else:
        sw = await pg.evaluate('[document.documentElement.scrollWidth, innerWidth]')
        ok(T('M1 điện thoại: không tràn ngang trang'), sw[0] <= sw[1], sw)
    ok(T('E1 0 pageerror'), not errs, errs[:3])
    await br.close()

async def main():
    async with async_playwright() as pw:
        await run(pw, 'desktop', 1366, 900, True); await run(pw, 'mobile', 390, 844, True); await run(pw, 'desktop', 1366, 900, False)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
