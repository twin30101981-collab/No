# -*- coding: utf-8 -*-
# HM-21b · V3 — DÒNG dữ liệu ở mọi bảng (Tất cả dư nợ, Ngắn hạn, Trung-dài hạn, Nợ đến hạn, Lãi đọng, Chuyển HM, Giải ngân, Dư nợ cầm cố,
# Tài sản bảo đảm, Trả nợ/xuất TS) mặc định xếp theo cán bộ (danh mục như Báo cáo ngày) rồi ngày cũ → mới. Cuộn hết bảng, chụp ảnh từng trang.
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p05/test_hm21b_dong_cb.py [app/QLTDPRO_v24.17.28.html]
import asyncio, functools, http.server, threading, sys, tempfile, subprocess, re, json
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.28.html'
PORT = 8862; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm21b'
if not EV.parent.exists(): EV = HERE / 'hm21b'
SHOT = EV / 'anh' / Path(APP).stem; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:700]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
TMP = Path(tempfile.mkdtemp()) / 'm'
subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(TMP)], check=True, stdout=subprocess.DEVNULL)
FILES = sorted(TMP.iterdir(), key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
ROSTER = [('Hội Sở', 'VŨ THỊ HẰNG'), ('Hội Sở', 'BÙI THỊ MAI'), ('PGD Hai Bà Trưng', 'TRẦN VĂN CB'), ('PGD Hai Bà Trưng', 'ĐỖ VĂN LONG'),
          ('PGD Số 2', 'PHẠM THỊ CB'), ('PGD Số 2', 'LÊ VĂN CB'), ('PGD Số 2', 'NGUYỄN THỊ CB')]
EXP = [n for _, n in ROSTER]
RTXT = '\n'.join(f'{p} | {n} | CBTD' for p, n in ROSTER)
# sao kê TS có khách CÒN dư nợ (để trang TSBĐ/cầm cố có dòng) — mã KH lấy từ dư nợ 31/10
_ws = openpyxl.load_workbook(FILES[-1], read_only=True).active; _rows = list(_ws.iter_rows(values_only=True)); _h = _rows[0]
KH = []
for r in _rows[1:]:
    k = (str(r[_h.index('brcd')]), r[_h.index('custnm')], r[_h.index('ofcnm')], r[_h.index('trctnm')])
    if k not in KH: KH.append(k)
    if len(KH) >= 40: break
def ts(i, k):
    d = f'{(i * 7) % 28 + 1:02d}/{(i * 5) % 12 + 1:02d}/{2015 + i % 10}'
    return {'clno': f'TS{i:03d}', 'clcustno': k[0], 'clcustnm': k[1], 'cltpcd': 'Đất ở', 'cldtltpcd': 'Thổ cư', 'clqtysz': '100', 'clunittpcd': 'm2', 'clloc': f'{i} Phố Thử',
            'clamt': 1_000_000_000, 'plgno': f'LCA{i:03d}', 'plgdt': d, 'plgtpcd': 'TC', 'exprdt': '01/09/2030', 'avblamtrt': '70', 'plgamt': 700_000_000,
            'plgcustno': k[0], 'plgcustnm': k[1], 'clccycd': 'VND', 'clholdcd': 'N', 'ntydt': d, 'rem': '', 'lnofcnm': k[2], 'trctcd': k[3], 'name_2': f'GCN{i}'}
TSR = [ts(i, k) for i, k in enumerate(KH)]
TSF = Path(tempfile.mkdtemp()) / '31_10_2026-TS.xlsx'
_wb = openpyxl.Workbook(); _w = _wb.active; _hh = list(TSR[0].keys()); _w.append(_hh)
for r in TSR: _w.append([r[k] for k in _hh])
_wb.save(TSF)
PAGES = ['#/tat-ca-du-no', '#/ngan-han-thau-chi', '#/trung-dai-han', '#/no-den-han', '#/lai-dong', '#/chuyen-han-muc', '#/giai-ngan', '#/du-no-cam-co', '#/tai-san-bao-dam', '#/tra-no-xuat-ts']
def dk(s): m = re.match(r'(\d{1,2})/(\d{1,2})/(\d{4})', s or ''); return (int(m[3]), int(m[2]), int(m[1])) if m else None
def rank(c): return EXP.index(c) if c in EXP else 99

GOM = r"""async()=>{const g=document.querySelector('[data-testid^="dt-"][data-testid$="'+location.hash.slice(2)+'"]')||document;
  const th=[...document.querySelectorAll('[data-testid=dt-th]')].map(x=>x.textContent.replace(/[▲▼↑↓]\d*/g,'').trim());
  const si=((document.querySelector('[data-testid=dt-sortinfo]')||{}).textContent||'').trim();
  const sc=document.querySelector('[data-testid=dt-scroll]');const out=[],seen=new Set();let last=-1;
  for(let i=0;i<800&&sc&&sc.scrollTop!==last;i++){last=sc.scrollTop;
    document.querySelectorAll('[data-testid=dt-row]').forEach(r=>{const k=Math.round(r.getBoundingClientRect().top+sc.scrollTop);if(seen.has(k))return;seen.add(k);out.push([k,[...r.children].map(c=>c.textContent.trim())])});
    sc.scrollTop+=sc.clientHeight*0.9;await new Promise(r=>setTimeout(r,20))}
  if(sc)sc.scrollTop=0;out.sort((a,b)=>a[0]-b[0]);return {th,si,rows:out.map(x=>x[1])}}"""

async def nap(pg, files):
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in files]); await pg.wait_for_timeout(3500)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(9000)

def kiem(d):
    th, si, rows = d['th'], d['si'], d['rows']
    ci = next((i for i, h in enumerate(th) if h in ('Cán bộ', 'CBTD')), None)
    m = re.match(r'Sắp xếp:\s*(.*?)\s*(bỏ|$)', si); keys = [k.strip() for k in (m[1] if m else '').split(',') if k.strip()]
    lb2 = re.sub(r'\s*[↑↓]$', '', keys[1]) if len(keys) > 1 else None
    di = th.index(lb2) if lb2 in th else None
    cbs = [r[ci] for r in rows if ci is not None and len(r) > ci]
    seq = [rank(c) for c in cbs]
    loi = [i for i in range(1, len(seq)) if seq[i] < seq[i - 1]]
    dloi = []
    if di is not None:
        for i in range(1, len(rows)):
            if cbs[i] == cbs[i - 1]:
                a, b = dk(rows[i - 1][di]), dk(rows[i][di])
                if a and b and b < a: dloi.append((i, cbs[i], rows[i - 1][di], rows[i][di]))
    thu = []
    for c in cbs:
        if not thu or thu[-1] != c: thu.append(c)
    return dict(n=len(rows), keys=keys, ci=ci, di=di, lb2=lb2, loi=loi[:5], dloi=dloi[:5], thu=thu[:12])

async def run(pw, name, vw, vh):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN', is_mobile=vw < 600, has_touch=vw < 600)
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0');localStorage.setItem('td_roster_v1'," + json.dumps(RTXT) + ")}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    await nap(pg, FILES + [TSF])
    for r in PAGES:
        await pg.goto(URL + r, wait_until='domcontentloaded'); await pg.wait_for_timeout(2200)
        tc = pg.locator('main button', has_text=re.compile(r'^Tất cả$'))
        if await tc.count(): await tc.first.click(); await pg.wait_for_timeout(1200)
        d = await pg.evaluate(GOM); k = kiem(d)
        await pg.wait_for_timeout(1500)
        ch = await pg.evaluate("(()=>{const t=[...document.querySelectorAll('[data-testid=dt-row]')].map(r=>Math.round(r.getBoundingClientRect().top));return t.filter((x,i)=>t.indexOf(x)!==i).length})()")
        await pg.screenshot(path=str(SHOT / f"{r.strip('#/')}_{name}.png"))
        ok(f'{name} {r}: ảnh chụp — 0 dòng chồng nhau', ch == 0, ch)
        if k['n'] == 0 and r == '#/du-no-cam-co':
            print(f'SKIP {name} {r}: dữ liệu thử không có khoản cầm cố (0 dòng) — chỉ kiểm sắp mặc định', flush=True)
            ok(f'{name} {r}: sắp mặc định "Cán bộ ↑" trước ({", ".join(k["keys"])})', k['keys'] and re.match(r'^(Cán bộ|CBTD) ↑$', k['keys'][0]), d['si']); continue
        ok(f'{name} {r}: sắp mặc định "Cán bộ ↑" trước ({", ".join(k["keys"])})', k['keys'] and re.match(r'^(Cán bộ|CBTD) ↑$', k['keys'][0]), (d['si'], d['th'][:6]))
        ok(f'{name} {r}: {k["n"]} dòng — cán bộ theo danh mục (Phòng → Cán bộ như Báo cáo ngày), cuộn hết bảng', k['n'] > 0 and k['ci'] is not None and not k['loi'], k)
        if k['lb2']: ok(f'{name} {r}: trong mỗi cán bộ "{k["lb2"]}" cũ → mới', k['di'] is not None and not k['dloi'], k)
    if vw >= 1000:
        # bố cục cũ đã lưu (chưa có l21) → chuyển một lần: sort mới, giữ độ rộng cột
        await pg.evaluate("""()=>{localStorage.setItem('qltd2_tbl_tat-ca-du-no',JSON.stringify({gd7:'24.6.1',sort:[{id:'ngaygn',desc:false}],widths:{tenkh:333},filters:{},hidden:[],pinned:['tenkh'],group:'none',density:'vua'}))}""")
        await pg.goto(URL + '#/tat-ca-du-no', wait_until='domcontentloaded'); await pg.wait_for_timeout(2200)
        si = await pg.inner_text('[data-testid=dt-sortinfo]')
        w = await pg.evaluate("Math.round([...document.querySelectorAll('[data-testid=dt-th]')].find(x=>x.textContent.includes('Tên khách hàng')).getBoundingClientRect().width)")
        ok(f'{name} L1 bố cục đã lưu trước HM-21b → sắp chuyển sang Cán bộ ↑ một lần, giữ độ rộng cột ({si.strip()[:40]}; rộng {w})', si.strip().startswith('Sắp xếp: Cán bộ ↑') and abs(w - 333) <= 2, (si, w))
        await pg.click('[data-testid=dt-sort-default]') if await pg.locator('[data-testid=dt-sort-default]').count() else None
    ok(f'{name} E1 0 pageerror', not errs, errs[:3])
    await br.close()

async def main():
    async with async_playwright() as pw:
        await run(pw, 'desktop', 1366, 900); await run(pw, 'mobile', 390, 844)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
