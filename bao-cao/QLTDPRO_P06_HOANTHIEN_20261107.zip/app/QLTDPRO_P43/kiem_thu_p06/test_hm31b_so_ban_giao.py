# -*- coding: utf-8 -*-
# HM-31 GĐ2 · V3 — Sổ bàn giao: app gợi ý → xác nhận → Báo cáo ngày tính lại các mốc theo cán bộ nhận; phạm vi DN / Trung+dài / Trung hạn.
# DỮ LIỆU THẬT qua QLTD_MSIT80_DIR (31.12.2025.xlsx, 30.09.2026.XLS, 31.10.2026.XLS) — KHÔNG để trong repo/ZIP; thiếu ⇒ SKIP.
# Đáp án: kiem_thu_p06/dap_an_ban_giao.py (pandas đọc thẳng tệp gốc, độc lập với app).
# Chạy từ app/QLTDPRO_P43/:  QLTD_MSIT80_DIR=/duong/dan python3 kiem_thu_p06/test_hm31b_so_ban_giao.py [app/QLTDPRO_v24.17.36.html]
import asyncio, functools, http.server, threading, sys, os, re, json, tempfile
from pathlib import Path
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.36.html'
D = Path(os.environ.get('QLTD_MSIT80_DIR', '/khong-co'))
FS = [D / '31.12.2025.xlsx', D / '30.09.2026.XLS', D / '31.10.2026.XLS']
if not all(f.exists() for f in FS):
    print('SKIP: không có dữ liệu msit80 thật (đặt QLTD_MSIT80_DIR)'); print('\nKẾT QUẢ: 0 PASS · 0 FAIL (SKIP)'); raise SystemExit(0)
sys.path.insert(0, str(HERE))
import warnings; warnings.filterwarnings('ignore')
from dap_an_ban_giao import doc, goi_y, ap_dung, bang, norm
from playwright.async_api import async_playwright
PORT = 8872; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm31'
if not EV.parent.exists(): EV = HERE / 'hm31'
SHOT = EV / 'anh' / Path(APP).stem; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:900]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
N, Qq, B = [doc(f) for f in FS]
GY = goi_y(N, Qq) + goi_y(Qq, B)
def dap(so, loc=None):
    a, b, c = bang(ap_dung(N, so, B), loc), bang(ap_dung(Qq, so, B), loc), bang(B, loc)
    return {k: [a.get(k, {}).get(t, 0) for t in ('kh', 'dn')] + [b.get(k, {}).get(t, 0) for t in ('kh', 'dn')] + [c.get(k, {}).get(t, 0) for t in ('kh', 'dn')] for k in set(a) | set(b) | set(c)}
PB = {'hội sở': 'Hội Sở', 'pgd hai bà trưng': 'PGD Hai Bà Trưng', 'pgd số 2': 'PGD Số 2'}
cur = B[B.bal > 0].groupby('cb').trctnm.agg(lambda s: s.mode().iloc[0]) if 'trctnm' in B else None
import pandas as pd
_t = pd.read_excel(FS[2], header=0, usecols=['ofcnm', 'trctnm']); _t['cb'] = _t.ofcnm.fillna('').astype(str).str.strip()
ROSTER = [(PB.get(str(p).strip().lower(), p), n) for n, p in _t[_t.cb != ''].groupby('cb').trctnm.agg(lambda s: s.mode().iloc[0]).items()]
def num(t):
    t = (t or '').strip()
    if t in ('', '-'): return 0
    v = re.sub(r'[^\d]', '', t); return (-1 if t.startswith('-') else 1) * int(v)
async def bang_app(pg, tab):
    await pg.click(f'[data-testid=bcn-sub-{tab}]'); await pg.wait_for_timeout(400)
    r = await pg.evaluate("[...document.querySelectorAll('[data-testid=bcn-table] tbody tr')].map(r=>[r.dataset.kind,...[...r.children].map(c=>c.textContent.trim())])")
    return {k: [[num(x) for x in row[2:6]] for row in r if row[0] == k] for k in ('tong',)}, {norm(row[1]): [num(x) for x in row[2:6]] for row in r if row[0] == 'cbtd'}
async def so_sanh(pg, T, so, loc, nhan):
    E = dap(so, loc); tk, ck = await bang_app(pg, 'kh'); td, cd = await bang_app(pg, 'dn')
    ek = [sum(v[i] for v in E.values()) for i in (0, 2, 2, 4)]; ed = [sum(v[i] for v in E.values()) for i in (1, 3, 3, 5)]
    ok(T(f'{nhan}: TỔNG KH 4 mốc {tk["tong"][0]} = Python {ek}'), tk['tong'][0] == ek, (tk['tong'], ek))
    ok(T(f'{nhan}: TỔNG dư nợ 4 mốc = Python (±2 đ) {td["tong"][0]}'), all(abs(a - b) <= 2 for a, b in zip(td['tong'][0], ed)), (td['tong'], ed))
    sai = []
    for k, v in E.items():
        if not any(v): continue
        a, b = ck.get(k), cd.get(k)
        if a != [v[0], v[2], v[2], v[4]] or not b or any(abs(x - y) > 2 for x, y in zip(b, [v[1], v[3], v[3], v[5]])): sai.append((k[:12], a, b, v))
    du = [k for k in ck if k not in E or not any(E[k])]
    du = [k for k in du if any(ck[k]) or any(cd.get(k, [0]))]
    ok(T(f'{nhan}: từng cán bộ ({len([k for k in E if any(E[k])])}) KH + dư nợ 4 mốc = Python'), not sai and not du, (sai[:3], du[:3]))
    kt = (await pg.inner_text('[data-testid=bg-kiem]')).strip()
    ok(T(f'{nhan}: kiểm Σ cán bộ = Σ phòng = TỔNG = tổng tệp ({kt[:60]})'), kt.startswith('✓'), kt)
    return td['tong'][0]
async def mo(pg):
    await pg.goto(URL + '#/chi-tieu-ke-hoach', wait_until='domcontentloaded'); await pg.wait_for_timeout(3500)
    await pg.click('[data-testid=ct-tab-ngay]'); await pg.wait_for_selector('[data-testid=bg-host] [data-testid=bg-bar]', timeout=20000); await pg.wait_for_timeout(1000)
async def run(pw, name, vw, vh, day_du):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN', is_mobile=vw < 600, has_touch=vw < 600, accept_downloads=True)
    await ctx.add_init_script("try{if(!sessionStorage.getItem('__k')){sessionStorage.setItem('__k','1');localStorage.setItem('gd9_tplok','0');localStorage.setItem('td_roster_v1'," + json.dumps('\n'.join(f'{p} | {n} | CBTD' for p, n in ROSTER)) + ")}}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    T = lambda s: f'{name}: {s}'
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in FS]); await pg.wait_for_timeout(12000)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(1000)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(25000)
    await mo(pg)
    g = await pg.evaluate("[...document.querySelectorAll('[data-testid=bg-goiy-row]')].map(r=>[r.dataset.tu,r.dataset.kieu,r.children[2].querySelector('b').textContent,r.children[0].textContent])")
    eg = sorted((norm(b['tu']), b['kieu'], norm(b['den'])) for b in GY); ag = sorted((norm(a), b, norm(c)) for a, b, c, _ in g)
    ok(T(f'G1 app gợi ý {len(g)} bàn giao (hiệu lực {sorted(set(x[3] for x in g))}) = Python {len(GY)} (từ cán bộ, nguyên/chia, người nhận)'), ag == eg and all(x[3] == '31/10/2026' for x in g), (ag, eg))
    so0 = await so_sanh(pg, T, [], None, 'G2 chưa xác nhận (= GĐ1)')
    await pg.screenshot(path=str(SHOT / f'{name}_1_goi_y.png'), full_page=True)
    await pg.click('[data-testid=bg-xn-all]'); await pg.wait_for_timeout(1500)
    n = (await pg.inner_text('[data-testid=bg-n]')).strip(); ng = await pg.locator('[data-testid=bg-goiy-row]').count()
    ok(T(f'G3 xác nhận tất cả → sổ {n} dòng, còn {ng} gợi ý'), n == str(len(GY)) and ng == 0, (n, ng))
    so = [dict(b) for b in GY]
    await so_sanh(pg, T, so, None, 'G4 sau xác nhận')
    await pg.screenshot(path=str(SHOT / f'{name}_2_da_xac_nhan.png'), full_page=True)
    if not day_du:
        sw = await pg.evaluate("[document.scrollingElement.scrollWidth, innerWidth]")
        ok(T(f'M1 điện thoại: trang không cuộn ngang ({sw})'), sw[0] <= sw[1] + 1, sw)
    else:
        for loc, nh in (('dn', 'G5 phạm vi Doanh nghiệp'), ('th', 'G6 phạm vi Trung + dài hạn'), ('th212', 'G7 phạm vi Trung hạn TK 212'), ('nh', 'G7b phạm vi Ngắn hạn + thấu chi')):
            await pg.select_option('[data-testid=bcn-loc]', loc); await pg.wait_for_timeout(1500)
            hd = (await pg.inner_text('[data-testid=bcn-header]')).strip()
            ok(T(f'{nh}: tiêu đề "{hd}"'), ('DOANH NGHIỆP' if loc == 'dn' else 'NGẮN' if loc == 'nh' else 'TRUNG') in hd and hd.endswith('31/10/2026'), hd)
            await so_sanh(pg, T, so, loc, nh)
            if loc == 'dn': await pg.screenshot(path=str(SHOT / f'{name}_3_dn.png'), full_page=True)
        await pg.select_option('[data-testid=bcn-loc]', ''); await pg.wait_for_timeout(1000)
        # F5 giữ sổ
        await pg.reload(wait_until='domcontentloaded'); await mo(pg)
        n = (await pg.inner_text('[data-testid=bg-n]')).strip()
        ok(T(f'G8 F5 → sổ vẫn {n} dòng, phạm vi về Tất cả'), n == str(len(GY)) and await pg.eval_on_selector('[data-testid=bcn-loc]', 'e=>e.value') == '', n)
        await so_sanh(pg, T, so, None, 'G8b sau F5')
        # xuất sổ
        await pg.evaluate("document.querySelector('[data-testid=bg-so]').open=true"); await pg.wait_for_timeout(300)
        async with pg.expect_download() as dl:
            await pg.click('[data-testid=bg-xuat]')
        p = Path(tempfile.mkdtemp()) / 'so.json'; await (await dl.value).save_as(p)
        js = json.loads(p.read_text(encoding='utf-8'))
        ok(T(f'G9 xuất sổ JSON: {len(js.get("so", []))} dòng, loại QLTDPRO-so-ban-giao'), js.get('loai') == 'QLTDPRO-so-ban-giao' and len(js['so']) == len(GY), js.get('loai'))
        # xoá 1 dòng
        x = [b for b in GY if b['kieu'] == 'nguyen'][0]
        k = await pg.evaluate("t=>{const r=[...document.querySelectorAll('[data-testid=bg-da-row]')].find(r=>r.children[1].textContent.startsWith(t));r.querySelector('[data-testid=bg-xoa]').click();return 1}", x['tu'])
        await pg.wait_for_timeout(1500)
        so2 = [b for b in so if b['tu'] != x['tu']]
        n = (await pg.inner_text('[data-testid=bg-n]')).strip()
        ok(T(f'G10 xoá 1 dòng sổ → còn {n}; nó lại hiện ở gợi ý'), n == str(len(GY) - 1) and await pg.locator('[data-testid=bg-goiy-row]').count() == 1, n)
        await so_sanh(pg, T, so2, None, 'G10b sau xoá 1 dòng')
        # nhập lại sổ đã xuất
        await pg.set_input_files('[data-testid=bg-nhap]', str(p)); await pg.wait_for_timeout(2000)
        n = (await pg.inner_text('[data-testid=bg-n]')).strip()
        ok(T(f'G11 nhập sổ JSON → {n} dòng (không trùng)'), n == str(len(GY)), n)
        await so_sanh(pg, T, so, None, 'G11b sau nhập sổ')
    ok(T('E1 0 pageerror'), not errs, errs[:3])
    await br.close()
async def main():
    async with async_playwright() as pw:
        await run(pw, 'desktop', 1366, 900, True)
        await run(pw, 'mobile', 390, 844, False)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
