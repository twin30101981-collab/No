# HM-09 · đo hiệu năng trang Chỉ tiêu kế hoạch (CDP profiler) với 12 mốc msit80 thật (QLTD_MSIT80_DIR; không có trong repo).
# Chạy: QLTD_MSIT80_DIR=… python3 kiem_thu_p06/do_hieu_nang_ctkh.py app/QLTDPRO_v24.17.41.html
import asyncio, functools, http.server, threading, json, time, sys, os, collections
from pathlib import Path
from playwright.async_api import async_playwright
APP = sys.argv[1]; ROOTD = Path(APP).parent; PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 8895
URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOTD))).serve_forever, daemon=True).start()
FS = ['31.12.2025.xlsx','31.01.2026.xlsx','28.02.2026.xlsx','31.03.2026.XLS','30.04.2026.xlsx','31.05.2026.xlsx','30.06.2026.XLS','31.07.2026.XLS','31.08.2026.XLS','30.09.2026.XLS','31.10.2026.XLS','05.11.2026.XLS']
HTML_SRC = open(APP, encoding='utf-8').read()
async def main():
    async with async_playwright() as pw:
        br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': 1440, 'height': 900}, locale='vi-VN')
        await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
        pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
        await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
        await pg.set_input_files('[data-testid="file-input"]', [str(Path(os.environ.get('QLTD_MSIT80_DIR', 'that')) / f) for f in FS]); await pg.wait_for_timeout(30000)
        await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(1000)
        y = pg.locator('[data-testid="confirm-yes"]')
        if await y.count(): await y.click()
        await pg.wait_for_timeout(60000)
        nmoc = await pg.evaluate("JSON.parse(localStorage.getItem('_archiveReportList')||'[]').filter(x=>x.type==='report').length")
        cdp = await ctx.new_cdp_session(pg); await cdp.send('Profiler.enable'); await cdp.send('Profiler.setSamplingInterval', {'interval': 200})
        T = {}
        async def do(name, coro_fn, wait_sel=None):
            t0 = time.time(); await coro_fn()
            if wait_sel: await pg.wait_for_selector(wait_sel, timeout=120000)
            await pg.evaluate("new Promise(r=>requestAnimationFrame(()=>setTimeout(r,0)))"); T[name] = round(time.time() - t0, 2)
        await cdp.send('Profiler.start')
        await do('1 mở Chỉ tiêu KH (mặc định BÁO CÁO NGÀY)', lambda: pg.goto(URL + '#/chi-tieu-ke-hoach', wait_until='domcontentloaded'), '[data-testid=bg-host] [data-testid=bg-bar]')
        for t in ('matrix', 'cbtd', 'phong', 'loaivay'):
            await do(f'2 tab {t}', lambda t=t: pg.click(f'[data-testid=ct-tab-{t}]'), f'[data-testid=ct-pn-{t}]')
        await do('3 tab BÁO CÁO NGÀY', lambda: pg.click('[data-testid=ct-tab-ngay]'), '[data-testid=bg-host] [data-testid=bg-bar]')
        await pg.evaluate("document.querySelector('[data-testid=bg-so]').open=true")
        await do('4 xác nhận 9 gợi ý (hiệu lực 01/10)', lambda: pg.fill('[data-testid=bg-hl]', '2026-10-01'))
        await do('4b', lambda: pg.click('[data-testid=bg-xn-all]'))
        await do('5 đổi phạm vi → Doanh nghiệp', lambda: pg.select_option('[data-testid=bcn-loc]', 'dn'))
        await do('6 đổi phạm vi → Tất cả', lambda: pg.select_option('[data-testid=bcn-loc]', ''))
        await do('7 chuyển tab DƯ NỢ', lambda: pg.click('[data-testid=bcn-sub-dn]'))
        await do('8 áp mẫu kế hoạch quý', lambda: pg.evaluate("document.querySelector('[data-testid=kh-so]').open=true;document.querySelector('[data-testid=kh-mau-ok]').click()"))
        await do('9 sửa 1 ô kế hoạch', lambda: pg.evaluate("(()=>{const i=document.querySelector('[data-testid=kh-in-dn]');i.value='2.100';i.dispatchEvent(new Event('change',{bubbles:true}))})()"))
        await do('10 quay lại TỔNG QUAN', lambda: pg.click('[data-testid=ct-tab-matrix]'), '[data-testid=ct-matrix]')
        prof = (await cdp.send('Profiler.stop'))['profile']
        # tự thời gian theo hàm
        nodes = {n['id']: n for n in prof['nodes']}; dt = collections.Counter(); 
        deltas = prof['timeDeltas']; samples = prof['samples']
        for s, d in zip(samples, deltas): dt[s] += d
        agg = collections.Counter(); info = {}
        for nid, us in dt.items():
            cf = nodes[nid]['callFrame']; k = (cf['functionName'] or '(anon)', cf['url'].split('/')[-1][:30], cf['lineNumber'], cf['columnNumber']); agg[k] += us
        tot = sum(agg.values())
        print('Số mốc lưu trữ:', nmoc); print(json.dumps(T, ensure_ascii=False, indent=0)); print('Tổng mẫu CPU (s):', round(tot / 1e6, 2))
        lines = HTML_SRC.split('\n')
        for k, us in agg.most_common(25):
            ctxs = ''
            if k[1].startswith('QLTDPRO') and k[2] >= 0:
                ln = lines[k[2]] if k[2] < len(lines) else ''; ctxs = ln[max(0, k[3] - 60):k[3] + 60].replace('\n', ' ')
            print(f'{us/1e6:7.2f}s  {k[0][:28]:28} L{k[2]}:{k[3]}  | {ctxs[:120]}')
        pass
        print('pageerror', errs[:2]); await br.close()
asyncio.run(main())
