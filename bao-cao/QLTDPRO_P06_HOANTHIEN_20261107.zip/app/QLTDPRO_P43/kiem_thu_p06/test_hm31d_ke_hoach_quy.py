# -*- coding: utf-8 -*-
# HM-31 GĐ3 · V3 — v24.17.39: kế hoạch quý theo cán bộ (dán/áp mẫu), chuyển kế hoạch theo sổ bàn giao (bảo toàn tổng),
# % thực hiện + dự báo cuối quý, xuất Excel đúng mẫu 4 bảng, đối soát với báo cáo tay.
# DỮ LIỆU THẬT qua QLTD_MSIT80_DIR (31.12.2025.xlsx, 30.09.2026.XLS, 31.10.2026.XLS) và QLTD_BANIN_JSON (số báo cáo tay 31/10/2026) — KHÔNG để trong repo/ZIP; thiếu ⇒ SKIP.
# Đáp án: kiem_thu_p06/dap_an_ban_giao.py (pandas đọc thẳng tệp gốc). Chạy từ app/QLTDPRO_P43/:
#   QLTD_MSIT80_DIR=/dir QLTD_BANIN_JSON=/f.json python3 kiem_thu_p06/test_hm31d_ke_hoach_quy.py [app/QLTDPRO_v24.17.39.html]
import asyncio, functools, http.server, threading, sys, os, re, json, tempfile, warnings, math
from pathlib import Path
warnings.filterwarnings('ignore')
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.39.html'
D = Path(os.environ.get('QLTD_MSIT80_DIR', '/khong-co')); BJ = Path(os.environ.get('QLTD_BANIN_JSON', '/khong-co.json'))
FS = [D / '31.12.2025.xlsx', D / '30.09.2026.XLS', D / '31.10.2026.XLS']
if not all(f.exists() for f in FS) or not BJ.exists():
    print('SKIP: không có dữ liệu thật (đặt QLTD_MSIT80_DIR, QLTD_BANIN_JSON)'); print('\nKẾT QUẢ: 0 PASS · 0 FAIL (SKIP)'); raise SystemExit(0)
sys.path.insert(0, str(HERE))
import pandas as pd, openpyxl
from dap_an_ban_giao import doc, goi_y, ap_dung, bang, norm, cb_kh
from playwright.async_api import async_playwright
PORT = 8874; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm31'
if not EV.parent.exists(): EV = HERE / 'hm31'
SHOT = EV / 'anh' / Path(APP).stem; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:900]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
N, Qq, B = [doc(f) for f in FS]
GY = goi_y(N, Qq) + goi_y(Qq, B); SO = [dict(b) for b in GY]
BANIN = json.loads(BJ.read_text(encoding='utf-8'))
TEN = {}
for d_ in (N, Qq, B):
    for n in d_[d_.cb != ''].cb.unique(): TEN[norm(n)] = n
PB = {'hội sở': 'Hội Sở', 'pgd hai bà trưng': 'PGD Hai Bà Trưng', 'pgd số 2': 'PGD Số 2'}
_t = pd.read_excel(FS[2], header=0, usecols=['ofcnm', 'trctnm']); _t['cb'] = _t.ofcnm.fillna('').astype(str).str.strip()
ROSTER = [(PB.get(str(p).strip().lower(), p), n) for n, p in _t[_t.cb != ''].groupby('cb').trctnm.agg(lambda s: s.mode().iloc[0]).items()]
VAN = next(v for k, v in TEN.items() if v not in {n for _, n in ROSTER})  # cán bộ đã bàn giao hết (có kế hoạch trong bản in)
KEYS = {norm(n) for _, n in ROSTER} | {norm(VAN)}
def jr(x): return int(math.floor(x + 0.5))
def num(t):
    t = (t or '').strip().replace('▲', '').replace('▼', '').strip()
    if t in ('', '-', '—', '–'): return 0
    t2 = t.replace('%', ''); v = re.sub(r'[^\d]', '', t2); return (-1 if t2.startswith('-') or t2.startswith('−') else 1) * int(v) if v else 0
# ---- kế hoạch: 2.000 tr dư nợ, 2.000 tr trung+dài, 2 KH cho 17 cán bộ + Vân (đúng cách bản in 31/10: tổng 36.000 / 36) ----
PLAN0 = {k: {'dn': 2000e6, 'th': 2000e6, 'kh': 2.0} for k in KEYS}
def chuyen(plan):
    R = {k: dict(v) for k, v in plan.items()}; nhom = {}
    for b in SO: nhom.setdefault(b['ngay'] if 'ngay' in b else '2026-10-31', []).append(b)
    X = cb_kh(Qq); cur = cb_kh(B)
    for ng in sorted(nhom):
        goc = {k: dict(v) for k, v in R.items()}
        for b in nhom[ng]:
            mine = [k for k, c in X.items() if c == b['tu']]; tot = len(mine); dest = {}
            for k in mine:
                d = cur.get(k, b['den']) if b['kieu'] == 'chia' else b['den']; dest[d] = dest.get(d, 0) + 1
            if norm(b['tu']) not in goc: continue   # cán bộ không có kế hoạch ⇒ không có gì để chuyển
            g = goc[norm(b['tu'])]
            for d, c in dest.items():
                sh = c / tot; r = R.setdefault(norm(d), {'dn': 0, 'th': 0, 'kh': 0})
                for f in ('dn', 'th', 'kh'): r[f] += g[f] * sh; R[norm(b['tu'])][f] -= g[f] * sh
    return R
async def mo(pg):
    await pg.goto(URL + '#/chi-tieu-ke-hoach', wait_until='domcontentloaded'); await pg.wait_for_timeout(3500)
    await pg.click('[data-testid=ct-tab-ngay]'); await pg.wait_for_selector('[data-testid=kh-host] [data-testid=kh-so]', timeout=20000); await pg.wait_for_timeout(1000)
async def tab(pg, t):
    await pg.click(f'[data-testid=bcn-sub-{t}]'); await pg.wait_for_timeout(400)
    return await pg.evaluate("[...document.querySelectorAll('[data-testid=bcn-table] tbody tr')].map(r=>[r.dataset.kind,r.dataset.bg||'',...[...r.children].map(c=>c.textContent.trim())])")
async def run(pw, name, vw, vh, day_du):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN', is_mobile=vw < 600, has_touch=vw < 600, accept_downloads=True)
    await ctx.add_init_script("try{if(!sessionStorage.getItem('__k')){sessionStorage.setItem('__k','1');localStorage.setItem('gd9_tplok','0');localStorage.setItem('td_roster_v1'," + json.dumps('\n'.join(f'{p} | {n} | CBTD' for p, n in ROSTER)) + ")}}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    T = lambda s: f'{name}: {s}'
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in FS]); await pg.wait_for_timeout(12000)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(1000)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(25000)
    await mo(pg)
    await pg.evaluate("document.querySelector('[data-testid=bg-so]').open=true")
    await pg.click('[data-testid=bg-xn-all]'); await pg.wait_for_timeout(1500)   # xác nhận 9 bàn giao
    await pg.evaluate("document.querySelector('[data-testid=kh-so]').open=true")
    s0 = (await pg.inner_text('[data-testid=kh-so] summary')).strip()
    ok(T(f'K1 chưa nhập kế hoạch quý: "{s0[:70]}"'), 'chưa nhập' in s0, s0)
    # dán 18 dòng: Tên ⇥ dư nợ ⇥ trung+dài ⇥ KH
    txt = '\n'.join(f"{TEN[k]}\t2.000\t2.000\t2" for k in sorted(KEYS))
    await pg.fill('[data-testid=kh-dan]', txt); await pg.click('[data-testid=kh-dan-ok]'); await pg.wait_for_timeout(1500)
    await pg.evaluate("document.querySelector('[data-testid=kh-so]').open=true")
    n = (await pg.inner_text('[data-testid=kh-n]')).strip(); tdn = num(await pg.inner_text('[data-testid=kh-t-dn]')); tkh = num(await pg.inner_text('[data-testid=kh-t-kh]'))
    ok(T(f'K2 dán kế hoạch quý IV: {n} cán bộ; tổng dư nợ {tdn} tr (Python 36.000), KH {tkh} (36)'), n == str(len(KEYS)) and tdn == 36000 and tkh == 36, (n, tdn, tkh))
    # chuyển TẮT = đúng như bản in (Vân vẫn giữ 2.000 / 2)
    await pg.select_option('[data-testid=kh-chuyen]', '0'); await pg.wait_for_timeout(1500)
    rk = await tab(pg, 'kh'); rd = await tab(pg, 'dn')
    plk = {norm(r[2]): num(r[11]) for r in rk if r[0] == 'cbtd'}; pld = {norm(r[2]): num(r[11]) for r in rd if r[0] == 'cbtd'}
    tkp = [num(r[11]) for r in rk if r[0] == 'tong'][0]; tdp = [num(r[11]) for r in rd if r[0] == 'tong'][0]
    ok(T(f'K3 chuyển kế hoạch TẮT: cột Kế hoạch mỗi cán bộ = 2 KH / 2.000 tr (cả cán bộ đã bàn giao); TỔNG {tkp} KH / {tdp} đ'),
       all(plk.get(k) == 2 for k in KEYS) and all(abs(pld.get(k, 0) - 2000e6) <= 1 for k in KEYS) and tkp == 36 and abs(tdp - 36000e6) <= 1, (plk, tkp, tdp))
    E = {k: bang(ap_dung(Qq, SO, B)).get(k, {'kh': 0, 'dn': 0}) for k in KEYS}; Eb = {k: bang(B).get(k, {'kh': 0, 'dn': 0}) for k in KEYS}
    q_kh = {norm(r[2]): num(r[10]) for r in rk if r[0] == 'cbtd'}   # +/- KH quý (cột 8 của ô: r[3+7]=r[10])
    bad = [(k[:10], q_kh.get(k), Eb[k]['kh'] - E[k]['kh'] - 2) for k in KEYS if q_kh.get(k) != Eb[k]['kh'] - E[k]['kh'] - 2]
    ok(T('K4 "+/- KH quý" = (Ngày BC − Đầu quý đã tính lại) − 2 cho từng cán bộ'), not bad, bad[:3])
    # chuyển BẬT: chia theo sổ bàn giao, bảo toàn tổng
    await pg.select_option('[data-testid=kh-chuyen]', '1'); await pg.wait_for_timeout(1500)
    await pg.evaluate("document.querySelector('[data-testid=kh-so]').open=true")
    R = chuyen(PLAN0)
    app = await pg.evaluate("Object.fromEntries([...document.querySelectorAll('[data-testid=kh-row]')].map(r=>[r.dataset.ten,[r.querySelector('[data-testid=kh-adn]').textContent,r.querySelector('[data-testid=kh-akh]').textContent]]))")
    sai = []
    for k, e in R.items():
        if k not in KEYS: continue
        a = next((v for t_, v in app.items() if norm(t_) == k), None)
        if a is None:
            if abs(e['dn']) > 1e6: sai.append((k[:8], None, e['dn'] / 1e6)); continue
            continue
        if abs(num(a[0]) - jr(e['dn'] / 1e6)) > 1 or abs(float(a[1].replace('.', '').replace(',', '.') or 0) - round(e['kh'], 2)) > 0.011: sai.append((k[:8], a, round(e['dn'] / 1e6), round(e['kh'], 2)))
    tad = num(await pg.inner_text('[data-testid=kh-t-adn]'))
    ok(T(f'K5 chuyển kế hoạch theo sổ bàn giao: từng cán bộ (dư nợ tr, KH) = Python; TỔNG áp dụng {tad} tr = 36.000 (bảo toàn)'), not sai and abs(tad - 36000) <= 1, (sai[:3], tad))
    rk = await tab(pg, 'kh'); rd = await tab(pg, 'dn')
    plk = {norm(r[2]): num(r[11]) for r in rk if r[0] == 'cbtd'}; pld = {norm(r[2]): num(r[11]) for r in rd if r[0] == 'cbtd'}
    bad = [(k[:10], plk.get(k, 0), jr(R[k]['kh'])) for k in R if k in KEYS and plk.get(k, 0) != jr(R[k]['kh'])] + [(k[:10], pld.get(k, 0), jr(R[k]['dn'])) for k in R if k in KEYS and abs(pld.get(k, 0) - jr(R[k]['dn'])) > 1]
    ok(T('K6 cột Kế hoạch trong Báo cáo ngày (KH và dư nợ) = kế hoạch đã chuyển theo sổ (Python)'), not bad, bad[:3])
    # % thực hiện + dự báo (quý IV, 31/10: đã 31/92 ngày)
    th = await pg.evaluate("Object.fromEntries([...document.querySelectorAll('[data-testid=kh-th-row]')].map(r=>[r.dataset.ten,[...r.children].map(c=>c.textContent.trim())]))")
    bad = []; days, done = 92, 31
    for k in KEYS:
        row = next((v for t_, v in th.items() if norm(t_) == k), None)
        eq, ek = E[k], R[k]; thk = Eb[k]['kh'] - eq['kh']; thd = Eb[k]['dn'] - eq['dn']; pk, pdn = jr(ek['kh']), jr(ek['dn'])
        if row is None:
            if pk or pdn or thk or abs(thd) > 1e6: bad.append((k[:8], 'thiếu dòng'))
            continue
        e_pctk = None if pk <= 0 else round(thk / pk * 1000) / 10; e_pctd = None if pdn <= 0 else math.floor(thd / pdn * 1000 + .5) / 10
        fk = jr(eq['kh'] + thk * days / done); fd = jr((eq['dn'] + thd * days / done) / 1e6)
        got = (num(row[1]), num(row[2]), num(row[4]), num(row[5]), num(row[6]), num(row[8]), num(row[9]))
        exp = (pk, thk, fk, jr(pdn / 1e6), jr(thd / 1e6), fd, jr(max(0, pdn - thd) / 1e6))
        if any(abs(a - b) > (1 if i >= 3 else 0) for i, (a, b) in enumerate(zip(got, exp))): bad.append((k[:8], got, exp))
    ok(T(f'K7 Thực hiện kế hoạch quý + dự báo cuối quý (đã {done}/{days} ngày): KH và dư nợ từng cán bộ = Python ({len(th)} dòng)'), not bad, bad[:3])
    await pg.screenshot(path=str(SHOT / f'{name}_d_1_ke_hoach.png'), full_page=True)
    if not day_du:
        sw = await pg.evaluate("[document.scrollingElement.scrollWidth, innerWidth]")
        ok(T(f'M1 điện thoại: không cuộn ngang ({sw})'), sw[0] <= sw[1] + 1, sw)
        ok(T('E1 0 pageerror'), not errs, errs[:3]); await br.close(); return
    # xuất 4 bảng
    await pg.evaluate("document.querySelector('[data-testid=ds-so]').open=true")
    async with pg.expect_download() as dl:
        await pg.click('[data-testid=kh-xuat4]')
    p = Path(tempfile.mkdtemp()) / 'b4.xlsx'; await (await dl.value).save_as(p)
    wb = openpyxl.load_workbook(p); names = wb.sheetnames
    ok(T(f'X1 Excel 4 bảng: sheet {names}'), len(names) == 4 and names[0].startswith('Khách') and names[3].startswith('Dư nợ trung'), names)
    detail = []; allok = True
    for si, (t, loc) in enumerate([('kh', None), ('dn', None), ('dn', 'dn'), ('dn', 'th')]):
        sh = wb.worksheets[si]; rows = {norm(str(r[0].value)): [c.value for c in r] for r in sh.iter_rows() if r[0].value}
        dv = 1 if t == 'kh' else 1e6
        a0, a1, a2 = bang(ap_dung(N, SO, B), loc), bang(ap_dung(Qq, SO, B), loc), bang(B, loc); sai = []
        for k in set(a0) | set(a1) | set(a2):
            e = [a0.get(k, {}).get(t, 0), a1.get(k, {}).get(t, 0), a1.get(k, {}).get(t, 0), a2.get(k, {}).get(t, 0)]
            if not any(e): continue
            r = rows.get(k)
            if r is None: sai.append((k[:8], 'thiếu dòng')); continue
            got = [r[1], r[2], r[3], r[4]]; exp = [jr(x / dv) if t == 'dn' else x for x in e]
            if any(abs((g or 0) - x) > (1 if t == 'dn' else 0) for g, x in zip(got, exp)): sai.append((k[:8], got, exp))
        tong = rows.get('tong'); et = [sum(a.get(k, {}).get(t, 0) for k in a) for a in (a0, a1, a1, a2)]
        if not tong or any(abs((g or 0) - (jr(x / dv) if t == 'dn' else x)) > 1 for g, x in zip(tong[1:5], et)): sai.append(('TỔNG', tong and tong[1:5], et))
        detail.append((sh.title, len(sai))); allok = allok and not sai
        ok(T(f'X2 sheet "{sh.title}": từng cán bộ + TỔNG (4 mốc, {"KH" if t == "kh" else "triệu đồng"}) = Python'), not sai, sai[:3])
    # đối soát với báo cáo tay 31/10/2026
    for kind, t, loc in (('kh', 'kh', None), ('dn', 'dn', None), ('dnn', 'dn', 'dn'), ('th', 'dn', 'th')):
        a0, a1, a2 = bang(ap_dung(N, SO, B), loc), bang(ap_dung(Qq, SO, B), loc), bang(B, loc); tol = 0 if t == 'kh' else 1
        tot = okc = 0; sai = []
        for nm, v in BANIN[kind].items():
            k = norm(nm)
            if k == 'tong': app = [sum(x.get(t, 0) for x in a.values()) for a in (a0, a1, a1, a2)]
            else: app = [a.get(k, {}).get(t, 0) for a in (a0, a1, a1, a2)]
            for i in range(4):
                vi = 0 if v[i] is None else v[i]   # "-" trên bản in = 0 (app đọc '-' là 0)
                tot += 1; x = app[i] if t == 'kh' else jr(app[i] / 1e6)
                if abs(x - vi) <= tol: okc += 1
        await pg.select_option('[data-testid=ds-bang]', kind)
        lines = '\n'.join(f"{nm}\t" + '\t'.join('-' if x is None else str(x) for x in v) for nm, v in BANIN[kind].items())
        await pg.fill('[data-testid=ds-dan]', lines); await pg.click('[data-testid=ds-ok]'); await pg.wait_for_timeout(2500)
        tx = (await pg.inner_text('[data-testid=ds-tong]')).strip(); m = re.search(r'Khớp (\d+)/(\d+)', tx)
        ok(T(f'D1 đối soát báo cáo tay "{kind}": app báo {tx[:40]}; Python {okc}/{tot}'), m and (int(m[1]), int(m[2])) == (okc, tot), (tx, okc, tot))
        if kind == 'kh':
            cau = await pg.evaluate("[...document.querySelectorAll('[data-testid=ds-row]')].map(r=>r.children[5].textContent)")
            ok(T(f'D2 đối soát KH: nguyên nhân gợi ý có "bàn giao" cho các ô lệch do bàn giao ({sum(1 for c in cau if "bàn giao" in c)}/{len(cau)})'), cau and sum(1 for c in cau if 'bàn giao' in c) >= 5, cau[:3])
            await pg.screenshot(path=str(SHOT / f'{name}_d_2_doi_soat.png'), full_page=True)
    ok(T('E1 0 pageerror'), not errs, errs[:3]); await br.close()
async def main():
    async with async_playwright() as pw:
        await run(pw, 'desktop', 1366, 900, True)
        await run(pw, 'mobile', 390, 844, False)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
