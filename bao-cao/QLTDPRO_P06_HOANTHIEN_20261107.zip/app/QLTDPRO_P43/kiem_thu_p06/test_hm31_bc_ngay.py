# -*- coding: utf-8 -*-
# HM-31 GĐ1 · V3 — Báo cáo ngày: mốc theo NGÀY DỮ LIỆU, cán bộ đã bàn giao vẫn trong TỔNG, bỏ khớp tên gần đúng, +/- KH quý = (BC − Đầu quý) − KH.
# DỮ LIỆU THẬT: đường dẫn thư mục msit80 qua biến QLTD_MSIT80_DIR (31.12.2025.xlsx, 30.09.2026.XLS, 31.10.2026.XLS) — KHÔNG để trong repo/ZIP.
# Thiếu biến/tệp ⇒ SKIP (thoát 0). Đáp án: pandas đọc thẳng tệp gốc (độc lập với app).
# Chạy từ app/QLTDPRO_P43/:  QLTD_MSIT80_DIR=/duong/dan python3 kiem_thu_p06/test_hm31_bc_ngay.py [app/QLTDPRO_v24.17.35.html]
import asyncio, functools, http.server, threading, sys, os, re, unicodedata
from pathlib import Path
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.35.html'
D = Path(os.environ.get('QLTD_MSIT80_DIR', '/khong-co'))
FS = [D / '31.12.2025.xlsx', D / '30.09.2026.XLS', D / '31.10.2026.XLS']
if not all(f.exists() for f in FS):
    print('SKIP: không có dữ liệu msit80 thật (đặt QLTD_MSIT80_DIR)'); print('\nKẾT QUẢ: 0 PASS · 0 FAIL (SKIP)'); raise SystemExit(0)
import pandas as pd
from playwright.async_api import async_playwright
PORT = 8871; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm31'
if not EV.parent.exists(): EV = HERE / 'hm31'
SHOT = EV / 'anh' / Path(APP).stem; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:700]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
def norm(s):
    s = unicodedata.normalize('NFD', str(s or '')).replace('đ', 'd').replace('Đ', 'd')
    return re.sub(r'\s+', ' ', ''.join(c for c in s if unicodedata.category(c) != 'Mn').lower().replace('.', ' ')).strip()
def dap_an(f):
    d = pd.read_excel(f, header=0, usecols=['brcd', 'dsbsbal', 'ofcnm', 'trctnm'])
    d['cb'] = d.ofcnm.fillna('').astype(str).str.strip(); d['k'] = d.brcd.astype(str).str.strip(); d['bal'] = pd.to_numeric(d.dsbsbal, errors='coerce').fillna(0)
    d = d[d.cb != '']; o = {}
    for cb, g in d.groupby(d.cb.map(norm)):
        s = g.groupby('k').bal.sum(); o[cb] = dict(ten=g.cb.iloc[0], phong=g.trctnm.mode().iloc[0], kh=int((s > 0).sum()), dn=int(round(g.bal.sum())))
    return o
EN, EQ, EB = [dap_an(f) for f in FS]
TK = lambda o: sum(v['kh'] for v in o.values()); TD = lambda o: sum(v['dn'] for v in o.values())
print(f'Đáp án: KH ĐN {TK(EN)} · ĐQ {TK(EQ)} · BC {TK(EB)}; DN ĐN {TD(EN)} · ĐQ {TD(EQ)} · BC {TD(EB)}')
# danh mục cấu hình như người dùng: chỉ cán bộ ĐANG quản lý ngày 31/10 (cán bộ đã bàn giao hết không còn trong danh mục)
PB = {'hội sở': 'Hội Sở', 'pgd hai bà trưng': 'PGD Hai Bà Trưng', 'pgd số 2': 'PGD Số 2'}
ROSTER = [(PB.get(str(v['phong']).strip().lower(), v['phong']), v['ten']) for v in EB.values()]
BG = sorted(v['ten'] for k, v in list(EN.items()) + list(EQ.items()) if k not in EB)
BG = sorted(set(BG))
def num(t):
    t = (t or '').strip()
    if t in ('', '-'): return 0
    v = re.sub(r'[^\d]', '', t); return (-1 if t.startswith('-') else 1) * int(v)
async def bang(pg, tab):
    await pg.click(f'[data-testid=bcn-sub-{tab}]'); await pg.wait_for_timeout(500)
    return await pg.evaluate("[...document.querySelectorAll('[data-testid=bcn-table] tbody tr')].map(r=>[r.dataset.kind,r.dataset.bg||'',...[...r.children].map(c=>c.textContent.trim())])")
async def run(pw, name, vw, vh, roster):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN', is_mobile=vw < 600, has_touch=vw < 600)
    init = "try{localStorage.setItem('gd9_tplok','0')" + (";localStorage.setItem('td_roster_v1'," + repr('\n'.join(f'{p} | {n} | CBTD' for p, n in roster)) + ")" if roster else '') + "}catch(e){}"
    await ctx.add_init_script(init)
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    T = lambda s: f'{name}: {s}'
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in FS]); await pg.wait_for_timeout(12000)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(1000)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(25000)
    await pg.goto(URL + '#/chi-tieu-ke-hoach', wait_until='domcontentloaded'); await pg.wait_for_timeout(4000)
    await pg.click('[data-testid=ct-tab-ngay]'); await pg.wait_for_selector('[data-testid=bcn-table]', timeout=20000); await pg.wait_for_timeout(1500)
    hd = (await pg.inner_text('[data-testid=bcn-header]')).strip()
    ok(T(f'B1 tiêu đề theo ngày dữ liệu ({hd})'), hd.endswith('31/10/2026'), hd)
    kh = await bang(pg, 'kh'); tong = [r for r in kh if r[0] == 'tong'][0]; c = [num(x) for x in tong[3:]]
    ok(T(f'B2 TỔNG KH Đầu năm/Đầu quý/Đầu tháng/Ngày BC = {c[:4]} (đáp án {TK(EN)}/{TK(EQ)}/{TK(EQ)}/{TK(EB)}; bản in 1.847/1.890/1.890/1.871)'),
       c[:4] == [TK(EN), TK(EQ), TK(EQ), TK(EB)], c)
    ok(T(f'B3 +/- đầu tháng/quý/năm TỔNG = {c[4:7]}'), c[4:7] == [TK(EB) - TK(EQ), TK(EB) - TK(EQ), TK(EB) - TK(EN)], c)
    ok(T(f'B4 +/- KH quý = (Ngày BC − Đầu quý) − KH quý ({c[7]} = {c[3]} − {c[1]} − {c[8]})'), c[7] == c[3] - c[1] - c[8], c)
    cb = {norm(r[2]): [num(x) for x in r[3:]] for r in kh if r[0] == 'cbtd'}
    sai = [(k, cb.get(k, [None] * 4)[:4], [EN.get(k, {}).get('kh', 0), EQ.get(k, {}).get('kh', 0), EQ.get(k, {}).get('kh', 0), EB.get(k, {}).get('kh', 0)]) for k in set(EN) | set(EQ) | set(EB)
           if cb.get(k, [None] * 4)[:4] != [EN.get(k, {}).get('kh', 0), EQ.get(k, {}).get('kh', 0), EQ.get(k, {}).get('kh', 0), EB.get(k, {}).get('kh', 0)]]
    ok(T(f'B5 từng cán bộ ({len(cb)} dòng): KH 4 mốc = Python, kể cả cán bộ đã bàn giao'), not sai, sai)
    ph = [r for r in kh if r[0] == 'phong']; sp = [sum(num(r[3 + i]) for r in ph) for i in range(4)]
    ok(T(f'B6 Σ nhóm = TỔNG ({sp})'), sp == c[:4], (sp, c))
    dn = await bang(pg, 'dn'); td = [num(x) for x in [r for r in dn if r[0] == 'tong'][0][3:7]]
    ok(T(f'B7 TỔNG DƯ NỢ 4 mốc = Python ({td}); bản in triệu đồng 1.992.329/2.180.111/2.180.111/2.158.433'),
       all(abs(a - b) <= 2 for a, b in zip(td, [TD(EN), TD(EQ), TD(EQ), TD(EB)])), (td, [TD(EN), TD(EQ), TD(EB)]))
    w = await pg.locator('[data-testid=bcn-warn]').all_inner_texts()
    nhom = [r[2] for r in kh if r[0] == 'cbtd' and r[1] == '1']
    if roster:
        ok(T(f'B8 danh mục KHÔNG có cán bộ đã bàn giao → nhóm "ĐÃ BÀN GIAO / NGOÀI DANH MỤC" ({nhom}) + cảnh báo'),
           sorted(nhom) == BG and any('ĐÃ BÀN GIAO' in r[2] for r in kh if r[0] == 'phong') and w and all(n in w[0] for n in BG), (nhom, BG, w))
        i_bg = [i for i, r in enumerate(kh) if r[0] == 'phong' and r[1] == '1']; i_t = [i for i, r in enumerate(kh) if r[0] == 'tong']
        ok(T('B9 nhóm bàn giao nằm ngay trước TỔNG'), i_bg and i_t and i_bg[0] == i_t[0] - 1, (i_bg, i_t))
    else:
        ok(T(f'B8 danh mục tự học từ dữ liệu: cán bộ đã bàn giao nằm trong phòng cũ, không có nhóm riêng ({nhom})'), not nhom)
    await pg.screenshot(path=str(SHOT / f'{name}_bc_ngay.png'), full_page=True)
    # Trả nợ: mốc theo ngày dữ liệu
    await pg.goto(URL + '#/tra-no-xuat-ts', wait_until='domcontentloaded'); await pg.wait_for_timeout(5000)
    mc = await pg.evaluate("window.__qltdTraNoMoc||null")
    ok(T(f'T1 Trả nợ: mốc D-1/CT trước/CQ trước = 30/09/2026, 31/12 N-1 = 31/12/2025 theo ngày dữ liệu 31/10 ({mc})'),
       mc and mc.get('D1') == '2026-09-30' and mc.get('EoM1') == '2026-09-30' and mc.get('EoQ1') == '2026-09-30' and mc.get('EoY1') == '2025-12-31', mc)
    ok(T('E1 0 pageerror'), not errs, errs[:3])
    await br.close()
async def main():
    async with async_playwright() as pw:
        await run(pw, 'desktop_dm_cauhinh', 1366, 900, ROSTER)
        await run(pw, 'desktop_dm_tuhoc', 1366, 900, None)
        await run(pw, 'mobile_dm_cauhinh', 390, 844, ROSTER)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
