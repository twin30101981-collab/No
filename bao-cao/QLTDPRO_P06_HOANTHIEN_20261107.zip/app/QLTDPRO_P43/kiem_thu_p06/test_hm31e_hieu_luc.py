# -*- coding: utf-8 -*-
# HM-31 · V3 — v24.17.40: "Ngày hiệu lực thực tế" của sổ bàn giao (người dùng 07/11/2026: hiệu lực từ 01/10/2026).
# DỮ LIỆU THẬT qua QLTD_MSIT80_DIR (31.12.2025.xlsx, 30.09.2026.XLS, 31.10.2026.XLS) — KHÔNG để trong repo/ZIP; thiếu ⇒ SKIP. Đáp án: pandas (dap_an_ban_giao.py).
# Chạy từ app/QLTDPRO_P43/:  QLTD_MSIT80_DIR=/duong/dan python3 kiem_thu_p06/test_hm31e_hieu_luc.py [app/QLTDPRO_v24.17.40.html]
import asyncio, functools, http.server, threading, sys, os, re, json, tempfile, warnings, math
from pathlib import Path
warnings.filterwarnings('ignore')
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.40.html'
D = Path(os.environ.get('QLTD_MSIT80_DIR', '/khong-co'))
FS = [D / '31.12.2025.xlsx', D / '30.09.2026.XLS', D / '31.10.2026.XLS']
if not all(f.exists() for f in FS):
    print('SKIP: không có dữ liệu msit80 thật (đặt QLTD_MSIT80_DIR)'); print('\nKẾT QUẢ: 0 PASS · 0 FAIL (SKIP)'); raise SystemExit(0)
sys.path.insert(0, str(HERE))
import pandas as pd, openpyxl
from dap_an_ban_giao import doc, goi_y, ap_dung, bang, norm, cb_kh
from playwright.async_api import async_playwright
PORT = 8875; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:700]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
N, Qq, B = [doc(f) for f in FS]
GY = goi_y(N, Qq) + goi_y(Qq, B); SO = [dict(b) for b in GY]
PB = {'hội sở': 'Hội Sở', 'pgd hai bà trưng': 'PGD Hai Bà Trưng', 'pgd số 2': 'PGD Số 2'}
_t = pd.read_excel(FS[2], header=0, usecols=['ofcnm', 'trctnm']); _t['cb'] = _t.ofcnm.fillna('').astype(str).str.strip()
ROSTER = [(PB.get(str(p).strip().lower(), p), n) for n, p in _t[_t.cb != ''].groupby('cb').trctnm.agg(lambda s: s.mode().iloc[0]).items()]
TEN = {}
for d_ in (N, Qq, B):
    for n in d_[d_.cb != ''].cb.unique(): TEN[norm(n)] = n
VAN = next(v for k, v in TEN.items() if v not in {n for _, n in ROSTER}); KEYS = {norm(n) for _, n in ROSTER} | {norm(VAN)}
def jr(x): return int(math.floor(x + 0.5))
def num(t):
    t = (t or '').strip(); 
    if t in ('', '-', '—'): return 0
    v = re.sub(r'[^\d]', '', t); return (-1 if t.startswith('-') else 1) * int(v) if v else 0
async def tab(pg, t):
    await pg.click(f'[data-testid=bcn-sub-{t}]'); await pg.wait_for_timeout(400)
    return await pg.evaluate("[...document.querySelectorAll('[data-testid=bcn-table] tbody tr')].map(r=>[r.dataset.kind,r.dataset.bg||'',...[...r.children].map(c=>c.textContent.trim())])")
def dap(so_n, so_q):
    a, b, c = bang(ap_dung(N, so_n, B)), bang(ap_dung(Qq, so_q, B)), bang(B)
    return {k: [a.get(k, {}).get('kh', 0), a.get(k, {}).get('dn', 0), b.get(k, {}).get('kh', 0), b.get(k, {}).get('dn', 0), c.get(k, {}).get('kh', 0), c.get(k, {}).get('dn', 0)] for k in set(a) | set(b) | set(c)}
async def so_sanh(pg, T, so_n, so_q, nhan):
    E = dap(so_n, so_q); rk, rd = await tab(pg, 'kh'), await tab(pg, 'dn')
    ck = {norm(r[2]): [num(x) for x in r[3:7]] for r in rk if r[0] == 'cbtd'}; cd = {norm(r[2]): [num(x) for x in r[3:7]] for r in rd if r[0] == 'cbtd'}
    tk = [num(x) for x in [r for r in rk if r[0] == 'tong'][0][3:7]]; td = [num(x) for x in [r for r in rd if r[0] == 'tong'][0][3:7]]
    ek = [sum(v[i] for v in E.values()) for i in (0, 2, 2, 4)]; ed = [sum(v[i] for v in E.values()) for i in (1, 3, 3, 5)]
    sai = [(k[:8], ck.get(k), [v[0], v[2], v[2], v[4]]) for k, v in E.items() if any(v) and (ck.get(k, [None] * 4) != [v[0], v[2], v[2], v[4]] or any(abs(x - y) > 2 for x, y in zip(cd.get(k, [9e18] * 4), [v[1], v[3], v[3], v[5]])))]
    ok(T(f'{nhan}: TỔNG {tk} KH; dư nợ 4 mốc (±2 đ) và từng cán bộ = Python'), tk == ek and all(abs(a - b) <= 2 for a, b in zip(td, ed)) and not sai, (tk, ek, sai[:3]))
async def mo(pg):
    await pg.goto(URL + '#/chi-tieu-ke-hoach', wait_until='domcontentloaded'); await pg.wait_for_timeout(3500)
    await pg.click('[data-testid=ct-tab-ngay]'); await pg.wait_for_selector('[data-testid=bg-host] [data-testid=bg-bar]', timeout=20000); await pg.wait_for_timeout(1000)
    await pg.evaluate("document.querySelector('[data-testid=bg-so]').open=true")
async def main():
    async with async_playwright() as pw:
        br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': 1366, 'height': 900}, locale='vi-VN', accept_downloads=True)
        await ctx.add_init_script("try{if(!sessionStorage.getItem('__k')){sessionStorage.setItem('__k','1');localStorage.setItem('gd9_tplok','0');localStorage.setItem('td_roster_v1'," + json.dumps('\n'.join(f'{p} | {n} | CBTD' for p, n in ROSTER)) + ")}}catch(e){}")
        pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200])); T = lambda s: s
        await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
        await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in FS]); await pg.wait_for_timeout(12000)
        await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(1000)
        y = pg.locator('[data-testid="confirm-yes"]')
        if await y.count(): await y.click()
        await pg.wait_for_timeout(25000); await mo(pg)
        ok(T('H1 gợi ý mặc định: hiệu lực = ngày mốc 31/10/2026'), await pg.evaluate("[...document.querySelectorAll('[data-testid=bg-goiy-row]')].every(r=>r.children[0].textContent==='31/10/2026')"))
        await pg.fill('[data-testid=bg-hl]', '2026-10-01'); await pg.click('[data-testid=bg-xn-all]'); await pg.wait_for_timeout(1500); await pg.evaluate("document.querySelector('[data-testid=bg-so]').open=true")
        ds = await pg.evaluate("[...document.querySelectorAll('[data-testid=bg-da-ngay]')].map(i=>i.value)"); ng = await pg.locator('[data-testid=bg-goiy-row]').count()
        ok(T(f'H2 xác nhận với ngày hiệu lực 01/10/2026: {len(ds)} dòng sổ, ngày {set(ds)}; không gợi ý lại ({ng})'), len(ds) == len(GY) and set(ds) == {'2026-10-01'} and ng == 0, (ds[:2], ng))
        await so_sanh(pg, T, SO, SO, 'H3 số liệu 3 mốc với hiệu lực 01/10 (= Python)')
        # kế hoạch quý IV chuyển theo bàn giao hiệu lực 01/10 (cả quý)
        await pg.evaluate("document.querySelector('[data-testid=kh-so]').open=true")
        await pg.fill('[data-testid=kh-dan]', '\n'.join(f"{TEN[k]}\t2.000\t2.000\t2" for k in sorted(KEYS))); await pg.click('[data-testid=kh-dan-ok]'); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('[data-testid=kh-so]').open=true"); tad = num(await pg.inner_text('[data-testid=kh-t-adn]'))
        app = await pg.evaluate("Object.fromEntries([...document.querySelectorAll('[data-testid=kh-row]')].map(r=>[r.dataset.ten,r.querySelector('[data-testid=kh-adn]').textContent]))")
        X = cb_kh(Qq); cur = cb_kh(B); R = {k: 2000.0 for k in KEYS}; goc = dict(R)
        for b in SO:
            mine = [k for k, c in X.items() if c == b['tu']]
            if not mine or norm(b['tu']) not in goc: continue
            dest = {}
            for k in mine: d = cur.get(k, b['den']) if b['kieu'] == 'chia' else b['den']; dest[d] = dest.get(d, 0) + 1
            for d, c in dest.items(): R[norm(d)] = R.get(norm(d), 0) + goc[norm(b['tu'])] * c / len(mine); R[norm(b['tu'])] -= goc[norm(b['tu'])] * c / len(mine)
        sai = [(k[:8], a, jr(R[k])) for k in KEYS for a in [next((v for t_, v in app.items() if norm(t_) == k), '0')] if abs(num(a) - jr(R[k])) > 1]
        ok(T(f'H4 kế hoạch quý IV chuyển theo bàn giao hiệu lực 01/10: từng cán bộ = Python; TỔNG {tad} tr = 36.000'), not sai and abs(tad - 36000) <= 1, (sai[:3], tad))
        # sửa ngày hiệu lực của 1 dòng thành 30/09/2026 ⇒ không tính lại mốc 30/09 (Đầu quý/tháng), vẫn tính lại 31/12 (Đầu năm)
        await pg.evaluate("document.querySelector('[data-testid=bg-so]').open=true")
        t0 = VAN; await pg.evaluate("t=>{const r=[...document.querySelectorAll('[data-testid=bg-da-row]')].find(r=>r.children[1].textContent.startsWith(t));const i=r.querySelector('[data-testid=bg-da-ngay]');i.value='2026-10-15';i.dispatchEvent(new Event('change',{bubbles:true}))}", t0)
        await pg.wait_for_timeout(1500)
        so_q = SO   # hiệu lực 15/10 vẫn sau mốc 30/09 ⇒ kết quả không đổi (bàn giao khác ngày áp nối tiếp theo ngày; dòng được chọn không nằm trong chuỗi)
        await so_sanh(pg, T, SO, so_q, 'H5 sửa 1 dòng sổ thành hiệu lực 15/10/2026 (sau mốc 30/09): số liệu không đổi')
        # Excel biên bản có ngày hiệu lực thực tế; F5 giữ
        await pg.evaluate("document.querySelector('[data-testid=bg-so]').open=true")
        async with pg.expect_download() as dl: await pg.click('[data-testid=bg-xlsx]')
        p = Path(tempfile.mkdtemp()) / 'so.xlsx'; await (await dl.value).save_as(p); ws = openpyxl.load_workbook(p).active; ngay = sorted({str(r[0].value) for r in ws.iter_rows(min_row=2) if r[0].value})
        ok(T(f'H6 Excel biên bản ghi ngày hiệu lực thực tế {ngay}'), ngay == ['01/10/2026', '15/10/2026'], ngay)
        await pg.reload(wait_until='domcontentloaded'); await mo(pg)
        ds = await pg.evaluate("[...document.querySelectorAll('[data-testid=bg-da-ngay]')].map(i=>i.value)")
        ok(T(f'H7 F5: ngày hiệu lực giữ nguyên ({sorted(set(ds))}), không gợi ý lại ({await pg.locator("[data-testid=bg-goiy-row]").count()})'), sorted(set(ds)) == ['2026-10-01', '2026-10-15'] and await pg.locator('[data-testid=bg-goiy-row]').count() == 0, ds)
        await so_sanh(pg, T, SO, so_q, 'H8 sau F5')
        ok(T('E1 0 pageerror'), not errs, errs[:3]); await br.close()
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
