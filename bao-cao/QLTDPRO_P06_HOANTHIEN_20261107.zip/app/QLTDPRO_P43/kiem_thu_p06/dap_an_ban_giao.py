# Đáp án độc lập HM-31 GĐ2 (pandas đọc thẳng msit80): gợi ý bàn giao + tính lại mốc theo sổ bàn giao.
# Quy tắc (người dùng chốt 07/11/2026): nguyên danh mục A→B: mọi số mốc của A thuộc B; chia danh mục: theo từng KH
# (KH còn ở ngày hiệu lực → cán bộ đang quản lý KH đó; KH đã tất toán → người nhận chính) cho MỌI mốc.
import pandas as pd, re, unicodedata
def norm(s):
    s = unicodedata.normalize('NFD', str(s or '')).replace('đ', 'd').replace('Đ', 'd')
    return re.sub(r'\s+', ' ', ''.join(c for c in s if unicodedata.category(c) != 'Mn').lower().replace('.', ' ')).strip()
def doc(f):
    d = pd.read_excel(f, header=0, usecols=['brcd', 'dsbsbal', 'ofcnm', 'ofcno', 'dsbsseq', 'lntpcd', 'custtpnm'])
    d['k'] = d.brcd.astype(str).str.strip(); d['cb'] = d.ofcnm.fillna('').astype(str).str.strip()
    d['bal'] = pd.to_numeric(d.dsbsbal, errors='coerce').fillna(0)
    d['ks'] = d.dsbsseq.fillna('').astype(str).str.strip(); d['ma'] = d.ofcno.fillna('').astype(str).str.strip()
    d['th212'] = d.lntpcd.fillna('').astype(str).str.contains(r'trung\s*hạn|TK\s*212', case=False, regex=True)
    d['nh'] = d.lntpcd.fillna('').astype(str).str.contains(r'ngắn\s*hạn|TK\s*211|thấu\s*chi', case=False, regex=True)
    d['th'] = d.lntpcd.fillna('').astype(str).str.contains(r'trung\s*hạn|dài\s*hạn|TK\s*21[23]', case=False, regex=True)
    d['dn'] = ~d.custtpnm.fillna('').map(norm).str.contains(r'(?:^|\s)(?:ca nhan|ho gia dinh|ho ca the|ca the)(?:\s|$)') & (d.custtpnm.fillna('').str.strip() != '')
    return d[d.cb != '']
def cb_kh(d):
    a = d[d.bal > 0]; return a.sort_values('bal', ascending=False).groupby('k').cb.first()
def goi_y(truoc, sau, ti_le=0.5, toi_thieu=5, nguyen=0.9):
    x, y = cb_kh(truoc), cb_kh(sau); j = pd.concat([x.rename('tu'), y.rename('den')], axis=1, join='inner'); j = j[j.tu != j.den]
    co = x.value_counts(); out = []
    for tu, g in j.groupby('tu'):
        vc = g.den.value_counts(); m = int(vc.sum())
        if m < toi_thieu or m < ti_le * co.get(tu, 0): continue
        out.append(dict(tu=tu, kieu='nguyen' if vc.iloc[0] >= nguyen * m else 'chia', den=vc.index[0], so=m))
    return out
def ap_dung(d, so, d_hieu_luc):
    """so: [{tu, den, kieu, kh?:set, ks?:set}]; d_hieu_luc: dòng tại ngày hiệu lực (để chia theo từng KH)."""
    cur = cb_kh(d_hieu_luc); by = {}
    for b in so: by.setdefault(b['tu'], []).append(b)
    def f(r):
        for b in by.get(r.cb, []):
            kh, ks = b.get('kh'), b.get('ks')
            if kh or ks:
                if not ((kh and r.k in kh) or (ks and r.ks in ks)): continue
            return b['den'] if b['kieu'] == 'nguyen' else cur.get(r.k, b['den'])
        return r.cb
    d = d.copy(); d['cb'] = d.apply(f, axis=1); return d
def bang(d, loc=None):
    if loc == 'th': d = d[d.th]
    if loc == 'dn': d = d[d.dn]
    if loc in ('th212', 'nh'): d = d[d[loc]]
    o = {}
    for cb, g in d.groupby(d.cb.map(norm)):
        s = g.groupby('k').bal.sum(); o[cb] = dict(kh=int((s > 0).sum()), dn=int(round(g.bal.sum())))
    return o
