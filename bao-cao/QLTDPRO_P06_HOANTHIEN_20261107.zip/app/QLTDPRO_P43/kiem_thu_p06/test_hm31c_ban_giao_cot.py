# -*- coding: utf-8 -*-
# HM-31 GĐ2 (phần còn lại) · V3 — v24.17.38: mã cán bộ (ofcno), cảnh báo tên gần giống, cột Bàn giao, chế độ mốc cũ,
# sổ: phạm vi mã KH / mã khế ước + ghi chú + người lập + Excel, và áp sổ cho Chỉ tiêu KH / Tổng quan / Trả nợ.
# DỮ LIỆU THẬT qua QLTD_MSIT80_DIR (31.12.2025.xlsx, 30.09.2026.XLS, 31.10.2026.XLS) — KHÔNG để trong repo/ZIP; thiếu ⇒ SKIP.
# Đáp án: kiem_thu_p06/dap_an_ban_giao.py (pandas đọc thẳng tệp gốc). Chạy từ app/QLTDPRO_P43/:
#   QLTD_MSIT80_DIR=/duong/dan python3 kiem_thu_p06/test_hm31c_ban_giao_cot.py [app/QLTDPRO_v24.17.38.html]
import asyncio, functools, http.server, threading, sys, os, re, json, tempfile, warnings
from pathlib import Path
warnings.filterwarnings('ignore')
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.38.html'
D = Path(os.environ.get('QLTD_MSIT80_DIR', '/khong-co'))
FS = [D / '31.12.2025.xlsx', D / '30.09.2026.XLS', D / '31.10.2026.XLS']
if not all(f.exists() for f in FS):
    print('SKIP: không có dữ liệu msit80 thật (đặt QLTD_MSIT80_DIR)'); print('\nKẾT QUẢ: 0 PASS · 0 FAIL (SKIP)'); raise SystemExit(0)
sys.path.insert(0, str(HERE))
import pandas as pd, openpyxl
from dap_an_ban_giao import doc, goi_y, ap_dung, bang, norm
from playwright.async_api import async_playwright
PORT = 8873; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm31'
if not EV.parent.exists(): EV = HERE / 'hm31'
SHOT = EV / 'anh' / Path(APP).stem; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:900]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
N, Qq, B = [doc(f) for f in FS]
GY = goi_y(N, Qq) + goi_y(Qq, B)
MA = {norm(n): m for n, m in B[B.cb != ''][['cb', 'ma']].drop_duplicates().values}
for d_ in (N, Qq):
    for n, m in d_[d_.cb != ''][['cb', 'ma']].drop_duplicates().values: MA.setdefault(norm(n), m)
TEN = {}
for d_ in (N, Qq, B):
    for n in d_[d_.cb != ''].cb.unique(): TEN[norm(n)] = n
PB = {'hội sở': 'Hội Sở', 'pgd hai bà trưng': 'PGD Hai Bà Trưng', 'pgd số 2': 'PGD Số 2'}
_t = pd.read_excel(FS[2], header=0, usecols=['ofcnm', 'trctnm']); _t['cb'] = _t.ofcnm.fillna('').astype(str).str.strip()
ROSTER = [(PB.get(str(p).strip().lower(), p), n) for n, p in _t[_t.cb != ''].groupby('cb').trctnm.agg(lambda s: s.mode().iloc[0]).items()]
def num(t):
    t = (t or '').strip().replace('▲', '').replace('▼', '').strip()
    if t in ('', '-', '—'): return 0
    v = re.sub(r'[^\d]', '', t); return (-1 if t.startswith('-') or t.startswith('−') else 1) * int(v)
def dap(so, loc=None):
    a, b, c = bang(ap_dung(N, so, B), loc), bang(ap_dung(Qq, so, B), loc), bang(B, loc)
    return {k: [a.get(k, {}).get(t, 0) for t in ('kh', 'dn')] + [b.get(k, {}).get(t, 0) for t in ('kh', 'dn')] + [c.get(k, {}).get(t, 0) for t in ('kh', 'dn')] for k in set(a) | set(b) | set(c)}
def thang(d, so): return bang(ap_dung(d, so, B))
async def bang_app(pg, tab):
    await pg.click(f'[data-testid=bcn-sub-{tab}]'); await pg.wait_for_timeout(400)
    r = await pg.evaluate("[...document.querySelectorAll('[data-testid=bcn-table] tbody tr')].map(r=>[r.dataset.kind,r.dataset.bg||'',...[...r.children].map(c=>c.textContent.trim())])")
    return r
async def so_sanh(pg, T, so, nhan):
    E = dap(so); rk, rd = await bang_app(pg, 'kh'), await bang_app(pg, 'dn')
    ck = {norm(r[2]): [num(x) for x in r[3:]] for r in rk if r[0] == 'cbtd'}; cd = {norm(r[2]): [num(x) for x in r[3:]] for r in rd if r[0] == 'cbtd'}
    tk = [num(x) for x in [r for r in rk if r[0] == 'tong'][0][3:]]; td = [num(x) for x in [r for r in rd if r[0] == 'tong'][0][3:]]
    ek = [sum(v[i] for v in E.values()) for i in (0, 2, 2, 4)]; ed = [sum(v[i] for v in E.values()) for i in (1, 3, 3, 5)]
    ok(T(f'{nhan}: TỔNG KH 4 mốc {tk[:4]} = Python {ek}; TỔNG dư nợ (±2 đ)'), tk[:4] == ek and all(abs(a - b) <= 2 for a, b in zip(td[:4], ed)), (tk[:4], ek, td[:4], ed))
    sai = [(k[:10], ck.get(k, [None])[:4], [v[0], v[2], v[2], v[4]]) for k, v in E.items() if any(v) and (ck.get(k, [None] * 4)[:4] != [v[0], v[2], v[2], v[4]] or any(abs(x - y) > 2 for x, y in zip(cd.get(k, [9e18] * 4)[:4], [v[1], v[3], v[3], v[5]])))]
    ok(T(f'{nhan}: từng cán bộ ({sum(1 for v in E.values() if any(v))}) KH + dư nợ 4 mốc = Python'), not sai, sai[:3])
    return ck, cd, tk, td, E
async def mo(pg, URL):
    await pg.goto(URL + '#/chi-tieu-ke-hoach', wait_until='domcontentloaded'); await pg.wait_for_timeout(3500)
    await pg.click('[data-testid=ct-tab-ngay]'); await pg.wait_for_selector('[data-testid=bg-host] [data-testid=bg-bar]', timeout=20000); await pg.wait_for_timeout(1000)
async def chon(pg, sel, name):
    await pg.select_option(sel, name); await pg.wait_for_timeout(1500)
async def run(pw, name, vw, vh, day_du):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN', is_mobile=vw < 600, has_touch=vw < 600, accept_downloads=True)
    await ctx.add_init_script("try{if(!sessionStorage.getItem('__k')){sessionStorage.setItem('__k','1');localStorage.setItem('gd9_tplok','0');localStorage.setItem('td_roster_v1'," + json.dumps('\n'.join(f'{p} | {n} | CBTD' for p, n in ROSTER)) + ")}}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    T = lambda s: f'{name}: {s}'
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in FS]); await pg.wait_for_timeout(12000)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(1000)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(25000)
    # C1 mã cán bộ r[32]
    rows = await pg.evaluate("(window.__GD7S&&window.__GD7S.qltd||[]).map(r=>[r[12],r[32]])")
    app_ma = {norm(n): m for n, m in rows if n}
    ok(T(f'C1 mã cán bộ (ofcno) lưu ở mọi dòng: {sum(1 for _, m in rows if m)}/{len(rows)}, {len(app_ma)} cán bộ = Python'), rows and all(m for _, m in rows) and all(MA.get(k) == v for k, v in app_ma.items()) and len(app_ma) == len(B[B.cb != ''].cb.unique()), (len(rows), list(app_ma.items())[:2]))
    await mo(pg, URL)
    # C2 gợi ý mang mã
    g = await pg.evaluate("[...document.querySelectorAll('[data-testid=bg-goiy-row]')].map(r=>[r.dataset.tu,r.dataset.ma])")
    ok(T(f'C2 {len(g)} gợi ý bàn giao mang MÃ cán bộ đúng'), len(g) == len(GY) and all(MA.get(norm(t)) == m for t, m in g), g[:3])
    # C3 cảnh báo tên gần giống (đáp án Python độc lập: cùng họ + cùng tên, thiếu/thừa 1–2 chữ đệm, hoặc khác ≤ 2 ký tự)
    names = {m: TEN[k] for k, m in MA.items()}
    def gan(a, b):
        ta, tb = a.split(), b.split()
        if a == b: return False
        if len(ta) >= 2 and len(tb) >= 2 and ta[0] == tb[0] and ta[-1] == tb[-1] and abs(len(ta) - len(tb)) <= 2:
            s_, l_ = (ta, tb) if len(ta) < len(tb) else (tb, ta)
            if all(t in l_ for t in s_): return True
        import difflib
        return sum(1 for o in difflib.SequenceMatcher(None, a, b).get_opcodes() if o[0] != 'equal') <= 1 and abs(len(a) - len(b)) <= 2 and sum(max(o[2] - o[1], o[4] - o[3]) for o in difflib.SequenceMatcher(None, a, b).get_opcodes() if o[0] != 'equal') <= 2
    ms = sorted(names); exp = {frozenset((x, z)) for i, x in enumerate(ms) for z in ms[i + 1:] if gan(norm(names[x]), norm(names[z]))}
    canh = await pg.evaluate("(document.querySelector('[data-testid=bg-canh]')||{innerText:''}).innerText")
    got = {frozenset(re.findall(r'\(mã (\d+)\)', ln)) for ln in canh.split('\n') if 'Tên gần giống' in ln}
    ok(T(f'C3 cảnh báo tên gần giống: {len(got)} cặp (mã) = Python {len(exp)}; ghi rõ "hai người khác nhau, app không gộp"'), got == exp and len(exp) >= 1 and 'không gộp' in canh, (got, exp))
    await pg.screenshot(path=str(SHOT / f'{name}_c_1_goi_y.png'), full_page=True)
    await pg.click('[data-testid=bg-xn-all]'); await pg.wait_for_timeout(1500)
    so = [dict(b) for b in GY]
    ck, cd, tk, td, E = await so_sanh(pg, T, so, 'C4 sau xác nhận 9 bàn giao')
    # cột Bàn giao
    rk = await bang_app(pg, 'kh'); raw_n, raw_q = bang(N), bang(Qq); new_n, new_q = thang(N, so), thang(Qq, so)
    bgk = {norm(r[2]): (num(r[12]), num(r[13])) for r in rk if r[0] == 'cbtd'}
    sai = []
    for k in set(raw_n) | set(raw_q) | set(new_n) | set(new_q):
        e = (new_q.get(k, {}).get('kh', 0) - raw_q.get(k, {}).get('kh', 0), new_n.get(k, {}).get('kh', 0) - raw_n.get(k, {}).get('kh', 0))
        if e != (0, 0) and bgk.get(k) != e: sai.append((k[:10], bgk.get(k), e))
        if e == (0, 0) and bgk.get(k, (0, 0)) != (0, 0): sai.append((k[:10], bgk.get(k), e))
    tg = [r for r in rk if r[0] == 'tong'][0]
    etq = sum(v['kh'] for v in new_q.values()) - sum(v['kh'] for v in raw_q.values()); etn = sum(v['kh'] for v in new_n.values()) - sum(v['kh'] for v in raw_n.values())
    ok(T(f'C5 cột "Bàn giao đầu quý / đầu năm" (KH) từng cán bộ = (tính lại − thô) Python; TỔNG ({tg[12]}, {tg[13]}) = Python ({etq}, {etn}) — chênh do KH vay ở 2 cán bộ đếm 1 lần'), not sai and (num(tg[12]), num(tg[13])) == (etq, etn), (sai[:4], tg[12:14], etq, etn))
    vân = [r for r in rk if r[0] == 'cbtd' and r[1] == '1']
    ok(T(f'C6 cán bộ đã bàn giao hết hiện ở nhóm riêng với số âm ở Bàn giao ({len(vân)} dòng)'), vân and all(num(r[13]) < 0 or num(r[12]) < 0 for r in vân if not any(num(x) for x in r[3:7])), vân[:2])
    rd = await bang_app(pg, 'dn'); bgd = {norm(r[2]): (num(r[12]), num(r[13])) for r in rd if r[0] == 'cbtd'}
    sai = [(k[:10], bgd.get(k), (round(new_q.get(k, {}).get('dn', 0) - raw_q.get(k, {}).get('dn', 0)), round(new_n.get(k, {}).get('dn', 0) - raw_n.get(k, {}).get('dn', 0)))) for k in set(raw_n) | set(new_n) | set(raw_q) | set(new_q)
           if any(abs(x - y) > 2 for x, y in zip(bgd.get(k, (0, 0)), (new_q.get(k, {}).get('dn', 0) - raw_q.get(k, {}).get('dn', 0), new_n.get(k, {}).get('dn', 0) - raw_n.get(k, {}).get('dn', 0))))]
    tgd = [r for r in rd if r[0] == 'tong'][0]
    ok(T(f'C7 Bàn giao (dư nợ) từng cán bộ = Python (±2 đ); TỔNG bàn giao dư nợ = ({tgd[12]}, {tgd[13]}) = 0'), not sai and abs(num(tgd[12])) <= 2 and abs(num(tgd[13])) <= 2, sai[:3])
    kt = (await pg.inner_text('[data-testid=bg-kiem]')).strip()
    ok(T(f'C8 dòng kiểm ✓ gồm "Σ bàn giao dư nợ = 0" ({kt[:70]})'), kt.startswith('✓') and 'Σ bàn giao dư nợ = 0' in kt, kt)
    await pg.screenshot(path=str(SHOT / f'{name}_c_2_cot_ban_giao.png'), full_page=True)
    if not day_du:
        sw = await pg.evaluate("[document.scrollingElement.scrollWidth, innerWidth]")
        ok(T(f'M1 điện thoại: không cuộn ngang ({sw})'), sw[0] <= sw[1] + 1, sw)
        ok(T('E1 0 pageerror'), not errs, errs[:3]); await br.close(); return
    # chế độ cũ
    await chon(pg, '[data-testid=bcn-cd]', 'cu')
    ck2, cd2, tk2, td2, _ = await so_sanh(pg, T, [], 'C9 chế độ "theo cán bộ tại thời điểm mốc" = số thô (GĐ1)')
    bg0 = [(r[12], r[13]) for r in await bang_app(pg, 'kh') if r[0] in ('cbtd', 'tong')]
    ok(T('C10 chế độ cũ: cột Bàn giao toàn 0/-'), all(num(a) == 0 and num(b) == 0 for a, b in bg0), bg0[:3])
    await chon(pg, '[data-testid=bcn-cd]', 'moi')
    # áp sổ cho các màn khác
    RN = {n for _, n in ROSTER}; PK = next(b for b in GY if b['kieu'] == 'nguyen' and b['tu'] in RN and b['den'] in RN)
    ct = {}
    await pg.goto(URL + '#/chi-tieu-ke-hoach', wait_until='domcontentloaded'); await pg.wait_for_timeout(3500)
    await pg.click('[data-testid=ct-tab-matrix]'); await pg.wait_for_timeout(500)
    await chon(pg, '[data-testid=ct-scope]', 'cbtd'); sai = []
    for who in (PK['tu'], PK['den']):
        await chon(pg, '[data-testid=ct-scope-id]', who)
        hd = await pg.evaluate("[...document.querySelectorAll('[data-testid=ct-matrix] thead th')].map(t=>t.textContent.trim())")
        row = await pg.evaluate("[...document.querySelector('[data-testid=ct-matrix] tbody tr[data-id=tongDuNo]').children].map(c=>(c.childNodes[0]?c.childNodes[0].textContent:'').trim())")
        ci = next(i for i, h in enumerate(hd) if 'Đầu năm' in h); cq = next(i for i, h in enumerate(hd) if 'Đầu Q4' in h)
        e_n, e_q = new_n.get(norm(who), {}).get('dn', 0), new_q.get(norm(who), {}).get('dn', 0)
        if abs(num(row[ci]) - e_n) > 2 or abs(num(row[cq]) - e_q) > 2: sai.append((norm(who)[:10], num(row[ci]), e_n, num(row[cq]), e_q))
    ok(T('S1 Chỉ tiêu KH → THEO CBTD: dư nợ cột Đầu năm / Đầu Q4 của cán bộ giao & nhận = Python tính lại theo sổ (±2 đ)'), not sai, sai)
    await pg.screenshot(path=str(SHOT / f'{name}_c_3_chi_tieu.png'), full_page=True)
    await pg.goto(URL + '#/tong-quan', wait_until='domcontentloaded'); await pg.wait_for_selector('[data-testid=gd7-delta]', timeout=20000); await pg.wait_for_timeout(1000)
    dl = await pg.evaluate("Object.fromEntries([...document.querySelectorAll('[data-testid=gd7-delta] tbody tr')].map(r=>[r.children[0].textContent.trim(),[...r.children].map(c=>c.textContent.trim())]))")
    sai = []
    for who in (PK['tu'], PK['den']):
        r = next((v for k, v in dl.items() if norm(k) == norm(who)), None); e = new_q.get(norm(who), {}).get('dn', 0)
        if not r or abs(num(r[2]) - e) > 2: sai.append((norm(who)[:10], r and num(r[2]), e))
    ok(T('S2 Tổng quan "Biến động dư nợ theo cán bộ": cột dư nợ kỳ trước (30/09) = Python tính lại theo sổ (±2 đ)'), not sai, sai)
    await pg.goto(URL + '#/tra-no-xuat-ts', wait_until='domcontentloaded'); await pg.wait_for_selector('[data-testid=tn-cbtd]', timeout=30000); await pg.wait_for_timeout(1500)
    sai = []
    cur = B[B.cb != ''].assign(k=B.k)
    for who in (PK['tu'], PK['den']):
        d0 = ap_dung(N, so, B); d0 = d0[d0.cb == who]; p = d0.groupby('k').bal.sum(); h = B[B.cb == who].groupby('k').bal.sum()
        giam = {k: h.get(k, 0) - v for k, v in p.items() if h.get(k, 0) > 0 and h.get(k, 0) < v}; het = [k for k, v in p.items() if v > 0 and h.get(k, 0) == 0]
        await chon(pg, '[data-testid=tn-cbtd]', who)
        tg_, he_ = num(await pg.inner_text('[data-testid=tn-tonggiam]')), num(await pg.inner_text('[data-testid=tn-het]'))
        hh = await pg.inner_text('[data-testid=tn-giam] h3'); ng = int(re.search(r'\((\d+)\)', hh).group(1))
        if abs(tg_ - abs(sum(giam.values()))) > 2 or he_ != len(het) or ng != len(giam): sai.append((norm(who)[:10], tg_, round(abs(sum(giam.values()))), he_, len(het), ng, len(giam)))
    ok(T('S3 Trả nợ/xuất TS (lọc cán bộ giao & nhận): tổng giảm, số KH giảm, số KH hết dư nợ = Python tính lại theo sổ'), not sai, sai)
    # --- thêm thủ công: phạm vi mã KH / mã khế ước ---
    await mo(pg, URL)
    await pg.evaluate("document.querySelector('[data-testid=bg-so]').open=true")
    while await pg.locator('[data-testid=bg-xoa]').count():
        await pg.locator('[data-testid=bg-xoa]').first.click(); await pg.wait_for_timeout(800); await pg.evaluate("document.querySelector('[data-testid=bg-so]').open=true")
    ng_ = [b for b in GY if b['kieu'] == 'nguyen'][:2]; X, Y = ng_
    khl = list(Qq[(Qq.cb == X['tu']) & (Qq.bal > 0)].k.unique()[:3]); ksl = list(Qq[(Qq.cb == Y['tu']) & (Qq.bal > 0)].ks.unique()[:2])
    mk = lambda b: {'tu': b['tu'], 'den': b['den'], 'kieu': 'nguyen'}
    so2 = [dict(mk(X), kh=set(khl)), dict(mk(Y), ks=set(ksl))]
    for b, kh, ks, gc, ng in ((X, khl, [], 'Bàn giao một phần theo mã KH', 'Người lập A'), (Y, [], ksl, 'Bàn giao theo mã khế ước', 'Người lập B')):
        await pg.evaluate("document.querySelector('[data-testid=bg-so]').open=true; document.querySelector('[data-testid=bg-add]').open=true")
        await pg.select_option('[data-testid=bg-add-tu]', f"{MA[norm(b['tu'])]}|{b['tu']}"); await pg.select_option('[data-testid=bg-add-den]', f"{MA[norm(b['den'])]}|{b['den']}")
        await pg.fill('[data-testid=bg-add-ngay]', '2026-10-31'); await pg.select_option('[data-testid=bg-add-kieu]', 'nguyen')
        await pg.fill('[data-testid=bg-add-kh]', ' '.join(kh)); await pg.fill('[data-testid=bg-add-ks]', '\n'.join(ks)); await pg.fill('[data-testid=bg-add-gc]', gc); await pg.fill('[data-testid=bg-add-nguoi]', ng)
        await pg.click('[data-testid=bg-add-ok]'); await pg.wait_for_timeout(1500)
    n = (await pg.inner_text('[data-testid=bg-n]')).strip(); pv = await pg.evaluate("[...document.querySelectorAll('[data-testid=bg-da-row]')].map(r=>r.children[3].textContent)")
    ok(T(f'P1 thêm thủ công 2 dòng sổ ({n}); phạm vi hiện "{pv}"'), n == '2' and pv == [f'{len(khl)} mã KH', f'{len(ksl)} mã khế ước'], (n, pv))
    await so_sanh(pg, T, so2, 'P2 phạm vi mã KH + mã khế ước: chỉ dòng thuộc phạm vi chuyển')
    full = dap(so2); ref = dap([mk(X), mk(Y)])
    ok(T('P3 phạm vi hẹp cho số khác với chuyển cả danh mục (không chuyển hết)'), full != ref)
    # ghi chú + người lập, F5
    await pg.evaluate("document.querySelector('[data-testid=bg-so]').open=true")
    gi = await pg.evaluate("[...document.querySelectorAll('[data-testid=bg-da-row]')].map(r=>[r.querySelector('[data-testid=bg-gc]').value,r.querySelector('[data-testid=bg-nguoi]').value])")
    ok(T(f'P4 ghi chú / người lập lưu ({gi})'), gi == [['Bàn giao một phần theo mã KH', 'Người lập A'], ['Bàn giao theo mã khế ước', 'Người lập B']], gi)
    await pg.fill('[data-testid=bg-da-row] [data-testid=bg-gc] >> nth=0', 'Đã sửa ghi chú'); await pg.keyboard.press('Tab'); await pg.wait_for_timeout(500)
    await pg.reload(wait_until='domcontentloaded'); await mo(pg, URL); await pg.evaluate("document.querySelector('[data-testid=bg-so]').open=true")
    gi = await pg.evaluate("[...document.querySelectorAll('[data-testid=bg-da-row]')].map(r=>r.querySelector('[data-testid=bg-gc]').value)")
    ok(T('P5 F5: ghi chú đã sửa vẫn còn, sổ 2 dòng'), gi[0] == 'Đã sửa ghi chú' and len(gi) == 2, gi)
    await so_sanh(pg, T, so2, 'P6 sau F5')
    async with pg.expect_download() as dl_:
        await pg.click('[data-testid=bg-xlsx]')
    p = Path(tempfile.mkdtemp()) / 'so.xlsx'; await (await dl_.value).save_as(p)
    ws = openpyxl.load_workbook(p).active; vals = [[c.value for c in r] for r in ws.iter_rows()]
    ok(T(f'X1 Excel biên bản: tiêu đề + 2 dòng; có mã cán bộ, ghi chú, người lập, phạm vi ({len(vals)} dòng)'),
       len(vals) == 3 and vals[0][:3] == ['Hiệu lực', 'Từ cán bộ', 'Mã cán bộ'] and any('Đã sửa ghi chú' in str(c) for c in vals[1] + vals[2]) and any('Người lập B' in str(c) for c in vals[2])
       and any(str(c).endswith('mã KH') for c in vals[1]) and any(str(c).endswith('mã khế ước') for c in vals[2]) and MA[norm(X['tu'])] in [str(c) for c in vals[1]], vals)
    await pg.screenshot(path=str(SHOT / f'{name}_c_4_thu_cong.png'), full_page=True)
    ok(T('E1 0 pageerror'), not errs, errs[:3]); await br.close()
async def main():
    async with async_playwright() as pw:
        await run(pw, 'desktop', 1366, 900, True)
        await run(pw, 'mobile', 390, 844, False)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
