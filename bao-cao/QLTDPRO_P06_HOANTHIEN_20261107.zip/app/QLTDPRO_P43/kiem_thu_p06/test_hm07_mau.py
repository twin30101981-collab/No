# -*- coding: utf-8 -*-
# HM-07 · V3 — Mở app không còn dò thư mục templates/ (http và file://): 0 yêu cầu, 0 lỗi console, không tạo sẵn kho mẫu rỗng;
# nạp mẫu bằng "📁 Nạp thư mục mẫu…" trong 📚 Bộ hồ sơ vẫn chạy; xuất mẫu chưa nạp báo rõ cách nạp. Q27 (người dùng 07/11/2026).
# Mẫu thử: 3 tệp .docx tự sinh (python-docx), đúng tên 3 mẫu duy nhất của 3 sản phẩm — không dùng mẫu thật.
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p06/test_hm07_mau.py [app/QLTDPRO_v24.17.37.html]
import asyncio, functools, http.server, threading, sys, tempfile, shutil
from pathlib import Path
import docx
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.37.html'
PORT = 8876; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:600]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
TMP = Path(tempfile.mkdtemp()); MAU = TMP / 'mau'
for p in ['TIÊU DÙNG/GIẢI NGÂN/Hợp đồng đặt cọc - TH.docx', 'CẦM CỐ/TT CHUNG - GIẢI NGÂN/Bảng kê mua hàng.docx', 'HẠN MỨC TÍN DỤNG/TT CHUNG/Biên bản kiểm tra SDVV.docx']:
    f = MAU / p; f.parent.mkdir(parents=True, exist_ok=True); d = docx.Document(); d.add_paragraph('Mẫu thử HM-07'); d.save(f)
FILE_URL = (ROOT / APP).resolve().as_uri()
async def mo(pw, url, T, nhan):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': 1366, 'height': 900}, locale='vi-VN')
    pg = await ctx.new_page(); req, con = [], []
    pg.on('request', lambda r: req.append(r.url) if 'templates' in r.url else None)
    pg.on('console', lambda m: con.append(m.text[:200]) if m.type == 'error' else None)
    errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    for lan in (1, 2):
        req.clear(); con.clear()
        await pg.goto(url, wait_until='domcontentloaded'); await pg.wait_for_timeout(5000)
        dbs = await pg.evaluate("indexedDB.databases().then(d=>d.map(x=>x.name))")
        ok(T(f'{nhan} lần {lan}: 0 yêu cầu templates/ ({len(req)}), 0 lỗi console ({len(con)}), không tạo kho mẫu rỗng'), not req and not con and 'QLTDProMauHsvx' not in dbs, (req[:2], con[:3], dbs))
    return br, ctx, pg, errs
async def main():
    async with async_playwright() as pw:
        T = lambda s: s
        br, ctx, pg, e1 = await mo(pw, FILE_URL, T, 'F1 file://'); await br.close()
        br, ctx, pg, errs = await mo(pw, URL, T, 'H1 http')
        await pg.goto(URL + '#/ho-so-vay-hop-nhat', wait_until='domcontentloaded'); await pg.wait_for_timeout(3000)
        await pg.click('[data-testid=hx-more]'); await pg.wait_for_timeout(300); await pg.click('[data-testid=hx-bo]')
        await pg.wait_for_selector('[data-testid=bo-dialog]'); await pg.wait_for_timeout(1500)
        h0 = (await pg.inner_text('[data-testid=bo-have]')).strip()
        ok(T(f'B1 mở 📚 Bộ hồ sơ khi chưa nạp: "{h0}"'), h0.startswith('Đã nạp 0/'), h0)
        dis = await pg.evaluate("[...document.querySelectorAll('[data-testid=bo-one]')].map(b=>b.disabled)")
        ok(T(f'B2 mẫu chưa nạp: nút ⬇ Xuất bị khoá ({sum(dis)}/{len(dis)})'), dis and all(dis), dis[:5])
        await pg.set_input_files('[data-testid=bo-dir]', str(MAU)); await pg.wait_for_timeout(2500)
        txt = await pg.evaluate("document.body.innerText"); h1 = (await pg.inner_text('[data-testid=bo-have]')).strip()
        dbs = await pg.evaluate("indexedDB.databases().then(d=>d.map(x=>x.name))")
        n = await pg.evaluate("new Promise(r=>{const q=indexedDB.open('QLTDProMauHsvx');q.onsuccess=()=>{const t=q.result.transaction('files').objectStore('files').count();t.onsuccess=()=>{r(t.result);q.result.close()}}})")
        dis1 = await pg.evaluate("[...document.querySelectorAll('[data-testid=bo-one]')].filter(b=>!b.disabled).length")
        ok(T(f'B3 📁 Nạp thư mục mẫu (3 tệp thử, 3 sản phẩm) → "Đã nạp 3 mẫu", kho có {n} mẫu, ô đếm "{h1}", {dis1} nút Xuất mở'), 'Đã nạp 3 mẫu' in txt and n == 3 and 'QLTDProMauHsvx' in dbs and h1.startswith('Đã nạp 1/') and dis1 == 1, (txt[-300:], n, h1, dis1))
        await pg.reload(wait_until='domcontentloaded'); await pg.wait_for_timeout(4000)
        n2 = await pg.evaluate("new Promise(r=>{const q=indexedDB.open('QLTDProMauHsvx');q.onsuccess=()=>{const t=q.result.transaction('files').objectStore('files').count();t.onsuccess=()=>{r(t.result);q.result.close()}}})")
        ok(T(f'B4 F5 → mẫu đã nạp vẫn còn ({n2})'), n2 == 3, n2)
        ok(T('E1 0 pageerror'), not errs and not e1, (errs[:2], e1[:2]))
        await br.close()
    shutil.rmtree(TMP, ignore_errors=True)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
