# HM-29 — Xem tại mốc + So với mốc từ ô "Dữ liệu ngày ▾" — v24.17.33 (gd25) — DAT_V3
Dựng: `python3 nguon_P05/build_p05_hm29.py` (v24.17.32 → .33). Người dùng 07/11: chọn "Xem mốc + so mốc"; F5 → về dữ liệu hiện hành.
- Bấm ô ngày → hộp: "Dữ liệu hiện hành" + mọi mốc msit80 trong Lưu trữ (mới → cũ, nhãn Cuối năm/Quý/Tháng, số KH, tỷ đồng).
- Chọn mốc → tải lại một lần (cờ sessionStorage dùng một lần): kho dư nợ đọc từ IndexedDB TWIN_Archive_v1/reportData, chế độ CHỈ XEM (readOnlyReason sẵn có chặn mọi lệnh lưu),
  ngày dữ liệu = ngày mốc (TD.dataDate đọc qua kho ảo, không ghi localStorage), danh sách mốc chỉ gồm mốc ≤ mốc đang xem (so sánh chỉ lùi về quá khứ), ghi danh sách mốc bị chặn.
  Dải tím "Đang xem mốc … CHỈ XEM" + nút "Về dữ liệu hiện hành"; vào Nhập dữ liệu ⇒ tự về hiện hành. Tài sản bảo đảm vẫn theo sao kê hiện hành (ghi trong dải).
- "So với mốc cũ hơn": bảng Tổng dư nợ, KH, khoản, Ngắn hạn, Trung-dài, Thấu chi, Doanh nghiệp, Nhóm 2–5 (hiện tại vs mốc).
- Sửa trong lúc làm: nhãn mốc dạng đối tượng hiện "[object Object]" → chữ; không tạo CSDL IndexedDB rỗng khi chưa có (huỷ onupgradeneeded như zv()).
Kiểm V3 `kiem_thu_p05/test_hm29_xem_moc.py`: v24.17.34 **26 PASS · 0 FAIL** (v24.17.32 trước sửa: trượt toàn bộ ca mới).
Hạn chế đã biết: chưa chạy với tệp thật; Tài sản bảo đảm không theo mốc; mốc cũ không có cột custtpnm ⇒ DN theo tên.
