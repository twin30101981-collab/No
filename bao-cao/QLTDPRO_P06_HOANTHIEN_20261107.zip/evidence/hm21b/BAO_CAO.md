# HM-21b — v24.17.28 — dòng dữ liệu mọi bảng xếp theo cán bộ như Báo cáo ngày — DAT_V3
Người dùng 06/11 (ảnh 8 trang): dòng trong bảng vẫn xếp theo ngày, cán bộ lẫn lộn. Dựng: `python3 nguon_P05/build_p05_hm21b.py` (v24.17.27 → .28).
## Sửa
- gd7.tdef: mọi bảng có cột Cán bộ/CBTD → sắp mặc định **Cán bộ ↑ (thứ tự danh mục: Phòng KH → PGD HBT → PGD Số 2, trong phòng theo danh mục)**, rồi ngày sẵn có ↑ (cũ → mới).
- gd7.tload: bố cục người dùng đã lưu (chưa có cờ l21) → chỉ thay cách sắp MỘT lần; giữ cột, độ rộng, lọc.
- Bảng dùng chung: bấm sắp theo cột Cán bộ dùng thứ tự danh mục (không theo chữ cái).
- Lỗi nền phát hiện khi kiểm ảnh: Nợ đến hạn / Lãi đọng có dòng chồng chữ sau khi cuộn (khóa dòng trùng khi 1 khoản có nhiều dòng). Sửa: khóa dòng = khóa + vị trí.
## Kiểm chứng V3 — `python3 kiem_thu_p05/test_hm21b_dong_cb.py`
10 trang (Tất cả dư nợ, Ngắn hạn, Trung-dài hạn, Nợ đến hạn, Lãi đọng, Chuyển HM, Giải ngân, Dư nợ cầm cố, TSBĐ, Trả nợ) × desktop 1366 + điện thoại 390:
cuộn HẾT bảng, kiểm thứ tự cán bộ, ngày cũ → mới trong mỗi cán bộ, 0 dòng chồng lúc chụp ảnh, chuyển bố cục đã lưu, 0 pageerror.
- v24.17.28: **77 PASS · 0 FAIL** (Dư nợ cầm cố: dữ liệu thử 0 khoản → chỉ kiểm cách sắp). Ảnh: anh/QLTDPRO_v24.17.28/
- v24.17.27 (trước sửa): 18 PASS · 43 FAIL (gồm dòng chồng 505/1421 ở Nợ đến hạn/Lãi đọng).
## Hồi quy chung (v24.17.28)
Lần 1: 1442 PASS · 5 FAIL — đều do KỲ VỌNG cũ về thứ tự dòng (thiết kế mới: cán bộ trước):
p05_hm21 D1 (4 ca, chờ cả bảng theo ngày) → sửa thành "ngày cũ → mới trong mỗi cán bộ"; p52_ma_kh R3 (chờ KH có hồ sơ ở đầu bảng) → lọc theo mã KH đó.
Chạy lại 2 bộ: 49/0 (p52 trên v24.17.27 vẫn đạt) ⇒ **1447 PASS · 0 FAIL** (LỆCH PB 12 = ca nhãn phiên bản đã khai báo; LOI_MT p41/p42_gd14 như cũ).
