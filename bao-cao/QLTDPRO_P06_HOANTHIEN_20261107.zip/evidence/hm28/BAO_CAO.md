# HM-28 — "Dư nợ cầm cố" → "Cầm cố", sắp lại menu Dư nợ — v24.17.32 — DAT_V3
Dựng: `python3 nguon_P05/build_p05_hm28.py` (v24.17.31 → .32).
## Làm (người dùng 07/11)
- Trang "Dư nợ cầm cố" đổi tên **"Cầm cố"** (menu, tiêu đề, tên tệp Excel `Cam_co_…`), đặt ngay sau trang "Doanh nghiệp".
- Trang "Khách hàng mới" đặt ngay sau "Cầm cố".
- Thứ tự menu Dư nợ: Tất cả dư nợ · Ngắn hạn · Thấu chi · Trung-dài hạn · Doanh nghiệp · **Cầm cố · Khách hàng mới** · Khách hàng 360°.
## An toàn
Chỉ đổi nhãn + thứ tự khai báo menu; slug cũ giữ nguyên (`#/du-no-cam-co`, `#/khach-hang-moi`) ⇒ liên kết, bố cục bảng, phạm vi lọc đã lưu, công thức không đổi. Thêm alias tìm kiếm "du-no-cam-co".
Thẻ "Dư nợ cầm cố" bên trong trang là tên chỉ tiêu (số tiền), giữ nguyên.
## Kiểm chứng V3 — `python3 kiem_thu_p05/test_hm28_cam_co_menu.py`
Dữ liệu thử ẩn danh: dư nợ 3 mốc + sao kê TS có 6 khách cầm cố (chứng chỉ tiền gửi) + 3 khách TS thường; đáp án Python độc lập; desktop + điện thoại.
- v24.17.32: **19 PASS · 0 FAIL** — thứ tự menu (8 mục liền nhau), nhãn mới, tiêu đề trang, khung trang cầm cố, 6 khách / dư nợ 5.095.101.000 đ = Python, Excel `Cam_co`, bấm lần lượt 8 mục menu đều mở, trang Khách hàng mới vẫn lập được báo cáo, quét 25 trang không trang nào trống, không tràn ngang trên điện thoại, 0 pageerror.
- v24.17.31 (trước): xem log/test_hm28_tren_v24.17.31_TRUOC.log.
