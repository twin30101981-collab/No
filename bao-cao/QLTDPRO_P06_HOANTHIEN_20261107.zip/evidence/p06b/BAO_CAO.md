# v24.17.42 → v24.17.43 — yêu cầu PC/laptop của người dùng (07/11/2026)

## v24.17.42 — bố cục trang Chỉ tiêu kế hoạch (ảnh người dùng)
Mặc định mở ở tab BÁO CÁO NGÀY; khối "📊 Kế hoạch quý" đặt TRÊN khối "🔁 Sổ bàn giao cán bộ". Cho phép ngày hiệu lực thực tế SAU ngày mốc gợi ý (ảnh người dùng: Lưu trữ có mốc "30/09" thực chất là tệp đầu tháng 10 đã mang số sau bàn giao ⇒ mốc đó giữ nguyên, các mốc trước được tính lại). Bộ kiểm cũ (p04_hm20, p04_hm03, p05_hm25) bấm tab TỔNG QUAN sau khi mở trang vì mặc định đổi.

## v24.17.43 (nguon_P06/build_p06_hm32.py; test kiem_thu_p06/test_hm32_cot_tien.py)
1. **Cột tiền lên màn hình đầu tiên** (PC/laptop, trừ Tổng quan và Chỉ tiêu KH): Dư nợ ở cột thứ 7 các trang Tất cả dư nợ, Ngắn hạn, Thấu chi, Trung-dài hạn, Doanh nghiệp, Nợ đến hạn, Lãi đọng, Dư nợ cầm cố; Chuyển hạn mức: HMTD + Dư nợ ngay sau "Số ngày còn lại"; Trả nợ/xuất TS: Dư nợ đầu năm, hiện tại, Giảm ngay sau Cán bộ. Bố cục người dùng đã lưu được đổi thứ tự cột MỘT lần (cờ l31), giữ độ rộng/lọc/cột ẩn; ai đã tự xếp lại sau đó thì giữ nguyên.
2. **Ma trận Loại vay × Nhóm nợ**: ô đậm nhất cũ trùng màu thanh tiêu đề (rgb 31,78,121) ⇒ đậm tối đa còn ~62%, chữ trắng khi nền đậm.
3. **Xu hướng kỳ**: bảng kỳ mới nhất lên đầu (biểu đồ vẫn theo thời gian).
4. **Tài sản bảo đảm** chưa có sao kê: lời nhắn nói rõ tệp msit80 KHÔNG chứa tài sản bảo đảm, cần nhập riêng tệp "Sao ke tai san bao dam dd.mm.yyyy.XLS" (kéo thả cùng lúc với msit80 được). Kiểm trên số thật: chỉ msit80 ⇒ trang trống (đúng thiết kế); thêm 3 tệp sao kê ⇒ trang hiện 2.254 TS, đối chiếu 3.864 dòng dư nợ, cả v24.17.34 và v24.17.43, 0 lỗi trang ⇒ KHÔNG phải lỗi phần mềm.

## Kiểm chứng V3 (số thử ẩn danh)
v24.17.43: 11 PASS · 0 FAIL (1280/1366/1920 px; màu ô; thứ tự kỳ; lời nhắn TSBĐ; chuyển bố cục lưu cũ + giữ bố cục người dùng đã xếp). v24.17.42 (trước sửa): 4 PASS · 7 FAIL.
Chưa làm (hỏi lại): đảo thứ tự mốc (mới → cũ) ở các cột mốc của Chỉ tiêu KH/Báo cáo ngày — đang theo trình tự thời gian như bản in; Lưu trữ đã mới → cũ từ HM-30.
