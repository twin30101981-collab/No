# HM-26 — Khách hàng mới: nhãn tím "TS trước kỳ" — v24.17.30 — DAT_V3
Dựng: `python3 nguon_P05/build_p05_hm26.py` (v24.17.29 → .30).
## Quy tắc (người dùng 06/11, chốt lại lần 2)
Tab Chi tiết → KH vay mới: khách vay mới, KHÔNG cầm cố, có ≥ 1 tài sản trong sao kê TSBĐ (theo mã KH) với ngày thế chấp (plgdt) < ngày đầu kỳ
⇒ nhãn tím "TS trước kỳ" thay chữ "mới" (kể cả khi còn TS khác thế chấp trong kỳ). TS không có ngày: coi là trước kỳ nếu đã có trong sao kê đầu kỳ.
Giữ "mới": chỉ có TS trong kỳ; không có TS; không nạp sao kê TSBĐ. Khách cầm cố: "mới" + "cầm cố" như cũ. Số đếm KH mới / món / tiền không đổi.
## Kiểm chứng V3 — `python3 kiem_thu_p05/test_hm26_ts_truoc_ky.py`
5 khách thử: TS trước kỳ → TS trước kỳ; TS trong kỳ → mới; không TS → mới; cầm cố → mới + cầm cố; 2 TS (trước + trong kỳ) → TS trước kỳ. Màu tím rgb(91,33,182). Desktop + điện thoại.
- v24.17.30: **14 PASS · 0 FAIL** · v24.17.29 (trước): trượt N1, N5, T1.
- Hồi quy chung: **1498 PASS · 0 FAIL** (30 bộ; LỆCH PB 12 = nhãn phiên bản đã khai báo; LOI_MT p41/p42_gd14 như cũ).
