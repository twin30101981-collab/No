# HM-30 — Lưu trữ + Trung tâm nhập dữ liệu sắp theo loại (Dư nợ / Tài sản), mới → cũ — v24.17.34 (gd26) — DAT_V3
Dựng: `python3 nguon_P05/build_p05_hm30.py` (v24.17.33 → .34). Người dùng 07/11: đủ 3 phần, mới → cũ.
- Lưu trữ: tab "💰 Dư nợ (msit80)" (đổi tên "Lưu trữ Báo cáo"; xếp theo ngày dữ liệu mới → cũ, dòng tiêu đề theo tháng, cảnh báo mốc bất thường: năm lệch xa / trùng ngày / chỉ siêu dữ liệu,
  lọc Tất cả · Có nhãn mốc · ⚠ Cần xem, nút 👁 xem tại mốc) + tab mới "🏠 Tài sản bảo đảm" (mốc TS tự lưu + bấm tay, chỉ đọc) + Hàng ngày + Lưu trữ Dữ liệu.
- Trung tâm nhập: 2 thẻ tóm tắt (Dư nợ: hiện hành, số mốc, cuối tháng thiếu; Tài sản: sao kê hiện hành, số TS, số mốc tự lưu) + lọc nhật ký Tất cả/Dư nợ/Tài sản; nhật ký xếp theo Ngày DL mới → cũ.
- An toàn: chỉ đổi thứ tự hiển thị; xoá / gắn nhãn / đổi tên dùng nguyên chỉ số gốc (có ca kiểm bấm xoá và gắn nhãn đúng mốc sau khi sắp lại). App không tự xoá mốc nào.
Kiểm V3 `kiem_thu_p05/test_hm30_luu_tru_loai.py`: **32 PASS · 0 FAIL** (desktop + điện thoại; thêm 2 mốc lỗi giả: năm 2006 và trùng ngày).
Lỗi tìm thấy khi làm: mở CSDL TSBD khi chưa có sẽ TẠO CSDL rỗng → đã huỷ nâng cấp (giống zv()) để không làm hỏng luồng nhập TS.
