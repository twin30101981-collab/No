# HM-21 (+ yêu cầu dropdown 06/11) — v24.17.27 — DAT_V3
Dựng: `cd app/QLTDPRO_P43 && python3 nguon_P05/build_p05_hm21.py` (v24.17.26 → v24.17.27; sw.js/manifest 24.17.27).

## Làm gì
- Lớp mới **gd24** (`nguon_P05/gd24.js`, chạy trước bundle): `window.QLTDCB.cmp` so 2 tên cán bộ hoặc phòng theo **đúng danh mục mà tab Báo cáo ngày dùng**
  (Hội Sở → PGD HBT → PGD Số 2, trong phòng theo danh mục; chưa khai báo thì theo thứ tự app tự học). Bundle ghi danh mục Báo cáo ngày vào `window.__qltdRosterBC`.
  Tên không có trong danh mục xếp sau (theo chữ cái), "(chưa có …)" xếp cuối. `QLTDCB.cuMoi` sắp ngày cũ → mới.
- Đã áp ở: ô chọn Phòng/Cán bộ dùng chung (Tất cả dư nợ, Ngắn hạn, Trung-dài hạn, Cảnh báo sớm, Nợ đến hạn, Lãi đọng, Chuyển HM, Giải ngân);
  "Gom Phòng → Cán bộ" của bảng dữ liệu; Chuyển hạn mức; Tổng quan (ô lọc Phòng/Cán bộ, ô Top KH, bảng chéo Phòng → Cán bộ, bảng Tăng/giảm, Excel bảng chéo);
  Trả nợ/xuất TS; Giải ngân (Thêm món thủ công); Tài sản bảo đảm (ô lọc + 2 tab gd23); Khách hàng mới (bảng, danh sách chi tiết, gd15 Đối soát + ô lọc + Excel).
- Ngày cũ → mới: các bảng dữ liệu vốn đã mặc định cũ → mới (đã kiểm). Sửa thêm: danh sách chi tiết khi bấm số ở Đối soát KH mới (trước: theo số tiền giảm dần),
  danh sách TS ở gd23 (trước: theo thứ tự tệp), danh sách khế ước KH mới (trong cán bộ theo ngày GN).
- **gd24-css** (người dùng 06/11): mọi `<select>` có chữ xanh đậm #0b3a6e, nền #f5f9ff, viền rõ, đổ bóng nhẹ; rê chuột thì nổi hơn; ô lọc đang chọn khác "Tất cả" chuyển màu hổ phách.
  Không đổi kích thước (cao 34 px như cũ).
- Giữ theo số tiền (có chủ đích): các bảng XẾP HẠNG (cột #, Top KH, "CBTD (top 8)", Excel "Theo CBTD"). Giữ mới → cũ: Lưu trữ, nhật ký Nhập (chờ người dùng quyết).

## Kiểm chứng V3 — `python3 kiem_thu_p05/test_hm21_thu_tu_cb.py`
Dữ liệu thử ẩn danh. Kịch bản A: danh mục cán bộ khai báo theo thứ tự KHÁC bảng chữ cái (desktop 1366 + điện thoại 390). Kịch bản B: chưa khai báo, so với chính tab Báo cáo ngày.
- v24.17.27: **35 PASS · 0 FAIL** (log/test_hm21_tren_v24.17.27.log)
- v24.17.26 (trước sửa): 11 PASS · 24 FAIL (log/test_hm21_tren_v24.17.26_TRUOC_SUA.log)
- Ảnh: anh/QLTDPRO_v24.17.27/*.png
## Hồi quy chung
- Trước (v24.17.26): 950 PASS · 0 FAIL (5 bộ KHONG_CHAY vì ZIP không kèm bản cũ làm đối chứng; LOI_MT p41/p42_gd14 như cũ).
- Sau (v24.17.27): **1373 PASS · 0 FAIL** (27 bộ, gồm p05_hm21 35/0; LỆCH PB 12 = ca nhãn phiên bản đã khai báo; LOI_MT p41/p42_gd14 như cũ). log/hoi_quy_sau_v24.17.27.log
