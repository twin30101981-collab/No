# HM-09 — Hiệu năng trang Chỉ tiêu kế hoạch — v24.17.41 — 07/11/2026

## Cách đo (kiem_thu_p06/do_hieu_nang_ctkh.py)
Playwright + CDP Profiler (lấy mẫu 200 µs), nạp **12 mốc msit80 thật** (31/12/2025 → 31/10/2026 + 05/11/2026, ~3.900 dòng/mốc ≈ 47.000 dòng), rồi 13 thao tác: mở trang, 4 tab, Báo cáo ngày, xác nhận 9 bàn giao, đổi phạm vi, áp mẫu/sửa kế hoạch quý, quay lại TỔNG QUAN. Máy kiểm thử (container) — máy văn phòng thường chậm hơn 2–4 lần, nên số giây thực tế lớn hơn tương ứng.

## Điểm nghẽn tìm thấy (v24.17.40, tổng 4,10 s CPU)
| Hàm | Thời gian tự thân | Nguyên nhân |
|---|---|---|
| `norm` (gd28) | 0,67 s | chuẩn hoá tên (NFD) cho mọi dòng của 12 mốc ở mỗi lần vẽ; chỉ ~20 tên khác nhau |
| `gr` (bundle) | 0,55 s | như trên, trong `Qv`/`ap` của Báo cáo ngày |
| quét dòng gd28 (`mkNm`, `cbKH`, cảnh báo tên, danh sách cán bộ) | ~0,6 s | dựng lại ngữ cảnh sổ bàn giao mỗi lần vẽ |
| `Qv` | 0,10 s | quét MỌI mốc lưu trữ dù chỉ dùng 3 mốc |
| P3 ×2 | — | Báo cáo ngày tính 2 lần (tính lại + thô) kể cả khi sổ trống |

## Sửa (nguon_P06/build_p06_hm09.py + gd28.js) — kết quả tính không đổi
1. Bộ nhớ đệm chuẩn hoá tên cho `gr` (bundle) và `norm` (gd28).
2. `Qv` chỉ quét dữ liệu hiện hành + 3 mốc Đầu năm/quý/tháng.
3. Bỏ lần tính "thô" khi sổ trống hoặc đang ở chế độ cách cũ.
4. Ngữ cảnh sổ bàn giao, gợi ý, cảnh báo tên, danh sách cán bộ: dùng lại khi dữ liệu và sổ không đổi.

## Kết quả (giây, cùng máy, cùng dữ liệu)
| Thao tác | v24.17.40 | v24.17.41 |
|---|---|---|
| Mở trang (TỔNG QUAN) | 0,40 | 0,35 |
| Tab THEO CBTD / PHÒNG / LOẠI VAY | 0,30 / 0,16 / 0,18 | 0,36 / 0,12 / 0,13 |
| Tab BÁO CÁO NGÀY | 0,48 | 0,18 |
| Xác nhận 9 bàn giao | 0,42 | 0,17 |
| Đổi phạm vi → DN / → Tất cả | 0,28 / 0,37 | 0,09 / 0,06 |
| Chuyển tab DƯ NỢ | 0,18 | 0,07 |
| Áp mẫu kế hoạch / sửa 1 ô | 0,44 / 0,48 | 0,14 / 0,14 |
| Quay lại TỔNG QUAN | 0,23 | 0,15 |
| **Tổng CPU** | **4,10 s** | **2,10 s** |
Còn lại chủ yếu là vẽ giao diện (program/idle) và `Kd` (tính chỉ tiêu theo mốc cho tab TỔNG QUAN/THEO CBTD) — chưa cần tối ưu thêm.
