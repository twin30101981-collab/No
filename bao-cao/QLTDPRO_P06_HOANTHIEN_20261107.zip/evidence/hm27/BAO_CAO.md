# HM-27 — Đổi tên "Doanh nghiệp" + trang "Thấu chi" tách khỏi "Ngắn hạn" — v24.17.31 — DAT_V3
Dựng: `python3 nguon_P05/build_p05_hm27.py` (v24.17.30 → .31).
## Làm (người dùng 07/11)
1. Trang "Cho vay doanh nghiệp" → **"Doanh nghiệp"** (menu, tiêu đề trang, tên tệp Excel `Doanh_nghiep_…`). Slug cũ giữ nguyên (`#/cho-vay-doanh-nghiep`), thêm alias tìm kiếm "cho-vay-doanh-nghiep".
2. Trang mới **"Thấu chi"** (`#/thau-chi`), cùng khung trang Ngắn hạn: ô Phòng/Cán bộ, thẻ, bảng dòng (lọc cột, Gom Phòng → Cán bộ, Xuất Excel `Thau_chi_…`), sắp mặc định Cán bộ ↑ rồi Ngày GN ↑.
3. **Tách thấu chi khỏi Ngắn hạn**: trang Ngắn hạn (đổi tên "Ngắn hạn", hết "+ thấu chi") không còn dòng thấu chi; ghi chú ở hai trang. Phân loại dùng đúng quy tắc sẵn có của gi() — nhãn loại vay khớp /thấu\s*chi/i — nên Ngắn hạn(mới) + Thấu chi = Ngắn hạn(cũ), không dòng nào rơi mất / trùng.
## An toàn
- Số đếm menu của cả 3 trang lấy từ cùng hàm badges (sb) với phần "Đối soát số liệu" (so số hiển thị với số tính lại) ⇒ Đối soát tự kiểm cả trang mới; kết quả 14/14.
- KHÔNG đổi: bảng tổng hợp Tổng quan / Chỉ tiêu kế hoạch / Báo cáo / Xu hướng (vốn đã có cột "Thấu chi" riêng); Tổng quan vẫn drill "Ngắn hạn + thấu chi" (đúng nghĩa ở đó).
- Bố cục bảng người dùng đã lưu của trang Ngắn hạn giữ nguyên (slug/khóa bố cục không đổi).
## Kiểm chứng V3 — `python3 kiem_thu_p05/test_hm27_thau_chi.py`
Dữ liệu thử ẩn danh (dữ liệu gốc không có thấu chi → đổi 40 dòng còn dư nợ sang loại vay OD), đáp án Python độc lập, desktop + điện thoại:
- v24.17.31: **28 PASS · 0 FAIL** — tên menu; số đếm Ngắn hạn/Thấu chi/Trung-dài = Python; Ngắn + Thấu chi = ngắn cũ; + Trung-dài = Tất cả dư nợ; Đối soát 14/14; trang Ngắn hạn không còn thấu chi; trang Thấu chi 40 dòng, Tổng dư nợ 18.876.415.000 đ, mọi phòng khớp; sắp mặc định; Excel; Tổng quan dòng Thấu chi không đổi; không tràn ngang; 0 pageerror.
- v24.17.30 (trước): xem log/test_hm27_tren_v24.17.30_TRUOC.log
- Lưu ý: dữ liệu thật 04/11/2026 (đã xoá khỏi máy) chưa chạy lại cho thay đổi này — cần nạp 1 tệp thật để xem số thấu chi thật.
