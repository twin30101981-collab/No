# HM-07 — Bỏ thăm dò mẫu .docx (templates/) khi mở app — v24.17.37 — DAT_V3 — 07/11/2026

## Kết luận nơi chứa mẫu (người dùng xác nhận 07/11 — Q27)
83 mẫu hồ sơ .docx nằm trên máy người dùng, nạp bằng **📚 Bộ hồ sơ → 📁 Nạp thư mục mẫu… / 📄 Nạp tệp .docx** vào kho IndexedDB `QLTDProMauHsvx` của trình duyệt. App được mở bằng tệp .html trực tiếp (file://). Không có thư mục templates/ trên máy chủ.

## Nguyên nhân
Khối `<script>` "nạp sẵn 83 mẫu hồ sơ" chạy mỗi lần mở app: mở CSDL `QLTDProMauHsvx` (tạo rỗng nếu chưa có) rồi gọi `__gd9TplFetch` → HEAD `templates/…` (HM-01 đã giảm 83 → 1 lượt, lưu cờ `gd9_tplok`).
- http: 1 yêu cầu 404 + 1 lỗi console mỗi trình duyệt/hồ sơ mới; file://: 2 lỗi console (chặn CORS + ERR_FAILED).
- Cờ `gd9_tplok=0` khoá vĩnh viễn; kho mẫu rỗng được tạo dù người dùng chưa từng dùng Bộ hồ sơ.

## Sửa (nguon_P06/build_p06_hm07.py)
- Bỏ hẳn khối tự tải templates/ (7.037 ký tự; vá có đếm, khẳng định không còn lời gọi `__gd9TplFetch`). Kho mẫu chỉ tạo khi mở Bộ hồ sơ.
- Lỗi "chưa nạp mẫu" (2 chỗ) → "chưa nạp mẫu — mở 📚 Bộ hồ sơ, bấm 📁 Nạp thư mục mẫu…". Nút ⬇ Xuất của mẫu chưa nạp vốn đã khoá.
- Không đổi luồng nạp mẫu, CSP, dữ liệu đã nạp.

## Kiểm chứng V3 — kiem_thu_p06/test_hm07_mau.py (mẫu thử tự sinh, không dùng mẫu thật)
- v24.17.37: **9 PASS · 0 FAIL** — file:// và http, mở 2 lần: 0 yêu cầu templates/, 0 lỗi console, không tạo kho mẫu rỗng; Bộ hồ sơ "Đã nạp 0/40", nút Xuất khoá; nạp thư mục 3 mẫu thử (3 sản phẩm) → "Đã nạp 3 mẫu", ô đếm 1/40, 1 nút Xuất mở; F5 vẫn còn 3 mẫu; 0 lỗi trang.
- v24.17.36 (trước sửa): 5 PASS · 4 FAIL — file:// lần 1: 1 yêu cầu + 2 lỗi console; http lần 1: 1 yêu cầu 404 + 1 lỗi console; lần 2: kho mẫu rỗng đã bị tạo.
