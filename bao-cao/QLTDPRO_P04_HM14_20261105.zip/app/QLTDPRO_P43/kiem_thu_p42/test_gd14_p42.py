# Kiểm thử gd14 P42 (Playwright Chromium) trên v24.14.0:
# A. cột lãi dự thu + công cụ tất toán (kế thừa P41, chạy lại trên bản mới)
# B. nguồn thư mục qua OPFS (kế thừa P41, chạy lại trên bản mới)
# C. cột "Nguồn" của bảng kế hoạch (mới P42)
# D. quét thư mục con tuỳ chọn (mới P42 — Q4)
# Chạy: python3 kiem_thu_p42/test_gd14_p42.py (cổng 8825)
import asyncio, functools, http.server, threading, base64, re, sys, io, zipfile
from pathlib import Path
from playwright.async_api import async_playwright
ROOT = Path(__file__).resolve().parent.parent; HERE = Path(__file__).resolve().parent
X = ROOT / 'app' / 'kiem_thu_p40' / 'xlsx'; Z = ROOT / 'app' / 'kiem_thu_p40' / 'zip'
PORT = 8825; URL = f'http://127.0.0.1:{PORT}/QLTDPRO_v24.14.0.html'
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:400]))

# ── fixture zip cho ca C (tạo bằng Python, nội dung = xlsx thật) ──
def mkzip(path, mapping, inner=None):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        for n, src in mapping.items(): z.writestr(n, src.read_bytes())
    return buf.getvalue()

GUI1 = HERE / 'zip' / 'gui_msit.zip'          # zip 1 tệp msit80
NGOAI = HERE / 'zip' / 'ngoai.zip'            # zip lồng zip lồng xlsx
(GUI1.parent.mkdir(parents=True, exist_ok=True))
GUI1.write_bytes(mkzip(None, {'gui_msit_31-10-2026.xlsx': X / 'msit80_31-10-2026.xlsx'}))
buf = io.BytesIO()
with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
    z.writestr('trong.zip', mkzip(None, {'trong_30-09-2026.xlsx': X / 'msit80_30-09-2026.xlsx'}))
NGOAI.write_bytes(buf.getvalue())

class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
httpd = http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / 'app'))); threading.Thread(target=httpd.serve_forever, daemon=True).start()

STUB = """
window.showDirectoryPicker = function () {
  if (window.__testDirHandle) return Promise.resolve(window.__testDirHandle);
  return Promise.reject(new DOMException('no dir', 'AbortError'));
};
"""

async def newpage(p, stub=True):
    b = await p.chromium.launch(headless=True); ctx = await b.new_context(viewport={'width': 1366, 'height': 900}, locale='vi-VN')
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    if stub: await ctx.add_init_script(STUB)
    pg = await ctx.new_page(); pg.errs = []; pg.on('pageerror', lambda e: pg.errs.append(str(e)))
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500); return b, pg

async def put(pg, files, wait=2500):
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in files]); await pg.wait_for_timeout(wait)

async def do_import(pg):
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(4500)

async def plan_rows(pg):
    t = pg.locator('[data-testid="plan"] tbody tr'); return await t.count()

async def nguon_texts(pg):
    return [t.strip() for t in await pg.locator('[data-testid="nguon"]').all_inner_texts()]

async def main():
    async with async_playwright() as p:
        # ── A. trang Lãi đọng: cột + công cụ (chạy lại trên v24.14.0) ──
        b, pg = await newpage(p, stub=False)
        try:
            await put(pg, [X / 'msit80_31-10-2026.xlsx']); await do_import(pg)
            await pg.goto(URL + '#/lai-dong', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
            body = await pg.inner_text('body')
            ok('A1 vào được trang Lãi đọng', 'page-lai-dong' in (await pg.content()) and ('Lãi đọng' in body), body[:200])
            ok('A2 có cột "Lãi dự thu đến chốt"', 'Lãi dự thu đến chốt' in body)
            ok('A3 có nút công cụ + ô ngày chốt + Σ', await pg.locator('[data-testid="gd14-tool"]').count() == 1 and await pg.locator('[data-testid="gd14-chot"]').count() == 1 and 'Σ lãi dự thu:' in body, body[:300])
            ok('A4 module nạp: QLTDLai + GD14 (P42)', await pg.evaluate("!!window.QLTDLai && !!window.GD14 && window.GD14.PHIEN_BAN === 'P42-GD14 1.0.0'"))
            ok('A5 vector chứng từ Vân Anh trong trình duyệt = 219.178', await pg.evaluate("window.QLTDLai.tinhLaiKhoan({6:'2026-04-15',7:'2026-04-17',8:8,11:500000000,23:''},{chot:'2026-04-17'}).tong") == 219178)
            await pg.fill('[data-testid="gd14-chot"]', '2026-10-31'); await pg.wait_for_timeout(600)
            t2 = await pg.locator('[data-testid="gd14-tong-duthu"]').inner_text()
            ok('A6 Σ lãi dự thu là số tiền', re.match(r'^Σ lãi dự thu: [\d.]+( đ)?$', t2.strip()) is not None, t2)
            await pg.fill('[data-testid="gd14-chot"]', '2025-10-31'); await pg.wait_for_timeout(600)
            t3 = await pg.locator('[data-testid="gd14-tong-duthu"]').inner_text()
            ok('A7 đổi ngày chốt → Σ đổi', t3 != t2, (t2, t3))
            await pg.fill('[data-testid="gd14-chot"]', '2026-11-03'); await pg.wait_for_timeout(600)
            await pg.click('[data-testid="gd14-tool"]'); await pg.wait_for_timeout(500)
            first = (await pg.locator('[data-testid="gd14-tool-row"]').first.inner_text()).split('·')[0].strip()
            await pg.fill('[data-testid="gd14-tool-search"]', first[:5]); await pg.wait_for_timeout(500)
            rows = await pg.locator('[data-testid="gd14-tool-row"]').count()
            ok('A8 công cụ lọc theo tên KH ("' + first[:10] + '…")', rows >= 1 and first[:5] in (await pg.locator('[data-testid="gd14-tool-row"]').first.inner_text()), (first, rows))
            await pg.locator('[data-testid="gd14-tool-row"]').first.click(); await pg.wait_for_timeout(500)
            rt = await pg.locator('[data-testid="gd14-tool-result"]').inner_text()
            ok('A9 kết quả có phân rã trong hạn/quá hạn + công thức', ('Lãi trong hạn' in rt and 'Quá hạn' in rt and 'TỔNG LÃI' in rt and '×' in rt), rt[:300])
            await pg.check('[data-testid="gd14-tool-chamtra"]'); await pg.wait_for_timeout(500)
            rt2 = await pg.locator('[data-testid="gd14-tool-result"]').inner_text()
            ok('A10 bật lãi chậm trả → dòng tách riêng (HM-14/Q12: ngắn hạn → ghi "không tính lãi chậm trả")', 'Chậm trả' in rt2 or 'không tính lãi chậm trả (Q12)' in rt2, rt2[:300])
            await pg.click('[data-testid="gd14-tool-close"]'); await pg.wait_for_timeout(300)
            ok('A11 đóng công cụ', await pg.locator('[data-testid="gd14-tool-overlay"]').count() == 0 and await pg.locator('[data-testid="gd14-tool"]').count() == 1)
            ok('A12 không lỗi JS (A)', not pg.errs, pg.errs)
        finally: await b.close()

        # ── C. cột "Nguồn" ──
        b, pg = await newpage(p, stub=True)
        try:
            await put(pg, [X / 'msit80_31-10-2026.xlsx'])
            ng = await nguon_texts(pg)
            ok('C1 tệp chọn tay → Nguồn "Chọn tệp / Kéo thả"', ng == ['Chọn tệp / Kéo thả'], ng)
            await put(pg, [Z / 'ok_3tep.zip'])
            ng = await nguon_texts(pg)
            ok('C2 tệp trong zip → Nguồn "ZIP: ok_3tep.zip" (tệp 31-10 trùng tên+kích thước với tệp chọn tay nên bị lọc khỏi kế hoạch)', len(ng) == 3 and ng.count('ZIP: ok_3tep.zip') == 2 and 'Chọn tệp / Kéo thả' in ng, ng)
            await put(pg, [NGOAI])
            ng = await nguon_texts(pg)
            ok('C3 zip lồng zip → Nguồn đủ chuỗi "ngoai.zip › trong.zip"', len(ng) == 4 and 'ngoai.zip' in ng[-1] and '› trong.zip' in ng[-1], ng)
            # nguồn qua thư mục
            b64 = base64.b64encode((X / 'msit80_31-10-2026.xlsx').read_bytes()).decode()
            b64z = base64.b64encode(GUI1.read_bytes()).decode()
            await pg.evaluate("""async ([b64, b64z]) => {
              const root = await navigator.storage.getDirectory();
              const dir = await root.getDirectoryHandle('ipcas_nguon_c', {create: true});
              const w1 = await (await dir.getFileHandle('msit80_31-10-2026.xlsx', {create: true})).createWritable();
              await w1.write(Uint8Array.from(atob(b64), c => c.charCodeAt(0))); await w1.close();
              const w2 = await (await dir.getFileHandle('gui_msit.zip', {create: true})).createWritable();
              await w2.write(Uint8Array.from(atob(b64z), c => c.charCodeAt(0))); await w2.close();
              window.__testDirHandle = dir; return true;
            }""", [b64, b64z])
            await pg.evaluate("window.GD14.folder.STABLE_MS = 0")
            await pg.click('[data-testid="gd14-folder-pick"]'); await pg.wait_for_timeout(3500)
            ng = await nguon_texts(pg)
            ok('C4 tệp từ thư mục → Nguồn có nhãn "Thư mục IPCAS"', any(g.startswith('Thư mục IPCAS') for g in ng), ng)
            ok('C5 zip trong thư mục → Nguồn "Thư mục IPCAS › ZIP: gui_msit.zip"', 'Thư mục IPCAS › ZIP: gui_msit.zip' in ng, ng)
            ok('C6 cột Nguồn có tiêu đề trong bảng', 'NGUỒN' in (await pg.locator('[data-testid="plan"] thead').inner_text()).upper())
            await do_import(pg)
            ng = await nguon_texts(pg)
            ok('C7 dòng đã nhập vẫn giữ Nguồn', 'Thư mục IPCAS › ZIP: gui_msit.zip' in ng and any(g.startswith('Thư mục IPCAS') for g in ng), ng)
            ok('C8 không lỗi JS (C)', not pg.errs, pg.errs)
        finally: await b.close()

        # ── D. quét thư mục con (Q4) ──
        b, pg = await newpage(p, stub=True)
        try:
            b64a = base64.b64encode((X / 'msit80_31-10-2026.xlsx').read_bytes()).decode()
            b64b = base64.b64encode((X / 'msit80_30-09-2026.xlsx').read_bytes()).decode()
            b64c = base64.b64encode((X / '18_08_2026-TS.xlsx').read_bytes()).decode()
            await pg.evaluate("""async ([b64a, b64b, b64c]) => {
              const root = await navigator.storage.getDirectory();
              const dir = await root.getDirectoryHandle('ipcas_con', {create: true});
              const w1 = await (await dir.getFileHandle('goc_31-10-2026.xlsx', {create: true})).createWritable();
              await w1.write(Uint8Array.from(atob(b64a), c => c.charCodeAt(0))); await w1.close();
              const sub = await dir.getDirectoryHandle('T08_2026', {create: true});
              const w2 = await (await sub.getFileHandle('con_30-09-2026.xlsx', {create: true})).createWritable();
              await w2.write(Uint8Array.from(atob(b64b), c => c.charCodeAt(0))); await w2.close();
              const an = await dir.getDirectoryHandle('.an', {create: true});
              const w3 = await (await an.getFileHandle('an_18-08-2026-TS.xlsx', {create: true})).createWritable();
              await w3.write(Uint8Array.from(atob(b64c), c => c.charCodeAt(0))); await w3.close();
              window.__testDirHandle = dir; return true;
            }""", [b64a, b64b, b64c])
            await pg.evaluate("window.GD14.folder.STABLE_MS = 0")
            await pg.click('[data-testid="gd14-folder-pick"]'); await pg.wait_for_timeout(3500)
            st = await pg.locator('[data-testid="gd14-folder-status"]').inner_text()
            n1 = await plan_rows(pg)
            ok('D1 mặc định mức 1: chỉ đề xuất tệp thư mục gốc', 'đề xuất 1 tệp mới' in st and n1 == 1, (st, n1))
            await pg.check('[data-testid="gd14-folder-sub"]'); await pg.wait_for_timeout(500)
            st = await pg.locator('[data-testid="gd14-folder-status"]').inner_text()
            ok('D2 ghi nhận bật thư mục con', 'thư mục con' in st, st)
            await pg.click('[data-testid="gd14-folder-scan"]'); await pg.wait_for_timeout(3500)
            st = await pg.locator('[data-testid="gd14-folder-status"]').inner_text()
            n2 = await plan_rows(pg)
            ok('D3 bật thư mục con → quét nhận tệp trong T08_2026', 'đề xuất 1 tệp mới' in st and n2 == 2, (st, n2))
            ok('D4 bỏ qua thư mục ẩn ".an"', 'an_18-08-2026-TS.xlsx' not in st and n2 == 2, (st, n2))
            ok('D5 tệp thư mục con vào bảng kế hoạch', 'con_30-09-2026.xlsx' in (await pg.locator('[data-testid="plan"]').inner_text()))
            ngd = await nguon_texts(pg)
            ok('D5b tệp thư mục con có nhãn nguồn "Thư mục IPCAS › T08_2026"', 'Thư mục IPCAS › T08_2026' in ngd, ngd)
            # tải lại trang: tuỳ chọn + handle giữ nguyên
            await pg.reload(wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
            ok('D6 sau tải lại vẫn giữ tuỳ chọn thư mục con', await pg.locator('[data-testid="gd14-folder-sub"]').is_checked())
            ok('D7 sau tải lại vẫn giữ thư mục', 'Quét ngay' in (await pg.locator('[data-testid="gd14-folder"]').inner_text()))
            await pg.evaluate("window.GD14.folder.STABLE_MS = 0")
            await pg.click('[data-testid="gd14-folder-repropose"]'); await pg.wait_for_timeout(3500)
            n3 = await plan_rows(pg)
            ok('D8 "Đưa lại tất cả tệp" với thư mục con: cả tệp gốc lẫn tệp con', n3 == 2, n3)
            # tệp trùng tên ở thư mục khác không bị khoá seen chặn
            await pg.evaluate("""async () => {
              const root = await navigator.storage.getDirectory();
              const dir = await root.getDirectoryHandle('ipcas_con');
              const sub2 = await dir.getDirectoryHandle('T09_2026', {create: true});
              const src = await dir.getFileHandle('goc_31-10-2026.xlsx');
              const f = await src.getFile(); const w = await (await sub2.getFileHandle('goc_31-10-2026.xlsx', {create: true})).createWritable();
              await w.write(await f.arrayBuffer()); await w.close(); return true;
            }""")
            await pg.evaluate("window.GD14.folder.STABLE_MS = 0")
            await pg.click('[data-testid="gd14-folder-scan"]'); await pg.wait_for_timeout(3500)
            st = await pg.locator('[data-testid="gd14-folder-status"]').inner_text()
            n4 = await plan_rows(pg)
            ok('D9 tệp mới thêm vào thư mục con sau khi đã quét vẫn được nhận (không bị khoá seen chặn)', 'đề xuất 1 tệp mới' in st and n4 == 2, (st, n4))
            ok('D10 không lỗi JS (D)', not pg.errs, pg.errs)
        finally: await b.close()

        # ── B. nguồn thư mục: hồi quy ca P41 trên v24.14.0 ──
        b, pg = await newpage(p, stub=True)
        try:
            body = await pg.inner_text('body')
            ok('B1 có thẻ nguồn thư mục', 'Nguồn thư mục IPCAS' in body and await pg.locator('[data-testid="gd14-folder"]').count() == 1, body[:200])
            b64 = base64.b64encode((X / 'msit80_31-10-2026.xlsx').read_bytes()).decode()
            ok('B2 nạp thư mục OPFS: 1 tệp thật + rác ~$', await pg.evaluate("""async (b64) => {
              const root = await navigator.storage.getDirectory();
              const dir = await root.getDirectoryHandle('ipcas_gui', {create: true});
              const w1 = await (await dir.getFileHandle('msit80_31-10-2026.xlsx', {create: true})).createWritable();
              await w1.write(Uint8Array.from(atob(b64), c => c.charCodeAt(0))); await w1.close();
              const w2 = await (await dir.getFileHandle('~$tam.xlsx', {create: true})).createWritable();
              await w2.write(new Uint8Array(10)); await w2.close();
              window.__testDirHandle = dir; return true;
            }""", b64))
            await pg.evaluate("window.GD14.folder.STABLE_MS = 0")
            await pg.click('[data-testid="gd14-folder-pick"]'); await pg.wait_for_timeout(3500)
            st = await pg.locator('[data-testid="gd14-folder-status"]').inner_text()
            ok('B3 đề xuất 1 tệp mới (bỏ ~$)', 'đề xuất 1 tệp mới' in st, st)
            b642 = base64.b64encode((X / 'msit80_30-09-2026.xlsx').read_bytes()).decode()
            await pg.evaluate("""async (b64) => {
              const dir = window.__testDirHandle;
              const w = await (await dir.getFileHandle('msit80_30-09-2026.xlsx', {create: true})).createWritable();
              await w.write(Uint8Array.from(atob(b64), c => c.charCodeAt(0))); await w.close();
            }""", b642)
            await pg.click('[data-testid="gd14-folder-scan"]'); await pg.wait_for_timeout(3500)
            ok('B4 quét lại nhận tệp mới, không chọn lại thư mục', await plan_rows(pg) == 2, await plan_rows(pg))
            await pg.click('[data-testid="gd14-folder-scan"]'); await pg.wait_for_timeout(2500)
            st3 = await pg.locator('[data-testid="gd14-folder-status"]').inner_text()
            ok('B5 quét lại lần nữa → không có tệp mới', 'không có tệp mới' in st3, st3)
            await pg.check('[data-testid="gd14-folder-auto"]'); await pg.wait_for_timeout(800)
            ok('B6 bật Tự nhập được ghi nhận', 'Tự nhập' in (await pg.locator('[data-testid="gd14-folder-status"]').inner_text()))
            await pg.reload(wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
            ok('B7 sau tải lại vẫn giữ thư mục + chế độ Tự nhập', await pg.locator('[data-testid="gd14-folder-auto"]').is_checked(), 'auto checkbox')
            await pg.evaluate("window.GD14.folder.STABLE_MS = 0")
            await pg.click('[data-testid="gd14-folder-repropose"]'); await pg.wait_for_timeout(3500)
            ok('B8 "Đưa lại tất cả tệp" đề xuất lại cả 2 tệp', await plan_rows(pg) == 2, await plan_rows(pg))
            await pg.click('[data-testid="gd14-folder-forget"]'); await pg.wait_for_timeout(800)
            ok('B9 bỏ thư mục → về trạng thái chưa chọn', 'Chưa chọn thư mục' in (await pg.locator('[data-testid="gd14-folder-status"]').inner_text()))
            ok('B10 CSDL riêng QLTDProFolder_v1 tồn tại, không chạm CSDL cũ', await pg.evaluate("indexedDB.databases ? indexedDB.databases().then(l => l.some(d => d.name === 'QLTDProFolder_v1')) : true"))
            ok('B11 không lỗi JS (B)', not pg.errs, pg.errs)
        finally: await b.close()

    print('\n' + str(sum(res)) + '/' + str(len(res)) + ' ca đạt')
    if sum(res) != len(res): sys.exit(1)

asyncio.run(main())
