# BÀN GIAO CUỐI PHIÊN P06 — QLTDPRO v24.17.45 — 07/11/2026
**Bản hiện hành: app/QLTDPRO_P43/app/QLTDPRO_v24.17.45.html** (sw.js/manifest 24.17.45). **Hồi quy tổng cuối (chạy bằng Opus): 1788 PASS · 0 FAIL** (50 bộ: 41 PASS, 7 LỆCH PB đã khai báo, 2 LOI_MT p41/p42_gd14 môi trường Chromium; SKIP 7). Log: evidence/hoi_quy/hoi_quy_v24.17.45.log.
**Đọc trước: handover/TRIEN_KHAI_PHIEN_P07.md** (trạng thái, việc đầu phiên, lệnh, chuỗi dựng, quy tắc đã chốt, rủi ro).
v24.17.45: trang Chỉ tiêu KH → BÁO CÁO NGÀY xếp: thanh phạm vi/kiểm tổng → BẢNG BÁO CÁO → Kế hoạch quý + Xuất 4 bảng/Đối soát → Sổ bàn giao (cuối); bộ kiểm p06_hm32 13/13.

v24.17.44 thêm: cột mốc Chỉ tiêu KH + Excel Xu hướng kỳ xếp kỳ mới nhất trước (bộ kiểm p06_hm32 12/12).

# BÀN GIAO — QLTDPRO — P06 · v24.17.43 (hiệu năng, bố cục PC/laptop, đối soát 05/11) — 07/11/2026
**Bản hiện hành: app/QLTDPRO_P43/app/QLTDPRO_v24.17.43.html** (sw.js/manifest 24.17.43). **Hồi quy v24.17.43: 1786 PASS · 0 FAIL** (41 bộ; LỆCH PB 12, LOI_MT p41/p42_gd14, SKIP 7 như cũ). Log: evidence/hoi_quy/hoi_quy_v24.17.43.log.
- **Đối soát 05/11/2026** (tệp msit80 05/11 là đúng nguồn bảng in 5/11): DN 88/88; trung+dài 73/88; dư nợ 71/88; KH 70/88; Đầu tháng + Ngày BC khớp tuyệt đối (evidence/hm31/BAO_CAO.md mục CHỐT 05/11; chot_05_11/ket_qua.json). Kịch bản kiem_thu_p06/chot_doi_soat_3110.py (QLTD_FILES/QLTD_NGAY chọn ngày khác).
- **HM-09 hiệu năng (v24.17.41)**: đo CDP trên 12 mốc thật; tổng CPU 13 thao tác 4,10 s → 2,10 s (evidence/hm09/BAO_CAO.md; kiem_thu_p06/do_hieu_nang_ctkh.py). Điểm nghẽn: chuẩn hoá tên lặp (gr/norm), Qv quét mọi mốc, Báo cáo ngày tính 2 lần, dựng lại ngữ cảnh sổ bàn giao.
- **v24.17.42**: trang Chỉ tiêu KH mặc định tab BÁO CÁO NGÀY; "Kế hoạch quý" trên "Sổ bàn giao"; hiệu lực bàn giao có thể SAU ngày mốc gợi ý (Lưu trữ có mốc 30/09 thực chất đã sau bàn giao).
- **v24.17.43**: cột tiền (Dư nợ; HMTD; Dư nợ đầu năm/hiện tại/Giảm) nằm trong màn hình đầu ở 1280/1366/1920 px, bố cục lưu cũ đổi 1 lần; ô đậm nhất ma trận Loại vay × Nhóm nợ không còn trùng màu tiêu đề; Xu hướng kỳ: mới nhất lên đầu; TSBĐ: lời nhắn rõ msit80 không chứa TSBĐ (trang trống khi chỉ có msit80 là đúng thiết kế, đã kiểm trên số thật). Chi tiết: evidence/p06b/BAO_CAO.md.
- Dựng: build_p06_hm09.py (v40→41, dùng gd28_v40.js), build_p06_hm31f.py (v41→42, gd28_v41.js→gd28.js), build_p06_hm32.py (v42→43).
Việc kế: (hỏi người dùng) đảo thứ tự mốc mới → cũ ở các cột mốc Chỉ tiêu KH/Báo cáo ngày?; nhập danh sách khách lẻ vào sổ; HM-08 → HM-10.

# BÀN GIAO — QLTDPRO — P06 · CHỐT ĐỐI SOÁT CHUẨN 31/10/2026 (tiến độ) — 07/11/2026
**Bản hiện hành không đổi: v24.17.40** (hồi quy 1775 PASS · 0 FAIL). Phiên này chỉ thêm kịch bản `kiem_thu_p06/chot_doi_soat_3110.py` (Playwright, chạy trên app với dữ liệu thật; không phải bộ hồi quy).
Kết quả chốt (evidence/hm31/BAO_CAO.md mục "CHỐT ĐỐI SOÁT"; evidence/hm31/chot_31_10/ket_qua.json): Doanh nghiệp 88/88 ô; Trung + dài hạn 72/88; Dư nợ 64/88; Khách hàng 63/88; Ngày BC khớp tuyệt đối 3 bảng; kiểm tổng ✓. Các ô lệch đều ở cột mốc do bản in tính tay (6 nhóm nguyên nhân đã ghi).
Người dùng giữ (có tên cán bộ, KHÔNG trong ZIP): BaoCao4Bang_31-10-2026_CHUAN.xlsx, DOI_SOAT_31-10-2026.xlsx, SoBanGiao_31-10-2026.xlsx/.json, ảnh chụp.
Việc kế: đối soát 05/11 khi có tệp; danh sách khách lẻ để nhập sổ theo mã KH; HM-08 → HM-10 → HM-09.

# BÀN GIAO — QLTDPRO — P06 · HM-31 GĐ3 + hiệu lực bàn giao 01/10 — 07/11/2026
**Bản hiện hành: app/QLTDPRO_P43/app/QLTDPRO_v24.17.40.html** (sw.js/manifest 24.17.40). **Hồi quy v24.17.40: 1775 PASS · 0 FAIL** (40 bộ; LỆCH PB 12, LOI_MT p41/p42_gd14, SKIP 7 như cũ). Log: evidence/hoi_quy/hoi_quy_v24.17.40.log.
HM-31 coi như HOÀN TẤT cho số liệu 31/10/2026 (GĐ1 + GĐ2 + GĐ3). Chi tiết: evidence/hm31/BAO_CAO.md (các phần GĐ1, GĐ2, GĐ2 còn lại, GĐ3, hiệu lực).

## HM-31 GĐ3 — v24.17.39 — DAT_V3 27/27 (số thật 31/10)
Kế hoạch quý theo cán bộ (nhập/dán Excel/áp mẫu; theo MÃ; chưa nhập = kế hoạch năm ÷ 4), chuyển kế hoạch theo sổ bàn giao (đồng thời cùng ngày; bảo toàn tổng; bật/tắt), % thực hiện + dự báo cuối quý, xuất Excel đúng mẫu 4 bảng, đối soát với báo cáo tay (khớp x/y ô + nguyên nhân gợi ý). Đối soát bản in 31/10: DN 36/36; trung+dài 63/76; KH 55/76; dư nợ 56/76 (ô lệch do bản in tính tay).
## Hiệu lực bàn giao — v24.17.40 — DAT_V3 9/9 (Q29: người dùng 07/11: hiệu lực từ 01/10/2026)
Ô "Ngày hiệu lực thực tế" khi xác nhận gợi ý + sửa ngày tại chỗ trong sổ; gợi ý không lặp lại (lưu `moc`). Nhập hiệu lực 01/10/2026 khi dùng app thật.
## Dựng
nguon_P06/build_p06_hm31d.py (v38→v39; dùng gd28_v39.js + gd28.css + gd29.js), build_p06_hm31e.py (v39→v40; gd28.js). Chuỗi cũ: build_p06_hm31.py/…b/…c dùng gd28_v36/v38 (đã kiểm tái hiện đúng md5).
## Bộ kiểm cần dữ liệu thật (KHÔNG có trong ZIP)
QLTD_MSIT80_DIR (31.12.2025.xlsx, 30.09.2026.XLS, 31.10.2026.XLS) cho p06_hm31/b/c/d/e; p06_hm31d cần thêm QLTD_BANIN_JSON (số báo cáo tay 31/10: kh/dn/dnn/th → {tên: [Đầu năm, Đầu quý, Đầu tháng, Ngày BC]}; người dùng giữ). Thiếu ⇒ SKIP.

## Việc kế tiếp
1. Đối soát số 05/11/2026 khi người dùng gửi tệp msit80 05/11 (tệp 04/11 KHÔNG phải nguồn của bảng in 5/11).
2. Nhập danh sách khách lẻ bản in gán khác (mã KH) vào sổ bàn giao (phạm vi mã KH) để triệt tiêu ô lệch còn lại — cần danh sách từ người dùng.
3. Kế hoạch NĂM theo mã cán bộ + % thực hiện năm; trang đối soát riêng (hiện là khối trong tab Báo cáo ngày).
4. HM-08 (hỏi lại: app mở bằng file:// nên phần PWA không có tác dụng; có thể chỉ làm "đổi phiên bản một chỗ + dọn bản cũ") → HM-10 → HM-09.

# BÀN GIAO — QLTDPRO — P06 · HM-07 + HM-31 GĐ2 (hoàn tất) — 07/11/2026
**Bản hiện hành: app/QLTDPRO_P43/app/QLTDPRO_v24.17.38.html** (sw.js/manifest 24.17.38). **Hồi quy v24.17.38: 1739 PASS · 0 FAIL** (38 bộ; LỆCH PB 12, LOI_MT p41/p42_gd14, SKIP 7 như cũ). Log: evidence/hoi_quy/hoi_quy_v24.17.38.log.

## HM-07 — v24.17.37 — DAT_V3 9/9 (evidence/hm07/BAO_CAO.md)
Bỏ tự tải 83 mẫu từ templates/ khi mở app (0 yêu cầu, 0 lỗi console ở http và file://; kho mẫu chỉ tạo khi mở Bộ hồ sơ). Mẫu nạp bằng "📚 Bộ hồ sơ → 📁 Nạp thư mục mẫu…" (Q27). Bộ kiểm p06_hm07 (mẫu thử tự sinh).

## HM-31 GĐ2 — phần còn lại — v24.17.38 — DAT_V3 36/36 + 59/59 (evidence/hm31/BAO_CAO.md)
Mã cán bộ (ofcno → r[32]); cảnh báo tên gần giống; cột Bàn giao; chọn "mốc so sánh" (đang quản lý / cách cũ); sổ có phạm vi mã KH/khế ước, ghi chú, người lập, thêm tay, Excel biên bản; áp sổ cho Chỉ tiêu KH, Tổng quan (Biến động theo cán bộ), Trả nợ. Bộ kiểm p06_hm31c; p06_hm31/hm31b cần QLTD_MSIT80_DIR.
Sửa trong hồi quy: tab Khách hàng mới hiện mã cán bộ bằng chữ <11px ⇒ thêm `table td small.text-muted-foreground{font-size:11px}`.
Quyết định thiết kế: dòng PHÒNG = Σ cán bộ (như bản in), không gom theo phòng khế ước (N8).
Đối soát bản in 31/10 (dư nợ từng cán bộ, 51 ô): thô 31/51 → sau sổ 39/51; 12 ô còn lệch do bản in không điều chỉnh Đầu năm của người cũ (6) và gán khác một số khách lẻ (6: Cao/Hoàng Anh ±1.900 tr…) ⇒ nhập vào sổ bằng phạm vi mã KH khi có danh sách.

## Việc kế tiếp
- **HM-31 GĐ3** (người dùng chốt 07/11: áp cho TOÀN chi nhánh; chốt số liệu 31/10; tệp 05/11 gửi sau): kế hoạch quý theo cán bộ + chuyển kế hoạch theo bàn giao + % thực hiện/dự báo + xuất 4 bảng + trang đối soát. Dữ liệu kế hoạch quý IV đã suy ngược từ thông báo 22/10 và bảng 5/11 (tệp KE_HOACH_QUY_IV_2026_DE_NHAP.xlsx người dùng giữ — có tên cán bộ nên không đưa vào repo).
- Đối soát 5/11: chờ tệp msit80 05/11 (tệp 04/11 KHÔNG phải nguồn của bảng in 5/11: dư nợ 2.169.168 vs 2.163.809; DN 104.067 vs 103.802; KH 1.877 vs 1.879).
- Sau đó HM-08 (hỏi lại: app mở bằng file:// nên phần PWA không có tác dụng) → HM-10 → HM-09.

# BÀN GIAO — QLTDPRO — P06 · HM-31 GĐ2 — 07/11/2026
**Bản hiện hành: app/QLTDPRO_P43/app/QLTDPRO_v24.17.36.html** (sw.js/manifest 24.17.36). **Hồi quy v24.17.36: 1694 PASS · 0 FAIL** (37 bộ; LỆCH PB 12, LOI_MT p41/p42_gd14, SKIP 7 như cũ). Log: evidence/hoi_quy/hoi_quy_v24.17.36.log.

## HM-31 GĐ2 — v24.17.36 — DAT_V3 59/59 trên số liệu THẬT (evidence/hm31/BAO_CAO.md, phần GĐ2)
- Báo cáo ngày: thanh "Phạm vi" (Tất cả / Doanh nghiệp / Trung + dài hạn / Trung hạn TK 212 / Ngắn hạn + thấu chi) áp cho cả các mốc.
- "🔁 Sổ bàn giao cán bộ": app gợi ý từ so 2 mốc liền nhau (≥ 5 KH và ≥ 50% KH chuyển; ≥ 90% sang 1 người ⇒ nguyên danh mục, còn lại ⇒ chia theo KH), người dùng xác nhận / bỏ qua / xoá / xuất-nhập JSON (localStorage td_ban_giao_v1). Các mốc trước ngày hiệu lực tính lại theo sổ. Dòng kiểm Σ cán bộ = Σ phòng = TỔNG = tổng tệp.
- Đối soát 31/10: bảng Doanh nghiệp khớp tuyệt đối 3 mốc; Dư nợ khớp ĐN/BC (bản in thiếu 200 tr ở ĐQ); KH 1.846/1.891/1.871 vs 1.847/1.890/1.871; 10/18 cán bộ khớp đủ 3 cột, lệch ở 2 danh mục bị chia (Q25 chia theo KH mọi mốc, bản in làm tay khác) và ±1–2 KH. Bảng Trung hạn: bản in BC bỏ khoản TK 213 nhưng ĐN vẫn tính.
- Bộ kiểm p06_hm31b (kiem_thu_p06/test_hm31b_so_ban_giao.py + đáp án dap_an_ban_giao.py) cần QLTD_MSIT80_DIR như p06_hm31.
- Dựng: nguon_P06/build_p06_hm31b.py (+ gd28.js/.css) từ v24.17.35.
- Quyết định: Q25 danh mục bị chia ⇒ theo từng KH mọi mốc (KH đã tất toán → người nhận chính); Q26 sổ bàn giao do app gợi ý, người dùng xác nhận.

## Việc kế tiếp (hỏi người dùng trước)
- HM-31 GĐ3: kế hoạch quý theo cán bộ (bản in 2 KH và 2.000 tr/cán bộ/quý; app đang KH năm/4) + chuyển kế hoạch khi bàn giao, % thực hiện + dự báo 31/12/2026, xuất đúng mẫu 4 bảng, giữ cột ofcno. Cần từ người dùng: kế hoạch năm/quý 4 theo cán bộ.
- Hoặc HM-07 → HM-08 → HM-10 → HM-09.

# BÀN GIAO — QLTDPRO — P06 · HM-31 GĐ1 — 07/11/2026
Skill: web-app-repair-upgrade v3.2.0 (skill không cài trong container P06 — làm theo quy trình trong HANDOVER) | **Bản hiện hành: app/QLTDPRO_P43/app/QLTDPRO_v24.17.35.html** (sw.js/manifest 24.17.35).
**Hồi quy mốc v24.17.34 (đầu P06): 1603 PASS · 0 FAIL. Hồi quy v24.17.35: 1635 PASS · 0 FAIL** (35 bộ; LỆCH PB 12, LOI_MT p41/p42_gd14, SKIP 7 như cũ). Log: evidence/hoi_quy/hoi_quy_v24.17.35.log.

## HM-31 GĐ1 — v24.17.35 — DAT_V3 32/32 trên số liệu THẬT (evidence/hm31/BAO_CAO.md)
- Báo cáo ngày + Trả nợ: mốc Đầu tháng/Đầu quý/Đầu năm (và D-1) theo NGÀY DỮ LIỆU, không theo ngày máy; Trả nợ dùng chung bộ chọn mốc E3.
- Cán bộ không còn trong danh mục → nhóm "CÁN BỘ ĐÃ BÀN GIAO / NGOÀI DANH MỤC" trước TỔNG, vẫn cộng TỔNG + cảnh báo; bỏ khớp tên gần đúng.
- "+/- KH quý"/"+/- kế hoạch" = (Ngày BC − Đầu quý) − KH quý (người dùng chốt 07/11 — Q23).
- Đối soát 31/10/2026: TỔNG KH Đầu năm 1.847 · Ngày BC 1.871, Dư nợ 1.992.329 / 2.158.433 tr = bản in. Đầu quý/Đầu tháng app 1.892 KH / 2.180.311 tr = tệp 30/09 gốc; bản in 1.890 / 2.180.111 vì đã chuyển KH theo bàn giao bằng tay ⇒ GĐ2.
- Bộ kiểm kiem_thu_p06/test_hm31_bc_ngay.py (đăng ký p06_hm31) cần QLTD_MSIT80_DIR trỏ tới msit80 thật 31.12.2025.xlsx / 30.09.2026.XLS / 31.10.2026.XLS (KHÔNG có trong ZIP) — thiếu ⇒ SKIP.
- Dựng: nguon_P06/build_p06_hm31.py (+ gd27.js) từ v24.17.34.

## Việc kế tiếp
1. Hỏi người dùng trước khi sang hạng mục kế: HM-31 GĐ2 (cần danh sách bàn giao 2026: ngày, từ → đến, phạm vi; mã cán bộ ofcno — app chưa giữ cột ofcno; kế hoạch năm + quý 4 theo cán bộ) hoặc HM-07 → HM-08 → HM-10 → HM-09.
2. Bảng in còn lệch ở cột Đầu quý từng cán bộ (chuyển KH tay) — chỉ khớp được sau GĐ2.

## Quyết định P06
Q23: "+/- KH quý" = (Ngày BC − Đầu quý) − KH quý, thống nhất mọi dòng. Q24: cán bộ ngoài danh mục ở nhóm riêng trước TỔNG; không khớp tên gần đúng.

# BÀN GIAO — QLTDPRO — ĐÓNG PHIÊN P05 — 07/11/2026
Skill: web-app-repair-upgrade v3.2.0 | Chế độ: 3 | **Bản hiện hành: app/QLTDPRO_P43/app/QLTDPRO_v24.17.34.html** (sw.js/manifest 24.17.34).
Lý do đóng: người dùng yêu cầu chuyển phiên. Việc dở dang: không có mã dở; HM-31 chưa bắt đầu (đã có phương án).
**HỒI QUY CUỐI v24.17.34: 1603 PASS · 0 FAIL** (34 bộ, gồm p05_hm21…p05_hm30; LỆCH PB 12 = ca nhãn phiên bản đã khai báo; LOI_MT p41/p42_gd14 như cũ do Chromium container; SKIP 7). Log: evidence/hoi_quy/hoi_quy_v24.17.34.log.

## Tóm tắt P05 (06–07/11/2026)
| Hạng mục | Bản | Kết quả |
|---|---|---|
| HM-21 cán bộ xếp theo phòng như Báo cáo ngày ở mọi trang + dòng cũ → mới + ô chọn dễ nhìn (gd24) | .27 | DAT_V3 35/35 |
| HM-21b dòng mọi bảng mặc định Cán bộ ↑ rồi ngày; sửa dòng chồng chữ Nợ đến hạn/Lãi đọng | .28 | DAT_V3 77/77 |
| HM-25 trang Cho vay doanh nghiệp (custtpnm); đối chiếu tệp thật 04/11: 129 dòng · 14 KH · 104,07 tỷ khớp 0 đồng | .29 | DAT_V3 34/34 |
| HM-26 nhãn tím "TS trước kỳ" (KH vay mới không cầm cố, ≥1 TS thế chấp trước kỳ) | .30 | DAT_V3 14/14 |
| HM-27 "Doanh nghiệp" + trang Thấu chi tách khỏi Ngắn hạn | .31 | DAT_V3 28/28 |
| HM-28 "Cầm cố" + thứ tự menu Doanh nghiệp · Cầm cố · Khách hàng mới | .32 | DAT_V3 19/19 |
| HM-29 Xem tại mốc + So với mốc từ ô "Dữ liệu ngày ▾" (gd25) | .33 | DAT_V3 26/26 |
| HM-30 Lưu trữ + Trung tâm nhập theo loại Dư nợ/Tài sản, mới → cũ (gd26) | .34 | DAT_V3 32/32 |
Hồi quy tổng: v24.17.30 = 1498/0; **v24.17.34 = 1603 PASS · 0 FAIL** (đã hoàn tất, không còn việc dở).

## Việc kế tiếp (thứ tự đề xuất)
1. Chạy hồi quy tổng TRƯỚC khi sửa gì (cd app/QLTDPRO_P43 && python3 kiem_thu_chung/chay_hoi_quy.py --app app/QLTDPRO_v24.17.34.html; ~35 phút) làm mốc, rồi SAU mỗi hạng mục; sửa kỳ vọng bộ kiểm cũ CHỈ khi gắn với thiết kế mới.
2. **HM-31 (P0) Bàn giao cán bộ tín dụng** — người dùng báo số liệu đến 31/10/2026 không tính được tăng giảm/chỉ tiêu cuối năm vì bàn giao cán bộ. Phương án chi tiết (3 giai đoạn) ở mục "HM-31" bên dưới + tệp PHUONG_AN_BAN_GIAO_CBTD_QLTDPRO.docx người dùng giữ (không đưa vào repo vì có tên cán bộ).
3. HM-07 (bỏ thăm dò .docx 404) → HM-08 → HM-10 → HM-09 (còn từ P04).
4. Đề xuất chờ duyệt: chuyển _prevDunoSnap sang IndexedDB; nút "Xoá các mục hỏng"; nạp bảng giá NQ38/2025.

## HM-31 — tóm tắt đối soát và phương án (07/11/2026, đối soát 4 bảng in 31/10/2026 với app)
- Ngày BC (31/10) khớp: số KH 19/19 cán bộ (tổng 1.871), tổng dư nợ 2.158.433 triệu = app. Sai ở MỐC SO SÁNH: app tổng Đầu năm/Đầu quý KH = 1.771/1.814, bản in 1.847/1.890 (lệch 76 = KH của cán bộ đã bàn giao hết, bị loại khỏi danh mục); app Đầu tháng = Ngày BC (do mốc chọn theo NGÀY CỦA MÁY).
- Nguyên nhân gốc (mã nguồn): N1 mốc gán theo cán bộ TẠI THỜI ĐIỂM mốc (bản in tính lại theo cán bộ ĐANG quản lý); N2 cán bộ hết khoản vay mất khỏi tổng; N3 định danh cán bộ bằng TÊN + khớp gần đúng (gộp nhầm 2 người tên gần giống ở 2 phòng); N4 mốc đầu tháng/quý theo new Date() (hàm P3/E3 ngày hôm nay; hàm v3 của tab Trả nợ cũng vậy); N5 "+/- KH quý" = Ngày BC − Kế hoạch (sai); N6 kế hoạch chia đều 1/4, không chuyển khi bàn giao; N7 không có sổ bàn giao; N8 phòng theo cán bộ hiện tại; N9 mốc Lưu trữ lỗi (năm 2006, trùng ngày, nhãn gắn nhầm) — HM-30 đã có cảnh báo.
- Báo cáo tay: công thức "+/- so với kế hoạch" không thống nhất giữa các dòng (Hội Sở dùng đầu năm − KH quý; dòng khác dùng đầu quý − KH quý); điều chỉnh bàn giao viết tay.
- Phương án: GĐ1 sửa N4, N5, N2, N3 (mốc theo ngày báo cáo; công thức; giữ cán bộ đã bàn giao trong tổng; bỏ khớp tên gần đúng + cảnh báo); GĐ2 Sổ bàn giao (app gợi ý từ so 2 mốc, người dùng xác nhận) + mã cán bộ + tính lại mốc theo danh mục ĐANG quản lý + cột Bàn giao + kiểm Σ cán bộ = Σ phòng = tổng tệp; GĐ3 chuyển kế hoạch theo bàn giao, % thực hiện + dự báo 31/12/2026, xuất mẫu 4 bảng, trang đối soát với báo cáo tay.
- Hàm cần xem đầu tiên (trong bundle): P3 (Báo cáo ngày), E3 (chọn mốc EoM1/EoQ1/EoY1 theo ngày), Qv/ap (gán cán bộ → dòng), v3 (Trả nợ), Wv/le.roster (danh mục cán bộ), T3 (phòng theo cán bộ), hàm l4/ob/sb (số đếm menu).
- Cần người dùng: tệp msit80 thật 31/12/2025, 30/09/2026, 31/10/2026; danh sách bàn giao 2026 (ngày, từ → đến, phạm vi); mã cán bộ IPCAS / cột ofcno; kế hoạch năm + quý 4 theo cán bộ; công thức +/- kế hoạch thống nhất (đề xuất đầu quý − KH quý).

## Quyết định nghiệp vụ trong P05
Q17 nhận diện DN theo custtpnm; Q18 chỉ tiêu Dư nợ DN cùng cách nhận diện; Q19 thứ tự menu + thấu chi tách khỏi Ngắn hạn; Q20 F5 ⇒ về dữ liệu hiện hành, xem mốc là CHỈ XEM; Q21 nhãn "TS trước kỳ" (≥1 TS trước kỳ); Q22 Lưu trữ/nhật ký nhập mới → cũ. Mở: Q7 (đối chiếu IPCAS thật), bảng xếp hạng giữ theo số tiền?, nhật ký/Lưu trữ đã chọn mới → cũ.

## Môi trường
pip install playwright==1.63.0 xlrd python-docx pdfplumber (Chromium tại /opt/pw-browsers); pandas, openpyxl; Node v22. Quy ước: vá chuỗi có đếm số lần; style trong <style>; không đổi CSP; chỉ ĐỌC IndexedDB của kho khác, KHÔNG tạo CSDL rỗng (huỷ onupgradeneeded như zv()). Bản cũ v24.17.12–.25 ở thư mục app/ chỉ là đối chứng cục bộ — không nằm trong ZIP (ZIP có .33 và .34); hồi quy cần "bản liền trước" nên giải nén kèm bản cũ nếu muốn đủ đối chứng.
Dựng: nguon_P05/build_p05_hm21.py … hm30.py (chuỗi v24.17.26 → .34). Bộ kiểm mới: kiem_thu_p05/ (đã đăng ký kiem_thu_chung/danh_muc.json: p05_hm21…p05_hm30).

# (P05 chi tiết từng hạng mục)
Bản hiện hành: **app/QLTDPRO_P43/app/QLTDPRO_v24.17.30.html** (sw.js/manifest 24.17.30).
## P05-4. HM-26 nhãn "TS trước kỳ" — v24.17.30 — DAT_V3 (evidence/hm26/BAO_CAO.md)
KH vay mới không cầm cố, có ≥1 TS thế chấp trước ngày đầu kỳ ⇒ nhãn tím "TS trước kỳ" thay "mới". V3 14/14; hồi quy 1498 PASS · 0 FAIL.
## P05-3. HM-25 Trang Cho vay doanh nghiệp — v24.17.29 — DAT_V3 (evidence/hm25/BAO_CAO.md)
Q17: DN theo cột msit80 custtpnm (r[30]; custdtltpnm r[31]); tệp cũ ⇒ theo tên. Q18: Chỉ tiêu Dư nợ DN cùng nhận diện. V3 34/34; hồi quy 1484 PASS · 0 FAIL.
Đã đối chiếu tệp thật 04/11/2026: 129 dòng · 14 KH · 104,07 tỷ khớp 0 đồng (evidence/hm25/BAO_CAO.md). Kế tiếp: HM-07 → HM-08 → HM-10 → HM-09.
## P05-2. HM-21b — v24.17.28 — DAT_V3 (evidence/hm21b/BAO_CAO.md)
Dòng mọi bảng dt mặc định Cán bộ ↑ (danh mục như Báo cáo ngày) rồi ngày cũ → mới; bố cục đã lưu chuyển 1 lần (cờ l21); sửa dòng chồng chữ Nợ đến hạn/Lãi đọng (rowKey trùng).
V3 77/77 (v24.17.27: 18/43); hồi quy 1447 PASS · 0 FAIL (sửa kỳ vọng p05_hm21 D1, p52 R3 theo thứ tự mới).
## P05-1. HM-21 + dropdown dễ nhìn — v24.17.27 — DAT_V3 (evidence/hm21/BAO_CAO.md)
Lớp gd24 (QLTDCB.cmp): mọi trang xếp cán bộ theo phòng GIỐNG Báo cáo ngày; danh sách chi tiết ngày cũ → mới; gd24-css: mọi ô chọn chữ xanh đậm, đổ bóng nhẹ, ô lọc đang chọn màu hổ phách.
V3 35/35 (v24.17.26: 11/24); hồi quy trước 950/0 (thiếu bản đối chứng) · sau 1373 PASS · 0 FAIL. Bản cũ v24.17.12–.25 người dùng gửi lại (khớp MANIFEST) — chỉ để làm đối chứng cục bộ, không vào ZIP.
Mở: bảng xếp hạng giữ thứ tự theo số tiền; Lưu trữ/nhật ký Nhập vẫn mới → cũ — chờ người dùng quyết. Kế tiếp: HM-07 → HM-08 → HM-10 → HM-09.

# BÀN GIAO — QLTDPRO — ĐÓNG PHIÊN P04 — 06/11/2026
Skill: web-app-repair-upgrade v3.2.0 | Chế độ: 3 | **Bản hiện hành: app/QLTDPRO_P43/app/QLTDPRO_v24.17.26.html** (sw.js/manifest 24.17.26).
Lý do đóng: người dùng yêu cầu chuyển phiên. Việc dở dang: **không có** (mọi hạng mục đã làm đều có ZIP + hồi quy).

## Tóm tắt P04 (05–06/11/2026)
| Hạng mục | Bản | Kết quả |
|---|---|---|
| HM-12, HM-18 | v24.17.15–.16 | DAT_V3 |
| HM-14 (+14b) Máy tính lãi chính xác (Q12, Q15) | v24.17.17–.18 | DAT_V3 (chưa đối chiếu chứng từ thật) |
| HM-19 + HM-13 Máy tính lãi & Lãi đọng giao diện; L-07 bảng Lãi đọng | v24.17.19–.20 | DAT_V3 |
| Đối soát bảng giá đất 2026 (PL02) + sửa dòng Vũ Xuân Thiều | v24.17.20 | 0 ô lệch; 1 lỗi nguồn đã sửa |
| HM-20 (+20b) Chỉ tiêu kế hoạch (Q14 nhãn mốc; gom phòng như Báo cáo ngày) | v24.17.21–.22 | DAT_V3 |
| HM-03 Lưu trữ cục bộ (gd21 báo đầy bộ nhớ) | v24.17.23 | DAT_V3 |
| HM-04 XSS, HM-06 bố cục | (không đổi app) | DAT_V3 |
| HM-05 lỗi bị nuốt | v24.17.24 | DAT_V3 (khung PA SXKD kiểm tĩnh) |
| HM-22 cột TS (Số HĐTC, Số GN, Địa chỉ) | v24.17.25 | DAT_V3 |
| HM-23 + HM-24 TS chưa có HĐTD, Đầu kỳ & 2 mốc (Q16) | v24.17.26 | DAT_V3 |
Hồi quy chung cuối (v24.17.26): **1338 PASS · 0 FAIL** (LOI_MT p41/p42_gd14 — Chromium container, như cũ).

## Việc kế tiếp (thứ tự đề xuất)
1. **HM-21** — mọi trang: ô chọn/bảng cán bộ xếp theo phòng như Báo cáo ngày (danh mục cán bộ: Phòng KH → PGD HBT → PGD Số 2), danh sách dòng mặc định ngày cũ → mới (người dùng chọn "Cả hai"); gồm cả 2 tab gd23.
2. HM-07 (bỏ thăm dò .docx 404) → HM-08 (PWA một nguồn phiên bản) → HM-10 (tài liệu lớp vá) → HM-09 (hiệu năng, tùy chọn).
3. Đề xuất chờ duyệt: chuyển _prevDunoSnap (~300 KB) sang IndexedDB; nút "Xoá các mục hỏng"; nạp bảng giá nhà nước NQ38/2025.
4. Cần người dùng: ≥ 20 khoản chứng từ IPCAS thật (HM-14, chốt Q7); dữ liệu thật cho HM-18.

## Quyết định nghiệp vụ đã chốt trong P04
Q11–Q16 (backlog.quyet_dinh_nghiep_vu). Q13 đã đổi 05/11: Chỉ tiêu kế hoạch gom phòng như Báo cáo ngày. Q16 (06/11): mốc TSBĐ tự lưu theo ngày tệp + giữ bấm tay. Mở: Q7.

## Môi trường
pip install playwright==1.63.0 xlrd python-docx pdfplumber (Chromium tại /opt/pw-browsers); pandas, openpyxl. Hồi quy: cd app/QLTDPRO_P43 && python3 kiem_thu_chung/chay_hoi_quy.py --app app/QLTDPRO_v24.17.26.html (~25 phút, 27 bộ).

# (Chi tiết từng hạng mục P04 bên dưới)
## 0m. HM-23 + HM-24 — v24.17.26 (06/11) — DAT_V3 (evidence/hm23/BAO_CAO.md)
Mốc TSBĐ tự lưu theo ngày tệp vào kho kv của QLTDProTSBD (moc_<ngày>, ≤ 120; bản cũ tạo từ dữ liệu hiện hành); tab "🆕 TS chưa có HĐTD" (Phòng → Cán bộ, mới / đã có HĐTD / không còn, danh sách + Excel); tab "📅 Đầu kỳ & 2 mốc" (bảng như Báo cáo ngày + chọn 2 mốc tự lưu/bấm tay). V3 25/25; hồi quy 1338 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ). Kế tiếp: HM-21 (xếp cán bộ theo phòng như Báo cáo ngày ở mọi trang, kể cả 2 tab mới) → HM-07…HM-10.

## 0l. Đợt 6 (người dùng 06/11) — HM-21…HM-24; HM-22 xong — v24.17.25 (evidence/hm22/BAO_CAO.md)
Quyết định: HM-21 "Cả hai" (cán bộ theo phòng như Báo cáo ngày ở mọi trang + dòng cũ → mới); HM-22 Số GN ghép msit80; HM-23 chỉ TS "chưa có hồ sơ"; HM-24 "Cả hai" (bảng như Báo cáo ngày + chọn 2 mốc).
HM-22: cột Số TS, Số HĐ thế chấp (plgno), Số giải ngân (khế ước còn dư nợ, ghép mã KH/mã chủ TS), Địa chỉ TS bật mặc định sau Mã KH; bố cục cũ chuyển 1 lần (l22). V3 6/6 (v24.17.24 1/5); hồi quy 1313 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ).
Kế tiếp: HM-23 + HM-24 (Q16 đã chốt: mốc TSBĐ tự lưu theo ngày tệp + giữ bấm tay) → HM-21.

## 0k. HM-06 Bố cục bảng rộng — DAT_V3, KHÔNG đổi app (v24.17.24) (evidence/hm06/BAO_CAO.md)
6 trang × 1366/390/360 + tệp chữ dài liền: 0 tràn ngang tài liệu, 0 phần tử lòi ngoài khung cuộn, 0 nút bị che vĩnh viễn (21/21). Kế tiếp: HM-07…HM-10.

## 0j. HM-05 Lỗi bị nuốt — v24.17.24 (05/11) — DAT_V3 (evidence/hm05/BAO_CAO.md)
84 catch rỗng lớp vá: 79 chấp nhận, 5 có hại → thông báo qua gd9Toast: H1 mốc giữa kỳ (Khách hàng mới), H2 Lưu trữ cho lãi theo đoạn (+ H2b từng mốc), H3 khung Phương án SXKD (nạp/tự lưu/lưu). V3 5/0/1 SKIP (H3 chỉ kiểm tĩnh); v24.17.23 FAIL H1a, H2. Hồi quy 1286 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ; SKIP 5 gồm H3). Cài: QLTDPRO_v24.17.24.html + sw.js + manifest.json. Kế tiếp: HM-06…HM-10.

## 0i. HM-04 Đầu vào không tin cậy — DAT_V3, KHÔNG đổi app (v24.17.23) (evidence/hm04/BAO_CAO.md)
Tệp thử 40 dòng, 8 trường × 5 kiểu chuỗi tấn công, nạp qua #/nhap: 8 trang hiển thị dưới dạng chữ, bấm 9 khung gd7, Máy tính lãi 6 khách, rê chuột 60 ô → 0 mã chạy, 0 phần tử bị chèn, 0 pageerror (5/5). Rà tĩnh: JSX tự thoát; dangerouslySetInnerHTML duy nhất là HTML cố định; lớp vá dùng esc/escapeHtml/textContent. Chưa phủ động: Khách hàng mới, Hồ sơ vay. Kế tiếp: HM-05…HM-10.

## 0h. HM-03 Lớp lưu trữ — v24.17.23 (05/11) — DAT_V3 (evidence/hm03/BAO_CAO.md)
Kiểm kê động: 8 CSDL IndexedDB (QLTDProDB v3, TWIN_Archive_v1, QLTDProGD9 = bản sao localStorage, QLTDPro2Undo, QLTDProTSBD, QLTDKhachHangMoi, QLTDProMauHsvx, QLTDProFolder_v1) + khóa localStorage. Sao lưu toàn bộ → khôi phục ở trình duyệt sạch: trùng 100%. JSON hỏng / thiếu khóa / dữ liệu cũ / đầy bộ nhớ: 0 lỗi, dư nợ còn nguyên. Thêm gd21: báo rõ khi bộ nhớ đầy. V3 19/19 (v24.17.22: 18/19). Sửa bộ kiểm p52 (R2 chập chờn). Hồi quy 1275 PASS · 1 FAIL (p52_ma_kh R2 chập chờn — bắt 13 số trong mã băm SHA-256 ở title; đã sửa bộ kiểm p52 bỏ chuỗi hex → chạy lại 3/3 lần 14/0) ⇒ 0 FAIL do HM-03; LOI_MT p41/p42_gd14 như cũ.
Đề xuất chờ duyệt: chuyển _prevDunoSnap (~300 KB) sang IndexedDB; nút "Xoá các mục hỏng" (thông báo gd9 trỏ tới công cụ chưa có). Kế tiếp: HM-04…HM-10.

## 0g. HM-20b — v24.17.22 (05/11): xếp cán bộ theo phòng GIỐNG Báo cáo ngày (người dùng; thay Q13 cũ)
Tổng phòng / tab Theo phòng = cộng cán bộ theo danh mục cán bộ (như Báo cáo ngày). V3 31/31 (X1 thứ tự phòng→cán bộ trùng Báo cáo ngày; X2–X4 số khớp Python theo ofcnm); hồi quy 1257 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ). Lưu ý: khác trang Khách hàng mới (theo trctnm); PGD HBT = 0 trên dữ liệu thử vì danh mục chưa có cán bộ thuộc PGD HBT. Cài: QLTDPRO_v24.17.22.html + sw.js + manifest.json. Kế tiếp: HM-03…HM-10.

## 0f. HM-20 Chỉ tiêu kế hoạch — v24.17.21 (05/11) — DAT_V3 (evidence/hm20/BAO_CAO.md)
Q14: nhãn mốc "Đầu Q4/2026 (số dư 30/09/2026)", "Đầu T11/2026 (số dư 31/10/2026)"; Δ đầu tháng so số dư cuối tháng trước. Q13: tổng phòng gom theo trctnm khế ước. gd20: nhóm chỉ tiêu (mặc định Dư nợ), chỉ Live/%HT, Δ so mốc, ẩn chỉ tiêu toàn 0, cột tên dính, thẻ điện thoại. V3 27/27; hồi quy 1252 PASS · 1 FAIL (p52_ma_kh R2 chập chờn đã biết — mã băm hex trong title #/nhap-du-lieu; chạy lại: lần 1 vẫn FAIL đúng ca R2 với mã băm khác, lần 2 đạt 14/0 — lỗi bộ kiểm, không do HM-20) ⇒ 0 FAIL do HM-20; LOI_MT p41/p42_gd14 như cũ.
Mở: xếp CBTD theo phòng khế ước? (danh mục thử: PGD HBT 0 CBTD nhưng 586,6 tỷ dư nợ khế ước); Excel chưa có cột kiểm tra. Kế tiếp: HM-03…HM-10. Cài: chép QLTDPRO_v24.17.21.html + sw.js + manifest.json.

## 0e. L-07 + sửa giá đất — v24.17.20 (05/11) — DAT_V3 (evidence/l07/BAO_CAO.md)
Bảng trang Lãi đọng: mặc định 8 cột (vừa 1366; 5 cột còn lại ở "Cột ▾"; bố cục đã lưu chuyển 1 lần), hàng lọc gom vào nút "Lọc theo cột (n)", nút/ô ≥ 28/40 px, vạch màu theo ngày chậm lãi (1–30/31–90/>90), bỏ chữ đỏ cả dòng. Giá đất: Vũ Xuân Thiều TB VT1 55.000, VT2 33.000. V3 32/32 (v24.17.19: 6 FAIL); hồi quy 1226 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ). Cài: chép QLTDPRO_v24.17.20.html + sw.js + manifest.json.
Kế tiếp đề xuất: HM-20 (Chỉ tiêu kế hoạch) → HM-03…HM-10; tùy chọn: nạp bảng giá nhà nước NQ38/2025.

## 0d. Đối soát bảng giá đất 2026 (05/11) — evidence/gia_dat/BAO_CAO.md
App (985 dòng, 8 phường) = PL02 (Báo cáo tư vấn 275/2026, 16/03/2026): 0/11.820 ô lệch; 6 dòng lệch chính tả (app đúng); 22 dòng chỉ PL02 đều không có giá (9 tiêu đề nhóm, 13 "chưa hoàn thiện"). Lỗi nguồn: Vũ Xuân Thiều STT 212 TB VT1 28.000 (đúng 55.000), VT2 16.800 (đúng 33.000) — app mang theo; CHỜ người dùng xác nhận sửa. NQ38/2025 (giá nhà nước) chưa có trong app.

## 0c. HM-19 + HM-13 — v24.17.19 (05/11) — DAT_V3 (evidence/hm19/BAO_CAO.md)
Một lối vào "Máy tính lãi" (bỏ nút Tính lãi tất toán; GD14.openAllot giữ làm API), bảng Gọn 9 cột + nút Đầy đủ, tổng dính đầu, thẻ trên điện thoại (có "Chọn tất cả khoản"), danh sách tìm ghi khế ước + đến hạn, bảng phân rã lãi dd/mm/yyyy, ghi chú nguồn 3 tổng trang Lãi đọng. V3 36/36; HM-14 49/49; hồi quy 1194/0. Sửa 5 bộ kiểm cũ theo thiết kế mới (nút tất toán, M8).
Còn: L-07 bảng trang Lãi đọng (bundle). Cài: chép QLTDPRO_v24.17.19.html + sw.js + manifest.json.
**Việc kế (người dùng 05/11): đối soát bảng giá đất 2026** — bảng trong app đã trích: evidence/gia_dat/BANG_GIA_DAT_TRONG_APP_v24.17.19.xlsx (kiem_thu_p04/trich_bang_gia_dat.py; 8 phường, 985 dòng, nghìn đ/m², VT1–VT4 × cao/thấp/TB). Chờ tệp "Bảng giá đất Thành phố Nam Định cũ.zip" (Drive bị chặn).

## 0b. HM-14b — v24.17.18 (05/11): Q15 chốt (toàn dư nợ gốc; kỳ = nxtrpmtschddt, không mặc định → kỳ chọn tay không giữ sang khách khác, cảnh báo khoản trung/dài thiếu lịch); Q7 còn mở → cột Chênh IPCAS thử mốc ngày đến hạn kỳ/gốc. Lõi 229/229, V3 49/49, hồi quy 1159 PASS · 1 FAIL (p52_ma_kh R2 chập chờn đã biết — mã băm hex ngẫu nhiên trong title #/nhap-du-lieu; chạy lại 2 lần 14/0) ⇒ 0 FAIL do HM-14b; LOI_MT p41/p42_gd14 như cũ. ZIP QLTDPRO_P04_HM14B_20261105.zip. Cài: chép QLTDPRO_v24.17.18.html + sw.js + manifest.json.

## 0a. P04 tiếp — HM-14 (Máy tính lãi chính xác số liệu) — DAT_V3 (chi tiết: evidence/hm14/BAO_CAO.md)
- **Bản hiện hành: app/QLTDPRO_P43/app/QLTDPRO_v24.17.17.html** (v24.17.16 → .17 bằng nguon_P04/build_p04_hm14.py). sw.js/manifest 24.17.17.
- Lõi qltd_lai.cjs GIỮ BYTE (sha256 55908dc6…); mô-đun mới nguon_P04/qltd_lai_hm14.cjs (QLTDLai.hm14 1.0.0) gọi lại tinhLaiKhoan:
  Q12 (ngắn hạn/thấu chi không lãi chậm trả; trung/dài hạn quá kỳ trả lãi nxtrpmtschddt hoặc kỳ chọn 1/3/6 tháng → LS×1,5 từ ngày kỳ),
  lãi theo đoạn dư nợ từ mốc Lưu trữ (+ lstrpmtdt), cột CHÊNH IPCAS (lãi app đến ngày dữ liệu − intamt), cảnh báo ngày chốt.
  Lãi dự thu trang Lãi đọng + công cụ Tính lãi tất toán dùng cùng tinhLaiQ12.
- Kiểm: lõi 224/224 (200 khoản đồng nhất với hàm cũ), V3 43/43 (1366 + 390, 0 pageerror), v24.17.16 FAIL 7 ca; lõi cũ 18/18 + 11/11.
  Hồi quy chung trước (v24.17.16) 882 PASS · 0 FAIL; sau (v24.17.17): 1146 PASS · 3 FAIL (A10 "lãi chậm trả" ở p41_gd14/p42_gd14/p42_mtl_gd14 — khoản ngắn hạn, Q12 bỏ lãi chậm trả) → sửa kỳ vọng A10 → 3 bộ 75/0 ⇒ 1149 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ).
- Chưa đạt: đối chiếu ≥ 20 khoản chứng từ IPCAS thật (cần người dùng). Câu hỏi: Q15 đã chốt 05/11 (xem 0b); Q7 còn mở.
- **Kế tiếp đề xuất: HM-19 + HM-13 (cùng hộp Máy tính lãi/Lãi đọng) → HM-20 → HM-03…HM-10.**

# (P04 phần trước)
## 0. P04 — tóm tắt
- **Bản hiện hành: app/QLTDPRO_P43/app/QLTDPRO_v24.17.16.html** (v24.17.14 → .15 build_p04_hm12.py → .16 build_p04_hm18.py). sw.js/manifest 24.17.16.
- HM-18 DAT_V3: gd15 1.3.0 (layR dùng chung) + gd16 1.0.0 (KPI/Tổng hợp/biểu đồ theo lõi, KPI bấm → chi tiết, CSS chữ/nút). evidence/hm18/BAO_CAO.md. Bộ kiểm kiem_thu_p04/test_hm18_khm_toan_trang.py (danh_muc p04_hm18). Hồi quy 881/1 → sửa kỳ vọng p03_hm17 T3 theo Q11 → 3 bộ 56/0.
- Kế tiếp: HM-14 (Máy tính lãi chính xác; áp Q12) → HM-19 + HM-13 → HM-20.
- HM-12: lõi QLTD_DSTN 1.1.0 (cộng thêm k.moc), gd15 1.2.0 (ô bấm → chi tiết, lọc, Excel 4 sheet). Chi tiết: evidence/hm12/BAO_CAO.md. Bộ kiểm: kiem_thu_p04/test_hm12_chi_tiet.py (đã thêm danh_muc p04_hm12). Hồi quy trước 829/0.
- Đề án v1.2: de-an/DE_AN_QLTDPRO_v1.2.docx (evidence/build_de_an_v12.js). Khảo sát điểm nghẽn (chỉ đọc) kiem_thu_p04/khao_sat_khm_lai.py, khao_sat_ctkh_tab.py → evidence/khao_sat_p04/.
- Phát hiện chính: KPI Thu nợ trang KH mới 528,31 tỷ (suy ra) ≠ Đối soát 544,70 tỷ; GN 50,66 tỷ/110 món ≠ 63,33 tỷ/124 món; Máy tính lãi 2 lối vào, 3 tổng lãi khác nhau; Chỉ tiêu kế hoạch 48 cột, cột tên không dính, gom phòng theo danh mục CB ≠ phòng khế ước, nhãn "Đầu Q3" = số dư 30/09.
- Câu hỏi mở: Q11–Q14 (backlog.quyet_dinh_nghiep_vu_mo).
- Thứ tự đề xuất: HM-12 (đóng) → HM-18 → HM-14 → HM-19+HM-13 → HM-20 → HM-03…HM-10.

# (Bản P03 bên dưới giữ để tra cứu)
## BÀN GIAO P03 (ĐÓNG PHIÊN) — 2026-11-05
Skill: web-app-repair-upgrade v3.2.0 | Chế độ: 3 | Lý do đóng: chạm ngưỡng ngữ cảnh sau HM-16. Trong P03: HM-11b, HM-17, HM-16 đều DAT_V3. Kế tiếp: HM-12.

## 1. Dự án và môi trường
Loại app: HTML đơn tệp + PWA (bundle React/Vite đã nén + lớp vá gd3–gd15) | **Bản hiện hành: app/QLTDPRO_P43/app/QLTDPRO_v24.17.14.html** (v24.17.11 → .12 build_p03_hm11b.py → .13 build_p03_hm17.py → .14 build_p03_hm16.py). v24.17.9–.13 giữ trong app/ làm đối chứng.
Chạy app: `cd app/QLTDPRO_P43/app && python3 -m http.server 8765` → http://localhost:8765/QLTDPRO_v24.17.14.html
Hồi quy chung: `cd app/QLTDPRO_P43 && python3 kiem_thu_chung/chay_hoi_quy.py --app app/QLTDPRO_v24.17.14.html [--chi id,id]` (đã có bộ p03_hm11b, p03_hm17).
Môi trường P03: Node v22.23.4; `pip install playwright==1.63.0 xlrd` (Chromium 153 /opt/pw-browsers); pandas, openpyxl có. V3_KHA_DUNG: có.
Quy ước: vá chuỗi chính xác có đếm số lần; style trong <style>; không đổi CSP, 4 CSDL; tiếng Việt.

## 2. Đề án và trạng thái (khớp backlog.json)
Đề án v1.1 — DA_DUYET — de-an/DE_AN_QLTDPRO_v1.1.docx. Điều chỉnh nhỏ: HM-15 (P02), **HM-16 (P03, phát hiện khi kiểm HM-11b trên dữ liệu thật)**.
Thứ tự còn lại: **HM-12 → HM-14 → HM-13 → HM-03…HM-10**.
| ID | Tên | Ưu tiên | Effort | Trạng thái | Bậc |
|----|-----|---------|--------|------------|-----|
| HM-01 | Bộ chạy hồi quy chung | P1 | M | DA_BAN_GIAO | V3 |
| HM-02 | Lỗi đọc ngày dd/mm qua mọi đường đọc tệp | P1 | S | DA_BAN_GIAO | V3 |
| HM-03…HM-10 | (xem backlog.json) | P1–P3 | — | CHUA_LAM | — |
| HM-11a | Lõi QLTD_DSTN + đối chiếu msit80 thật | P1 | M | DAT_V2 | V2 |
| HM-11b | Gắn QLTD_DSTN vào trang Khách hàng mới (bảng Phòng → Cán bộ) | P1 | M | DAT_V3 | V3 |
| HM-12 | Màn hình GN/thu nợ phòng → cán bộ, bấm số tiền xem chi tiết, xuất Excel | P1 | M | CHUA_LAM | — |
| HM-13 | Máy tính lãi: giao diện | P2 | M | CHUA_LAM | — |
| HM-14 | Máy tính lãi: chính xác số liệu | P1 | M | CHUA_LAM | — |
| HM-15 | Tệp TSBĐ .csv nhận nhầm loại | P1 | S | DA_BAN_GIAO | V3 |
| HM-16 | Lưu trữ bỏ khế ước dư nợ 0 → thiếu GN trả hết trong kỳ | P1 | S | DAT_V3 | V3 |
| HM-17 | Trang KH mới tính trùng GN khi khế ước đổi HĐTD (thừa 638,76 tỷ) | P0 | S | DAT_V3 | V3 |

## 3. Hạng mục vừa đóng: HM-11b — DAT_V3 (chi tiết: evidence/hm11b/BAO_CAO.md)
Làm: gd11 xuất API chỉ đọc Lưu trữ; chèn lõi QLTD_DSTN 1.0.1 + lớp vá gd15 (nguon_P02/gd15.js). Tab Đối soát: lấy mốc đầu/cuối đã chọn ở "Nạp từ Lưu trữ" + MỌI mốc ở giữa → bảng Phòng → Cán bộ (Đầu, số món GN, GN, Thu, Điều chỉnh, Cuối, Kiểm tra, số KƯ, tất toán), cảnh báo thiếu mốc; bảng cũ "Thu nợ suy ra" ẩn (nút xem lại); tệp chọn tay → thông báo, giữ bảng cũ. window.__khmDstn cho HM-12.
Kiểm chứng: V3 dữ liệu thử ẩn danh (kiem_thu_p03/tao_mis80_thu.py) **25/25 PASS** (desktop 1366 + điện thoại 390, 0 pageerror) — số màn hình = công cụ doi_chieu_mis80 0 đồng mọi phòng/cán bộ. Hồi quy chung trước/sau: 799 PASS · 0 FAIL (y hệt).
Dữ liệu thật (11 tệp người dùng gửi, chỉ ở thư mục tạm): **23/25** — lệch GN/thu (chuỗi 10 món 7,419 tỷ; 2 mốc 11 món 3,625 tỷ) do mốc Lưu trữ bỏ dòng dư nợ 0; lõi trên dữ liệu đã lọc dư nợ 0 khớp app 0 đồng, 0/7.065 khế ước lệch → HM-16.

## 3b. Hạng mục vừa đóng: HM-17 — DAT_V3 (chi tiết: evidence/hm17/BAO_CAO.md)
Gốc: buildReport + gd11.loadMidSnaps so khế ước giữa kỳ với mốc cuối theo brcd|apprseq|dsbsseq → khế ước đổi HĐTD sinh dòng "tất toán" giả. Sửa: khóa = dsbsseq (2 điểm; dấu tích KH mới giữ khóa cũ). V3: thử v24.17.12 2/5 → v24.17.13 5/5; thật 5/5 (5.957 món / 3.901,32 tỷ, trước 7.057 / 4.538,67). Hồi quy 828 PASS · 1 FAIL p52 R2 chập chờn (chạy lại: lần 1 vẫn FAIL đúng ca R2 với mã băm khác, lần 2 đạt 14/0 — lỗi bộ kiểm, không do HM-20; lỗi nền). Chưa đổi: khế ước tất toán vẫn gán cán bộ ở mốc cuối nó xuất hiện.

## 3c. Hạng mục vừa đóng: HM-16 — DAT_V3 (chi tiết: evidence/hm16/BAO_CAO.md)
Gốc: k4() ở Nhập dữ liệu loại dòng dư nợ 0, Zf() chỉ lưu dòng còn lại. Sửa: lưu khóa phụ rpt0_<timestamp> (mốc chính/KPI không đổi), gd15 1.1.0 gộp, cảnh báo mốc cũ cần nhập lại. V3: thử v24.17.13 23/25 → v24.17.14 25/25; thật 25/25 (0 đồng); hồi quy 829/0.

## 4. Hạng mục kế tiếp: HM-12 — màn hình GN/thu nợ phòng → cán bộ, bấm số tiền xem chi tiết từng khế ước, xuất Excel đối soát
Bước đầu: dùng window.__khmDstn (R.khe: dauKy, gn, gnMon, thu, dieuChinh, cuoiKy, cachTinh, gan, cbTen, phong) trong lớp vá gd15 (nguon_P02/gd15.js → build mới từ v24.17.14); ô số trong bảng khm-dstn-t bấm được → danh sách khế ước; xuất Excel cùng 4 sheet như kiem_thu_p02/doi_chieu_mis80.py (Phòng, Cán bộ, Chi tiết khế ước, Ghi chú). Kiểm V3 bằng test_hm11b_dstn.py (mở rộng) trên dữ liệu thử + thật.

## 5. Việc dở dang chính xác
Không có.

## 6. Quyết định đã chốt (không đảo ngược nếu chưa có bằng chứng mới)
- Giữ app đơn tệp, ngoại tuyến, CSP chặn mạng; không đổi 4 CSDL IndexedDB.
- Không đổi quy tắc lãi (365; quá hạn = LS×1,5 theo ngày đến hạn từng khoản GN; tròn từng phần) khi chưa có căn cứ.
- Không viết lại app; tính năng mới chỉ theo đề án đã duyệt (v1.1).
- HM-01: hồi quy chạy trên bản soi; bí danh tên HTML cũ; đối chứng = bản liền trước; ca nhãn bản cũ xếp LECH_PB có lý do.
- HM-02: tệp văn bản đọc thô (raw) ở mọi đường nạp có đọc ngày; tệp nhị phân không đổi.
- HM-11b: tích hợp lõi bằng lớp vá gd15 (không sửa bundle); chỉ ĐỌC Lưu trữ qua window.__gd11Api; quy tắc gán khế ước tất toán giữ như lõi 1.0.1 (người dùng 05/11: giữ tới khi nói khác).

## 7. Lỗi nền / ngoài phạm vi / đề xuất
- **HM-16 (mới, P1):** mốc Lưu trữ bỏ khế ước dư nợ 0 → GN trả hết trong kỳ không được tính (đã xác minh trên dữ liệu thật).
- 404 HEAD mẫu Bảng kê mua hàng.docx (HM-07).
- Chromium container sập khi tải lại trang có handle thư mục → p41_gd14/p42_gd14 dừng giữa chừng; chạy trên Chrome thường.
- Gói thiếu kiem_thu_p40/zip/ → runner sinh lại (zip + xlsx cùng lần) trên bản soi.

## 8. Việc người dùng cần làm
- Mở phiên mới cho HM-12: dán PROMPT_PHIEN_SAU.md (ZIP QLTDPRO_P03_HM16_20261105.zip có sẵn trong repo bao-cao/).
- Sau khi cài v24.17.14: **nhập lại các tệp msit80** (mốc cũ không có dòng dư nợ 0 — bảng Đối soát sẽ cảnh báo).
- Kiểm tay v24.17.13: Khách hàng mới → Nạp từ Lưu trữ 31/12/2025 → 31/10/2026 → Lập báo cáo: Doanh số cho vay ≈ 5.957 món (không còn khế ước lặp ở Chi tiết/Excel); báo lại nếu Lưu trữ máy bạn cho số khác (bản bạn xuất, bỏ trùng = 5.941).
- Kiểm tay v24.17.12: Nhập dữ liệu các tệp msit80 cuối tháng → Khách hàng mới → 📥 Nạp từ Lưu trữ (đầu 31/12/2025, cuối 31/10/2026) → Lập báo cáo → tab Đối soát: thấy bảng Phòng → Cán bộ, "11 mốc", Kiểm tra = 0; so với Excel DOI_SOAT_DSTN (biết trước lệch GN ~7,4 tỷ do HM-16).
- Cài v24.17.14: chép HTML + sw.js + manifest.json.

## 9. Đường lui: ZIP HM17 (v24.17.13), HM11B (v24.17.12), HM-11a (v24.17.11). Cũ hơn: HM-15 (v24.17.11), HM-02 (v24.17.10), HM-01 (v24.17.9)
## 10. File đã chạm trong phiên P03
Tạo: nguon_P02/gd15.js, nguon_P02/build_p03_hm11b.py, nguon_P02/build_p03_hm17.py, nguon_P02/build_p03_hm16.py, app/QLTDPRO_v24.17.12.html, app/QLTDPRO_v24.17.13.html, app/QLTDPRO_v24.17.14.html, evidence/hm16/, kiem_thu_p03/test_hm17_trung_gn.py, evidence/hm17/, kiem_thu_p03/tao_mis80_thu.py, kiem_thu_p03/test_hm11b_dstn.py, evidence/hm11b/. Sửa: app/sw.js, app/manifest.json (24.17.14); sửa kiem_thu_p03/tao_mis80_thu.py (+dòng dư nợ 0), kiem_thu_chung/danh_muc.json (+p03_hm11b, p03_hm17), handover/*.
## 11. Nhật ký ngắn
- S-OPEN P03 2026-11-05: giải nén ZIP HM-11a, MANIFEST 238/238 khớp; skill v3.2.0. Người dùng đã chọn HM-11b (làm ngay). Môi trường: cài playwright 1.63.0 + xlrd; V3 có.
- Hồi quy trước (v24.17.11): 799/0.
- gd15 + build → v24.17.12; dữ liệu thử 3 mốc; sửa bộ sinh ghi ô ngày (công cụ Python cần ô ngày như tệp thật). V3 thử 25/25.
- Người dùng gửi 11 tệp msit80 thật giữa chừng → V3 thật 23/25; khoanh: dòng dư nợ 0 bị bỏ ở Lưu trữ (xác minh 0/7.065 khế ước lệch sau lọc) → thẻ HM-16.
- Hồi quy sau (v24.17.12): 799/0. HM-11b DAT_V3; dựng QLTDPRO_P03_HM11B_20261105.zip.

## NHẬT KÝ HM-02 (write-ahead)
- 14:01 người dùng chọn ①: HM-01 DA_BAN_GIAO; Đợt 4 (HM-11…HM-14) DA_DUYET; mở HM-02.
- 14:05 tái hiện V3: TSBĐ văn bản .xls đảo ngày ≤ 12 (D1b FAIL); dư nợ văn bản đúng (E1 PASS); TSBĐ .csv nhận nhầm Dư nợ (thẻ mới HM-15). Gốc: worker aoa đọc cellDates:true không raw.
- 14:09 đã sửa: nguon_P02/build_p02_hm02.py → v24.17.10 (aoa raw:!0). test_hm02: v24.17.9 9/10 (D1b FAIL), v24.17.10 10/10. Thêm thẻ HM-15. Chạy hồi quy chung trên v24.17.10.
- HM-02 đóng: DAT_V3; dựng QLTDPRO_P02_HM02_20261104.zip.

## NHẬT KÝ HM-15 (write-ahead)
- 23:07 người dùng chọn HM-15: HM-02 DA_BAN_GIAO; mở HM-15 (tệp TSBĐ .csv nhận nhầm Dư nợ).
- 23:10 gốc: bước dò tiêu đề chỉ chạy .xls/.xlsx/.xlsm. Sửa nguon_P02/build_p02_hm15.py → v24.17.11 (+csv). test_hm15: v24.17.10 8/12 → v24.17.11 12/12. Chạy hồi quy chung v24.17.11.
- HM-15 đóng: DAT_V3; dựng QLTDPRO_P02_HM15_20261104.zip.
- S-CLOSE: chạm ngưỡng ngữ cảnh; người dùng chọn HM-11 → ghi làm kế tiếp, không mở trong P02; dựng QLTDPRO_P02_DONGPHIEN_20261104.zip.
- 05/11 người dùng trả lời Q4–Q6, Q10 + gửi 11 tệp msit80 thật; mở HM-11; phân tích R-01…R-07; tách HM-11a/HM-11b.
- Lõi qltd_dstn 1.0.0 → sửa quy tắc GN với mốc giữa thiếu dòng (U15) → 1.0.1 sửa mã KH = brcd (phát hiện trên dữ liệu thật, U21). Đối chiếu thật 0 đồng. HM-11a DAT_V2; dựng QLTDPRO_P02_HM11A_20261105.zip.
- 05/11 người dùng gửi 2 báo cáo app xuất (dữ liệu thật, chỉ thư mục tạm): phát hiện GN trùng 1.116 món/638,76 tỷ do đổi HĐTD; dư nợ cuối 18/18 cán bộ khớp lõi. Người dùng chọn ①: mở HM-17 (P0), sau đó HM-16.
- HM-17: tái hiện v24.17.12 2/5 → sửa build_p03_hm17.py → v24.17.13 5/5 (thử + thật). Hồi quy 828/1 (p52 chập chờn, chạy lại đạt). HM-17 DAT_V3; dựng QLTDPRO_P03_HM17_20261105.zip. Ngữ cảnh vùng Vàng → đề nghị đóng phiên, HM-16 ở phiên P04.
- 05/11 người dùng chọn HM-16 ngay trong P03 (vùng Vàng): mở HM-16.
- HM-16: tái hiện v24.17.13 23/25 → build_p03_hm16.py → v24.17.14 25/25 (thử + thật). Hồi quy 829/0. HM-16 DAT_V3. S-CLOSE (ngưỡng ngữ cảnh): dựng QLTDPRO_P03_HM16_20261105.zip (kiêm ZIP đóng phiên).

## NHẬT KÝ P04 (write-ahead)
- 14:05 S-OPEN P04: MANIFEST 267/267 khớp; cài xlrd; hồi quy trước v24.17.14 829/0.
- HM-12: lõi 1.1.0 (23/23), gd15 1.2.0, build v24.17.15; V3 thử 28/28; v24.17.14 1/4.
- 14:21 người dùng bổ sung đề án: KH mới toàn trang, Máy tính lãi → HM-18, HM-19; 14:25: Chỉ tiêu kế hoạch → HM-20. Khảo sát Playwright chỉ đọc; đề án v1.2 CHỜ DUYỆT.
- HM-12 hồi quy sau v24.17.15: 859 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ). HM-12 DAT_V3; dựng QLTDPRO_P04_HM12_20261105.zip.
- 15:23 người dùng: duyệt Đợt 5 (v1.2 DA_DUYET); Q11 cả GN mới + GN thêm món cũ; Q12 ngắn hạn không lãi chậm trả, trung/dài hạn quá hạn 150% khi đến kỳ chưa trả đủ lãi; Q13 phòng theo khế ước; Q14 số dư cuối kỳ trước trong Lưu trữ; thứ tự theo đề xuất → HM-12 DA_BAN_GIAO, mở HM-18.
- HM-18: v24.17.16 thử 23/23 (v24.17.15 FAIL A1/A2/A4); hồi quy 881/1 (p03_hm17 T3 kỳ vọng cũ) → sửa test → 56/0. DAT_V3; dựng QLTDPRO_P04_HM18_20261105.zip.
- HM-14 (05/11, phiên tiếp P04 trong container mới): giải nén ZIP HM18, MANIFEST khớp (trừ 4 HTML cũ v24.17.8–.11 không có trong gói); cài playwright 1.63.0 + xlrd.
  Hồi quy trước v24.17.16 882/0. Mô-đun qltd_lai_hm14 1.0.0 + build_p04_hm14 → v24.17.17. Lõi 224/224; V3 43/43 (v24.17.16: 7 FAIL). Hồi quy sau 1146 PASS · 3 FAIL (A10 "lãi chậm trả" ở p41_gd14/p42_gd14/p42_mtl_gd14 — khoản ngắn hạn, Q12 bỏ lãi chậm trả) → sửa kỳ vọng A10 → 3 bộ 75/0 ⇒ 1149 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ). DAT_V3; dựng QLTDPRO_P04_HM14_20261105.zip.
- 05/11 người dùng trả lời Q15 (a toàn dư nợ gốc; b nxtrpmtschddt, không mặc định), Q7 (chưa rõ, có thể đến ngày đến hạn) → HM-14b build_p04_hm14b → v24.17.18; lõi 229/229, V3 49/49; hồi quy 1159 PASS · 1 FAIL (p52_ma_kh R2 chập chờn đã biết — mã băm hex ngẫu nhiên trong title #/nhap-du-lieu; chạy lại 2 lần 14/0) ⇒ 0 FAIL do HM-14b; LOI_MT p41/p42_gd14 như cũ.
- 05/11 HM-19 + HM-13: build_p04_hm19 → v24.17.19; V3 36/36; hồi quy 1194/0. Đối soát giá đất: đã trích bảng app; chờ tệp nguồn.
- 05/11 Đối soát giá đất 2026: ghép 2 phần ZIP người dùng; doi_soat_gia_dat.py → 979 khớp, 0 ô lệch giá, 6 lệch chữ, 22 dòng nguồn không giá; 1 lỗi TB ở nguồn (Vũ Xuân Thiều).
- 05/11 L-07 + giá đất 212: build_p04_l07 → v24.17.20; V3 32/32; hồi quy 1226 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ).
- 05/11 HM-20: build_p04_hm20 + gd20 → v24.17.21; V3 27/27 (v24.17.20 FAIL Q14a); hồi quy 1252 PASS · 1 FAIL (p52_ma_kh R2 chập chờn đã biết — mã băm hex trong title #/nhap-du-lieu; chạy lại: lần 1 vẫn FAIL đúng ca R2 với mã băm khác, lần 2 đạt 14/0 — lỗi bộ kiểm, không do HM-20) ⇒ 0 FAIL do HM-20; LOI_MT p41/p42_gd14 như cũ.
- 05/11 HM-20b: build_p04_hm20b → v24.17.22 (gom phòng như Báo cáo ngày); V3 31/31; hồi quy 1257 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ).
- 05/11 HM-03: kiểm kê + test_hm03 19/19; gd21 → v24.17.23; sửa p52 R2; hồi quy 1275 PASS · 1 FAIL (p52_ma_kh R2 chập chờn — bắt 13 số trong mã băm SHA-256 ở title; đã sửa bộ kiểm p52 bỏ chuỗi hex → chạy lại 3/3 lần 14/0) ⇒ 0 FAIL do HM-03; LOI_MT p41/p42_gd14 như cũ.
- 05/11 HM-04: test_hm04_xss 5/5 trên v24.17.23; không đổi app; đăng ký p04_hm04 (bộ chạy chung: p04_hm03 19/0, p04_hm04 5/0).
- 05/11 HM-05: build_p04_hm05 → v24.17.24; test_hm05 5/0/1; hồi quy 1286 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ; SKIP 5 gồm H3).
- 05/11 HM-06: test_hm06 21/21 trên v24.17.24; không đổi app; đăng ký p04_hm06.
- 06/11 Đợt 6: thêm HM-21…24; HM-22 build_p04_hm22 → v24.17.25; V3 6/6; hồi quy 1313 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ).
- 06/11 HM-23+24: gd23 + build_p04_hm23 → v24.17.26; V3 25/25; hồi quy 1338 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ).
- 06/11 S-CLOSE P04 theo yêu cầu người dùng: dựng QLTDPRO_P04_DONGPHIEN_20261106.zip (= v24.17.26, hồi quy 1338/0).
