# QLTDPRO — Tài liệu triển khai phiên kế tiếp (P07)
Lập 07/11/2026 cuối phiên P06. Skill web-app-repair-upgrade v3.2.0 (không cài trong container P06 — làm theo quy trình HANDOVER).

## 1. Trạng thái bàn giao
- **Bản hiện hành:** `app/QLTDPRO_P43/app/QLTDPRO_v24.17.45.html` (sw.js/manifest 24.17.44). Gói cài đặt chỉ gồm app: `QLTDPRO_v24.17.45_CAI_DAT.zip`.
- **Hồi quy tổng v24.17.45:** xem dòng đầu HANDOVER.md (con số cuối cùng do hồi quy Opus xác nhận). Mốc trước: v24.17.43 = 1786 PASS · 0 FAIL.
- Đã hoàn tất trong P06: HM-07 (bỏ tự tải mẫu), HM-31 (GĐ1–GĐ3: mốc theo ngày dữ liệu, sổ bàn giao có mã cán bộ + phạm vi + hiệu lực thực tế, kế hoạch quý, chuyển kế hoạch, thực hiện/dự báo, xuất 4 bảng, đối soát), HM-09 (hiệu năng trang Chỉ tiêu KH: 4,10 s → 2,10 s CPU), bố cục PC/laptop (cột tiền vào màn hình đầu, màu ma trận, kỳ mới → cũ), chốt đối soát 31/10 và 05/11.
- Còn mở: **HM-08** (PWA/phiên bản một chỗ — app mở bằng tệp .html nên PWA không có tác dụng; đề xuất chỉ làm "đổi phiên bản ở một chỗ + dọn bản cũ"), **HM-10** (tài liệu lớp vá gd3–gd29 + neo vá), Q7 (đối soát IPCAS thật).

## 2. Việc nên làm đầu phiên P07 (hỏi người dùng trước khi làm)
1. **Danh sách khách lẻ bản in gán khác** (mã KH) → nhập vào sổ bàn giao theo phạm vi mã KH để triệt tiêu ô lệch còn lại ở đối soát 31/10 và 05/11 (hiện: DN 88/88; trung+dài 72–73/88; dư nợ 64–71/88; KH 63–70/88; Ngày BC và Đầu tháng khớp tuyệt đối).
2. **Xác nhận số kế hoạch quý IV** (người dùng giữ tệp KE_HOACH_QUY_IV_2026_DE_NHAP.xlsx): KH vay tăng 6 hay 2/cán bộ; bỏ cán bộ đã bàn giao hết khỏi kế hoạch; một tên viết sai trong thông báo (hiểu là cán bộ có tên gần giống trong dữ liệu IPCAS).
3. **Kế hoạch NĂM theo mã cán bộ + % thực hiện năm**; trang đối soát riêng (hiện là khối trong tab Báo cáo ngày).
4. HM-08 rút gọn → HM-10.
5. Khi người dùng nhập dữ liệu thật: nhắc nhập **Ngày hiệu lực thực tế = 01/10/2026** ở "Sổ bàn giao cán bộ"; nhắc trang **Tài sản bảo đảm** cần tệp sao kê TSBĐ riêng (msit80 không chứa TSBĐ).

## 3. Môi trường và lệnh
- `pip install playwright==1.63.0 xlrd python-docx pdfplumber openpyxl pandas`; Chromium ở /opt/pw-browsers; Node v22. Không `playwright install`.
- Giải nén ZIP vào thư mục tạm, kiểm `sha256sum -c handover/MANIFEST.sha256`.
- Hồi quy tổng (≈ 55–60 phút, chạy nền): `cd app/QLTDPRO_P43 && QLTD_MSIT80_DIR=<thư mục msit80 thật> QLTD_BANIN_JSON=<json bản in 31/10> python3 kiem_thu_chung/chay_hoi_quy.py --app app/QLTDPRO_v24.17.45.html`. Thiếu 2 biến ⇒ các bộ p06_hm31/b/c/d/e SKIP (an toàn). LOI_MT p41/p42_gd14 và LECH_PB 12 là đã biết.
- Dữ liệu thật KHÔNG nằm trong ZIP/repo (msit80 .XLS, tệp Excel đối soát có tên cán bộ, ảnh chụp). Nếu cần, xin lại người dùng; số báo cáo tay 31/10 và 05/11 dạng JSON {kh,dn,dnn,th → {tên: [Đầu năm, Đầu quý, Đầu tháng, Ngày BC]}} do phiên này dựng (không có trong ZIP vì có tên cán bộ).
- Đối soát chốt: `QLTD_MSIT80_DIR=… QLTD_FILES=31.12.2025.xlsx,30.09.2026.XLS,31.10.2026.XLS[,05.11.2026.XLS] QLTD_NGAY=05-11-2026 QLTD_BANIN_JSON=… QLTD_OUT=<thư mục> python3 kiem_thu_p06/chot_doi_soat_3110.py`.
- Đo hiệu năng: `QLTD_MSIT80_DIR=… python3 kiem_thu_p06/do_hieu_nang_ctkh.py app/QLTDPRO_v24.17.45.html`.

## 4. Chuỗi dựng (mỗi bước đọc nguồn lưu sẵn để tái hiện đúng md5)
v34 → build_p06_hm31 (.35) → hm31b (.36, gd28_v36) → hm07 (.37) → hm31c (.38, gd28_v38) → hm31d (.39, gd28_v39+gd29) → hm31e (.40, gd28_v40) → hm09 (.41, gd28_v41) → hm31f (.42) → hm32 (.43) → hm33 (.44) → hm34 (.45, gd28_v44: bảng báo cáo → Kế hoạch quý → Sổ bàn giao). Quy ước: vá chuỗi có đếm số lần (`rep` assert), bump phiên bản ở `"24.17.xx"` ×2 + sw.js + manifest; mỗi lần đổi nguồn gd28 thì lưu bản cũ thành gd28_vNN.js trước.

## 5. Quy tắc nghiệp vụ đã chốt (P06)
Q23 +/- KH quý = (Ngày BC − Đầu quý) − KH quý; Q24 cán bộ ngoài danh mục ở nhóm riêng trước TỔNG, không khớp tên gần đúng; Q25 danh mục bị chia → theo từng KH mọi mốc (KH đã tất toán → người nhận chính); Q26 sổ bàn giao app gợi ý, người dùng xác nhận; Q27 mẫu hồ sơ nạp bằng Bộ hồ sơ (mở file://); Q28 GĐ3 áp toàn chi nhánh, chốt 31/10; Q29 hiệu lực bàn giao 01/10/2026. Dòng PHÒNG = Σ cán bộ (đúng bản in), không gom theo phòng của khế ước. Bàn giao khác ngày áp nối tiếp theo ngày, cùng ngày đồng thời; kế hoạch chuyển đồng thời từ số đầu ngày.

## 6. Rủi ro / lưu ý
- Nhãn mốc Lưu trữ có thể sai (mốc "30/09" thực chất là tệp đầu tháng 10 đã sau bàn giao): chọn ngày hiệu lực thực tế SAU ngày mốc gợi ý; kiểm cảnh báo mốc ở Lưu trữ.
- Đổi cách đếm: tổng KH cộng theo cán bộ có thể lệch 1–2 so với KH duy nhất vì khách vay ở 2 cán bộ.
- Bố cục bảng lưu trong máy người dùng được đổi thứ tự cột MỘT lần (cờ l31); không bump REV để khỏi mất bộ lọc/độ rộng.
- Không đưa tên cán bộ vào repo/ZIP (log hồi quy đã che CBxx); chạy quét riêng tư trước khi đóng gói.
