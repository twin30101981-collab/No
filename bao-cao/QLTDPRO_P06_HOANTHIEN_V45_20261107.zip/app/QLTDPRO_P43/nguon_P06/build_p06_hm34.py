# P06 · v24.17.45 — từ v24.17.44 (người dùng 07/11, ảnh màn hình: "chưa thay đổi vị trí giữa hai bảng"):
#  trang Chỉ tiêu KH → tab BÁO CÁO NGÀY: thanh Phạm vi/Mốc so sánh/kiểm tổng → BẢNG BÁO CÁO → "Kế hoạch quý" + "Xuất 4 bảng/Đối soát" → "Sổ bàn giao cán bộ" (cuối).
# Chạy từ app/QLTDPRO_P43/:  python3 nguon_P06/build_p06_hm34.py   (cần v24.17.44)
import hashlib
SRC = 'app/QLTDPRO_v24.17.44.html'; DST = 'app/QLTDPRO_v24.17.45.html'
s = open(SRC, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old); assert c == n, ('anchor', c, n, old[:100]); s = s.replace(old, new)
a = s.index('<script id="gd28-js">'); b = s.index('</script>', a) + len('</script>\n')
s = s[:a] + '<script id="gd28-js">\n' + open('nguon_P06/gd28.js', encoding='utf-8').read() + '\n</script>\n' + s[b:]
# tách khối kh-host khỏi vị trí cũ (ngay sau tiêu đề) rồi đặt SAU bảng cùng vùng bg-so-host
i = s.index('o.jsx("div",{className:"no-print","data-testid":"kh-host"'); j = s.index(',o.jsx("div",{className:"no-print","data-testid":"bg-host"', i)
kh = s[i:j]; assert kh.count('QLTDKH.panel') == 1 and kh.endswith('})}})'), kh[-30:]
s = s[:i] + s[j + 1:]
tail = ',o.jsxs("p",{className:"no-print text-xs text-muted-foreground",children:["💡 ",o.jsx("b",{children:"Đầu năm / Đầu quý / Đầu tháng"})'
rep(tail, ',' + kh + ',o.jsx("div",{className:"no-print","data-testid":"bg-so-host"})' + tail)
c = s.count('"24.17.44"'); assert c == 2, c
s = s.replace('"24.17.44"', '"24.17.45"')
open(DST, 'w', encoding='utf-8').write(s)
for f in ('app/sw.js', 'app/manifest.json'):
    t = open(f, encoding='utf-8').read(); assert '24.17.44' in t, f
    open(f, 'w', encoding='utf-8').write(t.replace('24.17.44', '24.17.45'))
print('OK', DST, 'md5', hashlib.md5(s.encode()).hexdigest())
