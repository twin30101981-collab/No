# BÀN GIAO — QLTDPRO — Phiên P04 (ĐANG MỞ) — 2026-11-05
Skill: web-app-repair-upgrade v3.2.0 | Chế độ: 3 | P04: HM-12, HM-18, **HM-14 (+14b)** DAT_V3. **Bản hiện hành v24.17.26.** Đề án v1.2 DA_DUYET (Đợt 5).

## 0m. HM-23 + HM-24 — v24.17.26 (06/11) — DAT_V3 (evidence/hm23/BAO_CAO.md)
Mốc TSBĐ tự lưu theo ngày tệp vào kho kv của QLTDProTSBD (moc_<ngày>, ≤ 120; bản cũ tạo từ dữ liệu hiện hành); tab "🆕 TS chưa có HĐTD" (Phòng → Cán bộ, mới / đã có HĐTD / không còn, danh sách + Excel); tab "📅 Đầu kỳ & 2 mốc" (bảng như Báo cáo ngày + chọn 2 mốc tự lưu/bấm tay). V3 25/25; hồi quy 1338 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ). Kế tiếp: HM-21 (xếp cán bộ theo phòng như Báo cáo ngày ở mọi trang, kể cả 2 tab mới) → HM-07…HM-10.

## 0l. Đợt 6 (người dùng 06/11) — HM-21…HM-24; HM-22 xong — v24.17.25 (evidence/hm22/BAO_CAO.md)
Quyết định: HM-21 "Cả hai" (cán bộ theo phòng như Báo cáo ngày ở mọi trang + dòng cũ → mới); HM-22 Số GN ghép msit80; HM-23 chỉ TS "chưa có hồ sơ"; HM-24 "Cả hai" (bảng như Báo cáo ngày + chọn 2 mốc).
HM-22: cột Số TS, Số HĐ thế chấp (plgno), Số giải ngân (khế ước còn dư nợ, ghép mã KH/mã chủ TS), Địa chỉ TS bật mặc định sau Mã KH; bố cục cũ chuyển 1 lần (l22). V3 6/6 (v24.17.24 1/5); hồi quy 1313 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ).
Kế tiếp: HM-23 + HM-24 (Q16 đã chốt: mốc TSBĐ tự lưu theo ngày tệp + giữ bấm tay) → HM-21.

## 0k. HM-06 Bố cục bảng rộng — DAT_V3, KHÔNG đổi app (v24.17.24) (evidence/hm06/BAO_CAO.md)
6 trang × 1366/390/360 + tệp chữ dài liền: 0 tràn ngang tài liệu, 0 phần tử lòi ngoài khung cuộn, 0 nút bị che vĩnh viễn (21/21). Kế tiếp: HM-07…HM-10.

## 0j. HM-05 Lỗi bị nuốt — v24.17.24 (05/11) — DAT_V3 (evidence/hm05/BAO_CAO.md)
84 catch rỗng lớp vá: 79 chấp nhận, 5 có hại → thông báo qua gd9Toast: H1 mốc giữa kỳ (Khách hàng mới), H2 Lưu trữ cho lãi theo đoạn (+ H2b từng mốc), H3 khung Phương án SXKD (nạp/tự lưu/lưu). V3 5/0/1 SKIP (H3 chỉ kiểm tĩnh); v24.17.23 FAIL H1a, H2. Hồi quy 1286 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ; SKIP 5 gồm H3). Cài: QLTDPRO_v24.17.24.html + sw.js + manifest.json. Kế tiếp: HM-06…HM-10.

## 0i. HM-04 Đầu vào không tin cậy — DAT_V3, KHÔNG đổi app (v24.17.23) (evidence/hm04/BAO_CAO.md)
Tệp thử 40 dòng, 8 trường × 5 kiểu chuỗi tấn công, nạp qua #/nhap: 8 trang hiển thị dưới dạng chữ, bấm 9 khung gd7, Máy tính lãi 6 khách, rê chuột 60 ô → 0 mã chạy, 0 phần tử bị chèn, 0 pageerror (5/5). Rà tĩnh: JSX tự thoát; dangerouslySetInnerHTML duy nhất là HTML cố định; lớp vá dùng esc/escapeHtml/textContent. Chưa phủ động: Khách hàng mới, Hồ sơ vay. Kế tiếp: HM-05…HM-10.

## 0h. HM-03 Lớp lưu trữ — v24.17.23 (05/11) — DAT_V3 (evidence/hm03/BAO_CAO.md)
Kiểm kê động: 8 CSDL IndexedDB (QLTDProDB v3, TWIN_Archive_v1, QLTDProGD9 = bản sao localStorage, QLTDPro2Undo, QLTDProTSBD, QLTDKhachHangMoi, QLTDProMauHsvx, QLTDProFolder_v1) + khóa localStorage. Sao lưu toàn bộ → khôi phục ở trình duyệt sạch: trùng 100%. JSON hỏng / thiếu khóa / dữ liệu cũ / đầy bộ nhớ: 0 lỗi, dư nợ còn nguyên. Thêm gd21: báo rõ khi bộ nhớ đầy. V3 19/19 (v24.17.22: 18/19). Sửa bộ kiểm p52 (R2 chập chờn). Hồi quy 1275 PASS · 1 FAIL (p52_ma_kh R2 chập chờn — bắt 13 số trong mã băm SHA-256 ở title; đã sửa bộ kiểm p52 bỏ chuỗi hex → chạy lại 3/3 lần 14/0) ⇒ 0 FAIL do HM-03; LOI_MT p41/p42_gd14 như cũ.
Đề xuất chờ duyệt: chuyển _prevDunoSnap (~300 KB) sang IndexedDB; nút "Xoá các mục hỏng" (thông báo gd9 trỏ tới công cụ chưa có). Kế tiếp: HM-04…HM-10.

## 0g. HM-20b — v24.17.22 (05/11): xếp cán bộ theo phòng GIỐNG Báo cáo ngày (người dùng; thay Q13 cũ)
Tổng phòng / tab Theo phòng = cộng cán bộ theo danh mục cán bộ (như Báo cáo ngày). V3 31/31 (X1 thứ tự phòng→cán bộ trùng Báo cáo ngày; X2–X4 số khớp Python theo ofcnm); hồi quy 1257 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ). Lưu ý: khác trang Khách hàng mới (theo trctnm); PGD HBT = 0 trên dữ liệu thử vì danh mục chưa có cán bộ thuộc PGD HBT. Cài: QLTDPRO_v24.17.22.html + sw.js + manifest.json. Kế tiếp: HM-03…HM-10.

## 0f. HM-20 Chỉ tiêu kế hoạch — v24.17.21 (05/11) — DAT_V3 (evidence/hm20/BAO_CAO.md)
Q14: nhãn mốc "Đầu Q4/2026 (số dư 30/09/2026)", "Đầu T11/2026 (số dư 31/10/2026)"; Δ đầu tháng so số dư cuối tháng trước. Q13: tổng phòng gom theo trctnm khế ước. gd20: nhóm chỉ tiêu (mặc định Dư nợ), chỉ Live/%HT, Δ so mốc, ẩn chỉ tiêu toàn 0, cột tên dính, thẻ điện thoại. V3 27/27; hồi quy 1252 PASS · 1 FAIL (p52_ma_kh R2 chập chờn đã biết — mã băm hex trong title #/nhap-du-lieu; chạy lại: lần 1 vẫn FAIL đúng ca R2 với mã băm khác, lần 2 đạt 14/0 — lỗi bộ kiểm, không do HM-20) ⇒ 0 FAIL do HM-20; LOI_MT p41/p42_gd14 như cũ.
Mở: xếp CBTD theo phòng khế ước? (danh mục thử: PGD HBT 0 CBTD nhưng 586,6 tỷ dư nợ khế ước); Excel chưa có cột kiểm tra. Kế tiếp: HM-03…HM-10. Cài: chép QLTDPRO_v24.17.21.html + sw.js + manifest.json.

## 0e. L-07 + sửa giá đất — v24.17.20 (05/11) — DAT_V3 (evidence/l07/BAO_CAO.md)
Bảng trang Lãi đọng: mặc định 8 cột (vừa 1366; 5 cột còn lại ở "Cột ▾"; bố cục đã lưu chuyển 1 lần), hàng lọc gom vào nút "Lọc theo cột (n)", nút/ô ≥ 28/40 px, vạch màu theo ngày chậm lãi (1–30/31–90/>90), bỏ chữ đỏ cả dòng. Giá đất: Vũ Xuân Thiều TB VT1 55.000, VT2 33.000. V3 32/32 (v24.17.19: 6 FAIL); hồi quy 1226 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ). Cài: chép QLTDPRO_v24.17.20.html + sw.js + manifest.json.
Kế tiếp đề xuất: HM-20 (Chỉ tiêu kế hoạch) → HM-03…HM-10; tùy chọn: nạp bảng giá nhà nước NQ38/2025.

## 0d. Đối soát bảng giá đất 2026 (05/11) — evidence/gia_dat/BAO_CAO.md
App (985 dòng, 8 phường) = PL02 (Báo cáo tư vấn 275/2026, 16/03/2026): 0/11.820 ô lệch; 6 dòng lệch chính tả (app đúng); 22 dòng chỉ PL02 đều không có giá (9 tiêu đề nhóm, 13 "chưa hoàn thiện"). Lỗi nguồn: Vũ Xuân Thiều STT 212 TB VT1 28.000 (đúng 55.000), VT2 16.800 (đúng 33.000) — app mang theo; CHỜ người dùng xác nhận sửa. NQ38/2025 (giá nhà nước) chưa có trong app.

## 0c. HM-19 + HM-13 — v24.17.19 (05/11) — DAT_V3 (evidence/hm19/BAO_CAO.md)
Một lối vào "Máy tính lãi" (bỏ nút Tính lãi tất toán; GD14.openAllot giữ làm API), bảng Gọn 9 cột + nút Đầy đủ, tổng dính đầu, thẻ trên điện thoại (có "Chọn tất cả khoản"), danh sách tìm ghi khế ước + đến hạn, bảng phân rã lãi dd/mm/yyyy, ghi chú nguồn 3 tổng trang Lãi đọng. V3 36/36; HM-14 49/49; hồi quy 1194/0. Sửa 5 bộ kiểm cũ theo thiết kế mới (nút tất toán, M8).
Còn: L-07 bảng trang Lãi đọng (bundle). Cài: chép QLTDPRO_v24.17.19.html + sw.js + manifest.json.
**Việc kế (người dùng 05/11): đối soát bảng giá đất 2026** — bảng trong app đã trích: evidence/gia_dat/BANG_GIA_DAT_TRONG_APP_v24.17.19.xlsx (kiem_thu_p04/trich_bang_gia_dat.py; 8 phường, 985 dòng, nghìn đ/m², VT1–VT4 × cao/thấp/TB). Chờ tệp "Bảng giá đất Thành phố Nam Định cũ.zip" (Drive bị chặn).

## 0b. HM-14b — v24.17.18 (05/11): Q15 chốt (toàn dư nợ gốc; kỳ = nxtrpmtschddt, không mặc định → kỳ chọn tay không giữ sang khách khác, cảnh báo khoản trung/dài thiếu lịch); Q7 còn mở → cột Chênh IPCAS thử mốc ngày đến hạn kỳ/gốc. Lõi 229/229, V3 49/49, hồi quy 1159 PASS · 1 FAIL (p52_ma_kh R2 chập chờn đã biết — mã băm hex ngẫu nhiên trong title #/nhap-du-lieu; chạy lại 2 lần 14/0) ⇒ 0 FAIL do HM-14b; LOI_MT p41/p42_gd14 như cũ. ZIP QLTDPRO_P04_HM14B_20261105.zip. Cài: chép QLTDPRO_v24.17.18.html + sw.js + manifest.json.

## 0a. P04 tiếp — HM-14 (Máy tính lãi chính xác số liệu) — DAT_V3 (chi tiết: evidence/hm14/BAO_CAO.md)
- **Bản hiện hành: app/QLTDPRO_P43/app/QLTDPRO_v24.17.17.html** (v24.17.16 → .17 bằng nguon_P04/build_p04_hm14.py). sw.js/manifest 24.17.17.
- Lõi qltd_lai.cjs GIỮ BYTE (sha256 55908dc6…); mô-đun mới nguon_P04/qltd_lai_hm14.cjs (QLTDLai.hm14 1.0.0) gọi lại tinhLaiKhoan:
  Q12 (ngắn hạn/thấu chi không lãi chậm trả; trung/dài hạn quá kỳ trả lãi nxtrpmtschddt hoặc kỳ chọn 1/3/6 tháng → LS×1,5 từ ngày kỳ),
  lãi theo đoạn dư nợ từ mốc Lưu trữ (+ lstrpmtdt), cột CHÊNH IPCAS (lãi app đến ngày dữ liệu − intamt), cảnh báo ngày chốt.
  Lãi dự thu trang Lãi đọng + công cụ Tính lãi tất toán dùng cùng tinhLaiQ12.
- Kiểm: lõi 224/224 (200 khoản đồng nhất với hàm cũ), V3 43/43 (1366 + 390, 0 pageerror), v24.17.16 FAIL 7 ca; lõi cũ 18/18 + 11/11.
  Hồi quy chung trước (v24.17.16) 882 PASS · 0 FAIL; sau (v24.17.17): 1146 PASS · 3 FAIL (A10 "lãi chậm trả" ở p41_gd14/p42_gd14/p42_mtl_gd14 — khoản ngắn hạn, Q12 bỏ lãi chậm trả) → sửa kỳ vọng A10 → 3 bộ 75/0 ⇒ 1149 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ).
- Chưa đạt: đối chiếu ≥ 20 khoản chứng từ IPCAS thật (cần người dùng). Câu hỏi: Q15 đã chốt 05/11 (xem 0b); Q7 còn mở.
- **Kế tiếp đề xuất: HM-19 + HM-13 (cùng hộp Máy tính lãi/Lãi đọng) → HM-20 → HM-03…HM-10.**

# (P04 phần trước)
## 0. P04 — tóm tắt
- **Bản hiện hành: app/QLTDPRO_P43/app/QLTDPRO_v24.17.16.html** (v24.17.14 → .15 build_p04_hm12.py → .16 build_p04_hm18.py). sw.js/manifest 24.17.16.
- HM-18 DAT_V3: gd15 1.3.0 (layR dùng chung) + gd16 1.0.0 (KPI/Tổng hợp/biểu đồ theo lõi, KPI bấm → chi tiết, CSS chữ/nút). evidence/hm18/BAO_CAO.md. Bộ kiểm kiem_thu_p04/test_hm18_khm_toan_trang.py (danh_muc p04_hm18). Hồi quy 881/1 → sửa kỳ vọng p03_hm17 T3 theo Q11 → 3 bộ 56/0.
- Kế tiếp: HM-14 (Máy tính lãi chính xác; áp Q12) → HM-19 + HM-13 → HM-20.
- HM-12: lõi QLTD_DSTN 1.1.0 (cộng thêm k.moc), gd15 1.2.0 (ô bấm → chi tiết, lọc, Excel 4 sheet). Chi tiết: evidence/hm12/BAO_CAO.md. Bộ kiểm: kiem_thu_p04/test_hm12_chi_tiet.py (đã thêm danh_muc p04_hm12). Hồi quy trước 829/0.
- Đề án v1.2: de-an/DE_AN_QLTDPRO_v1.2.docx (evidence/build_de_an_v12.js). Khảo sát điểm nghẽn (chỉ đọc) kiem_thu_p04/khao_sat_khm_lai.py, khao_sat_ctkh_tab.py → evidence/khao_sat_p04/.
- Phát hiện chính: KPI Thu nợ trang KH mới 528,31 tỷ (suy ra) ≠ Đối soát 544,70 tỷ; GN 50,66 tỷ/110 món ≠ 63,33 tỷ/124 món; Máy tính lãi 2 lối vào, 3 tổng lãi khác nhau; Chỉ tiêu kế hoạch 48 cột, cột tên không dính, gom phòng theo danh mục CB ≠ phòng khế ước, nhãn "Đầu Q3" = số dư 30/09.
- Câu hỏi mở: Q11–Q14 (backlog.quyet_dinh_nghiep_vu_mo).
- Thứ tự đề xuất: HM-12 (đóng) → HM-18 → HM-14 → HM-19+HM-13 → HM-20 → HM-03…HM-10.

# (Bản P03 bên dưới giữ để tra cứu)
## BÀN GIAO P03 (ĐÓNG PHIÊN) — 2026-11-05
Skill: web-app-repair-upgrade v3.2.0 | Chế độ: 3 | Lý do đóng: chạm ngưỡng ngữ cảnh sau HM-16. Trong P03: HM-11b, HM-17, HM-16 đều DAT_V3. Kế tiếp: HM-12.

## 1. Dự án và môi trường
Loại app: HTML đơn tệp + PWA (bundle React/Vite đã nén + lớp vá gd3–gd15) | **Bản hiện hành: app/QLTDPRO_P43/app/QLTDPRO_v24.17.14.html** (v24.17.11 → .12 build_p03_hm11b.py → .13 build_p03_hm17.py → .14 build_p03_hm16.py). v24.17.9–.13 giữ trong app/ làm đối chứng.
Chạy app: `cd app/QLTDPRO_P43/app && python3 -m http.server 8765` → http://localhost:8765/QLTDPRO_v24.17.14.html
Hồi quy chung: `cd app/QLTDPRO_P43 && python3 kiem_thu_chung/chay_hoi_quy.py --app app/QLTDPRO_v24.17.14.html [--chi id,id]` (đã có bộ p03_hm11b, p03_hm17).
Môi trường P03: Node v22.23.4; `pip install playwright==1.63.0 xlrd` (Chromium 153 /opt/pw-browsers); pandas, openpyxl có. V3_KHA_DUNG: có.
Quy ước: vá chuỗi chính xác có đếm số lần; style trong <style>; không đổi CSP, 4 CSDL; tiếng Việt.

## 2. Đề án và trạng thái (khớp backlog.json)
Đề án v1.1 — DA_DUYET — de-an/DE_AN_QLTDPRO_v1.1.docx. Điều chỉnh nhỏ: HM-15 (P02), **HM-16 (P03, phát hiện khi kiểm HM-11b trên dữ liệu thật)**.
Thứ tự còn lại: **HM-12 → HM-14 → HM-13 → HM-03…HM-10**.
| ID | Tên | Ưu tiên | Effort | Trạng thái | Bậc |
|----|-----|---------|--------|------------|-----|
| HM-01 | Bộ chạy hồi quy chung | P1 | M | DA_BAN_GIAO | V3 |
| HM-02 | Lỗi đọc ngày dd/mm qua mọi đường đọc tệp | P1 | S | DA_BAN_GIAO | V3 |
| HM-03…HM-10 | (xem backlog.json) | P1–P3 | — | CHUA_LAM | — |
| HM-11a | Lõi QLTD_DSTN + đối chiếu msit80 thật | P1 | M | DAT_V2 | V2 |
| HM-11b | Gắn QLTD_DSTN vào trang Khách hàng mới (bảng Phòng → Cán bộ) | P1 | M | DAT_V3 | V3 |
| HM-12 | Màn hình GN/thu nợ phòng → cán bộ, bấm số tiền xem chi tiết, xuất Excel | P1 | M | CHUA_LAM | — |
| HM-13 | Máy tính lãi: giao diện | P2 | M | CHUA_LAM | — |
| HM-14 | Máy tính lãi: chính xác số liệu | P1 | M | CHUA_LAM | — |
| HM-15 | Tệp TSBĐ .csv nhận nhầm loại | P1 | S | DA_BAN_GIAO | V3 |
| HM-16 | Lưu trữ bỏ khế ước dư nợ 0 → thiếu GN trả hết trong kỳ | P1 | S | DAT_V3 | V3 |
| HM-17 | Trang KH mới tính trùng GN khi khế ước đổi HĐTD (thừa 638,76 tỷ) | P0 | S | DAT_V3 | V3 |

## 3. Hạng mục vừa đóng: HM-11b — DAT_V3 (chi tiết: evidence/hm11b/BAO_CAO.md)
Làm: gd11 xuất API chỉ đọc Lưu trữ; chèn lõi QLTD_DSTN 1.0.1 + lớp vá gd15 (nguon_P02/gd15.js). Tab Đối soát: lấy mốc đầu/cuối đã chọn ở "Nạp từ Lưu trữ" + MỌI mốc ở giữa → bảng Phòng → Cán bộ (Đầu, số món GN, GN, Thu, Điều chỉnh, Cuối, Kiểm tra, số KƯ, tất toán), cảnh báo thiếu mốc; bảng cũ "Thu nợ suy ra" ẩn (nút xem lại); tệp chọn tay → thông báo, giữ bảng cũ. window.__khmDstn cho HM-12.
Kiểm chứng: V3 dữ liệu thử ẩn danh (kiem_thu_p03/tao_mis80_thu.py) **25/25 PASS** (desktop 1366 + điện thoại 390, 0 pageerror) — số màn hình = công cụ doi_chieu_mis80 0 đồng mọi phòng/cán bộ. Hồi quy chung trước/sau: 799 PASS · 0 FAIL (y hệt).
Dữ liệu thật (11 tệp người dùng gửi, chỉ ở thư mục tạm): **23/25** — lệch GN/thu (chuỗi 10 món 7,419 tỷ; 2 mốc 11 món 3,625 tỷ) do mốc Lưu trữ bỏ dòng dư nợ 0; lõi trên dữ liệu đã lọc dư nợ 0 khớp app 0 đồng, 0/7.065 khế ước lệch → HM-16.

## 3b. Hạng mục vừa đóng: HM-17 — DAT_V3 (chi tiết: evidence/hm17/BAO_CAO.md)
Gốc: buildReport + gd11.loadMidSnaps so khế ước giữa kỳ với mốc cuối theo brcd|apprseq|dsbsseq → khế ước đổi HĐTD sinh dòng "tất toán" giả. Sửa: khóa = dsbsseq (2 điểm; dấu tích KH mới giữ khóa cũ). V3: thử v24.17.12 2/5 → v24.17.13 5/5; thật 5/5 (5.957 món / 3.901,32 tỷ, trước 7.057 / 4.538,67). Hồi quy 828 PASS · 1 FAIL p52 R2 chập chờn (chạy lại: lần 1 vẫn FAIL đúng ca R2 với mã băm khác, lần 2 đạt 14/0 — lỗi bộ kiểm, không do HM-20; lỗi nền). Chưa đổi: khế ước tất toán vẫn gán cán bộ ở mốc cuối nó xuất hiện.

## 3c. Hạng mục vừa đóng: HM-16 — DAT_V3 (chi tiết: evidence/hm16/BAO_CAO.md)
Gốc: k4() ở Nhập dữ liệu loại dòng dư nợ 0, Zf() chỉ lưu dòng còn lại. Sửa: lưu khóa phụ rpt0_<timestamp> (mốc chính/KPI không đổi), gd15 1.1.0 gộp, cảnh báo mốc cũ cần nhập lại. V3: thử v24.17.13 23/25 → v24.17.14 25/25; thật 25/25 (0 đồng); hồi quy 829/0.

## 4. Hạng mục kế tiếp: HM-12 — màn hình GN/thu nợ phòng → cán bộ, bấm số tiền xem chi tiết từng khế ước, xuất Excel đối soát
Bước đầu: dùng window.__khmDstn (R.khe: dauKy, gn, gnMon, thu, dieuChinh, cuoiKy, cachTinh, gan, cbTen, phong) trong lớp vá gd15 (nguon_P02/gd15.js → build mới từ v24.17.14); ô số trong bảng khm-dstn-t bấm được → danh sách khế ước; xuất Excel cùng 4 sheet như kiem_thu_p02/doi_chieu_mis80.py (Phòng, Cán bộ, Chi tiết khế ước, Ghi chú). Kiểm V3 bằng test_hm11b_dstn.py (mở rộng) trên dữ liệu thử + thật.

## 5. Việc dở dang chính xác
Không có.

## 6. Quyết định đã chốt (không đảo ngược nếu chưa có bằng chứng mới)
- Giữ app đơn tệp, ngoại tuyến, CSP chặn mạng; không đổi 4 CSDL IndexedDB.
- Không đổi quy tắc lãi (365; quá hạn = LS×1,5 theo ngày đến hạn từng khoản GN; tròn từng phần) khi chưa có căn cứ.
- Không viết lại app; tính năng mới chỉ theo đề án đã duyệt (v1.1).
- HM-01: hồi quy chạy trên bản soi; bí danh tên HTML cũ; đối chứng = bản liền trước; ca nhãn bản cũ xếp LECH_PB có lý do.
- HM-02: tệp văn bản đọc thô (raw) ở mọi đường nạp có đọc ngày; tệp nhị phân không đổi.
- HM-11b: tích hợp lõi bằng lớp vá gd15 (không sửa bundle); chỉ ĐỌC Lưu trữ qua window.__gd11Api; quy tắc gán khế ước tất toán giữ như lõi 1.0.1 (người dùng 05/11: giữ tới khi nói khác).

## 7. Lỗi nền / ngoài phạm vi / đề xuất
- **HM-16 (mới, P1):** mốc Lưu trữ bỏ khế ước dư nợ 0 → GN trả hết trong kỳ không được tính (đã xác minh trên dữ liệu thật).
- 404 HEAD mẫu Bảng kê mua hàng.docx (HM-07).
- Chromium container sập khi tải lại trang có handle thư mục → p41_gd14/p42_gd14 dừng giữa chừng; chạy trên Chrome thường.
- Gói thiếu kiem_thu_p40/zip/ → runner sinh lại (zip + xlsx cùng lần) trên bản soi.

## 8. Việc người dùng cần làm
- Mở phiên mới cho HM-12: dán PROMPT_PHIEN_SAU.md (ZIP QLTDPRO_P03_HM16_20261105.zip có sẵn trong repo bao-cao/).
- Sau khi cài v24.17.14: **nhập lại các tệp msit80** (mốc cũ không có dòng dư nợ 0 — bảng Đối soát sẽ cảnh báo).
- Kiểm tay v24.17.13: Khách hàng mới → Nạp từ Lưu trữ 31/12/2025 → 31/10/2026 → Lập báo cáo: Doanh số cho vay ≈ 5.957 món (không còn khế ước lặp ở Chi tiết/Excel); báo lại nếu Lưu trữ máy bạn cho số khác (bản bạn xuất, bỏ trùng = 5.941).
- Kiểm tay v24.17.12: Nhập dữ liệu các tệp msit80 cuối tháng → Khách hàng mới → 📥 Nạp từ Lưu trữ (đầu 31/12/2025, cuối 31/10/2026) → Lập báo cáo → tab Đối soát: thấy bảng Phòng → Cán bộ, "11 mốc", Kiểm tra = 0; so với Excel DOI_SOAT_DSTN (biết trước lệch GN ~7,4 tỷ do HM-16).
- Cài v24.17.14: chép HTML + sw.js + manifest.json.

## 9. Đường lui: ZIP HM17 (v24.17.13), HM11B (v24.17.12), HM-11a (v24.17.11). Cũ hơn: HM-15 (v24.17.11), HM-02 (v24.17.10), HM-01 (v24.17.9)
## 10. File đã chạm trong phiên P03
Tạo: nguon_P02/gd15.js, nguon_P02/build_p03_hm11b.py, nguon_P02/build_p03_hm17.py, nguon_P02/build_p03_hm16.py, app/QLTDPRO_v24.17.12.html, app/QLTDPRO_v24.17.13.html, app/QLTDPRO_v24.17.14.html, evidence/hm16/, kiem_thu_p03/test_hm17_trung_gn.py, evidence/hm17/, kiem_thu_p03/tao_mis80_thu.py, kiem_thu_p03/test_hm11b_dstn.py, evidence/hm11b/. Sửa: app/sw.js, app/manifest.json (24.17.14); sửa kiem_thu_p03/tao_mis80_thu.py (+dòng dư nợ 0), kiem_thu_chung/danh_muc.json (+p03_hm11b, p03_hm17), handover/*.
## 11. Nhật ký ngắn
- S-OPEN P03 2026-11-05: giải nén ZIP HM-11a, MANIFEST 238/238 khớp; skill v3.2.0. Người dùng đã chọn HM-11b (làm ngay). Môi trường: cài playwright 1.63.0 + xlrd; V3 có.
- Hồi quy trước (v24.17.11): 799/0.
- gd15 + build → v24.17.12; dữ liệu thử 3 mốc; sửa bộ sinh ghi ô ngày (công cụ Python cần ô ngày như tệp thật). V3 thử 25/25.
- Người dùng gửi 11 tệp msit80 thật giữa chừng → V3 thật 23/25; khoanh: dòng dư nợ 0 bị bỏ ở Lưu trữ (xác minh 0/7.065 khế ước lệch sau lọc) → thẻ HM-16.
- Hồi quy sau (v24.17.12): 799/0. HM-11b DAT_V3; dựng QLTDPRO_P03_HM11B_20261105.zip.

## NHẬT KÝ HM-02 (write-ahead)
- 14:01 người dùng chọn ①: HM-01 DA_BAN_GIAO; Đợt 4 (HM-11…HM-14) DA_DUYET; mở HM-02.
- 14:05 tái hiện V3: TSBĐ văn bản .xls đảo ngày ≤ 12 (D1b FAIL); dư nợ văn bản đúng (E1 PASS); TSBĐ .csv nhận nhầm Dư nợ (thẻ mới HM-15). Gốc: worker aoa đọc cellDates:true không raw.
- 14:09 đã sửa: nguon_P02/build_p02_hm02.py → v24.17.10 (aoa raw:!0). test_hm02: v24.17.9 9/10 (D1b FAIL), v24.17.10 10/10. Thêm thẻ HM-15. Chạy hồi quy chung trên v24.17.10.
- HM-02 đóng: DAT_V3; dựng QLTDPRO_P02_HM02_20261104.zip.

## NHẬT KÝ HM-15 (write-ahead)
- 23:07 người dùng chọn HM-15: HM-02 DA_BAN_GIAO; mở HM-15 (tệp TSBĐ .csv nhận nhầm Dư nợ).
- 23:10 gốc: bước dò tiêu đề chỉ chạy .xls/.xlsx/.xlsm. Sửa nguon_P02/build_p02_hm15.py → v24.17.11 (+csv). test_hm15: v24.17.10 8/12 → v24.17.11 12/12. Chạy hồi quy chung v24.17.11.
- HM-15 đóng: DAT_V3; dựng QLTDPRO_P02_HM15_20261104.zip.
- S-CLOSE: chạm ngưỡng ngữ cảnh; người dùng chọn HM-11 → ghi làm kế tiếp, không mở trong P02; dựng QLTDPRO_P02_DONGPHIEN_20261104.zip.
- 05/11 người dùng trả lời Q4–Q6, Q10 + gửi 11 tệp msit80 thật; mở HM-11; phân tích R-01…R-07; tách HM-11a/HM-11b.
- Lõi qltd_dstn 1.0.0 → sửa quy tắc GN với mốc giữa thiếu dòng (U15) → 1.0.1 sửa mã KH = brcd (phát hiện trên dữ liệu thật, U21). Đối chiếu thật 0 đồng. HM-11a DAT_V2; dựng QLTDPRO_P02_HM11A_20261105.zip.
- 05/11 người dùng gửi 2 báo cáo app xuất (dữ liệu thật, chỉ thư mục tạm): phát hiện GN trùng 1.116 món/638,76 tỷ do đổi HĐTD; dư nợ cuối 18/18 cán bộ khớp lõi. Người dùng chọn ①: mở HM-17 (P0), sau đó HM-16.
- HM-17: tái hiện v24.17.12 2/5 → sửa build_p03_hm17.py → v24.17.13 5/5 (thử + thật). Hồi quy 828/1 (p52 chập chờn, chạy lại đạt). HM-17 DAT_V3; dựng QLTDPRO_P03_HM17_20261105.zip. Ngữ cảnh vùng Vàng → đề nghị đóng phiên, HM-16 ở phiên P04.
- 05/11 người dùng chọn HM-16 ngay trong P03 (vùng Vàng): mở HM-16.
- HM-16: tái hiện v24.17.13 23/25 → build_p03_hm16.py → v24.17.14 25/25 (thử + thật). Hồi quy 829/0. HM-16 DAT_V3. S-CLOSE (ngưỡng ngữ cảnh): dựng QLTDPRO_P03_HM16_20261105.zip (kiêm ZIP đóng phiên).

## NHẬT KÝ P04 (write-ahead)
- 14:05 S-OPEN P04: MANIFEST 267/267 khớp; cài xlrd; hồi quy trước v24.17.14 829/0.
- HM-12: lõi 1.1.0 (23/23), gd15 1.2.0, build v24.17.15; V3 thử 28/28; v24.17.14 1/4.
- 14:21 người dùng bổ sung đề án: KH mới toàn trang, Máy tính lãi → HM-18, HM-19; 14:25: Chỉ tiêu kế hoạch → HM-20. Khảo sát Playwright chỉ đọc; đề án v1.2 CHỜ DUYỆT.
- HM-12 hồi quy sau v24.17.15: 859 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ). HM-12 DAT_V3; dựng QLTDPRO_P04_HM12_20261105.zip.
- 15:23 người dùng: duyệt Đợt 5 (v1.2 DA_DUYET); Q11 cả GN mới + GN thêm món cũ; Q12 ngắn hạn không lãi chậm trả, trung/dài hạn quá hạn 150% khi đến kỳ chưa trả đủ lãi; Q13 phòng theo khế ước; Q14 số dư cuối kỳ trước trong Lưu trữ; thứ tự theo đề xuất → HM-12 DA_BAN_GIAO, mở HM-18.
- HM-18: v24.17.16 thử 23/23 (v24.17.15 FAIL A1/A2/A4); hồi quy 881/1 (p03_hm17 T3 kỳ vọng cũ) → sửa test → 56/0. DAT_V3; dựng QLTDPRO_P04_HM18_20261105.zip.
- HM-14 (05/11, phiên tiếp P04 trong container mới): giải nén ZIP HM18, MANIFEST khớp (trừ 4 HTML cũ v24.17.8–.11 không có trong gói); cài playwright 1.63.0 + xlrd.
  Hồi quy trước v24.17.16 882/0. Mô-đun qltd_lai_hm14 1.0.0 + build_p04_hm14 → v24.17.17. Lõi 224/224; V3 43/43 (v24.17.16: 7 FAIL). Hồi quy sau 1146 PASS · 3 FAIL (A10 "lãi chậm trả" ở p41_gd14/p42_gd14/p42_mtl_gd14 — khoản ngắn hạn, Q12 bỏ lãi chậm trả) → sửa kỳ vọng A10 → 3 bộ 75/0 ⇒ 1149 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ). DAT_V3; dựng QLTDPRO_P04_HM14_20261105.zip.
- 05/11 người dùng trả lời Q15 (a toàn dư nợ gốc; b nxtrpmtschddt, không mặc định), Q7 (chưa rõ, có thể đến ngày đến hạn) → HM-14b build_p04_hm14b → v24.17.18; lõi 229/229, V3 49/49; hồi quy 1159 PASS · 1 FAIL (p52_ma_kh R2 chập chờn đã biết — mã băm hex ngẫu nhiên trong title #/nhap-du-lieu; chạy lại 2 lần 14/0) ⇒ 0 FAIL do HM-14b; LOI_MT p41/p42_gd14 như cũ.
- 05/11 HM-19 + HM-13: build_p04_hm19 → v24.17.19; V3 36/36; hồi quy 1194/0. Đối soát giá đất: đã trích bảng app; chờ tệp nguồn.
- 05/11 Đối soát giá đất 2026: ghép 2 phần ZIP người dùng; doi_soat_gia_dat.py → 979 khớp, 0 ô lệch giá, 6 lệch chữ, 22 dòng nguồn không giá; 1 lỗi TB ở nguồn (Vũ Xuân Thiều).
- 05/11 L-07 + giá đất 212: build_p04_l07 → v24.17.20; V3 32/32; hồi quy 1226 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ).
- 05/11 HM-20: build_p04_hm20 + gd20 → v24.17.21; V3 27/27 (v24.17.20 FAIL Q14a); hồi quy 1252 PASS · 1 FAIL (p52_ma_kh R2 chập chờn đã biết — mã băm hex trong title #/nhap-du-lieu; chạy lại: lần 1 vẫn FAIL đúng ca R2 với mã băm khác, lần 2 đạt 14/0 — lỗi bộ kiểm, không do HM-20) ⇒ 0 FAIL do HM-20; LOI_MT p41/p42_gd14 như cũ.
- 05/11 HM-20b: build_p04_hm20b → v24.17.22 (gom phòng như Báo cáo ngày); V3 31/31; hồi quy 1257 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ).
- 05/11 HM-03: kiểm kê + test_hm03 19/19; gd21 → v24.17.23; sửa p52 R2; hồi quy 1275 PASS · 1 FAIL (p52_ma_kh R2 chập chờn — bắt 13 số trong mã băm SHA-256 ở title; đã sửa bộ kiểm p52 bỏ chuỗi hex → chạy lại 3/3 lần 14/0) ⇒ 0 FAIL do HM-03; LOI_MT p41/p42_gd14 như cũ.
- 05/11 HM-04: test_hm04_xss 5/5 trên v24.17.23; không đổi app; đăng ký p04_hm04 (bộ chạy chung: p04_hm03 19/0, p04_hm04 5/0).
- 05/11 HM-05: build_p04_hm05 → v24.17.24; test_hm05 5/0/1; hồi quy 1286 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ; SKIP 5 gồm H3).
- 05/11 HM-06: test_hm06 21/21 trên v24.17.24; không đổi app; đăng ký p04_hm06.
- 06/11 Đợt 6: thêm HM-21…24; HM-22 build_p04_hm22 → v24.17.25; V3 6/6; hồi quy 1313 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ).
- 06/11 HM-23+24: gd23 + build_p04_hm23 → v24.17.26; V3 25/25; hồi quy 1338 PASS · 0 FAIL (LOI_MT p41/p42_gd14 như cũ).
