# HM-31 GĐ1 — Bàn giao cán bộ tín dụng (giai đoạn 1) — v24.17.35 — 07/11/2026

## Vấn đề (người dùng, 4 bảng in 31/10/2026)
Báo cáo ngày không tính được tăng/giảm và chỉ tiêu vì bàn giao cán bộ: app ra Đầu tháng = Ngày BC; Đầu năm/Đầu quý thiếu KH của cán bộ đã bàn giao hết.

## Nguyên nhân gốc (mã nguồn v24.17.34)
- N4: `s6` (Báo cáo ngày) gọi `P3(..., new Date)` → `E3` chọn mốc Đầu tháng/Đầu quý/Đầu năm theo NGÀY MÁY (07/11 ⇒ "đầu tháng" = 31/10 = chính ngày BC). Tab Trả nợ (`v3`) cũng `new Date`; D-1 so theo giờ nhập; mốc CT/CQ chỉ theo nhãn (tag).
- N2: `P3` chỉ duyệt cán bộ trong danh mục (`fn × members`) → cán bộ không còn trong danh mục mất khỏi TỔNG.
- N3: `Qv` gán tên lạ bằng `roster.match` (khớp viết tắt / 2 từ cuối) → có thể gộp nhầm người.
- N5: `I3`: "+/- KH quý" = Ngày BC − KH quý.

## Sửa (nguon_P06/build_p06_hm31.py + gd27.js, vá chuỗi có đếm)
- Ngày báo cáo = ngày dữ liệu (`_currentFileDate` / mốc đang xem) cho Báo cáo ngày và Trả nợ; Trả nợ dùng chung bộ chọn mốc `E3` (nhãn trước, rồi ngày cuối tháng/quý/năm của dữ liệu), ngày mốc theo ngày dữ liệu, D-1 theo ngày dữ liệu.
- Cán bộ ngoài danh mục → nhóm "CÁN BỘ ĐÃ BÀN GIAO / NGOÀI DANH MỤC" ngay trước TỔNG (người dùng chọn 07/11), vẫn cộng TỔNG; cảnh báo liệt kê tên. Bỏ khớp tên gần đúng.
- "+/- KH quý" (KH) và "+/- kế hoạch" (DN) = (Ngày BC − Đầu quý) − KH quý — người dùng chốt; khớp bảng in KHÁCH HÀNG mọi dòng (vd Tổng 1.871 − 1.890 − 36 = −55).

## Kiểm chứng V3 — số liệu THẬT (msit80 31/12/2025, 30/09/2026, 31/10/2026; không nằm trong repo/ZIP)
Bộ kiểm `kiem_thu_p06/test_hm31_bc_ngay.py` (đáp án pandas đọc thẳng tệp gốc; 3 cấu hình: desktop danh mục cấu hình KHÔNG có cán bộ đã bàn giao, desktop danh mục tự học, điện thoại).
- v24.17.35: **32 PASS · 0 FAIL** (log/test_hm31_v24.17.35_SAU_SUA.log — tên cán bộ đã che CBxx).
- v24.17.34 (trước sửa): 10 PASS · 22 FAIL — tái hiện lỗi: danh mục cấu hình Đầu năm 1.682 / Đầu quý 1.719 / Đầu tháng 1.871 (= Ngày BC); tự học: Đầu tháng 1.871 (log/test_hm31_v24.17.34_TRUOC_SUA.log).

| TỔNG (31/10/2026) | Đầu năm | Đầu quý | Đầu tháng | Ngày BC |
|---|---|---|---|---|
| Bản in — KH | 1.847 | 1.890 | 1.890 | 1.871 |
| App v24.17.35 = tệp gốc — KH | **1.847** | 1.892 | 1.892 | **1.871** |
| Bản in — Dư nợ (tr) | 1.992.329 | 2.180.111 | 2.180.111 | 2.158.433 |
| App v24.17.35 = tệp gốc — Dư nợ (tr) | **1.992.329** | 2.180.311 | 2.180.311 | **2.158.433** |

Chênh còn lại ở Đầu quý/Đầu tháng (2 KH, 200 tr) KHÔNG phải lỗi app: tệp 30/09 gốc cho 1.892 KH / 2.180.311 tr theo cán bộ tại mốc; bản in đã chuyển KH của 2 cán bộ đã bàn giao sang người nhận bằng tay (và từng dòng cán bộ ở cột Đầu quý của bản in khác tệp gốc, vd CB nhận bàn giao). Phần này thuộc GĐ2 (Sổ bàn giao + tính lại mốc theo danh mục đang quản lý) — cần danh sách bàn giao 2026 của người dùng.

## Còn lại (GĐ2/GĐ3)
Sổ bàn giao (ngày, từ → đến, phạm vi); tính lại mốc theo cán bộ đang quản lý; cột ofcno (app chưa giữ mã cán bộ); kế hoạch quý theo cán bộ (hiện = KH năm/4) + chuyển kế hoạch khi bàn giao.

---
# HM-31 GĐ2 — Sổ bàn giao cán bộ — v24.17.36 — 07/11/2026

## Quyết định người dùng (07/11)
- 7 bàn giao NGUYÊN danh mục tháng 10/2026 app dò ra là đúng.
- Danh mục bị CHIA (2 trường hợp): chia theo từng KH cho MỌI mốc (KH còn ở ngày hiệu lực → cán bộ đang quản lý; đã tất toán → người nhận chính) — Q25.
- Sổ bàn giao: app gợi ý, người dùng xác nhận — Q26.

## Làm gì (nguon_P06/build_p06_hm31b.py + gd28.js/.css)
- Báo cáo ngày có thanh "Phạm vi": Tất cả / Doanh nghiệp / Trung + dài hạn (TK 212, 213) / Trung hạn (TK 212) / Ngắn hạn + thấu chi — áp cho cả ngày BC lẫn các mốc; tiêu đề đổi theo phạm vi.
- "🔁 Sổ bàn giao cán bộ": so từng cặp mốc liền nhau; cán bộ có ≥ 5 KH và ≥ 50% KH chuyển đi ⇒ gợi ý; ≥ 90% sang một người ⇒ "Nguyên danh mục", còn lại ⇒ "Chia theo từng KH". Xác nhận từng dòng / tất cả, bỏ qua, xoá, xuất/nhập JSON (localStorage td_ban_giao_v1).
- Mốc trước ngày hiệu lực được tính lại theo sổ (P3 → QLTDBG.apDung), cán bộ đã bàn giao hết không còn dòng riêng.
- Dòng kiểm "✓ Σ cán bộ = Σ phòng = TỔNG = tổng tệp (4 mốc, KH và dư nợ)".

## Kiểm chứng V3 — số liệu thật, đáp án pandas độc lập (kiem_thu_p06/dap_an_ban_giao.py)
`kiem_thu_p06/test_hm31b_so_ban_giao.py` trên v24.17.36: **59 PASS · 0 FAIL** (desktop + điện thoại; log/test_hm31b_v24.17.36_GD2.log, tên cán bộ che CBxx):
gợi ý 9 bàn giao (7 nguyên + 2 chia, hiệu lực 31/10/2026) = Python; trước/sau xác nhận từng cán bộ KH + dư nợ 4 mốc = Python; 5 phạm vi; F5 giữ sổ; xuất / xoá / nhập sổ; điện thoại không cuộn ngang; 0 lỗi trang.

## Đối chiếu bản in 31/10/2026 (sau xác nhận sổ)
| Bảng | Tổng app (ĐN / ĐQ / BC) | Bản in | Ghi chú |
|---|---|---|---|
| Khách hàng | 1.846 / 1.891 / 1.871 | 1.847 / 1.890 / 1.871 | 1 KH trùng sau gộp danh mục (đếm 1 lần) |
| Dư nợ (tr) | 1.992.329 / 2.180.311 / 2.158.433 | 1.992.329 / 2.180.111 / 2.158.433 | bản in thiếu 200 tr ở Đầu quý |
| DN doanh nghiệp (tr) | 68.305 / 96.434 / 104.932 | 68.305 / 96.434 / 104.932 | **khớp tuyệt đối** |
| Trung + dài hạn (tr) | 197.632 / 216.569 / 218.835 | 197.632 / 214.555 / 217.442 | bản in Ngày BC bỏ 1 khoản TK 213 (1.393 tr) nhưng Đầu năm vẫn tính ⇒ dùng phạm vi "Trung hạn (TK 212)" nếu muốn loại TK 213 (BC = 217.442 khớp) |

Từng cán bộ (bảng KH): 10/18 khớp đủ 3 cột; lệch ở 2 danh mục bị chia (bản in để Đầu năm của cán bộ cũ nguyên/giao trọn cho 1 người — app chia theo từng KH theo Q25) và ±1–2 KH ở Đầu quý do chuyển tay.

## Còn lại (GĐ3)
Kế hoạch quý theo cán bộ (bản in: 2 KH và 2.000 tr/cán bộ/quý; app đang lấy KH năm/4) + chuyển kế hoạch khi bàn giao; % thực hiện + dự báo 31/12/2026; xuất đúng mẫu 4 bảng; cột mã cán bộ ofcno (app chưa giữ).

---
# HM-31 GĐ2 — phần còn lại — v24.17.38 — 07/11/2026

## Đã làm (nguon_P06/build_p06_hm31c.py + gd28.js/.css, từ v24.17.37)
1. **Mã cán bộ:** bộ đọc msit80 lưu thêm cột `ofcno` vào dòng r[32] (tệp thật có cột này, 3.832/3.832 dòng; ứng 1–1 với tên: 19 mã ↔ 19 tên). Dòng lưu trữ cũ chưa có mã được tra mã theo tên từ các dòng có mã. Sổ bàn giao khớp theo MÃ (sổ cũ chưa có mã vẫn khớp theo tên).
2. **Cảnh báo tên gần giống:** thanh vàng liệt kê cặp tên gần giống kèm mã ("hai người khác nhau, app không gộp"); và cảnh báo cùng mã khác cách viết tên. Trường hợp thật: hai cán bộ tên gần giống có hai mã riêng (xác nhận là hai người khác nhau).
3. **Cột "Bàn giao đầu quý / đầu năm"** (nhận + / giao −) ở cả bảng Khách hàng và Dư nợ, ở dòng cán bộ, phòng, TỔNG; dòng "(đã bàn giao)" của cán bộ nghỉ hiện số âm ở cột này. Kiểm Σ bàn giao dư nợ = 0 (số khách hàng có thể lệch 1 vì khách vay ở 2 cán bộ chỉ đếm 1 lần).
4. **Mốc so sánh** chọn được: "Theo danh mục đang quản lý" (mặc định) / "Theo cán bộ tại thời điểm mốc (cách cũ)" — cách cũ cho lại đúng số GĐ1.
5. **Sổ bàn giao:** thêm phạm vi theo danh sách mã KH (brcd) và/hoặc mã khế ước (dsbsseq); ghi chú, người lập (sửa tại chỗ); "＋ Thêm bàn giao thủ công"; **Xuất Excel (biên bản)**; xuất/nhập JSON.
6. **Áp sổ cho các màn khác:** Chỉ tiêu kế hoạch (THEO CBTD/PHÒNG/TỔNG QUAN: các cột mốc), Tổng quan "Biến động dư nợ theo cán bộ so kỳ trước", Trả nợ/xuất TS (mốc 31/12 và các cột Δ mốc).
- **Quyết định thiết kế:** dòng PHÒNG = Σ cán bộ của phòng (đúng cách bản in) — không gom theo phòng của khế ước (N8) vì sẽ lệch bản in.

## Kiểm chứng V3 — số liệu thật, đáp án pandas độc lập
- `kiem_thu_p06/test_hm31c_ban_giao_cot.py` trên v24.17.38: **36 PASS · 0 FAIL** (desktop + điện thoại): mã cán bộ 3.832/3.832 = Python; 9 gợi ý mang mã đúng; cảnh báo tên gần giống = Python; cột Bàn giao (KH và dư nợ) từng cán bộ = (tính lại − thô) Python, Σ dư nợ = 0; chế độ cũ = số thô; Chỉ tiêu KH / Tổng quan / Trả nợ (cán bộ giao & nhận) = Python; thêm thủ công phạm vi mã KH + mã khế ước = Python; ghi chú/người lập lưu sau F5; Excel biên bản đọc lại đúng; điện thoại không cuộn ngang; 0 lỗi trang.
- Bộ GĐ2 trước (`test_hm31b…`, v24.17.36) chạy lại trên v24.17.38 để đảm bảo không hồi quy (xem hoi_quy_v24.17.38.log).

## Đối chiếu bản in dư nợ từng cán bộ (triệu đồng; 17 cán bộ × 3 mốc có số = 51 ô)
- Cách cũ (thô): khớp 31/51. **Sau sổ bàn giao (v24.17.38): khớp 39/51.**
- 12 ô còn lệch: 6 ô "Đầu năm" mà bản in để số thô của cán bộ cũ/không điều chỉnh (6 cán bộ: 1 đã bàn giao hết + 5 người nhận danh mục chia); 6 ô nhỏ do bản in gán KHÁC cho từng khách lẻ (2 cán bộ đầu quý ±1.900 tr; 1 cán bộ 200 tr và 75 tr; 1 cán bộ −350 tr; 1 cán bộ +351 tr). Cần người dùng cho biết các khách đó (mã KH) để nhập vào sổ bằng phạm vi mã KH.

---
# HM-31 GĐ3 — Kế hoạch quý, chuyển kế hoạch, thực hiện/dự báo, 4 bảng, đối soát — v24.17.39 — 07/11/2026

## Phạm vi chốt (người dùng 07/11)
Áp cho TOÀN BỘ cán bộ tín dụng chi nhánh; chốt số liệu 31/10/2026 để hoàn thiện; số 05/11 đối soát sau (tệp 04/11 không phải nguồn của bảng in 5/11 — dư nợ 2.169.168 vs 2.163.809 tr; DN 104.067 vs 103.802; KH 1.877 vs 1.879). Số kế hoạch quý IV suy ngược từ thông báo 22/10 + các bảng 5/11 (tệp người dùng giữ — có tên cán bộ).

## Làm gì (nguon_P06/build_p06_hm31d.py + gd29.js; từ v24.17.38)
1. **Kế hoạch quý theo cán bộ** (panel "📊 Kế hoạch quý" dưới Báo cáo ngày): nhập từng ô, dán từ Excel (Tên ⇥ Dư nợ ⇥ Trung+dài ⇥ KH), hoặc "Áp mẫu cho mọi cán bộ"; lưu theo MÃ cán bộ (td_kh_quy_v1). Chưa nhập ⇒ giữ kế hoạch năm ÷ 4 như cũ.
2. **Chuyển kế hoạch theo sổ bàn giao** (bật mặc định, tắt được): chia theo tỷ lệ số KH chuyển (nguyên danh mục = 100%); các bàn giao cùng ngày chia ĐỒNG THỜI từ số đầu ngày (không nối tiếp — tránh chuyển lại phần vừa nhận); tổng kế hoạch chi nhánh không đổi; cán bộ không có kế hoạch thì không có gì để chuyển.
3. **% thực hiện + dự báo cuối quý** (tốc độ bình quân theo ngày đã qua) cho số KH và dư nợ: Thực hiện = Ngày BC − Đầu quý (đã tính lại theo sổ); % = Thực hiện ÷ Kế hoạch; Dự báo = Đầu quý + Thực hiện × (số ngày quý ÷ số ngày đã qua); Còn thiếu.
4. **Xuất Excel đúng mẫu 4 bảng** (Khách hàng · Dư nợ hàng ngày · Dư nợ doanh nghiệp · Dư nợ trung + dài hạn; dư nợ tính triệu đồng; kèm cột Bàn giao).
5. **Đối soát với báo cáo tay**: chọn bảng, dán số (Tên ⇥ Đầu năm ⇥ Đầu quý ⇥ Đầu tháng ⇥ Ngày BC) ⇒ app báo "Khớp x/y ô" và liệt kê ô lệch với nguyên nhân gợi ý ("đúng bằng cột Bàn giao — báo cáo tay chưa tính lại", "cán bộ có bàn giao", "tên không có trong báo cáo", chênh số).

## Kiểm chứng V3 — số liệu thật 31/10/2026, đáp án pandas độc lập (kiem_thu_p06/test_hm31d_ke_hoach_quy.py)
**27 PASS · 0 FAIL** (desktop + điện thoại; log/test_hm31d_v24.17.39_GD3.log): dán kế hoạch 18 cán bộ (tổng 36.000 tr / 36 KH = đúng bản in); chuyển TẮT = mọi cán bộ 2 KH / 2.000 tr, "+/- KH quý" = (BC − Đầu quý tính lại) − 2; chuyển BẬT: từng cán bộ (dư nợ, KH) = Python, tổng áp dụng 36.000 (bảo toàn), cột Kế hoạch trong Báo cáo ngày = kế hoạch đã chuyển; % thực hiện + dự báo (đã 31/92 ngày) từng cán bộ = Python; Excel 4 bảng từng cán bộ + TỔNG (4 mốc) = Python; đối soát báo cáo tay = Python (cùng số ô khớp/lệch); điện thoại không cuộn ngang; 0 lỗi trang.
Lỗi tìm ra khi kiểm: bản đầu chuyển kế hoạch NỐI TIẾP — cán bộ vừa nhận kế hoạch lại chuyển đi tiếp (chuỗi bàn giao vòng tròn giữa 3 cán bộ): sửa thành chia đồng thời, kiểm bằng ca K5.

## Kết quả đối soát với 4 bảng in 31/10/2026 (số ô khớp / tổng ô; Khách hàng dung sai 0, dư nợ ±1 triệu)
| Bảng in | Khớp | Ghi chú |
|---|---|---|
| Dư nợ doanh nghiệp | **36/36** | khớp tuyệt đối mọi cán bộ + TỔNG, 4 mốc |
| Dư nợ trung + dài hạn | 63/76 | 13 ô lệch: khách bản in gán khác / Đầu năm người cũ |
| Khách hàng | 55/76 | 21 ô lệch, 18 ô do bàn giao (bản in chưa tính lại hoặc tính tay) |
| Dư nợ hàng ngày | 56/76 | 20 ô lệch |
Các ô lệch còn lại là chênh do bản in tính tay (giữ số thô Đầu năm của người cũ; gán khác một số khách lẻ). Khi người dùng có danh sách khách đó (mã KH), nhập vào sổ bàn giao bằng phạm vi mã KH để triệt tiêu.

## Còn lại
Kế hoạch NĂM theo mã cán bộ và % thực hiện năm (đang dùng Chỉ tiêu KH hiện có); đối soát số 05/11 khi có tệp msit80 05/11; trang đối soát hiện là khối trong tab Báo cáo ngày (chưa là trang riêng).

---
# HM-31 — Ngày hiệu lực thực tế của sổ bàn giao — v24.17.40 — 07/11/2026

## Yêu cầu (người dùng 07/11): "Hiệu lực bàn giao cán bộ tín dụng bắt đầu từ ngày 1/10/2026"
Trước đó gợi ý đặt hiệu lực = ngày của mốc sau (31/10). Số liệu các mốc cần tính lại (30/09, 31/12) không đổi vì cả hai đều trước 01/10, nhưng ngày hiển thị / Excel biên bản và kế hoạch cả quý IV phải theo 01/10.

## Làm gì (nguon_P06/build_p06_hm31e.py; gd28.js)
- Ô **"Ngày hiệu lực thực tế"** ở khối gợi ý (để trống = ngày mốc): xác nhận từng dòng / tất cả sẽ ghi hiệu lực đó (không được sau ngày mốc). Dòng sổ lưu thêm `moc` (ngày mốc gợi ý) để gợi ý không lặp lại.
- Cột "Hiệu lực" trong bảng "Đã xác nhận" là ô ngày, sửa tại chỗ.
- Quy tắc: bàn giao hiệu lực ngày D chỉ tính lại các mốc TRƯỚC D; các bàn giao khác ngày được áp nối tiếp theo ngày, cùng ngày thì đồng thời. Chia theo từng KH dùng danh mục tại mốc đầu tiên không sớm hơn D.

## Kiểm chứng V3 — số liệu thật (kiem_thu_p06/test_hm31e_hieu_luc.py)
**9 PASS · 0 FAIL**: gợi ý mặc định 31/10; xác nhận với 01/10/2026 → 9 dòng sổ ngày 01/10, không gợi ý lại; số liệu 3 mốc (TỔNG + từng cán bộ, KH và dư nợ) = Python; kế hoạch quý IV chuyển theo bàn giao hiệu lực 01/10 = Python (tổng 36.000 tr); sửa 1 dòng thành 15/10 → số liệu không đổi; Excel biên bản ghi ngày hiệu lực thực tế; F5 giữ nguyên; 0 lỗi trang.
Lưu ý thiết kế đã kiểm: đặt hiệu lực ≤ ngày mốc thì mốc đó không tính lại; với bàn giao "chia" nên đặt hiệu lực sau mốc cũ (30/09) để danh mục người nhận lấy từ mốc 31/10.
