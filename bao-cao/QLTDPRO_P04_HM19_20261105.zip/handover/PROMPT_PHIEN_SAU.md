Áp dụng skill web-app-repair-upgrade (bản v3.2.0) cho phiên tiếp theo của đề án QLTDPRO.
Tôi đính kèm ZIP bàn giao: QLTDPRO_P04_HM19_20261105.zip (có sẵn trong repo: bao-cao/; giải nén vào thư mục tạm).
Hãy: (1) giải nén, đọc handover/HANDOVER.md (mục 0a, 0b, 0c) và backlog.json, xác minh MANIFEST.sha256;
(2) kiểm tra môi trường một lần (pip install playwright==1.63.0 xlrd; Chromium tại /opt/pw-browsers; pandas, openpyxl);
(3) đề án v1.2 đã duyệt; Q4–Q6, Q10–Q15 đã chốt (backlog.quyet_dinh_nghiep_vu); Q7 còn mở (nếu tôi đã trả lời thì áp dụng).
    Làm việc kế: đối soát bảng giá đất 2026 (tệp nguồn tôi gửi kèm) với bảng trong app (evidence/gia_dat/), sau đó HM-20;
(4) chạy hồi quy chung trước và sau: cd app/QLTDPRO_P43 && python3 kiem_thu_chung/chay_hoi_quy.py --app app/QLTDPRO_v24.17.19.html;
(5) kiểm chứng theo thang V3/V2/V1, bàn giao ZIP sau mỗi hạng mục và hỏi tôi trước khi sang hạng mục kế;
(6) theo dõi ngưỡng ngữ cảnh, giữ dự trữ đóng gói, đóng phiên bằng ZIP khi chạm vùng Đỏ.
Không đưa dữ liệu khách hàng thật vào repo hay ZIP. Chỉ trả lời bằng tiếng Việt, ngắn gọn.
