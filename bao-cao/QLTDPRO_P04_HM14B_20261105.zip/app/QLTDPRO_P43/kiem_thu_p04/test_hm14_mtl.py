# -*- coding: utf-8 -*-
# HM-14 · V3 — Máy tính lãi trên giao diện thật (Playwright Chromium; desktop 1366×768 + điện thoại 390×844).
# Số kỳ vọng tính ĐỘC LẬP bằng Python (Fraction, tròn nửa-lên). Dữ liệu thử ẩn danh, không có dữ liệu khách hàng thật.
# Lưu trữ: ca "đoạn dư nợ" thay window.__gd11Api bằng bản giả 3 mốc (31/10, 30/11, 10/12/2026); ca "không Lưu trữ" dùng app thật.
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p04/test_hm14_mtl.py [app/QLTDPRO_v24.17.17.html]
import asyncio, functools, http.server, threading, re, sys, json
from datetime import date
from fractions import Fraction as F
from math import floor
from pathlib import Path
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.18.html'
PORT = 8841; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
SHOT = ROOT.parent.parent / 'evidence' / 'hm14' / 'anh' if (ROOT.parent.parent / 'evidence').exists() else HERE / 'anh_hm14'
SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:400]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()

def d(s): return date.fromisoformat(s)
def rnd(x): return int(floor(x + F(1, 2)))
def seg(duno, ls, tu, den, mat):
    n = (d(den) - d(tu)).days; th = n if mat is None else (0 if d(mat) <= d(tu) else min(n, (d(mat) - d(tu)).days)); qh = n - th
    k = F(duno) * F(ls) / 100 / 365
    return (rnd(k * th) if th else 0) + (rnd(k * qh) if qh else 0) + (rnd(k * F(1, 2) * qh) if qh else 0)
def num(s): s = s.strip(); neg = s.startswith('-'); v = int(re.sub(r'[^\d]', '', s) or 0); return -v if neg else v
def row(ten, seq, duno, ls, gn, mat, moc, loai='Vay ngắn hạn (TK 211)', nxt='', intamt=0, lst=''):
    r = [''] * 27
    r[0] = '3201'; r[1] = ten; r[2] = 'HD-' + seq; r[6] = gn; r[7] = mat; r[8] = ls; r[10] = intamt; r[11] = duno; r[13] = loai
    r[20] = seq; r[23] = moc; r[24] = '2029-12-31'; r[25] = nxt; r[26] = lst
    return r
KH = 'Khách Thử Mười Bốn'; CHOT = '2026-12-15'; NGAY_DL = '2026-12-10'
I4 = seg(400_000_000, '9', '2026-11-20', NGAY_DL, '2027-06-01')
ROWS = [
    row(KH, 'L1', 1_000_000_000, '8.8', '2026-04-22', '2027-04-22', '2026-10-22'),                                    # ngắn hạn, không đổi
    row(KH, 'L2', 1_000_000_000, '8.8', '2025-10-22', '2028-10-22', '2026-10-22', 'Vay trung hạn (TK 212)', '2026-11-22'),  # Q12
    row(KH, 'L3', 250_000_000, '8.8', '2026-05-01', '2027-05-01', '2026-11-01', lst='05/12/2026'),                    # 3 đoạn dư nợ
    row(KH, 'L4', 400_000_000, '9', '2026-06-01', '2027-06-01', '2026-11-20', intamt=I4),                             # IPCAS khớp
    row(KH, 'L5', 400_000_000, '9', '2026-06-02', '2027-06-01', '2026-11-20', intamt=I4 - seg(400_000_000, '9', '2026-11-20', '2026-11-21', None)),  # lệch 1 ngày
    row(KH, 'L6', 300_000_000, '7.2', '2025-08-10', '2029-08-10', '2026-10-10', 'Vay dài hạn (TK 213)'),             # dài hạn không lịch
    row(KH, 'L7', 600_000_000, '8', '2025-11-22', '2028-11-22', '2026-11-22', 'Vay trung hạn (TK 212)', '2026-12-22',
        intamt=seg(600_000_000, '8', '2026-11-22', '2026-12-22', None)),                                               # Q7: intamt đến ngày đến hạn kỳ
]
SNAP = {  # mốc Lưu trữ giả: dayKey → [(seq, duno, lst)]
    '31/10/2026': [('L1', 1_000_000_000, ''), ('L2', 1_000_000_000, ''), ('L3', 1_000_000_000, ''), ('L4', 400_000_000, ''), ('L5', 400_000_000, ''), ('L6', 300_000_000, ''), ('L7', 600_000_000, '')],
    '30/11/2026': [('L1', 1_000_000_000, ''), ('L2', 1_000_000_000, ''), ('L3', 600_000_000, '15/11/2026'), ('L4', 400_000_000, ''), ('L5', 400_000_000, ''), ('L6', 300_000_000, ''), ('L7', 600_000_000, '')],
    '10/12/2026': [('L1', 1_000_000_000, ''), ('L2', 1_000_000_000, ''), ('L3', 250_000_000, '05/12/2026'), ('L4', 400_000_000, ''), ('L5', 400_000_000, ''), ('L6', 300_000_000, ''), ('L7', 600_000_000, '')],
}
EXP = {
    'L1': seg(1_000_000_000, '8.8', '2026-10-22', CHOT, '2027-04-22'),
    'L2': seg(1_000_000_000, '8.8', '2026-10-22', CHOT, '2026-11-22'),
    'L2_tat': seg(1_000_000_000, '8.8', '2026-10-22', CHOT, '2028-10-22'),
    'L3': seg(1_000_000_000, '8.8', '2026-11-01', '2026-11-15', '2027-05-01') + seg(600_000_000, '8.8', '2026-11-15', '2026-12-05', '2027-05-01') + seg(250_000_000, '8.8', '2026-12-05', CHOT, '2027-05-01'),
    'L3_cu': seg(250_000_000, '8.8', '2026-11-01', CHOT, '2027-05-01'),
    'L4': seg(400_000_000, '9', '2026-11-20', CHOT, '2027-06-01'),
    'L5': seg(400_000_000, '9', '2026-11-20', CHOT, '2027-06-01'),
    'L6': seg(300_000_000, '7.2', '2026-10-10', CHOT, '2029-08-10'),
    'L6_1t': seg(300_000_000, '7.2', '2026-10-10', CHOT, '2026-11-10'),
    'L7': seg(600_000_000, '8', '2026-11-22', CHOT, '2028-11-22'),
}
STUB = '''(snap) => { const iso = s => { const m = /^(\\d{2})\\/(\\d{2})\\/(\\d{4})$/.exec(s||''); return m ? m[3]+'-'+m[2]+'-'+m[1] : ''; };
  const real = window.__gd11Api || {};
  window.__gd11Api = Object.assign({}, real, { arcList: () => Object.keys(snap).map((k, i) => ({ dayKey: k, timestamp: 100 + i, name: 'msit80_' + k })),
    vnToIso: iso, loadArcRows: m => Promise.resolve(snap[m.dayKey].map(x => { const r = new Array(27).fill(''); r[0]='3201'; r[20]=x[0]; r[11]=x[1]; r[26]=x[2]; return r; })),
    loadZeroRows: () => Promise.resolve([]) }); }'''

async def run(pw, name, vw, vh):
    b = await pw.chromium.launch(); pg = await b.new_page(viewport={'width': vw, 'height': vh})
    errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    await pg.goto(URL, wait_until='domcontentloaded'); await pg.wait_for_timeout(3000)
    T = lambda s: f'{name}: {s}'
    async def rows():
        out = {}; rs = pg.locator('[data-testid=gd14-calc-row]')
        for i in range(await rs.count()):
            r = rs.nth(i); seq = (await r.locator('td').nth(2).inner_text()).split('GN:')[-1].strip()
            t = r.locator('[data-testid=gd14-calc-tong]'); ip = r.locator('[data-testid=gd14-calc-ipcas]')
            out[seq] = dict(tong=num(await t.inner_text()) if await t.count() else None,
                            ip=await ip.get_attribute('data-chenh') if await ip.count() else 'thieu',
                            ipcls=await ip.get_attribute('class') if await ip.count() else '',
                            khop=await ip.get_attribute('data-khop') if await ip.count() else None, title=await r.get_attribute('title') or '',
                            q12=await r.locator('[data-testid=gd14-calc-q12]').count(), doan=(await r.locator('[data-testid=gd14-calc-doan]').all_inner_texts()))
        return out
    async def open_(chot=CHOT, stub=True):
        if stub: await pg.evaluate(STUB, SNAP)
        await pg.evaluate('([r,c]) => GD14.openCalc(r, {chot:c})', [ROWS, chot]); await pg.wait_for_timeout(300)
        await pg.fill('[data-testid=gd14-calc-search]', 'Muoi Bon'); await pg.locator('[data-testid=gd14-calc-hit]').first.click(); await pg.wait_for_timeout(600)
    # --- A. không Lưu trữ (app thật, hồ sơ trình duyệt mới) ---
    await open_(stub=False); r = await rows()
    ok(T('A1 không Lưu trữ: L1 ngắn hạn = công thức cũ'), r.get('L1', {}).get('tong') == EXP['L1'], r.get('L1'))
    ok(T('A2 không Lưu trữ: L3 tính 1 đoạn như cũ (không bịa đoạn)'), r.get('L3', {}).get('tong') == EXP['L3_cu'], r.get('L3'))
    dl = pg.locator('[data-testid=gd14-calc-ngaydl]')
    ok(T('A3 nhãn ngày dữ liệu "chưa có"'), await dl.count() == 1 and 'chưa có' in await dl.inner_text())
    await pg.click('[data-testid=gd14-calc-x]')
    # --- B. Lưu trữ 3 mốc ---
    await open_(); r = await rows()
    ok(T('B1 L1 ngắn hạn không đổi'), r['L1']['tong'] == EXP['L1'], r['L1'])
    ok(T('B2 L2 trung hạn Q12: LS×1,5 từ kỳ trả lãi 22/11'), r['L2']['tong'] == EXP['L2'] and r['L2']['q12'] == 1, (r['L2'], EXP['L2']))
    ok(T('B3 L3 lãi theo 3 đoạn dư nợ'), r['L3']['tong'] == EXP['L3'] and r['L3']['doan'] == ['3 đoạn dư nợ'], (r['L3'], EXP['L3']))
    ok(T('B4 L4 Chênh IPCAS = 0 (khớp)'), r['L4']['ip'] == '0' and 'ip0' in (r['L4']['ipcls'] or ''), r['L4'])
    exp5 = seg(400_000_000, '9', '2026-11-20', '2026-11-21', None)
    ok(T('B5 L5 Chênh IPCAS = 1 ngày lãi, tô cam'), r['L5']['ip'] == str(exp5) and 'ipl' in (r['L5']['ipcls'] or ''), (r['L5'], exp5))
    ok(T('B6 L1 intamt = 0 → "—" không đối chiếu'), r['L1']['ip'] is None, r['L1'])
    ok(T('B7 L6 dài hạn không lịch: không áp Q12'), r['L6']['tong'] == EXP['L6'] and r['L6']['q12'] == 0, r['L6'])
    tl = num(await pg.locator('[data-testid=gd14-calc-tonglai]').inner_text())
    ok(T('B8 Tổng lãi = Σ khoản (độc lập)'), tl == sum(EXP[k] for k in ('L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'L7')), tl)
    ok(T('B7b L6 thiếu lịch → cảnh báo "chưa xét quá hạn lãi" (Q15b)'), 'thiếu lịch trả nợ' in r['L6']['title'], r['L6']['title'][-200:])
    ok(T('B7c L7 Q7: Chênh IPCAS ≠ 0 nhưng khớp nếu đến ngày đến hạn kỳ 22/12'), r['L7']['khop'] == '2026-12-22' and 'ipq' in (r['L7']['ipcls'] or '') and r['L7']['tong'] == EXP['L7'], r['L7'])
    ok(T('B9 ngày dữ liệu 10/12/2026'), '10/12/2026' in await pg.locator('[data-testid=gd14-calc-ngaydl]').inner_text())
    ok(T('B10 không cảnh báo ngày chốt khi chốt 15/12'), await pg.locator('[data-testid=gd14-calc-chot-warn]').count() == 0)
    await pg.click('[data-testid=gd14-calc-copy]'); cp = await pg.evaluate('GD14.calc.lastCopy') or ''
    ok(T('B11 Copy có Q12 / Đoạn / Chênh IPCAS'), 'Q12:' in cp and 'Đoạn 01/11/2026 → 15/11/2026' in cp and 'Chênh so IPCAS' in cp, cp[-600:])
    await pg.locator('[data-testid=gd14-calc-h14]').scroll_into_view_if_needed(); await pg.screenshot(path=str(SHOT / f'{name}_01_bang.png'))
    sw = await pg.evaluate('[document.documentElement.scrollWidth, innerWidth]')
    ok(T('B12 không tràn ngang trang'), sw[0] <= sw[1], sw)
    if vw < 600:
        h = await pg.locator('[data-testid=gd14-calc-kylai]').evaluate('e => e.getBoundingClientRect().height')
        ok(T('B13 ô chọn kỳ ≥ 40px trên điện thoại'), h >= 40, h)
    # --- C. đổi kỳ trả lãi ---
    await pg.select_option('[data-testid=gd14-calc-kylai]', '1'); await pg.wait_for_timeout(200); r = await rows()
    ok(T('C1 chọn kỳ 1 tháng: L6 dài hạn Q12 từ 10/11'), r['L6']['tong'] == EXP['L6_1t'] and r['L6']['q12'] == 1, (r['L6'], EXP['L6_1t']))
    ok(T('C2 kỳ 1 tháng: L2 vẫn theo lịch IPCAS 22/11'), r['L2']['tong'] == EXP['L2'], r['L2'])
    await pg.select_option('[data-testid=gd14-calc-kylai]', 'tat'); await pg.wait_for_timeout(200); r = await rows()
    ok(T('C3 "Không áp Q12": L2 về cách cũ'), r['L2']['tong'] == EXP['L2_tat'] and r['L2']['q12'] == 0, r['L2'])
    await pg.click('[data-testid=gd14-calc-x]')
    # --- D. cảnh báo ngày chốt ---
    await open_('2026-12-01')
    ok(T('D0 mở lại: kỳ chọn tay không giữ (Q15b không mặc định)'), await pg.locator('[data-testid=gd14-calc-kylai]').input_value() == '')
    w = pg.locator('[data-testid=gd14-calc-chot-warn]')
    ok(T('D1 chốt 01/12 trước ngày dữ liệu → cảnh báo'), await w.count() == 1 and 'TRƯỚC' in await w.inner_text())
    await pg.click('[data-testid=gd14-calc-x]'); await open_('2027-03-01')
    w = pg.locator('[data-testid=gd14-calc-chot-warn]')
    ok(T('D2 chốt cách 81 ngày → cảnh báo'), await w.count() == 1 and '81 ngày' in await w.inner_text())
    await pg.click('[data-testid=gd14-calc-x]')
    ok(T('E1 0 pageerror'), not errs, errs)
    await b.close()

async def main():
    async with async_playwright() as pw:
        await run(pw, 'desktop', 1366, 768); await run(pw, 'mobile', 390, 844)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
