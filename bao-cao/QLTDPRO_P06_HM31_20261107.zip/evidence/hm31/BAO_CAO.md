# HM-31 GĐ1 — Bàn giao cán bộ tín dụng (giai đoạn 1) — v24.17.35 — 07/11/2026

## Vấn đề (người dùng, 4 bảng in 31/10/2026)
Báo cáo ngày không tính được tăng/giảm và chỉ tiêu vì bàn giao cán bộ: app ra Đầu tháng = Ngày BC; Đầu năm/Đầu quý thiếu KH của cán bộ đã bàn giao hết.

## Nguyên nhân gốc (mã nguồn v24.17.34)
- N4: `s6` (Báo cáo ngày) gọi `P3(..., new Date)` → `E3` chọn mốc Đầu tháng/Đầu quý/Đầu năm theo NGÀY MÁY (07/11 ⇒ "đầu tháng" = 31/10 = chính ngày BC). Tab Trả nợ (`v3`) cũng `new Date`; D-1 so theo giờ nhập; mốc CT/CQ chỉ theo nhãn (tag).
- N2: `P3` chỉ duyệt cán bộ trong danh mục (`fn × members`) → cán bộ không còn trong danh mục mất khỏi TỔNG.
- N3: `Qv` gán tên lạ bằng `roster.match` (khớp viết tắt / 2 từ cuối) → có thể gộp nhầm người.
- N5: `I3`: "+/- KH quý" = Ngày BC − KH quý.

## Sửa (nguon_P06/build_p06_hm31.py + gd27.js, vá chuỗi có đếm)
- Ngày báo cáo = ngày dữ liệu (`_currentFileDate` / mốc đang xem) cho Báo cáo ngày và Trả nợ; Trả nợ dùng chung bộ chọn mốc `E3` (nhãn trước, rồi ngày cuối tháng/quý/năm của dữ liệu), ngày mốc theo ngày dữ liệu, D-1 theo ngày dữ liệu.
- Cán bộ ngoài danh mục → nhóm "CÁN BỘ ĐÃ BÀN GIAO / NGOÀI DANH MỤC" ngay trước TỔNG (người dùng chọn 07/11), vẫn cộng TỔNG; cảnh báo liệt kê tên. Bỏ khớp tên gần đúng.
- "+/- KH quý" (KH) và "+/- kế hoạch" (DN) = (Ngày BC − Đầu quý) − KH quý — người dùng chốt; khớp bảng in KHÁCH HÀNG mọi dòng (vd Tổng 1.871 − 1.890 − 36 = −55).

## Kiểm chứng V3 — số liệu THẬT (msit80 31/12/2025, 30/09/2026, 31/10/2026; không nằm trong repo/ZIP)
Bộ kiểm `kiem_thu_p06/test_hm31_bc_ngay.py` (đáp án pandas đọc thẳng tệp gốc; 3 cấu hình: desktop danh mục cấu hình KHÔNG có cán bộ đã bàn giao, desktop danh mục tự học, điện thoại).
- v24.17.35: **32 PASS · 0 FAIL** (log/test_hm31_v24.17.35_SAU_SUA.log — tên cán bộ đã che CBxx).
- v24.17.34 (trước sửa): 10 PASS · 22 FAIL — tái hiện lỗi: danh mục cấu hình Đầu năm 1.682 / Đầu quý 1.719 / Đầu tháng 1.871 (= Ngày BC); tự học: Đầu tháng 1.871 (log/test_hm31_v24.17.34_TRUOC_SUA.log).

| TỔNG (31/10/2026) | Đầu năm | Đầu quý | Đầu tháng | Ngày BC |
|---|---|---|---|---|
| Bản in — KH | 1.847 | 1.890 | 1.890 | 1.871 |
| App v24.17.35 = tệp gốc — KH | **1.847** | 1.892 | 1.892 | **1.871** |
| Bản in — Dư nợ (tr) | 1.992.329 | 2.180.111 | 2.180.111 | 2.158.433 |
| App v24.17.35 = tệp gốc — Dư nợ (tr) | **1.992.329** | 2.180.311 | 2.180.311 | **2.158.433** |

Chênh còn lại ở Đầu quý/Đầu tháng (2 KH, 200 tr) KHÔNG phải lỗi app: tệp 30/09 gốc cho 1.892 KH / 2.180.311 tr theo cán bộ tại mốc; bản in đã chuyển KH của 2 cán bộ đã bàn giao sang người nhận bằng tay (và từng dòng cán bộ ở cột Đầu quý của bản in khác tệp gốc, vd CB nhận bàn giao). Phần này thuộc GĐ2 (Sổ bàn giao + tính lại mốc theo danh mục đang quản lý) — cần danh sách bàn giao 2026 của người dùng.

## Còn lại (GĐ2/GĐ3)
Sổ bàn giao (ngày, từ → đến, phạm vi); tính lại mốc theo cán bộ đang quản lý; cột ofcno (app chưa giữ mã cán bộ); kế hoạch quý theo cán bộ (hiện = KH năm/4) + chuyển kế hoạch khi bàn giao.
