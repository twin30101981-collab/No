Áp dụng skill web-app-repair-upgrade (bản v3.2.0) tiếp phiên P06 của đề án QLTDPRO.
ZIP bàn giao: QLTDPRO_P06_HM31_20261107.zip (repo, thư mục bao-cao/, nhánh ccr-88209e2f-78z0lq; giải nén vào thư mục tạm).
(1) Giải nén, đọc handover/HANDOVER.md (phần đầu "P06 · HM-31 GĐ1") và backlog.json, xác minh MANIFEST.sha256.
(2) Môi trường: pip install playwright==1.63.0 xlrd python-docx pdfplumber; Chromium tại /opt/pw-browsers; pandas, openpyxl; Node.
(3) Bản hiện hành app/QLTDPRO_P43/app/QLTDPRO_v24.17.35.html; hồi quy 1635 PASS · 0 FAIL — chạy lại làm mốc trước khi sửa
    (cd app/QLTDPRO_P43 && QLTD_MSIT80_DIR=<thư mục msit80 thật nếu có> python3 kiem_thu_chung/chay_hoi_quy.py --app app/QLTDPRO_v24.17.35.html).
    Q7 còn mở; Q17–Q24 đã chốt. Hạng mục kế (hỏi tôi trước): HM-31 GĐ2 (sổ bàn giao, cần danh sách bàn giao 2026 + kế hoạch theo cán bộ) hoặc HM-07 → HM-08 → HM-10 → HM-09.
(4) Kiểm chứng V3/V2/V1, bàn giao ZIP sau mỗi hạng mục, hỏi trước khi sang hạng mục kế.
(5) Theo dõi ngưỡng ngữ cảnh, đóng phiên bằng ZIP khi chạm vùng Đỏ.
Không đưa dữ liệu khách hàng thật (kể cả msit80 .XLS, ảnh chụp số liệu thật, tên cán bộ) vào repo hay ZIP. Chỉ trả lời tiếng Việt, ngắn gọn.
