# HM-25 — Trang "Cho vay doanh nghiệp" — v24.17.29 — DAT_V3
Dựng: `python3 nguon_P05/build_p05_hm25.py` (v24.17.28 → .29).
## Quyết định (người dùng 06/11)
- Q17: nhận diện DN theo cột msit80 **custtpnm** (khác "Cá nhân" / "Hộ gia đình" / "Hộ cá thể" ⇒ DN); **custdtltpnm** hiện ở cột "Loại KH (IPCAS)".
  Tệp/mốc cũ chưa có cột ⇒ tạm theo tên KH (quy tắc sẵn có của Chỉ tiêu kế hoạch), trang báo số dòng tính theo tên.
- Q18: chỉ tiêu "Dư nợ Doanh nghiệp" (Chỉ tiêu kế hoạch) đổi cùng cách nhận diện ⇒ luôn bằng tổng trang DN.
- Phạm vi: bảng + thẻ tổng hợp.
## Làm
- Bộ đọc msit80 đọc thêm 2 cột → dòng r[30], r[31] (r[27], r[28] đã dùng cho TSBĐ khi sửa tay).
- `window.QLTD_laDN` (gd24) dùng chung cho trang DN, số đếm menu, Chỉ tiêu kế hoạch.
- Menu Dư nợ → "Cho vay doanh nghiệp" (`#/cho-vay-doanh-nghiep`, có số dòng); dùng lại khung trang Ngắn hạn / Trung-dài hạn: ô Phòng/Cán bộ,
  thẻ Khách hàng / Hồ sơ / Tổng dư nợ / Nhóm 2–5, bảng dòng (lọc cột, Gom Phòng → Cán bộ, Xuất Excel "Cho_vay_doanh_nghiep"),
  sắp mặc định Cán bộ ↑ (danh mục như Báo cáo ngày) rồi Ngày GN ↑ (HM-21b). Thêm thẻ: Tỷ trọng / dư nợ chi nhánh, Ngắn hạn, Trung hạn, Dài hạn, Thấu chi (theo bộ lọc).
## Kiểm chứng V3 — `python3 kiem_thu_p05/test_hm25_dn.py`
Dữ liệu thử ẩn danh: A = msit80 có thêm custtpnm/custdtltpnm (6 loại: DN, cá nhân, hộ gia đình, tổ chức khác…), desktop + điện thoại;
B = tệp không có cột, 25 khách tên "CÔNG TY TNHH…". Đáp án Python độc lập.
- v24.17.29: **34 PASS · 0 FAIL** — số dòng, dư nợ, số KH, tỷ trọng, tổng 4 loại vay, lọc phòng, Excel, số đếm menu, Chỉ tiêu "Dư nợ DN" = trang DN, 0 pageerror, không tràn ngang.
- v24.17.28: chưa có trang (P1 FAIL). Ảnh: anh/QLTDPRO_v24.17.29/
- Lưu ý: dữ liệu thử không có thấu chi DN (thẻ Thấu chi = 0 đ); cần đối chiếu 1 tệp msit80 thật có cột custtpnm.
## Hồi quy chung (v24.17.29): **1484 PASS · 0 FAIL** (29 bộ gồm p05_hm21 35/0, p05_hm21b 77/0, p05_hm25 34/0; LỆCH PB 12 = nhãn phiên bản đã khai báo; LOI_MT p41/p42_gd14 như cũ).
