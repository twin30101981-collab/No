# -*- coding: utf-8 -*-
# HM-21 · V3 — MỌI trang xếp cán bộ theo phòng GIỐNG Báo cáo ngày + danh sách mặc định ngày cũ → mới; kèm gd24-css (ô chọn dễ nhìn).
# Dữ liệu thử ẩn danh: dư nợ 3 mốc (tao_mis80_thu) + 1 sao kê TS sinh từ tên cán bộ thử. Kịch bản A: danh mục cán bộ khai báo
# (thứ tự KHÁC bảng chữ cái); kịch bản B: chưa khai báo (app tự học) — đáp án = chính tab Báo cáo ngày.
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p05/test_hm21_thu_tu_cb.py [app/QLTDPRO_v24.17.27.html]
import asyncio, functools, http.server, threading, sys, tempfile, subprocess, re, json
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.27.html'
PORT = 8861; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence' / 'hm21'
if not EV.parent.exists(): EV = HERE / 'hm21'
SHOT = EV / 'anh' / Path(APP).stem; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:600]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
TMP = Path(tempfile.mkdtemp()) / 'm'
subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(TMP)], check=True, stdout=subprocess.DEVNULL)
FILES = sorted(TMP.iterdir(), key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
ROSTER = [('Hội Sở', 'VŨ THỊ HẰNG'), ('Hội Sở', 'BÙI THỊ MAI'), ('PGD Hai Bà Trưng', 'TRẦN VĂN CB'), ('PGD Hai Bà Trưng', 'ĐỖ VĂN LONG'),
          ('PGD Số 2', 'PHẠM THỊ CB'), ('PGD Số 2', 'LÊ VĂN CB'), ('PGD Số 2', 'NGUYỄN THỊ CB')]
EXP = [n for _, n in ROSTER]; ALL = set(EXP)
RTXT = '\n'.join(f'{p} | {n} | CBTD' for p, n in ROSTER)
PH = {'hội sở': 0, 'phòng khách hàng': 0, 'pgd hai bà trưng': 1, 'pgd hbt': 1, 'pgd số 2': 2}
def prank(p): return PH.get(re.sub(r'^phòng\s+(?=hội)', '', (p or '').strip().lower()), 9)
# sao kê TS: khách chưa có HĐTD, cán bộ trộn thứ tự, ngày thế chấp trộn
def ts(so, c, ngay):
    return {'clno': so, 'clcustno': 'MOI' + so, 'clcustnm': 'Khách TS ' + so, 'cltpcd': 'Đất ở', 'cldtltpcd': 'Thổ cư', 'clqtysz': '100', 'clunittpcd': 'm2', 'clloc': so + ' Phố Thử',
            'clamt': 1_000_000_000, 'plgno': 'LCA' + so, 'plgdt': ngay, 'plgtpcd': 'TC', 'exprdt': '01/09/2028', 'avblamtrt': '70', 'plgamt': 700_000_000,
            'plgcustno': 'MOI' + so, 'plgcustnm': 'Khách TS ' + so, 'clccycd': 'VND', 'clholdcd': 'N', 'ntydt': ngay, 'rem': '', 'lnofcnm': ROSTER[c][1], 'trctcd': ROSTER[c][0], 'name_2': 'GCN' + so}
TSR = [ts('T1', 5, '15/03/2026'), ts('T2', 0, '20/08/2026'), ts('T3', 0, '02/01/2025'), ts('T4', 3, '11/11/2025'), ts('T5', 0, '05/06/2026'), ts('T6', 6, '01/02/2026')]
TSF = Path(tempfile.mkdtemp()) / '31_10_2026-TS.xlsx'
_wb = openpyxl.Workbook(); _w = _wb.active; _h = list(TSR[0].keys()); _w.append(_h)
for r in TSR: _w.append([r[k] for k in _h])
_wb.save(TSF)
def dk(s): m = re.match(r'(\d{1,2})/(\d{1,2})/(\d{4})', s or ''); return (int(m[3]), int(m[2]), int(m[1])) if m else (9999,)
def asc(xs): v = [dk(x) for x in xs if x]; return len(v) >= 2 and v == sorted(v)
def thu_tu(names, ref):
    """names (đã bỏ trùng liên tiếp) phải: tên có trong ref theo đúng thứ tự ref, tên lạ đứng sau"""
    k = [n for n in names if n in ref]; u = [i for i, n in enumerate(names) if n not in ref]
    return k == [n for n in ref if n in k] and all(i >= len(k) for i in u)
def strip(o): return re.sub(r'\s·\s[\d.]+$', '', o).strip()

async def nap(pg, files):
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in files]); await pg.wait_for_timeout(3500)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(9000)
async def go(pg, r, w=2200):
    await pg.goto(URL + r, wait_until='domcontentloaded'); await pg.wait_for_timeout(w)
async def opts(pg, sel): return [strip(x) for x in (await pg.eval_on_selector_all(sel + ' option', 'o=>o.map(x=>x.textContent.trim())'))[1:]]
async def bao_cao_ngay(pg):
    await go(pg, '#/chi-tieu-ke-hoach')
    await pg.locator('main button', has_text=re.compile('^BÁO CÁO NGÀY$', re.I)).first.click(); await pg.wait_for_timeout(1500)
    return await pg.evaluate("""()=>{const t=[...document.querySelectorAll('main table')].find(x=>x.offsetParent&&(x.querySelector('th')||{}).textContent.trim()==='CBTD');if(!t)return null;
      return [...t.tBodies[0].rows].map(r=>r.children[0].textContent.trim())}""")
async def nhom_luoi(pg):
    """bật Gom Phòng → Cán bộ ở bảng dữ liệu, cuộn hết, lấy thứ tự dòng nhóm"""
    await pg.click('[data-testid=dt-group]'); await pg.wait_for_timeout(1200)
    return await pg.evaluate("""async()=>{const sc=document.querySelector('[data-testid=dt-scroll]');const out=[],seen=new Set();let last=-1;
      for(let i=0;i<600&&sc.scrollTop!==last;i++){last=sc.scrollTop;document.querySelectorAll('[data-testid=dt-group-row]').forEach(r=>{const f=r.textContent.trim();if(seen.has(f))return;seen.add(f);out.push(f.replace(/\\s*\\(\\d[\\d.]*\\).*$/,'').replace(/^[▾▸]\\s*/,''))});
        sc.scrollTop+=sc.clientHeight*0.9;await new Promise(r=>setTimeout(r,25))}return out}""")
async def cot_ngay(pg, lb, n=40):
    return await pg.evaluate("""([lb,n])=>{const th=[...document.querySelectorAll('[data-testid=dt-th]')].map(x=>x.textContent.replace(/[▲▼]/g,'').trim());const i=th.indexOf(lb);if(i<0)return null;
      return [...document.querySelectorAll('[data-testid=dt-row]')].slice(0,n).map(r=>(r.children[i]||{}).textContent.trim())}""", [lb, n])
STYLE = """(s)=>{const e=document.querySelector(s);if(!e)return null;const c=getComputedStyle(e);return {color:c.color,shadow:c.boxShadow,h:Math.round(e.getBoundingClientRect().height),bg:c.backgroundColor}}"""

async def kich_ban_A(pw, name, vw, vh):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN', is_mobile=vw < 600, has_touch=vw < 600)
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0');localStorage.setItem('td_roster_v1'," + json.dumps(RTXT) + ")}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    T = lambda s: f'{name} A: {s}'
    await nap(pg, FILES + [TSF])
    if vw >= 1000:
        bc = await bao_cao_ngay(pg); bcb = [x for x in (bc or []) if x in ALL]
        ok(T('A0 tab Báo cáo ngày: cán bộ theo danh mục (Hội Sở → PGD HBT → PGD Số 2)'), bcb == EXP, bc)
        await pg.select_option('[data-testid=ct-scope]', label='Theo CBTD'); await pg.wait_for_timeout(800)
        o = await pg.eval_on_selector_all('[data-testid=ct-scope-id] option', 'o=>o.map(x=>x.textContent.trim())')
        ok(T('A1 Chỉ tiêu kế hoạch · ô chọn CBTD = Báo cáo ngày'), [x.split(' — ')[0] for x in o if x.split(' — ')[0] in ALL] == EXP, o)
        await go(pg, '#/tong-quan', 3000)
        for sel, lb in (('[data-testid=gd7-f-cb]', 'lọc Cán bộ'), ('select[data-topcb]', 'Top KH · phạm vi cán bộ')):
            o = await opts(pg, sel); ok(T(f'A2 Tổng quan · ô {lb} theo danh mục'), thu_tu(o, EXP) and set(o) >= ALL, o)
        tr = await pg.evaluate("""()=>{const o=[];document.querySelectorAll('[data-testid=gd7-tree] tr.gd7-l1, [data-testid=gd7-tree] tr.gd7-l2').forEach(r=>{const t=r.children[0].textContent.replace(/[▾▸]/g,'').trim();o.push([r.classList.contains('gd7-l1')?1:2,t])});return o}""")
        ph = [t for l, t in tr if l == 1]; sai = []
        cur = []; 
        for l, t in tr + [(1, '#')]:
            if l == 1:
                if cur and not thu_tu(cur, EXP): sai.append(cur)
                cur = []
            else: cur.append(t)
        ok(T('A3 Tổng quan · bảng chéo Phòng → Cán bộ: phòng Hội Sở → HBT → Số 2, cán bộ trong phòng theo danh mục'), [prank(p) for p in ph] == sorted(prank(p) for p in ph) and len(ph) >= 2 and not sai, (ph, sai[:2]))
        dl = await pg.evaluate("[...document.querySelectorAll('[data-testid=gd7-delta] tbody tr:not(.gd7-total)')].map(r=>[r.children[0].textContent.trim(),r.children[1].textContent.trim()])")
        key = [(prank(p), EXP.index(c) if c in EXP else 99) for c, p in dl]
        ok(T('A4 Tổng quan · bảng Tăng/giảm theo cán bộ: Phòng → Cán bộ theo danh mục'), len(dl) >= 3 and key == sorted(key), dl)
    pages = ['#/tat-ca-du-no', '#/ngan-han-thau-chi', '#/trung-dai-han', '#/canh-bao-som', '#/giai-ngan'] if vw >= 1000 else ['#/tat-ca-du-no', '#/giai-ngan']
    for r in pages:
        await go(pg, r)
        o = await opts(pg, '[data-testid=sc-cb]'); p = await opts(pg, '[data-testid=sc-pb]')
        ok(T(f'A5 {r} · ô Phòng ban (Hội Sở → HBT → Số 2) + ô Cán bộ theo danh mục'), [prank(x) for x in p] == [0, 1, 2] and thu_tu(o, EXP) and set(o) >= ALL, (p, o))
        if r in ('#/tat-ca-du-no', '#/giai-ngan'):
            si = await pg.inner_text('[data-testid=dt-sortinfo]'); col = await cot_ngay(pg, 'Ngày GN')
            ok(T(f'D1 {r} · mặc định sắp Ngày GN cũ → mới ({si.strip()[:30]})'), '↑' in si and col and asc(col), (si, (col or [])[:12]))
    st = await pg.evaluate(STYLE, '[data-testid=sc-cb]')
    ok(T(f'S1 ô chọn: chữ xanh đậm + đổ bóng nhẹ ({st})'), st and st['color'] == 'rgb(11, 58, 110)' and st['shadow'] not in ('none', ''), st)
    await pg.select_option('[data-testid=sc-pb]', index=1); await pg.wait_for_timeout(600)
    st2 = await pg.evaluate(STYLE, '[data-testid=sc-pb]')
    ok(T('S2 ô lọc đang chọn khác "Tất cả" → màu hổ phách để dễ nhận'), st2 and st2['color'] == 'rgb(122, 62, 0)', st2)
    o = await opts(pg, '[data-testid=sc-cb]'); ok(T('A6 chọn phòng → ô Cán bộ vẫn theo danh mục'), thu_tu(o, EXP), o)
    await pg.screenshot(path=str(SHOT / f'{name}_giai_ngan.png'))
    if vw >= 1000:
        await go(pg, '#/tat-ca-du-no'); g = await nhom_luoi(pg); sai = []
        phs = [x for x in g if x.startswith('Phòng ')]; cur = []
        for x in g + ['Phòng #']:
            if x.startswith('Phòng '):
                if cur and not thu_tu(cur, EXP): sai.append(cur)
                cur = []
            elif x.startswith('CB '): cur.append(x[3:].strip())
        ok(T('A7 Tất cả dư nợ · "Gom Phòng → Cán bộ": phòng Hội Sở → HBT → Số 2, cán bộ theo danh mục (cuộn hết bảng)'), [prank(p[6:]) for p in phs] == [0, 1, 2] and not sai, (phs, sai[:2], g[:12]))
        await go(pg, '#/tra-no-xuat-ts')
        o = await opts(pg, '[data-testid=tn-cbtd]'); ok(T('A8 Trả nợ / xuất TS · ô Cán bộ theo danh mục'), thu_tu(o, EXP) and set(o) >= ALL, o)
        # Khách hàng mới · Đối soát (gd15)
        await go(pg, '#/khach-hang-moi', 2500)
        await pg.select_option('[data-testid=khm-arch-dau]', index=0); await pg.select_option('[data-testid=khm-arch-cuoi]', index=2)
        await pg.locator('[data-testid="khm-arch-load"]').click(); await pg.wait_for_timeout(2500)
        await pg.locator('[data-testid="khm-go"]').click(); await pg.wait_for_selector('[data-testid="khm-tab-doisoat-btn"]', timeout=30000)
        await pg.locator('[data-testid="khm-tab-doisoat-btn"]').first.click(); await pg.wait_for_selector('[data-testid="khm-dstn-t"]', timeout=60000); await pg.wait_for_timeout(600)
        rows = await pg.evaluate("[...document.querySelectorAll('[data-testid=khm-dstn-t] tbody tr[data-sc]')].map(r=>[r.dataset.sc,r.dataset.phong||'',r.children[0].textContent.replace(/[▾▸]/g,'').trim()])")
        phs = []; sai = []; cur = []
        for sc, p, t in rows + [['phong', '#', '#']]:
            if sc == 'phong':
                if cur and not thu_tu(cur, EXP): sai.append(cur)
                cur = []; phs.append(p)
            elif sc == 'cb': cur.append(next((n for n in EXP if t.startswith(n)), t))
        phs = phs[:-1]
        ok(T('A9 Khách hàng mới · Đối soát: Phòng (Hội Sở → HBT → Số 2) → Cán bộ theo danh mục'), [prank(p) for p in phs] == sorted(prank(p) for p in phs) and len(phs) >= 2 and not sai, (phs, sai[:2]))
        o = [x for x in await opts(pg, '[data-testid=khm-dstn-loc-cb]')]
        kk = [(prank(x.split(' · ')[-1]), EXP.index(x.split(' · ')[0]) if x.split(' · ')[0] in EXP else 99) for x in o]
        ok(T('A10 Khách hàng mới · ô Lọc cán bộ: Phòng → Cán bộ theo danh mục'), len(o) >= 7 and kk == sorted(kk), o)
        await pg.evaluate("()=>{const td=document.querySelector('[data-testid=khm-dstn-t] tr[data-sc=phong] td[data-k=gn].gd15-ck');td.dispatchEvent(new MouseEvent('click',{bubbles:true}))}")
        await pg.wait_for_selector('[data-testid="khm-dstn-ct"]'); await pg.wait_for_timeout(300)
        col = await pg.evaluate("""()=>{const t=document.querySelector('[data-testid=khm-dstn-ct-t]');const H=[...t.querySelectorAll('thead th')].map(x=>x.textContent.trim());const i=H.indexOf('Ngày GN');
          return [...t.querySelectorAll('tbody tr')].map(r=>(r.children[i]||{}).textContent.trim())}""")
        ok(T(f'D2 Khách hàng mới · bấm số Giải ngân → danh sách Ngày GN cũ → mới ({len(col)} dòng)'), asc(col), col[:12])
        await pg.screenshot(path=str(SHOT / f'{name}_khm.png'))
        # Tài sản bảo đảm · TS chưa có HĐTD (gd23)
        await go(pg, '#/tai-san-bao-dam', 2500); await pg.click('[data-testid=ts-tab-kct]'); await pg.wait_for_timeout(2500)
        cbs = [x for x in await pg.evaluate("[...document.querySelectorAll('[data-testid=gd23-kct-t] tbody tr[data-cb]')].map(r=>r.getAttribute('data-cb'))") if x in ALL]
        ok(T('A11 Tài sản bảo đảm · TS chưa có HĐTD: cán bộ theo danh mục'), cbs == [n for n in EXP if n in {r['lnofcnm'] for r in TSR}], cbs)
        b = pg.locator('[data-testid=gd23-kct-t] tr[data-cb="VŨ THỊ HẰNG"] td[data-k] button').first
        if await b.count():
            await b.click(); await pg.wait_for_timeout(500)
            nd = await pg.evaluate("[...document.querySelectorAll('[data-testid=gd23-ct-t] tbody td[data-lb=\"Ngày thế chấp\"]')].map(x=>x.textContent.trim())")
            ok(T('D3 Tài sản bảo đảm · danh sách TS ngày thế chấp cũ → mới'), nd == ['02/01/2025', '05/06/2026', '20/08/2026'], nd)
        else: ok(T('D3 Tài sản bảo đảm · danh sách TS ngày thế chấp cũ → mới'), False, 'không thấy nút số')
    else:
        sw = await pg.evaluate('[document.documentElement.scrollWidth, innerWidth]')
        ok(T('M1 điện thoại: không tràn ngang trang'), sw[0] <= sw[1], sw)
    ok(T('E1 0 pageerror'), not errs, errs[:3])
    await br.close()

async def kich_ban_B(pw):
    br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': 1366, 'height': 900}, locale='vi-VN')
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    await nap(pg, FILES)
    await go(pg, '#/giai-ngan'); o1 = await opts(pg, '[data-testid=sc-cb]')   # mở trang TRƯỚC khi vào Báo cáo ngày
    bc = [x for x in (await bao_cao_ngay(pg) or []) if x in ALL]
    await go(pg, '#/tong-quan', 3000); o2 = await opts(pg, '[data-testid=gd7-f-cb]')
    await go(pg, '#/tat-ca-du-no'); o3 = await opts(pg, '[data-testid=sc-cb]')
    ok('desktop B: B1 chưa khai báo danh mục (app tự học) — ô Cán bộ Giải ngân / Tổng quan / Tất cả dư nợ = thứ tự Báo cáo ngày', len(bc) == 7 and o1 == bc and o2 == bc and o3 == bc, (bc, o1, o2, o3))
    ok('desktop B: E1 0 pageerror', not errs, errs[:3])
    await br.close()

async def main():
    async with async_playwright() as pw:
        await kich_ban_A(pw, 'desktop', 1366, 900); await kich_ban_A(pw, 'mobile', 390, 844); await kich_ban_B(pw)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
