# -*- coding: utf-8 -*-
# Chốt đối soát chuẩn 31/10/2026 bằng Playwright trên app (không phải bộ kiểm hồi quy): nạp msit80 thật, sổ bàn giao (hiệu lực 01/10/2026),
# kế hoạch quý theo bản in, xuất 4 bảng + sổ bàn giao, đối soát từng ô với báo cáo tay (kể cả dòng phòng + TỔNG).
# Đầu vào (KHÔNG có trong repo/ZIP): QLTD_MSIT80_DIR, QLTD_BANIN_JSON; đầu ra: QLTD_OUT (Excel/ảnh có tên cán bộ — chỉ giao người dùng).
# Chạy từ app/QLTDPRO_P43/:  QLTD_MSIT80_DIR=… QLTD_BANIN_JSON=… QLTD_OUT=… python3 kiem_thu_p06/chot_doi_soat_3110.py [app/QLTDPRO_v24.17.40.html]
import asyncio, functools, http.server, threading, sys, os, re, json, warnings
from pathlib import Path
warnings.filterwarnings('ignore')
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.40.html'
D = Path(os.environ['QLTD_MSIT80_DIR']); BANIN = json.loads(Path(os.environ['QLTD_BANIN_JSON']).read_text(encoding='utf-8')); OUT = Path(os.environ['QLTD_OUT']); OUT.mkdir(parents=True, exist_ok=True)
FS = [D / '31.12.2025.xlsx', D / '30.09.2026.XLS', D / '31.10.2026.XLS']
import pandas as pd, openpyxl
from openpyxl.styles import Font, PatternFill
from playwright.async_api import async_playwright
sys.path.insert(0, str(HERE)); from dap_an_ban_giao import norm
PORT = 8877; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()
PB = {'hội sở': 'Hội Sở', 'pgd hai bà trưng': 'PGD Hai Bà Trưng', 'pgd số 2': 'PGD Số 2'}
_t = pd.read_excel(FS[2], header=0, usecols=['ofcnm', 'trctnm']); _t['cb'] = _t.ofcnm.fillna('').astype(str).str.strip()
ROSTER = [(PB.get(str(p).strip().lower(), p), n) for n, p in _t[_t.cb != ''].groupby('cb').trctnm.agg(lambda s: s.mode().iloc[0]).items()]
TEN_KH = [n for n in BANIN['kh'] if n not in ('TỔNG', 'PHÒNG KHÁCH HÀNG', 'PGD HBT', 'PGD Số 2')]
async def main():
    async with async_playwright() as pw:
        br = await pw.chromium.launch(); ctx = await br.new_context(viewport={'width': 1440, 'height': 900}, locale='vi-VN', accept_downloads=True)
        await ctx.add_init_script("try{if(!sessionStorage.getItem('__k')){sessionStorage.setItem('__k','1');localStorage.setItem('gd9_tplok','0');localStorage.setItem('td_roster_v1'," + json.dumps('\n'.join(f'{p} | {n} | CBTD' for p, n in ROSTER)) + ")}}catch(e){}")
        pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
        await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
        await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in FS]); await pg.wait_for_timeout(12000)
        await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(1000)
        y = pg.locator('[data-testid="confirm-yes"]')
        if await y.count(): await y.click()
        await pg.wait_for_timeout(25000)
        await pg.goto(URL + '#/chi-tieu-ke-hoach', wait_until='domcontentloaded'); await pg.wait_for_timeout(3500)
        await pg.click('[data-testid=ct-tab-ngay]'); await pg.wait_for_selector('[data-testid=bg-host] [data-testid=bg-bar]', timeout=20000); await pg.wait_for_timeout(1000)
        await pg.evaluate("document.querySelector('[data-testid=bg-so]').open=true")
        ngy = await pg.locator('[data-testid=bg-goiy-row]').count()
        await pg.fill('[data-testid=bg-hl]', '2026-10-01'); await pg.click('[data-testid=bg-xn-all]'); await pg.wait_for_timeout(1500)
        # kế hoạch quý như bản in 31/10: mỗi cán bộ (kể cả cán bộ đã bàn giao) 2.000 tr dư nợ, 2.000 tr trung+dài, 2 KH
        await pg.evaluate("document.querySelector('[data-testid=kh-so]').open=true")
        await pg.fill('[data-testid=kh-dan]', '\n'.join(f"{n}\t2.000\t2.000\t2" for n in TEN_KH)); await pg.click('[data-testid=kh-dan-ok]'); await pg.wait_for_timeout(1500)
        kiem = (await pg.inner_text('[data-testid=bg-kiem]')).strip(); canh = await pg.evaluate("(document.querySelector('[data-testid=bg-canh]')||{innerText:''}).innerText")
        await pg.screenshot(path=str(OUT / 'anh_bao_cao_ngay_kh.png'), full_page=True)
        # tải: 4 bảng, sổ bàn giao (Excel + JSON)
        await pg.evaluate("document.querySelector('[data-testid=bg-so]').open=true;document.querySelector('[data-testid=ds-so]').open=true")
        for sel, ten in (('kh-xuat4', 'BaoCao4Bang_31-10-2026_CHUAN.xlsx'), ('bg-xlsx', 'SoBanGiao_31-10-2026.xlsx'), ('bg-xuat', 'SoBanGiao_31-10-2026.json')):
            async with pg.expect_download() as dl: await pg.click(f'[data-testid={sel}]')
            await (await dl.value).save_as(OUT / ten)
        # đối soát trong app (4 bảng)
        tom = {}
        for kind in ('kh', 'dn', 'dnn', 'th'):
            await pg.select_option('[data-testid=ds-bang]', kind)
            await pg.fill('[data-testid=ds-dan]', '\n'.join(f"{n}\t" + '\t'.join('-' if x is None else str(x) for x in v) for n, v in BANIN[kind].items()))
            await pg.click('[data-testid=ds-ok]'); await pg.wait_for_timeout(2000)
            tom[kind] = (await pg.inner_text('[data-testid=ds-tong]')).strip()
            tom[kind + '_rows'] = await pg.evaluate("[...document.querySelectorAll('[data-testid=ds-row]')].map(r=>[...r.children].map(c=>c.textContent.trim()))")
            await pg.screenshot(path=str(OUT / f'anh_doi_soat_{kind}.png'), full_page=True)
        await br.close()
    # Excel đối soát từng ô (app = số trong tệp 4 bảng do app xuất)
    wb4 = openpyxl.load_workbook(OUT / 'BaoCao4Bang_31-10-2026_CHUAN.xlsx'); out = openpyxl.Workbook(); ws0 = out.active; ws0.title = 'Tong_hop'
    ws0.append(['ĐỐI SOÁT BÁO CÁO TAY ↔ APP (v24.17.40) — số liệu đến 31/10/2026; sổ bàn giao 9 dòng hiệu lực 01/10/2026; KH: chính xác; dư nợ: triệu đồng, dung sai ±1'])
    ws0.append(['Bảng', 'Ô khớp / tổng (app)', 'Ô lệch']); TEN = {'kh': 'Khách hàng', 'dn': 'Dư nợ hàng ngày', 'dnn': 'Dư nợ doanh nghiệp', 'th': 'Dư nợ trung + dài hạn'}
    for si, kind in enumerate(('kh', 'dn', 'dnn', 'th')):
        sh = wb4.worksheets[si]; app = {norm(str(r[0].value)): [c.value for c in r] for r in sh.iter_rows() if r[0].value}
        ws = out.create_sheet(TEN[kind][:28]); ws.append(['Cán bộ / phòng', 'Đầu năm (tay)', 'Đầu năm (app)', 'Lệch', 'Đầu quý (tay)', 'Đầu quý (app)', 'Lệch', 'Đầu tháng (tay)', 'Đầu tháng (app)', 'Lệch', 'Ngày BC (tay)', 'Ngày BC (app)', 'Lệch', 'Bàn giao đầu quý (app)', 'Bàn giao đầu năm (app)'])
        tol = 0 if kind == 'kh' else 1; okc = tot = 0
        for n, v in BANIN[kind].items():
            a = app.get(norm(n)); row = [n]
            for i in range(4):
                t_ = 0 if v[i] is None else v[i]; x = (a[i + 1] if a else None) or 0; d = x - t_; row += [t_, x, d]; tot += 1; okc += abs(d) <= tol
            row += [(a[10] if a else None) or 0, (a[11] if a else None) or 0]; ws.append(row)
            for j in (4, 7, 10, 13):
                c = ws.cell(ws.max_row, j)
                if abs(c.value or 0) > tol: c.fill = PatternFill('solid', fgColor='FEE2E2')
        for c in ws[1]: c.font = Font(bold=True)
        ws.column_dimensions['A'].width = 24
        ws0.append([TEN[kind], f'{okc}/{tot}', tot - okc, 'app báo: ' + tom[kind]])
    out.save(OUT / 'DOI_SOAT_31-10-2026.xlsx')
    kq = {'goi_y': ngy, 'kiem': kiem, 'canh_ten': bool(canh.strip()), 'doi_soat': {k: tom[k] for k in ('kh', 'dn', 'dnn', 'th')}, 'pageerror': errs}
    (OUT / 'ket_qua.json').write_text(json.dumps(kq, ensure_ascii=False, indent=1), encoding='utf-8'); print(json.dumps(kq, ensure_ascii=False, indent=1))
asyncio.run(main())
