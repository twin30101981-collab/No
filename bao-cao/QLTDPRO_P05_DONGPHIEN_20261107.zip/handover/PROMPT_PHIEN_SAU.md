Áp dụng skill web-app-repair-upgrade (bản v3.2.0) cho phiên tiếp theo (P06) của đề án QLTDPRO.
ZIP bàn giao: QLTDPRO_P05_DONGPHIEN_20261107.zip (có sẵn trong repo, thư mục bao-cao/, nhánh ccr-e8514b28-o3ia1p; giải nén vào thư mục tạm).
Hãy: (1) giải nén, đọc handover/HANDOVER.md (phần đầu "ĐÓNG PHIÊN P05") và backlog.json, xác minh MANIFEST.sha256;
(2) kiểm tra môi trường một lần (pip install playwright==1.63.0 xlrd python-docx pdfplumber; Chromium tại /opt/pw-browsers; pandas, openpyxl; Node);
(3) bản hiện hành app/QLTDPRO_P43/app/QLTDPRO_v24.17.34.html; quyết định Q17–Q22 đã chốt, Q7 còn mở.
    Hồi quy v24.17.34 đã đạt 1603 PASS · 0 FAIL; chạy lại làm mốc trước khi sửa (cd app/QLTDPRO_P43 && python3 kiem_thu_chung/chay_hoi_quy.py --app app/QLTDPRO_v24.17.34.html).
    Hạng mục kế: HM-31 (P0) Bàn giao cán bộ tín dụng — làm Giai đoạn 1 trước (mốc theo ngày báo cáo, công thức +/- KH quý, giữ cán bộ đã bàn giao trong tổng, bỏ khớp tên gần đúng), kiểm chứng bằng 4 báo cáo ngày 31/10/2026 người dùng gửi; hỏi người dùng các mục "Cần người dùng" trong HANDOVER;
    sau đó HM-07 → HM-08 → HM-10 → HM-09;
(4) kiểm chứng theo thang V3/V2/V1, bàn giao ZIP sau mỗi hạng mục và hỏi tôi trước khi sang hạng mục kế;
(5) theo dõi ngưỡng ngữ cảnh, giữ dự trữ đóng gói, đóng phiên bằng ZIP khi chạm vùng Đỏ.
Không đưa dữ liệu khách hàng thật (kể cả tệp msit80 .XLS thật) vào repo hay ZIP. Chỉ trả lời bằng tiếng Việt, ngắn gọn.
