# -*- coding: utf-8 -*-
# HM-20 · V3 — Chỉ tiêu kế hoạch: nhãn mốc đúng kỳ (Q14), gom phòng theo khế ước (Q13), bảng 48 cột dễ theo dõi (gd20).
# Dữ liệu thử ẩn danh: kiem_thu_p03/tao_mis80_thu.py (mốc 30/09, 15/10, 31/10/2026) nạp qua #/nhap; đáp án tính ĐỘC LẬP từ tệp xlsx.
# Chạy từ app/QLTDPRO_P43/:  python3 kiem_thu_p04/test_hm20_ctkh.py [app/QLTDPRO_v24.17.21.html]
import asyncio, functools, http.server, threading, re, sys, tempfile, os, subprocess, collections
from pathlib import Path
import openpyxl
from playwright.async_api import async_playwright
HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
APP = sys.argv[1] if len(sys.argv) > 1 else 'app/QLTDPRO_v24.17.21.html'
PORT = 8847; URL = f'http://127.0.0.1:{PORT}/{Path(APP).name}'
EV = ROOT.parent.parent / 'evidence'; SHOT = (EV / 'hm20' / 'anh') if EV.exists() else HERE / 'anh_hm20'; SHOT.mkdir(parents=True, exist_ok=True)
res = []
def ok(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else ' — ' + str(info)[:400]), flush=True)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
threading.Thread(target=http.server.ThreadingHTTPServer(('127.0.0.1', PORT), functools.partial(Q, directory=str(ROOT / Path(APP).parent))).serve_forever, daemon=True).start()

TMP = Path(tempfile.mkdtemp()) / 'm'
subprocess.run([sys.executable, '-I', str(ROOT / 'kiem_thu_p03/tao_mis80_thu.py'), str(ROOT / 'app/kiem_thu_p40/xlsx/msit80_30-09-2026.xlsx'), str(TMP)], check=True, stdout=subprocess.DEVNULL)
FILES = sorted(TMP.iterdir(), key=lambda f: f.name[6:10] + f.name[3:5] + f.name[:2])
def tong(f):
    ws = openpyxl.load_workbook(f, read_only=True).active; rows = list(ws.iter_rows(values_only=True)); h = rows[0]
    b, p = h.index('dsbsbal'), h.index('trctnm'); c = collections.Counter(); s = 0
    for r in rows[1:]: v = r[b] or 0; s += v; c[str(r[p]).strip()] += v
    return s, c
EXP = {f.name[:10]: tong(f) for f in FILES}
S0930, S1031 = EXP['30.09.2026'][0], EXP['31.10.2026'][0]; PH1031 = EXP['31.10.2026'][1]
def num(s):
    t = (s or '').strip(); neg = t.startswith('-') or t.startswith('−'); v = re.sub(r'[^\d]', '', t); return (-int(v) if neg else int(v)) if v else None

async def tab(pg, t):
    await pg.locator('main button', has_text=re.compile('^' + t + '$', re.I)).first.click(); await pg.wait_for_timeout(1200)
async def cell(pg, grid, rowtxt, lb):
    return await pg.evaluate("""([g,rt,lb])=>{const t=document.querySelector('[data-testid='+g+']');if(!t)return null;
      const tr=[...t.tBodies[0].rows].find(r=>r.children[0]&&r.children[0].textContent.trim().toUpperCase().startsWith(rt.toUpperCase()));if(!tr)return '∅row';
      const td=[...tr.children].find(c=>c.getAttribute('data-lb')===lb);return td?td.textContent:'∅col'}""", [grid, rowtxt, lb])

async def run(pw, name, vw, vh):
    b = await pw.chromium.launch(); ctx = await b.new_context(viewport={'width': vw, 'height': vh}, locale='vi-VN')
    await ctx.add_init_script("try{localStorage.setItem('gd9_tplok','0')}catch(e){}")
    pg = await ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    T = lambda s: f'{name}: {s}'
    await pg.goto(URL + '#/nhap', wait_until='domcontentloaded'); await pg.wait_for_timeout(1500)
    await pg.set_input_files('[data-testid="file-input"]', [str(f) for f in FILES]); await pg.wait_for_timeout(3000)
    await pg.locator('[data-testid="chay"]').click(); await pg.wait_for_timeout(800)
    y = pg.locator('[data-testid="confirm-yes"]')
    if await y.count(): await y.click()
    await pg.wait_for_timeout(8000)
    await pg.goto(URL + '#/chi-tieu-ke-hoach', wait_until='domcontentloaded'); await pg.wait_for_timeout(2500)
    # Tổng quan — nhãn mốc (Q14)
    hd = await pg.evaluate("[...document.querySelectorAll('[data-testid=ct-matrix] thead th')].map(t=>t.textContent.trim())")
    ok(T('Q14a Tổng quan: "Đầu Q4/2026 (số dư 30/09/2026)" + "Đầu T11/2026 (số dư 31/10/2026)"'), 'Đầu Q4/2026 (số dư 30/09/2026)' in hd and 'Đầu T11/2026 (số dư 31/10/2026)' in hd, hd)
    vals = await pg.evaluate("""(h)=>{const t=document.querySelector('[data-testid=ct-matrix]');const hs=[...t.querySelectorAll('thead th')].map(x=>x.textContent.trim());
      const tr=[...t.tBodies[0].rows].find(r=>/tổng dư nợ/i.test(r.children[0].textContent));return h.map(k=>tr?tr.children[hs.indexOf(k)].textContent:null)}""", ['Đầu Q4/2026 (số dư 30/09/2026)', 'Đầu T11/2026 (số dư 31/10/2026)'])
    first = [num((re.match(r'\s*\d{1,3}(?:\.\d{3})*', v or '') or [''])[0]) for v in vals]
    ok(T('Q14b số ở cột mốc = Σ dư nợ tệp 30/09 và 31/10 (Python)'), first == [S0930, S1031], (vals, S0930, S1031))
    await pg.screenshot(path=str(SHOT / f'{name}_0_tongquan.png'))
    # Theo CBTD
    await tab(pg, 'THEO CBTD')
    ok(T('U1 có thanh chọn nhóm chỉ tiêu'), await pg.locator('[data-testid=gd20-bar]').count() >= 1)
    if vw >= 1000:
        m = await pg.evaluate("(()=>{const t=document.querySelector('[data-testid=ct-grid-cbtd]');let w=t.parentElement;while(w&&!(/auto|scroll/.test(getComputedStyle(w).overflowX)))w=w.parentElement;return [t.scrollWidth,w?w.clientWidth:0,[...t.tHead.rows[2].children].filter(c=>c.getBoundingClientRect().width>2).length]})()")
        ok(T('U2 mặc định (nhóm Dư nợ) vừa khung 1366, không cuộn ngang'), m[0] <= m[1] + 1 and m[2] <= 18, m)
        await pg.click('[data-testid=gd20-nhom-all]'); await pg.uncheck('[data-testid=gd20-an0]'); await pg.wait_for_timeout(400)
        st = await pg.evaluate("""(async()=>{const t=document.querySelector('[data-testid=ct-grid-cbtd]');let w=t.parentElement;while(w&&!(/auto|scroll/.test(getComputedStyle(w).overflowX)))w=w.parentElement;
          const c=t.tBodies[0].querySelector('tr.gd20-r td');const x0=c.getBoundingClientRect().x;w.scrollLeft=w.scrollWidth;await new Promise(r=>setTimeout(r,200));
          const x1=c.getBoundingClientRect().x;const h=t.tHead.rows[0].children[0].getBoundingClientRect().x;w.scrollLeft=0;return [x0,x1,h,w.scrollWidth>w.clientWidth]})()""")
        ok(T('U3 "Tất cả": cuộn ngang tới cuối vẫn thấy tên CBTD + tiêu đề (cột dính)'), st[3] and abs(st[0] - st[1]) < 1, st)
        await pg.check('[data-testid=gd20-an0]'); await pg.click('[data-testid=gd20-nhom-duno]'); await pg.wait_for_timeout(300)
        await pg.check('[data-testid=gd20-live]'); await pg.wait_for_timeout(300)
        kv = await pg.evaluate("[...document.querySelector('[data-testid=ct-grid-cbtd]').tHead.rows[2].children].filter(c=>c.getBoundingClientRect().width>2).map(c=>c.textContent.trim())")
        ok(T('U4 "Chỉ Live/%HT": không còn cột KH'), kv and 'KH' not in kv and 'Live' in kv, kv)
        await pg.uncheck('[data-testid=gd20-live]'); await pg.wait_for_timeout(300)
    await pg.check('[data-testid=gd20-delta]'); await pg.wait_for_timeout(400)
    dh = await pg.evaluate("[...document.querySelector('[data-testid=ct-grid-cbtd]').tHead.rows[0].children].map(c=>c.textContent.trim())")
    ok(T('Q14c Δ so mốc: "Đầu Q4 (số dư cuối Q3)" và "Đầu T11 (số dư cuối T10)"'), any('Đầu Q4 (số dư cuối Q3)' in x for x in dh) and any('Đầu T11 (số dư cuối T10)' in x for x in dh), dh)
    dq = await cell(pg, 'ct-grid-cbtd', 'TỔNG CHI NHÁNH', 'Δ Tổng dư nợ so Đầu Q4 (số dư cuối Q3)')
    dm = await cell(pg, 'ct-grid-cbtd', 'TỔNG CHI NHÁNH', 'Δ Tổng dư nợ so Đầu T11 (số dư cuối T10)')
    ok(T('Q14d Δ chi nhánh: so đầu Q4 = Σ31/10 − Σ30/09; so đầu T11 = 0'), num(dq) == S1031 - S0930 and num(dm) == 0, (dq, dm, S1031 - S0930))
    lv = await cell(pg, 'ct-grid-cbtd', 'TỔNG CHI NHÁNH', 'Tổng dư nợ · Live')
    ok(T('S1 Live chi nhánh = Σ dư nợ 31/10 (Python)'), num(lv) == S1031, (lv, S1031))
    await pg.screenshot(path=str(SHOT / f'{name}_1_cbtd.png'))
    # Theo phòng — Q13
    await tab(pg, 'THEO PHÒNG')
    got = await pg.evaluate("""()=>{const t=document.querySelector('[data-testid=ct-grid-phong]');return [...t.tBodies[0].rows].map(r=>[r.children[0].textContent.trim(),([...r.children].find(c=>c.getAttribute('data-lb')==='Tổng dư nợ · Live')||{}).textContent])}""")
    gm = {k: num(v) for k, v in got if v is not None}
    want = {'PHÒNG KHÁCH HÀNG': PH1031['Hội Sở'], 'PGD HBT': PH1031['PGD Hai Bà Trưng'], 'PGD SỐ 2': PH1031['PGD Số 2']}
    hit = {k: next((v for kk, v in gm.items() if kk.upper().endswith(k) or kk.upper() == k), None) for k in want}
    ok(T('Q13a Theo phòng: Live mỗi phòng = Σ dư nợ khế ước ghi phòng đó (trctnm, Python)'), hit == want, (got, want))
    tot = next((v for k, v in gm.items() if 'CHI NHÁNH' in k.upper()), None)
    ok(T('Q13b Σ 3 phòng = chi nhánh = Σ tệp 31/10'), sum(want.values()) == S1031 and tot == S1031, (tot, S1031))
    ok(T('Q13c có ghi chú cách gom phòng'), 'PHÒNG GHI TRÊN KHẾ ƯỚC' in await pg.inner_text('main'))
    await pg.screenshot(path=str(SHOT / f'{name}_2_phong.png'))
    await tab(pg, 'THEO LOẠI VAY')
    ok(T('U5 tab Theo loại vay cũng có thanh nhóm'), await pg.evaluate("!!document.querySelector('[data-gd20-bar=ct-grid-loaivay]')"))
    if vw < 600:
        await tab(pg, 'THEO CBTD')
        cd = await pg.evaluate("(()=>{const r=document.querySelector('[data-testid=ct-grid-cbtd] tr.gd20-r');return [getComputedStyle(r).display,Math.round(r.getBoundingClientRect().width),document.documentElement.scrollWidth,innerWidth]})()")
        ok(T('M1 điện thoại: mỗi CBTD một thẻ, không tràn trang'), cd[0] == 'block' and cd[1] <= vw and cd[2] <= cd[3], cd)
        sm = await pg.evaluate("[...document.querySelectorAll('.gd20-bar button,.gd20-bar label')].filter(e=>e.getBoundingClientRect().height<40).length")
        ok(T('M2 nút nhóm ≥ 40 px'), sm == 0, sm)
        await pg.screenshot(path=str(SHOT / f'{name}_3_the.png'))
    ok(T('E1 0 pageerror'), not errs, errs)
    await b.close()

async def main():
    async with async_playwright() as pw:
        await run(pw, 'desktop', 1366, 768); await run(pw, 'mobile', 390, 844)
    print(f'\nKẾT QUẢ: {sum(res)} PASS · {len(res) - sum(res)} FAIL ({APP})'); raise SystemExit(0 if all(res) else 1)
asyncio.run(main())
